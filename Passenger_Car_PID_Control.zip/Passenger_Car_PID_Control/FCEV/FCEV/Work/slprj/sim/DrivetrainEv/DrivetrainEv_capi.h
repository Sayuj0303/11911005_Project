#ifndef RTW_HEADER_DrivetrainEv_capi_h_
#define RTW_HEADER_DrivetrainEv_capi_h_
#include "DrivetrainEv.h"
extern void DrivetrainEv_InitializeDataMapInfo ( hcopmldpph * const
a5ree4wwe5 , lvsoqlxlcs * localDW , edp3webv0p * localX , void * sysRanPtr ,
int contextTid ) ;
#endif
