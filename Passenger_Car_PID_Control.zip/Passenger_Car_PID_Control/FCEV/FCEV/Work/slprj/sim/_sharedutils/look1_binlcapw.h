#ifndef RTW_HEADER_look1_binlcapw_h_
#define RTW_HEADER_look1_binlcapw_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T look1_binlcapw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif
