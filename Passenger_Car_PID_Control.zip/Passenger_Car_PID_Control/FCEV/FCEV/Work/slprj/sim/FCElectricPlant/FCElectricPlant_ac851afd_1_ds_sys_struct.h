#ifndef struct__NeDynamicSystemTag
#define struct__NeDynamicSystemTag
typedef struct _NeDynamicSystemTag { NeDynamicSystem mBase ; int32_T mRefCnt
; PmAllocator mAlloc ; real_T * mField0 ; real_T * mField1 ; real_T * mField2
; real_T * mField3 ; real_T * mField4 ; real_T * mField5 ; real_T * mField6 ;
real_T * mField7 ; real_T * mField8 ; real_T * mField9 ; real_T * mField10 ;
real_T * mField11 ; real_T * mField12 ; real_T * mField13 ; real_T * mField14
; real_T * mField15 ; real_T * mField16 ; real_T * mField17 ; real_T *
mField18 ; real_T * mField19 ; real_T * mField20 ; real_T * mField21 ; real_T
* mField22 ; real_T * mField23 ; real_T * mField24 ; real_T * mField25 ;
real_T * mField26 ; real_T * mField27 ; real_T * mField28 ; real_T * mField29
; real_T * mField30 ; real_T * mField31 ; real_T * mField32 ; real_T *
mField33 ; real_T * mField34 ; real_T * mField35 ; real_T * mField36 ; real_T
* mField37 ; real_T * mField38 ; real_T * mField39 ; real_T * mField40 ;
real_T * mField41 ; real_T * mField42 ; real_T * mField43 ; real_T * mField44
; real_T * mField45 ; real_T * mField46 ; real_T * mField47 ; real_T *
mField48 ; real_T * mField49 ; real_T * mField50 ; real_T * mField51 ; real_T
* mField52 ; } _NeDynamicSystem ;
#else
typedef struct _NeDynamicSystemTag _NeDynamicSystem ;
#endif
