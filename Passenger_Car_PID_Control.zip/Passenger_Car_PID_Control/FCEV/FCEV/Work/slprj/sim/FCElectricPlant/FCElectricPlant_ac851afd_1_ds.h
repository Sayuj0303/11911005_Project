#ifdef __cplusplus
extern "C" {
#endif
#ifndef FCELECTRICPLANT_AC851AFD_1_DS_H
#define FCELECTRICPLANT_AC851AFD_1_DS_H 1
extern NeDynamicSystem * FCElectricPlant_ac851afd_1_dae_ds ( PmAllocator *
allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
