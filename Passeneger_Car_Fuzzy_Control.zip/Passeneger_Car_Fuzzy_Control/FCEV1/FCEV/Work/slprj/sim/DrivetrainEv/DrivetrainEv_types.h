#ifndef RTW_HEADER_DrivetrainEv_types_h_
#define RTW_HEADER_DrivetrainEv_types_h_
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct fu2d21p2me_ fu2d21p2me ; typedef struct k15rssna2x_ k15rssna2x
; typedef struct p4tcmhlmqo_ p4tcmhlmqo ; typedef struct j3ujqghva4_
j3ujqghva4 ; typedef struct aremv21hur_ aremv21hur ; typedef struct
pymb3fi5g4_ pymb3fi5g4 ; typedef struct gwbuyqty4q_ gwbuyqty4q ; typedef
struct eyoob242x4_ eyoob242x4 ; typedef struct lu0k1fvhhc_ lu0k1fvhhc ;
typedef struct akbgnuupjzy_ akbgnuupjzy ; typedef struct kz1ziyy35g
hcopmldpph ;
#endif
