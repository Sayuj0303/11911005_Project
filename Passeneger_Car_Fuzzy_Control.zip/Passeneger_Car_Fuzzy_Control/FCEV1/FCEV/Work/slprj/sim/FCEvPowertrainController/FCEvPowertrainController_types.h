#ifndef RTW_HEADER_FCEvPowertrainController_types_h_
#define RTW_HEADER_FCEvPowertrainController_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_IDgMmAocjV2Mcx0AXuhokB_
#define DEFINED_TYPEDEF_FOR_struct_IDgMmAocjV2Mcx0AXuhokB_
typedef struct { real_T maxPWR ; real_T opLimit ; real_T minV ; real_T SOCtgt
; real_T tempTgt ; } struct_IDgMmAocjV2Mcx0AXuhokB ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_IrVVNAL3AYACbvpTBmlCsC_
#define DEFINED_TYPEDEF_FOR_struct_IrVVNAL3AYACbvpTBmlCsC_
typedef struct { uint8_T SimulinkDiagnostic ; uint8_T Model [ 42 ] ; uint8_T
Block [ 66 ] ; uint8_T OutOfRangeInputValue ; uint8_T NoRuleFired ; uint8_T
EmptyOutputFuzzySet ; } struct_IrVVNAL3AYACbvpTBmlCsC ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_nDiNttezQ8pHMZv76leKsH_
#define DEFINED_TYPEDEF_FOR_struct_nDiNttezQ8pHMZv76leKsH_
typedef struct { uint8_T type [ 6 ] ; uint8_T sl_padding0 [ 2 ] ; int32_T
origTypeLength ; uint8_T sl_padding1 [ 4 ] ; real_T params [ 4 ] ; int32_T
origParamLength ; uint8_T sl_padding2 [ 4 ] ; } struct_nDiNttezQ8pHMZv76leKsH
;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_rymdL7RCSjnd1DH1clnSMH_
#define DEFINED_TYPEDEF_FOR_struct_rymdL7RCSjnd1DH1clnSMH_
typedef struct { struct_nDiNttezQ8pHMZv76leKsH mf [ 5 ] ; int32_T origNumMF ;
uint8_T sl_padding0 [ 4 ] ; } struct_rymdL7RCSjnd1DH1clnSMH ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_qH4Unbydb9KS7ehcrvtFcB_
#define DEFINED_TYPEDEF_FOR_struct_qH4Unbydb9KS7ehcrvtFcB_
typedef struct { uint8_T type [ 8 ] ; int32_T origTypeLength ; uint8_T
sl_padding0 [ 4 ] ; real_T params ; int32_T origParamLength ; uint8_T
sl_padding1 [ 4 ] ; } struct_qH4Unbydb9KS7ehcrvtFcB ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_5glPHvFHAiiblwOGTVSKoE_
#define DEFINED_TYPEDEF_FOR_struct_5glPHvFHAiiblwOGTVSKoE_
typedef struct { struct_qH4Unbydb9KS7ehcrvtFcB mf [ 5 ] ; int32_T origNumMF ;
uint8_T sl_padding0 [ 4 ] ; } struct_5glPHvFHAiiblwOGTVSKoE ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_7Lqzn3wFo4w8m6DtNU4MYG_
#define DEFINED_TYPEDEF_FOR_struct_7Lqzn3wFo4w8m6DtNU4MYG_
typedef struct { uint8_T type [ 6 ] ; uint8_T andMethod [ 4 ] ; uint8_T
orMethod [ 6 ] ; uint8_T defuzzMethod [ 6 ] ; uint8_T impMethod [ 4 ] ;
uint8_T aggMethod [ 3 ] ; uint8_T sl_padding0 [ 3 ] ; real_T inputRange [ 4 ]
; real_T outputRange [ 2 ] ; struct_rymdL7RCSjnd1DH1clnSMH inputMF [ 2 ] ;
struct_5glPHvFHAiiblwOGTVSKoE outputMF ; real_T antecedent [ 30 ] ; real_T
consequent [ 15 ] ; real_T connection [ 15 ] ; real_T weight [ 15 ] ; int32_T
numSamples ; int32_T numInputs ; int32_T numOutputs ; int32_T numRules ;
int32_T numInputMFs [ 2 ] ; int32_T numCumInputMFs [ 2 ] ; int32_T
numOutputMFs ; int32_T numCumOutputMFs ; real_T outputSamplePoints ; int32_T
orrSize [ 2 ] ; int32_T aggSize [ 2 ] ; int32_T irrSize [ 2 ] ; int32_T
rfsSize [ 2 ] ; int32_T sumSize [ 2 ] ; int32_T inputFuzzySetType ; uint8_T
sl_padding1 [ 4 ] ; } struct_7Lqzn3wFo4w8m6DtNU4MYG ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 24
#endif
#ifndef SS_INT64
#define SS_INT64 25
#endif
typedef struct gdngfg3ibwc_ gdngfg3ibwc ; typedef struct ax55bwwar2
ezkw1qrycv ;
#endif
