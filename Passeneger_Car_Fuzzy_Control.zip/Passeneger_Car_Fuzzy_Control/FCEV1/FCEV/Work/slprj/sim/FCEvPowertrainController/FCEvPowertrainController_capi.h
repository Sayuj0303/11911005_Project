#ifndef RTW_HEADER_FCEvPowertrainController_capi_h_
#define RTW_HEADER_FCEvPowertrainController_capi_h_
#include "FCEvPowertrainController.h"
extern void FCEvPowertrainController_InitializeDataMapInfo ( ezkw1qrycv *
const jxp0bqrs0w , void * sysRanPtr , int contextTid ) ;
#endif
