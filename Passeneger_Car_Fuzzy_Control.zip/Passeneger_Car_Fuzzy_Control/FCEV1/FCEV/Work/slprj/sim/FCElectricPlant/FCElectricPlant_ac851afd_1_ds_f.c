#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_f.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_f ( const NeDynamicSystem * LC , const
NeDynamicSystemInput * t5710 , NeDsMethodOutput * t5711 ) { ETTS0 acb_efOut ;
ETTS0 ae_efOut ; ETTS0 aj_efOut ; ETTS0 ak_efOut ; ETTS0 ap_efOut ; ETTS0
av_efOut ; ETTS0 b_efOut ; ETTS0 bb_efOut ; ETTS0 bbb_efOut ; ETTS0 bdb_efOut
; ETTS0 bh_efOut ; ETTS0 bo_efOut ; ETTS0 bu_efOut ; ETTS0 cab_efOut ; ETTS0
cb_efOut ; ETTS0 cm_efOut ; ETTS0 cp_efOut ; ETTS0 ct_efOut ; ETTS0 cx_efOut
; ETTS0 d_efOut ; ETTS0 dc_efOut ; ETTS0 ddb_efOut ; ETTS0 dn_efOut ; ETTS0
ds_efOut ; ETTS0 dy_efOut ; ETTS0 eb_efOut ; ETTS0 ecb_efOut ; ETTS0 ed_efOut
; ETTS0 ee_efOut ; ETTS0 efOut ; ETTS0 ek_efOut ; ETTS0 en_efOut ; ETTS0
ep_efOut ; ETTS0 er_efOut ; ETTS0 ev_efOut ; ETTS0 f_efOut ; ETTS0 fb_efOut ;
ETTS0 fbb_efOut ; ETTS0 fc_efOut ; ETTS0 fd_efOut ; ETTS0 fdb_efOut ; ETTS0
fo_efOut ; ETTS0 fq_efOut ; ETTS0 fu_efOut ; ETTS0 g_efOut ; ETTS0 gab_efOut
; ETTS0 gc_efOut ; ETTS0 gm_efOut ; ETTS0 gn_efOut ; ETTS0 gt_efOut ; ETTS0
hb_efOut ; ETTS0 hdb_efOut ; ETTS0 ho_efOut ; ETTS0 hs_efOut ; ETTS0 hy_efOut
; ETTS0 i_efOut ; ETTS0 ib_efOut ; ETTS0 ic_efOut ; ETTS0 icb_efOut ; ETTS0
in_efOut ; ETTS0 ip_efOut ; ETTS0 iv_efOut ; ETTS0 jbb_efOut ; ETTS0 jd_efOut
; ETTS0 jdb_efOut ; ETTS0 jo_efOut ; ETTS0 jq_efOut ; ETTS0 ju_efOut ; ETTS0
jw_efOut ; ETTS0 k_efOut ; ETTS0 kab_efOut ; ETTS0 kb_efOut ; ETTS0 kc_efOut
; ETTS0 kg_efOut ; ETTS0 ko_efOut ; ETTS0 kp_efOut ; ETTS0 kt_efOut ; ETTS0
l_efOut ; ETTS0 ld_efOut ; ETTS0 le_efOut ; ETTS0 lf_efOut ; ETTS0 lk_efOut ;
ETTS0 ll_efOut ; ETTS0 ln_efOut ; ETTS0 ly_efOut ; ETTS0 mb_efOut ; ETTS0
mcb_efOut ; ETTS0 mn_efOut ; ETTS0 mp_efOut ; ETTS0 mv_efOut ; ETTS0 n_efOut
; ETTS0 nb_efOut ; ETTS0 nbb_efOut ; ETTS0 nd_efOut ; ETTS0 nh_efOut ; ETTS0
nj_efOut ; ETTS0 nm_efOut ; ETTS0 np_efOut ; ETTS0 ns_efOut ; ETTS0 nu_efOut
; ETTS0 o_efOut ; ETTS0 oab_efOut ; ETTS0 odb_efOut ; ETTS0 oi_efOut ; ETTS0
on_efOut ; ETTS0 ot_efOut ; ETTS0 pb_efOut ; ETTS0 pc_efOut ; ETTS0 pdb_efOut
; ETTS0 pf_efOut ; ETTS0 pl_efOut ; ETTS0 py_efOut ; ETTS0 q_efOut ; ETTS0
qc_efOut ; ETTS0 qcb_efOut ; ETTS0 qdb_efOut ; ETTS0 qn_efOut ; ETTS0
qq_efOut ; ETTS0 qr_efOut ; ETTS0 qv_efOut ; ETTS0 r_efOut ; ETTS0 rb_efOut ;
ETTS0 rbb_efOut ; ETTS0 rdb_efOut ; ETTS0 rh_efOut ; ETTS0 rn_efOut ; ETTS0
ro_efOut ; ETTS0 ru_efOut ; ETTS0 sab_efOut ; ETTS0 sb_efOut ; ETTS0 sd_efOut
; ETTS0 sdb_efOut ; ETTS0 si_efOut ; ETTS0 st_efOut ; ETTS0 t101 ; ETTS0 t102
; ETTS0 t109 ; ETTS0 t116 ; ETTS0 t123 ; ETTS0 t125 ; ETTS0 t136 ; ETTS0 t137
; ETTS0 t139 ; ETTS0 t140 ; ETTS0 t142 ; ETTS0 t146 ; ETTS0 t148 ; ETTS0 t153
; ETTS0 t154 ; ETTS0 t156 ; ETTS0 t158 ; ETTS0 t159 ; ETTS0 t163 ; ETTS0 t166
; ETTS0 t170 ; ETTS0 t171 ; ETTS0 t173 ; ETTS0 t177 ; ETTS0 t178 ; ETTS0 t179
; ETTS0 t180 ; ETTS0 t182 ; ETTS0 t187 ; ETTS0 t188 ; ETTS0 t190 ; ETTS0 t193
; ETTS0 t3 ; ETTS0 t45 ; ETTS0 t51 ; ETTS0 t52 ; ETTS0 t53 ; ETTS0 t54 ;
ETTS0 t55 ; ETTS0 t56 ; ETTS0 t57 ; ETTS0 t59 ; ETTS0 t62 ; ETTS0 t71 ; ETTS0
t77 ; ETTS0 t81 ; ETTS0 t88 ; ETTS0 t95 ; ETTS0 t99 ; ETTS0 t_efOut ; ETTS0
td_efOut ; ETTS0 tdb_efOut ; ETTS0 tn_efOut ; ETTS0 to_efOut ; ETTS0 ts_efOut
; ETTS0 tw_efOut ; ETTS0 ty_efOut ; ETTS0 ub_efOut ; ETTS0 uc_efOut ; ETTS0
ucb_efOut ; ETTS0 udb_efOut ; ETTS0 uo_efOut ; ETTS0 up_efOut ; ETTS0
ur_efOut ; ETTS0 uv_efOut ; ETTS0 ux_efOut ; ETTS0 v_efOut ; ETTS0 vb_efOut ;
ETTS0 vbb_efOut ; ETTS0 vd_efOut ; ETTS0 vdb_efOut ; ETTS0 vn_efOut ; ETTS0
vu_efOut ; ETTS0 vx_efOut ; ETTS0 w_efOut ; ETTS0 wab_efOut ; ETTS0 wc_efOut
; ETTS0 wcb_efOut ; ETTS0 wdb_efOut ; ETTS0 wf_efOut ; ETTS0 wg_efOut ; ETTS0
wn_efOut ; ETTS0 wo_efOut ; ETTS0 wp_efOut ; ETTS0 wt_efOut ; ETTS0 xb_efOut
; ETTS0 xd_efOut ; ETTS0 xs_efOut ; ETTS0 xw_efOut ; ETTS0 xy_efOut ; ETTS0
y_efOut ; ETTS0 yb_efOut ; ETTS0 yc_efOut ; ETTS0 ycb_efOut ; ETTS0 ye_efOut
; ETTS0 yh_efOut ; ETTS0 yk_efOut ; ETTS0 yn_efOut ; ETTS0 yo_efOut ; ETTS0
yp_efOut ; ETTS0 yr_efOut ; ETTS0 yv_efOut ; ETTS0 yx_efOut ; PmRealVector
out ; real_T X [ 582 ] ; real_T t2047 [ 582 ] ; real_T nonscalar1 [ 7 ] ;
real_T nonscalar59 [ 7 ] ; real_T nonscalar58 [ 6 ] ; real_T nonscalar63 [ 5
] ; real_T nonscalar64 [ 3 ] ; real_T t2626 [ 2 ] ; real_T aab_efOut [ 1 ] ;
real_T ab_efOut [ 1 ] ; real_T abb_efOut [ 1 ] ; real_T ac_efOut [ 1 ] ;
real_T ad_efOut [ 1 ] ; real_T adb_efOut [ 1 ] ; real_T aeb_efOut [ 1 ] ;
real_T af_efOut [ 1 ] ; real_T afb_efOut [ 1 ] ; real_T ag_efOut [ 1 ] ;
real_T ah_efOut [ 1 ] ; real_T ai_efOut [ 1 ] ; real_T al_efOut [ 1 ] ;
real_T am_efOut [ 1 ] ; real_T an_efOut [ 1 ] ; real_T ao_efOut [ 1 ] ;
real_T aq_efOut [ 1 ] ; real_T ar_efOut [ 1 ] ; real_T as_efOut [ 1 ] ;
real_T at_efOut [ 1 ] ; real_T au_efOut [ 1 ] ; real_T aw_efOut [ 1 ] ;
real_T ax_efOut [ 1 ] ; real_T ay_efOut [ 1 ] ; real_T bab_efOut [ 1 ] ;
real_T bc_efOut [ 1 ] ; real_T bcb_efOut [ 1 ] ; real_T bd_efOut [ 1 ] ;
real_T be_efOut [ 1 ] ; real_T beb_efOut [ 1 ] ; real_T bf_efOut [ 1 ] ;
real_T bfb_efOut [ 1 ] ; real_T bg_efOut [ 1 ] ; real_T bi_efOut [ 1 ] ;
real_T bj_efOut [ 1 ] ; real_T bk_efOut [ 1 ] ; real_T bl_efOut [ 1 ] ;
real_T bm_efOut [ 1 ] ; real_T bn_efOut [ 1 ] ; real_T bp_efOut [ 1 ] ;
real_T bq_efOut [ 1 ] ; real_T br_efOut [ 1 ] ; real_T bs_efOut [ 1 ] ;
real_T bt_efOut [ 1 ] ; real_T bv_efOut [ 1 ] ; real_T bw_efOut [ 1 ] ;
real_T bx_efOut [ 1 ] ; real_T by_efOut [ 1 ] ; real_T c_efOut [ 1 ] ; real_T
cbb_efOut [ 1 ] ; real_T cc_efOut [ 1 ] ; real_T ccb_efOut [ 1 ] ; real_T
cd_efOut [ 1 ] ; real_T cdb_efOut [ 1 ] ; real_T ce_efOut [ 1 ] ; real_T
ceb_efOut [ 1 ] ; real_T cf_efOut [ 1 ] ; real_T cfb_efOut [ 1 ] ; real_T
cg_efOut [ 1 ] ; real_T ch_efOut [ 1 ] ; real_T ci_efOut [ 1 ] ; real_T
cj_efOut [ 1 ] ; real_T ck_efOut [ 1 ] ; real_T cl_efOut [ 1 ] ; real_T
cn_efOut [ 1 ] ; real_T co_efOut [ 1 ] ; real_T cq_efOut [ 1 ] ; real_T
cr_efOut [ 1 ] ; real_T cs_efOut [ 1 ] ; real_T cu_efOut [ 1 ] ; real_T
cv_efOut [ 1 ] ; real_T cw_efOut [ 1 ] ; real_T cy_efOut [ 1 ] ; real_T
dab_efOut [ 1 ] ; real_T db_efOut [ 1 ] ; real_T dbb_efOut [ 1 ] ; real_T
dcb_efOut [ 1 ] ; real_T dd_efOut [ 1 ] ; real_T de_efOut [ 1 ] ; real_T
deb_efOut [ 1 ] ; real_T df_efOut [ 1 ] ; real_T dfb_efOut [ 1 ] ; real_T
dg_efOut [ 1 ] ; real_T dh_efOut [ 1 ] ; real_T di_efOut [ 1 ] ; real_T
dj_efOut [ 1 ] ; real_T dk_efOut [ 1 ] ; real_T dl_efOut [ 1 ] ; real_T
dm_efOut [ 1 ] ; real_T do_efOut [ 1 ] ; real_T dp_efOut [ 1 ] ; real_T
dq_efOut [ 1 ] ; real_T dr_efOut [ 1 ] ; real_T dt_efOut [ 1 ] ; real_T
du_efOut [ 1 ] ; real_T dv_efOut [ 1 ] ; real_T dw_efOut [ 1 ] ; real_T
dx_efOut [ 1 ] ; real_T e_efOut [ 1 ] ; real_T eab_efOut [ 1 ] ; real_T
ebb_efOut [ 1 ] ; real_T ec_efOut [ 1 ] ; real_T edb_efOut [ 1 ] ; real_T
eeb_efOut [ 1 ] ; real_T ef_efOut [ 1 ] ; real_T efb_efOut [ 1 ] ; real_T
eg_efOut [ 1 ] ; real_T eh_efOut [ 1 ] ; real_T ei_efOut [ 1 ] ; real_T
ej_efOut [ 1 ] ; real_T el_efOut [ 1 ] ; real_T em_efOut [ 1 ] ; real_T
eo_efOut [ 1 ] ; real_T eq_efOut [ 1 ] ; real_T es_efOut [ 1 ] ; real_T
et_efOut [ 1 ] ; real_T eu_efOut [ 1 ] ; real_T ew_efOut [ 1 ] ; real_T
ex_efOut [ 1 ] ; real_T ey_efOut [ 1 ] ; real_T fab_efOut [ 1 ] ; real_T
fcb_efOut [ 1 ] ; real_T fe_efOut [ 1 ] ; real_T feb_efOut [ 1 ] ; real_T
ff_efOut [ 1 ] ; real_T ffb_efOut [ 1 ] ; real_T fg_efOut [ 1 ] ; real_T
fh_efOut [ 1 ] ; real_T fi_efOut [ 1 ] ; real_T fj_efOut [ 1 ] ; real_T
fk_efOut [ 1 ] ; real_T fl_efOut [ 1 ] ; real_T fm_efOut [ 1 ] ; real_T
fn_efOut [ 1 ] ; real_T fp_efOut [ 1 ] ; real_T fr_efOut [ 1 ] ; real_T
fs_efOut [ 1 ] ; real_T ft_efOut [ 1 ] ; real_T fv_efOut [ 1 ] ; real_T
fw_efOut [ 1 ] ; real_T fx_efOut [ 1 ] ; real_T fy_efOut [ 1 ] ; real_T
gb_efOut [ 1 ] ; real_T gbb_efOut [ 1 ] ; real_T gcb_efOut [ 1 ] ; real_T
gd_efOut [ 1 ] ; real_T gdb_efOut [ 1 ] ; real_T ge_efOut [ 1 ] ; real_T
geb_efOut [ 1 ] ; real_T gf_efOut [ 1 ] ; real_T gfb_efOut [ 1 ] ; real_T
gg_efOut [ 1 ] ; real_T gh_efOut [ 1 ] ; real_T gi_efOut [ 1 ] ; real_T
gj_efOut [ 1 ] ; real_T gk_efOut [ 1 ] ; real_T gl_efOut [ 1 ] ; real_T
go_efOut [ 1 ] ; real_T gp_efOut [ 1 ] ; real_T gq_efOut [ 1 ] ; real_T
gr_efOut [ 1 ] ; real_T gs_efOut [ 1 ] ; real_T gu_efOut [ 1 ] ; real_T
gv_efOut [ 1 ] ; real_T gw_efOut [ 1 ] ; real_T gx_efOut [ 1 ] ; real_T
gy_efOut [ 1 ] ; real_T h_efOut [ 1 ] ; real_T hab_efOut [ 1 ] ; real_T
hbb_efOut [ 1 ] ; real_T hc_efOut [ 1 ] ; real_T hcb_efOut [ 1 ] ; real_T
hd_efOut [ 1 ] ; real_T he_efOut [ 1 ] ; real_T heb_efOut [ 1 ] ; real_T
hf_efOut [ 1 ] ; real_T hg_efOut [ 1 ] ; real_T hh_efOut [ 1 ] ; real_T
hi_efOut [ 1 ] ; real_T hj_efOut [ 1 ] ; real_T hk_efOut [ 1 ] ; real_T
hl_efOut [ 1 ] ; real_T hm_efOut [ 1 ] ; real_T hn_efOut [ 1 ] ; real_T
hp_efOut [ 1 ] ; real_T hq_efOut [ 1 ] ; real_T hr_efOut [ 1 ] ; real_T
ht_efOut [ 1 ] ; real_T hu_efOut [ 1 ] ; real_T hv_efOut [ 1 ] ; real_T
hw_efOut [ 1 ] ; real_T hx_efOut [ 1 ] ; real_T iab_efOut [ 1 ] ; real_T
ibb_efOut [ 1 ] ; real_T id_efOut [ 1 ] ; real_T idb_efOut [ 1 ] ; real_T
ie_efOut [ 1 ] ; real_T ieb_efOut [ 1 ] ; real_T if_efOut [ 1 ] ; real_T
ig_efOut [ 1 ] ; real_T ih_efOut [ 1 ] ; real_T ii_efOut [ 1 ] ; real_T
ij_efOut [ 1 ] ; real_T ik_efOut [ 1 ] ; real_T il_efOut [ 1 ] ; real_T
im_efOut [ 1 ] ; real_T io_efOut [ 1 ] ; real_T iq_efOut [ 1 ] ; real_T
ir_efOut [ 1 ] ; real_T is_efOut [ 1 ] ; real_T it_efOut [ 1 ] ; real_T
iu_efOut [ 1 ] ; real_T iw_efOut [ 1 ] ; real_T ix_efOut [ 1 ] ; real_T
iy_efOut [ 1 ] ; real_T j_efOut [ 1 ] ; real_T jab_efOut [ 1 ] ; real_T
jb_efOut [ 1 ] ; real_T jc_efOut [ 1 ] ; real_T jcb_efOut [ 1 ] ; real_T
je_efOut [ 1 ] ; real_T jeb_efOut [ 1 ] ; real_T jf_efOut [ 1 ] ; real_T
jg_efOut [ 1 ] ; real_T jh_efOut [ 1 ] ; real_T ji_efOut [ 1 ] ; real_T
jj_efOut [ 1 ] ; real_T jk_efOut [ 1 ] ; real_T jl_efOut [ 1 ] ; real_T
jm_efOut [ 1 ] ; real_T jn_efOut [ 1 ] ; real_T jp_efOut [ 1 ] ; real_T
jr_efOut [ 1 ] ; real_T js_efOut [ 1 ] ; real_T jt_efOut [ 1 ] ; real_T
jv_efOut [ 1 ] ; real_T jx_efOut [ 1 ] ; real_T jy_efOut [ 1 ] ; real_T
kbb_efOut [ 1 ] ; real_T kcb_efOut [ 1 ] ; real_T kd_efOut [ 1 ] ; real_T
kdb_efOut [ 1 ] ; real_T ke_efOut [ 1 ] ; real_T keb_efOut [ 1 ] ; real_T
kf_efOut [ 1 ] ; real_T kh_efOut [ 1 ] ; real_T ki_efOut [ 1 ] ; real_T
kj_efOut [ 1 ] ; real_T kk_efOut [ 1 ] ; real_T kl_efOut [ 1 ] ; real_T
km_efOut [ 1 ] ; real_T kn_efOut [ 1 ] ; real_T kq_efOut [ 1 ] ; real_T
kr_efOut [ 1 ] ; real_T ks_efOut [ 1 ] ; real_T ku_efOut [ 1 ] ; real_T
kv_efOut [ 1 ] ; real_T kw_efOut [ 1 ] ; real_T kx_efOut [ 1 ] ; real_T
ky_efOut [ 1 ] ; real_T lab_efOut [ 1 ] ; real_T lb_efOut [ 1 ] ; real_T
lbb_efOut [ 1 ] ; real_T lc_efOut [ 1 ] ; real_T lcb_efOut [ 1 ] ; real_T
ldb_efOut [ 1 ] ; real_T leb_efOut [ 1 ] ; real_T lg_efOut [ 1 ] ; real_T
lh_efOut [ 1 ] ; real_T li_efOut [ 1 ] ; real_T lj_efOut [ 1 ] ; real_T
lm_efOut [ 1 ] ; real_T lo_efOut [ 1 ] ; real_T lp_efOut [ 1 ] ; real_T
lq_efOut [ 1 ] ; real_T lr_efOut [ 1 ] ; real_T ls_efOut [ 1 ] ; real_T
lt_efOut [ 1 ] ; real_T lu_efOut [ 1 ] ; real_T lv_efOut [ 1 ] ; real_T
lw_efOut [ 1 ] ; real_T lx_efOut [ 1 ] ; real_T m_efOut [ 1 ] ; real_T
mab_efOut [ 1 ] ; real_T mbb_efOut [ 1 ] ; real_T mc_efOut [ 1 ] ; real_T
md_efOut [ 1 ] ; real_T mdb_efOut [ 1 ] ; real_T me_efOut [ 1 ] ; real_T
meb_efOut [ 1 ] ; real_T mf_efOut [ 1 ] ; real_T mg_efOut [ 1 ] ; real_T
mh_efOut [ 1 ] ; real_T mi_efOut [ 1 ] ; real_T mj_efOut [ 1 ] ; real_T
mk_efOut [ 1 ] ; real_T ml_efOut [ 1 ] ; real_T mm_efOut [ 1 ] ; real_T
mo_efOut [ 1 ] ; real_T mq_efOut [ 1 ] ; real_T mr_efOut [ 1 ] ; real_T
ms_efOut [ 1 ] ; real_T mt_efOut [ 1 ] ; real_T mu_efOut [ 1 ] ; real_T
mw_efOut [ 1 ] ; real_T mx_efOut [ 1 ] ; real_T my_efOut [ 1 ] ; real_T
nab_efOut [ 1 ] ; real_T nc_efOut [ 1 ] ; real_T ncb_efOut [ 1 ] ; real_T
ndb_efOut [ 1 ] ; real_T ne_efOut [ 1 ] ; real_T neb_efOut [ 1 ] ; real_T
nf_efOut [ 1 ] ; real_T ng_efOut [ 1 ] ; real_T ni_efOut [ 1 ] ; real_T
nk_efOut [ 1 ] ; real_T nl_efOut [ 1 ] ; real_T nn_efOut [ 1 ] ; real_T
no_efOut [ 1 ] ; real_T nq_efOut [ 1 ] ; real_T nr_efOut [ 1 ] ; real_T
nt_efOut [ 1 ] ; real_T nv_efOut [ 1 ] ; real_T nw_efOut [ 1 ] ; real_T
nx_efOut [ 1 ] ; real_T ny_efOut [ 1 ] ; real_T ob_efOut [ 1 ] ; real_T
obb_efOut [ 1 ] ; real_T oc_efOut [ 1 ] ; real_T ocb_efOut [ 1 ] ; real_T
od_efOut [ 1 ] ; real_T oe_efOut [ 1 ] ; real_T oeb_efOut [ 1 ] ; real_T
of_efOut [ 1 ] ; real_T og_efOut [ 1 ] ; real_T oh_efOut [ 1 ] ; real_T
oj_efOut [ 1 ] ; real_T ok_efOut [ 1 ] ; real_T ol_efOut [ 1 ] ; real_T
om_efOut [ 1 ] ; real_T oo_efOut [ 1 ] ; real_T op_efOut [ 1 ] ; real_T
oq_efOut [ 1 ] ; real_T or_efOut [ 1 ] ; real_T os_efOut [ 1 ] ; real_T
ou_efOut [ 1 ] ; real_T ov_efOut [ 1 ] ; real_T ow_efOut [ 1 ] ; real_T
ox_efOut [ 1 ] ; real_T oy_efOut [ 1 ] ; real_T p_efOut [ 1 ] ; real_T
pab_efOut [ 1 ] ; real_T pbb_efOut [ 1 ] ; real_T pcb_efOut [ 1 ] ; real_T
pd_efOut [ 1 ] ; real_T pe_efOut [ 1 ] ; real_T peb_efOut [ 1 ] ; real_T
pg_efOut [ 1 ] ; real_T ph_efOut [ 1 ] ; real_T pi_efOut [ 1 ] ; real_T
pj_efOut [ 1 ] ; real_T pk_efOut [ 1 ] ; real_T pm_efOut [ 1 ] ; real_T
pn_efOut [ 1 ] ; real_T po_efOut [ 1 ] ; real_T pp_efOut [ 1 ] ; real_T
pq_efOut [ 1 ] ; real_T pr_efOut [ 1 ] ; real_T ps_efOut [ 1 ] ; real_T
pt_efOut [ 1 ] ; real_T pu_efOut [ 1 ] ; real_T pv_efOut [ 1 ] ; real_T
pw_efOut [ 1 ] ; real_T px_efOut [ 1 ] ; real_T qab_efOut [ 1 ] ; real_T
qb_efOut [ 1 ] ; real_T qbb_efOut [ 1 ] ; real_T qd_efOut [ 1 ] ; real_T
qe_efOut [ 1 ] ; real_T qeb_efOut [ 1 ] ; real_T qf_efOut [ 1 ] ; real_T
qg_efOut [ 1 ] ; real_T qh_efOut [ 1 ] ; real_T qi_efOut [ 1 ] ; real_T
qj_efOut [ 1 ] ; real_T qk_efOut [ 1 ] ; real_T ql_efOut [ 1 ] ; real_T
qm_efOut [ 1 ] ; real_T qo_efOut [ 1 ] ; real_T qp_efOut [ 1 ] ; real_T
qs_efOut [ 1 ] ; real_T qt_efOut [ 1 ] ; real_T qu_efOut [ 1 ] ; real_T
qw_efOut [ 1 ] ; real_T qx_efOut [ 1 ] ; real_T qy_efOut [ 1 ] ; real_T
rab_efOut [ 1 ] ; real_T rc_efOut [ 1 ] ; real_T rcb_efOut [ 1 ] ; real_T
rd_efOut [ 1 ] ; real_T re_efOut [ 1 ] ; real_T reb_efOut [ 1 ] ; real_T
rf_efOut [ 1 ] ; real_T rg_efOut [ 1 ] ; real_T ri_efOut [ 1 ] ; real_T
rj_efOut [ 1 ] ; real_T rk_efOut [ 1 ] ; real_T rl_efOut [ 1 ] ; real_T
rm_efOut [ 1 ] ; real_T rp_efOut [ 1 ] ; real_T rq_efOut [ 1 ] ; real_T
rr_efOut [ 1 ] ; real_T rs_efOut [ 1 ] ; real_T rt_efOut [ 1 ] ; real_T
rv_efOut [ 1 ] ; real_T rw_efOut [ 1 ] ; real_T rx_efOut [ 1 ] ; real_T
ry_efOut [ 1 ] ; real_T s_efOut [ 1 ] ; real_T sbb_efOut [ 1 ] ; real_T
sc_efOut [ 1 ] ; real_T scb_efOut [ 1 ] ; real_T se_efOut [ 1 ] ; real_T
seb_efOut [ 1 ] ; real_T sf_efOut [ 1 ] ; real_T sg_efOut [ 1 ] ; real_T
sh_efOut [ 1 ] ; real_T sj_efOut [ 1 ] ; real_T sk_efOut [ 1 ] ; real_T
sl_efOut [ 1 ] ; real_T sm_efOut [ 1 ] ; real_T sn_efOut [ 1 ] ; real_T
so_efOut [ 1 ] ; real_T sp_efOut [ 1 ] ; real_T sq_efOut [ 1 ] ; real_T
sr_efOut [ 1 ] ; real_T ss_efOut [ 1 ] ; real_T su_efOut [ 1 ] ; real_T
sv_efOut [ 1 ] ; real_T sw_efOut [ 1 ] ; real_T sx_efOut [ 1 ] ; real_T
sy_efOut [ 1 ] ; real_T t1941 [ 1 ] ; real_T t2049 [ 1 ] ; real_T t226 [ 1 ]
; real_T t2583 [ 1 ] ; real_T tab_efOut [ 1 ] ; real_T tb_efOut [ 1 ] ;
real_T tbb_efOut [ 1 ] ; real_T tc_efOut [ 1 ] ; real_T tcb_efOut [ 1 ] ;
real_T te_efOut [ 1 ] ; real_T teb_efOut [ 1 ] ; real_T tf_efOut [ 1 ] ;
real_T tg_efOut [ 1 ] ; real_T th_efOut [ 1 ] ; real_T ti_efOut [ 1 ] ;
real_T tj_efOut [ 1 ] ; real_T tk_efOut [ 1 ] ; real_T tl_efOut [ 1 ] ;
real_T tm_efOut [ 1 ] ; real_T tp_efOut [ 1 ] ; real_T tq_efOut [ 1 ] ;
real_T tr_efOut [ 1 ] ; real_T tt_efOut [ 1 ] ; real_T tu_efOut [ 1 ] ;
real_T tv_efOut [ 1 ] ; real_T tx_efOut [ 1 ] ; real_T u_efOut [ 1 ] ; real_T
uab_efOut [ 1 ] ; real_T ubb_efOut [ 1 ] ; real_T ud_efOut [ 1 ] ; real_T
ue_efOut [ 1 ] ; real_T ueb_efOut [ 1 ] ; real_T uf_efOut [ 1 ] ; real_T
ug_efOut [ 1 ] ; real_T uh_efOut [ 1 ] ; real_T ui_efOut [ 1 ] ; real_T
uj_efOut [ 1 ] ; real_T uk_efOut [ 1 ] ; real_T ul_efOut [ 1 ] ; real_T
um_efOut [ 1 ] ; real_T un_efOut [ 1 ] ; real_T uq_efOut [ 1 ] ; real_T
us_efOut [ 1 ] ; real_T ut_efOut [ 1 ] ; real_T uu_efOut [ 1 ] ; real_T
uw_efOut [ 1 ] ; real_T uy_efOut [ 1 ] ; real_T vab_efOut [ 1 ] ; real_T
vc_efOut [ 1 ] ; real_T vcb_efOut [ 1 ] ; real_T ve_efOut [ 1 ] ; real_T
veb_efOut [ 1 ] ; real_T vf_efOut [ 1 ] ; real_T vg_efOut [ 1 ] ; real_T
vh_efOut [ 1 ] ; real_T vi_efOut [ 1 ] ; real_T vj_efOut [ 1 ] ; real_T
vk_efOut [ 1 ] ; real_T vl_efOut [ 1 ] ; real_T vm_efOut [ 1 ] ; real_T
vo_efOut [ 1 ] ; real_T vp_efOut [ 1 ] ; real_T vq_efOut [ 1 ] ; real_T
vr_efOut [ 1 ] ; real_T vs_efOut [ 1 ] ; real_T vt_efOut [ 1 ] ; real_T
vv_efOut [ 1 ] ; real_T vw_efOut [ 1 ] ; real_T vy_efOut [ 1 ] ; real_T
wb_efOut [ 1 ] ; real_T wbb_efOut [ 1 ] ; real_T wd_efOut [ 1 ] ; real_T
we_efOut [ 1 ] ; real_T web_efOut [ 1 ] ; real_T wh_efOut [ 1 ] ; real_T
wi_efOut [ 1 ] ; real_T wj_efOut [ 1 ] ; real_T wk_efOut [ 1 ] ; real_T
wl_efOut [ 1 ] ; real_T wm_efOut [ 1 ] ; real_T wq_efOut [ 1 ] ; real_T
wr_efOut [ 1 ] ; real_T ws_efOut [ 1 ] ; real_T wu_efOut [ 1 ] ; real_T
wv_efOut [ 1 ] ; real_T ww_efOut [ 1 ] ; real_T wx_efOut [ 1 ] ; real_T
wy_efOut [ 1 ] ; real_T x_efOut [ 1 ] ; real_T xab_efOut [ 1 ] ; real_T
xbb_efOut [ 1 ] ; real_T xc_efOut [ 1 ] ; real_T xcb_efOut [ 1 ] ; real_T
xdb_efOut [ 1 ] ; real_T xe_efOut [ 1 ] ; real_T xeb_efOut [ 1 ] ; real_T
xf_efOut [ 1 ] ; real_T xg_efOut [ 1 ] ; real_T xh_efOut [ 1 ] ; real_T
xi_efOut [ 1 ] ; real_T xj_efOut [ 1 ] ; real_T xk_efOut [ 1 ] ; real_T
xl_efOut [ 1 ] ; real_T xm_efOut [ 1 ] ; real_T xn_efOut [ 1 ] ; real_T
xo_efOut [ 1 ] ; real_T xp_efOut [ 1 ] ; real_T xq_efOut [ 1 ] ; real_T
xr_efOut [ 1 ] ; real_T xt_efOut [ 1 ] ; real_T xu_efOut [ 1 ] ; real_T
xv_efOut [ 1 ] ; real_T xx_efOut [ 1 ] ; real_T yab_efOut [ 1 ] ; real_T
ybb_efOut [ 1 ] ; real_T yd_efOut [ 1 ] ; real_T ydb_efOut [ 1 ] ; real_T
yeb_efOut [ 1 ] ; real_T yf_efOut [ 1 ] ; real_T yg_efOut [ 1 ] ; real_T
yi_efOut [ 1 ] ; real_T yj_efOut [ 1 ] ; real_T yl_efOut [ 1 ] ; real_T
ym_efOut [ 1 ] ; real_T yq_efOut [ 1 ] ; real_T ys_efOut [ 1 ] ; real_T
yt_efOut [ 1 ] ; real_T yu_efOut [ 1 ] ; real_T yw_efOut [ 1 ] ; real_T
yy_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co0 ; real_T
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio0 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce15 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato15 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T22 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; real_T
U_idx_0 ; real_T U_idx_1 ; real_T U_idx_10 ; real_T U_idx_11 ; real_T
U_idx_12 ; real_T U_idx_13 ; real_T U_idx_2 ; real_T U_idx_3 ; real_T U_idx_4
; real_T U_idx_5 ; real_T U_idx_6 ; real_T U_idx_7 ; real_T U_idx_8 ; real_T
U_idx_9 ; real_T intrm_sf_mf_1064 ; real_T intrm_sf_mf_11 ; real_T
intrm_sf_mf_1104 ; real_T intrm_sf_mf_1119 ; real_T intrm_sf_mf_1220 ; real_T
intrm_sf_mf_1229 ; real_T intrm_sf_mf_1254 ; real_T intrm_sf_mf_1257 ; real_T
intrm_sf_mf_1267 ; real_T intrm_sf_mf_1295 ; real_T intrm_sf_mf_1296 ; real_T
intrm_sf_mf_1299 ; real_T intrm_sf_mf_1314 ; real_T intrm_sf_mf_1350 ; real_T
intrm_sf_mf_1359 ; real_T intrm_sf_mf_1462 ; real_T intrm_sf_mf_1524 ; real_T
intrm_sf_mf_1569 ; real_T intrm_sf_mf_157 ; real_T intrm_sf_mf_1748 ; real_T
intrm_sf_mf_199 ; real_T intrm_sf_mf_249 ; real_T intrm_sf_mf_261 ; real_T
intrm_sf_mf_352 ; real_T intrm_sf_mf_356 ; real_T intrm_sf_mf_383 ; real_T
intrm_sf_mf_393 ; real_T intrm_sf_mf_454 ; real_T intrm_sf_mf_517 ; real_T
intrm_sf_mf_541 ; real_T intrm_sf_mf_636 ; real_T intrm_sf_mf_661 ; real_T
intrm_sf_mf_821 ; real_T intrm_sf_mf_826 ; real_T intrm_sf_mf_863 ; real_T
intrm_sf_mf_866 ; real_T intrm_sf_mf_867 ; real_T intrm_sf_mf_869 ; real_T
piece199 ; real_T piece20 ; real_T piece237 ; real_T piece313 ; real_T
piece354 ; real_T piece416 ; real_T piece422 ; real_T piece45 ; real_T
piece81 ; real_T t194 ; real_T t213 ; real_T t220 ; real_T t222 ; real_T
t2585_idx_0 ; real_T t2586_idx_0 ; real_T t2587_idx_0 ; real_T t2634 ; real_T
t2638 ; real_T t2646 ; real_T t2656 ; real_T t2671 ; real_T t2680 ; real_T
t2681 ; real_T t2689 ; real_T t2705 ; real_T t2711 ; real_T t2717 ; real_T
t2727 ; real_T t2728 ; real_T t2729 ; real_T t2731 ; real_T t2733 ; real_T
t2735 ; real_T t2736 ; real_T t2737 ; real_T t2738 ; real_T t2739 ; real_T
t2741 ; real_T t2742 ; real_T t2743 ; real_T t2744 ; real_T t2745 ; real_T
t2747 ; real_T t2749 ; real_T t2750 ; real_T t2751 ; real_T t2752 ; real_T
t2753 ; real_T t2755 ; real_T t2756 ; real_T t2757 ; real_T t2758 ; real_T
t2760 ; real_T t2761 ; real_T t2763 ; real_T t2766 ; real_T t2767 ; real_T
t2769 ; real_T t2771 ; real_T t2774 ; real_T t2775 ; real_T t2778 ; real_T
t2779 ; real_T t2781 ; real_T t2782 ; real_T t2783 ; real_T t2784 ; real_T
t2785 ; real_T t2787 ; real_T t2789 ; real_T t2790 ; real_T t2793 ; real_T
t2794 ; real_T t2795 ; real_T t2796 ; real_T t2797 ; real_T t2798 ; real_T
t2799 ; real_T t2800 ; real_T t2801 ; real_T t2802 ; real_T t2803 ; real_T
t2805 ; real_T t2806 ; real_T t2808 ; real_T t2809 ; real_T t2810 ; real_T
t2812 ; real_T t2813 ; real_T t2815 ; real_T t2818 ; real_T t2819 ; real_T
t2820 ; real_T t2821 ; real_T t2823 ; real_T t2828 ; real_T t2830 ; real_T
t2832 ; real_T t2837 ; real_T t2838 ; real_T t2840 ; real_T t2842 ; real_T
t2845 ; real_T t2846 ; real_T t2848 ; real_T t2849 ; real_T t2850 ; real_T
t2851 ; real_T t2852 ; real_T t2857 ; real_T t2860 ; real_T t2862 ; real_T
t2864 ; real_T t2866 ; real_T t2867 ; real_T t2869 ; real_T t2872 ; real_T
t2873 ; real_T t2874 ; real_T t2875 ; real_T t2876 ; real_T t2877 ; real_T
t2879 ; real_T t2880 ; real_T t2881 ; real_T t2883 ; real_T t2884 ; real_T
t2887 ; real_T t2888 ; real_T t2890 ; real_T t2892 ; real_T t2894 ; real_T
t2898 ; real_T t2899 ; real_T t2900 ; real_T t2902 ; real_T t2905 ; real_T
t2906 ; real_T t2907 ; real_T t2909 ; real_T t2911 ; real_T t2913 ; real_T
t2914 ; real_T t2916 ; real_T t2919 ; real_T t2920 ; real_T t2921 ; real_T
t2923 ; real_T t2926 ; real_T t2928 ; real_T t2931 ; real_T t2934 ; real_T
t2937 ; real_T t2938 ; real_T t2940 ; real_T t2943 ; real_T t2944 ; real_T
t2945 ; real_T t2946 ; real_T t2947 ; real_T t2948 ; real_T t2950 ; real_T
t2951 ; real_T t2952 ; real_T t2953 ; real_T t2955 ; real_T t2956 ; real_T
t2960 ; real_T t2961 ; real_T t2962 ; real_T t2963 ; real_T t2966 ; real_T
t2968 ; real_T t2970 ; real_T t2971 ; real_T t2972 ; real_T t2973 ; real_T
t2974 ; real_T t2975 ; real_T t2980 ; real_T t2982 ; real_T t2987 ; real_T
t2989 ; real_T t2994 ; real_T t2995 ; real_T t2996 ; real_T t2997 ; real_T
t2998 ; real_T t2999 ; real_T t3001 ; real_T t3002 ; real_T t3003 ; real_T
t3004 ; real_T t3007 ; real_T t3008 ; real_T t3009 ; real_T t3011 ; real_T
t3012 ; real_T t3013 ; real_T t3021 ; real_T t3022 ; real_T t3025 ; real_T
t3026 ; real_T t3027 ; real_T t3028 ; real_T t3029 ; real_T t3030 ; real_T
t3031 ; real_T t3032 ; real_T t3033 ; real_T t3034 ; real_T t3035 ; real_T
t3036 ; real_T t3040 ; real_T t3041 ; real_T t3042 ; real_T t3043 ; real_T
t3044 ; real_T t3045 ; real_T t3046 ; real_T t3047 ; real_T t3049 ; real_T
t3050 ; real_T t3054 ; real_T t3055 ; real_T t3056 ; real_T t3059 ; real_T
t3060 ; real_T t3062 ; real_T t3064 ; real_T t3066 ; real_T t3067 ; real_T
t3068 ; real_T t3069 ; real_T t3074 ; real_T t3075 ; real_T t3077 ; real_T
t3079 ; real_T t3083 ; real_T t3084 ; real_T t3086 ; real_T t3087 ; real_T
t3088 ; real_T t3090 ; real_T t3091 ; real_T t3093 ; real_T t3095 ; real_T
t3096 ; real_T t3097 ; real_T t3098 ; real_T t3100 ; real_T t3102 ; real_T
t3103 ; real_T t3105 ; real_T t3109 ; real_T t3110 ; real_T t3111 ; real_T
t3112 ; real_T t3114 ; real_T t3118 ; real_T t3119 ; real_T t3120 ; real_T
t3121 ; real_T t3123 ; real_T t3124 ; real_T t3125 ; real_T t3127 ; real_T
t3132 ; real_T t3133 ; real_T t3134 ; real_T t3135 ; real_T t3137 ; real_T
t3139 ; real_T t3140 ; real_T t3145 ; real_T t3149 ; real_T t3152 ; real_T
t3155 ; real_T t3159 ; real_T t3164 ; real_T t3174 ; real_T t3176 ; real_T
t3177 ; real_T t3179 ; real_T t3181 ; real_T t3182 ; real_T t3183 ; real_T
t3184 ; real_T t3185 ; real_T t3186 ; real_T t3188 ; real_T t3189 ; real_T
t3190 ; real_T t3191 ; real_T t3192 ; real_T t3193 ; real_T t3195 ; real_T
t3196 ; real_T t3197 ; real_T t3201 ; real_T t3204 ; real_T t3205 ; real_T
t3206 ; real_T t3210 ; real_T t3211 ; real_T t3212 ; real_T t3217 ; real_T
t3218 ; real_T t3219 ; real_T t3221 ; real_T t3222 ; real_T t3223 ; real_T
t3224 ; real_T t3225 ; real_T t3228 ; real_T t3229 ; real_T t3231 ; real_T
t3232 ; real_T t3233 ; real_T t3240 ; real_T t3242 ; real_T t3245 ; real_T
t3246 ; real_T t3248 ; real_T t3252 ; real_T t3257 ; real_T t3258 ; real_T
t3260 ; real_T t3262 ; real_T t3264 ; real_T t3266 ; real_T t3269 ; real_T
t3270 ; real_T t3272 ; real_T t3278 ; real_T t3279 ; real_T t3280 ; real_T
t3281 ; real_T t3283 ; real_T t3284 ; real_T t3285 ; real_T t3286 ; real_T
t3287 ; real_T t3288 ; real_T t3289 ; real_T t3290 ; real_T t3292 ; real_T
t3293 ; real_T t3294 ; real_T t3295 ; real_T t3296 ; real_T t3297 ; real_T
t3298 ; real_T t3299 ; real_T t3300 ; real_T t3302 ; real_T t3303 ; real_T
t3304 ; real_T t3305 ; real_T t3307 ; real_T t3308 ; real_T t3311 ; real_T
t3312 ; real_T t3314 ; real_T t3316 ; real_T t3317 ; real_T t3319 ; real_T
t3320 ; real_T t3322 ; real_T t3328 ; real_T t3333 ; real_T t3335 ; real_T
t3336 ; real_T t3337 ; real_T t3338 ; real_T t3339 ; real_T t3340 ; real_T
t3342 ; real_T t3343 ; real_T t3344 ; real_T t3345 ; real_T t3346 ; real_T
t3347 ; real_T t3348 ; real_T t3350 ; real_T t3354 ; real_T t3355 ; real_T
t3359 ; real_T t3360 ; real_T t3361 ; real_T t3362 ; real_T t3364 ; real_T
t3365 ; real_T t3367 ; real_T t3369 ; real_T t3370 ; real_T t3371 ; real_T
t3372 ; real_T t3374 ; real_T t3381 ; real_T t3382 ; real_T t3386 ; real_T
t3391 ; real_T t3392 ; real_T t3393 ; real_T t3394 ; real_T t3395 ; real_T
t3396 ; real_T t3397 ; real_T t3399 ; real_T t3400 ; real_T t3401 ; real_T
t3403 ; real_T t3405 ; real_T t3406 ; real_T t3407 ; real_T t3408 ; real_T
t3411 ; real_T t3412 ; real_T t3414 ; real_T t3416 ; real_T t3417 ; real_T
t3418 ; real_T t3427 ; real_T t3429 ; real_T t3432 ; real_T t3438 ; real_T
t3439 ; real_T t3440 ; real_T t3441 ; real_T t3453 ; real_T t3454 ; real_T
t3455 ; real_T t3459 ; real_T t3461 ; real_T t3462 ; real_T t3463 ; real_T
t3464 ; real_T t3466 ; real_T t3467 ; real_T t3468 ; real_T t3473 ; real_T
t3475 ; real_T t3476 ; real_T t3478 ; real_T t3482 ; real_T t3483 ; real_T
t3488 ; real_T t3489 ; real_T t3490 ; real_T t3492 ; real_T t3493 ; real_T
t3494 ; real_T t3495 ; real_T t3496 ; real_T t3498 ; real_T t3499 ; real_T
t3500 ; real_T t3501 ; real_T t3502 ; real_T t3506 ; real_T t3507 ; real_T
t3508 ; real_T t3509 ; real_T t3510 ; real_T t3511 ; real_T t3512 ; real_T
t3513 ; real_T t3514 ; real_T t3516 ; real_T t3517 ; real_T t3518 ; real_T
t3519 ; real_T t3520 ; real_T t3521 ; real_T t3522 ; real_T t3523 ; real_T
t3525 ; real_T t3526 ; real_T t3528 ; real_T t3529 ; real_T t3530 ; real_T
t3531 ; real_T t3532 ; real_T t3533 ; real_T t3534 ; real_T t3535 ; real_T
t3536 ; real_T t3538 ; real_T t3539 ; real_T t3543 ; real_T t3544 ; real_T
t3545 ; real_T t3546 ; real_T t3548 ; real_T t3549 ; real_T t3551 ; real_T
t3552 ; real_T t3553 ; real_T t3554 ; real_T t3555 ; real_T t3556 ; real_T
t3557 ; real_T t3558 ; real_T t3563 ; real_T t3564 ; real_T t3565 ; real_T
t3568 ; real_T t3570 ; real_T t3572 ; real_T t3573 ; real_T t3575 ; real_T
t3576 ; real_T t3577 ; real_T t3578 ; real_T t3579 ; real_T t3582 ; real_T
t3583 ; real_T t3584 ; real_T t3585 ; real_T t3587 ; real_T t3590 ; real_T
t3596 ; real_T t3598 ; real_T t3599 ; real_T t3600 ; real_T t3601 ; real_T
t3603 ; real_T t3606 ; real_T t3608 ; real_T t3609 ; real_T t3610 ; real_T
t3611 ; real_T t3612 ; real_T t3613 ; real_T t3616 ; real_T t3617 ; real_T
t3618 ; real_T t3620 ; real_T t3621 ; real_T t3623 ; real_T t3626 ; real_T
t3627 ; real_T t3631 ; real_T t3633 ; real_T t3708 ; real_T t3718 ; real_T
t3721 ; real_T t3734 ; real_T t3738 ; real_T t3740 ; real_T t3742 ; real_T
t3745 ; real_T t3754 ; real_T t3819 ; real_T t3848 ; real_T t3851 ; real_T
t3856 ; real_T t3861 ; real_T t4165 ; real_T t4221 ; real_T t4237 ; real_T
t4240 ; real_T t4247 ; real_T t4251 ; real_T t4284 ; real_T t4289 ; real_T
t4298 ; real_T t4303 ; real_T t4332 ; real_T t4363 ; real_T t4367 ; real_T
t4394 ; real_T t4396 ; real_T t4405 ; real_T t4426 ; real_T t4440 ; real_T
t4447 ; real_T t4451 ; real_T t4473 ; real_T t4487 ; real_T t4494 ; real_T
t4498 ; real_T t4503 ; real_T t4510 ; real_T t4517 ; real_T t4534 ; real_T
t4548 ; real_T t4576 ; real_T t4581 ; real_T t4626 ; real_T t4628 ; real_T
t4641 ; real_T t4658 ; real_T t4677 ; real_T t4703 ; real_T t4716 ; real_T
t4726 ; real_T t4729 ; real_T t4747 ; real_T t4766 ; real_T t4767 ; real_T
t4768 ; real_T t4785 ; real_T t4803 ; real_T t4812 ; real_T t4813 ; real_T
t4815 ; real_T t4821 ; real_T t4823 ; real_T t4834 ; real_T t4891 ; real_T
t4901 ; real_T t5007 ; real_T t5250 ; real_T t5267 ; real_T t5294 ; real_T
t5690 ; real_T t5708 ; real_T zc_int113 ; real_T zc_int132 ; real_T zc_int147
; real_T zc_int181 ; real_T zc_int182 ; real_T zc_int186 ; real_T zc_int192 ;
real_T zc_int209 ; real_T zc_int220 ; real_T zc_int305 ; real_T zc_int307 ;
real_T zc_int324 ; real_T zc_int339 ; real_T zc_int348 ; real_T zc_int349 ;
real_T zc_int350 ; real_T zc_int352 ; real_T zc_int357 ; real_T zc_int36 ;
real_T zc_int363 ; real_T zc_int365 ; real_T zc_int366 ; real_T zc_int368 ;
real_T zc_int50 ; real_T zc_int52 ; real_T zc_int6 ; real_T zc_int81 ; real_T
zc_int84 ; size_t t1006 [ 1 ] ; size_t t1009 [ 1 ] ; size_t t1647 [ 1 ] ;
size_t t1921 [ 1 ] ; size_t t1924 [ 1 ] ; size_t t224 [ 1 ] ; size_t t225 [ 1
] ; size_t t227 [ 1 ] ; size_t t2571 [ 1 ] ; size_t t2572 [ 1 ] ; size_t
t2618 ; size_t t2619 ; size_t t2620 ; int32_T M [ 361 ] ; int32_T b ; for ( b
= 0 ; b < 361 ; b ++ ) { M [ b ] = t5710 -> mM . mX [ b ] ; } U_idx_0 = t5710
-> mU . mX [ 0 ] ; U_idx_1 = t5710 -> mU . mX [ 1 ] ; U_idx_2 = t5710 -> mU .
mX [ 2 ] ; U_idx_3 = t5710 -> mU . mX [ 3 ] ; U_idx_4 = t5710 -> mU . mX [ 4
] ; U_idx_5 = t5710 -> mU . mX [ 5 ] ; U_idx_6 = t5710 -> mU . mX [ 6 ] ;
U_idx_7 = t5710 -> mU . mX [ 7 ] ; U_idx_8 = t5710 -> mU . mX [ 8 ] ; U_idx_9
= t5710 -> mU . mX [ 9 ] ; U_idx_10 = t5710 -> mU . mX [ 10 ] ; U_idx_11 =
t5710 -> mU . mX [ 11 ] ; U_idx_12 = t5710 -> mU . mX [ 12 ] ; U_idx_13 =
t5710 -> mU . mX [ 13 ] ; for ( b = 0 ; b < 582 ; b ++ ) { X [ b ] = t5710 ->
mX . mX [ b ] ; } out = t5711 -> mF ; nonscalar1 [ 0 ] = 19080.0 ; nonscalar1
[ 1 ] = 19080.0 ; nonscalar1 [ 2 ] = 19080.0 ; nonscalar1 [ 3 ] = 19080.0 ;
nonscalar1 [ 4 ] = 19080.0 ; nonscalar1 [ 5 ] = 19080.0 ; nonscalar1 [ 6 ] =
19080.0 ; nonscalar58 [ 0 ] = 0.0 ; nonscalar58 [ 1 ] = 0.2 ; nonscalar58 [ 2
] = 0.4 ; nonscalar58 [ 3 ] = 0.6 ; nonscalar58 [ 4 ] = 0.8 ; nonscalar58 [ 5
] = 1.0 ; nonscalar59 [ 0 ] = 243.1 ; nonscalar59 [ 1 ] = 253.1 ; nonscalar59
[ 2 ] = 263.1 ; nonscalar59 [ 3 ] = 273.1 ; nonscalar59 [ 4 ] = 283.1 ;
nonscalar59 [ 5 ] = 298.1 ; nonscalar59 [ 6 ] = 313.1 ; nonscalar63 [ 0 ] =
1.0 ; nonscalar63 [ 1 ] = 1.25 ; nonscalar63 [ 2 ] = 1.5 ; nonscalar63 [ 3 ]
= 1.75 ; nonscalar63 [ 4 ] = 2.0 ; nonscalar64 [ 0 ] = 0.0 ; nonscalar64 [ 1
] = 188.49555921538757 ; nonscalar64 [ 2 ] = 376.99111843077515 ; t5294 = - X
[ 79ULL ] - U_idx_1 ; t5690 = ( ( ( real_T ) ( t5294 >= 0.0 ) * t5294 *
1000.0 + ( real_T ) ( t5294 < 0.0 ) * X [ 81ULL ] ) - 0.9 ) /
0.099999999999999978 ; if ( ( real_T ) ( t5294 >= 0.0 ) * t5294 * 1000.0 + (
real_T ) ( t5294 < 0.0 ) * X [ 81ULL ] <= 0.9 ) { t5690 = 0.0 ; } else {
t5690 = ( real_T ) ( t5294 >= 0.0 ) * t5294 * 1000.0 + ( real_T ) ( t5294 <
0.0 ) * X [ 81ULL ] >= 1.0 ? 1.0 : t5690 * t5690 * 3.0 - t5690 * t5690 *
t5690 * 2.0 ; } t5007 = pmf_sqrt ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12
) ; t1941 [ 0ULL ] = X [ 97ULL ] ; t224 [ 0 ] = 20ULL ; t225 [ 0 ] = 1ULL ;
tlu2_linear_linear_prelookup ( & efOut . mField0 [ 0ULL ] , & efOut . mField1
[ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField2 , & t1941 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t190 =
efOut ; t226 [ 0ULL ] = X [ 93ULL ] ; t227 [ 0 ] = 19ULL ;
tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t226 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t182 = b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut [ 0ULL ] , & t190 .
mField0 [ 0ULL ] , & t190 . mField2 [ 0ULL ] , & t182 . mField0 [ 0ULL ] , &
t182 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2583 [ 0 ] = c_efOut [
0 ] ; t5267 = t2583 [ 0ULL ] ; t5250 = U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 :
t5007 ) * X [ 93ULL ] / ( t5267 == 0.0 ? 1.0E-16 : t5267 ) ; t2727 = ( 1.0 -
U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) ) / 2.0 ; t2728 = ( U_idx_2 / (
t5007 == 0.0 ? 1.0E-16 : t5007 ) + 1.0 ) / 2.0 ; t2583 [ 0ULL ] = X [ 92ULL ]
; tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2583 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t188 = d_efOut ; tlu2_2d_linear_linear_value ( & e_efOut [ 0ULL ] , & t188 .
mField0 [ 0ULL ] , & t188 . mField2 [ 0ULL ] , & t182 . mField0 [ 0ULL ] , &
t182 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2049 [ 0 ] = e_efOut [
0 ] ; t2729 = t2049 [ 0ULL ] ; t2049 [ 0ULL ] = X [ 99ULL ] ;
tlu2_linear_linear_prelookup ( & f_efOut . mField0 [ 0ULL ] , & f_efOut .
mField1 [ 0ULL ] , & f_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t180 = f_efOut ; t2049 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup
( & g_efOut . mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t179 = g_efOut ;
tlu2_2d_linear_linear_value ( & h_efOut [ 0ULL ] , & t180 . mField0 [ 0ULL ]
, & t180 . mField2 [ 0ULL ] , & t179 . mField0 [ 0ULL ] , & t179 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = h_efOut [ 0 ] ; t4891 =
t2585_idx_0 ; t4901 = - U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [
95ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2731 = ( 1.0 - -
U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) ) / 2.0 ; t2733 = ( - U_idx_2 /
( t5007 == 0.0 ? 1.0E-16 : t5007 ) + 1.0 ) / 2.0 ; t2049 [ 0ULL ] = X [ 94ULL
] ; tlu2_linear_linear_prelookup ( & i_efOut . mField0 [ 0ULL ] , & i_efOut .
mField1 [ 0ULL ] , & i_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t166 = i_efOut ; tlu2_2d_linear_linear_value ( & j_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t179 . mField0 [ 0ULL ] , &
t179 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = j_efOut [
0 ] ; t2735 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 97ULL ] ;
tlu2_linear_nearest_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t153 = k_efOut ; t2049 [ 0ULL ] = X [ 93ULL ] ; tlu2_linear_nearest_prelookup
( & l_efOut . mField0 [ 0ULL ] , & l_efOut . mField1 [ 0ULL ] , & l_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = l_efOut ;
tlu2_2d_linear_nearest_value ( & m_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = m_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 = t2585_idx_0
; t2049 [ 0ULL ] = X [ 99ULL ] ; tlu2_linear_nearest_prelookup ( & n_efOut .
mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224
[ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = n_efOut ; t2049 [ 0ULL ] = X [ 95ULL ]
; tlu2_linear_nearest_prelookup ( & o_efOut . mField0 [ 0ULL ] , & o_efOut .
mField1 [ 0ULL ] , & o_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t170 = o_efOut ; tlu2_2d_linear_nearest_value ( & p_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t170 . mField0 [ 0ULL ] , &
t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = p_efOut [
0 ] ; Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 = (
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 + t2585_idx_0
) / 2.0 ; t5267 = ( t5267 + t4891 ) / 2.0 ; t4891 =
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 *
1697.0562748477141 / 0.7 ;
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 = pmf_sqrt (
X [ 100ULL ] * X [ 100ULL ] + t4891 * t4891 ) ; t2049 [ 0ULL ] = X [ 106ULL ]
; tlu2_linear_linear_prelookup ( & q_efOut . mField0 [ 0ULL ] , & q_efOut .
mField1 [ 0ULL ] , & q_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t163 = q_efOut ; t2049 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_linear_prelookup
( & r_efOut . mField0 [ 0ULL ] , & r_efOut . mField1 [ 0ULL ] , & r_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t159 = r_efOut ;
tlu2_2d_linear_linear_value ( & s_efOut [ 0ULL ] , & t163 . mField0 [ 0ULL ]
, & t163 . mField2 [ 0ULL ] , & t159 . mField0 [ 0ULL ] , & t159 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = s_efOut [ 0 ] ; t4891 =
t2585_idx_0 ; Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co0
= U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [ 102ULL ] / ( t2585_idx_0
== 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] = X [ 101ULL ] ;
tlu2_linear_linear_prelookup ( & t_efOut . mField0 [ 0ULL ] , & t_efOut .
mField1 [ 0ULL ] , & t_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t187 = t_efOut ; tlu2_2d_linear_linear_value ( & u_efOut [ 0ULL ] , & t187 .
mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , & t159 . mField0 [ 0ULL ] , &
t159 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = u_efOut [
0 ] ; t2736 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 108ULL ] ;
tlu2_linear_linear_prelookup ( & v_efOut . mField0 [ 0ULL ] , & v_efOut .
mField1 [ 0ULL ] , & v_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t158 = v_efOut ; t2049 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup
( & w_efOut . mField0 [ 0ULL ] , & w_efOut . mField1 [ 0ULL ] , & w_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t156 = w_efOut ;
tlu2_2d_linear_linear_value ( & x_efOut [ 0ULL ] , & t158 . mField0 [ 0ULL ]
, & t158 . mField2 [ 0ULL ] , & t156 . mField0 [ 0ULL ] , & t156 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = x_efOut [ 0 ] ; t2737 =
t2585_idx_0 ; t2738 = - U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [
104ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] =
X [ 103ULL ] ; tlu2_linear_linear_prelookup ( & y_efOut . mField0 [ 0ULL ] ,
& y_efOut . mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t166 = y_efOut ; tlu2_2d_linear_linear_value ( &
ab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t156 . mField0 [ 0ULL ] , & t156 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = ab_efOut [ 0 ] ; t2739 = t2585_idx_0 ; t2049 [ 0ULL ] = X [
106ULL ] ; tlu2_linear_nearest_prelookup ( & bb_efOut . mField0 [ 0ULL ] , &
bb_efOut . mField1 [ 0ULL ] , & bb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t153 = bb_efOut ; t2049 [ 0ULL ] = X [ 102ULL ] ;
tlu2_linear_nearest_prelookup ( & cb_efOut . mField0 [ 0ULL ] , & cb_efOut .
mField1 [ 0ULL ] , & cb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t166 = cb_efOut ; tlu2_2d_linear_nearest_value ( & db_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] ,
& t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = db_efOut
[ 0 ] ; t2741 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 108ULL ] ;
tlu2_linear_nearest_prelookup ( & eb_efOut . mField0 [ 0ULL ] , & eb_efOut .
mField1 [ 0ULL ] , & eb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t166 = eb_efOut ; t2049 [ 0ULL ] = X [ 104ULL ] ;
tlu2_linear_nearest_prelookup ( & fb_efOut . mField0 [ 0ULL ] , & fb_efOut .
mField1 [ 0ULL ] , & fb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t170 = fb_efOut ; tlu2_2d_linear_nearest_value ( & gb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t170 . mField0 [ 0ULL ] ,
& t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gb_efOut
[ 0 ] ; t2741 = ( t2741 + t2585_idx_0 ) / 2.0 ; t4891 = ( t4891 + t2737 ) /
2.0 ; t2737 = t2741 * 1697.0562748477141 / 0.7 ; t2741 = pmf_sqrt ( X [
109ULL ] * X [ 109ULL ] + t2737 * t2737 ) ; t2049 [ 0ULL ] = X [ 115ULL ] ;
tlu2_linear_linear_prelookup ( & hb_efOut . mField0 [ 0ULL ] , & hb_efOut .
mField1 [ 0ULL ] , & hb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t148 = hb_efOut ; t2049 [ 0ULL ] = X [ 111ULL ] ;
tlu2_linear_linear_prelookup ( & ib_efOut . mField0 [ 0ULL ] , & ib_efOut .
mField1 [ 0ULL ] , & ib_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t146 = ib_efOut ; tlu2_2d_linear_linear_value ( & jb_efOut [ 0ULL ] , & t148
. mField0 [ 0ULL ] , & t148 . mField2 [ 0ULL ] , & t146 . mField0 [ 0ULL ] ,
& t146 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = jb_efOut
[ 0 ] ; t2737 = t2585_idx_0 ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio0 = U_idx_2 / (
t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [ 111ULL ] / ( t2585_idx_0 == 0.0 ?
1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_linear_prelookup ( & kb_efOut . mField0 [ 0ULL ] , & kb_efOut .
mField1 [ 0ULL ] , & kb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t170 = kb_efOut ; tlu2_2d_linear_linear_value ( & lb_efOut [ 0ULL ] , & t170
. mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , & t146 . mField0 [ 0ULL ] ,
& t146 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = lb_efOut
[ 0 ] ; t2742 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 117ULL ] ;
tlu2_linear_linear_prelookup ( & mb_efOut . mField0 [ 0ULL ] , & mb_efOut .
mField1 [ 0ULL ] , & mb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t139 = mb_efOut ; t2049 [ 0ULL ] = X [ 113ULL ] ;
tlu2_linear_linear_prelookup ( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut .
mField1 [ 0ULL ] , & nb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t137 = nb_efOut ; tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t139
. mField0 [ 0ULL ] , & t139 . mField2 [ 0ULL ] , & t137 . mField0 [ 0ULL ] ,
& t137 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ob_efOut
[ 0 ] ; t2743 = t2585_idx_0 ; t2744 = - U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 :
t5007 ) * X [ 113ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ;
t2049 [ 0ULL ] = X [ 112ULL ] ; tlu2_linear_linear_prelookup ( & pb_efOut .
mField0 [ 0ULL ] , & pb_efOut . mField1 [ 0ULL ] , & pb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , &
t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = pb_efOut ;
tlu2_2d_linear_linear_value ( & qb_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , & t137 . mField0 [ 0ULL ] , & t137 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = qb_efOut [ 0 ] ; t2745 =
t2585_idx_0 ; t2049 [ 0ULL ] = X [ 115ULL ] ; tlu2_linear_nearest_prelookup (
& rb_efOut . mField0 [ 0ULL ] , & rb_efOut . mField1 [ 0ULL ] , & rb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [
0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t153 = rb_efOut ; t2049 [ 0ULL
] = X [ 111ULL ] ; tlu2_linear_nearest_prelookup ( & sb_efOut . mField0 [
0ULL ] , & sb_efOut . mField1 [ 0ULL ] , & sb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t166 = sb_efOut ; tlu2_2d_linear_nearest_value ( &
tb_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField5 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = tb_efOut [ 0 ] ; t2747 = t2585_idx_0 ; t2049 [ 0ULL ] = X [
117ULL ] ; tlu2_linear_nearest_prelookup ( & ub_efOut . mField0 [ 0ULL ] , &
ub_efOut . mField1 [ 0ULL ] , & ub_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t187 = ub_efOut ; t2049 [ 0ULL ] = X [ 113ULL ] ;
tlu2_linear_nearest_prelookup ( & vb_efOut . mField0 [ 0ULL ] , & vb_efOut .
mField1 [ 0ULL ] , & vb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t170 = vb_efOut ; tlu2_2d_linear_nearest_value ( & wb_efOut [ 0ULL ] , & t187
. mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , & t170 . mField0 [ 0ULL ] ,
& t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = wb_efOut
[ 0 ] ; t2747 = ( t2747 + t2585_idx_0 ) / 2.0 ; t2737 = ( t2737 + t2743 ) /
2.0 ; t2743 = t2747 * 1697.0562748477141 / 0.7 ; t2747 = pmf_sqrt ( X [
118ULL ] * X [ 118ULL ] + t2743 * t2743 ) ; t2743 = ( U_idx_2 - ( - U_idx_2 )
) / 2.0 ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg = t2743
>= 0.0 ? X [ 112ULL ] : X [ 119ULL ] ; t2049 [ 0ULL ] = ( X [ 6ULL ] +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) / 2.0 ;
tlu2_linear_linear_prelookup ( & xb_efOut . mField0 [ 0ULL ] , & xb_efOut .
mField1 [ 0ULL ] , & xb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t153 = xb_efOut ; t2049 [ 0ULL ] = ( X [ 113ULL ] + X [ 120ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & yb_efOut . mField0 [ 0ULL ] , & yb_efOut .
mField1 [ 0ULL ] , & yb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t178 = yb_efOut ; tlu2_2d_linear_linear_value ( & ac_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] ,
& t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ac_efOut
[ 0 ] ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 =
t2585_idx_0 ; tlu2_2d_linear_linear_value ( & bc_efOut [ 0ULL ] , & t153 .
mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , &
t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = bc_efOut
[ 0 ] ; Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU = ( t2743 >= 0.0
? t2743 : - t2743 ) * 0.01 ; t2755 = t2585_idx_0 * 7.8539816339744827E-5 ;
t2749 = Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU / ( t2755 == 0.0
? 1.0E-16 : t2755 ) ; t2751 = t2749 >= 2000.0 ? t2749 : 1.0 ; t2756 =
pmf_log10 ( 6.9 / ( t2751 == 0.0 ? 1.0E-16 : t2751 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t2751 == 0.0 ? 1.0E-16 : t2751 ) +
0.00017169489553429715 ) * 3.24 ; t2751 = 1.0 / ( t2756 == 0.0 ? 1.0E-16 :
t2756 ) ; t2758 = ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t2751 / 8.0 ) * 12.7 + 1.0 ; t2750
= ( ( t2749 > 1000.0 ? t2749 : 1000.0 ) - 1000.0 ) * ( t2751 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 / ( t2758 ==
0.0 ? 1.0E-16 : t2758 ) ; t2751 = ( t2749 - 2000.0 ) / 2000.0 ; t2752 = t2751
* t2751 * 3.0 - t2751 * t2751 * t2751 * 2.0 ; if ( t2749 <= 2000.0 ) { t2751
= 3.66 ; } else if ( t2749 >= 4000.0 ) { t2751 = t2750 ; } else { t2751 = (
1.0 - t2752 ) * 3.66 + t2750 * t2752 ; } t2751 = ( U_idx_0 -
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * ( 1.0 - pmf_exp
( - ( t2751 * 0.031415926535897927 / ( t2749 + 1.0 == 0.0 ? 1.0E-16 : t2749 +
1.0 ) / 7.8539816339744827E-5 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 == 0.0 ?
1.0E-16 : Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 ) )
) ) ; tlu2_2d_linear_linear_value ( & cc_efOut [ 0ULL ] , & t153 . mField0 [
0ULL ] , & t153 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , & t178 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t224 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = cc_efOut [ 0 ] ;
t2749 = t2749 * 7.8539816339744827E-5 / 0.01 *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * t2751 *
t2585_idx_0 ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg =
pmf_sqrt ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) ; t2049 [ 0ULL ] = X
[ 123ULL ] ; tlu2_linear_linear_prelookup ( & dc_efOut . mField0 [ 0ULL ] , &
dc_efOut . mField1 [ 0ULL ] , & dc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t125 = dc_efOut ; tlu2_2d_linear_linear_value ( &
ec_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , &
t137 . mField0 [ 0ULL ] , & t137 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = ec_efOut [ 0 ] ; t2750 = U_idx_2 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [ 113ULL ] /
( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 = ( 1.0 -
U_idx_2 / ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0
? 1.0E-16 : Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) ) /
2.0 ; t2751 = ( U_idx_2 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) + 1.0 ) / 2.0 ;
t2049 [ 0ULL ] = X [ 125ULL ] ; tlu2_linear_linear_prelookup ( & fc_efOut .
mField0 [ 0ULL ] , & fc_efOut . mField1 [ 0ULL ] , & fc_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , &
t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t154 = fc_efOut ; t2049 [ 0ULL ] = X [
120ULL ] ; tlu2_linear_linear_prelookup ( & gc_efOut . mField0 [ 0ULL ] , &
gc_efOut . mField1 [ 0ULL ] , & gc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t142 = gc_efOut ; tlu2_2d_linear_linear_value ( &
hc_efOut [ 0ULL ] , & t154 . mField0 [ 0ULL ] , & t154 . mField2 [ 0ULL ] , &
t142 . mField0 [ 0ULL ] , & t142 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = hc_efOut [ 0 ] ; t2753 = - U_idx_2 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [ 120ULL ] /
( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2752 = ( 1.0 - - U_idx_2 /
( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) ) / 2.0 ; t2755
= ( - U_idx_2 / ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg
== 0.0 ? 1.0E-16 : Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg
) + 1.0 ) / 2.0 ; t2049 [ 0ULL ] = X [ 119ULL ] ;
tlu2_linear_linear_prelookup ( & ic_efOut . mField0 [ 0ULL ] , & ic_efOut .
mField1 [ 0ULL ] , & ic_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t187 = ic_efOut ; tlu2_2d_linear_linear_value ( & jc_efOut [ 0ULL ] , & t187
. mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , & t142 . mField0 [ 0ULL ] ,
& t142 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = jc_efOut
[ 0 ] ; t2756 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 6ULL ] ;
tlu2_linear_linear_prelookup ( & kc_efOut . mField0 [ 0ULL ] , & kc_efOut .
mField1 [ 0ULL ] , & kc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t99 = kc_efOut ; tlu2_2d_linear_linear_value ( & lc_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , &
t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = lc_efOut
[ 0 ] ; t2757 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( & mc_efOut [ 0ULL
] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , & t178 . mField0 [
0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField8 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0
= mc_efOut [ 0 ] ; t2758 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( &
nc_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField7 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = nc_efOut [ 0 ] ; intrm_sf_mf_261 = t2585_idx_0 ;
tlu2_2d_linear_linear_value ( & oc_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , & t178 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = oc_efOut [ 0 ] ; t2760 =
t2585_idx_0 ; t2761 = t2743 >= 0.0 ? X [ 94ULL ] : X [ 101ULL ] ; t2049 [
0ULL ] = ( X [ 9ULL ] + t2761 ) / 2.0 ; tlu2_linear_linear_prelookup ( &
pc_efOut . mField0 [ 0ULL ] , & pc_efOut . mField1 [ 0ULL ] , & pc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [
0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = pc_efOut ; t2049 [ 0ULL
] = ( X [ 95ULL ] + X [ 102ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( &
qc_efOut . mField0 [ 0ULL ] , & qc_efOut . mField1 [ 0ULL ] , & qc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t2049 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t153 = qc_efOut ;
tlu2_2d_linear_linear_value ( & rc_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = rc_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 = t2585_idx_0
; tlu2_2d_linear_linear_value ( & sc_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = sc_efOut [ 0 ] ; t4834 =
t2585_idx_0 * 7.8539816339744827E-5 ; t2763 =
Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU / ( t4834 == 0.0 ?
1.0E-16 : t4834 ) ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = t2763 >= 2000.0
? t2763 : 1.0 ; t2778 = pmf_log10 ( 6.9 / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T ) +
0.00017169489553429715 ) * 3.24 ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = 1.0 / ( t2778
== 0.0 ? 1.0E-16 : t2778 ) ; U_idx_1 = ( pmf_pow (
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T / 8.0 ) * 12.7 +
1.0 ; Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU = ( ( t2763 >
1000.0 ? t2763 : 1000.0 ) - 1000.0 ) * (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T / 8.0 ) *
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 / ( U_idx_1
== 0.0 ? 1.0E-16 : U_idx_1 ) ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = ( t2763 -
2000.0 ) / 2000.0 ; t2766 =
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T *
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T * 3.0 -
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T *
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T *
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T * 2.0 ; if (
t2763 <= 2000.0 ) {
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = 3.66 ; } else
if ( t2763 >= 4000.0 ) {
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T =
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU ; } else {
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = ( 1.0 - t2766 )
* 3.66 + Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU * t2766 ; }
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = ( X [ 10ULL ] -
t2761 ) * ( 1.0 - pmf_exp ( - (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T *
0.031415926535897927 / ( t2763 + 1.0 == 0.0 ? 1.0E-16 : t2763 + 1.0 ) /
7.8539816339744827E-5 / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 == 0.0 ?
1.0E-16 : Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 ) )
) ) ; tlu2_2d_linear_linear_value ( & tc_efOut [ 0ULL ] , & t166 . mField0 [
0ULL ] , & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t224 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = tc_efOut [ 0 ] ;
t2763 = t2763 * 7.8539816339744827E-5 / 0.01 *
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 *
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T * t2585_idx_0 ;
t2049 [ 0ULL ] = X [ 128ULL ] ; tlu2_linear_linear_prelookup ( & uc_efOut .
mField0 [ 0ULL ] , & uc_efOut . mField1 [ 0ULL ] , & uc_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , &
t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t116 = uc_efOut ;
tlu2_2d_linear_linear_value ( & vc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t179 . mField0 [ 0ULL ] , & t179 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = vc_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0 = U_idx_2 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [ 95ULL ] / (
t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] = X [ 130ULL ]
; tlu2_linear_linear_prelookup ( & wc_efOut . mField0 [ 0ULL ] , & wc_efOut .
mField1 [ 0ULL ] , & wc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t136 = wc_efOut ; tlu2_2d_linear_linear_value ( & xc_efOut [ 0ULL ] , & t136
. mField0 [ 0ULL ] , & t136 . mField2 [ 0ULL ] , & t159 . mField0 [ 0ULL ] ,
& t159 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xc_efOut
[ 0 ] ; Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU = - U_idx_2 /
( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [ 102ULL ]
/ ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] = X [ 9ULL
] ; tlu2_linear_linear_prelookup ( & yc_efOut . mField0 [ 0ULL ] , & yc_efOut
. mField1 [ 0ULL ] , & yc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = yc_efOut ; tlu2_2d_linear_linear_value ( & ad_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1
, & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ad_efOut [ 0 ] ; t2761 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( &
bd_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField8 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = bd_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T = t2585_idx_0 ;
tlu2_2d_linear_linear_value ( & cd_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = cd_efOut [ 0 ] ; t2766 =
t2585_idx_0 ; tlu2_2d_linear_linear_value ( & dd_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t153 . mField0 [ 0ULL ] , &
t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = dd_efOut
[ 0 ] ; t2767 = t2585_idx_0 ; t2769 = t2743 >= 0.0 ? X [ 103ULL ] : X [
110ULL ] ; t2049 [ 0ULL ] = ( X [ 11ULL ] + t2769 ) / 2.0 ;
tlu2_linear_linear_prelookup ( & ed_efOut . mField0 [ 0ULL ] , & ed_efOut .
mField1 [ 0ULL ] , & ed_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t153 = ed_efOut ; t2049 [ 0ULL ] = ( X [ 104ULL ] + X [ 111ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & fd_efOut . mField0 [ 0ULL ] , & fd_efOut .
mField1 [ 0ULL ] , & fd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t166 = fd_efOut ; tlu2_2d_linear_linear_value ( & gd_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] ,
& t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gd_efOut
[ 0 ] ; t2743 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( & hd_efOut [ 0ULL
] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t166 . mField0
[ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField7 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0
= hd_efOut [ 0 ] ; t2793 = t2585_idx_0 * 7.8539816339744827E-5 ; t2771 =
Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU / ( t2793 == 0.0 ?
1.0E-16 : t2793 ) ; Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I =
t2771 >= 2000.0 ? t2771 : 1.0 ; t2794 = pmf_log10 ( 6.9 / (
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I ) +
0.00017169489553429715 ) * 3.24 ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = 1.0 / ( t2794 == 0.0 ?
1.0E-16 : t2794 ) ; t2796 = ( pmf_pow ( t2743 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I / 8.0 ) *
12.7 + 1.0 ; Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU = ( ( t2771
> 1000.0 ? t2771 : 1000.0 ) - 1000.0 ) * (
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I / 8.0 ) * t2743 / ( t2796
== 0.0 ? 1.0E-16 : t2796 ) ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = ( t2771 - 2000.0 ) /
2000.0 ; t2774 = Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I *
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I * 3.0 -
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I *
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I *
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I * 2.0 ; if ( t2771 <=
2000.0 ) { Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = 3.66 ; }
else if ( t2771 >= 4000.0 ) {
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I =
Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU ; } else {
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = ( 1.0 - t2774 ) * 3.66
+ Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU * t2774 ; }
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = ( X [ 12ULL ] - t2769 )
* ( 1.0 - pmf_exp ( - ( Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I *
0.031415926535897927 / ( t2771 + 1.0 == 0.0 ? 1.0E-16 : t2771 + 1.0 ) /
7.8539816339744827E-5 / ( t2743 == 0.0 ? 1.0E-16 : t2743 ) ) ) ) ;
tlu2_2d_linear_linear_value ( & id_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = id_efOut [ 0 ] ; t2771 =
t2771 * 7.8539816339744827E-5 / 0.01 * t2743 *
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I * t2585_idx_0 ; t2049 [
0ULL ] = X [ 133ULL ] ; tlu2_linear_linear_prelookup ( & jd_efOut . mField0 [
0ULL ] , & jd_efOut . mField1 [ 0ULL ] , & jd_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t123 = jd_efOut ; tlu2_2d_linear_linear_value ( &
kd_efOut [ 0ULL ] , & t123 . mField0 [ 0ULL ] , & t123 . mField2 [ 0ULL ] , &
t156 . mField0 [ 0ULL ] , & t156 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = kd_efOut [ 0 ] ; t2769 = U_idx_2 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [ 104ULL ] /
( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] = X [ 135ULL
] ; tlu2_linear_linear_prelookup ( & ld_efOut . mField0 [ 0ULL ] , & ld_efOut
. mField1 [ 0ULL ] , & ld_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] )
; t109 = ld_efOut ; tlu2_2d_linear_linear_value ( & md_efOut [ 0ULL ] , &
t109 . mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , & t146 . mField0 [ 0ULL
] , & t146 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1
, & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
md_efOut [ 0 ] ; Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU = -
U_idx_2 / ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0
? 1.0E-16 : Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) * X [
111ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t2049 [ 0ULL ] =
X [ 11ULL ] ; tlu2_linear_linear_prelookup ( & nd_efOut . mField0 [ 0ULL ] ,
& nd_efOut . mField1 [ 0ULL ] , & nd_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t170 = nd_efOut ; tlu2_2d_linear_linear_value ( &
od_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t2585_idx_0 = od_efOut [ 0 ] ; t2743 = t2585_idx_0 ;
tlu2_2d_linear_linear_value ( & pd_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = pd_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I = t2585_idx_0 ;
tlu2_2d_linear_linear_value ( & qd_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = qd_efOut [ 0 ] ; t2774 =
t2585_idx_0 ; tlu2_2d_linear_linear_value ( & rd_efOut [ 0ULL ] , & t170 .
mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , & t166 . mField0 [ 0ULL ] , &
t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = rd_efOut
[ 0 ] ; t2775 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 140ULL ] ;
tlu2_linear_linear_prelookup ( & sd_efOut . mField0 [ 0ULL ] , & sd_efOut .
mField1 [ 0ULL ] , & sd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t2049 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t102 = sd_efOut ; t2049 [ 0ULL ] = X [ 138ULL ] ;
tlu2_linear_linear_prelookup ( & td_efOut . mField0 [ 0ULL ] , & td_efOut .
mField1 [ 0ULL ] , & td_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t2049 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t101 = td_efOut ; tlu2_2d_linear_linear_value ( & ud_efOut [ 0ULL ] , & t102
. mField0 [ 0ULL ] , & t102 . mField2 [ 0ULL ] , & t101 . mField0 [ 0ULL ] ,
& t101 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ud_efOut
[ 0 ] ; t4834 = t2585_idx_0 ; t2778 = U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 :
t5007 ) * X [ 138ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ;
t2049 [ 0ULL ] = X [ 137ULL ] ; tlu2_linear_linear_prelookup ( & vd_efOut .
mField0 [ 0ULL ] , & vd_efOut . mField1 [ 0ULL ] , & vd_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [ 0ULL ] , &
t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t170 = vd_efOut ;
tlu2_2d_linear_linear_value ( & wd_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , & t101 . mField0 [ 0ULL ] , & t101 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = wd_efOut [ 0 ] ; t2779 =
t2585_idx_0 ; t2049 [ 0ULL ] = X [ 142ULL ] ; tlu2_linear_linear_prelookup (
& xd_efOut . mField0 [ 0ULL ] , & xd_efOut . mField1 [ 0ULL ] , & xd_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t2049 [
0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t140 = xd_efOut ;
tlu2_2d_linear_linear_value ( & yd_efOut [ 0ULL ] , & t140 . mField0 [ 0ULL ]
, & t140 . mField2 [ 0ULL ] , & t182 . mField0 [ 0ULL ] , & t182 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = yd_efOut [ 0 ] ; t2781 = -
U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [ 93ULL ] / ( t2585_idx_0 ==
0.0 ? 1.0E-16 : t2585_idx_0 ) ; t4834 = ( t4834 + t2585_idx_0 ) / 2.0 ; t2782
= pmf_sqrt ( ( X [ 146ULL ] >= 1.0 ? X [ 146ULL ] : 1.0 ) * 402.5245441795231
) ; if ( X [ 146ULL ] >= 1.0 ) { t2783 = pmf_log ( X [ 146ULL ] ) ; } else {
t2783 = X [ 146ULL ] - 1.0 ; } if ( X [ 147ULL ] / 1.0E-5 >= 1.0 ) { t2784 =
pmf_log ( X [ 147ULL ] / 1.0E-5 ) ; } else { t2784 = X [ 147ULL ] / 1.0E-5 -
1.0 ; } t2785 = pmf_exp ( ( t2784 - 5.65948221575962 ) - t2783 ) ; t2783 = X
[ 154ULL ] / 0.001 / ( t2785 == 0.0 ? 1.0E-16 : t2785 ) * ( X [ 154ULL ] /
0.001 / ( t2785 == 0.0 ? 1.0E-16 : t2785 ) ) / 2.0 * 0.001 + ( ( X [ 146ULL ]
- 293.15 ) + 420.0 ) ; zc_int350 = t2782 * t2785 * 1.0E-6 ; t2782 = pmf_sqrt
( X [ 154ULL ] * X [ 154ULL ] + zc_int350 * zc_int350 ) ; t2787 = pmf_sqrt (
( X [ 148ULL ] >= 1.0 ? X [ 148ULL ] : 1.0 ) * 402.5245441795231 ) ; if ( X [
148ULL ] >= 1.0 ) { t2789 = pmf_log ( X [ 148ULL ] ) ; } else { t2789 = X [
148ULL ] - 1.0 ; } if ( X [ 149ULL ] / 1.0E-5 >= 1.0 ) { t2790 = pmf_log ( X
[ 149ULL ] / 1.0E-5 ) ; } else { t2790 = X [ 149ULL ] / 1.0E-5 - 1.0 ; }
piece313 = pmf_exp ( ( t2790 - 5.65948221575962 ) - t2789 ) ; t2789 = - X [
154ULL ] / 0.001 / ( piece313 == 0.0 ? 1.0E-16 : piece313 ) * ( - X [ 154ULL
] / 0.001 / ( piece313 == 0.0 ? 1.0E-16 : piece313 ) ) / 2.0 * 0.001 + ( ( X
[ 148ULL ] - 293.15 ) + 420.0 ) ; t2793 = t2787 * piece313 * 1.0E-6 ; t2787 =
pmf_sqrt ( X [ 154ULL ] * X [ 154ULL ] + t2793 * t2793 ) ; if ( X [ 151ULL ]
>= 1.0 ) { piece313 = pmf_log ( X [ 151ULL ] ) ; } else { piece313 = X [
151ULL ] - 1.0 ; } t2793 = pmf_exp ( ( t2784 - 5.65948221575962 ) - piece313
) ; if ( X [ 152ULL ] >= 1.0 ) { t2784 = pmf_log ( X [ 152ULL ] ) ; } else {
t2784 = X [ 152ULL ] - 1.0 ; } piece313 = pmf_exp ( ( t2790 -
5.65948221575962 ) - t2784 ) ; t2784 = pmf_sqrt ( X [ 154ULL ] * X [ 154ULL ]
+ 1.0E-8 ) * X [ 154ULL ] ; t2785 = - X [ 154ULL ] / 0.001 / ( t2785 == 0.0 ?
1.0E-16 : t2785 ) * ( - X [ 154ULL ] / 0.001 / ( t2785 == 0.0 ? 1.0E-16 :
t2785 ) ) / 2.0 * 0.001 + ( ( X [ 146ULL ] - 293.15 ) + 420.0 ) ; t2790 = X [
158ULL ] * - 0.2 + 0.2 ; t2794 = X [ 172ULL ] * 1.0E-9 + X [ 19ULL ] ; t2795
= ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] * - 1.0000000000000011 ) + X [
173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ; t2797 = X [ 88ULL ] + X [ 174ULL ] ;
t2798 = pmf_sqrt ( X [ 186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 ) ;
t2799 = pmf_sqrt ( X [ 186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 ) ;
t2800 = pmf_sqrt ( X [ 186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 ) ;
if ( X [ 191ULL ] <= 0.0 ) { t2801 = 0.0 ; } else { t2801 = X [ 191ULL ] >=
1.0 ? 1.0 : X [ 191ULL ] ; } if ( X [ 192ULL ] <= 0.0 ) { t2802 = 0.0 ; }
else { t2802 = X [ 192ULL ] >= 1.0 ? 1.0 : X [ 192ULL ] ; } t2803 = ( ( ( 1.0
- t2801 ) - t2802 ) * 296.802103844292 + t2801 * 461.523 ) + t2802 *
4124.48151675695 ; if ( 1.0 - X [ 191ULL ] >= 0.01 ) { t2805 = 1.0 - X [
191ULL ] ; } else if ( 1.0 - X [ 191ULL ] >= - 0.1 ) { t2805 = pmf_exp ( ( (
1.0 - X [ 191ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t2805 =
1.6701700790245661E-7 ; } t2806 = - X [ 198ULL ] + U_idx_4 * - 0.01 ; if ( X
[ 23ULL ] <= 0.0 ) { t2808 = 0.0 ; } else { t2808 = X [ 23ULL ] >= 1.0 ? 1.0
: X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) { t2809 = 0.0 ; } else { t2809 =
X [ 24ULL ] >= 1.0 ? 1.0 : X [ 24ULL ] ; } t2810 = ( ( ( 1.0 - t2808 ) -
t2809 ) * 296.802103844292 + t2808 * 461.523 ) + t2809 * 4124.48151675695 ;
zc_int36 = ( X [ 21ULL ] / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) - X
[ 199ULL ] / ( X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * t2806 *
t2810 / 7.8539816339744827E-5 ; if ( X [ 199ULL ] <= 216.59999999999997 ) {
t2812 = 216.59999999999997 ; } else { t2812 = X [ 199ULL ] >= 623.15 ? 623.15
: X [ 199ULL ] ; } t2815 = t2812 * t2812 ; t2813 = ( ( ( 1074.1165326382554 +
t2812 * - 0.22145652610641059 ) + t2815 * 0.0003721298010901061 ) * ( ( 1.0 -
t2808 ) - t2809 ) + ( ( 1479.6504774710402 + t2812 * 1.2002114337050787 ) +
t2815 * - 0.00038614513167845434 ) * t2808 ) + ( ( 12825.281119789837 + t2812
* 6.9647057412840034 ) + t2815 * - 0.0070524868246844051 ) * t2809 ; t2838 =
t2813 - t2810 ; t2812 = t2813 / ( t2838 == 0.0 ? 1.0E-16 : t2838 ) ; t2813 =
pmf_sqrt ( zc_int36 * zc_int36 * 9.999999999999999E-14 + fabs ( X [ 199ULL ]
* t2812 * t2810 ) * 1.0E-9 ) ; if ( X [ 201ULL ] <= 0.0 ) { t2815 = 0.0 ; }
else { t2815 = X [ 201ULL ] >= 1.0 ? 1.0 : X [ 201ULL ] ; } if ( X [ 202ULL ]
<= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 =
0.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 = X [ 202ULL
] >= 1.0 ? 1.0 : X [ 202ULL ] ; } t2049 [ 0ULL ] = X [ 21ULL ] ; t1924 [ 0 ]
= 52ULL ; tlu2_linear_nearest_prelookup ( & ae_efOut . mField0 [ 0ULL ] , &
ae_efOut . mField1 [ 0ULL ] , & ae_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t99 = ae_efOut ; tlu2_1d_linear_nearest_value ( &
be_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = be_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ce_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = ce_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
de_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = de_efOut [ 0 ] ; t2818 = ( ( ( 1.0 - t2815 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ) *
t2585_idx_0 + t2586_idx_0 * t2815 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ; t4284 = X [
200ULL ] * X [ 200ULL ] * t2812 ; t2820 = - pmf_sqrt ( fabs ( t4284 / ( t2810
== 0.0 ? 1.0E-16 : t2810 ) / ( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] )
) ) * 7.8539816339744827E-5 ; if ( t2820 >= 0.0 ) { t2821 = t2820 * 100000.0
; } else { t2821 = - t2820 * 100000.0 ; } t4494 = t2818 *
7.8539816339744827E-5 ; t2823 = t2821 * 0.01 / ( t4494 == 0.0 ? 1.0E-16 :
t4494 ) ; t2845 = X [ 21ULL ] * t2810 ; piece20 = X [ 22ULL ] / ( t2845 ==
0.0 ? 1.0E-16 : t2845 ) ; t4487 = piece20 * 1.5707963267948965E-8 ; zc_int113
= t2820 * t2818 * 35.2 / ( t4487 == 0.0 ? 1.0E-16 : t4487 ) ; t2828 = t2823
>= 1.0 ? t2823 : 1.0 ; t2848 = pmf_log10 ( 6.9 / ( t2828 == 0.0 ? 1.0E-16 :
t2828 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2828 == 0.0 ?
1.0E-16 : t2828 ) + 0.00017169489553429715 ) * 3.24 ; t2850 = piece20 *
1.2337005501361697E-10 ; t2821 = t2820 * t2821 * ( 1.0 / ( t2848 == 0.0 ?
1.0E-16 : t2848 ) ) * 0.55 / ( t2850 == 0.0 ? 1.0E-16 : t2850 ) ; t2828 = (
t2823 - 2000.0 ) / 2000.0 ; t2830 = t2828 * t2828 * 3.0 - t2828 * t2828 *
t2828 * 2.0 ; if ( t2823 <= 2000.0 ) { t2828 = zc_int113 * 1.0E-5 ; } else if
( t2823 >= 4000.0 ) { t2828 = t2821 * 1.0E-5 ; } else { t2828 = ( ( 1.0 -
t2830 ) * zc_int113 + t2821 * t2830 ) * 1.0E-5 ; } t2813 = t2806 * t2813 /
7.8539816339744827E-5 * 0.00031622776601683789 + t2828 ; t2821 = X [ 176ULL ]
- X [ 22ULL ] ; zc_int113 = - ( ( X [ 21ULL ] / ( X [ 22ULL ] == 0.0 ?
1.0E-16 : X [ 22ULL ] ) - X [ 203ULL ] / ( X [ 204ULL ] == 0.0 ? 1.0E-16 : X
[ 204ULL ] ) ) * X [ 186ULL ] * t2810 ) / 7.8539816339744827E-5 ; if ( X [
203ULL ] <= 216.59999999999997 ) { t2828 = 216.59999999999997 ; } else {
t2828 = X [ 203ULL ] >= 623.15 ? 623.15 : X [ 203ULL ] ; } t2634 = t2828 *
t2828 ; t2830 = ( ( ( 1074.1165326382554 + t2828 * - 0.22145652610641059 ) +
t2634 * 0.0003721298010901061 ) * ( ( 1.0 - t2808 ) - t2809 ) + ( (
1479.6504774710402 + t2828 * 1.2002114337050787 ) + t2634 * -
0.00038614513167845434 ) * t2808 ) + ( ( 12825.281119789837 + t2828 *
6.9647057412840034 ) + t2634 * - 0.0070524868246844051 ) * t2809 ;
intrm_sf_mf_157 = t2830 - t2810 ; t2828 = t2830 / ( intrm_sf_mf_157 == 0.0 ?
1.0E-16 : intrm_sf_mf_157 ) ; t2830 = pmf_sqrt ( zc_int113 * zc_int113 *
9.999999999999999E-14 + fabs ( X [ 203ULL ] * t2828 * t2810 ) * 1.0E-9 ) ;
t4498 = X [ 204ULL ] * X [ 204ULL ] * t2828 ; t2634 = - pmf_sqrt ( fabs (
t4498 / ( t2810 == 0.0 ? 1.0E-16 : t2810 ) / ( X [ 203ULL ] == 0.0 ? 1.0E-16
: X [ 203ULL ] ) ) ) * 7.8539816339744827E-5 ; if ( t2634 >= 0.0 ) { t2832 =
t2634 * 100000.0 ; } else { t2832 = - t2634 * 100000.0 ; } zc_int352 = t2832
* 0.01 / ( t4494 == 0.0 ? 1.0E-16 : t4494 ) ; t2837 = t2634 * t2818 * 35.2 /
( t4487 == 0.0 ? 1.0E-16 : t4487 ) ; t2838 = zc_int352 >= 1.0 ? zc_int352 :
1.0 ; t2866 = pmf_log10 ( 6.9 / ( t2838 == 0.0 ? 1.0E-16 : t2838 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2838 == 0.0 ? 1.0E-16 : t2838
) + 0.00017169489553429715 ) * 3.24 ; t2832 = t2634 * t2832 * ( 1.0 / ( t2866
== 0.0 ? 1.0E-16 : t2866 ) ) * 0.55 / ( t2850 == 0.0 ? 1.0E-16 : t2850 ) ;
t2838 = ( zc_int352 - 2000.0 ) / 2000.0 ; t2840 = t2838 * t2838 * 3.0 - t2838
* t2838 * t2838 * 2.0 ; if ( zc_int352 <= 2000.0 ) { t2838 = t2837 * 1.0E-5 ;
} else if ( zc_int352 >= 4000.0 ) { t2838 = t2832 * 1.0E-5 ; } else { t2838 =
( ( 1.0 - t2840 ) * t2837 + t2832 * t2840 ) * 1.0E-5 ; } t2830 = - ( X [
186ULL ] * t2830 ) / 7.8539816339744827E-5 * 0.00031622776601683789 + t2838 ;
t2832 = X [ 195ULL ] - X [ 22ULL ] ; t2049 [ 0ULL ] = X [ 21ULL ] ;
tlu2_linear_linear_prelookup ( & ee_efOut . mField0 [ 0ULL ] , & ee_efOut .
mField1 [ 0ULL ] , & ee_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t187 = ee_efOut ; tlu2_1d_linear_linear_value ( & fe_efOut [ 0ULL ] , &
t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
fe_efOut [ 0 ] ; t2837 = t2585_idx_0 ; tlu2_1d_linear_linear_value ( &
ge_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField19 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = ge_efOut [ 0 ] ; t2838 = t2585_idx_0 ; if ( 1.0 - X
[ 23ULL ] >= 0.01 ) { t2842 = 1.0 - X [ 23ULL ] ; } else if ( 1.0 - X [ 23ULL
] >= - 0.1 ) { t2842 = pmf_exp ( ( ( 1.0 - X [ 23ULL ] ) - 0.01 ) / 0.01 ) *
0.01 ; } else { t2842 = 1.6701700790245661E-7 ; } t2840 = X [ 24ULL ] / (
t2842 == 0.0 ? 1.0E-16 : t2842 ) * 3827.6794129126583 + 296.802103844292 ;
tlu2_1d_linear_linear_value ( & he_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ]
, & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = he_efOut [ 0 ] ; t2846 =
pmf_exp ( pmf_log ( X [ 22ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t2846 >=
1.0 ) { t2873 = ( t2846 - 1.0 ) * 461.523 + t2840 ; t2848 = t2840 / ( t2873
== 0.0 ? 1.0E-16 : t2873 ) ; } else { t2848 = 1.0 ; } t2875 = t2848 * 0.01 ;
t2840 = ( X [ 23ULL ] - t2848 ) / ( t2875 == 0.0 ? 1.0E-16 : t2875 ) ; if ( X
[ 23ULL ] - t2848 <= 0.0 ) { t2840 = 0.0 ; } else if ( X [ 23ULL ] - t2848 >=
t2848 * 0.01 ) { t2840 = X [ 23ULL ] - t2848 ; } else { t2840 = ( X [ 23ULL ]
- t2848 ) * ( t2840 * t2840 * 3.0 - t2840 * t2840 * t2840 * 2.0 ) ; } piece20
= piece20 * t2840 * 7.8539816339744827E-5 / 0.001 ; t2840 = ( t2837 - t2838 )
* piece20 ; tlu2_1d_linear_nearest_value ( & ie_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ie_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & je_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = je_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & ke_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField22 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ke_efOut [ 0
] ; t2838 = ( ( ( 1.0 - t2815 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ) *
t2585_idx_0 + t2586_idx_0 * t2815 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ; t2848 = ( X
[ 179ULL ] - X [ 21ULL ] ) * ( t2838 * 0.031415926535897927 / 0.01 ) ; if ( X
[ 178ULL ] <= 0.0 ) { t2849 = 0.0 ; } else { t2849 = X [ 178ULL ] >= 1.0 ?
1.0 : X [ 178ULL ] ; } if ( X [ 177ULL ] <= 0.0 ) { t2851 = 0.0 ; } else {
t2851 = X [ 177ULL ] >= 1.0 ? 1.0 : X [ 177ULL ] ; } t2852 = ( ( ( 1.0 -
t2849 ) - t2851 ) * 296.802103844292 + t2849 * 461.523 ) + t2851 *
4124.48151675695 ; t2857 = X [ 178ULL ] * 461.523 / ( t2852 == 0.0 ? 1.0E-16
: t2852 ) ; if ( t2857 <= 0.0 ) { intrm_sf_mf_157 = 0.0 ; } else {
intrm_sf_mf_157 = t2857 >= 1.0 ? 1.0 : t2857 ; } t2857 = X [ 177ULL ] *
4124.48151675695 / ( t2852 == 0.0 ? 1.0E-16 : t2852 ) ; if ( t2857 <= 0.0 ) {
t2860 = 0.0 ; } else { t2860 = t2857 >= 1.0 ? 1.0 : t2857 ; } t2049 [ 0ULL ]
= X [ 175ULL ] ; tlu2_linear_nearest_prelookup ( & le_efOut . mField0 [ 0ULL
] , & le_efOut . mField1 [ 0ULL ] , & le_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = le_efOut ; tlu2_1d_linear_nearest_value ( &
me_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = me_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ne_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = ne_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
oe_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = oe_efOut [ 0 ] ; t2857 = ( ( ( 1.0 - intrm_sf_mf_157
) - t2860 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_157 ) + t2587_idx_0 *
t2860 ; tlu2_1d_linear_nearest_value ( & pe_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = pe_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & qe_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = qe_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & re_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = re_efOut [ 0
] ; t2862 = ( ( ( 1.0 - t2815 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ) *
t2585_idx_0 + t2586_idx_0 * t2815 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ;
tlu2_1d_linear_nearest_value ( & se_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = se_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & te_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = te_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ue_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ue_efOut [ 0 ] ; t2815
= ( ( ( 1.0 - intrm_sf_mf_157 ) - t2860 ) * t2585_idx_0 + t2586_idx_0 *
intrm_sf_mf_157 ) + t2587_idx_0 * t2860 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 = ( t2806 - (
- X [ 186ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & ve_efOut [ 0ULL ]
, & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = ve_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
we_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = we_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
xe_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = xe_efOut [ 0 ] ; t2866 = ( ( ( 1.0 - intrm_sf_mf_157
) - t2860 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_157 ) + t2587_idx_0 *
t2860 ; t2883 = ( t2818 + t2866 ) / 2.0 * 7.8539816339744827E-5 ;
intrm_sf_mf_157 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 : 0.0 ) *
0.01 / ( t2883 == 0.0 ? 1.0E-16 : t2883 ) ; t2860 = intrm_sf_mf_157 >= 0.0 ?
intrm_sf_mf_157 : - intrm_sf_mf_157 ; t2864 = t2860 > 1000.0 ? t2860 : 1000.0
; t2884 = t2857 + t2862 ; if ( t2884 / 2.0 > 0.5 ) { t2867 = ( t2857 + t2862
) / 2.0 ; } else { t2867 = 0.5 ; } intrm_sf_mf_249 = pmf_log10 ( 6.9 / (
t2864 == 0.0 ? 1.0E-16 : t2864 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t2864 == 0.0 ? 1.0E-16 : t2864 ) + 0.00017169489553429715 ) * 3.24 ;
t2869 = 1.0 / ( intrm_sf_mf_249 == 0.0 ? 1.0E-16 : intrm_sf_mf_249 ) ; t2888
= ( pmf_pow ( t2867 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t2869 / 8.0
) * 12.7 + 1.0 ; t2864 = ( t2864 - 1000.0 ) * ( t2869 / 8.0 ) * t2867 / (
t2888 == 0.0 ? 1.0E-16 : t2888 ) ; t2867 = ( t2860 - 2000.0 ) / 2000.0 ;
t2869 = t2867 * t2867 * 3.0 - t2867 * t2867 * t2867 * 2.0 ; if ( t2860 <=
2000.0 ) { t2867 = 3.66 ; } else if ( t2860 >= 4000.0 ) { t2867 = t2864 ; }
else { t2867 = ( 1.0 - t2869 ) * 3.66 + t2864 * t2869 ; } zc_int81 = t2884 /
2.0 ; if ( t2860 > t2867 * 0.031415926535897927 / 7.8539816339744827E-5 / (
zc_int81 == 0.0 ? 1.0E-16 : zc_int81 ) / 30.0 ) { t2899 = ( t2857 + t2862 ) /
2.0 ; t2864 = t2867 * 0.031415926535897927 / ( t2860 == 0.0 ? 1.0E-16 : t2860
) / 7.8539816339744827E-5 / ( t2899 == 0.0 ? 1.0E-16 : t2899 ) ; } else {
t2864 = 30.0 ; } t2860 = ( X [ 179ULL ] - X [ 175ULL ] ) * ( 1.0 - pmf_exp (
- t2864 ) ) ; intrm_sf_mf_157 = intrm_sf_mf_157 * 7.8539816339744827E-5 /
0.01 * ( t2884 / 2.0 ) * ( ( t2815 + t2838 ) / 2.0 ) * t2860 ; if ( X [
197ULL ] <= 0.0 ) { t2860 = 0.0 ; } else { t2860 = X [ 197ULL ] >= 1.0 ? 1.0
: X [ 197ULL ] ; } if ( X [ 196ULL ] <= 0.0 ) { t2864 = 0.0 ; } else { t2864
= X [ 196ULL ] >= 1.0 ? 1.0 : X [ 196ULL ] ; } t2867 = ( ( ( 1.0 - t2860 ) -
t2864 ) * 296.802103844292 + t2860 * 461.523 ) + t2864 * 4124.48151675695 ;
t2869 = X [ 197ULL ] * 461.523 / ( t2867 == 0.0 ? 1.0E-16 : t2867 ) ; if (
t2869 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 =
t2869 >= 1.0 ? 1.0 : t2869 ; } t2869 = X [ 196ULL ] * 4124.48151675695 / (
t2867 == 0.0 ? 1.0E-16 : t2867 ) ; if ( t2869 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 =
t2869 >= 1.0 ? 1.0 : t2869 ; } t2049 [ 0ULL ] = X [ 194ULL ] ;
tlu2_linear_nearest_prelookup ( & ye_efOut . mField0 [ 0ULL ] , & ye_efOut .
mField1 [ 0ULL ] , & ye_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = ye_efOut ; tlu2_1d_linear_nearest_value ( & af_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
af_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & bf_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = bf_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & cf_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = cf_efOut [ 0
] ; t2869 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6
; tlu2_1d_linear_nearest_value ( & df_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL
] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = df_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ef_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = ef_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ff_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ff_efOut [ 0 ] ; t2872 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6
; tlu2_1d_linear_nearest_value ( & gf_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL
] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & hf_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = hf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & if_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = if_efOut [ 0 ] ; t2907 =
( t2818 + ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6
) ) / 2.0 * 7.8539816339744827E-5 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 <= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 : 0.0 ) *
0.01 / ( t2907 == 0.0 ? 1.0E-16 : t2907 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 : 1000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = t2862 + t2869
; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 / 2.0 >
0.5 ) { t2873 = ( t2862 + t2869 ) / 2.0 ; } else { t2873 = 0.5 ; } U_idx_1 =
pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) +
0.00017169489553429715 ) * 3.24 ; t2874 = 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ; intrm_sf_mf_356 = ( pmf_pow ( t2873 , 0.66666666666666663 ) - 1.0
) * pmf_sqrt ( t2874 / 8.0 ) * 12.7 + 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 - 1000.0 ) *
( t2874 / 8.0 ) * t2873 / ( intrm_sf_mf_356 == 0.0 ? 1.0E-16 :
intrm_sf_mf_356 ) ; t2873 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 - 2000.0 ) /
2000.0 ; t2874 = t2873 * t2873 * 3.0 - t2873 * t2873 * t2873 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 <= 2000.0 ) {
t2873 = 3.66 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 >= 4000.0 ) {
t2873 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ; }
else { t2873 = ( 1.0 - t2874 ) * 3.66 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 * t2874 ; }
U_idx_1 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 / 2.0
; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 >
t2873 * 0.031415926535897927 / 7.8539816339744827E-5 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) / 30.0 ) { t2923 = ( t2862 + t2869 ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 = t2873 *
0.031415926535897927 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) /
7.8539816339744827E-5 / ( t2923 == 0.0 ? 1.0E-16 : t2923 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 = 30.0 ; }
t2862 = ( X [ 179ULL ] - X [ 194ULL ] ) * ( 1.0 - pmf_exp ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) ) ; t2838 =
intrm_sf_mf_157 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 *
7.8539816339744827E-5 / 0.01 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 / 2.0 ) * ( (
t2838 + t2872 ) / 2.0 ) * t2862 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 = pmf_sqrt (
t2806 * t2806 + 2.0360111955237585E-13 ) ; intrm_sf_mf_157 = pmf_sqrt ( t2806
* t2806 + 2.3237892571262758E-14 ) ; t2862 = pmf_sqrt ( t2806 * t2806 +
1.6409606283812424E-14 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 = pmf_sqrt (
X [ 186ULL ] * X [ 186ULL ] + 2.0360111955237585E-13 ) ; t2872 = pmf_sqrt ( X
[ 186ULL ] * X [ 186ULL ] + 2.3237892571262758E-14 ) ; t2873 = pmf_sqrt ( X [
186ULL ] * X [ 186ULL ] + 1.6409606283812424E-14 ) ;
tlu2_1d_linear_linear_value ( & jf_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ]
, & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = jf_efOut [ 0 ] ; t2874 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & kf_efOut [ 0ULL ] , & t187 .
mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
kf_efOut [ 0 ] ; t2876 = - X [ 187ULL ] + ( - X [ 210ULL ] - X [ 211ULL ] ) ;
t2869 = ( - X [ 186ULL ] + t2806 ) - piece20 * 100000.0 ; t2877 = ( - X [
188ULL ] + ( - X [ 212ULL ] - X [ 213ULL ] ) ) - piece20 * 100000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 = ( ( ( 1.0 -
t2808 ) - t2809 ) * t2874 + t2837 * t2808 ) + t2585_idx_0 * t2809 ; t2879 =
t2874 - X [ 21ULL ] * 0.296802103844292 ; t2874 = t2585_idx_0 - X [ 21ULL ] *
4.12448151675695 ; t2875 = t2837 - X [ 21ULL ] * 0.461523 ; t2837 = U_idx_3 *
0.031415926535897927 ; if ( t2837 * 0.0001 <= 7.8539816339744857E-13 ) {
t2880 = 7.8539816339744857E-13 ; } else if ( t2837 * 0.0001 >=
3.1415926535897929E-6 ) { t2880 = 3.1415926535897929E-6 ; } else { t2880 =
t2837 * 0.0001 ; } t2837 = t2880 / 7.8539816339744827E-5 ; if ( X [ 221ULL ]
<= 0.0 ) { t2881 = 0.0 ; } else { t2881 = X [ 221ULL ] >= 1.0 ? 1.0 : X [
221ULL ] ; } if ( X [ 222ULL ] <= 0.0 ) { intrm_sf_mf_517 = 0.0 ; } else {
intrm_sf_mf_517 = X [ 222ULL ] >= 1.0 ? 1.0 : X [ 222ULL ] ; } t2883 = ( ( (
1.0 - t2881 ) - intrm_sf_mf_517 ) * 296.802103844292 + t2881 * 461.523 ) +
intrm_sf_mf_517 * 4124.48151675695 ; t2928 = X [ 219ULL ] * t2883 ; t2884 = X
[ 220ULL ] / ( t2928 == 0.0 ? 1.0E-16 : t2928 ) ; zc_int50 = X [ 220ULL ] / (
X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [
219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; intrm_sf_mf_249 = X [ 220ULL ]
/ 1.01325 * ( X [ 224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] )
) ; if ( X [ 186ULL ] > 0.0 ) { t2887 = ( t2837 + 1.0 ) * ( 1.0 - t2837 *
zc_int50 ) * ( X [ 186ULL ] / 0.64 / ( t2880 == 0.0 ? 1.0E-16 : t2880 ) * ( X
[ 186ULL ] / 0.64 / ( t2880 == 0.0 ? 1.0E-16 : t2880 ) ) / 2.0 / ( t2884 ==
0.0 ? 1.0E-16 : t2884 ) ) * 9.9999999999999991E-11 ; } else if ( X [ 186ULL ]
< 0.0 ) { t2887 = ( t2837 + 1.0 ) * ( 1.0 - t2837 * intrm_sf_mf_249 ) * ( X [
186ULL ] / 0.64 / ( t2880 == 0.0 ? 1.0E-16 : t2880 ) * ( X [ 186ULL ] / 0.64
/ ( t2880 == 0.0 ? 1.0E-16 : t2880 ) ) / 2.0 / ( t2884 == 0.0 ? 1.0E-16 :
t2884 ) ) * 9.9999999999999991E-11 ; } else { t2887 = 0.0 ; } intrm_sf_mf_383
= ( X [ 195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ; t2888 = ( 1.0 -
t2837 ) * ( 1.0 - t2837 ) ; t2890 = intrm_sf_mf_383 * t2888 ; t2892 = ( t2837
+ 1.0 ) * ( 1.0 - t2837 * zc_int50 ) - ( 1.0 - t2837 * intrm_sf_mf_249 ) *
t2837 * 2.0 ; zc_int81 = ( X [ 195ULL ] - 1.01325 ) * ( t2892 >= t2888 ?
t2892 : t2888 ) ; t2892 = ( X [ 195ULL ] - 1.01325 ) / ( intrm_sf_mf_383 ==
0.0 ? 1.0E-16 : intrm_sf_mf_383 ) ; t2894 = t2892 * t2892 * 3.0 - t2892 *
t2892 * t2892 * 2.0 ; if ( X [ 195ULL ] - 1.01325 <= 0.0 ) { t2892 = t2890 ;
} else if ( X [ 195ULL ] - 1.01325 >= intrm_sf_mf_383 ) { t2892 = zc_int81 ;
} else { t2892 = ( 1.0 - t2894 ) * t2890 + zc_int81 * t2894 ; } zc_int81 = (
t2837 + 1.0 ) * ( 1.0 - t2837 * intrm_sf_mf_249 ) - ( 1.0 - t2837 * zc_int50
) * t2837 * 2.0 ; t2837 = ( 1.01325 - X [ 195ULL ] ) * ( zc_int81 >= t2888 ?
zc_int81 : t2888 ) ; zc_int50 = ( 1.01325 - X [ 195ULL ] ) / (
intrm_sf_mf_383 == 0.0 ? 1.0E-16 : intrm_sf_mf_383 ) ; intrm_sf_mf_249 =
zc_int50 * zc_int50 * 3.0 - zc_int50 * zc_int50 * zc_int50 * 2.0 ; if (
1.01325 - X [ 195ULL ] <= 0.0 ) { zc_int50 = t2890 ; } else if ( 1.01325 - X
[ 195ULL ] >= intrm_sf_mf_383 ) { zc_int50 = t2837 ; } else { zc_int50 = (
1.0 - intrm_sf_mf_249 ) * t2890 + t2837 * intrm_sf_mf_249 ; } if ( X [ 195ULL
] > 1.01325 ) { t2837 = t2892 ; } else { t2837 = X [ 195ULL ] < 1.01325 ?
zc_int50 : t2890 ; } if ( X [ 219ULL ] <= 216.59999999999997 ) { zc_int50 =
216.59999999999997 ; } else { zc_int50 = X [ 219ULL ] >= 623.15 ? 623.15 : X
[ 219ULL ] ; } U_idx_1 = zc_int50 * zc_int50 ; intrm_sf_mf_249 = ( ( (
1074.1165326382554 + zc_int50 * - 0.22145652610641059 ) + U_idx_1 *
0.0003721298010901061 ) * ( ( 1.0 - t2881 ) - intrm_sf_mf_517 ) + ( (
1479.6504774710402 + zc_int50 * 1.2002114337050787 ) + U_idx_1 * -
0.00038614513167845434 ) * t2881 ) + ( ( 12825.281119789837 + zc_int50 *
6.9647057412840034 ) + U_idx_1 * - 0.0070524868246844051 ) * intrm_sf_mf_517
; t2951 = intrm_sf_mf_249 - t2883 ; t2952 = X [ 220ULL ] * X [ 220ULL ] * (
intrm_sf_mf_249 / ( t2951 == 0.0 ? 1.0E-16 : t2951 ) ) ; zc_int50 = pmf_sqrt
( fabs ( t2952 / ( t2883 == 0.0 ? 1.0E-16 : t2883 ) / ( X [ 219ULL ] == 0.0 ?
1.0E-16 : X [ 219ULL ] ) ) ) * t2880 * 0.64 ; t2955 = t2884 * 2.0 ; t2884 = (
X [ 195ULL ] - 1.01325 ) * pmf_sqrt ( fabs ( t2955 / ( t2837 == 0.0 ? 1.0E-16
: t2837 ) ) ) * t2880 * 0.64 ; if ( X [ 27ULL ] <= 0.0 ) { intrm_sf_mf_249 =
0.0 ; } else { intrm_sf_mf_249 = X [ 27ULL ] >= 1.0 ? 1.0 : X [ 27ULL ] ; }
if ( X [ 26ULL ] <= 0.0 ) { t2888 = 0.0 ; } else { t2888 = X [ 26ULL ] >= 1.0
? 1.0 : X [ 26ULL ] ; } t2890 = ( ( ( 1.0 - intrm_sf_mf_249 ) - t2888 ) *
296.802103844292 + intrm_sf_mf_249 * 461.523 ) + t2888 * 4124.48151675695 ;
t2892 = ( X [ 25ULL ] / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) - X [
245ULL ] / ( X [ 246ULL ] == 0.0 ? 1.0E-16 : X [ 246ULL ] ) ) * X [ 244ULL ]
* t2890 / 0.32 ; if ( X [ 245ULL ] <= 216.59999999999997 ) { zc_int81 =
216.59999999999997 ; } else { zc_int81 = X [ 245ULL ] >= 623.15 ? 623.15 : X
[ 245ULL ] ; } t2656 = zc_int81 * zc_int81 ; t2894 = ( ( ( 1074.1165326382554
+ zc_int81 * - 0.22145652610641059 ) + t2656 * 0.0003721298010901061 ) * ( (
1.0 - intrm_sf_mf_249 ) - t2888 ) + ( ( 1479.6504774710402 + zc_int81 *
1.2002114337050787 ) + t2656 * - 0.00038614513167845434 ) * intrm_sf_mf_249 )
+ ( ( 12825.281119789837 + zc_int81 * 6.9647057412840034 ) + t2656 * -
0.0070524868246844051 ) * t2888 ; t2961 = t2894 - t2890 ; zc_int81 = t2894 /
( t2961 == 0.0 ? 1.0E-16 : t2961 ) ; t2894 = pmf_sqrt ( t2892 * t2892 *
9.999999999999999E-14 + fabs ( X [ 245ULL ] * zc_int81 * t2890 ) * 1.0E-9 ) ;
if ( X [ 232ULL ] <= 0.0 ) { t2656 = 0.0 ; } else { t2656 = X [ 232ULL ] >=
1.0 ? 1.0 : X [ 232ULL ] ; } if ( X [ 234ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 = X [ 234ULL
] >= 1.0 ? 1.0 : X [ 234ULL ] ; } t2049 [ 0ULL ] = X [ 25ULL ] ;
tlu2_linear_nearest_prelookup ( & lf_efOut . mField0 [ 0ULL ] , & lf_efOut .
mField1 [ 0ULL ] , & lf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = lf_efOut ; tlu2_1d_linear_nearest_value ( & mf_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
mf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & nf_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
nf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & of_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
of_efOut [ 0 ] ; t2898 = ( ( ( 1.0 - t2656 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ) *
t2585_idx_0 + t2586_idx_0 * t2656 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ; t2962 = X [
246ULL ] * X [ 246ULL ] * zc_int81 ; t2899 = - pmf_sqrt ( fabs ( t2962 / (
t2890 == 0.0 ? 1.0E-16 : t2890 ) / ( X [ 245ULL ] == 0.0 ? 1.0E-16 : X [
245ULL ] ) ) ) * 0.32 ; if ( t2899 >= 0.0 ) { t2900 = t2899 * 100000.0 ; }
else { t2900 = - t2899 * 100000.0 ; } t2966 = t2898 * 0.32 ; t2902 = t2900 *
0.01 / ( t2966 == 0.0 ? 1.0E-16 : t2966 ) ; t2968 = X [ 25ULL ] * t2890 ;
piece45 = X [ 31ULL ] / ( t2968 == 0.0 ? 1.0E-16 : t2968 ) ; t2970 = piece45
* 6.4000000000000011E-5 ; zc_int84 = t2899 * t2898 * 2.9973120849090416 / (
t2970 == 0.0 ? 1.0E-16 : t2970 ) ; t2905 = t2902 >= 1.0 ? t2902 : 1.0 ; t2971
= pmf_log10 ( 6.9 / ( t2905 == 0.0 ? 1.0E-16 : t2905 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2905 == 0.0 ? 1.0E-16 : t2905
) + 0.00017169489553429715 ) * 3.24 ; t2973 = piece45 * 0.0020480000000000003
; t2900 = t2899 * t2900 * ( 1.0 / ( t2971 == 0.0 ? 1.0E-16 : t2971 ) ) *
0.046833001326703774 / ( t2973 == 0.0 ? 1.0E-16 : t2973 ) ; t2905 = ( t2902 -
2000.0 ) / 2000.0 ; t2906 = t2905 * t2905 * 3.0 - t2905 * t2905 * t2905 * 2.0
; if ( t2902 <= 2000.0 ) { t2905 = zc_int84 * 1.0E-5 ; } else if ( t2902 >=
4000.0 ) { t2905 = t2900 * 1.0E-5 ; } else { t2905 = ( ( 1.0 - t2906 ) *
zc_int84 + t2900 * t2906 ) * 1.0E-5 ; } t2894 = X [ 244ULL ] * t2894 / 0.32 *
0.00031622776601683789 + t2905 ; t2900 = X [ 241ULL ] - X [ 31ULL ] ;
zc_int84 = ( X [ 25ULL ] / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) - X
[ 248ULL ] / ( X [ 249ULL ] == 0.0 ? 1.0E-16 : X [ 249ULL ] ) ) * X [ 247ULL
] * t2890 / 0.32 ; if ( X [ 248ULL ] <= 216.59999999999997 ) { t2905 =
216.59999999999997 ; } else { t2905 = X [ 248ULL ] >= 623.15 ? 623.15 : X [
248ULL ] ; } t2907 = t2905 * t2905 ; t2906 = ( ( ( 1074.1165326382554 + t2905
* - 0.22145652610641059 ) + t2907 * 0.0003721298010901061 ) * ( ( 1.0 -
intrm_sf_mf_249 ) - t2888 ) + ( ( 1479.6504774710402 + t2905 *
1.2002114337050787 ) + t2907 * - 0.00038614513167845434 ) * intrm_sf_mf_249 )
+ ( ( 12825.281119789837 + t2905 * 6.9647057412840034 ) + t2907 * -
0.0070524868246844051 ) * t2888 ; t213 = t2906 - t2890 ; t2905 = t2906 / (
t213 == 0.0 ? 1.0E-16 : t213 ) ; t2906 = pmf_sqrt ( zc_int84 * zc_int84 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t2905 * t2890 ) * 1.0E-9 ) ;
t2982 = X [ 249ULL ] * X [ 249ULL ] * t2905 ; t2907 = - pmf_sqrt ( fabs (
t2982 / ( t2890 == 0.0 ? 1.0E-16 : t2890 ) / ( X [ 248ULL ] == 0.0 ? 1.0E-16
: X [ 248ULL ] ) ) ) * 0.32 ; if ( t2907 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = t2907 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = - t2907 *
100000.0 ; } t2909 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 * 0.01 / (
t2966 == 0.0 ? 1.0E-16 : t2966 ) ; U_idx_1 = t2907 * t2898 *
2.9973120849090416 / ( t2970 == 0.0 ? 1.0E-16 : t2970 ) ; t2911 = t2909 >=
1.0 ? t2909 : 1.0 ; t2989 = pmf_log10 ( 6.9 / ( t2911 == 0.0 ? 1.0E-16 :
t2911 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2911 == 0.0 ?
1.0E-16 : t2911 ) + 0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = t2907 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 * ( 1.0 / (
t2989 == 0.0 ? 1.0E-16 : t2989 ) ) * 0.046833001326703774 / ( t2973 == 0.0 ?
1.0E-16 : t2973 ) ; t2911 = ( t2909 - 2000.0 ) / 2000.0 ; intrm_sf_mf_356 =
t2911 * t2911 * 3.0 - t2911 * t2911 * t2911 * 2.0 ; if ( t2909 <= 2000.0 ) {
t2911 = U_idx_1 * 1.0E-5 ; } else if ( t2909 >= 4000.0 ) { t2911 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 * 1.0E-5 ; }
else { t2911 = ( ( 1.0 - intrm_sf_mf_356 ) * U_idx_1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 *
intrm_sf_mf_356 ) * 1.0E-5 ; } t2906 = X [ 247ULL ] * t2906 / 0.32 *
0.00031622776601683789 + t2911 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = X [ 227ULL ]
- X [ 31ULL ] ; t2049 [ 0ULL ] = X [ 25ULL ] ; tlu2_linear_linear_prelookup (
& pf_efOut . mField0 [ 0ULL ] , & pf_efOut . mField1 [ 0ULL ] , & pf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t88 = pf_efOut ;
tlu2_1d_linear_linear_value ( & qf_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = qf_efOut [ 0 ] ; t2911 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & rf_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField19 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = rf_efOut
[ 0 ] ; intrm_sf_mf_356 = t2585_idx_0 ; if ( 1.0 - X [ 27ULL ] >= 0.01 ) {
t2914 = 1.0 - X [ 27ULL ] ; } else if ( 1.0 - X [ 27ULL ] >= - 0.1 ) { t2914
= pmf_exp ( ( ( 1.0 - X [ 27ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t2914
= 1.6701700790245661E-7 ; } t2913 = X [ 26ULL ] / ( t2914 == 0.0 ? 1.0E-16 :
t2914 ) * 3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value
( & sf_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = sf_efOut [ 0 ] ; t2916 = pmf_exp ( pmf_log ( X [
31ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t2916 >= 1.0 ) { t2996 = ( t2916
- 1.0 ) * 461.523 + t2913 ; U_idx_1 = t2913 / ( t2996 == 0.0 ? 1.0E-16 :
t2996 ) ; } else { U_idx_1 = 1.0 ; } t2998 = U_idx_1 * 0.01 ; t2913 = ( X [
27ULL ] - U_idx_1 ) / ( t2998 == 0.0 ? 1.0E-16 : t2998 ) ; if ( X [ 27ULL ] -
U_idx_1 <= 0.0 ) { t2913 = 0.0 ; } else if ( X [ 27ULL ] - U_idx_1 >= U_idx_1
* 0.01 ) { t2913 = X [ 27ULL ] - U_idx_1 ; } else { t2913 = ( X [ 27ULL ] -
U_idx_1 ) * ( t2913 * t2913 * 3.0 - t2913 * t2913 * t2913 * 2.0 ) ; } piece45
= piece45 * t2913 * 0.026773120849090417 / 0.001 ; t2913 = ( t2911 -
intrm_sf_mf_356 ) * piece45 ; tlu2_1d_linear_nearest_value ( & tf_efOut [
0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = tf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
uf_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = uf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
vf_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField22 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = vf_efOut [ 0 ] ; intrm_sf_mf_356 = ( ( ( 1.0 - t2656
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ) *
t2585_idx_0 + t2586_idx_0 * t2656 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ; if ( X [
243ULL ] <= 0.0 ) { zc_int220 = 0.0 ; } else { zc_int220 = X [ 243ULL ] >=
1.0 ? 1.0 : X [ 243ULL ] ; } if ( X [ 242ULL ] <= 0.0 ) { t2919 = 0.0 ; }
else { t2919 = X [ 242ULL ] >= 1.0 ? 1.0 : X [ 242ULL ] ; } t2920 = ( ( ( 1.0
- zc_int220 ) - t2919 ) * 296.802103844292 + zc_int220 * 461.523 ) + t2919 *
4124.48151675695 ; t2921 = X [ 243ULL ] * 461.523 / ( t2920 == 0.0 ? 1.0E-16
: t2920 ) ; if ( t2921 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 = t2921 >=
1.0 ? 1.0 : t2921 ; } t2921 = X [ 242ULL ] * 4124.48151675695 / ( t2920 ==
0.0 ? 1.0E-16 : t2920 ) ; if ( t2921 <= 0.0 ) { t2923 = 0.0 ; } else { t2923
= t2921 >= 1.0 ? 1.0 : t2921 ; } t2049 [ 0ULL ] = X [ 240ULL ] ;
tlu2_linear_nearest_prelookup ( & wf_efOut . mField0 [ 0ULL ] , & wf_efOut .
mField1 [ 0ULL ] , & wf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = wf_efOut ; tlu2_1d_linear_nearest_value ( & xf_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
xf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & yf_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
yf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ag_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ag_efOut [ 0 ] ; t2921 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) - t2923 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) +
t2587_idx_0 * t2923 ; tlu2_1d_linear_nearest_value ( & bg_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
bg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & cg_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
cg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & dg_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
dg_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 = ( ( ( 1.0 -
t2656 ) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ) *
t2585_idx_0 + t2586_idx_0 * t2656 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ;
tlu2_1d_linear_nearest_value ( & eg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = eg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = fg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & gg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = gg_efOut [ 0 ] ; t2656
= ( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17
) - t2923 ) * t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) +
t2587_idx_0 * t2923 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 = ( X [ 244ULL
] - X [ 247ULL ] ) / 2.0 ; tlu2_1d_linear_nearest_value ( & hg_efOut [ 0ULL ]
, & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = hg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ig_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = ig_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
jg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = jg_efOut [ 0 ] ; t2931 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) - t2923 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) +
t2587_idx_0 * t2923 ; zc_int181 = ( t2898 + t2931 ) / 2.0 * 0.32 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 : 0.0 ) * 0.01
/ ( zc_int181 == 0.0 ? 1.0E-16 : zc_int181 ) ; t2923 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ; t2926 =
t2923 > 1000.0 ? t2923 : 1000.0 ; t3007 = t2921 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ; if ( t3007 /
2.0 > 0.5 ) { t2934 = ( t2921 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ) / 2.0 ; }
else { t2934 = 0.5 ; } t3009 = pmf_log10 ( 6.9 / ( t2926 == 0.0 ? 1.0E-16 :
t2926 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2926 == 0.0 ?
1.0E-16 : t2926 ) + 0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = 1.0 / (
t3009 == 0.0 ? 1.0E-16 : t3009 ) ; t3011 = ( pmf_pow ( t2934 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 / 8.0 ) * 12.7
+ 1.0 ; t2926 = ( t2926 - 1000.0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 / 8.0 ) *
t2934 / ( t3011 == 0.0 ? 1.0E-16 : t3011 ) ; t2934 = ( t2923 - 2000.0 ) /
2000.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 =
t2934 * t2934 * 3.0 - t2934 * t2934 * t2934 * 2.0 ; if ( t2923 <= 2000.0 ) {
t2934 = 3.66 ; } else if ( t2923 >= 4000.0 ) { t2934 = t2926 ; } else { t2934
= ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ) *
3.66 + t2926 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79
; } t220 = t3007 / 2.0 ; if ( t2923 > t2934 * 10.709248339636167 / 0.32 / (
t220 == 0.0 ? 1.0E-16 : t220 ) / 30.0 ) { t3022 = ( t2921 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ) / 2.0 ;
t2926 = t2934 * 10.709248339636167 / ( t2923 == 0.0 ? 1.0E-16 : t2923 ) /
0.32 / ( t3022 == 0.0 ? 1.0E-16 : t3022 ) ; } else { t2926 = 30.0 ; } t2923 =
( X [ 32ULL ] - X [ 240ULL ] ) * ( 1.0 - pmf_exp ( - t2926 ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 * 0.32 / 0.01
* ( t3007 / 2.0 ) * ( ( t2656 + intrm_sf_mf_356 ) / 2.0 ) * t2923 ; if ( X [
229ULL ] <= 0.0 ) { t2923 = 0.0 ; } else { t2923 = X [ 229ULL ] >= 1.0 ? 1.0
: X [ 229ULL ] ; } if ( X [ 228ULL ] <= 0.0 ) { t2926 = 0.0 ; } else { t2926
= X [ 228ULL ] >= 1.0 ? 1.0 : X [ 228ULL ] ; } t2934 = ( ( ( 1.0 - t2923 ) -
t2926 ) * 296.802103844292 + t2923 * 461.523 ) + t2926 * 4124.48151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = X [ 229ULL ]
* 461.523 / ( t2934 == 0.0 ? 1.0E-16 : t2934 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 <= 0.0 ) {
t2937 = 0.0 ; } else { t2937 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 >= 1.0 ? 1.0 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = X [ 228ULL ]
* 4124.48151675695 / ( t2934 == 0.0 ? 1.0E-16 : t2934 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 <= 0.0 ) {
t2938 = 0.0 ; } else { t2938 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 >= 1.0 ? 1.0 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ; } t2049 [
0ULL ] = X [ 226ULL ] ; tlu2_linear_nearest_prelookup ( & kg_efOut . mField0
[ 0ULL ] , & kg_efOut . mField1 [ 0ULL ] , & kg_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [
0ULL ] , & t225 [ 0ULL ] ) ; t166 = kg_efOut ; tlu2_1d_linear_nearest_value (
& lg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = lg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
mg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = mg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ng_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = ng_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = ( ( ( 1.0 -
t2937 ) - t2938 ) * t2585_idx_0 + t2586_idx_0 * t2937 ) + t2587_idx_0 * t2938
; tlu2_1d_linear_nearest_value ( & og_efOut [ 0ULL ] , & t166 . mField0 [
0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = og_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & pg_efOut [ 0ULL ] , & t166 . mField0 [
0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = pg_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & qg_efOut [ 0ULL ] , & t166 . mField0 [
0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField22 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = qg_efOut [ 0
] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = ( ( (
1.0 - t2937 ) - t2938 ) * t2585_idx_0 + t2586_idx_0 * t2937 ) + t2587_idx_0 *
t2938 ; t2940 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 <= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 : 0.0 ;
tlu2_1d_linear_nearest_value ( & rg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = rg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & sg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = sg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & tg_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = tg_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 = ( ( ( 1.0 -
t2937 ) - t2938 ) * t2585_idx_0 + t2586_idx_0 * t2937 ) + t2587_idx_0 * t2938
; t3030 = ( t2898 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ) / 2.0 * 0.32
; t2937 = - t2940 * 0.01 / ( t3030 == 0.0 ? 1.0E-16 : t3030 ) ; t2938 = t2937
>= 0.0 ? t2937 : - t2937 ; t2940 = t2938 > 1000.0 ? t2938 : 1000.0 ; t3031 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ; if ( t3031 /
2.0 > 0.5 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21
= ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ) / 2.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = 0.5 ;
} t3033 = pmf_log10 ( 6.9 / ( t2940 == 0.0 ? 1.0E-16 : t2940 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2940 == 0.0 ? 1.0E-16 : t2940
) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_352 = 1.0 / ( t3033 == 0.0
? 1.0E-16 : t3033 ) ; t3035 = ( pmf_pow (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intrm_sf_mf_352 / 8.0 ) * 12.7 +
1.0 ; t2940 = ( t2940 - 1000.0 ) * ( intrm_sf_mf_352 / 8.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 / ( t3035 ==
0.0 ? 1.0E-16 : t3035 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = ( t2938 -
2000.0 ) / 2000.0 ; intrm_sf_mf_352 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 * 2.0 ; if (
t2938 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = 3.66 ; }
else if ( t2938 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = t2940 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = ( 1.0
- intrm_sf_mf_352 ) * 3.66 + t2940 * intrm_sf_mf_352 ; } t3040 = t3031 / 2.0
; if ( t2938 > Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21
* 10.709248339636167 / 0.32 / ( t3040 == 0.0 ? 1.0E-16 : t3040 ) / 30.0 ) {
t3046 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ) / 2.0 ;
t2940 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 *
10.709248339636167 / ( t2938 == 0.0 ? 1.0E-16 : t2938 ) / 0.32 / ( t3046 ==
0.0 ? 1.0E-16 : t3046 ) ; } else { t2940 = 30.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 = ( X [ 32ULL
] - X [ 226ULL ] ) * ( 1.0 - pmf_exp ( - t2940 ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 + t2937 * 0.32
/ 0.01 * ( t3031 / 2.0 ) * ( ( intrm_sf_mf_356 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ) / 2.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 = pmf_sqrt ( X
[ 244ULL ] * X [ 244ULL ] + 4.3455507383574884E-7 ) ; t2937 = pmf_sqrt ( X [
244ULL ] * X [ 244ULL ] + 4.9597684650720062E-8 ) ; t2938 = pmf_sqrt ( X [
244ULL ] * X [ 244ULL ] + 3.5023764535063275E-8 ) ; t2940 = pmf_sqrt ( X [
247ULL ] * X [ 247ULL ] + 4.3455507383574884E-7 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 = pmf_sqrt ( X
[ 247ULL ] * X [ 247ULL ] + 4.9597684650720062E-8 ) ; intrm_sf_mf_352 =
pmf_sqrt ( X [ 247ULL ] * X [ 247ULL ] + 3.5023764535063275E-8 ) ;
tlu2_1d_linear_linear_value ( & ug_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ug_efOut [ 0 ] ; t2943 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & vg_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = vg_efOut
[ 0 ] ; t2945 = X [ 254ULL ] + X [ 259ULL ] ; t2946 = ( X [ 244ULL ] + X [
247ULL ] ) - piece45 * 100000.0 ; t2947 = ( X [ 255ULL ] + X [ 260ULL ] ) -
piece45 * 100000.0 ; t2948 = ( ( ( 1.0 - intrm_sf_mf_249 ) - t2888 ) * t2943
+ t2911 * intrm_sf_mf_249 ) + t2585_idx_0 * t2888 ; t2950 = t2943 - X [ 25ULL
] * 0.296802103844292 ; t2943 = t2585_idx_0 - X [ 25ULL ] * 4.12448151675695
; t2944 = t2911 - X [ 25ULL ] * 0.461523 ; if ( X [ 30ULL ] <= 0.0 ) { t2911
= 0.0 ; } else { t2911 = X [ 30ULL ] >= 1.0 ? 1.0 : X [ 30ULL ] ; } if ( X [
29ULL ] <= 0.0 ) { t2951 = 0.0 ; } else { t2951 = X [ 29ULL ] >= 1.0 ? 1.0 :
X [ 29ULL ] ; } t2953 = ( ( ( 1.0 - t2911 ) - t2951 ) * 296.802103844292 +
t2911 * 461.523 ) + t2951 * 4124.48151675695 ; t2956 = - ( ( X [ 28ULL ] / (
X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) - X [ 263ULL ] / ( X [ 264ULL ]
== 0.0 ? 1.0E-16 : X [ 264ULL ] ) ) * X [ 247ULL ] * t2953 ) / 0.32 ; if ( X
[ 263ULL ] <= 216.59999999999997 ) { t2960 = 216.59999999999997 ; } else {
t2960 = X [ 263ULL ] >= 623.15 ? 623.15 : X [ 263ULL ] ; } t2963 = t2960 *
t2960 ; t2961 = ( ( ( 1074.1165326382554 + t2960 * - 0.22145652610641059 ) +
t2963 * 0.0003721298010901061 ) * ( ( 1.0 - t2911 ) - t2951 ) + ( (
1479.6504774710402 + t2960 * 1.2002114337050787 ) + t2963 * -
0.00038614513167845434 ) * t2911 ) + ( ( 12825.281119789837 + t2960 *
6.9647057412840034 ) + t2963 * - 0.0070524868246844051 ) * t2951 ; t3055 =
t2961 - t2953 ; t2960 = t2961 / ( t3055 == 0.0 ? 1.0E-16 : t3055 ) ; t2961 =
pmf_sqrt ( t2956 * t2956 * 9.999999999999999E-14 + fabs ( X [ 263ULL ] *
t2960 * t2953 ) * 1.0E-9 ) ; if ( X [ 237ULL ] <= 0.0 ) { t2963 = 0.0 ; }
else { t2963 = X [ 237ULL ] >= 1.0 ? 1.0 : X [ 237ULL ] ; } if ( X [ 239ULL ]
<= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 =
0.0 ; } else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95
= X [ 239ULL ] >= 1.0 ? 1.0 : X [ 239ULL ] ; } t2049 [ 0ULL ] = X [ 28ULL ] ;
tlu2_linear_nearest_prelookup ( & wg_efOut . mField0 [ 0ULL ] , & wg_efOut .
mField1 [ 0ULL ] , & wg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = wg_efOut ; tlu2_1d_linear_nearest_value ( & xg_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
xg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & yg_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
yg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ah_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ah_efOut [ 0 ] ; piece81 = ( ( ( 1.0 - t2963 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ) *
t2585_idx_0 + t2586_idx_0 * t2963 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ; t3056 = X [
264ULL ] * X [ 264ULL ] * t2960 ; t2971 = - pmf_sqrt ( fabs ( t3056 / ( t2953
== 0.0 ? 1.0E-16 : t2953 ) / ( X [ 263ULL ] == 0.0 ? 1.0E-16 : X [ 263ULL ] )
) ) * 0.32 ; if ( t2971 >= 0.0 ) { t2972 = t2971 * 100000.0 ; } else { t2972
= - t2971 * 100000.0 ; } t3060 = piece81 * 0.32 ; t2974 = t2972 * 0.01 / (
t3060 == 0.0 ? 1.0E-16 : t3060 ) ; t3062 = X [ 28ULL ] * t2953 ; t2975 = X [
33ULL ] / ( t3062 == 0.0 ? 1.0E-16 : t3062 ) ; t3064 = t2975 *
6.4000000000000011E-5 ; t2980 = t2971 * piece81 * 2.9973120849090416 / (
t3064 == 0.0 ? 1.0E-16 : t3064 ) ; t213 = t2974 >= 1.0 ? t2974 : 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = pmf_log10 (
6.9 / ( t213 == 0.0 ? 1.0E-16 : t213 ) + 0.00017169489553429715 ) * pmf_log10
( 6.9 / ( t213 == 0.0 ? 1.0E-16 : t213 ) + 0.00017169489553429715 ) * 3.24 ;
t3067 = t2975 * 0.0020480000000000003 ; t2972 = t2971 * t2972 * ( 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ) )
* 0.046833001326703774 / ( t3067 == 0.0 ? 1.0E-16 : t3067 ) ; t213 = ( t2974
- 2000.0 ) / 2000.0 ; zc_int147 = t213 * t213 * 3.0 - t213 * t213 * t213 *
2.0 ; if ( t2974 <= 2000.0 ) { t213 = t2980 * 1.0E-5 ; } else if ( t2974 >=
4000.0 ) { t213 = t2972 * 1.0E-5 ; } else { t213 = ( ( 1.0 - zc_int147 ) *
t2980 + t2972 * zc_int147 ) * 1.0E-5 ; } t2961 = - ( X [ 247ULL ] * t2961 ) /
0.32 * 0.00031622776601683789 + t213 ; t2972 = X [ 227ULL ] - X [ 33ULL ] ;
t2980 = ( X [ 28ULL ] / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) - X [
265ULL ] / ( X [ 266ULL ] == 0.0 ? 1.0E-16 : X [ 266ULL ] ) ) * X [ 198ULL ]
* t2953 / 0.32 ; if ( X [ 265ULL ] <= 216.59999999999997 ) { t213 =
216.59999999999997 ; } else { t213 = X [ 265ULL ] >= 623.15 ? 623.15 : X [
265ULL ] ; } zc_int132 = t213 * t213 ; zc_int147 = ( ( ( 1074.1165326382554 +
t213 * - 0.22145652610641059 ) + zc_int132 * 0.0003721298010901061 ) * ( (
1.0 - t2911 ) - t2951 ) + ( ( 1479.6504774710402 + t213 * 1.2002114337050787
) + zc_int132 * - 0.00038614513167845434 ) * t2911 ) + ( ( 12825.281119789837
+ t213 * 6.9647057412840034 ) + zc_int132 * - 0.0070524868246844051 ) * t2951
; t3075 = zc_int147 - t2953 ; t213 = zc_int147 / ( t3075 == 0.0 ? 1.0E-16 :
t3075 ) ; zc_int147 = pmf_sqrt ( t2980 * t2980 * 9.999999999999999E-14 + fabs
( X [ 265ULL ] * t213 * t2953 ) * 1.0E-9 ) ; t4247 = X [ 266ULL ] * X [
266ULL ] * t213 ; zc_int132 = - pmf_sqrt ( fabs ( t4247 / ( t2953 == 0.0 ?
1.0E-16 : t2953 ) / ( X [ 265ULL ] == 0.0 ? 1.0E-16 : X [ 265ULL ] ) ) ) *
0.32 ; if ( zc_int132 >= 0.0 ) { t2987 = zc_int132 * 100000.0 ; } else {
t2987 = - zc_int132 * 100000.0 ; } t2989 = t2987 * 0.01 / ( t3060 == 0.0 ?
1.0E-16 : t3060 ) ; U_idx_1 = zc_int132 * piece81 * 2.9973120849090416 / (
t3064 == 0.0 ? 1.0E-16 : t3064 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = t2989 >= 1.0
? t2989 : 1.0 ; t3083 = pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) +
0.00017169489553429715 ) * 3.24 ; t2987 = zc_int132 * t2987 * ( 1.0 / ( t3083
== 0.0 ? 1.0E-16 : t3083 ) ) * 0.046833001326703774 / ( t3067 == 0.0 ?
1.0E-16 : t3067 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = ( t2989 -
2000.0 ) / 2000.0 ; intrm_sf_mf_454 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 * 2.0 ; if (
t2989 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = U_idx_1 *
1.0E-5 ; } else if ( t2989 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = t2987 *
1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = ( ( 1.0 -
intrm_sf_mf_454 ) * U_idx_1 + t2987 * intrm_sf_mf_454 ) * 1.0E-5 ; }
zc_int147 = X [ 198ULL ] * zc_int147 / 0.32 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ; t2987 = X [
176ULL ] - X [ 33ULL ] ; t2049 [ 0ULL ] = X [ 28ULL ] ;
tlu2_linear_linear_prelookup ( & bh_efOut . mField0 [ 0ULL ] , & bh_efOut .
mField1 [ 0ULL ] , & bh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t178 = bh_efOut ; tlu2_1d_linear_linear_value ( & ch_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ch_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = t2585_idx_0
; tlu2_1d_linear_linear_value ( & dh_efOut [ 0ULL ] , & t178 . mField0 [ 0ULL
] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField19
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = dh_efOut [ 0 ] ;
intrm_sf_mf_454 = t2585_idx_0 ; if ( 1.0 - X [ 30ULL ] >= 0.01 ) { t2995 =
1.0 - X [ 30ULL ] ; } else if ( 1.0 - X [ 30ULL ] >= - 0.1 ) { t2995 =
pmf_exp ( ( ( 1.0 - X [ 30ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t2995 =
1.6701700790245661E-7 ; } t2994 = X [ 29ULL ] / ( t2995 == 0.0 ? 1.0E-16 :
t2995 ) * 3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value
( & eh_efOut [ 0ULL ] , & t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = eh_efOut [ 0 ] ; t2996 = pmf_exp ( pmf_log ( X [
33ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t2996 >= 1.0 ) { t3090 = ( t2996
- 1.0 ) * 461.523 + t2994 ; t2997 = t2994 / ( t3090 == 0.0 ? 1.0E-16 : t3090
) ; } else { t2997 = 1.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 = t2997 *
0.01 ; t2994 = ( X [ 30ULL ] - t2997 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 ) ;
if ( X [ 30ULL ] - t2997 <= 0.0 ) { t2994 = 0.0 ; } else if ( X [ 30ULL ] -
t2997 >= t2997 * 0.01 ) { t2994 = X [ 30ULL ] - t2997 ; } else { t2994 = ( X
[ 30ULL ] - t2997 ) * ( t2994 * t2994 * 3.0 - t2994 * t2994 * t2994 * 2.0 ) ;
} t2975 = t2975 * t2994 * 0.026773120849090417 / 0.001 ; t2994 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 -
intrm_sf_mf_454 ) * t2975 ; tlu2_1d_linear_nearest_value ( & fh_efOut [ 0ULL
] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = fh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
gh_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = gh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
hh_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField22 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = hh_efOut [ 0 ] ; intrm_sf_mf_454 = ( ( ( 1.0 - t2963
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ) *
t2585_idx_0 + t2586_idx_0 * t2963 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ; t2997 = ( X
[ 32ULL ] - X [ 28ULL ] ) * ( intrm_sf_mf_454 * 10.709248339636167 / 0.01 ) ;
tlu2_1d_linear_nearest_value ( & ih_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ih_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jh_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = jh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & kh_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = kh_efOut [ 0 ] ; t2998
= ( ( ( 1.0 - t2963 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ) *
t2585_idx_0 + t2586_idx_0 * t2963 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ; t2963 = ( -
X [ 247ULL ] - X [ 198ULL ] ) / 2.0 ; t3098 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 + piece81 ) /
2.0 * 0.32 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 =
( t2963 >= 0.0 ? t2963 : 0.0 ) * 0.01 / ( t3098 == 0.0 ? 1.0E-16 : t3098 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ; t2999 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 : 1000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 + t2998 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 / 2.0 > 0.5 )
{ U_idx_1 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79
+ t2998 ) / 2.0 ; } else { U_idx_1 = 0.5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 = pmf_log10 (
6.9 / ( t2999 == 0.0 ? 1.0E-16 : t2999 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t2999 == 0.0 ? 1.0E-16 : t2999 ) + 0.00017169489553429715
) * 3.24 ; t3001 = 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ) ;
t3103 = ( pmf_pow ( U_idx_1 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
t3001 / 8.0 ) * 12.7 + 1.0 ; t2999 = ( t2999 - 1000.0 ) * ( t3001 / 8.0 ) *
U_idx_1 / ( t3103 == 0.0 ? 1.0E-16 : t3103 ) ; U_idx_1 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 - 2000.0 ) /
2000.0 ; t3001 = U_idx_1 * U_idx_1 * 3.0 - U_idx_1 * U_idx_1 * U_idx_1 * 2.0
; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 <=
2000.0 ) { U_idx_1 = 3.66 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 >= 4000.0 ) {
U_idx_1 = t2999 ; } else { U_idx_1 = ( 1.0 - t3001 ) * 3.66 + t2999 * t3001 ;
} Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 / 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 > U_idx_1 *
10.709248339636167 / 0.32 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 ) /
30.0 ) { t3114 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 + t2998 ) /
2.0 ; t2999 = U_idx_1 * 10.709248339636167 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ) /
0.32 / ( t3114 == 0.0 ? 1.0E-16 : t3114 ) ; } else { t2999 = 30.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = ( X [ 32ULL
] - X [ 226ULL ] ) * ( 1.0 - pmf_exp ( - t2999 ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 * 0.32 / 0.01
* ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 / 2.0 ) *
( ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 +
intrm_sf_mf_454 ) / 2.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ; t3120 = (
t2866 + piece81 ) / 2.0 * 0.32 ; t2866 = - ( t2963 <= 0.0 ? t2963 : 0.0 ) *
0.01 / ( t3120 == 0.0 ? 1.0E-16 : t3120 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = t2866 >= 0.0
? t2866 : - t2866 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 : 1000.0 ;
t3121 = t2857 + t2998 ; if ( t3121 / 2.0 > 0.5 ) { t2963 = ( t2857 + t2998 )
/ 2.0 ; } else { t2963 = 0.5 ; } t3123 = pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ) +
0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 = 1.0 / (
t3123 == 0.0 ? 1.0E-16 : t3123 ) ; t3125 = ( pmf_pow ( t2963 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 / 8.0 ) * 12.7
+ 1.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 - 1000.0 ) *
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 / 8.0 ) *
t2963 / ( t3125 == 0.0 ? 1.0E-16 : t3125 ) ; t2963 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 - 2000.0 ) /
2000.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 =
t2963 * t2963 * 3.0 - t2963 * t2963 * t2963 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 <= 2000.0 ) {
t2963 = 3.66 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 >= 4000.0 ) {
t2963 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ; }
else { t2963 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ) * 3.66 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 ; } zc_int349
= t3121 / 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 > t2963 *
10.709248339636167 / 0.32 / ( zc_int349 == 0.0 ? 1.0E-16 : zc_int349 ) / 30.0
) { zc_int348 = ( t2857 + t2998 ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = t2963 *
10.709248339636167 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ) /
0.32 / ( zc_int348 == 0.0 ? 1.0E-16 : zc_int348 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = 30.0 ; }
t2857 = ( X [ 32ULL ] - X [ 175ULL ] ) * ( 1.0 - pmf_exp ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 ) ) ; t2857 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 + t2866 * 0.32
/ 0.01 * ( t3121 / 2.0 ) * ( ( t2815 + intrm_sf_mf_454 ) / 2.0 ) * t2857 ;
t2866 = pmf_sqrt ( X [ 198ULL ] * X [ 198ULL ] + 4.3455507383574884E-7 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 = pmf_sqrt ( X
[ 198ULL ] * X [ 198ULL ] + 4.9597684650720062E-8 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 = pmf_sqrt ( X
[ 198ULL ] * X [ 198ULL ] + 3.5023764535063275E-8 ) ;
tlu2_1d_linear_linear_value ( & lh_efOut [ 0ULL ] , & t178 . mField0 [ 0ULL ]
, & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = lh_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = t2585_idx_0
; tlu2_1d_linear_linear_value ( & mh_efOut [ 0ULL ] , & t178 . mField0 [ 0ULL
] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = mh_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 = ( - X [
259ULL ] + X [ 210ULL ] ) + X [ 276ULL ] ; intrm_sf_mf_454 = ( ( ( - X [
247ULL ] + X [ 198ULL ] ) + X [ 276ULL ] ) + X [ 277ULL ] ) - t2975 *
100000.0 ; t2998 = ( ( - X [ 260ULL ] + X [ 212ULL ] ) + X [ 277ULL ] ) -
t2975 * 100000.0 ; t2999 = ( ( ( 1.0 - t2911 ) - t2951 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 * t2911 ) +
t2585_idx_0 * t2951 ; t3001 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 - X [ 28ULL ]
* 0.296802103844292 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 = t2585_idx_0
- X [ 28ULL ] * 4.12448151675695 ; t2963 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 - X [ 28ULL ]
* 0.461523 ; if ( X [ 36ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 = X [ 36ULL
] >= 1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL ] <= 0.0 ) { t3002 = 0.0 ; }
else { t3002 = X [ 35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t3003 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) - t3002 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 * 461.523 ) +
t3002 * 4124.48151675695 ; t3004 = ( X [ 34ULL ] / ( X [ 37ULL ] == 0.0 ?
1.0E-16 : X [ 37ULL ] ) - X [ 289ULL ] / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X
[ 290ULL ] ) ) * X [ 288ULL ] * t3003 / 0.0019634954084936209 ; if ( X [
289ULL ] <= 216.59999999999997 ) { zc_int182 = 216.59999999999997 ; } else {
zc_int182 = X [ 289ULL ] >= 623.15 ? 623.15 : X [ 289ULL ] ; } t3007 =
zc_int182 * zc_int182 ; zc_int181 = ( ( ( 1074.1165326382554 + zc_int182 * -
0.22145652610641059 ) + t3007 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) - t3002 ) +
( ( 1479.6504774710402 + zc_int182 * 1.2002114337050787 ) + t3007 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) + ( (
12825.281119789837 + zc_int182 * 6.9647057412840034 ) + t3007 * -
0.0070524868246844051 ) * t3002 ; t3145 = zc_int181 - t3003 ; zc_int182 =
zc_int181 / ( t3145 == 0.0 ? 1.0E-16 : t3145 ) ; zc_int181 = pmf_sqrt ( t3004
* t3004 * 9.999999999999999E-14 + fabs ( X [ 289ULL ] * zc_int182 * t3003 ) *
1.0E-9 ) ; if ( X [ 285ULL ] <= 0.0 ) { t3007 = 0.0 ; } else { t3007 = X [
285ULL ] >= 1.0 ? 1.0 : X [ 285ULL ] ; } if ( X [ 284ULL ] <= 0.0 ) { t3008 =
0.0 ; } else { t3008 = X [ 284ULL ] >= 1.0 ? 1.0 : X [ 284ULL ] ; } t2049 [
0ULL ] = X [ 34ULL ] ; tlu2_linear_nearest_prelookup ( & nh_efOut . mField0 [
0ULL ] , & nh_efOut . mField1 [ 0ULL ] , & nh_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t77 = nh_efOut ; tlu2_1d_linear_nearest_value ( &
oh_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ] , & t77 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = oh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ph_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ] , & t77 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = ph_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
qh_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ] , & t77 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = qh_efOut [ 0 ] ; t3009 = ( ( ( 1.0 - t3007 ) - t3008 ) *
t2585_idx_0 + t2586_idx_0 * t3007 ) + t2587_idx_0 * t3008 ; t4289 = X [
290ULL ] * X [ 290ULL ] * zc_int182 ; zc_int192 = - pmf_sqrt ( fabs ( t4289 /
( t3003 == 0.0 ? 1.0E-16 : t3003 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16 : X [
289ULL ] ) ) ) * 0.0019634954084936209 ; if ( zc_int192 >= 0.0 ) { t3011 =
zc_int192 * 100000.0 ; } else { t3011 = - zc_int192 * 100000.0 ; } t4426 =
t3009 * 0.0019634954084936209 ; t3012 = t3011 * 0.05 / ( t4426 == 0.0 ?
1.0E-16 : t4426 ) ; t3152 = X [ 34ULL ] * t3003 ; t3013 = X [ 37ULL ] / (
t3152 == 0.0 ? 1.0E-16 : t3152 ) ; t4440 = t3013 * 9.8174770424681068E-6 ;
zc_int186 = zc_int192 * t3009 * 11.2 / ( t4440 == 0.0 ? 1.0E-16 : t4440 ) ;
t220 = t3012 >= 1.0 ? t3012 : 1.0 ; t3155 = pmf_log10 ( 6.9 / ( t220 == 0.0 ?
1.0E-16 : t220 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t220 == 0.0
? 1.0E-16 : t220 ) + 2.8767404433520813E-5 ) * 3.24 ; t4298 = t3013 *
3.855314219175531E-7 ; t3011 = zc_int192 * t3011 * ( 1.0 / ( t3155 == 0.0 ?
1.0E-16 : t3155 ) ) * 0.175 / ( t4298 == 0.0 ? 1.0E-16 : t4298 ) ; t220 = (
t3012 - 2000.0 ) / 2000.0 ; zc_int209 = t220 * t220 * 3.0 - t220 * t220 *
t220 * 2.0 ; if ( t3012 <= 2000.0 ) { t220 = zc_int186 * 1.0E-5 ; } else if (
t3012 >= 4000.0 ) { t220 = t3011 * 1.0E-5 ; } else { t220 = ( ( 1.0 -
zc_int209 ) * zc_int186 + t3011 * zc_int209 ) * 1.0E-5 ; } zc_int181 = X [
288ULL ] * zc_int181 / 0.0019634954084936209 * 0.00031622776601683789 + t220
; t3011 = X [ 38ULL ] - X [ 37ULL ] ; zc_int186 = - ( ( X [ 34ULL ] / ( X [
37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) - X [ 291ULL ] / ( X [ 292ULL ] ==
0.0 ? 1.0E-16 : X [ 292ULL ] ) ) * X [ 244ULL ] * t3003 ) /
0.0019634954084936209 ; if ( X [ 291ULL ] <= 216.59999999999997 ) { t220 =
216.59999999999997 ; } else { t220 = X [ 291ULL ] >= 623.15 ? 623.15 : X [
291ULL ] ; } t2671 = t220 * t220 ; zc_int209 = ( ( ( 1074.1165326382554 +
t220 * - 0.22145652610641059 ) + t2671 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) - t3002 ) +
( ( 1479.6504774710402 + t220 * 1.2002114337050787 ) + t2671 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) + ( (
12825.281119789837 + t220 * 6.9647057412840034 ) + t2671 * -
0.0070524868246844051 ) * t3002 ; U_idx_1 = zc_int209 - t3003 ; t220 =
zc_int209 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; zc_int209 = pmf_sqrt (
zc_int186 * zc_int186 * 9.999999999999999E-14 + fabs ( X [ 291ULL ] * t220 *
t3003 ) * 1.0E-9 ) ; t4303 = X [ 292ULL ] * X [ 292ULL ] * t220 ; t2671 = -
pmf_sqrt ( fabs ( t4303 / ( t3003 == 0.0 ? 1.0E-16 : t3003 ) / ( X [ 291ULL ]
== 0.0 ? 1.0E-16 : X [ 291ULL ] ) ) ) * 0.0019634954084936209 ; if ( t2671 >=
0.0 ) { t222 = t2671 * 100000.0 ; } else { t222 = - t2671 * 100000.0 ; }
zc_int324 = t222 * 0.05 / ( t4426 == 0.0 ? 1.0E-16 : t4426 ) ; t3021 = t2671
* t3009 * 11.2 / ( t4440 == 0.0 ? 1.0E-16 : t4440 ) ; t3022 = zc_int324 >=
1.0 ? zc_int324 : 1.0 ; intrm_sf_mf_1229 = pmf_log10 ( 6.9 / ( t3022 == 0.0 ?
1.0E-16 : t3022 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3022 ==
0.0 ? 1.0E-16 : t3022 ) + 2.8767404433520813E-5 ) * 3.24 ; t222 = t2671 *
t222 * ( 1.0 / ( intrm_sf_mf_1229 == 0.0 ? 1.0E-16 : intrm_sf_mf_1229 ) ) *
0.175 / ( t4298 == 0.0 ? 1.0E-16 : t4298 ) ; t3022 = ( zc_int324 - 2000.0 ) /
2000.0 ; intrm_sf_mf_636 = t3022 * t3022 * 3.0 - t3022 * t3022 * t3022 * 2.0
; if ( zc_int324 <= 2000.0 ) { t3022 = t3021 * 1.0E-5 ; } else if ( zc_int324
>= 4000.0 ) { t3022 = t222 * 1.0E-5 ; } else { t3022 = ( ( 1.0 -
intrm_sf_mf_636 ) * t3021 + t222 * intrm_sf_mf_636 ) * 1.0E-5 ; } zc_int209 =
- ( X [ 244ULL ] * zc_int209 ) / 0.0019634954084936209 *
0.00031622776601683789 + t3022 ; t222 = X [ 241ULL ] - X [ 37ULL ] ; t2049 [
0ULL ] = X [ 34ULL ] ; tlu2_linear_linear_prelookup ( & rh_efOut . mField0 [
0ULL ] , & rh_efOut . mField1 [ 0ULL ] , & rh_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = rh_efOut ; tlu2_1d_linear_linear_value ( &
sh_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = sh_efOut [ 0 ] ; t3021 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & th_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField19 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = th_efOut [ 0 ] ; t3022 =
t2585_idx_0 ; if ( 1.0 - X [ 36ULL ] >= 0.01 ) { t3025 = 1.0 - X [ 36ULL ] ;
} else if ( 1.0 - X [ 36ULL ] >= - 0.1 ) { t3025 = pmf_exp ( ( ( 1.0 - X [
36ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t3025 = 1.6701700790245661E-7 ;
} intrm_sf_mf_636 = X [ 35ULL ] / ( t3025 == 0.0 ? 1.0E-16 : t3025 ) *
3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
uh_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = uh_efOut [ 0 ] ; t3026 = pmf_exp ( pmf_log ( X [
37ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3026 >= 1.0 ) { zc_int366 = (
t3026 - 1.0 ) * 461.523 + intrm_sf_mf_636 ; t3027 = intrm_sf_mf_636 / (
zc_int366 == 0.0 ? 1.0E-16 : zc_int366 ) ; } else { t3027 = 1.0 ; } t3182 =
t3027 * 0.01 ; intrm_sf_mf_636 = ( X [ 36ULL ] - t3027 ) / ( t3182 == 0.0 ?
1.0E-16 : t3182 ) ; if ( X [ 36ULL ] - t3027 <= 0.0 ) { intrm_sf_mf_636 = 0.0
; } else if ( X [ 36ULL ] - t3027 >= t3027 * 0.01 ) { intrm_sf_mf_636 = X [
36ULL ] - t3027 ; } else { intrm_sf_mf_636 = ( X [ 36ULL ] - t3027 ) * (
intrm_sf_mf_636 * intrm_sf_mf_636 * 3.0 - intrm_sf_mf_636 * intrm_sf_mf_636 *
intrm_sf_mf_636 * 2.0 ) ; } t3013 = t3013 * intrm_sf_mf_636 *
0.00049087385212340522 / 0.001 ; intrm_sf_mf_636 = ( t3021 - t3022 ) * t3013
; tlu2_1d_linear_nearest_value ( & vh_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL
] , & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = vh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & wh_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = wh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & xh_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = xh_efOut [ 0 ] ; t3022 =
( ( ( 1.0 - t3007 ) - t3008 ) * t2585_idx_0 + t2586_idx_0 * t3007 ) +
t2587_idx_0 * t3008 ; t3027 = ( X [ 287ULL ] - X [ 34ULL ] ) * ( t3022 *
0.039269908169872414 / 0.05 ) ; if ( X [ 280ULL ] <= 0.0 ) { t3028 = 0.0 ; }
else { t3028 = X [ 280ULL ] >= 1.0 ? 1.0 : X [ 280ULL ] ; } if ( X [ 279ULL ]
<= 0.0 ) { t3029 = 0.0 ; } else { t3029 = X [ 279ULL ] >= 1.0 ? 1.0 : X [
279ULL ] ; } t3030 = ( ( ( 1.0 - t3028 ) - t3029 ) * 296.802103844292 + t3028
* 461.523 ) + t3029 * 4124.48151675695 ; t3031 = X [ 280ULL ] * 461.523 / (
t3030 == 0.0 ? 1.0E-16 : t3030 ) ; if ( t3031 <= 0.0 ) { t3032 = 0.0 ; } else
{ t3032 = t3031 >= 1.0 ? 1.0 : t3031 ; } t3031 = X [ 279ULL ] *
4124.48151675695 / ( t3030 == 0.0 ? 1.0E-16 : t3030 ) ; if ( t3031 <= 0.0 ) {
t3033 = 0.0 ; } else { t3033 = t3031 >= 1.0 ? 1.0 : t3031 ; } t2049 [ 0ULL ]
= X [ 278ULL ] ; tlu2_linear_nearest_prelookup ( & yh_efOut . mField0 [ 0ULL
] , & yh_efOut . mField1 [ 0ULL ] , & yh_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t170 = yh_efOut ; tlu2_1d_linear_nearest_value ( &
ai_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = ai_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
bi_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = bi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ci_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = ci_efOut [ 0 ] ; t3031 = ( ( ( 1.0 - t3032 ) - t3033
) * t2585_idx_0 + t2586_idx_0 * t3032 ) + t2587_idx_0 * t3033 ;
tlu2_1d_linear_nearest_value ( & di_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = di_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ei_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = ei_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fi_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = fi_efOut [ 0 ] ; t3034 =
( ( ( 1.0 - t3007 ) - t3008 ) * t2585_idx_0 + t2586_idx_0 * t3007 ) +
t2587_idx_0 * t3008 ; tlu2_1d_linear_nearest_value ( & gi_efOut [ 0ULL ] , &
t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
gi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & hi_efOut [ 0ULL ] , & t170
. mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
hi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ii_efOut [ 0ULL ] , & t170
. mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField22 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ii_efOut [ 0 ] ; t3007 = ( ( ( 1.0 - t3032 ) - t3033 ) * t2585_idx_0 +
t2586_idx_0 * t3032 ) + t2587_idx_0 * t3033 ; t3008 = ( X [ 288ULL ] - ( - X
[ 244ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & ji_efOut [ 0ULL ] , &
t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ji_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ki_efOut [ 0ULL ] , & t170
. mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ki_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & li_efOut [ 0ULL ] , & t170
. mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
li_efOut [ 0 ] ; t3190 = ( t3009 + ( ( ( ( 1.0 - t3032 ) - t3033 ) *
t2585_idx_0 + t2586_idx_0 * t3032 ) + t2587_idx_0 * t3033 ) ) / 2.0 *
0.0019634954084936209 ; t3032 = ( t3008 >= 0.0 ? t3008 : 0.0 ) * 0.05 / (
t3190 == 0.0 ? 1.0E-16 : t3190 ) ; t3033 = t3032 >= 0.0 ? t3032 : - t3032 ;
t3035 = t3033 > 1000.0 ? t3033 : 1000.0 ; t3191 = t3031 + t3034 ; if ( t3191
/ 2.0 > 0.5 ) { t3036 = ( t3031 + t3034 ) / 2.0 ; } else { t3036 = 0.5 ; }
t3193 = pmf_log10 ( 6.9 / ( t3035 == 0.0 ? 1.0E-16 : t3035 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3035 == 0.0 ? 1.0E-16 : t3035
) + 2.8767404433520813E-5 ) * 3.24 ; intrm_sf_mf_661 = 1.0 / ( t3193 == 0.0 ?
1.0E-16 : t3193 ) ; t3195 = ( pmf_pow ( t3036 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( intrm_sf_mf_661 / 8.0 ) * 12.7 + 1.0 ; t3035 = ( t3035 - 1000.0
) * ( intrm_sf_mf_661 / 8.0 ) * t3036 / ( t3195 == 0.0 ? 1.0E-16 : t3195 ) ;
t3036 = ( t3033 - 2000.0 ) / 2000.0 ; intrm_sf_mf_661 = t3036 * t3036 * 3.0 -
t3036 * t3036 * t3036 * 2.0 ; if ( t3033 <= 2000.0 ) { t3036 = 3.66 ; } else
if ( t3033 >= 4000.0 ) { t3036 = t3035 ; } else { t3036 = ( 1.0 -
intrm_sf_mf_661 ) * 3.66 + t3035 * intrm_sf_mf_661 ; } zc_int368 = t3191 /
2.0 ; if ( t3033 > t3036 * 0.039269908169872414 / 0.0019634954084936209 / (
zc_int368 == 0.0 ? 1.0E-16 : zc_int368 ) / 30.0 ) { t3206 = ( t3031 + t3034 )
/ 2.0 ; t3035 = t3036 * 0.039269908169872414 / ( t3033 == 0.0 ? 1.0E-16 :
t3033 ) / 0.0019634954084936209 / ( t3206 == 0.0 ? 1.0E-16 : t3206 ) ; } else
{ t3035 = 30.0 ; } t3031 = ( X [ 287ULL ] - X [ 278ULL ] ) * ( 1.0 - pmf_exp
( - t3035 ) ) ; t3007 = t3032 * 0.0019634954084936209 / 0.05 * ( t3191 / 2.0
) * ( ( t3007 + t3022 ) / 2.0 ) * t3031 ; t3212 = ( t2931 + t3009 ) / 2.0 *
0.0019634954084936209 ; t2931 = - ( t3008 <= 0.0 ? t3008 : 0.0 ) * 0.05 / (
t3212 == 0.0 ? 1.0E-16 : t3212 ) ; t3008 = t2931 >= 0.0 ? t2931 : - t2931 ;
t3031 = t3008 > 1000.0 ? t3008 : 1000.0 ; piece237 = t2921 + t3034 ; if (
piece237 / 2.0 > 0.5 ) { t3032 = ( t2921 + t3034 ) / 2.0 ; } else { t3032 =
0.5 ; } piece354 = pmf_log10 ( 6.9 / ( t3031 == 0.0 ? 1.0E-16 : t3031 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3031 == 0.0 ? 1.0E-16 : t3031
) + 2.8767404433520813E-5 ) * 3.24 ; t3033 = 1.0 / ( piece354 == 0.0 ?
1.0E-16 : piece354 ) ; t3217 = ( pmf_pow ( t3032 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t3033 / 8.0 ) * 12.7 + 1.0 ; t3031 = ( t3031 - 1000.0 ) *
( t3033 / 8.0 ) * t3032 / ( t3217 == 0.0 ? 1.0E-16 : t3217 ) ; t3032 = (
t3008 - 2000.0 ) / 2000.0 ; t3033 = t3032 * t3032 * 3.0 - t3032 * t3032 *
t3032 * 2.0 ; if ( t3008 <= 2000.0 ) { t3032 = 3.66 ; } else if ( t3008 >=
4000.0 ) { t3032 = t3031 ; } else { t3032 = ( 1.0 - t3033 ) * 3.66 + t3031 *
t3033 ; } t3222 = piece237 / 2.0 ; if ( t3008 > t3032 * 0.039269908169872414
/ 0.0019634954084936209 / ( t3222 == 0.0 ? 1.0E-16 : t3222 ) / 30.0 ) { t3228
= ( t2921 + t3034 ) / 2.0 ; t3031 = t3032 * 0.039269908169872414 / ( t3008 ==
0.0 ? 1.0E-16 : t3008 ) / 0.0019634954084936209 / ( t3228 == 0.0 ? 1.0E-16 :
t3228 ) ; } else { t3031 = 30.0 ; } t2921 = ( X [ 287ULL ] - X [ 240ULL ] ) *
( 1.0 - pmf_exp ( - t3031 ) ) ; t2921 = t3007 + t2931 * 0.0019634954084936209
/ 0.05 * ( piece237 / 2.0 ) * ( ( t2656 + t3022 ) / 2.0 ) * t2921 ; t2656 =
pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] + 5.0900279888093953E-12 ) ; t2931 =
pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] + 5.8094731428156895E-13 ) ; t3007 =
pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 ) ; t3008 =
pmf_sqrt ( X [ 244ULL ] * X [ 244ULL ] + 5.0900279888093953E-12 ) ; t3022 =
pmf_sqrt ( X [ 244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 ) ; t3031 =
pmf_sqrt ( X [ 244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 ) ;
tlu2_1d_linear_linear_value ( & mi_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = mi_efOut [ 0 ] ; t3032 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & ni_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ni_efOut [ 0 ] ; t3034 = - X [ 254ULL ] + X [ 295ULL ] ; t3035 = ( ( - X [
244ULL ] + X [ 288ULL ] ) + U_idx_5 ) - t3013 * 100000.0 ; t3036 = ( ( - X [
255ULL ] + X [ 296ULL ] ) + U_idx_5 ) - t3013 * 100000.0 ; intrm_sf_mf_661 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 )
- t3002 ) * t3032 + t3021 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) +
t2585_idx_0 * t3002 ; t3040 = t3032 - X [ 34ULL ] * 0.296802103844292 ; t3032
= t2585_idx_0 - X [ 34ULL ] * 4.12448151675695 ; t3033 = t3021 - X [ 34ULL ]
* 0.461523 ; t3021 = pmf_sqrt ( X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) ; t3041 = pmf_sqrt ( X [ 313ULL ] * X [ 313ULL ] +
5.2285258285341208E-12 ) ; t3042 = pmf_sqrt ( X [ 313ULL ] * X [ 313ULL ] +
3.6921614138577959E-12 ) ; if ( X [ 318ULL ] <= 0.0 ) { t3043 = 0.0 ; } else
{ t3043 = X [ 318ULL ] >= 1.0 ? 1.0 : X [ 318ULL ] ; } if ( X [ 319ULL ] <=
0.0 ) { t3044 = 0.0 ; } else { t3044 = X [ 319ULL ] >= 1.0 ? 1.0 : X [ 319ULL
] ; } t3045 = ( ( ( 1.0 - t3043 ) - t3044 ) * 296.802103844292 + t3043 *
461.523 ) + t3044 * 259.836612622973 ; if ( 1.0 - X [ 318ULL ] >= 0.01 ) {
t3046 = 1.0 - X [ 318ULL ] ; } else if ( 1.0 - X [ 318ULL ] >= - 0.1 ) {
t3046 = pmf_exp ( ( ( 1.0 - X [ 318ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else
{ t3046 = 1.6701700790245661E-7 ; } t3047 = ( X [ 322ULL ] *
0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X [
41ULL ] <= 0.0 ) { t3049 = 0.0 ; } else { t3049 = X [ 41ULL ] >= 1.0 ? 1.0 :
X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) { t3050 = 0.0 ; } else { t3050 = X
[ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; } t3054 = ( ( ( 1.0 - t3049 ) - t3050
) * 296.802103844292 + t3049 * 461.523 ) + t3050 * 259.836612622973 ; t3055 =
( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) - X [ 326ULL ]
/ ( X [ 327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) ) * X [ 325ULL ] * t3054 /
0.0019634954084936209 ; if ( X [ 326ULL ] <= 216.59999999999997 ) { zc_int305
= 216.59999999999997 ; } else { zc_int305 = X [ 326ULL ] >= 623.15 ? 623.15 :
X [ 326ULL ] ; } U_idx_3 = zc_int305 * zc_int305 ; t3059 = ( ( (
1074.1165326382554 + zc_int305 * - 0.22145652610641059 ) + U_idx_3 *
0.0003721298010901061 ) * ( ( 1.0 - t3049 ) - t3050 ) + ( (
1479.6504774710402 + zc_int305 * 1.2002114337050787 ) + U_idx_3 * -
0.00038614513167845434 ) * t3049 ) + ( ( 900.639412248396 + zc_int305 * -
0.044484923911441127 ) + U_idx_3 * 0.00036936011832051582 ) * t3050 ;
intrm_sf_mf_1220 = t3059 - t3054 ; zc_int305 = t3059 / ( intrm_sf_mf_1220 ==
0.0 ? 1.0E-16 : intrm_sf_mf_1220 ) ; t3059 = pmf_sqrt ( t3055 * t3055 *
9.999999999999999E-14 + fabs ( X [ 326ULL ] * zc_int305 * t3054 ) * 1.0E-9 )
; if ( X [ 328ULL ] <= 0.0 ) { U_idx_3 = 0.0 ; } else { U_idx_3 = X [ 328ULL
] >= 1.0 ? 1.0 : X [ 328ULL ] ; } if ( X [ 329ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = X [
329ULL ] >= 1.0 ? 1.0 : X [ 329ULL ] ; } t2049 [ 0ULL ] = X [ 39ULL ] ;
tlu2_linear_nearest_prelookup ( & oi_efOut . mField0 [ 0ULL ] , & oi_efOut .
mField1 [ 0ULL ] , & oi_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = oi_efOut ; tlu2_1d_linear_nearest_value ( & pi_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
pi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & qi_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = qi_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & ri_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ri_efOut [ 0
] ; t3066 = ( ( ( 1.0 - U_idx_3 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ) *
t2585_idx_0 + t2586_idx_0 * U_idx_3 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ; t4332 = X [
327ULL ] * X [ 327ULL ] * zc_int305 ; t3068 = - pmf_sqrt ( fabs ( t4332 / (
t3054 == 0.0 ? 1.0E-16 : t3054 ) / ( X [ 326ULL ] == 0.0 ? 1.0E-16 : X [
326ULL ] ) ) ) * 0.0019634954084936209 ; if ( t3068 >= 0.0 ) { t3069 = t3068
* 100000.0 ; } else { t3069 = - t3068 * 100000.0 ; } t4363 = t3066 *
0.0019634954084936209 ; t3074 = t3069 * 0.05 / ( t4363 == 0.0 ? 1.0E-16 :
t4363 ) ; t3245 = X [ 39ULL ] * t3054 ; t3075 = X [ 40ULL ] / ( t3245 == 0.0
? 1.0E-16 : t3245 ) ; t4451 = t3075 * 9.8174770424681068E-6 ; t3077 = t3068 *
t3066 * 35.2 / ( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; t3079 = t3074 >= 1.0 ?
t3074 : 1.0 ; t3248 = pmf_log10 ( 6.9 / ( t3079 == 0.0 ? 1.0E-16 : t3079 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3079 == 0.0 ? 1.0E-16 : t3079
) + 2.8767404433520813E-5 ) * 3.24 ; t4367 = t3075 * 3.855314219175531E-7 ;
t3069 = t3068 * t3069 * ( 1.0 / ( t3248 == 0.0 ? 1.0E-16 : t3248 ) ) * 0.55 /
( t4367 == 0.0 ? 1.0E-16 : t4367 ) ; t3079 = ( t3074 - 2000.0 ) / 2000.0 ;
zc_int339 = t3079 * t3079 * 3.0 - t3079 * t3079 * t3079 * 2.0 ; if ( t3074 <=
2000.0 ) { t3079 = t3077 * 1.0E-5 ; } else if ( t3074 >= 4000.0 ) { t3079 =
t3069 * 1.0E-5 ; } else { t3079 = ( ( 1.0 - zc_int339 ) * t3077 + t3069 *
zc_int339 ) * 1.0E-5 ; } t3059 = X [ 325ULL ] * t3059 / 0.0019634954084936209
* 0.00031622776601683789 + t3079 ; t3069 = X [ 303ULL ] - X [ 40ULL ] ; t3077
= - ( ( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) - X [
330ULL ] / ( X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] ) ) * X [ 313ULL ]
* t3054 ) / 0.0019634954084936209 ; if ( X [ 330ULL ] <= 216.59999999999997 )
{ t3079 = 216.59999999999997 ; } else { t3079 = X [ 330ULL ] >= 623.15 ?
623.15 : X [ 330ULL ] ; } t3083 = t3079 * t3079 ; zc_int339 = ( ( (
1074.1165326382554 + t3079 * - 0.22145652610641059 ) + t3083 *
0.0003721298010901061 ) * ( ( 1.0 - t3049 ) - t3050 ) + ( (
1479.6504774710402 + t3079 * 1.2002114337050787 ) + t3083 * -
0.00038614513167845434 ) * t3049 ) + ( ( 900.639412248396 + t3079 * -
0.044484923911441127 ) + t3083 * 0.00036936011832051582 ) * t3050 ; t3258 =
zc_int339 - t3054 ; t3079 = zc_int339 / ( t3258 == 0.0 ? 1.0E-16 : t3258 ) ;
zc_int339 = pmf_sqrt ( t3077 * t3077 * 9.999999999999999E-14 + fabs ( X [
330ULL ] * t3079 * t3054 ) * 1.0E-9 ) ; t4394 = X [ 331ULL ] * X [ 331ULL ] *
t3079 ; t3083 = - pmf_sqrt ( fabs ( t4394 / ( t3054 == 0.0 ? 1.0E-16 : t3054
) / ( X [ 330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) *
0.0019634954084936209 ; if ( t3083 >= 0.0 ) { t3084 = t3083 * 100000.0 ; }
else { t3084 = - t3083 * 100000.0 ; } t3086 = t3084 * 0.05 / ( t4363 == 0.0 ?
1.0E-16 : t4363 ) ; t3087 = t3083 * t3066 * 35.2 / ( t4451 == 0.0 ? 1.0E-16 :
t4451 ) ; t3088 = t3086 >= 1.0 ? t3086 : 1.0 ; t3266 = pmf_log10 ( 6.9 / (
t3088 == 0.0 ? 1.0E-16 : t3088 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9
/ ( t3088 == 0.0 ? 1.0E-16 : t3088 ) + 2.8767404433520813E-5 ) * 3.24 ; t3084
= t3083 * t3084 * ( 1.0 / ( t3266 == 0.0 ? 1.0E-16 : t3266 ) ) * 0.55 / (
t4367 == 0.0 ? 1.0E-16 : t4367 ) ; t3088 = ( t3086 - 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = t3088 *
t3088 * 3.0 - t3088 * t3088 * t3088 * 2.0 ; if ( t3086 <= 2000.0 ) { t3088 =
t3087 * 1.0E-5 ; } else if ( t3086 >= 4000.0 ) { t3088 = t3084 * 1.0E-5 ; }
else { t3088 = ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 ) * t3087 +
t3084 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 ) *
1.0E-5 ; } zc_int339 = - ( X [ 313ULL ] * zc_int339 ) / 0.0019634954084936209
* 0.00031622776601683789 + t3088 ; t3084 = t3047 - X [ 40ULL ] ; t2049 [ 0ULL
] = X [ 39ULL ] ; tlu2_linear_linear_prelookup ( & si_efOut . mField0 [ 0ULL
] , & si_efOut . mField1 [ 0ULL ] , & si_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t153 = si_efOut ; tlu2_1d_linear_linear_value ( &
ti_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = ti_efOut [ 0 ] ; t3087 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & ui_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField19 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ui_efOut [ 0 ] ; t3088 =
t2585_idx_0 ; if ( 1.0 - X [ 41ULL ] >= 0.01 ) { t3090 = 1.0 - X [ 41ULL ] ;
} else if ( 1.0 - X [ 41ULL ] >= - 0.1 ) { t3090 = pmf_exp ( ( ( 1.0 - X [
41ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t3090 = 1.6701700790245661E-7 ;
} Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = X [ 42ULL
] / ( t3090 == 0.0 ? 1.0E-16 : t3090 ) * - 36.965491221318985 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & vi_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
vi_efOut [ 0 ] ; t3091 = pmf_exp ( pmf_log ( X [ 40ULL ] * 100000.0 ) -
t2585_idx_0 ) ; if ( t3091 >= 1.0 ) { t4821 = ( t3091 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 / ( t4821 ==
0.0 ? 1.0E-16 : t4821 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 = 1.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 * 0.01 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = ( X [ 41ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ) ;
if ( X [ 41ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = 0.0 ; } else
if ( X [ 41ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = X [ 41ULL ]
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = ( X [ 41ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 * 2.0 ) ; }
t3075 = t3075 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 *
0.0019634954084936209 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = ( t3087 -
t3088 ) * t3075 ; tlu2_1d_linear_nearest_value ( & wi_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
wi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & xi_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = xi_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & yi_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField29 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = yi_efOut [ 0
] ; t3088 = ( ( ( 1.0 - U_idx_3 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ) *
t2585_idx_0 + t2586_idx_0 * U_idx_3 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 = ( X [
306ULL ] - X [ 39ULL ] ) * ( t3088 * 0.15707963267948966 / 0.05 ) ; if ( X [
305ULL ] <= 0.0 ) { t3093 = 0.0 ; } else { t3093 = X [ 305ULL ] >= 1.0 ? 1.0
: X [ 305ULL ] ; } if ( X [ 304ULL ] <= 0.0 ) { intrm_sf_mf_1119 = 0.0 ; }
else { intrm_sf_mf_1119 = X [ 304ULL ] >= 1.0 ? 1.0 : X [ 304ULL ] ; } t3095
= ( ( ( 1.0 - t3093 ) - intrm_sf_mf_1119 ) * 296.802103844292 + t3093 *
461.523 ) + intrm_sf_mf_1119 * 259.836612622973 ; t3096 = X [ 305ULL ] *
461.523 / ( t3095 == 0.0 ? 1.0E-16 : t3095 ) ; if ( t3096 <= 0.0 ) { t3097 =
0.0 ; } else { t3097 = t3096 >= 1.0 ? 1.0 : t3096 ; } t3096 = X [ 304ULL ] *
259.836612622973 / ( t3095 == 0.0 ? 1.0E-16 : t3095 ) ; if ( t3096 <= 0.0 ) {
t3098 = 0.0 ; } else { t3098 = t3096 >= 1.0 ? 1.0 : t3096 ; } t2049 [ 0ULL ]
= X [ 302ULL ] ; tlu2_linear_nearest_prelookup ( & aj_efOut . mField0 [ 0ULL
] , & aj_efOut . mField1 [ 0ULL ] , & aj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = aj_efOut ; tlu2_1d_linear_nearest_value ( &
bj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = bj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
cj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = cj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
dj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField30 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = dj_efOut [ 0 ] ; t3096 = ( ( ( 1.0 - t3097 ) - t3098
) * t2585_idx_0 + t2586_idx_0 * t3097 ) + t2587_idx_0 * t3098 ;
tlu2_1d_linear_nearest_value ( & ej_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ej_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fj_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = fj_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & gj_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = gj_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 = ( ( ( 1.0 -
U_idx_3 ) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 )
* t2585_idx_0 + t2586_idx_0 * U_idx_3 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ;
tlu2_1d_linear_nearest_value ( & hj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = hj_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ij_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = ij_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField29
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = jj_efOut [ 0 ] ;
U_idx_3 = ( ( ( 1.0 - t3097 ) - t3098 ) * t2585_idx_0 + t2586_idx_0 * t3097 )
+ t2587_idx_0 * t3098 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = ( X [
325ULL ] - ( - X [ 313ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( &
kj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = kj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
lj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = lj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
mj_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = mj_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 = ( ( ( 1.0 -
t3097 ) - t3098 ) * t2585_idx_0 + t2586_idx_0 * t3097 ) + t2587_idx_0 * t3098
; t3283 = ( t3066 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ) / 2.0 *
0.0019634954084936209 ; t3097 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 : 0.0 ) *
0.05 / ( t3283 == 0.0 ? 1.0E-16 : t3283 ) ; t3098 = t3097 >= 0.0 ? t3097 : -
t3097 ; t3100 = t3098 > 1000.0 ? t3098 : 1000.0 ; t3284 = t3096 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 ; if ( t3284
/ 2.0 > 0.5 ) { t3102 = ( t3096 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 ) / 2.0 ; }
else { t3102 = 0.5 ; } t3286 = pmf_log10 ( 6.9 / ( t3100 == 0.0 ? 1.0E-16 :
t3100 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3100 == 0.0 ?
1.0E-16 : t3100 ) + 2.8767404433520813E-5 ) * 3.24 ; t3103 = 1.0 / ( t3286 ==
0.0 ? 1.0E-16 : t3286 ) ; t3288 = ( pmf_pow ( t3102 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t3103 / 8.0 ) * 12.7 + 1.0 ; t3100 = ( t3100 - 1000.0 ) *
( t3103 / 8.0 ) * t3102 / ( t3288 == 0.0 ? 1.0E-16 : t3288 ) ; t3102 = (
t3098 - 2000.0 ) / 2000.0 ; t3103 = t3102 * t3102 * 3.0 - t3102 * t3102 *
t3102 * 2.0 ; if ( t3098 <= 2000.0 ) { t3102 = 3.66 ; } else if ( t3098 >=
4000.0 ) { t3102 = t3100 ; } else { t3102 = ( 1.0 - t3103 ) * 3.66 + t3100 *
t3103 ; } t3293 = t3284 / 2.0 ; if ( t3098 > t3102 * 0.15707963267948966 /
0.0019634954084936209 / ( t3293 == 0.0 ? 1.0E-16 : t3293 ) / 30.0 ) { t3299 =
( t3096 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 ) /
2.0 ; t3100 = t3102 * 0.15707963267948966 / ( t3098 == 0.0 ? 1.0E-16 : t3098
) / 0.0019634954084936209 / ( t3299 == 0.0 ? 1.0E-16 : t3299 ) ; } else {
t3100 = 30.0 ; } t3098 = ( X [ 306ULL ] - X [ 302ULL ] ) * ( 1.0 - pmf_exp (
- t3100 ) ) ; t3097 = t3097 * 0.0019634954084936209 / 0.05 * ( t3284 / 2.0 )
* ( ( U_idx_3 + t3088 ) / 2.0 ) * t3098 ; if ( X [ 324ULL ] <= 0.0 ) { t3098
= 0.0 ; } else { t3098 = X [ 324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X
[ 323ULL ] <= 0.0 ) { t3100 = 0.0 ; } else { t3100 = X [ 323ULL ] >= 1.0 ?
1.0 : X [ 323ULL ] ; } t3102 = ( ( ( 1.0 - t3098 ) - t3100 ) *
296.802103844292 + t3098 * 461.523 ) + t3100 * 259.836612622973 ; t3103 = X [
324ULL ] * 461.523 / ( t3102 == 0.0 ? 1.0E-16 : t3102 ) ; if ( t3103 <= 0.0 )
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 =
t3103 >= 1.0 ? 1.0 : t3103 ; } t3103 = X [ 323ULL ] * 259.836612622973 / (
t3102 == 0.0 ? 1.0E-16 : t3102 ) ; if ( t3103 <= 0.0 ) { t3105 = 0.0 ; } else
{ t3105 = t3103 >= 1.0 ? 1.0 : t3103 ; } t2049 [ 0ULL ] = X [ 321ULL ] ;
tlu2_linear_nearest_prelookup ( & nj_efOut . mField0 [ 0ULL ] , & nj_efOut .
mField1 [ 0ULL ] , & nj_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t178 = nj_efOut ; tlu2_1d_linear_nearest_value ( & oj_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
oj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & pj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
pj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & qj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
qj_efOut [ 0 ] ; t3103 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) - t3105 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) +
t2587_idx_0 * t3105 ; tlu2_1d_linear_nearest_value ( & rj_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
rj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & sj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
sj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & tj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField29 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
tj_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) - t3105 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) +
t2587_idx_0 * t3105 ; tlu2_1d_linear_nearest_value ( & uj_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
uj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & vj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
vj_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & wj_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
wj_efOut [ 0 ] ; t3307 = ( t3066 + ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) - t3105 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) +
t2587_idx_0 * t3105 ) ) / 2.0 * 0.0019634954084936209 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 <= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 : 0.0 ) *
0.05 / ( t3307 == 0.0 ? 1.0E-16 : t3307 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ; t3105 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 : 1000.0 ;
t3308 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 +
t3103 ; if ( t3308 / 2.0 > 0.5 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 + t3103 ) /
2.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = 0.5 ; }
intrm_sf_mf_1359 = pmf_log10 ( 6.9 / ( t3105 == 0.0 ? 1.0E-16 : t3105 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3105 == 0.0 ? 1.0E-16 : t3105
) + 2.8767404433520813E-5 ) * 3.24 ; t3109 = 1.0 / ( intrm_sf_mf_1359 == 0.0
? 1.0E-16 : intrm_sf_mf_1359 ) ; t3312 = ( pmf_pow (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t3109 / 8.0 ) * 12.7 + 1.0 ; t3105
= ( t3105 - 1000.0 ) * ( t3109 / 8.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 / ( t3312 ==
0.0 ? 1.0E-16 : t3312 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 - 2000.0 ) /
2000.0 ; t3109 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = 3.66 ; }
else if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 >=
4000.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 =
t3105 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = ( 1.0 -
t3109 ) * 3.66 + t3105 * t3109 ; } t3317 = t3308 / 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 *
0.15707963267948966 / 0.0019634954084936209 / ( t3317 == 0.0 ? 1.0E-16 :
t3317 ) / 30.0 ) { intrm_sf_mf_1296 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 + t3103 ) /
2.0 ; t3105 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47
* 0.15707963267948966 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) /
0.0019634954084936209 / ( intrm_sf_mf_1296 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1296 ) ; } else { t3105 = 30.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 = ( X [
306ULL ] - X [ 321ULL ] ) * ( 1.0 - pmf_exp ( - t3105 ) ) ; t3088 = t3097 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 *
0.0019634954084936209 / 0.05 * ( t3308 / 2.0 ) * ( ( t3088 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 ) / 2.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 = pmf_sqrt (
X [ 325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 ) ; t3097 = pmf_sqrt ( X
[ 325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 = pmf_sqrt (
X [ 325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 ) ; t3103 = pmf_sqrt ( X
[ 313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 = pmf_sqrt (
X [ 313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 ) ; t3105 = pmf_sqrt ( X
[ 313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 ) ;
tlu2_1d_linear_linear_value ( & xj_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xj_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 = t2585_idx_0
; tlu2_1d_linear_linear_value ( & yj_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = yj_efOut [ 0 ] ; t3109
= - X [ 314ULL ] + X [ 336ULL ] ; t3110 = ( - X [ 313ULL ] + X [ 325ULL ] ) -
t3075 * 100000.0 ; t3111 = ( - X [ 315ULL ] + X [ 337ULL ] ) - t3075 *
100000.0 ; t3112 = ( ( ( 1.0 - t3049 ) - t3050 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 + t3087 *
t3049 ) + t2585_idx_0 * t3050 ; t3114 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 - X [ 39ULL ]
* 0.296802103844292 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 = t2585_idx_0
- X [ 39ULL ] * 0.25983661262297303 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 = t3087 - X [
39ULL ] * 0.461523 ; if ( X [ 322ULL ] * 0.0019634954084936209 <=
1.9634954084936209E-11 ) { t3087 = 1.9634954084936209E-11 ; } else if ( X [
322ULL ] * 0.0019634954084936209 >= 0.0012566370614359179 ) { t3087 =
0.0012566370614359179 ; } else { t3087 = X [ 322ULL ] * 0.0019634954084936209
; } zc_int307 = t3087 / 0.0019634954084936209 ; if ( X [ 345ULL ] <= 0.0 ) {
intrm_sf_mf_866 = 0.0 ; } else { intrm_sf_mf_866 = X [ 345ULL ] >= 1.0 ? 1.0
: X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0 ) { t3118 = 0.0 ; } else { t3118
= X [ 346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ; } t3119 = ( ( ( 1.0 -
intrm_sf_mf_866 ) - t3118 ) * 296.802103844292 + intrm_sf_mf_866 * 461.523 )
+ t3118 * 259.836612622973 ; t3328 = X [ 343ULL ] * t3119 ; t3120 = X [
344ULL ] / ( t3328 == 0.0 ? 1.0E-16 : t3328 ) ; t3121 = X [ 344ULL ] / (
t3047 == 0.0 ? 1.0E-16 : t3047 ) * ( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ; intrm_sf_mf_867 = X [ 344ULL ] / 1.01325 * ( X [
348ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; if ( X [
313ULL ] > 0.0 ) { t3123 = ( zc_int307 + 1.0 ) * ( 1.0 - zc_int307 * t3121 )
* ( X [ 313ULL ] / 0.64 / ( t3087 == 0.0 ? 1.0E-16 : t3087 ) * ( X [ 313ULL ]
/ 0.64 / ( t3087 == 0.0 ? 1.0E-16 : t3087 ) ) / 2.0 / ( t3120 == 0.0 ?
1.0E-16 : t3120 ) ) * 9.9999999999999991E-11 ; } else if ( X [ 313ULL ] < 0.0
) { t3123 = ( zc_int307 + 1.0 ) * ( 1.0 - zc_int307 * intrm_sf_mf_867 ) * ( X
[ 313ULL ] / 0.64 / ( t3087 == 0.0 ? 1.0E-16 : t3087 ) * ( X [ 313ULL ] /
0.64 / ( t3087 == 0.0 ? 1.0E-16 : t3087 ) ) / 2.0 / ( t3120 == 0.0 ? 1.0E-16
: t3120 ) ) * 9.9999999999999991E-11 ; } else { t3123 = 0.0 ; } t3125 = (
t3047 + 1.01325 ) / 2.0 * 0.0010000000000000009 ; t3124 = ( 1.0 - zc_int307 )
* ( 1.0 - zc_int307 ) ; intrm_sf_mf_869 = t3125 * t3124 ; t3127 = ( zc_int307
+ 1.0 ) * ( 1.0 - zc_int307 * t3121 ) - ( 1.0 - zc_int307 * intrm_sf_mf_867 )
* zc_int307 * 2.0 ; zc_int357 = ( t3047 - 1.01325 ) * ( t3127 >= t3124 ?
t3127 : t3124 ) ; t3127 = ( t3047 - 1.01325 ) / ( t3125 == 0.0 ? 1.0E-16 :
t3125 ) ; zc_int349 = t3127 * t3127 * 3.0 - t3127 * t3127 * t3127 * 2.0 ; if
( t3047 - 1.01325 <= 0.0 ) { t3127 = intrm_sf_mf_869 ; } else if ( t3047 -
1.01325 >= t3125 ) { t3127 = zc_int357 ; } else { t3127 = ( 1.0 - zc_int349 )
* intrm_sf_mf_869 + zc_int357 * zc_int349 ; } zc_int357 = ( zc_int307 + 1.0 )
* ( 1.0 - zc_int307 * intrm_sf_mf_867 ) - ( 1.0 - zc_int307 * t3121 ) *
zc_int307 * 2.0 ; zc_int307 = ( 1.01325 - t3047 ) * ( zc_int357 >= t3124 ?
zc_int357 : t3124 ) ; t3121 = ( 1.01325 - t3047 ) / ( t3125 == 0.0 ? 1.0E-16
: t3125 ) ; intrm_sf_mf_867 = t3121 * t3121 * 3.0 - t3121 * t3121 * t3121 *
2.0 ; if ( 1.01325 - t3047 <= 0.0 ) { t3121 = intrm_sf_mf_869 ; } else if (
1.01325 - t3047 >= t3125 ) { t3121 = zc_int307 ; } else { t3121 = ( 1.0 -
intrm_sf_mf_867 ) * intrm_sf_mf_869 + zc_int307 * intrm_sf_mf_867 ; } if (
t3047 > 1.01325 ) { zc_int307 = t3127 ; } else { zc_int307 = t3047 < 1.01325
? t3121 : intrm_sf_mf_869 ; } if ( X [ 343ULL ] <= 216.59999999999997 ) {
t3121 = 216.59999999999997 ; } else { t3121 = X [ 343ULL ] >= 623.15 ? 623.15
: X [ 343ULL ] ; } t2680 = t3121 * t3121 ; intrm_sf_mf_867 = ( ( (
1074.1165326382554 + t3121 * - 0.22145652610641059 ) + t2680 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_866 ) - t3118 ) + ( (
1479.6504774710402 + t3121 * 1.2002114337050787 ) + t2680 * -
0.00038614513167845434 ) * intrm_sf_mf_866 ) + ( ( 900.639412248396 + t3121 *
- 0.044484923911441127 ) + t2680 * 0.00036936011832051582 ) * t3118 ; t3350 =
intrm_sf_mf_867 - t3119 ; t4405 = X [ 344ULL ] * X [ 344ULL ] * (
intrm_sf_mf_867 / ( t3350 == 0.0 ? 1.0E-16 : t3350 ) ) ; t3121 = pmf_sqrt (
fabs ( t4405 / ( t3119 == 0.0 ? 1.0E-16 : t3119 ) / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ) * t3087 * 0.64 ; t3354 = t3120 * 2.0 ; t3120 = (
t3047 - 1.01325 ) * pmf_sqrt ( fabs ( t3354 / ( zc_int307 == 0.0 ? 1.0E-16 :
zc_int307 ) ) ) * t3087 * 0.64 ; if ( X [ 45ULL ] <= 0.0 ) { intrm_sf_mf_867
= 0.0 ; } else { intrm_sf_mf_867 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; }
if ( X [ 44ULL ] <= 0.0 ) { t3124 = 0.0 ; } else { t3124 = X [ 44ULL ] >= 1.0
? 1.0 : X [ 44ULL ] ; } intrm_sf_mf_869 = ( ( ( 1.0 - intrm_sf_mf_867 ) -
t3124 ) * 296.802103844292 + intrm_sf_mf_867 * 461.523 ) + t3124 *
259.836612622973 ; t3127 = ( X [ 43ULL ] / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X
[ 49ULL ] ) - X [ 369ULL ] / ( X [ 370ULL ] == 0.0 ? 1.0E-16 : X [ 370ULL ] )
) * X [ 368ULL ] * intrm_sf_mf_869 / 0.32 ; if ( X [ 369ULL ] <=
216.59999999999997 ) { zc_int357 = 216.59999999999997 ; } else { zc_int357 =
X [ 369ULL ] >= 623.15 ? 623.15 : X [ 369ULL ] ; } t3132 = zc_int357 *
zc_int357 ; zc_int349 = ( ( ( 1074.1165326382554 + zc_int357 * -
0.22145652610641059 ) + t3132 * 0.0003721298010901061 ) * ( ( 1.0 -
intrm_sf_mf_867 ) - t3124 ) + ( ( 1479.6504774710402 + zc_int357 *
1.2002114337050787 ) + t3132 * - 0.00038614513167845434 ) * intrm_sf_mf_867 )
+ ( ( 900.639412248396 + zc_int357 * - 0.044484923911441127 ) + t3132 *
0.00036936011832051582 ) * t3124 ; t3360 = zc_int349 - intrm_sf_mf_869 ;
zc_int357 = zc_int349 / ( t3360 == 0.0 ? 1.0E-16 : t3360 ) ; zc_int349 =
pmf_sqrt ( t3127 * t3127 * 9.999999999999999E-14 + fabs ( X [ 369ULL ] *
zc_int357 * intrm_sf_mf_869 ) * 1.0E-9 ) ; if ( X [ 356ULL ] <= 0.0 ) { t2680
= 0.0 ; } else { t2680 = X [ 356ULL ] >= 1.0 ? 1.0 : X [ 356ULL ] ; } if ( X
[ 358ULL ] <= 0.0 ) { t3132 = 0.0 ; } else { t3132 = X [ 358ULL ] >= 1.0 ?
1.0 : X [ 358ULL ] ; } t2049 [ 0ULL ] = X [ 43ULL ] ;
tlu2_linear_nearest_prelookup ( & ak_efOut . mField0 [ 0ULL ] , & ak_efOut .
mField1 [ 0ULL ] , & ak_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = ak_efOut ; tlu2_1d_linear_nearest_value ( & bk_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
bk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ck_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ck_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & dk_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
dk_efOut [ 0 ] ; t3133 = ( ( ( 1.0 - t2680 ) - t3132 ) * t2585_idx_0 +
t2586_idx_0 * t2680 ) + t2587_idx_0 * t3132 ; t3361 = X [ 370ULL ] * X [
370ULL ] * zc_int357 ; t3134 = - pmf_sqrt ( fabs ( t3361 / ( intrm_sf_mf_869
== 0.0 ? 1.0E-16 : intrm_sf_mf_869 ) / ( X [ 369ULL ] == 0.0 ? 1.0E-16 : X [
369ULL ] ) ) ) * 0.32 ; if ( t3134 >= 0.0 ) { t3135 = t3134 * 100000.0 ; }
else { t3135 = - t3134 * 100000.0 ; } t3365 = t3133 * 0.32 ; zc_int348 =
t3135 * 0.01 / ( t3365 == 0.0 ? 1.0E-16 : t3365 ) ; t3367 = X [ 43ULL ] *
intrm_sf_mf_869 ; t3137 = X [ 49ULL ] / ( t3367 == 0.0 ? 1.0E-16 : t3367 ) ;
t3369 = t3137 * 6.4000000000000011E-5 ; t3139 = t3134 * t3133 *
2.9973120849090416 / ( t3369 == 0.0 ? 1.0E-16 : t3369 ) ; t3140 = zc_int348
>= 1.0 ? zc_int348 : 1.0 ; t3370 = pmf_log10 ( 6.9 / ( t3140 == 0.0 ? 1.0E-16
: t3140 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3140 == 0.0 ?
1.0E-16 : t3140 ) + 0.00017169489553429715 ) * 3.24 ; t3372 = t3137 *
0.0020480000000000003 ; t3135 = t3134 * t3135 * ( 1.0 / ( t3370 == 0.0 ?
1.0E-16 : t3370 ) ) * 0.046833001326703774 / ( t3372 == 0.0 ? 1.0E-16 : t3372
) ; t3140 = ( zc_int348 - 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = t3140 * t3140
* 3.0 - t3140 * t3140 * t3140 * 2.0 ; if ( zc_int348 <= 2000.0 ) { t3140 =
t3139 * 1.0E-5 ; } else if ( zc_int348 >= 4000.0 ) { t3140 = t3135 * 1.0E-5 ;
} else { t3140 = ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 ) * t3139 +
t3135 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 ) *
1.0E-5 ; } zc_int349 = X [ 368ULL ] * zc_int349 / 0.32 *
0.00031622776601683789 + t3140 ; t3135 = X [ 365ULL ] - X [ 49ULL ] ; t3139 =
( X [ 43ULL ] / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) - X [ 372ULL ]
/ ( X [ 373ULL ] == 0.0 ? 1.0E-16 : X [ 373ULL ] ) ) * X [ 371ULL ] *
intrm_sf_mf_869 / 0.32 ; if ( X [ 372ULL ] <= 216.59999999999997 ) { t3140 =
216.59999999999997 ; } else { t3140 = X [ 372ULL ] >= 623.15 ? 623.15 : X [
372ULL ] ; } t3145 = t3140 * t3140 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = ( ( (
1074.1165326382554 + t3140 * - 0.22145652610641059 ) + t3145 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_867 ) - t3124 ) + ( (
1479.6504774710402 + t3140 * 1.2002114337050787 ) + t3145 * -
0.00038614513167845434 ) * intrm_sf_mf_867 ) + ( ( 900.639412248396 + t3140 *
- 0.044484923911441127 ) + t3145 * 0.00036936011832051582 ) * t3124 ;
intrm_sf_mf_1748 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 -
intrm_sf_mf_869 ; t3140 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 / (
intrm_sf_mf_1748 == 0.0 ? 1.0E-16 : intrm_sf_mf_1748 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = pmf_sqrt (
t3139 * t3139 * 9.999999999999999E-14 + fabs ( X [ 372ULL ] * t3140 *
intrm_sf_mf_869 ) * 1.0E-9 ) ; t3381 = X [ 373ULL ] * X [ 373ULL ] * t3140 ;
t3145 = - pmf_sqrt ( fabs ( t3381 / ( intrm_sf_mf_869 == 0.0 ? 1.0E-16 :
intrm_sf_mf_869 ) / ( X [ 372ULL ] == 0.0 ? 1.0E-16 : X [ 372ULL ] ) ) ) *
0.32 ; if ( t3145 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 = t3145 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 = - t3145 *
100000.0 ; } t3149 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 * 0.01 / (
t3365 == 0.0 ? 1.0E-16 : t3365 ) ; U_idx_1 = t3145 * t3133 *
2.9973120849090416 / ( t3369 == 0.0 ? 1.0E-16 : t3369 ) ; t3155 = t3149 >=
1.0 ? t3149 : 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 = pmf_log10 (
6.9 / ( t3155 == 0.0 ? 1.0E-16 : t3155 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t3155 == 0.0 ? 1.0E-16 : t3155 ) + 0.00017169489553429715
) * 3.24 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 =
t3145 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 * ( 1.0
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 ) )
* 0.046833001326703774 / ( t3372 == 0.0 ? 1.0E-16 : t3372 ) ; t3155 = ( t3149
- 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 = t3155 *
t3155 * 3.0 - t3155 * t3155 * t3155 * 2.0 ; if ( t3149 <= 2000.0 ) { t3155 =
U_idx_1 * 1.0E-5 ; } else if ( t3149 >= 4000.0 ) { t3155 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 * 1.0E-5 ; }
else { t3155 = ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 ) * U_idx_1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = X [ 371ULL ]
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 / 0.32 *
0.00031622776601683789 + t3155 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 = X [ 351ULL ]
- X [ 49ULL ] ; t2049 [ 0ULL ] = X [ 43ULL ] ; tlu2_linear_linear_prelookup (
& ek_efOut . mField0 [ 0ULL ] , & ek_efOut . mField1 [ 0ULL ] , & ek_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t187 = ek_efOut ;
tlu2_1d_linear_linear_value ( & fk_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ]
, & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = fk_efOut [ 0 ] ; t3155 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & gk_efOut [ 0ULL ] , & t187 .
mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField19 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
gk_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 = t2585_idx_0
; if ( 1.0 - X [ 45ULL ] >= 0.01 ) { t3159 = 1.0 - X [ 45ULL ] ; } else if (
1.0 - X [ 45ULL ] >= - 0.1 ) { t3159 = pmf_exp ( ( ( 1.0 - X [ 45ULL ] ) -
0.01 ) / 0.01 ) * 0.01 ; } else { t3159 = 1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = X [ 44ULL ] /
( t3159 == 0.0 ? 1.0E-16 : t3159 ) * - 36.965491221318985 + 296.802103844292
; tlu2_1d_linear_linear_value ( & hk_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL
] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = hk_efOut [ 0 ] ; t3164
= pmf_exp ( pmf_log ( X [ 49ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3164
>= 1.0 ) { t3395 = ( t3164 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 ; U_idx_1 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 / ( t3395 ==
0.0 ? 1.0E-16 : t3395 ) ; } else { U_idx_1 = 1.0 ; } t3397 = U_idx_1 * 0.01 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = ( X [ 45ULL ]
- U_idx_1 ) / ( t3397 == 0.0 ? 1.0E-16 : t3397 ) ; if ( X [ 45ULL ] - U_idx_1
<= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 =
0.0 ; } else if ( X [ 45ULL ] - U_idx_1 >= U_idx_1 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = X [ 45ULL ] -
U_idx_1 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = ( X [ 45ULL ]
- U_idx_1 ) * ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 * 2.0 ) ; }
t3137 = t3137 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8
* 0.026773120849090417 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = ( t3155 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 ) * t3137 ;
tlu2_1d_linear_nearest_value ( & ik_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ik_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jk_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = jk_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & kk_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField29
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = kk_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 = ( ( ( 1.0 -
t2680 ) - t3132 ) * t2585_idx_0 + t2586_idx_0 * t2680 ) + t2587_idx_0 * t3132
; if ( X [ 367ULL ] <= 0.0 ) { intrm_sf_mf_1254 = 0.0 ; } else {
intrm_sf_mf_1254 = X [ 367ULL ] >= 1.0 ? 1.0 : X [ 367ULL ] ; } if ( X [
366ULL ] <= 0.0 ) { intrm_sf_mf_1257 = 0.0 ; } else { intrm_sf_mf_1257 = X [
366ULL ] >= 1.0 ? 1.0 : X [ 366ULL ] ; } zc_int363 = ( ( ( 1.0 -
intrm_sf_mf_1254 ) - intrm_sf_mf_1257 ) * 296.802103844292 + intrm_sf_mf_1254
* 461.523 ) + intrm_sf_mf_1257 * 259.836612622973 ; intrm_sf_mf_1229 = X [
367ULL ] * 461.523 / ( zc_int363 == 0.0 ? 1.0E-16 : zc_int363 ) ; if (
intrm_sf_mf_1229 <= 0.0 ) { t3174 = 0.0 ; } else { t3174 = intrm_sf_mf_1229
>= 1.0 ? 1.0 : intrm_sf_mf_1229 ; } intrm_sf_mf_1229 = X [ 366ULL ] *
259.836612622973 / ( zc_int363 == 0.0 ? 1.0E-16 : zc_int363 ) ; if (
intrm_sf_mf_1229 <= 0.0 ) { t3176 = 0.0 ; } else { t3176 = intrm_sf_mf_1229
>= 1.0 ? 1.0 : intrm_sf_mf_1229 ; } t2049 [ 0ULL ] = X [ 364ULL ] ;
tlu2_linear_nearest_prelookup ( & lk_efOut . mField0 [ 0ULL ] , & lk_efOut .
mField1 [ 0ULL ] , & lk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = lk_efOut ; tlu2_1d_linear_nearest_value ( & mk_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
mk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & nk_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
nk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ok_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ok_efOut [ 0 ] ; intrm_sf_mf_1229 = ( ( ( 1.0 - t3174 ) - t3176 ) *
t2585_idx_0 + t2586_idx_0 * t3174 ) + t2587_idx_0 * t3176 ;
tlu2_1d_linear_nearest_value ( & pk_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = pk_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & qk_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = qk_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & rk_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = rk_efOut [ 0 ] ; t3177
= ( ( ( 1.0 - t2680 ) - t3132 ) * t2585_idx_0 + t2586_idx_0 * t2680 ) +
t2587_idx_0 * t3132 ; tlu2_1d_linear_nearest_value ( & sk_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
sk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & tk_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
tk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & uk_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField29 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
uk_efOut [ 0 ] ; t2680 = ( ( ( 1.0 - t3174 ) - t3176 ) * t2585_idx_0 +
t2586_idx_0 * t3174 ) + t2587_idx_0 * t3176 ; t3132 = ( X [ 368ULL ] - X [
371ULL ] ) / 2.0 ; tlu2_1d_linear_nearest_value ( & vk_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
vk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & wk_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
wk_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & xk_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
xk_efOut [ 0 ] ; t3179 = ( ( ( 1.0 - t3174 ) - t3176 ) * t2585_idx_0 +
t2586_idx_0 * t3174 ) + t2587_idx_0 * t3176 ; t3405 = ( t3133 + t3179 ) / 2.0
* 0.32 ; t3174 = ( t3132 >= 0.0 ? t3132 : 0.0 ) * 0.01 / ( t3405 == 0.0 ?
1.0E-16 : t3405 ) ; t3176 = t3174 >= 0.0 ? t3174 : - t3174 ; zc_int365 =
t3176 > 1000.0 ? t3176 : 1000.0 ; t3406 = intrm_sf_mf_1229 + t3177 ; if (
t3406 / 2.0 > 0.5 ) { zc_int366 = ( intrm_sf_mf_1229 + t3177 ) / 2.0 ; } else
{ zc_int366 = 0.5 ; } t3408 = pmf_log10 ( 6.9 / ( zc_int365 == 0.0 ? 1.0E-16
: zc_int365 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( zc_int365 ==
0.0 ? 1.0E-16 : zc_int365 ) + 0.00017169489553429715 ) * 3.24 ; t3181 = 1.0 /
( t3408 == 0.0 ? 1.0E-16 : t3408 ) ; U_idx_1 = ( pmf_pow ( zc_int366 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t3181 / 8.0 ) * 12.7 + 1.0 ;
zc_int365 = ( zc_int365 - 1000.0 ) * ( t3181 / 8.0 ) * zc_int366 / ( U_idx_1
== 0.0 ? 1.0E-16 : U_idx_1 ) ; zc_int366 = ( t3176 - 2000.0 ) / 2000.0 ;
t3181 = zc_int366 * zc_int366 * 3.0 - zc_int366 * zc_int366 * zc_int366 * 2.0
; if ( t3176 <= 2000.0 ) { zc_int366 = 3.66 ; } else if ( t3176 >= 4000.0 ) {
zc_int366 = zc_int365 ; } else { zc_int366 = ( 1.0 - t3181 ) * 3.66 +
zc_int365 * t3181 ; } U_idx_1 = t3406 / 2.0 ; if ( t3176 > zc_int366 *
10.709248339636167 / 0.32 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) / 30.0 ) {
t4581 = ( intrm_sf_mf_1229 + t3177 ) / 2.0 ; zc_int365 = zc_int366 *
10.709248339636167 / ( t3176 == 0.0 ? 1.0E-16 : t3176 ) / 0.32 / ( t4581 ==
0.0 ? 1.0E-16 : t4581 ) ; } else { zc_int365 = 30.0 ; } t3176 = ( X [ 32ULL ]
- X [ 364ULL ] ) * ( 1.0 - pmf_exp ( - zc_int365 ) ) ; t3174 = t3174 * 0.32 /
0.01 * ( t3406 / 2.0 ) * ( ( t2680 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 ) / 2.0 ) *
t3176 ; if ( X [ 353ULL ] <= 0.0 ) { t3176 = 0.0 ; } else { t3176 = X [
353ULL ] >= 1.0 ? 1.0 : X [ 353ULL ] ; } if ( X [ 352ULL ] <= 0.0 ) {
zc_int365 = 0.0 ; } else { zc_int365 = X [ 352ULL ] >= 1.0 ? 1.0 : X [ 352ULL
] ; } zc_int366 = ( ( ( 1.0 - t3176 ) - zc_int365 ) * 296.802103844292 +
t3176 * 461.523 ) + zc_int365 * 259.836612622973 ; t3181 = X [ 353ULL ] *
461.523 / ( zc_int366 == 0.0 ? 1.0E-16 : zc_int366 ) ; if ( t3181 <= 0.0 ) {
t3182 = 0.0 ; } else { t3182 = t3181 >= 1.0 ? 1.0 : t3181 ; } t3181 = X [
352ULL ] * 259.836612622973 / ( zc_int366 == 0.0 ? 1.0E-16 : zc_int366 ) ; if
( t3181 <= 0.0 ) { t3183 = 0.0 ; } else { t3183 = t3181 >= 1.0 ? 1.0 : t3181
; } t2049 [ 0ULL ] = X [ 350ULL ] ; tlu2_linear_nearest_prelookup ( &
yk_efOut . mField0 [ 0ULL ] , & yk_efOut . mField1 [ 0ULL ] , & yk_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t99 = yk_efOut ;
tlu2_1d_linear_nearest_value ( & al_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = al_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & bl_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = bl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & cl_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = cl_efOut [ 0 ] ; t3181 =
( ( ( 1.0 - t3182 ) - t3183 ) * t2585_idx_0 + t2586_idx_0 * t3182 ) +
t2587_idx_0 * t3183 ; tlu2_1d_linear_nearest_value ( & dl_efOut [ 0ULL ] , &
t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
dl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & el_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = el_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & fl_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField29 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = fl_efOut [ 0
] ; t3184 = ( ( ( 1.0 - t3182 ) - t3183 ) * t2585_idx_0 + t2586_idx_0 * t3182
) + t2587_idx_0 * t3183 ; t3185 = t3132 <= 0.0 ? t3132 : 0.0 ;
tlu2_1d_linear_nearest_value ( & gl_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & hl_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = hl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & il_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = il_efOut [ 0 ] ; t3132 =
( ( ( 1.0 - t3182 ) - t3183 ) * t2585_idx_0 + t2586_idx_0 * t3182 ) +
t2587_idx_0 * t3183 ; t3429 = ( t3133 + t3132 ) / 2.0 * 0.32 ; t3182 = -
t3185 * 0.01 / ( t3429 == 0.0 ? 1.0E-16 : t3429 ) ; t3183 = t3182 >= 0.0 ?
t3182 : - t3182 ; t3185 = t3183 > 1000.0 ? t3183 : 1000.0 ; t4658 = t3177 +
t3181 ; if ( t4658 / 2.0 > 0.5 ) { t3186 = ( t3177 + t3181 ) / 2.0 ; } else {
t3186 = 0.5 ; } t3432 = pmf_log10 ( 6.9 / ( t3185 == 0.0 ? 1.0E-16 : t3185 )
+ 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3185 == 0.0 ? 1.0E-16 :
t3185 ) + 0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 = 1.0 / (
t3432 == 0.0 ? 1.0E-16 : t3432 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 = ( pmf_pow (
t3186 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 / 8.0 ) * 12.7
+ 1.0 ; t3185 = ( t3185 - 1000.0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 / 8.0 ) *
t3186 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 ) ; t3186 = (
t3183 - 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 = t3186 *
t3186 * 3.0 - t3186 * t3186 * t3186 * 2.0 ; if ( t3183 <= 2000.0 ) { t3186 =
3.66 ; } else if ( t3183 >= 4000.0 ) { t3186 = t3185 ; } else { t3186 = ( 1.0
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 ) * 3.66 +
t3185 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 ; }
t3439 = t4658 / 2.0 ; if ( t3183 > t3186 * 10.709248339636167 / 0.32 / (
t3439 == 0.0 ? 1.0E-16 : t3439 ) / 30.0 ) { t4510 = ( t3177 + t3181 ) / 2.0 ;
t3185 = t3186 * 10.709248339636167 / ( t3183 == 0.0 ? 1.0E-16 : t3183 ) /
0.32 / ( t4510 == 0.0 ? 1.0E-16 : t4510 ) ; } else { t3185 = 30.0 ; } t3177 =
( X [ 32ULL ] - X [ 350ULL ] ) * ( 1.0 - pmf_exp ( - t3185 ) ) ; t3177 =
t3174 + t3182 * 0.32 / 0.01 * ( t4658 / 2.0 ) * ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 + t3184 ) /
2.0 ) * t3177 ; t3174 = pmf_sqrt ( X [ 368ULL ] * X [ 368ULL ] +
2.5711439722933289E-8 ) ; t3182 = pmf_sqrt ( X [ 368ULL ] * X [ 368ULL ] +
4.9597684650720062E-8 ) ; t3183 = pmf_sqrt ( X [ 368ULL ] * X [ 368ULL ] +
3.5023764535063275E-8 ) ; t3185 = pmf_sqrt ( X [ 371ULL ] * X [ 371ULL ] +
2.5711439722933289E-8 ) ; t3186 = pmf_sqrt ( X [ 371ULL ] * X [ 371ULL ] +
4.9597684650720062E-8 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 = pmf_sqrt ( X
[ 371ULL ] * X [ 371ULL ] + 3.5023764535063275E-8 ) ;
tlu2_1d_linear_linear_value ( & jl_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ]
, & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = jl_efOut [ 0 ] ; t3188 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & kl_efOut [ 0ULL ] , & t187 .
mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
kl_efOut [ 0 ] ; t3190 = X [ 378ULL ] + X [ 383ULL ] ; t3191 = ( X [ 368ULL ]
+ X [ 371ULL ] ) - t3137 * 100000.0 ; t3192 = ( X [ 379ULL ] + X [ 384ULL ] )
- t3137 * 100000.0 ; t3193 = ( ( ( 1.0 - intrm_sf_mf_867 ) - t3124 ) * t3188
+ t3155 * intrm_sf_mf_867 ) + t2585_idx_0 * t3124 ; t3195 = t3188 - X [ 43ULL
] * 0.296802103844292 ; t3188 = t2585_idx_0 - X [ 43ULL ] *
0.25983661262297303 ; t3189 = t3155 - X [ 43ULL ] * 0.461523 ; if ( X [ 48ULL
] <= 0.0 ) { t3155 = 0.0 ; } else { t3155 = X [ 48ULL ] >= 1.0 ? 1.0 : X [
48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { t3196 = 0.0 ; } else { t3196 = X [
47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ; } t3197 = ( ( ( 1.0 - t3155 ) - t3196 )
* 296.802103844292 + t3155 * 461.523 ) + t3196 * 259.836612622973 ; zc_int52
= - ( ( X [ 46ULL ] / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) - X [
387ULL ] / ( X [ 388ULL ] == 0.0 ? 1.0E-16 : X [ 388ULL ] ) ) * X [ 371ULL ]
* t3197 ) / 0.32 ; if ( X [ 387ULL ] <= 216.59999999999997 ) { zc_int368 =
216.59999999999997 ; } else { zc_int368 = X [ 387ULL ] >= 623.15 ? 623.15 : X
[ 387ULL ] ; } t2705 = zc_int368 * zc_int368 ; t3201 = ( ( (
1074.1165326382554 + zc_int368 * - 0.22145652610641059 ) + t2705 *
0.0003721298010901061 ) * ( ( 1.0 - t3155 ) - t3196 ) + ( (
1479.6504774710402 + zc_int368 * 1.2002114337050787 ) + t2705 * -
0.00038614513167845434 ) * t3155 ) + ( ( 900.639412248396 + zc_int368 * -
0.044484923911441127 ) + t2705 * 0.00036936011832051582 ) * t3196 ; t3454 =
t3201 - t3197 ; zc_int368 = t3201 / ( t3454 == 0.0 ? 1.0E-16 : t3454 ) ;
t3201 = pmf_sqrt ( zc_int52 * zc_int52 * 9.999999999999999E-14 + fabs ( X [
387ULL ] * zc_int368 * t3197 ) * 1.0E-9 ) ; if ( X [ 361ULL ] <= 0.0 ) {
t2705 = 0.0 ; } else { t2705 = X [ 361ULL ] >= 1.0 ? 1.0 : X [ 361ULL ] ; }
if ( X [ 363ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 = X [ 363ULL
] >= 1.0 ? 1.0 : X [ 363ULL ] ; } t2049 [ 0ULL ] = X [ 46ULL ] ;
tlu2_linear_nearest_prelookup ( & ll_efOut . mField0 [ 0ULL ] , & ll_efOut .
mField1 [ 0ULL ] , & ll_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = ll_efOut ; tlu2_1d_linear_nearest_value ( & ml_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ml_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & nl_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
nl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ol_efOut [ 0ULL ] , & t153
. mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ol_efOut [ 0 ] ; t3204 = ( ( ( 1.0 - t2705 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ) *
t2585_idx_0 + t2586_idx_0 * t2705 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ; t3455 = X [
388ULL ] * X [ 388ULL ] * zc_int368 ; t3205 = - pmf_sqrt ( fabs ( t3455 / (
t3197 == 0.0 ? 1.0E-16 : t3197 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X [
387ULL ] ) ) ) * 0.32 ; if ( t3205 >= 0.0 ) { t3206 = t3205 * 100000.0 ; }
else { t3206 = - t3205 * 100000.0 ; } t3459 = t3204 * 0.32 ; zc_int6 = t3206
* 0.01 / ( t3459 == 0.0 ? 1.0E-16 : t3459 ) ; t3461 = X [ 46ULL ] * t3197 ;
piece199 = X [ 50ULL ] / ( t3461 == 0.0 ? 1.0E-16 : t3461 ) ; t3463 =
piece199 * 6.4000000000000011E-5 ; t3210 = t3205 * t3204 * 2.9973120849090416
/ ( t3463 == 0.0 ? 1.0E-16 : t3463 ) ; t3211 = zc_int6 >= 1.0 ? zc_int6 : 1.0
; t3464 = pmf_log10 ( 6.9 / ( t3211 == 0.0 ? 1.0E-16 : t3211 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3211 == 0.0 ? 1.0E-16 : t3211
) + 0.00017169489553429715 ) * 3.24 ; t3466 = piece199 *
0.0020480000000000003 ; t3206 = t3205 * t3206 * ( 1.0 / ( t3464 == 0.0 ?
1.0E-16 : t3464 ) ) * 0.046833001326703774 / ( t3466 == 0.0 ? 1.0E-16 : t3466
) ; t3211 = ( zc_int6 - 2000.0 ) / 2000.0 ; t3212 = t3211 * t3211 * 3.0 -
t3211 * t3211 * t3211 * 2.0 ; if ( zc_int6 <= 2000.0 ) { t3211 = t3210 *
1.0E-5 ; } else if ( zc_int6 >= 4000.0 ) { t3211 = t3206 * 1.0E-5 ; } else {
t3211 = ( ( 1.0 - t3212 ) * t3210 + t3206 * t3212 ) * 1.0E-5 ; } t3201 = - (
X [ 371ULL ] * t3201 ) / 0.32 * 0.00031622776601683789 + t3211 ; t3206 = X [
351ULL ] - X [ 50ULL ] ; t3210 = - ( ( X [ 46ULL ] / ( X [ 50ULL ] == 0.0 ?
1.0E-16 : X [ 50ULL ] ) - X [ 389ULL ] / ( X [ 390ULL ] == 0.0 ? 1.0E-16 : X
[ 390ULL ] ) ) * X [ 325ULL ] * t3197 ) / 0.32 ; if ( X [ 389ULL ] <=
216.59999999999997 ) { t3211 = 216.59999999999997 ; } else { t3211 = X [
389ULL ] >= 623.15 ? 623.15 : X [ 389ULL ] ; } piece237 = t3211 * t3211 ;
t3212 = ( ( ( 1074.1165326382554 + t3211 * - 0.22145652610641059 ) + piece237
* 0.0003721298010901061 ) * ( ( 1.0 - t3155 ) - t3196 ) + ( (
1479.6504774710402 + t3211 * 1.2002114337050787 ) + piece237 * -
0.00038614513167845434 ) * t3155 ) + ( ( 900.639412248396 + t3211 * -
0.044484923911441127 ) + piece237 * 0.00036936011832051582 ) * t3196 ;
U_idx_1 = t3212 - t3197 ; t3211 = t3212 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ; t3212 = pmf_sqrt ( t3210 * t3210 * 9.999999999999999E-14 + fabs (
X [ 389ULL ] * t3211 * t3197 ) * 1.0E-9 ) ; t3475 = X [ 390ULL ] * X [ 390ULL
] * t3211 ; piece237 = - pmf_sqrt ( fabs ( t3475 / ( t3197 == 0.0 ? 1.0E-16 :
t3197 ) / ( X [ 389ULL ] == 0.0 ? 1.0E-16 : X [ 389ULL ] ) ) ) * 0.32 ; if (
piece237 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 = piece237 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 = - piece237 *
100000.0 ; } piece354 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 * 0.01 / (
t3459 == 0.0 ? 1.0E-16 : t3459 ) ; U_idx_1 = piece237 * t3204 *
2.9973120849090416 / ( t3463 == 0.0 ? 1.0E-16 : t3463 ) ; t3217 = piece354 >=
1.0 ? piece354 : 1.0 ; t3482 = pmf_log10 ( 6.9 / ( t3217 == 0.0 ? 1.0E-16 :
t3217 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3217 == 0.0 ?
1.0E-16 : t3217 ) + 0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 = piece237 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 * ( 1.0 / (
t3482 == 0.0 ? 1.0E-16 : t3482 ) ) * 0.046833001326703774 / ( t3466 == 0.0 ?
1.0E-16 : t3466 ) ; t3217 = ( piece354 - 2000.0 ) / 2000.0 ; t3218 = t3217 *
t3217 * 3.0 - t3217 * t3217 * t3217 * 2.0 ; if ( piece354 <= 2000.0 ) { t3217
= U_idx_1 * 1.0E-5 ; } else if ( piece354 >= 4000.0 ) { t3217 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 * 1.0E-5 ; }
else { t3217 = ( ( 1.0 - t3218 ) * U_idx_1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 * t3218 ) *
1.0E-5 ; } t3212 = - ( X [ 325ULL ] * t3212 ) / 0.32 * 0.00031622776601683789
+ t3217 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 = X
[ 303ULL ] - X [ 50ULL ] ; t2049 [ 0ULL ] = X [ 46ULL ] ;
tlu2_linear_linear_prelookup ( & pl_efOut . mField0 [ 0ULL ] , & pl_efOut .
mField1 [ 0ULL ] , & pl_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = pl_efOut ; tlu2_1d_linear_linear_value ( & ql_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ql_efOut [ 0 ] ; t3217 = t2585_idx_0 ; tlu2_1d_linear_linear_value ( &
rl_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField19 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = rl_efOut [ 0 ] ; t3218 = t2585_idx_0 ; if ( 1.0 - X
[ 48ULL ] >= 0.01 ) { t3221 = 1.0 - X [ 48ULL ] ; } else if ( 1.0 - X [ 48ULL
] >= - 0.1 ) { t3221 = pmf_exp ( ( ( 1.0 - X [ 48ULL ] ) - 0.01 ) / 0.01 ) *
0.01 ; } else { t3221 = 1.6701700790245661E-7 ; } t3219 = X [ 47ULL ] / (
t3221 == 0.0 ? 1.0E-16 : t3221 ) * - 36.965491221318985 + 296.802103844292 ;
tlu2_1d_linear_linear_value ( & sl_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = sl_efOut [ 0 ] ; t3222 =
pmf_exp ( pmf_log ( X [ 50ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3222 >=
1.0 ) { t3489 = ( t3222 - 1.0 ) * 461.523 + t3219 ; t3223 = t3219 / ( t3489
== 0.0 ? 1.0E-16 : t3489 ) ; } else { t3223 = 1.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 = t3223 *
0.01 ; t3219 = ( X [ 48ULL ] - t3223 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ) ;
if ( X [ 48ULL ] - t3223 <= 0.0 ) { t3219 = 0.0 ; } else if ( X [ 48ULL ] -
t3223 >= t3223 * 0.01 ) { t3219 = X [ 48ULL ] - t3223 ; } else { t3219 = ( X
[ 48ULL ] - t3223 ) * ( t3219 * t3219 * 3.0 - t3219 * t3219 * t3219 * 2.0 ) ;
} piece199 = piece199 * t3219 * 0.026773120849090417 / 0.001 ; t3219 = (
t3217 - t3218 ) * piece199 ; tlu2_1d_linear_nearest_value ( & tl_efOut [ 0ULL
] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = tl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
ul_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = ul_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
vl_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField29 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = vl_efOut [ 0 ] ; t3218 = ( ( ( 1.0 - t2705 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ) *
t2585_idx_0 + t2586_idx_0 * t2705 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ; t3223 = ( X
[ 32ULL ] - X [ 46ULL ] ) * ( t3218 * 10.709248339636167 / 0.01 ) ;
tlu2_1d_linear_nearest_value ( & wl_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = wl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & xl_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = xl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & yl_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = yl_efOut [ 0 ] ; t3224
= ( ( ( 1.0 - t2705 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ) *
t2585_idx_0 + t2586_idx_0 * t2705 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ; t2705 = ( -
X [ 371ULL ] - ( - X [ 325ULL ] ) ) / 2.0 ; t2796 = ( t3204 + t3132 ) / 2.0 *
0.32 ; t3132 = ( t2705 >= 0.0 ? t2705 : 0.0 ) * 0.01 / ( t2796 == 0.0 ?
1.0E-16 : t2796 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 = t3132 >= 0.0
? t3132 : - t3132 ; t3225 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 : 1000.0 ;
t3498 = t3224 + t3181 ; if ( t3498 / 2.0 > 0.5 ) { U_idx_1 = ( t3224 + t3181
) / 2.0 ; } else { U_idx_1 = 0.5 ; } t3500 = pmf_log10 ( 6.9 / ( t3225 == 0.0
? 1.0E-16 : t3225 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3225 ==
0.0 ? 1.0E-16 : t3225 ) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_1064
= 1.0 / ( t3500 == 0.0 ? 1.0E-16 : t3500 ) ; t3502 = ( pmf_pow ( U_idx_1 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intrm_sf_mf_1064 / 8.0 ) * 12.7 +
1.0 ; t3225 = ( t3225 - 1000.0 ) * ( intrm_sf_mf_1064 / 8.0 ) * U_idx_1 / (
t3502 == 0.0 ? 1.0E-16 : t3502 ) ; U_idx_1 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 - 2000.0 ) /
2000.0 ; intrm_sf_mf_1064 = U_idx_1 * U_idx_1 * 3.0 - U_idx_1 * U_idx_1 *
U_idx_1 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 <= 2000.0 ) {
U_idx_1 = 3.66 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 >= 4000.0 ) {
U_idx_1 = t3225 ; } else { U_idx_1 = ( 1.0 - intrm_sf_mf_1064 ) * 3.66 +
t3225 * intrm_sf_mf_1064 ; } t3507 = t3498 / 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 > U_idx_1 *
10.709248339636167 / 0.32 / ( t3507 == 0.0 ? 1.0E-16 : t3507 ) / 30.0 ) {
t3513 = ( t3224 + t3181 ) / 2.0 ; t3225 = U_idx_1 * 10.709248339636167 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ) /
0.32 / ( t3513 == 0.0 ? 1.0E-16 : t3513 ) ; } else { t3225 = 30.0 ; } t3181 =
( X [ 32ULL ] - X [ 350ULL ] ) * ( 1.0 - pmf_exp ( - t3225 ) ) ; t3132 =
t3132 * 0.32 / 0.01 * ( t3498 / 2.0 ) * ( ( t3218 + t3184 ) / 2.0 ) * t3181 ;
t3519 = ( t3204 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ) / 2.0 * 0.32
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 = - ( t2705
<= 0.0 ? t2705 : 0.0 ) * 0.01 / ( t3519 == 0.0 ? 1.0E-16 : t3519 ) ; t3181 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ; t3184 =
t3181 > 1000.0 ? t3181 : 1000.0 ; t3520 = t3224 + t3096 ; if ( t3520 / 2.0 >
0.5 ) { t2705 = ( t3224 + t3096 ) / 2.0 ; } else { t2705 = 0.5 ; } t3522 =
pmf_log10 ( 6.9 / ( t3184 == 0.0 ? 1.0E-16 : t3184 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t3184 == 0.0 ? 1.0E-16 : t3184 ) +
0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 = 1.0 / (
t3522 == 0.0 ? 1.0E-16 : t3522 ) ; U_idx_1 = ( pmf_pow ( t2705 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 / 8.0 ) * 12.7
+ 1.0 ; t3184 = ( t3184 - 1000.0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 / 8.0 ) *
t2705 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; t2705 = ( t3181 - 2000.0 ) /
2000.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 =
t2705 * t2705 * 3.0 - t2705 * t2705 * t2705 * 2.0 ; if ( t3181 <= 2000.0 ) {
t2705 = 3.66 ; } else if ( t3181 >= 4000.0 ) { t2705 = t3184 ; } else { t2705
= ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 ) *
3.66 + t3184 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95
; } t3529 = t3520 / 2.0 ; if ( t3181 > t2705 * 10.709248339636167 / 0.32 / (
t3529 == 0.0 ? 1.0E-16 : t3529 ) / 30.0 ) { t3535 = ( t3224 + t3096 ) / 2.0 ;
t3184 = t2705 * 10.709248339636167 / ( t3181 == 0.0 ? 1.0E-16 : t3181 ) /
0.32 / ( t3535 == 0.0 ? 1.0E-16 : t3535 ) ; } else { t3184 = 30.0 ; } t3096 =
( X [ 32ULL ] - X [ 302ULL ] ) * ( 1.0 - pmf_exp ( - t3184 ) ) ; t3096 =
t3132 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 * 0.32
/ 0.01 * ( t3520 / 2.0 ) * ( ( t3218 + U_idx_3 ) / 2.0 ) * t3096 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 = pmf_sqrt ( X
[ 325ULL ] * X [ 325ULL ] + 2.5711439722933289E-8 ) ; t3132 = pmf_sqrt ( X [
325ULL ] * X [ 325ULL ] + 4.9597684650720062E-8 ) ; t3181 = pmf_sqrt ( X [
325ULL ] * X [ 325ULL ] + 3.5023764535063275E-8 ) ;
tlu2_1d_linear_linear_value ( & am_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = am_efOut [ 0 ] ; t3184 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & bm_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
bm_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 = ( - X [
383ULL ] - X [ 336ULL ] ) + X [ 401ULL ] ; t3218 = ( ( ( - X [ 371ULL ] - X [
325ULL ] ) + X [ 401ULL ] ) + X [ 402ULL ] ) - piece199 * 100000.0 ; t3224 =
( ( - X [ 384ULL ] - X [ 337ULL ] ) + X [ 402ULL ] ) - piece199 * 100000.0 ;
t3225 = ( ( ( 1.0 - t3155 ) - t3196 ) * t3184 + t3217 * t3155 ) + t2585_idx_0
* t3196 ; intrm_sf_mf_1064 = t3184 - X [ 46ULL ] * 0.296802103844292 ; t3184
= t2585_idx_0 - X [ 46ULL ] * 0.25983661262297303 ; t2705 = t3217 - X [ 46ULL
] * 0.461523 ; if ( X [ 53ULL ] <= 0.0 ) { t3217 = 0.0 ; } else { t3217 = X [
53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; } if ( X [ 52ULL ] <= 0.0 ) { t3228 =
0.0 ; } else { t3228 = X [ 52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t3229 = ( (
( 1.0 - t3217 ) - t3228 ) * 296.802103844292 + t3217 * 461.523 ) + t3228 *
259.836612622973 ; t3231 = ( X [ 51ULL ] / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X
[ 54ULL ] ) - X [ 414ULL ] / ( X [ 415ULL ] == 0.0 ? 1.0E-16 : X [ 415ULL ] )
) * X [ 413ULL ] * t3229 / 0.0019634954084936209 ; if ( X [ 414ULL ] <=
216.59999999999997 ) { t3232 = 216.59999999999997 ; } else { t3232 = X [
414ULL ] >= 623.15 ? 623.15 : X [ 414ULL ] ; } t2711 = t3232 * t3232 ; t3233
= ( ( ( 1074.1165326382554 + t3232 * - 0.22145652610641059 ) + t2711 *
0.0003721298010901061 ) * ( ( 1.0 - t3217 ) - t3228 ) + ( (
1479.6504774710402 + t3232 * 1.2002114337050787 ) + t2711 * -
0.00038614513167845434 ) * t3217 ) + ( ( 900.639412248396 + t3232 * -
0.044484923911441127 ) + t2711 * 0.00036936011832051582 ) * t3228 ; t3544 =
t3233 - t3229 ; t3232 = t3233 / ( t3544 == 0.0 ? 1.0E-16 : t3544 ) ; t3233 =
pmf_sqrt ( t3231 * t3231 * 9.999999999999999E-14 + fabs ( X [ 414ULL ] *
t3232 * t3229 ) * 1.0E-9 ) ; if ( X [ 410ULL ] <= 0.0 ) { t2711 = 0.0 ; }
else { t2711 = X [ 410ULL ] >= 1.0 ? 1.0 : X [ 410ULL ] ; } if ( X [ 409ULL ]
<= 0.0 ) { intrm_sf_mf_1220 = 0.0 ; } else { intrm_sf_mf_1220 = X [ 409ULL ]
>= 1.0 ? 1.0 : X [ 409ULL ] ; } t2049 [ 0ULL ] = X [ 51ULL ] ;
tlu2_linear_nearest_prelookup ( & cm_efOut . mField0 [ 0ULL ] , & cm_efOut .
mField1 [ 0ULL ] , & cm_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t178 = cm_efOut ; tlu2_1d_linear_nearest_value ( & dm_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
dm_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & em_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
em_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & fm_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
fm_efOut [ 0 ] ; t3240 = ( ( ( 1.0 - t2711 ) - intrm_sf_mf_1220 ) *
t2585_idx_0 + t2586_idx_0 * t2711 ) + t2587_idx_0 * intrm_sf_mf_1220 ; t3545
= X [ 415ULL ] * X [ 415ULL ] * t3232 ; t3242 = - pmf_sqrt ( fabs ( t3545 / (
t3229 == 0.0 ? 1.0E-16 : t3229 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [
414ULL ] ) ) ) * 0.0019634954084936209 ; if ( t3242 >= 0.0 ) { t3246 = t3242
* 100000.0 ; } else { t3246 = - t3242 * 100000.0 ; } t3549 = t3240 *
0.0019634954084936209 ; t3248 = t3246 * 0.05 / ( t3549 == 0.0 ? 1.0E-16 :
t3549 ) ; t3551 = X [ 51ULL ] * t3229 ; piece416 = X [ 54ULL ] / ( t3551 ==
0.0 ? 1.0E-16 : t3551 ) ; t3553 = piece416 * 9.8174770424681068E-6 ; piece422
= t3242 * t3240 * 11.2 / ( t3553 == 0.0 ? 1.0E-16 : t3553 ) ; t3252 = t3248
>= 1.0 ? t3248 : 1.0 ; t3554 = pmf_log10 ( 6.9 / ( t3252 == 0.0 ? 1.0E-16 :
t3252 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3252 == 0.0 ?
1.0E-16 : t3252 ) + 2.8767404433520813E-5 ) * 3.24 ; t3556 = piece416 *
3.855314219175531E-7 ; t3246 = t3242 * t3246 * ( 1.0 / ( t3554 == 0.0 ?
1.0E-16 : t3554 ) ) * 0.175 / ( t3556 == 0.0 ? 1.0E-16 : t3556 ) ; t3252 = (
t3248 - 2000.0 ) / 2000.0 ; t3257 = t3252 * t3252 * 3.0 - t3252 * t3252 *
t3252 * 2.0 ; if ( t3248 <= 2000.0 ) { t3252 = piece422 * 1.0E-5 ; } else if
( t3248 >= 4000.0 ) { t3252 = t3246 * 1.0E-5 ; } else { t3252 = ( ( 1.0 -
t3257 ) * piece422 + t3246 * t3257 ) * 1.0E-5 ; } t3233 = X [ 413ULL ] *
t3233 / 0.0019634954084936209 * 0.00031622776601683789 + t3252 ; t3246 = X [
55ULL ] - X [ 54ULL ] ; piece422 = - ( ( X [ 51ULL ] / ( X [ 54ULL ] == 0.0 ?
1.0E-16 : X [ 54ULL ] ) - X [ 416ULL ] / ( X [ 417ULL ] == 0.0 ? 1.0E-16 : X
[ 417ULL ] ) ) * X [ 368ULL ] * t3229 ) / 0.0019634954084936209 ; if ( X [
416ULL ] <= 216.59999999999997 ) { t3252 = 216.59999999999997 ; } else {
t3252 = X [ 416ULL ] >= 623.15 ? 623.15 : X [ 416ULL ] ; } t3258 = t3252 *
t3252 ; t3257 = ( ( ( 1074.1165326382554 + t3252 * - 0.22145652610641059 ) +
t3258 * 0.0003721298010901061 ) * ( ( 1.0 - t3217 ) - t3228 ) + ( (
1479.6504774710402 + t3252 * 1.2002114337050787 ) + t3258 * -
0.00038614513167845434 ) * t3217 ) + ( ( 900.639412248396 + t3252 * -
0.044484923911441127 ) + t3258 * 0.00036936011832051582 ) * t3228 ; t3564 =
t3257 - t3229 ; t3252 = t3257 / ( t3564 == 0.0 ? 1.0E-16 : t3564 ) ; t3257 =
pmf_sqrt ( piece422 * piece422 * 9.999999999999999E-14 + fabs ( X [ 416ULL ]
* t3252 * t3229 ) * 1.0E-9 ) ; t3565 = X [ 417ULL ] * X [ 417ULL ] * t3252 ;
t3258 = - pmf_sqrt ( fabs ( t3565 / ( t3229 == 0.0 ? 1.0E-16 : t3229 ) / ( X
[ 416ULL ] == 0.0 ? 1.0E-16 : X [ 416ULL ] ) ) ) * 0.0019634954084936209 ; if
( t3258 >= 0.0 ) { t3260 = t3258 * 100000.0 ; } else { t3260 = - t3258 *
100000.0 ; } t3262 = t3260 * 0.05 / ( t3549 == 0.0 ? 1.0E-16 : t3549 ) ;
t3264 = t3258 * t3240 * 11.2 / ( t3553 == 0.0 ? 1.0E-16 : t3553 ) ; t3266 =
t3262 >= 1.0 ? t3262 : 1.0 ; t3572 = pmf_log10 ( 6.9 / ( t3266 == 0.0 ?
1.0E-16 : t3266 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3266 ==
0.0 ? 1.0E-16 : t3266 ) + 2.8767404433520813E-5 ) * 3.24 ; t3260 = t3258 *
t3260 * ( 1.0 / ( t3572 == 0.0 ? 1.0E-16 : t3572 ) ) * 0.175 / ( t3556 == 0.0
? 1.0E-16 : t3556 ) ; t3266 = ( t3262 - 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = t3266 *
t3266 * 3.0 - t3266 * t3266 * t3266 * 2.0 ; if ( t3262 <= 2000.0 ) { t3266 =
t3264 * 1.0E-5 ; } else if ( t3262 >= 4000.0 ) { t3266 = t3260 * 1.0E-5 ; }
else { t3266 = ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 ) * t3264 +
t3260 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 ) *
1.0E-5 ; } t3257 = - ( X [ 368ULL ] * t3257 ) / 0.0019634954084936209 *
0.00031622776601683789 + t3266 ; t3260 = X [ 365ULL ] - X [ 54ULL ] ; t2049 [
0ULL ] = X [ 51ULL ] ; tlu2_linear_linear_prelookup ( & gm_efOut . mField0 [
0ULL ] , & gm_efOut . mField1 [ 0ULL ] , & gm_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = gm_efOut ; tlu2_1d_linear_linear_value ( &
hm_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = hm_efOut [ 0 ] ; t3264 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & im_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField19 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = im_efOut [ 0 ] ; t3266 =
t2585_idx_0 ; if ( 1.0 - X [ 53ULL ] >= 0.01 ) { t3269 = 1.0 - X [ 53ULL ] ;
} else if ( 1.0 - X [ 53ULL ] >= - 0.1 ) { t3269 = pmf_exp ( ( ( 1.0 - X [
53ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t3269 = 1.6701700790245661E-7 ;
} Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = X [ 52ULL
] / ( t3269 == 0.0 ? 1.0E-16 : t3269 ) * - 36.965491221318985 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & jm_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
jm_efOut [ 0 ] ; t3270 = pmf_exp ( pmf_log ( X [ 54ULL ] * 100000.0 ) -
t2585_idx_0 ) ; if ( t3270 >= 1.0 ) { t3579 = ( t3270 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 / ( t3579 ==
0.0 ? 1.0E-16 : t3579 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 = 1.0 ; }
intrm_sf_mf_1104 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 * 0.01 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = ( X [ 53ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 ) / (
intrm_sf_mf_1104 == 0.0 ? 1.0E-16 : intrm_sf_mf_1104 ) ; if ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = 0.0 ; } else
if ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = X [ 53ULL ]
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = ( X [ 53ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 * 2.0 ) ; }
piece416 = piece416 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 *
0.00049087385212340522 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = ( t3264 -
t3266 ) * piece416 ; tlu2_1d_linear_nearest_value ( & km_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField20 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
km_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & lm_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField21 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
lm_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & mm_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField29 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
mm_efOut [ 0 ] ; t3266 = ( ( ( 1.0 - t2711 ) - intrm_sf_mf_1220 ) *
t2585_idx_0 + t2586_idx_0 * t2711 ) + t2587_idx_0 * intrm_sf_mf_1220 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 = ( X [ 412ULL
] - X [ 51ULL ] ) * ( t3266 * 0.039269908169872414 / 0.05 ) ; if ( X [ 405ULL
] <= 0.0 ) { t3272 = 0.0 ; } else { t3272 = X [ 405ULL ] >= 1.0 ? 1.0 : X [
405ULL ] ; } if ( X [ 404ULL ] <= 0.0 ) { t4821 = 0.0 ; } else { t4821 = X [
404ULL ] >= 1.0 ? 1.0 : X [ 404ULL ] ; } t4447 = ( ( ( 1.0 - t3272 ) - t4821
) * 296.802103844292 + t3272 * 461.523 ) + t4821 * 259.836612622973 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = X [ 405ULL
] * 461.523 / ( t4447 == 0.0 ? 1.0E-16 : t4447 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 >= 1.0 ? 1.0
: Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = X [ 404ULL
] * 259.836612622973 / ( t4447 == 0.0 ? 1.0E-16 : t4447 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 <= 0.0 ) {
U_idx_3 = 0.0 ; } else { U_idx_3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 >= 1.0 ? 1.0
: Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ; } t2049 [
0ULL ] = X [ 403ULL ] ; tlu2_linear_nearest_prelookup ( & nm_efOut . mField0
[ 0ULL ] , & nm_efOut . mField1 [ 0ULL ] , & nm_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [
0ULL ] , & t225 [ 0ULL ] ) ; t88 = nm_efOut ; tlu2_1d_linear_nearest_value (
& om_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = om_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
pm_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = pm_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
qm_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField30 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = qm_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ) - U_idx_3 )
* t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ) +
t2587_idx_0 * U_idx_3 ; tlu2_1d_linear_nearest_value ( & rm_efOut [ 0ULL ] ,
& t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0
= rm_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & sm_efOut [ 0ULL ] , &
t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
sm_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & tm_efOut [ 0ULL ] , & t178
. mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
tm_efOut [ 0 ] ; t3278 = ( ( ( 1.0 - t2711 ) - intrm_sf_mf_1220 ) *
t2585_idx_0 + t2586_idx_0 * t2711 ) + t2587_idx_0 * intrm_sf_mf_1220 ;
tlu2_1d_linear_nearest_value ( & um_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = um_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & vm_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = vm_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & wm_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField29 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = wm_efOut [ 0 ] ; t2711 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 )
- U_idx_3 ) * t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ) +
t2587_idx_0 * U_idx_3 ; intrm_sf_mf_1220 = ( X [ 413ULL ] - ( - X [ 368ULL ]
) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & xm_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xm_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & ym_efOut [ 0ULL ] , & t88 . mField0
[ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = ym_efOut [ 0
] ; tlu2_1d_linear_nearest_value ( & an_efOut [ 0ULL ] , & t88 . mField0 [
0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField28 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = an_efOut [ 0
] ; U_idx_1 = ( t3240 + ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ) - U_idx_3 )
* t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ) +
t2587_idx_0 * U_idx_3 ) ) / 2.0 * 0.0019634954084936209 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = (
intrm_sf_mf_1220 >= 0.0 ? intrm_sf_mf_1220 : 0.0 ) * 0.05 / ( U_idx_1 == 0.0
? 1.0E-16 : U_idx_1 ) ; U_idx_3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ; t3279 =
U_idx_3 > 1000.0 ? U_idx_3 : 1000.0 ; t3590 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 + t3278 ; if
( t3590 / 2.0 > 0.5 ) { t3280 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 + t3278 ) /
2.0 ; } else { t3280 = 0.5 ; } U_idx_1 = pmf_log10 ( 6.9 / ( t3279 == 0.0 ?
1.0E-16 : t3279 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3279 ==
0.0 ? 1.0E-16 : t3279 ) + 2.8767404433520813E-5 ) * 3.24 ; t3281 = 1.0 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; U_idx_1 = ( pmf_pow ( t3280 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t3281 / 8.0 ) * 12.7 + 1.0 ; t3279
= ( t3279 - 1000.0 ) * ( t3281 / 8.0 ) * t3280 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ; t3280 = ( U_idx_3 - 2000.0 ) / 2000.0 ; t3281 = t3280 * t3280 *
3.0 - t3280 * t3280 * t3280 * 2.0 ; if ( U_idx_3 <= 2000.0 ) { t3280 = 3.66 ;
} else if ( U_idx_3 >= 4000.0 ) { t3280 = t3279 ; } else { t3280 = ( 1.0 -
t3281 ) * 3.66 + t3279 * t3281 ; } t3599 = t3590 / 2.0 ; if ( U_idx_3 > t3280
* 0.039269908169872414 / 0.0019634954084936209 / ( t3599 == 0.0 ? 1.0E-16 :
t3599 ) / 30.0 ) { intrm_sf_mf_199 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 + t3278 ) /
2.0 ; t3279 = t3280 * 0.039269908169872414 / ( U_idx_3 == 0.0 ? 1.0E-16 :
U_idx_3 ) / 0.0019634954084936209 / ( intrm_sf_mf_199 == 0.0 ? 1.0E-16 :
intrm_sf_mf_199 ) ; } else { t3279 = 30.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = ( X [
412ULL ] - X [ 403ULL ] ) * ( 1.0 - pmf_exp ( - t3279 ) ) ; t2711 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
0.0019634954084936209 / 0.05 * ( t3590 / 2.0 ) * ( ( t2711 + t3266 ) / 2.0 )
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ; t3611 = (
t3240 + t3179 ) / 2.0 * 0.0019634954084936209 ; t3179 = - ( intrm_sf_mf_1220
<= 0.0 ? intrm_sf_mf_1220 : 0.0 ) * 0.05 / ( t3611 == 0.0 ? 1.0E-16 : t3611 )
; intrm_sf_mf_1220 = t3179 >= 0.0 ? t3179 : - t3179 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 =
intrm_sf_mf_1220 > 1000.0 ? intrm_sf_mf_1220 : 1000.0 ; t3612 = t3278 +
intrm_sf_mf_1229 ; if ( t3612 / 2.0 > 0.5 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = ( t3278 +
intrm_sf_mf_1229 ) / 2.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = 0.5 ; }
U_idx_7 = pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ) +
2.8767404433520813E-5 ) * 3.24 ; U_idx_3 = 1.0 / ( U_idx_7 == 0.0 ? 1.0E-16 :
U_idx_7 ) ; t3616 = ( pmf_pow (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( U_idx_3 / 8.0 ) * 12.7 + 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 - 1000.0 ) *
( U_idx_3 / 8.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 / ( t3616 ==
0.0 ? 1.0E-16 : t3616 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = (
intrm_sf_mf_1220 - 2000.0 ) / 2000.0 ; U_idx_3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 * 2.0 ; if (
intrm_sf_mf_1220 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = 3.66 ; }
else if ( intrm_sf_mf_1220 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = ( 1.0 -
U_idx_3 ) * 3.66 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 * U_idx_3 ; }
t3621 = t3612 / 2.0 ; if ( intrm_sf_mf_1220 >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
0.039269908169872414 / 0.0019634954084936209 / ( t3621 == 0.0 ? 1.0E-16 :
t3621 ) / 30.0 ) { t3627 = ( t3278 + intrm_sf_mf_1229 ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 *
0.039269908169872414 / ( intrm_sf_mf_1220 == 0.0 ? 1.0E-16 : intrm_sf_mf_1220
) / 0.0019634954084936209 / ( t3627 == 0.0 ? 1.0E-16 : t3627 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = 30.0 ; }
intrm_sf_mf_1229 = ( X [ 412ULL ] - X [ 364ULL ] ) * ( 1.0 - pmf_exp ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ) ) ;
intrm_sf_mf_1229 = t2711 + t3179 * 0.0019634954084936209 / 0.05 * ( t3612 /
2.0 ) * ( ( t3266 + t2680 ) / 2.0 ) * intrm_sf_mf_1229 ; t2680 = pmf_sqrt ( X
[ 413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 ) ; t3179 = pmf_sqrt ( X [
413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 ) ; t2711 = pmf_sqrt ( X [
413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 ) ; intrm_sf_mf_1220 =
pmf_sqrt ( X [ 368ULL ] * X [ 368ULL ] + 3.0116308772356542E-13 ) ; t3266 =
pmf_sqrt ( X [ 368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 = pmf_sqrt (
X [ 368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 ) ;
tlu2_1d_linear_linear_value ( & bn_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = bn_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = t2585_idx_0
; tlu2_1d_linear_linear_value ( & cn_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = cn_efOut [ 0 ] ; t3278
= - X [ 378ULL ] + X [ 420ULL ] ; t3279 = ( ( - X [ 368ULL ] + X [ 413ULL ] )
+ U_idx_8 ) - piece416 * 100000.0 ; t3280 = ( ( - X [ 379ULL ] + X [ 421ULL ]
) + U_idx_8 ) - piece416 * 100000.0 ; t3281 = ( ( ( 1.0 - t3217 ) - t3228 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 + t3264 *
t3217 ) + t2585_idx_0 * t3228 ; t3283 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 - X [ 51ULL ]
* 0.296802103844292 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 = t2585_idx_0
- X [ 51ULL ] * 0.25983661262297303 ; t3284 = - X [ 434ULL ] + U_idx_10 * -
2.0 ; t3285 = pmf_sqrt ( t3284 * t3284 + 6.4274470286298274E-9 ) ; t2049 [
0ULL ] = X [ 433ULL ] ; t1006 [ 0 ] = 11ULL ; tlu2_linear_linear_prelookup (
& dn_efOut . mField0 [ 0ULL ] , & dn_efOut . mField1 [ 0ULL ] , & dn_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [
0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t62 = dn_efOut ; t2049 [ 0ULL
] = 1.01325 ; t1009 [ 0 ] = 12ULL ; tlu2_linear_linear_prelookup ( & en_efOut
. mField0 [ 0ULL ] , & en_efOut . mField1 [ 0ULL ] , & en_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t2049 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t177 = en_efOut ;
tlu2_2d_linear_linear_value ( & fn_efOut [ 0ULL ] , & t62 . mField0 [ 0ULL ]
, & t62 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = fn_efOut [ 0 ] ; t3287 =
t3284 / ( t3285 == 0.0 ? 1.0E-16 : t3285 ) * 1.01325 / ( t2585_idx_0 == 0.0 ?
1.0E-16 : t2585_idx_0 ) ; t3286 = ( 1.0 - t3284 / ( t3285 == 0.0 ? 1.0E-16 :
t3285 ) ) / 2.0 ; t3284 = ( t3284 / ( t3285 == 0.0 ? 1.0E-16 : t3285 ) + 1.0
) / 2.0 ; t2049 [ 0ULL ] = X [ 429ULL ] ; tlu2_linear_linear_prelookup ( &
gn_efOut . mField0 [ 0ULL ] , & gn_efOut . mField1 [ 0ULL ] , & gn_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [
0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t99 = gn_efOut ;
tlu2_2d_linear_linear_value ( & hn_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = hn_efOut [ 0 ] ; t3288 =
t2585_idx_0 ; t2049 [ 0ULL ] = X [ 56ULL ] ; tlu2_linear_linear_prelookup ( &
in_efOut . mField0 [ 0ULL ] , & in_efOut . mField1 [ 0ULL ] , & in_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [
0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = in_efOut ;
tlu2_2d_linear_linear_value ( & jn_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = jn_efOut [ 0 ] ; t3289 =
t2585_idx_0 ; t3292 = X [ 432ULL ] * 0.1 ; tlu2_2d_linear_linear_value ( &
kn_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t177 . mField0 [ 0ULL ] , & t177 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = kn_efOut [ 0 ] ; t3290 = t2585_idx_0 ; t3293 = 1.01325 /
( t3289 == 0.0 ? 1.0E-16 : t3289 ) * 100.0 + t2585_idx_0 ; t3294 = pmf_sqrt (
X [ 442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 ) ; t2049 [ 0ULL ] = X [
441ULL ] ; tlu2_linear_linear_prelookup ( & ln_efOut . mField0 [ 0ULL ] , &
ln_efOut . mField1 [ 0ULL ] , & ln_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t59 = ln_efOut ; t2049 [ 0ULL ] = X [ 437ULL ] ;
tlu2_linear_linear_prelookup ( & mn_efOut . mField0 [ 0ULL ] , & mn_efOut .
mField1 [ 0ULL ] , & mn_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t71 = mn_efOut ; tlu2_2d_linear_linear_value ( & nn_efOut [ 0ULL ] , & t59
. mField0 [ 0ULL ] , & t59 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
nn_efOut [ 0 ] ; t3296 = X [ 442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) *
X [ 437ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t3295 = ( 1.0
- X [ 442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) ) / 2.0 ; t3297 = ( X [
442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) + 1.0 ) / 2.0 ; t2049 [ 0ULL ]
= X [ 436ULL ] ; tlu2_linear_linear_prelookup ( & on_efOut . mField0 [ 0ULL ]
, & on_efOut . mField1 [ 0ULL ] , & on_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = on_efOut ; tlu2_2d_linear_linear_value ( &
pn_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField37 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ]
) ; t2585_idx_0 = pn_efOut [ 0 ] ; t3298 = t2585_idx_0 ; t2049 [ 0ULL ] = X [
444ULL ] ; tlu2_linear_linear_prelookup ( & qn_efOut . mField0 [ 0ULL ] , &
qn_efOut . mField1 [ 0ULL ] , & qn_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t173 = qn_efOut ; t2049 [ 0ULL ] = X [ 439ULL ] ;
tlu2_linear_linear_prelookup ( & rn_efOut . mField0 [ 0ULL ] , & rn_efOut .
mField1 [ 0ULL ] , & rn_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t57 = rn_efOut ; tlu2_2d_linear_linear_value ( & sn_efOut [ 0ULL ] , & t173
. mField0 [ 0ULL ] , & t173 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , &
t57 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
sn_efOut [ 0 ] ; t3300 = - X [ 442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 )
* X [ 439ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t3299 = (
1.0 - - X [ 442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) ) / 2.0 ; t3302 = (
- X [ 442ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) + 1.0 ) / 2.0 ; t2049 [
0ULL ] = X [ 438ULL ] ; tlu2_linear_linear_prelookup ( & tn_efOut . mField0 [
0ULL ] , & tn_efOut . mField1 [ 0ULL ] , & tn_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = tn_efOut ; tlu2_2d_linear_linear_value ( &
un_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t57 . mField0 [ 0ULL ] , & t57 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField37 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ]
) ; t2585_idx_0 = un_efOut [ 0 ] ; t3303 = t2585_idx_0 ; t2049 [ 0ULL ] = X [
438ULL ] ; tlu2_linear_nearest_prelookup ( & vn_efOut . mField0 [ 0ULL ] , &
vn_efOut . mField1 [ 0ULL ] , & vn_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t153 = vn_efOut ; t2049 [ 0ULL ] = X [ 58ULL ] ;
tlu2_linear_nearest_prelookup ( & wn_efOut . mField0 [ 0ULL ] , & wn_efOut .
mField1 [ 0ULL ] , & wn_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t88 = wn_efOut ; tlu2_2d_linear_nearest_value ( & xn_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL
] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39
, & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
xn_efOut [ 0 ] ; t3304 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 429ULL ] ;
tlu2_linear_nearest_prelookup ( & yn_efOut . mField0 [ 0ULL ] , & yn_efOut .
mField1 [ 0ULL ] , & yn_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = yn_efOut ; tlu2_2d_linear_nearest_value ( & ao_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL
] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39
, & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ao_efOut [ 0 ] ; t3305 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 59ULL ] ;
tlu2_linear_nearest_prelookup ( & bo_efOut . mField0 [ 0ULL ] , & bo_efOut .
mField1 [ 0ULL ] , & bo_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] )
; t170 = bo_efOut ; tlu2_2d_linear_nearest_value ( & co_efOut [ 0ULL ] , &
t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL
] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39
, & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
co_efOut [ 0 ] ; intrm_sf_mf_1314 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & do_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL
] , & t170 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = do_efOut [ 0 ] ; t3307 =
t2585_idx_0 ; t3308 = ( X [ 32ULL ] - X [ 59ULL ] ) * ( t2585_idx_0 *
1.6063872509454251 / 0.01 ) ; intrm_sf_mf_1350 = ( X [ 442ULL ] - X [ 434ULL
] ) / 2.0 ; tlu2_2d_linear_nearest_value ( & eo_efOut [ 0ULL ] , & t170 .
mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , &
t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
eo_efOut [ 0 ] ; intrm_sf_mf_1359 = t2585_idx_0 ; t4221 = intrm_sf_mf_1350 *
0.01 ; t4251 = t2585_idx_0 * 0.002 ; t3311 = t4221 / ( t4251 == 0.0 ? 1.0E-16
: t4251 ) ; t3312 = pmf_sqrt ( X [ 442ULL ] * X [ 442ULL ] +
5.1419576229038592E-12 ) ; t2049 [ 0ULL ] = X [ 446ULL ] ;
tlu2_linear_linear_prelookup ( & fo_efOut . mField0 [ 0ULL ] , & fo_efOut .
mField1 [ 0ULL ] , & fo_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] )
; t56 = fo_efOut ; tlu2_2d_linear_linear_value ( & go_efOut [ 0ULL ] , & t56
. mField0 [ 0ULL ] , & t56 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , &
t57 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
go_efOut [ 0 ] ; t3314 = X [ 442ULL ] / ( t3312 == 0.0 ? 1.0E-16 : t3312 ) *
X [ 439ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce10 = ( 1.0 - X [
442ULL ] / ( t3312 == 0.0 ? 1.0E-16 : t3312 ) ) / 2.0 ; t3316 = ( X [ 442ULL
] / ( t3312 == 0.0 ? 1.0E-16 : t3312 ) + 1.0 ) / 2.0 ; t3317 = pmf_sqrt ( X [
434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 ) ; t2049 [ 0ULL ] = X [
448ULL ] ; tlu2_linear_linear_prelookup ( & ho_efOut . mField0 [ 0ULL ] , &
ho_efOut . mField1 [ 0ULL ] , & ho_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t95 = ho_efOut ; tlu2_2d_linear_linear_value ( &
io_efOut [ 0ULL ] , & t95 . mField0 [ 0ULL ] , & t95 . mField2 [ 0ULL ] , &
t177 . mField0 [ 0ULL ] , & t177 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField36 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = io_efOut [ 0 ] ; t3319 = X [ 434ULL ] / ( t3317 == 0.0 ?
1.0E-16 : t3317 ) * 1.01325 / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 )
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce15 = ( 1.0 - X
[ 434ULL ] / ( t3317 == 0.0 ? 1.0E-16 : t3317 ) ) / 2.0 ; t3320 = ( X [
434ULL ] / ( t3317 == 0.0 ? 1.0E-16 : t3317 ) + 1.0 ) / 2.0 ; t2049 [ 0ULL ]
= X [ 59ULL ] ; tlu2_linear_linear_prelookup ( & jo_efOut . mField0 [ 0ULL ]
, & jo_efOut . mField1 [ 0ULL ] , & jo_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t187 = jo_efOut ; t2049 [ 0ULL ] = X [ 58ULL ] ;
tlu2_linear_linear_prelookup ( & ko_efOut . mField0 [ 0ULL ] , & ko_efOut .
mField1 [ 0ULL ] , & ko_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t55 = ko_efOut ; tlu2_2d_linear_linear_value ( & lo_efOut [ 0ULL ] , & t187
. mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , & t55 . mField0 [ 0ULL ] , &
t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
lo_efOut [ 0 ] ; t4503 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( &
mo_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , &
t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField37 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ]
) ; t2585_idx_0 = mo_efOut [ 0 ] ; t3322 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & no_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = no_efOut [ 0 ] ;
intrm_sf_mf_1296 = t2585_idx_0 ; tlu2_2d_linear_nearest_value ( & oo_efOut [
0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField40 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = oo_efOut [ 0 ] ; t4626 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & po_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = po_efOut [ 0 ] ;
intrm_sf_mf_1299 = t2585_idx_0 ; tlu2_2d_linear_nearest_value ( & qo_efOut [
0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField41 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = qo_efOut [ 0 ] ; intrm_sf_mf_1295 = t2585_idx_0 ; t3333 =
U_idx_10 * 2.0 ; t3336 = pmf_sqrt ( t3333 * t3333 + 1.2620262729050631E-10 )
; t2049 [ 0ULL ] = X [ 453ULL ] ; tlu2_linear_linear_prelookup ( & ro_efOut .
mField0 [ 0ULL ] , & ro_efOut . mField1 [ 0ULL ] , & ro_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , &
t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t54 = ro_efOut ;
tlu2_2d_linear_linear_value ( & so_efOut [ 0ULL ] , & t54 . mField0 [ 0ULL ]
, & t54 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = so_efOut [ 0 ] ; t3337 =
t2585_idx_0 ; t3338 = t3333 / ( t3336 == 0.0 ? 1.0E-16 : t3336 ) * 1.01325 /
( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t3339 = ( 1.0 - t3333 / (
t3336 == 0.0 ? 1.0E-16 : t3336 ) ) / 2.0 ; t3340 = ( t3333 / ( t3336 == 0.0 ?
1.0E-16 : t3336 ) + 1.0 ) / 2.0 ; t2049 [ 0ULL ] = X [ 455ULL ] ;
tlu2_linear_linear_prelookup ( & to_efOut . mField0 [ 0ULL ] , & to_efOut .
mField1 [ 0ULL ] , & to_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] )
; t53 = to_efOut ; t2049 [ 0ULL ] = X [ 451ULL ] ;
tlu2_linear_linear_prelookup ( & uo_efOut . mField0 [ 0ULL ] , & uo_efOut .
mField1 [ 0ULL ] , & uo_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t51 = uo_efOut ; tlu2_2d_linear_linear_value ( & vo_efOut [ 0ULL ] , & t53
. mField0 [ 0ULL ] , & t53 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , &
t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
vo_efOut [ 0 ] ; intrm_sf_mf_1524 = t2585_idx_0 ; t3342 = - t3333 / ( t3336
== 0.0 ? 1.0E-16 : t3336 ) * X [ 451ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 :
t2585_idx_0 ) ; t3343 = ( 1.0 - - t3333 / ( t3336 == 0.0 ? 1.0E-16 : t3336 )
) / 2.0 ; t3344 = ( - t3333 / ( t3336 == 0.0 ? 1.0E-16 : t3336 ) + 1.0 ) /
2.0 ; t2049 [ 0ULL ] = X [ 450ULL ] ; tlu2_linear_linear_prelookup ( &
wo_efOut . mField0 [ 0ULL ] , & wo_efOut . mField1 [ 0ULL ] , & wo_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [
0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t178 = wo_efOut ;
tlu2_2d_linear_linear_value ( & xo_efOut [ 0ULL ] , & t178 . mField0 [ 0ULL ]
, & t178 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xo_efOut [ 0 ] ; t3345 =
t2585_idx_0 ; t3337 = ( t3337 + intrm_sf_mf_1524 ) / 2.0 ; t3335 = ( X [
451ULL ] - 1.01325 ) * ( U_idx_10 * 2.0 ) / ( t3337 == 0.0 ? 1.0E-16 : t3337
) ; t2049 [ 0ULL ] = X [ 450ULL ] ; tlu2_linear_nearest_prelookup ( &
yo_efOut . mField0 [ 0ULL ] , & yo_efOut . mField1 [ 0ULL ] , & yo_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [
0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] ) ; t55 = yo_efOut ; t2049 [ 0ULL
] = X [ 60ULL ] ; tlu2_linear_nearest_prelookup ( & ap_efOut . mField0 [ 0ULL
] , & ap_efOut . mField1 [ 0ULL ] , & ap_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL
] , & t225 [ 0ULL ] ) ; t187 = ap_efOut ; tlu2_2d_linear_nearest_value ( &
bp_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , &
t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField39 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = bp_efOut [ 0 ] ; t3337 = t2585_idx_0 ; t2049 [ 0ULL ] = X
[ 436ULL ] ; tlu2_linear_nearest_prelookup ( & cp_efOut . mField0 [ 0ULL ] ,
& cp_efOut . mField1 [ 0ULL ] , & cp_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t153 = cp_efOut ; tlu2_2d_linear_nearest_value ( &
dp_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , &
t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField39 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = dp_efOut [ 0 ] ; intrm_sf_mf_1524 = t2585_idx_0 ; t2049 [
0ULL ] = X [ 61ULL ] ; tlu2_linear_nearest_prelookup ( & ep_efOut . mField0 [
0ULL ] , & ep_efOut . mField1 [ 0ULL ] , & ep_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = ep_efOut ; tlu2_2d_linear_nearest_value ( &
fp_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField39 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = fp_efOut [ 0 ] ; t3346 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & gp_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t1006 [ 0ULL ] ,
& t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gp_efOut [ 0 ] ; t3347 =
t2585_idx_0 ; t3348 = ( X [ 62ULL ] - X [ 61ULL ] ) * ( t2585_idx_0 *
1.3250000000000002 / 0.0028301886792452828 ) ; intrm_sf_mf_1569 = ( t3333 - (
- X [ 442ULL ] ) ) / 2.0 ; tlu2_2d_linear_nearest_value ( & hp_efOut [ 0ULL ]
, & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t187 . mField0 [
0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField41 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = hp_efOut [ 0 ] ; t3350 = t2585_idx_0 ; t2815 = intrm_sf_mf_1569
* 0.0028301886792452828 ; zc_int350 = t2585_idx_0 * 0.00093750000000000007 ;
t4823 = t2815 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ; t3355 = pmf_sqrt
( t3333 * t3333 + 2.4102926357361849E-12 ) ; t2049 [ 0ULL ] = X [ 456ULL ] ;
tlu2_linear_linear_prelookup ( & ip_efOut . mField0 [ 0ULL ] , & ip_efOut .
mField1 [ 0ULL ] , & ip_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL ] , & t225 [ 0ULL ] )
; t77 = ip_efOut ; tlu2_2d_linear_linear_value ( & jp_efOut [ 0ULL ] , & t77
. mField0 [ 0ULL ] , & t77 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , &
t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
jp_efOut [ 0 ] ; t3360 = t3333 / ( t3355 == 0.0 ? 1.0E-16 : t3355 ) * X [
451ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 : t2585_idx_0 ) ; t3359 = ( 1.0 -
t3333 / ( t3355 == 0.0 ? 1.0E-16 : t3355 ) ) / 2.0 ; t3362 = ( t3333 / (
t3355 == 0.0 ? 1.0E-16 : t3355 ) + 1.0 ) / 2.0 ; t3364 = pmf_sqrt ( X [
442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 ) ; t2049 [ 0ULL ] = X [
458ULL ] ; tlu2_linear_linear_prelookup ( & kp_efOut . mField0 [ 0ULL ] , &
kp_efOut . mField1 [ 0ULL ] , & kp_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t88 = kp_efOut ; tlu2_2d_linear_linear_value ( &
lp_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , &
t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ]
) ; t2585_idx_0 = lp_efOut [ 0 ] ; t3370 = - X [ 442ULL ] / ( t3364 == 0.0 ?
1.0E-16 : t3364 ) * X [ 437ULL ] / ( t2585_idx_0 == 0.0 ? 1.0E-16 :
t2585_idx_0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato15 = ( 1.0 - - X
[ 442ULL ] / ( t3364 == 0.0 ? 1.0E-16 : t3364 ) ) / 2.0 ; t3371 = ( - X [
442ULL ] / ( t3364 == 0.0 ? 1.0E-16 : t3364 ) + 1.0 ) / 2.0 ; t2049 [ 0ULL ]
= X [ 61ULL ] ; tlu2_linear_linear_prelookup ( & mp_efOut . mField0 [ 0ULL ]
, & mp_efOut . mField1 [ 0ULL ] , & mp_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t2049 [ 0ULL ] , & t1006 [ 0ULL
] , & t225 [ 0ULL ] ) ; t3 = mp_efOut ; t2049 [ 0ULL ] = X [ 60ULL ] ;
tlu2_linear_linear_prelookup ( & np_efOut . mField0 [ 0ULL ] , & np_efOut .
mField1 [ 0ULL ] , & np_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t2049 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = np_efOut ; tlu2_2d_linear_linear_value ( & op_efOut [ 0ULL ] , & t3 .
mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t1006
[ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = op_efOut [ 0
] ; t4576 = t2585_idx_0 ; tlu2_2d_linear_linear_value ( & pp_efOut [ 0ULL ] ,
& t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 ,
& t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
pp_efOut [ 0 ] ; t3374 = t2585_idx_0 ; tlu2_2d_linear_nearest_value ( &
qp_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , &
t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField40 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = qp_efOut [ 0 ] ; t4628 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & rp_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t1006 [ 0ULL ] ,
& t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = rp_efOut [ 0 ] ;
intrm_sf_mf_1748 = t2585_idx_0 ; tlu2_2d_linear_nearest_value ( & sp_efOut [
0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , & t187 .
mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField41 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = sp_efOut [ 0 ] ; t3382 = t2585_idx_0 ;
tlu2_2d_linear_nearest_value ( & tp_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t1006 [ 0ULL ] ,
& t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = tp_efOut [ 0 ] ; t4747 =
t2585_idx_0 ; if ( X [ 461ULL ] < 0.0 ) { t3386 = X [ 461ULL ] * 17.81 +
0.043 ; } else if ( X [ 461ULL ] <= 1.0 ) { t3386 = ( ( X [ 461ULL ] * 17.81
+ 0.043 ) - X [ 461ULL ] * X [ 461ULL ] * 39.85 ) + X [ 461ULL ] * X [ 461ULL
] * X [ 461ULL ] * 36.0 ; } else { t3386 = ( X [ 461ULL ] - 1.0 ) * 1.4 +
14.003 ; } if ( X [ 462ULL ] < 0.0 ) { U_idx_3 = X [ 462ULL ] * 17.81 + 0.043
; } else if ( X [ 462ULL ] <= 1.0 ) { U_idx_3 = ( ( X [ 462ULL ] * 17.81 +
0.043 ) - X [ 462ULL ] * X [ 462ULL ] * 39.85 ) + X [ 462ULL ] * X [ 462ULL ]
* X [ 462ULL ] * 36.0 ; } else { U_idx_3 = ( X [ 462ULL ] - 1.0 ) * 1.4 +
14.003 ; } t3392 = pmf_exp ( ( 0.003298697014679202 - 1.0 / ( X [ 32ULL ] ==
0.0 ? 1.0E-16 : X [ 32ULL ] ) ) * 2416.0 ) * 1.25E-10 ; if ( X [ 173ULL ] <=
0.0 ) { t3393 = - X [ 173ULL ] / 0.028 ; } else { t3393 = 0.0 ; } t3394 =
t3393 * 0.20177105219743391 / 192970.66424 ; if ( t3386 >= 0.0 ) { t3391 =
t3386 * t3386 * 0.0029 + t3386 * 0.05 ; } else { t3391 = t3386 * 0.05 ; }
t3391 = t3393 * t3391 / 96485.33212 ; t2049 [ 0ULL ] = X [ 32ULL ] ;
tlu2_linear_nearest_prelookup ( & up_efOut . mField0 [ 0ULL ] , & up_efOut .
mField1 [ 0ULL ] , & up_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t45 = up_efOut ; tlu2_1d_linear_nearest_value ( & vp_efOut [ 0ULL ] , & t45
. mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
vp_efOut [ 0 ] ; t2638 = ( X [ 230ULL ] + X [ 235ULL ] ) / 2.0 ; t2646 = ( X
[ 354ULL ] + X [ 359ULL ] ) / 2.0 ; t2049 [ 0ULL ] = X [ 32ULL ] ;
tlu2_linear_linear_prelookup ( & wp_efOut . mField0 [ 0ULL ] , & wp_efOut .
mField1 [ 0ULL ] , & wp_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t193 = wp_efOut ; tlu2_1d_linear_linear_value ( & xp_efOut [ 0ULL ] , &
t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t1941 [ 0 ] =
xp_efOut [ 0 ] ; t2681 = pmf_exp ( pmf_log ( t2638 ) - t1941 [ 0ULL ] ) ;
t2689 = X [ 461ULL ] / ( t2681 == 0.0 ? 1.0E-16 : t2681 ) ; t2681 = pmf_exp (
pmf_log ( t2646 ) - t1941 [ 0ULL ] ) ; t3395 = X [ 462ULL ] / ( t2681 == 0.0
? 1.0E-16 : t2681 ) ; if ( t2638 > t2646 ) { U_idx_1 = t2585_idx_0 * X [
32ULL ] * 0.001039307827269155 ; t3396 = ( t2638 - t2646 ) * t2638 * t2689 *
1.58E-18 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else { t3754 =
t2585_idx_0 * X [ 32ULL ] * 0.001039307827269155 ; t3396 = ( t2638 - t2646 )
* t2646 * t3395 * 1.58E-18 / ( t3754 == 0.0 ? 1.0E-16 : t3754 ) ; } t3392 = (
( ( t3386 * 1818.181818181818 - U_idx_3 * 1818.181818181818 ) * t3392 /
0.000125 + t3391 ) + t3396 ) * 0.20177105219743391 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 = t3393 *
0.022577863652674921 / 192970.66424 ; t3391 = t3393 * 0.3583866814737065 /
385941.32848 ; t3386 = ( t3386 + U_idx_3 ) / 2.0 ; if ( t3386 >= 1.0 ) {
U_idx_3 = t3386 * 0.005139 - 0.00326 ; } else { U_idx_3 =
0.0018790000000000005 ; } t3386 = pmf_exp ( ( 0.003298697014679202 - 1.0 / (
X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) ) * 1268.0 ) * U_idx_3 ; U_idx_3
= 0.000125 / ( t3386 == 0.0 ? 1.0E-16 : t3386 ) ; t3396 = t2681 * ( ( X [
356ULL ] + X [ 361ULL ] ) / 2.0 ) ; t3386 = t3396 >= 1.0E-9 ? t3396 : 1.0E-6
; t2681 = t2638 * ( ( X [ 234ULL ] + X [ 239ULL ] ) / 2.0 ) / 1.01325 ; if (
t2681 * 1.0E-5 >= 1.0E-9 ) { t3396 = t2681 * 1.0E-5 ; } else { t3396 = 1.0E-6
; } t2681 = t2646 * ( ( X [ 358ULL ] + X [ 363ULL ] ) / 2.0 ) / 1.01325 ; if
( t2681 * 1.0E-5 >= 1.0E-9 ) { t3397 = t2681 * 1.0E-5 ; } else { t3397 =
1.0E-6 ; } t3708 = X [ 32ULL ] * 8.31446261815324 ; t2638 = ( X [ 237ULL ] -
t2689 ) * ( t2638 * 7.0000000000000007E-6 / ( t3708 == 0.0 ? 1.0E-16 : t3708
) ) / 0.00025 ; t2646 = ( t3395 - X [ 361ULL ] ) * ( t2646 *
7.0000000000000007E-6 / ( t3708 == 0.0 ? 1.0E-16 : t3708 ) ) / 0.00025 ; if (
t3393 >= 1.0 ) { t2689 = pmf_log ( t3393 ) * ( t3708 / 135079.46496800001 ) ;
} else { t2689 = 0.0 ; } if ( t3393 <= 13986.0 ) { t194 = pmf_log ( 1.0 -
t3393 / 14000.0 ) ; } else { t194 = - 6.9077552789821359 - ( t3393 / 14000.0
- 0.999 ) / 0.0010000000000000009 ; } t2681 = X [ 32ULL ] * -
8.31446261815324 / 192970.66424 * t194 ; t3718 = pmf_sqrt ( t3397 ) * t3396 ;
t3395 = t3708 / 192970.66424 * pmf_log ( t3718 / ( t3386 == 0.0 ? 1.0E-16 :
t3386 ) ) + 1.228891453185164 ; t3396 = U_idx_3 * t3393 ; t3395 = t3393 * ( (
( t3395 - t2689 ) - t3396 * 0.01 ) - t2681 ) * 11.200000000000001 ; t3393 = -
X [ 465ULL ] + X [ 402ULL ] ; t2049 [ 0ULL ] = X [ 63ULL ] ;
tlu2_linear_linear_prelookup ( & yp_efOut . mField0 [ 0ULL ] , & yp_efOut .
mField1 [ 0ULL ] , & yp_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = yp_efOut ; tlu2_1d_linear_linear_value ( & aq_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
aq_efOut [ 0 ] ; t3397 = t2585_idx_0 ; tlu2_1d_linear_linear_value ( &
bq_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField19 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = bq_efOut [ 0 ] ; t194 = t2585_idx_0 ; if ( X [ 66ULL
] <= 0.0 ) { t3399 = 0.0 ; } else { t3399 = X [ 66ULL ] >= 1.0 ? 1.0 : X [
66ULL ] ; } if ( X [ 65ULL ] <= 0.0 ) { t3400 = 0.0 ; } else { t3400 = X [
65ULL ] >= 1.0 ? 1.0 : X [ 65ULL ] ; } t3401 = ( ( ( 1.0 - t3399 ) - t3400 )
* 296.802103844292 + t3399 * 461.523 ) + t3400 * 4124.48151675695 ; t3721 = X
[ 63ULL ] * t3401 ; if ( 1.0 - X [ 66ULL ] >= 0.01 ) { t3403 = 1.0 - X [
66ULL ] ; } else if ( 1.0 - X [ 66ULL ] >= - 0.1 ) { t3403 = pmf_exp ( ( (
1.0 - X [ 66ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t3403 =
1.6701700790245661E-7 ; } t4812 = X [ 65ULL ] / ( t3403 == 0.0 ? 1.0E-16 :
t3403 ) * 3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value
( & cq_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = cq_efOut [ 0 ] ; t3405 = pmf_exp ( pmf_log ( X [
64ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3405 >= 1.0 ) { t3754 = ( t3405
- 1.0 ) * 461.523 + t4812 ; t3406 = t4812 / ( t3754 == 0.0 ? 1.0E-16 : t3754
) ; } else { t3406 = 1.0 ; } U_idx_1 = t3406 * 0.01 ; t4812 = ( X [ 66ULL ] -
t3406 ) / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; if ( X [ 66ULL ] - t3406
<= 0.0 ) { t4812 = 0.0 ; } else if ( X [ 66ULL ] - t3406 >= t3406 * 0.01 ) {
t4812 = X [ 66ULL ] - t3406 ; } else { t4812 = ( X [ 66ULL ] - t3406 ) * (
t4812 * t4812 * 3.0 - t4812 * t4812 * t4812 * 2.0 ) ; } t4815 = X [ 64ULL ] /
( t3721 == 0.0 ? 1.0E-16 : t3721 ) * t4812 * 0.12 / 0.001 ; t4812 = ( t3397 -
t194 ) * t4815 ; t194 = pmf_sqrt ( X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) ; t3406 = pmf_sqrt ( X [ 478ULL ] * X [ 478ULL ] +
2.0914103314136477E-13 ) ; t3407 = pmf_sqrt ( X [ 478ULL ] * X [ 478ULL ] +
1.4768645655431184E-13 ) ; tlu2_1d_linear_linear_value ( & dq_efOut [ 0ULL ]
, & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = dq_efOut [ 0 ] ; t3408 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & eq_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = eq_efOut [ 0 ] ; t3411 =
X [ 478ULL ] - t4815 * 100000.0 ; t3412 = X [ 480ULL ] - t4815 * 100000.0 ;
t3414 = ( ( ( 1.0 - t3399 ) - t3400 ) * t3408 + t3397 * t3399 ) + t2585_idx_0
* t3400 ; t3416 = t3408 - X [ 63ULL ] * 0.296802103844292 ; t3408 =
t2585_idx_0 - X [ 63ULL ] * 4.12448151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T22 = t3397 - X [
63ULL ] * 0.461523 ; if ( X [ 69ULL ] <= 0.0 ) { t3397 = 0.0 ; } else { t3397
= X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <= 0.0 ) {
t3417 = 0.0 ; } else { t3417 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; }
t3418 = ( ( ( 1.0 - t3397 ) - t3417 ) * 296.802103844292 + t3397 * 461.523 )
+ t3417 * 4124.48151675695 ; t4534 = - ( ( X [ 67ULL ] / ( X [ 68ULL ] == 0.0
? 1.0E-16 : X [ 68ULL ] ) - X [ 488ULL ] / ( X [ 489ULL ] == 0.0 ? 1.0E-16 :
X [ 489ULL ] ) ) * X [ 478ULL ] * t3418 ) / 7.8539816339744827E-5 ; if ( X [
488ULL ] <= 216.59999999999997 ) { t4548 = 216.59999999999997 ; } else {
t4548 = X [ 488ULL ] >= 623.15 ? 623.15 : X [ 488ULL ] ; } t2717 = t4548 *
t4548 ; t4581 = ( ( ( 1074.1165326382554 + t4548 * - 0.22145652610641059 ) +
t2717 * 0.0003721298010901061 ) * ( ( 1.0 - t3397 ) - t3417 ) + ( (
1479.6504774710402 + t4548 * 1.2002114337050787 ) + t2717 * -
0.00038614513167845434 ) * t3397 ) + ( ( 12825.281119789837 + t4548 *
6.9647057412840034 ) + t2717 * - 0.0070524868246844051 ) * t3417 ; t3734 =
t4581 - t3418 ; t4548 = t4581 / ( t3734 == 0.0 ? 1.0E-16 : t3734 ) ; t4581 =
pmf_sqrt ( t4534 * t4534 * 9.999999999999999E-14 + fabs ( X [ 488ULL ] *
t4548 * t3418 ) * 1.0E-9 ) ; if ( X [ 490ULL ] <= 0.0 ) { t2717 = 0.0 ; }
else { t2717 = X [ 490ULL ] >= 1.0 ? 1.0 : X [ 490ULL ] ; } if ( X [ 491ULL ]
<= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 =
0.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 = X [ 491ULL
] >= 1.0 ? 1.0 : X [ 491ULL ] ; } t2049 [ 0ULL ] = X [ 67ULL ] ;
tlu2_linear_nearest_prelookup ( & fq_efOut . mField0 [ 0ULL ] , & fq_efOut .
mField1 [ 0ULL ] , & fq_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = fq_efOut ; tlu2_1d_linear_nearest_value ( & gq_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
gq_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & hq_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = hq_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & iq_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField17 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = iq_efOut [ 0
] ; t4641 = ( ( ( 1.0 - t2717 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ) *
t2585_idx_0 + t2586_idx_0 * t2717 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ; t3734 = X [
489ULL ] * X [ 489ULL ] * t4548 ; t4803 = - pmf_sqrt ( fabs ( t3734 / ( t3418
== 0.0 ? 1.0E-16 : t3418 ) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] )
) ) * 7.8539816339744827E-5 ; if ( t4803 >= 0.0 ) { t3427 = t4803 * 100000.0
; } else { t3427 = - t4803 * 100000.0 ; } t3738 = t4641 *
7.8539816339744827E-5 ; t4813 = t3427 * 0.01 / ( t3738 == 0.0 ? 1.0E-16 :
t3738 ) ; t3740 = X [ 67ULL ] * t3418 ; t3429 = X [ 68ULL ] / ( t3740 == 0.0
? 1.0E-16 : t3740 ) ; t3742 = t3429 * 1.5707963267948965E-8 ; t4658 = t4803 *
t4641 * 35.2 / ( t3742 == 0.0 ? 1.0E-16 : t3742 ) ; t4677 = t4813 >= 1.0 ?
t4813 : 1.0 ; U_idx_1 = pmf_log10 ( 6.9 / ( t4677 == 0.0 ? 1.0E-16 : t4677 )
+ 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t4677 == 0.0 ? 1.0E-16 :
t4677 ) + 0.00017169489553429715 ) * 3.24 ; t3745 = t3429 *
1.2337005501361697E-10 ; t3427 = t4803 * t3427 * ( 1.0 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ) * 0.55 / ( t3745 == 0.0 ? 1.0E-16 : t3745 ) ; t4677 = (
t4813 - 2000.0 ) / 2000.0 ; t3432 = t4677 * t4677 * 3.0 - t4677 * t4677 *
t4677 * 2.0 ; if ( t4813 <= 2000.0 ) { t4677 = t4658 * 1.0E-5 ; } else if (
t4813 >= 4000.0 ) { t4677 = t3427 * 1.0E-5 ; } else { t4677 = ( ( 1.0 - t3432
) * t4658 + t3427 * t3432 ) * 1.0E-5 ; } t4581 = - ( X [ 478ULL ] * t4581 ) /
7.8539816339744827E-5 * 0.00031622776601683789 + t4677 ; t3427 = X [ 485ULL ]
- X [ 68ULL ] ; t4658 = ( X [ 67ULL ] / ( X [ 68ULL ] == 0.0 ? 1.0E-16 : X [
68ULL ] ) - X [ 493ULL ] / ( X [ 494ULL ] == 0.0 ? 1.0E-16 : X [ 494ULL ] ) )
* X [ 492ULL ] * t3418 / 7.8539816339744827E-5 ; if ( X [ 493ULL ] <=
216.59999999999997 ) { t4677 = 216.59999999999997 ; } else { t4677 = X [
493ULL ] >= 623.15 ? 623.15 : X [ 493ULL ] ; } t4766 = t4677 * t4677 ; t3432
= ( ( ( 1074.1165326382554 + t4677 * - 0.22145652610641059 ) + t4766 *
0.0003721298010901061 ) * ( ( 1.0 - t3397 ) - t3417 ) + ( (
1479.6504774710402 + t4677 * 1.2002114337050787 ) + t4766 * -
0.00038614513167845434 ) * t3397 ) + ( ( 12825.281119789837 + t4677 *
6.9647057412840034 ) + t4766 * - 0.0070524868246844051 ) * t3417 ; t3754 =
t3432 - t3418 ; t4677 = t3432 / ( t3754 == 0.0 ? 1.0E-16 : t3754 ) ; t3432 =
pmf_sqrt ( t4658 * t4658 * 9.999999999999999E-14 + fabs ( X [ 493ULL ] *
t4677 * t3418 ) * 1.0E-9 ) ; t3754 = X [ 494ULL ] * X [ 494ULL ] * t4677 ;
t4766 = - pmf_sqrt ( fabs ( t3754 / ( t3418 == 0.0 ? 1.0E-16 : t3418 ) / ( X
[ 493ULL ] == 0.0 ? 1.0E-16 : X [ 493ULL ] ) ) ) * 7.8539816339744827E-5 ; if
( t4766 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 = t4766 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 = - t4766 *
100000.0 ; } t4703 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 * 0.01 / (
t3738 == 0.0 ? 1.0E-16 : t3738 ) ; t4716 = t4766 * t4641 * 35.2 / ( t3742 ==
0.0 ? 1.0E-16 : t3742 ) ; t3438 = t4703 >= 1.0 ? t4703 : 1.0 ; U_idx_3 =
pmf_log10 ( 6.9 / ( t3438 == 0.0 ? 1.0E-16 : t3438 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t3438 == 0.0 ? 1.0E-16 : t3438 ) +
0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 = t4766 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 * ( 1.0 / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * 0.55 / ( t3745 == 0.0 ? 1.0E-16 :
t3745 ) ; t3438 = ( t4703 - 2000.0 ) / 2000.0 ; t3439 = t3438 * t3438 * 3.0 -
t3438 * t3438 * t3438 * 2.0 ; if ( t4703 <= 2000.0 ) { t3438 = t4716 * 1.0E-5
; } else if ( t4703 >= 4000.0 ) { t3438 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 * 1.0E-5 ; }
else { t3438 = ( ( 1.0 - t3439 ) * t4716 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 * t3439 ) *
1.0E-5 ; } t3432 = X [ 492ULL ] * t3432 / 7.8539816339744827E-5 *
0.00031622776601683789 + t3438 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 = X [ 38ULL ]
- X [ 68ULL ] ; t2049 [ 0ULL ] = X [ 67ULL ] ; tlu2_linear_linear_prelookup (
& jq_efOut . mField0 [ 0ULL ] , & jq_efOut . mField1 [ 0ULL ] , & jq_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t153 = jq_efOut ;
tlu2_1d_linear_linear_value ( & kq_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = kq_efOut [ 0 ] ; t4716 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & lq_efOut [ 0ULL ] , & t153 .
mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField19 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
lq_efOut [ 0 ] ; t3438 = t2585_idx_0 ; if ( 1.0 - X [ 69ULL ] >= 0.01 ) {
t3440 = 1.0 - X [ 69ULL ] ; } else if ( 1.0 - X [ 69ULL ] >= - 0.1 ) { t3440
= pmf_exp ( ( ( 1.0 - X [ 69ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t3440
= 1.6701700790245661E-7 ; } t3439 = X [ 70ULL ] / ( t3440 == 0.0 ? 1.0E-16 :
t3440 ) * 3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value
( & mq_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = mq_efOut [ 0 ] ; t3441 = pmf_exp ( pmf_log ( X [
68ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3441 >= 1.0 ) { U_idx_3 = (
t3441 - 1.0 ) * 461.523 + t3439 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 = t3439 / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 = 1.0 ; }
t3819 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 * 0.01
; t3439 = ( X [ 69ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 ) / ( t3819 ==
0.0 ? 1.0E-16 : t3819 ) ; if ( X [ 69ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 <= 0.0 ) {
t3439 = 0.0 ; } else if ( X [ 69ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 * 0.01 ) {
t3439 = X [ 69ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 ; } else {
t3439 = ( X [ 69ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 ) * ( t3439 *
t3439 * 3.0 - t3439 * t3439 * t3439 * 2.0 ) ; } t3429 = t3429 * t3439 *
7.8539816339744827E-5 / 0.001 ; t3439 = ( t4716 - t3438 ) * t3429 ;
tlu2_1d_linear_nearest_value ( & nq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = nq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & oq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = oq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & pq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = pq_efOut [ 0 ] ; t3438 =
( ( ( 1.0 - t2717 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ) *
t2585_idx_0 + t2586_idx_0 * t2717 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 = ( X [ 483ULL
] - X [ 67ULL ] ) * ( t3438 * 0.031415926535897927 / 0.01 ) ; if ( X [ 487ULL
] <= 0.0 ) { t4785 = 0.0 ; } else { t4785 = X [ 487ULL ] >= 1.0 ? 1.0 : X [
487ULL ] ; } if ( X [ 486ULL ] <= 0.0 ) { t4726 = 0.0 ; } else { t4726 = X [
486ULL ] >= 1.0 ? 1.0 : X [ 486ULL ] ; } t4510 = ( ( ( 1.0 - t4785 ) - t4726
) * 296.802103844292 + t4785 * 461.523 ) + t4726 * 4124.48151675695 ;
intrm_sf_mf_1462 = X [ 487ULL ] * 461.523 / ( t4510 == 0.0 ? 1.0E-16 : t4510
) ; if ( intrm_sf_mf_1462 <= 0.0 ) { t4729 = 0.0 ; } else { t4729 =
intrm_sf_mf_1462 >= 1.0 ? 1.0 : intrm_sf_mf_1462 ; } intrm_sf_mf_1462 = X [
486ULL ] * 4124.48151675695 / ( t4510 == 0.0 ? 1.0E-16 : t4510 ) ; if (
intrm_sf_mf_1462 <= 0.0 ) { t4517 = 0.0 ; } else { t4517 = intrm_sf_mf_1462
>= 1.0 ? 1.0 : intrm_sf_mf_1462 ; } t2049 [ 0ULL ] = X [ 484ULL ] ;
tlu2_linear_nearest_prelookup ( & qq_efOut . mField0 [ 0ULL ] , & qq_efOut .
mField1 [ 0ULL ] , & qq_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = qq_efOut ; tlu2_1d_linear_nearest_value ( & rq_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
rq_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & sq_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
sq_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & tq_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
tq_efOut [ 0 ] ; intrm_sf_mf_1462 = ( ( ( 1.0 - t4729 ) - t4517 ) *
t2585_idx_0 + t2586_idx_0 * t4729 ) + t2587_idx_0 * t4517 ;
tlu2_1d_linear_nearest_value ( & uq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = uq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & vq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = vq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & wq_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = wq_efOut [ 0 ] ; t3453 =
( ( ( 1.0 - t2717 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ) *
t2585_idx_0 + t2586_idx_0 * t2717 ) + t2587_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ;
tlu2_1d_linear_nearest_value ( & xq_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & yq_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = yq_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ar_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ar_efOut [ 0 ] ; t2717
= ( ( ( 1.0 - t4729 ) - t4517 ) * t2585_idx_0 + t2586_idx_0 * t4729 ) +
t2587_idx_0 * t4517 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 = ( - X [
478ULL ] - X [ 492ULL ] ) / 2.0 ; tlu2_1d_linear_nearest_value ( & br_efOut [
0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = br_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
cr_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = cr_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
dr_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField17 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = dr_efOut [ 0 ] ; U_idx_1 = ( t4641 + ( ( ( ( 1.0 -
t4729 ) - t4517 ) * t2585_idx_0 + t2586_idx_0 * t4729 ) + t2587_idx_0 * t4517
) ) / 2.0 * 7.8539816339744827E-5 ; t4729 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 : 0.0 ) *
0.01 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; t4517 = t4729 >= 0.0 ? t4729
: - t4729 ; t3454 = t4517 > 1000.0 ? t4517 : 1000.0 ; U_idx_3 =
intrm_sf_mf_1462 + t3453 ; if ( U_idx_3 / 2.0 > 0.5 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = (
intrm_sf_mf_1462 + t3453 ) / 2.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = 0.5 ; }
t3819 = pmf_log10 ( 6.9 / ( t3454 == 0.0 ? 1.0E-16 : t3454 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3454 == 0.0 ? 1.0E-16 : t3454
) + 0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 = 1.0 / (
t3819 == 0.0 ? 1.0E-16 : t3819 ) ; U_idx_1 = ( pmf_pow (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 / 8.0 ) *
12.7 + 1.0 ; t3454 = ( t3454 - 1000.0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 / 8.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 / ( U_idx_1
== 0.0 ? 1.0E-16 : U_idx_1 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = ( t4517 -
2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 * 2.0 ; if (
t4517 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = 3.66 ; }
else if ( t4517 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = t3454 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) *
3.66 + t3454 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ; } t3819 =
U_idx_3 / 2.0 ; if ( t4517 >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 *
0.031415926535897927 / 7.8539816339744827E-5 / ( t3819 == 0.0 ? 1.0E-16 :
t3819 ) / 30.0 ) { U_idx_1 = ( intrm_sf_mf_1462 + t3453 ) / 2.0 ; t3454 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 *
0.031415926535897927 / ( t4517 == 0.0 ? 1.0E-16 : t4517 ) /
7.8539816339744827E-5 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else {
t3454 = 30.0 ; } intrm_sf_mf_1462 = ( X [ 483ULL ] - X [ 484ULL ] ) * ( 1.0 -
pmf_exp ( - t3454 ) ) ; t2717 = t4729 * 7.8539816339744827E-5 / 0.01 * (
U_idx_3 / 2.0 ) * ( ( t2717 + t3438 ) / 2.0 ) * intrm_sf_mf_1462 ; if ( X [
468ULL ] <= 0.0 ) { intrm_sf_mf_1462 = 0.0 ; } else { intrm_sf_mf_1462 = X [
468ULL ] >= 1.0 ? 1.0 : X [ 468ULL ] ; } if ( X [ 467ULL ] <= 0.0 ) { t4729 =
0.0 ; } else { t4729 = X [ 467ULL ] >= 1.0 ? 1.0 : X [ 467ULL ] ; } t4517 = (
( ( 1.0 - intrm_sf_mf_1462 ) - t4729 ) * 296.802103844292 + intrm_sf_mf_1462
* 461.523 ) + t4729 * 4124.48151675695 ; t3454 = X [ 468ULL ] * 461.523 / (
t4517 == 0.0 ? 1.0E-16 : t4517 ) ; if ( t3454 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 =
t3454 >= 1.0 ? 1.0 : t3454 ; } t3454 = X [ 467ULL ] * 4124.48151675695 / (
t4517 == 0.0 ? 1.0E-16 : t4517 ) ; if ( t3454 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 =
t3454 >= 1.0 ? 1.0 : t3454 ; } t2049 [ 0ULL ] = X [ 466ULL ] ;
tlu2_linear_nearest_prelookup ( & er_efOut . mField0 [ 0ULL ] , & er_efOut .
mField1 [ 0ULL ] , & er_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = er_efOut ; tlu2_1d_linear_nearest_value ( & fr_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField23 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
fr_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & gr_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField24 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = gr_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & hr_efOut [ 0ULL ] , & t99 . mField0
[ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField25 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = hr_efOut [ 0
] ; t3454 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21
; tlu2_1d_linear_nearest_value ( & ir_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL
] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ir_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jr_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = jr_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & kr_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = kr_efOut [ 0 ] ; t3462 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21
; tlu2_1d_linear_nearest_value ( & lr_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL
] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = lr_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & mr_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = mr_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & nr_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = nr_efOut [ 0 ] ; U_idx_1
= ( t4641 + ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) +
t2587_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21
) ) / 2.0 * 7.8539816339744827E-5 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 <= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 : 0.0 ) *
0.01 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 > 1000.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 : 1000.0 ;
U_idx_3 = t3453 + t3454 ; if ( U_idx_3 / 2.0 > 0.5 ) { t3464 = ( t3453 +
t3454 ) / 2.0 ; } else { t3464 = 0.5 ; } t3819 = pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) +
0.00017169489553429715 ) * 3.24 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 = 1.0 / (
t3819 == 0.0 ? 1.0E-16 : t3819 ) ; U_idx_1 = ( pmf_pow ( t3464 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 / 8.0 ) *
12.7 + 1.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21
= ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 - 1000.0
) * ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 / 8.0 )
* t3464 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; t3464 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 - 2000.0 ) /
2000.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 =
t3464 * t3464 * 3.0 - t3464 * t3464 * t3464 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 <= 2000.0 ) {
t3464 = 3.66 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 >= 4000.0 ) {
t3464 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ; }
else { t3464 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 ) * 3.66 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 ; } t3819 =
U_idx_3 / 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 > t3464 *
0.031415926535897927 / 7.8539816339744827E-5 / ( t3819 == 0.0 ? 1.0E-16 :
t3819 ) / 30.0 ) { U_idx_1 = ( t3453 + t3454 ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 = t3464 *
0.031415926535897927 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) /
7.8539816339744827E-5 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 = 30.0 ; }
t3453 = ( X [ 483ULL ] - X [ 466ULL ] ) * ( 1.0 - pmf_exp ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) ) ; t3438 =
t2717 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 *
7.8539816339744827E-5 / 0.01 * ( U_idx_3 / 2.0 ) * ( ( t3438 + t3462 ) / 2.0
) * t3453 ; t2717 = pmf_sqrt ( X [ 478ULL ] * X [ 478ULL ] +
2.0360111955237585E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 = pmf_sqrt (
X [ 478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 ) ; t3453 = pmf_sqrt ( X
[ 478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 ) ; t3454 = pmf_sqrt ( X [
492ULL ] * X [ 492ULL ] + 2.0360111955237585E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 = pmf_sqrt (
X [ 492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 = pmf_sqrt (
X [ 492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 ) ;
tlu2_1d_linear_linear_value ( & or_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL ]
, & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = or_efOut [ 0 ] ; t3462 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & pr_efOut [ 0ULL ] , & t153 .
mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
pr_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 = - X [
479ULL ] + X [ 502ULL ] ; t3467 = ( - X [ 478ULL ] + X [ 492ULL ] ) - t3429 *
100000.0 ; t3468 = ( - X [ 480ULL ] + X [ 503ULL ] ) - t3429 * 100000.0 ;
t3473 = ( ( ( 1.0 - t3397 ) - t3417 ) * t3462 + t4716 * t3397 ) + t2585_idx_0
* t3417 ; t3476 = t3462 - X [ 67ULL ] * 0.296802103844292 ; t3462 =
t2585_idx_0 - X [ 67ULL ] * 4.12448151675695 ; t3464 = t4716 - X [ 67ULL ] *
0.461523 ; t4716 = ( X [ 485ULL ] * - 0.7999998 + U_idx_11 *
7.9999980000000006 ) + 9.9999999947364415E-9 ; if ( t4716 *
7.8539816339744827E-5 <= 7.8539816339744857E-13 ) { t3478 =
7.8539816339744857E-13 ; } else if ( t4716 * 7.8539816339744827E-5 >=
3.1415926535897929E-6 ) { t3478 = 3.1415926535897929E-6 ; } else { t3478 =
t4716 * 7.8539816339744827E-5 ; } t4716 = t3478 / 7.8539816339744827E-5 ; if
( X [ 508ULL ] <= 0.0 ) { t4767 = 0.0 ; } else { t4767 = X [ 508ULL ] >= 1.0
? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL ] <= 0.0 ) { t3482 = 0.0 ; } else {
t3482 = X [ 509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } t3483 = ( ( ( 1.0 -
t4767 ) - t3482 ) * 296.802103844292 + t4767 * 461.523 ) + t3482 *
4124.48151675695 ; t3819 = X [ 506ULL ] * t3483 ; U_idx_11 = X [ 507ULL ] / (
t3819 == 0.0 ? 1.0E-16 : t3819 ) ; t4768 = X [ 507ULL ] / ( X [ 64ULL ] ==
0.0 ? 1.0E-16 : X [ 64ULL ] ) * ( X [ 510ULL ] / ( X [ 506ULL ] == 0.0 ?
1.0E-16 : X [ 506ULL ] ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 = X [ 507ULL
] / ( X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) * ( X [ 511ULL ] / ( X [
506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; if ( - X [ 478ULL ] > 0.0 ) {
t3488 = ( t4716 + 1.0 ) * ( 1.0 - t4716 * t4768 ) * ( - X [ 478ULL ] / 0.64 /
( t3478 == 0.0 ? 1.0E-16 : t3478 ) * ( - X [ 478ULL ] / 0.64 / ( t3478 == 0.0
? 1.0E-16 : t3478 ) ) / 2.0 / ( U_idx_11 == 0.0 ? 1.0E-16 : U_idx_11 ) ) *
9.9999999999999991E-11 ; } else if ( - X [ 478ULL ] < 0.0 ) { t3488 = ( t4716
+ 1.0 ) * ( 1.0 - t4716 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ) * ( - X [
478ULL ] / 0.64 / ( t3478 == 0.0 ? 1.0E-16 : t3478 ) * ( - X [ 478ULL ] /
0.64 / ( t3478 == 0.0 ? 1.0E-16 : t3478 ) ) / 2.0 / ( U_idx_11 == 0.0 ?
1.0E-16 : U_idx_11 ) ) * 9.9999999999999991E-11 ; } else { t3488 = 0.0 ; }
t3490 = ( X [ 64ULL ] + X [ 485ULL ] ) / 2.0 * 0.0010000000000000009 ; t3489
= ( 1.0 - t4716 ) * ( 1.0 - t4716 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 = t3490 *
t3489 ; t3492 = ( t4716 + 1.0 ) * ( 1.0 - t4716 * t4768 ) - ( 1.0 - t4716 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ) * t4716 *
2.0 ; t3493 = ( X [ 64ULL ] - X [ 485ULL ] ) * ( t3492 >= t3489 ? t3492 :
t3489 ) ; t3492 = ( X [ 64ULL ] - X [ 485ULL ] ) / ( t3490 == 0.0 ? 1.0E-16 :
t3490 ) ; t3494 = t3492 * t3492 * 3.0 - t3492 * t3492 * t3492 * 2.0 ; if ( X
[ 64ULL ] - X [ 485ULL ] <= 0.0 ) { t3492 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; } else if (
X [ 64ULL ] - X [ 485ULL ] >= t3490 ) { t3492 = t3493 ; } else { t3492 = (
1.0 - t3494 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 + t3493 *
t3494 ; } t3493 = ( t4716 + 1.0 ) * ( 1.0 - t4716 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ) - ( 1.0 -
t4716 * t4768 ) * t4716 * 2.0 ; t4716 = ( X [ 485ULL ] - X [ 64ULL ] ) * (
t3493 >= t3489 ? t3493 : t3489 ) ; t4768 = ( X [ 485ULL ] - X [ 64ULL ] ) / (
t3490 == 0.0 ? 1.0E-16 : t3490 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 = t4768 *
t4768 * 3.0 - t4768 * t4768 * t4768 * 2.0 ; if ( X [ 485ULL ] - X [ 64ULL ]
<= 0.0 ) { t4768 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; } else if (
X [ 485ULL ] - X [ 64ULL ] >= t3490 ) { t4768 = t4716 ; } else { t4768 = (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 + t4716 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ; } if ( X [
64ULL ] > X [ 485ULL ] ) { t4716 = t3492 ; } else { t4716 = X [ 64ULL ] < X [
485ULL ] ? t4768 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; } if ( X [
506ULL ] <= 216.59999999999997 ) { t4768 = 216.59999999999997 ; } else {
t4768 = X [ 506ULL ] >= 623.15 ? 623.15 : X [ 506ULL ] ; } t3495 = t4768 *
t4768 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 = ( (
( 1074.1165326382554 + t4768 * - 0.22145652610641059 ) + t3495 *
0.0003721298010901061 ) * ( ( 1.0 - t4767 ) - t3482 ) + ( (
1479.6504774710402 + t4768 * 1.2002114337050787 ) + t3495 * -
0.00038614513167845434 ) * t4767 ) + ( ( 12825.281119789837 + t4768 *
6.9647057412840034 ) + t3495 * - 0.0070524868246844051 ) * t3482 ; t3848 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 - t3483 ;
t3848 = X [ 507ULL ] * X [ 507ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 / ( t3848 ==
0.0 ? 1.0E-16 : t3848 ) ) ; t4768 = pmf_sqrt ( fabs ( t3848 / ( t3483 == 0.0
? 1.0E-16 : t3483 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) *
t3478 * 0.64 ; t3851 = U_idx_11 * 2.0 ; U_idx_11 = ( X [ 64ULL ] - X [ 485ULL
] ) * pmf_sqrt ( fabs ( t3851 / ( t4716 == 0.0 ? 1.0E-16 : t4716 ) ) ) *
t3478 * 0.64 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 = pmf_sqrt (
X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) ; t3489 = pmf_sqrt ( X
[ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 = pmf_sqrt (
X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) ; if ( X [ 524ULL ] <=
0.0 ) { t3492 = 0.0 ; } else { t3492 = X [ 524ULL ] >= 1.0 ? 1.0 : X [ 524ULL
] ; } if ( X [ 525ULL ] <= 0.0 ) { t3493 = 0.0 ; } else { t3493 = X [ 525ULL
] >= 1.0 ? 1.0 : X [ 525ULL ] ; } t3494 = ( ( ( 1.0 - t3492 ) - t3493 ) *
296.802103844292 + t3492 * 461.523 ) + t3493 * 259.836612622973 ; if ( 1.0 -
X [ 524ULL ] >= 0.01 ) { t3495 = 1.0 - X [ 524ULL ] ; } else if ( 1.0 - X [
524ULL ] >= - 0.1 ) { t3495 = pmf_exp ( ( ( 1.0 - X [ 524ULL ] ) - 0.01 ) /
0.01 ) * 0.01 ; } else { t3495 = 1.6701700790245661E-7 ; } if ( X [ 537ULL ]
<= 0.0 ) { t3496 = 0.0 ; } else { t3496 = X [ 537ULL ] >= 1.0 ? 1.0 : X [
537ULL ] ; } if ( X [ 536ULL ] <= 0.0 ) { t2796 = 0.0 ; } else { t2796 = X [
536ULL ] >= 1.0 ? 1.0 : X [ 536ULL ] ; } t3498 = ( ( ( 1.0 - t3496 ) - t2796
) * 296.802103844292 + t3496 * 461.523 ) + t2796 * 259.836612622973 ; t2049 [
0ULL ] = X [ 531ULL ] ; tlu2_linear_linear_prelookup ( & qr_efOut . mField0 [
0ULL ] , & qr_efOut . mField1 [ 0ULL ] , & qr_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t187 = qr_efOut ; tlu2_1d_linear_linear_value ( &
rr_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = rr_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
sr_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = sr_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
tr_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = tr_efOut [ 0 ] ; t3499 = ( ( ( 1.0 - t3496 ) - t2796
) * t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ; t2049 [ 0ULL
] = X [ 534ULL ] ; tlu2_linear_linear_prelookup ( & ur_efOut . mField0 [ 0ULL
] , & ur_efOut . mField1 [ 0ULL ] , & ur_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t170 = ur_efOut ; tlu2_1d_linear_linear_value ( &
vr_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = vr_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
wr_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = wr_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
xr_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ] , & t170 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = xr_efOut [ 0 ] ; t3500 = ( ( ( 1.0 - t3496 ) - t2796
) * t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ; t2049 [ 0ULL
] = X [ 532ULL ] ; tlu2_linear_linear_prelookup ( & yr_efOut . mField0 [ 0ULL
] , & yr_efOut . mField1 [ 0ULL ] , & yr_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t52 = yr_efOut ; tlu2_1d_linear_linear_value ( &
as_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = as_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & bs_efOut
[ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = bs_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & cs_efOut
[ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = cs_efOut [ 0 ] ; t3501 = ( ( ( 1.0 - t3496 ) - t2796 ) *
t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ; t2049 [ 0ULL ] =
X [ 533ULL ] ; tlu2_linear_linear_prelookup ( & ds_efOut . mField0 [ 0ULL ] ,
& ds_efOut . mField1 [ 0ULL ] , & ds_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t3 = ds_efOut ; tlu2_1d_linear_linear_value ( &
es_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = es_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & fs_efOut
[ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = fs_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & gs_efOut
[ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = gs_efOut [ 0 ] ; t3502 = ( ( ( 1.0 - t3496 ) - t2796 ) *
t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ; t2049 [ 0ULL ] =
X [ 71ULL ] ; tlu2_linear_linear_prelookup ( & hs_efOut . mField0 [ 0ULL ] ,
& hs_efOut . mField1 [ 0ULL ] , & hs_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t99 = hs_efOut ; tlu2_1d_linear_linear_value ( &
is_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = is_efOut [ 0 ] ; t3506 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & js_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField19 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = js_efOut [ 0 ] ; t3507 =
t2585_idx_0 ; if ( X [ 73ULL ] <= 0.0 ) { t3508 = 0.0 ; } else { t3508 = X [
73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ] ; } if ( X [ 72ULL ] <= 0.0 ) { t3509 =
0.0 ; } else { t3509 = X [ 72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; } t3510 = ( (
( 1.0 - t3508 ) - t3509 ) * 296.802103844292 + t3508 * 461.523 ) + t3509 *
259.836612622973 ; t3856 = X [ 71ULL ] * t3510 ; if ( 1.0 - X [ 73ULL ] >=
0.01 ) { t3512 = 1.0 - X [ 73ULL ] ; } else if ( 1.0 - X [ 73ULL ] >= - 0.1 )
{ t3512 = pmf_exp ( ( ( 1.0 - X [ 73ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else
{ t3512 = 1.6701700790245661E-7 ; } t3513 = X [ 72ULL ] / ( t3512 == 0.0 ?
1.0E-16 : t3512 ) * - 36.965491221318985 + 296.802103844292 ;
tlu2_1d_linear_linear_value ( & ks_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ks_efOut [ 0 ] ; t3514 =
pmf_exp ( pmf_log ( X [ 55ULL ] * 100000.0 ) - t2585_idx_0 ) ; if ( t3514 >=
1.0 ) { U_idx_1 = ( t3514 - 1.0 ) * 461.523 + t3513 ; t3516 = t3513 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else { t3516 = 1.0 ; } t3861 = t3516
* 0.01 ; t3513 = ( X [ 73ULL ] - t3516 ) / ( t3861 == 0.0 ? 1.0E-16 : t3861 )
; if ( X [ 73ULL ] - t3516 <= 0.0 ) { t3513 = 0.0 ; } else if ( X [ 73ULL ] -
t3516 >= t3516 * 0.01 ) { t3513 = X [ 73ULL ] - t3516 ; } else { t3513 = ( X
[ 73ULL ] - t3516 ) * ( t3513 * t3513 * 3.0 - t3513 * t3513 * t3513 * 2.0 ) ;
} t3511 = X [ 55ULL ] / ( t3856 == 0.0 ? 1.0E-16 : t3856 ) * t3513 * 0.0003 /
0.001 ; t3513 = ( t3506 - t3507 ) * t3511 ; t3507 = pmf_sqrt ( X [ 413ULL ] *
X [ 413ULL ] + 2.7104677895120892E-12 ) ; t3516 = pmf_sqrt ( X [ 413ULL ] * X
[ 413ULL ] + 5.2285258285341208E-12 ) ; t3517 = pmf_sqrt ( X [ 413ULL ] * X [
413ULL ] + 3.6921614138577959E-12 ) ; tlu2_1d_linear_linear_value ( &
ls_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = ls_efOut [ 0 ] ; t3518 = t2585_idx_0 ;
tlu2_1d_linear_linear_value ( & ms_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL ]
, & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ms_efOut [ 0 ] ; t3520 =
- X [ 520ULL ] - X [ 420ULL ] ; t3521 = ( - X [ 519ULL ] - X [ 413ULL ] ) -
t3511 * 100000.0 ; t3522 = ( - X [ 521ULL ] - X [ 421ULL ] ) - t3511 *
100000.0 ; t3523 = ( ( ( 1.0 - t3508 ) - t3509 ) * t3518 + t3506 * t3508 ) +
t2585_idx_0 * t3509 ; t3525 = t3518 - X [ 71ULL ] * 0.296802103844292 ; t3518
= t2585_idx_0 - X [ 71ULL ] * 0.25983661262297303 ; t3519 = t3506 - X [ 71ULL
] * 0.461523 ; t2049 [ 0ULL ] = X [ 74ULL ] ; tlu2_linear_linear_prelookup (
& ns_efOut . mField0 [ 0ULL ] , & ns_efOut . mField1 [ 0ULL ] , & ns_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t55 = ns_efOut ;
tlu2_1d_linear_linear_value ( & os_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = os_efOut [ 0 ] ; t3506 =
t2585_idx_0 ; tlu2_1d_linear_linear_value ( & ps_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField19 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ps_efOut
[ 0 ] ; t3526 = t2585_idx_0 ; if ( X [ 76ULL ] <= 0.0 ) { t3528 = 0.0 ; }
else { t3528 = X [ 76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <=
0.0 ) { t3529 = 0.0 ; } else { t3529 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ]
; } t3530 = ( ( ( 1.0 - t3528 ) - t3529 ) * 296.802103844292 + t3528 *
461.523 ) + t3529 * 4124.48151675695 ; t3861 = X [ 74ULL ] * t3530 ; if ( 1.0
- X [ 76ULL ] >= 0.01 ) { t3532 = 1.0 - X [ 76ULL ] ; } else if ( 1.0 - X [
76ULL ] >= - 0.1 ) { t3532 = pmf_exp ( ( ( 1.0 - X [ 76ULL ] ) - 0.01 ) /
0.01 ) * 0.01 ; } else { t3532 = 1.6701700790245661E-7 ; } t3533 = X [ 75ULL
] / ( t3532 == 0.0 ? 1.0E-16 : t3532 ) * 3827.6794129126583 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & qs_efOut [ 0ULL ] , & t55
. mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField14 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
qs_efOut [ 0 ] ; t3534 = pmf_exp ( pmf_log ( X [ 38ULL ] * 100000.0 ) -
t2585_idx_0 ) ; if ( t3534 >= 1.0 ) { t4165 = ( t3534 - 1.0 ) * 461.523 +
t3533 ; t3535 = t3533 / ( t4165 == 0.0 ? 1.0E-16 : t4165 ) ; } else { t3535 =
1.0 ; } U_idx_10 = t3535 * 0.01 ; t3533 = ( X [ 76ULL ] - t3535 ) / (
U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) ; if ( X [ 76ULL ] - t3535 <= 0.0 ) {
t3533 = 0.0 ; } else if ( X [ 76ULL ] - t3535 >= t3535 * 0.01 ) { t3533 = X [
76ULL ] - t3535 ; } else { t3533 = ( X [ 76ULL ] - t3535 ) * ( t3533 * t3533
* 3.0 - t3533 * t3533 * t3533 * 2.0 ) ; } t3531 = X [ 38ULL ] / ( t3861 ==
0.0 ? 1.0E-16 : t3861 ) * t3533 * 0.00012500000000000003 / 0.001 ; t3533 = (
t3506 - t3526 ) * t3531 ; t3526 = pmf_sqrt ( X [ 492ULL ] * X [ 492ULL ] +
1.8324100759713822E-12 ) ; t3535 = pmf_sqrt ( X [ 492ULL ] * X [ 492ULL ] +
2.0914103314136477E-13 ) ; t3536 = pmf_sqrt ( X [ 492ULL ] * X [ 492ULL ] +
1.4768645655431184E-13 ) ; t3538 = U_idx_4 * 0.01 ; t3539 = pmf_sqrt ( t3538
* t3538 + 1.8324100759713822E-12 ) ; t3543 = pmf_sqrt ( t3538 * t3538 +
2.0914103314136477E-13 ) ; t3544 = pmf_sqrt ( t3538 * t3538 +
1.4768645655431184E-13 ) ; t3546 = pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] +
1.8324100759713822E-12 ) ; t3548 = pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] +
2.0914103314136477E-13 ) ; t3552 = pmf_sqrt ( X [ 288ULL ] * X [ 288ULL ] +
1.4768645655431184E-13 ) ; tlu2_1d_linear_linear_value ( & rs_efOut [ 0ULL ]
, & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0
= rs_efOut [ 0 ] ; t3554 = t2585_idx_0 ; tlu2_1d_linear_linear_value ( &
ss_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = ss_efOut [ 0 ] ; t3557 = ( - X [ 502ULL ] - X [ 295ULL ]
) + X [ 211ULL ] ; t3558 = ( ( - X [ 492ULL ] - X [ 288ULL ] ) + t3538 ) -
t3531 * 100000.0 ; t3563 = ( ( - X [ 503ULL ] - X [ 296ULL ] ) + X [ 213ULL ]
) - t3531 * 100000.0 ; t3564 = ( ( ( 1.0 - t3528 ) - t3529 ) * t3554 + t3506
* t3528 ) + t2585_idx_0 * t3529 ; t3568 = t3554 - X [ 74ULL ] *
0.296802103844292 ; t3554 = t2585_idx_0 - X [ 74ULL ] * 4.12448151675695 ;
t3555 = t3506 - X [ 74ULL ] * 0.461523 ; if ( X [ 576ULL ] <= 0.0 ) { t3506 =
0.0 ; } else { t3506 = X [ 576ULL ] >= 1.0 ? 1.0 : X [ 576ULL ] ; } if ( X [
575ULL ] <= 0.0 ) { t3570 = 0.0 ; } else { t3570 = X [ 575ULL ] >= 1.0 ? 1.0
: X [ 575ULL ] ; } t3572 = ( ( ( 1.0 - t3506 ) - t3570 ) * 296.802103844292 +
t3506 * 461.523 ) + t3570 * 4124.48151675695 ; t2049 [ 0ULL ] = X [ 570ULL ]
; tlu2_linear_linear_prelookup ( & ts_efOut . mField0 [ 0ULL ] , & ts_efOut .
mField1 [ 0ULL ] , & ts_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t55 = ts_efOut ; tlu2_1d_linear_linear_value ( & us_efOut [ 0ULL ] , & t55
. mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
us_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & vs_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = vs_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & ws_efOut [ 0ULL ] , & t55 . mField0 [
0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ws_efOut [ 0
] ; t3573 = ( ( ( 1.0 - t3506 ) - t3570 ) * t2585_idx_0 + t2586_idx_0 * t3506
) + t2587_idx_0 * t3570 ; t2049 [ 0ULL ] = X [ 573ULL ] ;
tlu2_linear_linear_prelookup ( & xs_efOut . mField0 [ 0ULL ] , & xs_efOut .
mField1 [ 0ULL ] , & xs_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = xs_efOut ; tlu2_1d_linear_linear_value ( & ys_efOut [ 0ULL ] , &
t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ys_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & at_efOut [ 0ULL ] , & t153 .
mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
at_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & bt_efOut [ 0ULL ] , & t153 .
mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
bt_efOut [ 0 ] ; t3575 = ( ( ( 1.0 - t3506 ) - t3570 ) * t2585_idx_0 +
t2586_idx_0 * t3506 ) + t2587_idx_0 * t3570 ; t2049 [ 0ULL ] = X [ 571ULL ] ;
tlu2_linear_linear_prelookup ( & ct_efOut . mField0 [ 0ULL ] , & ct_efOut .
mField1 [ 0ULL ] , & ct_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t81 = ct_efOut ; tlu2_1d_linear_linear_value ( & dt_efOut [ 0ULL ] , & t81
. mField0 [ 0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
dt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & et_efOut [ 0ULL ] , & t81 .
mField0 [ 0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = et_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & ft_efOut [ 0ULL ] , & t81 . mField0 [
0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ft_efOut [ 0
] ; t3576 = ( ( ( 1.0 - t3506 ) - t3570 ) * t2585_idx_0 + t2586_idx_0 * t3506
) + t2587_idx_0 * t3570 ; t2049 [ 0ULL ] = X [ 572ULL ] ;
tlu2_linear_linear_prelookup ( & gt_efOut . mField0 [ 0ULL ] , & gt_efOut .
mField1 [ 0ULL ] , & gt_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t171 = gt_efOut ; tlu2_1d_linear_linear_value ( & ht_efOut [ 0ULL ] , &
t171 . mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ht_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & it_efOut [ 0ULL ] , & t171 .
mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
it_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & jt_efOut [ 0ULL ] , & t171 .
mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
jt_efOut [ 0 ] ; t3577 = ( ( ( 1.0 - t3506 ) - t3570 ) * t2585_idx_0 +
t2586_idx_0 * t3506 ) + t2587_idx_0 * t3570 ; t3578 = U_idx_2 >= 0.0 ?
U_idx_2 : - U_idx_2 ; t4165 = t3578 * 0.01 ; U_idx_10 = intrm_sf_mf_261 *
7.8539816339744827E-5 ; t3579 = t4165 / ( U_idx_10 == 0.0 ? 1.0E-16 :
U_idx_10 ) ; intrm_sf_mf_11 = X [ 371ULL ] >= 0.0 ? X [ 371ULL ] : - X [
371ULL ] ; intrm_sf_mf_1104 = intrm_sf_mf_11 * 0.01 / ( t3365 == 0.0 ?
1.0E-16 : t3365 ) ; t3582 = intrm_sf_mf_1104 >= 1.0 ? intrm_sf_mf_1104 : 1.0
; t5294 = pmf_log10 ( 6.9 / ( t3582 == 0.0 ? 1.0E-16 : t3582 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3582 == 0.0 ? 1.0E-16 : t3582
) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_11 = X [ 371ULL ] *
intrm_sf_mf_11 * ( 1.0 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) ) *
0.046833001326703774 / ( t3372 == 0.0 ? 1.0E-16 : t3372 ) ; t3582 = (
intrm_sf_mf_1104 - 2000.0 ) / 2000.0 ; t3583 = t3582 * t3582 * 3.0 - t3582 *
t3582 * t3582 * 2.0 ; t3582 = X [ 371ULL ] * t3133 * 2.9973120849090416 / (
t3369 == 0.0 ? 1.0E-16 : t3369 ) ; if ( intrm_sf_mf_1104 <= 2000.0 ) { t3584
= t3582 * 9.9999999999999991E-11 ; } else if ( intrm_sf_mf_1104 >= 4000.0 ) {
t3584 = intrm_sf_mf_11 * 9.9999999999999991E-11 ; } else { t3584 = ( ( 1.0 -
t3583 ) * t3582 + intrm_sf_mf_11 * t3583 ) * 9.9999999999999991E-11 ; }
intrm_sf_mf_11 = t3579 >= 2000.0 ? t3579 : 1.0 ; t2049 [ 0ULL ] = X [ 350ULL
] ; tlu2_linear_linear_prelookup ( & kt_efOut . mField0 [ 0ULL ] , & kt_efOut
. mField1 [ 0ULL ] , & kt_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t99 = kt_efOut ; tlu2_1d_linear_linear_value ( & lt_efOut [ 0ULL ] , &
t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
lt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & mt_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = mt_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & nt_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = nt_efOut [ 0
] ; intrm_sf_mf_1104 = ( ( ( 1.0 - t3176 ) - zc_int365 ) * t2585_idx_0 +
t2586_idx_0 * t3176 ) + t2587_idx_0 * zc_int365 ; t2049 [ 0ULL ] = X [ 302ULL
] ; tlu2_linear_linear_prelookup ( & ot_efOut . mField0 [ 0ULL ] , & ot_efOut
. mField1 [ 0ULL ] , & ot_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t99 = ot_efOut ; tlu2_1d_linear_linear_value ( & pt_efOut [ 0ULL ] , &
t99 . mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
pt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & qt_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = qt_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & rt_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = rt_efOut [ 0
] ; t3176 = ( ( ( 1.0 - t3093 ) - intrm_sf_mf_1119 ) * t2585_idx_0 +
t2586_idx_0 * t3093 ) + t2587_idx_0 * intrm_sf_mf_1119 ; t2049 [ 0ULL ] = X [
387ULL ] ; tlu2_linear_linear_prelookup ( & st_efOut . mField0 [ 0ULL ] , &
st_efOut . mField1 [ 0ULL ] , & st_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t45 = st_efOut ; tlu2_1d_linear_linear_value ( &
tt_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = tt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ut_efOut
[ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = ut_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & vt_efOut
[ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = vt_efOut [ 0 ] ; t3093 = ( ( ( 1.0 - t3155 ) - t3196 ) *
t2585_idx_0 + t2586_idx_0 * t3155 ) + t2587_idx_0 * t3196 ; t2049 [ 0ULL ] =
X [ 389ULL ] ; tlu2_linear_linear_prelookup ( & wt_efOut . mField0 [ 0ULL ] ,
& wt_efOut . mField1 [ 0ULL ] , & wt_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t45 = wt_efOut ; tlu2_1d_linear_linear_value ( &
xt_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = xt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & yt_efOut
[ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = yt_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & au_efOut
[ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = au_efOut [ 0 ] ; intrm_sf_mf_1119 = ( ( ( 1.0 - t3155 ) -
t3196 ) * t2585_idx_0 + t2586_idx_0 * t3155 ) + t2587_idx_0 * t3196 ; if ( -
X [ 371ULL ] >= 0.0 ) { zc_int365 = - X [ 371ULL ] ; } else { zc_int365 = X [
371ULL ] ; } t3582 = zc_int365 * 0.01 / ( t3459 == 0.0 ? 1.0E-16 : t3459 ) ;
t3583 = t3582 >= 1.0 ? t3582 : 1.0 ; t5294 = pmf_log10 ( 6.9 / ( t3583 == 0.0
? 1.0E-16 : t3583 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3583 ==
0.0 ? 1.0E-16 : t3583 ) + 0.00017169489553429715 ) * 3.24 ; t3585 = X [
371ULL ] * t3204 * - 2.9973120849090416 / ( t3463 == 0.0 ? 1.0E-16 : t3463 )
; zc_int365 = X [ 371ULL ] * zc_int365 * ( 1.0 / ( t5294 == 0.0 ? 1.0E-16 :
t5294 ) ) * - 0.046833001326703774 / ( t3466 == 0.0 ? 1.0E-16 : t3466 ) ;
t3583 = ( t3582 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1267 = t3583 * t3583 * 3.0
- t3583 * t3583 * t3583 * 2.0 ; if ( t3582 <= 2000.0 ) { t3583 = t3585 *
9.9999999999999991E-11 ; } else if ( t3582 >= 4000.0 ) { t3583 = zc_int365 *
9.9999999999999991E-11 ; } else { t3583 = ( ( 1.0 - intrm_sf_mf_1267 ) *
t3585 + zc_int365 * intrm_sf_mf_1267 ) * 9.9999999999999991E-11 ; } if ( - X
[ 325ULL ] >= 0.0 ) { zc_int365 = - X [ 325ULL ] ; } else { zc_int365 = X [
325ULL ] ; } t3582 = zc_int365 * 0.01 / ( t3459 == 0.0 ? 1.0E-16 : t3459 ) ;
t3585 = t3582 >= 1.0 ? t3582 : 1.0 ; t5294 = pmf_log10 ( 6.9 / ( t3585 == 0.0
? 1.0E-16 : t3585 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3585 ==
0.0 ? 1.0E-16 : t3585 ) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_1267
= X [ 325ULL ] * t3204 * - 2.9973120849090416 / ( t3463 == 0.0 ? 1.0E-16 :
t3463 ) ; zc_int365 = X [ 325ULL ] * zc_int365 * ( 1.0 / ( t5294 == 0.0 ?
1.0E-16 : t5294 ) ) * - 0.046833001326703774 / ( t3466 == 0.0 ? 1.0E-16 :
t3466 ) ; t3585 = ( t3582 - 2000.0 ) / 2000.0 ; t3587 = t3585 * t3585 * 3.0 -
t3585 * t3585 * t3585 * 2.0 ; if ( t3582 <= 2000.0 ) { t3585 =
intrm_sf_mf_1267 * 9.9999999999999991E-11 ; } else if ( t3582 >= 4000.0 ) {
t3585 = zc_int365 * 9.9999999999999991E-11 ; } else { t3585 = ( ( 1.0 - t3587
) * intrm_sf_mf_1267 + zc_int365 * t3587 ) * 9.9999999999999991E-11 ; } t5294
= pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ?
1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 ) * 3.24 ; zc_int365 =
1.0 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) * 0.55 / 0.01 ; t2049 [ 0ULL ] = X [
403ULL ] ; tlu2_linear_linear_prelookup ( & bu_efOut . mField0 [ 0ULL ] , &
bu_efOut . mField1 [ 0ULL ] , & bu_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = bu_efOut ; tlu2_1d_linear_linear_value ( &
cu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = cu_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
du_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = du_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
eu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = eu_efOut [ 0 ] ; intrm_sf_mf_11 = ( ( ( 1.0 - t3272
) - t4821 ) * t2585_idx_0 + t2586_idx_0 * t3272 ) + t2587_idx_0 * t4821 ;
t2049 [ 0ULL ] = X [ 364ULL ] ; tlu2_linear_linear_prelookup ( & fu_efOut .
mField0 [ 0ULL ] , & fu_efOut . mField1 [ 0ULL ] , & fu_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = fu_efOut ;
tlu2_1d_linear_linear_value ( & gu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gu_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & hu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = hu_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & iu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = iu_efOut [ 0 ] ; t3272 =
( ( ( 1.0 - intrm_sf_mf_1254 ) - intrm_sf_mf_1257 ) * t2585_idx_0 +
t2586_idx_0 * intrm_sf_mf_1254 ) + t2587_idx_0 * intrm_sf_mf_1257 ; t2049 [
0ULL ] = X [ 414ULL ] ; tlu2_linear_linear_prelookup ( & ju_efOut . mField0 [
0ULL ] , & ju_efOut . mField1 [ 0ULL ] , & ju_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = ju_efOut ; tlu2_1d_linear_linear_value ( &
ku_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = ku_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
lu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = lu_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
mu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = mu_efOut [ 0 ] ; intrm_sf_mf_1254 = ( ( ( 1.0 -
t3217 ) - t3228 ) * t2585_idx_0 + t2586_idx_0 * t3217 ) + t2587_idx_0 * t3228
; t2049 [ 0ULL ] = X [ 416ULL ] ; tlu2_linear_linear_prelookup ( & nu_efOut .
mField0 [ 0ULL ] , & nu_efOut . mField1 [ 0ULL ] , & nu_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = nu_efOut ;
tlu2_1d_linear_linear_value ( & ou_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = ou_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & pu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = pu_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & qu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ]
, & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = qu_efOut [ 0 ] ;
intrm_sf_mf_1257 = ( ( ( 1.0 - t3217 ) - t3228 ) * t2585_idx_0 + t2586_idx_0
* t3217 ) + t2587_idx_0 * t3228 ; t4821 = X [ 413ULL ] >= 0.0 ? X [ 413ULL ]
: - X [ 413ULL ] ; t3582 = t4821 * 0.05 / ( t3549 == 0.0 ? 1.0E-16 : t3549 )
; intrm_sf_mf_1267 = t3582 >= 1.0 ? t3582 : 1.0 ; t5294 = pmf_log10 ( 6.9 / (
intrm_sf_mf_1267 == 0.0 ? 1.0E-16 : intrm_sf_mf_1267 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1267 == 0.0 ?
1.0E-16 : intrm_sf_mf_1267 ) + 2.8767404433520813E-5 ) * 3.24 ; t3587 = X [
413ULL ] * t3240 * 11.2 / ( t3553 == 0.0 ? 1.0E-16 : t3553 ) ; t4821 = X [
413ULL ] * t4821 * ( 1.0 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) ) * 0.175 / (
t3556 == 0.0 ? 1.0E-16 : t3556 ) ; intrm_sf_mf_1267 = ( t3582 - 2000.0 ) /
2000.0 ; U_idx_3 = intrm_sf_mf_1267 * intrm_sf_mf_1267 * 3.0 -
intrm_sf_mf_1267 * intrm_sf_mf_1267 * intrm_sf_mf_1267 * 2.0 ; if ( t3582 <=
2000.0 ) { intrm_sf_mf_1267 = t3587 * 9.9999999999999991E-11 ; } else if (
t3582 >= 4000.0 ) { intrm_sf_mf_1267 = t4821 * 9.9999999999999991E-11 ; }
else { intrm_sf_mf_1267 = ( ( 1.0 - U_idx_3 ) * t3587 + t4821 * U_idx_3 ) *
9.9999999999999991E-11 ; } if ( - X [ 368ULL ] >= 0.0 ) { t4821 = - X [
368ULL ] ; } else { t4821 = X [ 368ULL ] ; } t3582 = t4821 * 0.05 / ( t3549
== 0.0 ? 1.0E-16 : t3549 ) ; t3587 = t3582 >= 1.0 ? t3582 : 1.0 ; t5294 =
pmf_log10 ( 6.9 / ( t3587 == 0.0 ? 1.0E-16 : t3587 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t3587 == 0.0 ? 1.0E-16 : t3587 ) +
2.8767404433520813E-5 ) * 3.24 ; U_idx_3 = X [ 368ULL ] * t3240 * - 11.2 / (
t3553 == 0.0 ? 1.0E-16 : t3553 ) ; t4821 = X [ 368ULL ] * t4821 * ( 1.0 / (
t5294 == 0.0 ? 1.0E-16 : t5294 ) ) * - 0.175 / ( t3556 == 0.0 ? 1.0E-16 :
t3556 ) ; t3587 = ( t3582 - 2000.0 ) / 2000.0 ; U_idx_1 = t3587 * t3587 * 3.0
- t3587 * t3587 * t3587 * 2.0 ; if ( t3582 <= 2000.0 ) { t3587 = U_idx_3 *
9.9999999999999991E-11 ; } else if ( t3582 >= 4000.0 ) { t3587 = t4821 *
9.9999999999999991E-11 ; } else { t3587 = ( ( 1.0 - U_idx_1 ) * U_idx_3 +
t4821 * U_idx_1 ) * 9.9999999999999991E-11 ; } U_idx_7 = ( intrm_sf_mf_1299 +
intrm_sf_mf_1359 ) / 2.0 * 0.002 ; t4821 = t4221 / ( U_idx_7 == 0.0 ? 1.0E-16
: U_idx_7 ) ; intrm_sf_mf_1299 = t4821 >= 0.0 ? t4821 : - t4821 ; t3582 =
intrm_sf_mf_1299 > 1000.0 ? intrm_sf_mf_1299 : 1000.0 ; t4221 = t3304 +
intrm_sf_mf_1314 ; if ( t4221 / 2.0 > 0.5 ) { U_idx_3 = ( t3304 +
intrm_sf_mf_1314 ) / 2.0 ; } else { U_idx_3 = 0.5 ; } t5294 = pmf_log10 ( 6.9
/ ( t3582 == 0.0 ? 1.0E-16 : t3582 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t3582 == 0.0 ? 1.0E-16 : t3582 ) + 0.00017169489553429715 ) * 3.24 ;
U_idx_1 = 1.0 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) ; U_idx_7 = ( pmf_pow (
U_idx_3 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( U_idx_1 / 8.0 ) * 12.7 +
1.0 ; t3582 = ( t3582 - 1000.0 ) * ( U_idx_1 / 8.0 ) * U_idx_3 / ( U_idx_7 ==
0.0 ? 1.0E-16 : U_idx_7 ) ; U_idx_3 = ( intrm_sf_mf_1299 - 2000.0 ) / 2000.0
; U_idx_1 = U_idx_3 * U_idx_3 * 3.0 - U_idx_3 * U_idx_3 * U_idx_3 * 2.0 ; if
( intrm_sf_mf_1299 <= 2000.0 ) { U_idx_3 = 3.66 ; } else if (
intrm_sf_mf_1299 >= 4000.0 ) { U_idx_3 = t3582 ; } else { U_idx_3 = ( 1.0 -
U_idx_1 ) * 3.66 + t3582 * U_idx_1 ; } t5294 = t4221 / 2.0 ; if (
intrm_sf_mf_1299 > U_idx_3 * 1.6063872509454251 / 0.002 / ( t5294 == 0.0 ?
1.0E-16 : t5294 ) / 30.0 ) { U_idx_1 = ( t3304 + intrm_sf_mf_1314 ) / 2.0 ;
t3582 = U_idx_3 * 1.6063872509454251 / ( intrm_sf_mf_1299 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1299 ) / 0.002 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else
{ t3582 = 30.0 ; } t3304 = ( X [ 32ULL ] - X [ 438ULL ] ) * ( 1.0 - pmf_exp (
- t3582 ) ) ; t4821 = t4821 * 0.002 / 0.01 * ( t4221 / 2.0 ) * ( (
intrm_sf_mf_1296 + t3307 ) / 2.0 ) * t3304 ; U_idx_7 = ( intrm_sf_mf_1295 +
intrm_sf_mf_1359 ) / 2.0 * 0.002 ; t3304 = - intrm_sf_mf_1350 * 0.01 / (
U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) ; intrm_sf_mf_1350 = t3304 >= 0.0 ?
t3304 : - t3304 ; intrm_sf_mf_1296 = intrm_sf_mf_1350 > 1000.0 ?
intrm_sf_mf_1350 : 1000.0 ; t4221 = t3305 + intrm_sf_mf_1314 ; if ( t4221 /
2.0 > 0.5 ) { intrm_sf_mf_1299 = ( t3305 + intrm_sf_mf_1314 ) / 2.0 ; } else
{ intrm_sf_mf_1299 = 0.5 ; } t5294 = pmf_log10 ( 6.9 / ( intrm_sf_mf_1296 ==
0.0 ? 1.0E-16 : intrm_sf_mf_1296 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( intrm_sf_mf_1296 == 0.0 ? 1.0E-16 : intrm_sf_mf_1296 ) +
0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_1295 = 1.0 / ( t5294 == 0.0 ?
1.0E-16 : t5294 ) ; U_idx_7 = ( pmf_pow ( intrm_sf_mf_1299 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intrm_sf_mf_1295 / 8.0 ) * 12.7 +
1.0 ; intrm_sf_mf_1296 = ( intrm_sf_mf_1296 - 1000.0 ) * ( intrm_sf_mf_1295 /
8.0 ) * intrm_sf_mf_1299 / ( U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) ;
intrm_sf_mf_1299 = ( intrm_sf_mf_1350 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1295
= intrm_sf_mf_1299 * intrm_sf_mf_1299 * 3.0 - intrm_sf_mf_1299 *
intrm_sf_mf_1299 * intrm_sf_mf_1299 * 2.0 ; if ( intrm_sf_mf_1350 <= 2000.0 )
{ intrm_sf_mf_1299 = 3.66 ; } else if ( intrm_sf_mf_1350 >= 4000.0 ) {
intrm_sf_mf_1299 = intrm_sf_mf_1296 ; } else { intrm_sf_mf_1299 = ( 1.0 -
intrm_sf_mf_1295 ) * 3.66 + intrm_sf_mf_1296 * intrm_sf_mf_1295 ; } U_idx_7 =
t2757 * 1.5707963267948965E-8 ; intrm_sf_mf_1296 = U_idx_2 * intrm_sf_mf_261
* 35.2 / ( U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) * 1.0E-5 ; t5294 = t4221 /
2.0 ; if ( intrm_sf_mf_1350 > intrm_sf_mf_1299 * 1.6063872509454251 / 0.002 /
( t5294 == 0.0 ? 1.0E-16 : t5294 ) / 30.0 ) { U_idx_1 = ( t3305 +
intrm_sf_mf_1314 ) / 2.0 ; intrm_sf_mf_1295 = intrm_sf_mf_1299 *
1.6063872509454251 / ( intrm_sf_mf_1350 == 0.0 ? 1.0E-16 : intrm_sf_mf_1350 )
/ 0.002 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else { intrm_sf_mf_1295
= 30.0 ; } t3305 = ( X [ 32ULL ] - X [ 429ULL ] ) * ( 1.0 - pmf_exp ( -
intrm_sf_mf_1295 ) ) ; t3304 = t3304 * 0.002 / 0.01 * ( t4221 / 2.0 ) * ( (
t4626 + t3307 ) / 2.0 ) * t3305 ; t3305 = ( t3311 - - 20.0 ) / 40.0 ;
intrm_sf_mf_1314 = t3305 * t3305 * 3.0 - t3305 * t3305 * t3305 * 2.0 ; if (
t3311 <= - 20.0 ) { t3305 = t3304 * 0.001 ; } else if ( t3311 >= 20.0 ) {
t3305 = t4821 * 0.001 ; } else { t3305 = ( ( 1.0 - intrm_sf_mf_1314 ) * t3304
+ t4821 * intrm_sf_mf_1314 ) * 0.001 ; } t4821 = X [ 442ULL ] >= 0.0 ? X [
442ULL ] : - X [ 442ULL ] ; t3304 = t4821 * 0.01 / ( t4251 == 0.0 ? 1.0E-16 :
t4251 ) ; intrm_sf_mf_1314 = t3304 >= 1.0 ? t3304 : 1.0 ; t4221 = pmf_log10 (
6.9 / ( intrm_sf_mf_1314 == 0.0 ? 1.0E-16 : intrm_sf_mf_1314 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1314 == 0.0 ?
1.0E-16 : intrm_sf_mf_1314 ) + 0.00017169489553429715 ) * 3.24 ; t5294 =
t4503 * 4.0000000000000003E-7 ; t3307 = X [ 442ULL ] * intrm_sf_mf_1359 *
67.455490037817 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) ; U_idx_1 = t4503 *
8.0E-8 ; t4821 = X [ 442ULL ] * t4821 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 :
t4221 ) ) * 1.0539920318408906 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ;
intrm_sf_mf_1314 = ( t3304 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1350 =
intrm_sf_mf_1314 * intrm_sf_mf_1314 * 3.0 - intrm_sf_mf_1314 *
intrm_sf_mf_1314 * intrm_sf_mf_1314 * 2.0 ; if ( t3304 <= 2000.0 ) {
intrm_sf_mf_1314 = t3307 * 1.0E-5 ; } else if ( t3304 >= 4000.0 ) {
intrm_sf_mf_1314 = t4821 * 1.0E-5 ; } else { intrm_sf_mf_1314 = ( ( 1.0 -
intrm_sf_mf_1350 ) * t3307 + t4821 * intrm_sf_mf_1350 ) * 1.0E-5 ; } t4821 =
X [ 434ULL ] >= 0.0 ? X [ 434ULL ] : - X [ 434ULL ] ; t3304 = t4821 * 0.01 /
( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t3307 = t3304 >= 1.0 ? t3304 : 1.0 ;
t4221 = pmf_log10 ( 6.9 / ( t3307 == 0.0 ? 1.0E-16 : t3307 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3307 == 0.0 ? 1.0E-16 : t3307
) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_1350 = X [ 434ULL ] *
intrm_sf_mf_1359 * 67.455490037817 / ( t5294 == 0.0 ? 1.0E-16 : t5294 ) ;
t4821 = X [ 434ULL ] * t4821 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) *
1.0539920318408906 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; t3307 = ( t3304
- 2000.0 ) / 2000.0 ; intrm_sf_mf_1359 = t3307 * t3307 * 3.0 - t3307 * t3307
* t3307 * 2.0 ; if ( t3304 <= 2000.0 ) { t3307 = intrm_sf_mf_1350 * 1.0E-5 ;
} else if ( t3304 >= 4000.0 ) { t3307 = t4821 * 1.0E-5 ; } else { t3307 = ( (
1.0 - intrm_sf_mf_1359 ) * intrm_sf_mf_1350 + t4821 * intrm_sf_mf_1359 ) *
1.0E-5 ; } t4251 = ( t3382 + t3350 ) / 2.0 * 0.00093750000000000007 ; t4821 =
t2815 / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t3304 = t4821 >= 0.0 ? t4821 : -
t4821 ; intrm_sf_mf_1350 = t3304 > 1000.0 ? t3304 : 1000.0 ; t4221 = t3337 +
t3346 ; if ( t4221 / 2.0 > 0.5 ) { intrm_sf_mf_1359 = ( t3337 + t3346 ) / 2.0
; } else { intrm_sf_mf_1359 = 0.5 ; } t4251 = pmf_log10 ( 6.9 / (
intrm_sf_mf_1350 == 0.0 ? 1.0E-16 : intrm_sf_mf_1350 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1350 == 0.0 ?
1.0E-16 : intrm_sf_mf_1350 ) + 0.00069701528436089772 ) * 3.24 ; t3311 = 1.0
/ ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t2815 = ( pmf_pow ( intrm_sf_mf_1359 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t3311 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_1350 = ( intrm_sf_mf_1350 - 1000.0 ) * ( t3311 / 8.0 ) *
intrm_sf_mf_1359 / ( t2815 == 0.0 ? 1.0E-16 : t2815 ) ; intrm_sf_mf_1359 = (
t3304 - 2000.0 ) / 2000.0 ; t3311 = intrm_sf_mf_1359 * intrm_sf_mf_1359 * 3.0
- intrm_sf_mf_1359 * intrm_sf_mf_1359 * intrm_sf_mf_1359 * 2.0 ; if ( t3304
<= 2000.0 ) { intrm_sf_mf_1359 = 3.66 ; } else if ( t3304 >= 4000.0 ) {
intrm_sf_mf_1359 = intrm_sf_mf_1350 ; } else { intrm_sf_mf_1359 = ( 1.0 -
t3311 ) * 3.66 + intrm_sf_mf_1350 * t3311 ; } t4251 = t4221 / 2.0 ; if (
t3304 > intrm_sf_mf_1359 * 1.3250000000000002 / 0.00093750000000000007 / (
t4251 == 0.0 ? 1.0E-16 : t4251 ) / 30.0 ) { U_idx_1 = ( t3337 + t3346 ) / 2.0
; intrm_sf_mf_1350 = intrm_sf_mf_1359 * 1.3250000000000002 / ( t3304 == 0.0 ?
1.0E-16 : t3304 ) / 0.00093750000000000007 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ; } else { intrm_sf_mf_1350 = 30.0 ; } t3304 = ( X [ 62ULL ] - X [
450ULL ] ) * ( 1.0 - pmf_exp ( - intrm_sf_mf_1350 ) ) ; t4821 = t4821 *
0.00093750000000000007 / 0.0028301886792452828 * ( t4221 / 2.0 ) * ( ( t4628
+ t3347 ) / 2.0 ) * t3304 ; t2815 = ( t4747 + t3350 ) / 2.0 *
0.00093750000000000007 ; t3304 = - intrm_sf_mf_1569 * 0.0028301886792452828 /
( t2815 == 0.0 ? 1.0E-16 : t2815 ) ; intrm_sf_mf_1350 = t3304 >= 0.0 ? t3304
: - t3304 ; intrm_sf_mf_1359 = intrm_sf_mf_1350 > 1000.0 ? intrm_sf_mf_1350 :
1000.0 ; t4221 = intrm_sf_mf_1524 + t3346 ; if ( t4221 / 2.0 > 0.5 ) { t3311
= ( intrm_sf_mf_1524 + t3346 ) / 2.0 ; } else { t3311 = 0.5 ; } t4251 =
pmf_log10 ( 6.9 / ( intrm_sf_mf_1359 == 0.0 ? 1.0E-16 : intrm_sf_mf_1359 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1359 == 0.0 ?
1.0E-16 : intrm_sf_mf_1359 ) + 0.00069701528436089772 ) * 3.24 ; t4503 = 1.0
/ ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t2815 = ( pmf_pow ( t3311 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t4503 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_1359 = ( intrm_sf_mf_1359 - 1000.0 ) * ( t4503 / 8.0 ) * t3311 /
( t2815 == 0.0 ? 1.0E-16 : t2815 ) ; t3311 = ( intrm_sf_mf_1350 - 2000.0 ) /
2000.0 ; t4503 = t3311 * t3311 * 3.0 - t3311 * t3311 * t3311 * 2.0 ; if (
intrm_sf_mf_1350 <= 2000.0 ) { t3311 = 3.66 ; } else if ( intrm_sf_mf_1350 >=
4000.0 ) { t3311 = intrm_sf_mf_1359 ; } else { t3311 = ( 1.0 - t4503 ) * 3.66
+ intrm_sf_mf_1359 * t4503 ; } t4251 = t4221 / 2.0 ; if ( intrm_sf_mf_1350 >
t3311 * 1.3250000000000002 / 0.00093750000000000007 / ( t4251 == 0.0 ?
1.0E-16 : t4251 ) / 30.0 ) { U_idx_1 = ( intrm_sf_mf_1524 + t3346 ) / 2.0 ;
intrm_sf_mf_1359 = t3311 * 1.3250000000000002 / ( intrm_sf_mf_1350 == 0.0 ?
1.0E-16 : intrm_sf_mf_1350 ) / 0.00093750000000000007 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ; } else { intrm_sf_mf_1359 = 30.0 ; } intrm_sf_mf_1350 =
( X [ 62ULL ] - X [ 436ULL ] ) * ( 1.0 - pmf_exp ( - intrm_sf_mf_1359 ) ) ;
t3304 = t3304 * 0.00093750000000000007 / 0.0028301886792452828 * ( t4221 /
2.0 ) * ( ( intrm_sf_mf_1748 + t3347 ) / 2.0 ) * intrm_sf_mf_1350 ;
intrm_sf_mf_1350 = ( t4823 - - 20.0 ) / 40.0 ; intrm_sf_mf_1359 =
intrm_sf_mf_1350 * intrm_sf_mf_1350 * 3.0 - intrm_sf_mf_1350 *
intrm_sf_mf_1350 * intrm_sf_mf_1350 * 2.0 ; if ( t4823 <= - 20.0 ) {
intrm_sf_mf_1350 = t3304 * 0.001 ; } else if ( t4823 >= 20.0 ) {
intrm_sf_mf_1350 = t4821 * 0.001 ; } else { intrm_sf_mf_1350 = ( ( 1.0 -
intrm_sf_mf_1359 ) * t3304 + t4821 * intrm_sf_mf_1359 ) * 0.001 ; } t4821 =
t3333 >= 0.0 ? t3333 : - t3333 ; t3304 = t4821 * 0.0028301886792452828 / (
zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ; intrm_sf_mf_1359 = t3304 >= 1.0 ?
t3304 : 1.0 ; t4221 = pmf_log10 ( 6.9 / ( intrm_sf_mf_1359 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1359 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_1359 == 0.0 ? 1.0E-16 : intrm_sf_mf_1359 ) +
0.00069701528436089772 ) * 3.24 ; t4251 = t4576 * 1.50186899252403E-8 ; t3311
= t3333 * t3350 * 112.0 / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t2815 = t4576
* 4.97494103773585E-9 ; t4821 = t3333 * t4821 * ( 1.0 / ( t4221 == 0.0 ?
1.0E-16 : t4221 ) ) * 1.75 / ( t2815 == 0.0 ? 1.0E-16 : t2815 ) ;
intrm_sf_mf_1359 = ( t3304 - 2000.0 ) / 2000.0 ; t4503 = intrm_sf_mf_1359 *
intrm_sf_mf_1359 * 3.0 - intrm_sf_mf_1359 * intrm_sf_mf_1359 *
intrm_sf_mf_1359 * 2.0 ; if ( t3304 <= 2000.0 ) { intrm_sf_mf_1359 = t3311 *
1.0E-5 ; } else if ( t3304 >= 4000.0 ) { intrm_sf_mf_1359 = t4821 * 1.0E-5 ;
} else { intrm_sf_mf_1359 = ( ( 1.0 - t4503 ) * t3311 + t4821 * t4503 ) *
1.0E-5 ; } if ( - X [ 442ULL ] >= 0.0 ) { t4821 = - X [ 442ULL ] ; } else {
t4821 = X [ 442ULL ] ; } t3304 = t4821 * 0.0028301886792452828 / ( zc_int350
== 0.0 ? 1.0E-16 : zc_int350 ) ; t3311 = t3304 >= 1.0 ? t3304 : 1.0 ; t4221 =
pmf_log10 ( 6.9 / ( t3311 == 0.0 ? 1.0E-16 : t3311 ) + 0.00069701528436089772
) * pmf_log10 ( 6.9 / ( t3311 == 0.0 ? 1.0E-16 : t3311 ) +
0.00069701528436089772 ) * 3.24 ; t4503 = X [ 442ULL ] * t3350 * - 112.0 / (
t4251 == 0.0 ? 1.0E-16 : t4251 ) ; t4821 = X [ 442ULL ] * t4821 * ( 1.0 / (
t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * - 1.75 / ( t2815 == 0.0 ? 1.0E-16 :
t2815 ) ; t3311 = ( t3304 - 2000.0 ) / 2000.0 ; t4626 = t3311 * t3311 * 3.0 -
t3311 * t3311 * t3311 * 2.0 ; if ( t3304 <= 2000.0 ) { t3311 = t4503 * 1.0E-5
; } else if ( t3304 >= 4000.0 ) { t3311 = t4821 * 1.0E-5 ; } else { t3311 = (
( 1.0 - t4626 ) * t4503 + t4821 * t4626 ) * 1.0E-5 ; } if ( X [ 471ULL ] <=
0.0 ) { t4821 = 0.0 ; } else { t4821 = X [ 471ULL ] >= 1.0 ? 1.0 : X [ 471ULL
] ; } if ( X [ 470ULL ] <= 0.0 ) { t3304 = 0.0 ; } else { t3304 = X [ 470ULL
] >= 1.0 ? 1.0 : X [ 470ULL ] ; } t4503 = ( ( ( 1.0 - t4821 ) - t3304 ) *
296.802103844292 + t4821 * 461.523 ) + t3304 * 4124.48151675695 ; t2049 [
0ULL ] = X [ 469ULL ] ; tlu2_linear_linear_prelookup ( & ru_efOut . mField0 [
0ULL ] , & ru_efOut . mField1 [ 0ULL ] , & ru_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = ru_efOut ; tlu2_1d_linear_linear_value ( &
su_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = su_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
tu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = tu_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
uu_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = uu_efOut [ 0 ] ; t4626 = ( ( ( 1.0 - t4821 ) - t3304
) * t2585_idx_0 + t2586_idx_0 * t4821 ) + t2587_idx_0 * t3304 ; t4251 = t2757
* 1.2337005501361696E-8 ; t2757 = U_idx_2 * zc_int365 * t3578 / ( t4251 ==
0.0 ? 1.0E-16 : t4251 ) * 1.0E-5 ; t2049 [ 0ULL ] = X [ 484ULL ] ;
tlu2_linear_linear_prelookup ( & vu_efOut . mField0 [ 0ULL ] , & vu_efOut .
mField1 [ 0ULL ] , & vu_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = vu_efOut ; tlu2_1d_linear_linear_value ( & wu_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
wu_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & xu_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
xu_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & yu_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
yu_efOut [ 0 ] ; zc_int365 = ( ( ( 1.0 - t4785 ) - t4726 ) * t2585_idx_0 +
t2586_idx_0 * t4785 ) + t2587_idx_0 * t4726 ; t4821 = ( t3579 - 2000.0 ) /
2000.0 ; t2049 [ 0ULL ] = X [ 466ULL ] ; tlu2_linear_linear_prelookup ( &
av_efOut . mField0 [ 0ULL ] , & av_efOut . mField1 [ 0ULL ] , & av_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t45 = av_efOut ;
tlu2_1d_linear_linear_value ( & bv_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = bv_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & cv_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = cv_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & dv_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = dv_efOut [ 0 ] ; t3304 =
( ( ( 1.0 - intrm_sf_mf_1462 ) - t4729 ) * t2585_idx_0 + t2586_idx_0 *
intrm_sf_mf_1462 ) + t2587_idx_0 * t4729 ; t2049 [ 0ULL ] = X [ 488ULL ] ;
tlu2_linear_linear_prelookup ( & ev_efOut . mField0 [ 0ULL ] , & ev_efOut .
mField1 [ 0ULL ] , & ev_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t193 = ev_efOut ; tlu2_1d_linear_linear_value ( & fv_efOut [ 0ULL ] , &
t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
fv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & gv_efOut [ 0ULL ] , & t193 .
mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
gv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & hv_efOut [ 0ULL ] , & t193 .
mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
hv_efOut [ 0 ] ; intrm_sf_mf_1299 = ( ( ( 1.0 - t3397 ) - t3417 ) *
t2585_idx_0 + t2586_idx_0 * t3397 ) + t2587_idx_0 * t3417 ; t2049 [ 0ULL ] =
X [ 493ULL ] ; tlu2_linear_linear_prelookup ( & iv_efOut . mField0 [ 0ULL ] ,
& iv_efOut . mField1 [ 0ULL ] , & iv_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = iv_efOut ; tlu2_1d_linear_linear_value ( &
jv_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = jv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
kv_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = kv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
lv_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = lv_efOut [ 0 ] ; intrm_sf_mf_1295 = ( ( ( 1.0 -
t3397 ) - t3417 ) * t2585_idx_0 + t2586_idx_0 * t3397 ) + t2587_idx_0 * t3417
; if ( - X [ 478ULL ] >= 0.0 ) { t3333 = - X [ 478ULL ] ; } else { t3333 = X
[ 478ULL ] ; } t3337 = t3333 * 0.01 / ( t3738 == 0.0 ? 1.0E-16 : t3738 ) ;
intrm_sf_mf_1524 = t3337 >= 1.0 ? t3337 : 1.0 ; t4221 = pmf_log10 ( 6.9 / (
intrm_sf_mf_1524 == 0.0 ? 1.0E-16 : intrm_sf_mf_1524 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1524 == 0.0 ?
1.0E-16 : intrm_sf_mf_1524 ) + 0.00017169489553429715 ) * 3.24 ; t3346 = X [
478ULL ] * t4641 * - 35.2 / ( t3742 == 0.0 ? 1.0E-16 : t3742 ) ; t3333 = X [
478ULL ] * t3333 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * - 0.55 / (
t3745 == 0.0 ? 1.0E-16 : t3745 ) ; intrm_sf_mf_1524 = ( t3337 - 2000.0 ) /
2000.0 ; t3347 = intrm_sf_mf_1524 * intrm_sf_mf_1524 * 3.0 - intrm_sf_mf_1524
* intrm_sf_mf_1524 * intrm_sf_mf_1524 * 2.0 ; if ( t3337 <= 2000.0 ) {
intrm_sf_mf_1524 = t3346 * 9.9999999999999991E-11 ; } else if ( t3337 >=
4000.0 ) { intrm_sf_mf_1524 = t3333 * 9.9999999999999991E-11 ; } else {
intrm_sf_mf_1524 = ( ( 1.0 - t3347 ) * t3346 + t3333 * t3347 ) *
9.9999999999999991E-11 ; } t3333 = X [ 492ULL ] >= 0.0 ? X [ 492ULL ] : - X [
492ULL ] ; t3337 = t3333 * 0.01 / ( t3738 == 0.0 ? 1.0E-16 : t3738 ) ; t3346
= t3337 >= 1.0 ? t3337 : 1.0 ; t4221 = pmf_log10 ( 6.9 / ( t3346 == 0.0 ?
1.0E-16 : t3346 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3346 ==
0.0 ? 1.0E-16 : t3346 ) + 0.00017169489553429715 ) * 3.24 ; t3347 = X [
492ULL ] * t4641 * 35.2 / ( t3742 == 0.0 ? 1.0E-16 : t3742 ) ; t3333 = X [
492ULL ] * t3333 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * 0.55 / (
t3745 == 0.0 ? 1.0E-16 : t3745 ) ; t3346 = ( t3337 - 2000.0 ) / 2000.0 ;
intrm_sf_mf_1569 = t3346 * t3346 * 3.0 - t3346 * t3346 * t3346 * 2.0 ; if (
t3337 <= 2000.0 ) { t3346 = t3347 * 9.9999999999999991E-11 ; } else if (
t3337 >= 4000.0 ) { t3346 = t3333 * 9.9999999999999991E-11 ; } else { t3346 =
( ( 1.0 - intrm_sf_mf_1569 ) * t3347 + t3333 * intrm_sf_mf_1569 ) *
9.9999999999999991E-11 ; } t2049 [ 0ULL ] = X [ 510ULL ] ;
tlu2_linear_linear_prelookup ( & mv_efOut . mField0 [ 0ULL ] , & mv_efOut .
mField1 [ 0ULL ] , & mv_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = mv_efOut ; tlu2_1d_linear_linear_value ( & nv_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
nv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ov_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ov_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & pv_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
pv_efOut [ 0 ] ; t3333 = ( ( ( 1.0 - t4767 ) - t3482 ) * t2585_idx_0 +
t2586_idx_0 * t4767 ) + t2587_idx_0 * t3482 ; t2049 [ 0ULL ] = X [ 511ULL ] ;
tlu2_linear_linear_prelookup ( & qv_efOut . mField0 [ 0ULL ] , & qv_efOut .
mField1 [ 0ULL ] , & qv_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = qv_efOut ; tlu2_1d_linear_linear_value ( & rv_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
rv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & sv_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
sv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & tv_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
tv_efOut [ 0 ] ; t3337 = ( ( ( 1.0 - t4767 ) - t3482 ) * t2585_idx_0 +
t2586_idx_0 * t4767 ) + t2587_idx_0 * t3482 ; t2049 [ 0ULL ] = X [ 506ULL ] ;
tlu2_linear_linear_prelookup ( & uv_efOut . mField0 [ 0ULL ] , & uv_efOut .
mField1 [ 0ULL ] , & uv_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = uv_efOut ; tlu2_1d_linear_linear_value ( & vv_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
vv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & wv_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
wv_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & xv_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
xv_efOut [ 0 ] ; t3347 = ( ( ( 1.0 - t4767 ) - t3482 ) * t2585_idx_0 +
t2586_idx_0 * t4767 ) + t2587_idx_0 * t3482 ; t2815 = t3490 - ( - t3490 ) ;
intrm_sf_mf_1569 = ( ( X [ 64ULL ] - X [ 485ULL ] ) - ( - t3490 ) ) / ( t2815
== 0.0 ? 1.0E-16 : t2815 ) ; t3350 = intrm_sf_mf_1569 * intrm_sf_mf_1569 *
3.0 - intrm_sf_mf_1569 * intrm_sf_mf_1569 * intrm_sf_mf_1569 * 2.0 ; if ( X [
64ULL ] - X [ 485ULL ] <= - t3490 ) { intrm_sf_mf_1569 = X [ 485ULL ] ; }
else if ( X [ 64ULL ] - X [ 485ULL ] >= t3490 ) { intrm_sf_mf_1569 = X [
64ULL ] ; } else { intrm_sf_mf_1569 = ( 1.0 - t3350 ) * X [ 485ULL ] + X [
64ULL ] * t3350 ; } if ( X [ 515ULL ] <= 0.0 ) { t3350 = 0.0 ; } else { t3350
= X [ 515ULL ] >= 1.0 ? 1.0 : X [ 515ULL ] ; } if ( X [ 514ULL ] <= 0.0 ) {
t4823 = 0.0 ; } else { t4823 = X [ 514ULL ] >= 1.0 ? 1.0 : X [ 514ULL ] ; }
t4576 = ( ( ( 1.0 - t3350 ) - t4823 ) * 296.802103844292 + t3350 * 461.523 )
+ t4823 * 259.836612622973 ; t2049 [ 0ULL ] = X [ 513ULL ] ;
tlu2_linear_linear_prelookup ( & yv_efOut . mField0 [ 0ULL ] , & yv_efOut .
mField1 [ 0ULL ] , & yv_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = yv_efOut ; tlu2_1d_linear_linear_value ( & aw_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
aw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & bw_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
bw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & cw_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
cw_efOut [ 0 ] ; t4628 = ( ( ( 1.0 - t3350 ) - t4823 ) * t2585_idx_0 +
t2586_idx_0 * t3350 ) + t2587_idx_0 * t4823 ; tlu2_1d_linear_linear_value ( &
dw_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = dw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
ew_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField43 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = ew_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
fw_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField44 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = fw_efOut [ 0 ] ; t3350 = ( ( ( 1.0 - t3496 ) - t2796
) * t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ;
tlu2_1d_linear_linear_value ( & gw_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField42 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = gw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & hw_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField43 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = hw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & iw_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL ]
, & t170 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField44 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = iw_efOut [ 0 ] ; t4823 =
( ( ( 1.0 - t3496 ) - t2796 ) * t2585_idx_0 + t2586_idx_0 * t3496 ) +
t2587_idx_0 * t2796 ; intrm_sf_mf_1748 = t4821 * t4821 * 3.0 - t4821 * t4821
* t4821 * 2.0 ; if ( X [ 529ULL ] <= 0.0 ) { t4821 = 0.0 ; } else { t4821 = X
[ 529ULL ] >= 1.0 ? 1.0 : X [ 529ULL ] ; } if ( X [ 528ULL ] <= 0.0 ) { t3382
= 0.0 ; } else { t3382 = X [ 528ULL ] >= 1.0 ? 1.0 : X [ 528ULL ] ; } t4747 =
( ( ( 1.0 - t4821 ) - t3382 ) * 296.802103844292 + t4821 * 461.523 ) + t3382
* 259.836612622973 ; t2049 [ 0ULL ] = X [ 527ULL ] ;
tlu2_linear_linear_prelookup ( & jw_efOut . mField0 [ 0ULL ] , & jw_efOut .
mField1 [ 0ULL ] , & jw_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t193 = jw_efOut ; tlu2_1d_linear_linear_value ( & kw_efOut [ 0ULL ] , &
t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
kw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & lw_efOut [ 0ULL ] , & t193 .
mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
lw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & mw_efOut [ 0ULL ] , & t193 .
mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
mw_efOut [ 0 ] ; t4785 = ( ( ( 1.0 - t4821 ) - t3382 ) * t2585_idx_0 +
t2586_idx_0 * t4821 ) + t2587_idx_0 * t3382 ; tlu2_1d_linear_linear_value ( &
nw_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = nw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ow_efOut
[ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField43 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = ow_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & pw_efOut
[ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField44 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = pw_efOut [ 0 ] ; t4821 = ( ( ( 1.0 - t3496 ) - t2796 ) *
t2585_idx_0 + t2586_idx_0 * t3496 ) + t2587_idx_0 * t2796 ;
tlu2_1d_linear_linear_value ( & qw_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] ,
& t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField42 , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = qw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & rw_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] ,
& t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField43 , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = rw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & sw_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] ,
& t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField44 , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = sw_efOut [ 0 ] ; t3382 = (
( ( 1.0 - t3496 ) - t2796 ) * t2585_idx_0 + t2586_idx_0 * t3496 ) +
t2587_idx_0 * t2796 ; if ( X [ 555ULL ] <= 0.0 ) { t4726 = 0.0 ; } else {
t4726 = X [ 555ULL ] >= 1.0 ? 1.0 : X [ 555ULL ] ; } if ( X [ 554ULL ] <= 0.0
) { intrm_sf_mf_1462 = 0.0 ; } else { intrm_sf_mf_1462 = X [ 554ULL ] >= 1.0
? 1.0 : X [ 554ULL ] ; } t4729 = ( ( ( 1.0 - t4726 ) - intrm_sf_mf_1462 ) *
296.802103844292 + t4726 * 461.523 ) + intrm_sf_mf_1462 * 4124.48151675695 ;
t2049 [ 0ULL ] = X [ 553ULL ] ; tlu2_linear_linear_prelookup ( & tw_efOut .
mField0 [ 0ULL ] , & tw_efOut . mField1 [ 0ULL ] , & tw_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t193 = tw_efOut ;
tlu2_1d_linear_linear_value ( & uw_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ]
, & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = uw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & vw_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ]
, & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = vw_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ww_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ]
, & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ww_efOut [ 0 ] ; t4767 =
( ( ( 1.0 - t4726 ) - intrm_sf_mf_1462 ) * t2585_idx_0 + t2586_idx_0 * t4726
) + t2587_idx_0 * intrm_sf_mf_1462 ; t2049 [ 0ULL ] = X [ 278ULL ] ;
tlu2_linear_linear_prelookup ( & xw_efOut . mField0 [ 0ULL ] , & xw_efOut .
mField1 [ 0ULL ] , & xw_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = xw_efOut ; tlu2_1d_linear_linear_value ( & yw_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
yw_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ax_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ax_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & bx_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
bx_efOut [ 0 ] ; t4726 = ( ( ( 1.0 - t3028 ) - t3029 ) * t2585_idx_0 +
t2586_idx_0 * t3028 ) + t2587_idx_0 * t3029 ; t2049 [ 0ULL ] = X [ 175ULL ] ;
tlu2_linear_linear_prelookup ( & cx_efOut . mField0 [ 0ULL ] , & cx_efOut .
mField1 [ 0ULL ] , & cx_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = cx_efOut ; tlu2_1d_linear_linear_value ( & dx_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
dx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ex_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ex_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & fx_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
fx_efOut [ 0 ] ; t3028 = ( ( ( 1.0 - t2849 ) - t2851 ) * t2585_idx_0 +
t2586_idx_0 * t2849 ) + t2587_idx_0 * t2851 ; tlu2_1d_linear_linear_value ( &
gx_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = gx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & hx_efOut
[ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField43 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = hx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ix_efOut
[ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField45 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = ix_efOut [ 0 ] ; t2849 = ( ( ( 1.0 - t3506 ) - t3570 ) *
t2585_idx_0 + t2586_idx_0 * t3506 ) + t2587_idx_0 * t3570 ; if ( t3579 <=
2000.0 ) { t2851 = intrm_sf_mf_1296 ; } else if ( t3579 >= 4000.0 ) { t2851 =
t2757 ; } else { t2851 = ( 1.0 - intrm_sf_mf_1748 ) * intrm_sf_mf_1296 +
t2757 * intrm_sf_mf_1748 ; } tlu2_1d_linear_linear_value ( & jx_efOut [ 0ULL
] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = jx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & kx_efOut
[ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField43 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = kx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & lx_efOut
[ 0ULL ] , & t153 . mField0 [ 0ULL ] , & t153 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField45 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = lx_efOut [ 0 ] ; t3029 = ( ( ( ( ( ( 1.0 - t3506 ) -
t3570 ) * t2585_idx_0 + t2586_idx_0 * t3506 ) + t2587_idx_0 * t3570 ) -
pmf_log ( X [ 38ULL ] * 100000.0 ) * t3572 ) - t2849 ) + pmf_log ( X [ 176ULL
] * 100000.0 ) * t3572 ; tlu2_1d_linear_linear_value ( & mx_efOut [ 0ULL ] ,
& t81 . mField0 [ 0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
mx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & nx_efOut [ 0ULL ] , & t81 .
mField0 [ 0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField43 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = nx_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & ox_efOut [ 0ULL ] , & t81 . mField0 [
0ULL ] , & t81 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField45 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ox_efOut [ 0
] ; t2757 = ( ( ( 1.0 - t3506 ) - t3570 ) * t2585_idx_0 + t2586_idx_0 * t3506
) + t2587_idx_0 * t3570 ; tlu2_1d_linear_linear_value ( & px_efOut [ 0ULL ] ,
& t171 . mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField42 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0
= px_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & qx_efOut [ 0ULL ] , & t171
. mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField43 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
qx_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & rx_efOut [ 0ULL ] , & t171 .
mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField45 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
rx_efOut [ 0 ] ; intrm_sf_mf_1296 = ( ( ( ( ( ( 1.0 - t3506 ) - t3570 ) *
t2585_idx_0 + t2586_idx_0 * t3506 ) + t2587_idx_0 * t3570 ) - pmf_log ( X [
176ULL ] * 100000.0 ) * t3572 ) - t2757 ) + pmf_log ( X [ 38ULL ] * 100000.0
) * t3572 ; tlu2_2d_linear_linear_value ( & sx_efOut [ 0ULL ] , & t188 .
mField0 [ 0ULL ] , & t188 . mField2 [ 0ULL ] , & t182 . mField0 [ 0ULL ] , &
t182 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = sx_efOut
[ 0 ] ; t2757 = t2585_idx_0 ; t2849 = pmf_log ( X [ 7ULL ] ) ;
intrm_sf_mf_1748 = pmf_log ( X [ 148ULL ] ) ; intrm_sf_mf_1462 = pmf_log ( X
[ 144ULL ] ) ; t3482 = pmf_log ( X [ 15ULL ] / 1.0E-5 ) ; t3490 = pmf_log ( X
[ 149ULL ] / 1.0E-5 ) ; t3506 = pmf_log ( X [ 145ULL ] / 1.0E-5 ) ; t3570 =
pmf_log ( X [ 161ULL ] ) ; t3579 = pmf_log ( X [ 162ULL ] ) ; t3582 = pmf_log
( X [ 163ULL ] ) ; U_idx_1 = pmf_sqrt ( X [ 148ULL ] * 402.5245441795231 ) ;
t2819 = pmf_sqrt ( X [ 144ULL ] * 402.5245441795231 ) ; t3590 = X [ 162ULL ]
* U_idx_1 * 1.0E-6 ; U_idx_1 = X [ 163ULL ] * t2819 * 1.0E-6 ; t2819 =
pmf_sqrt ( X [ 154ULL ] * X [ 154ULL ] + t3590 * t3590 ) ; t3590 = pmf_sqrt (
U_idx_1 * U_idx_1 ) ; if ( - U_idx_2 >= 0.0 ) { t3596 = 0.0 ; } else {
zc_int350 = X [ 159ULL ] * 1.2337005501361696E-8 ; t3596 = U_idx_2 * U_idx_2
/ ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) * 1.0E-5 ; } if ( U_idx_2 >= 0.0
) { t3598 = 0.0 ; } else { zc_int350 = X [ 160ULL ] * 1.2337005501361696E-8 ;
t3598 = U_idx_2 * U_idx_2 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) *
1.0E-5 ; } if ( U_idx_13 >= 1.0 ) { t3599 = 1.0 ; } else { t3599 = U_idx_13
<= 0.0 ? 0.0 : U_idx_13 ; } if ( - U_idx_2 >= 0.0 ) { t3600 = - U_idx_2 ; }
else { t3600 = U_idx_2 ; } tlu2_2d_linear_linear_value ( & tx_efOut [ 0ULL ]
, & t178 . mField0 [ 0ULL ] , & t178 . mField2 [ 0ULL ] , & t51 . mField0 [
0ULL ] , & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField36 , & t1006 [ 0ULL ] , & t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = tx_efOut [ 0 ] ; t3601 = t2585_idx_0 ; t4221 = t3600 * 0.01 ;
intrm_sf_mf_393 = t4221 / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) ; t3603 =
X [ 55ULL ] / ( t4747 == 0.0 ? 1.0E-16 : t4747 ) / ( X [ 527ULL ] == 0.0 ?
1.0E-16 : X [ 527ULL ] ) ; t2049 [ 0ULL ] = X [ 77ULL ] ; t1647 [ 0 ] = 23ULL
; tlu2_linear_nearest_prelookup ( & ux_efOut . mField0 [ 0ULL ] , & ux_efOut
. mField1 [ 0ULL ] , & ux_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField47 , & t2049 [ 0ULL ] , & t1647 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = ux_efOut ; t2049 [ 0ULL ] = X [ 581ULL ] ; t1921 [ 0 ] = 29ULL ;
tlu2_linear_nearest_prelookup ( & vx_efOut . mField0 [ 0ULL ] , & vx_efOut .
mField1 [ 0ULL ] , & vx_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField48 , & t2049 [ 0ULL ] , & t1921 [ 0ULL ] , & t225 [ 0ULL ] )
; t171 = vx_efOut ; tlu2_2d_linear_nearest_value ( & wx_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , & t171 . mField0 [ 0ULL
] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField46
, & t1647 [ 0ULL ] , & t1921 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
wx_efOut [ 0 ] ; U_idx_1 = t2585_idx_0 ; tlu2_2d_linear_nearest_value ( &
xx_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , &
t171 . mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField49 , & t1647 [ 0ULL ] , & t1921 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = xx_efOut [ 0 ] ; t3606 = ( t2585_idx_0 - U_idx_1 ) * ( (
X [ 13ULL ] - 298.15 ) / 100.0 ) + U_idx_1 ; t2049 [ 0ULL ] = X [ 194ULL ] ;
tlu2_linear_linear_prelookup ( & yx_efOut . mField0 [ 0ULL ] , & yx_efOut .
mField1 [ 0ULL ] , & yx_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = yx_efOut ; tlu2_1d_linear_linear_value ( & ay_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ay_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & by_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
by_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & cy_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
cy_efOut [ 0 ] ; intrm_sf_mf_199 = ( ( ( 1.0 - t2860 ) - t2864 ) *
t2585_idx_0 + t2586_idx_0 * t2860 ) + t2587_idx_0 * t2864 ; t2860 =
intrm_sf_mf_393 >= 2000.0 ? intrm_sf_mf_393 : 1.0 ; t2049 [ 0ULL ] = X [
199ULL ] ; tlu2_linear_linear_prelookup ( & dy_efOut . mField0 [ 0ULL ] , &
dy_efOut . mField1 [ 0ULL ] , & dy_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = dy_efOut ; tlu2_1d_linear_linear_value ( &
ey_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = ey_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
fy_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = fy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
gy_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = gy_efOut [ 0 ] ; t2864 = ( ( ( 1.0 - t2808 ) - t2809
) * t2585_idx_0 + t2586_idx_0 * t2808 ) + t2587_idx_0 * t2809 ; t2049 [ 0ULL
] = X [ 203ULL ] ; tlu2_linear_linear_prelookup ( & hy_efOut . mField0 [ 0ULL
] , & hy_efOut . mField1 [ 0ULL ] , & hy_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = hy_efOut ; tlu2_1d_linear_linear_value ( &
iy_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = iy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
jy_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = jy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
ky_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = ky_efOut [ 0 ] ; t3608 = ( ( ( 1.0 - t2808 ) - t2809
) * t2585_idx_0 + t2586_idx_0 * t2808 ) + t2587_idx_0 * t2809 ; zc_int350 =
pmf_log10 ( 6.9 / ( t2860 == 0.0 ? 1.0E-16 : t2860 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t2860 == 0.0 ? 1.0E-16 : t2860 ) +
0.00017169489553429715 ) * 3.24 ; t2860 = 1.0 / ( zc_int350 == 0.0 ? 1.0E-16
: zc_int350 ) * 0.55 / 0.01 ; t3609 = t2806 >= 0.0 ? t2806 : - t2806 ; t3610
= t3609 * 0.01 / ( t4494 == 0.0 ? 1.0E-16 : t4494 ) ; t3611 = t3610 >= 1.0 ?
t3610 : 1.0 ; zc_int350 = pmf_log10 ( 6.9 / ( t3611 == 0.0 ? 1.0E-16 : t3611
) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3611 == 0.0 ? 1.0E-16 :
t3611 ) + 0.00017169489553429715 ) * 3.24 ; t3612 = t2806 * t2818 * 35.2 / (
t4487 == 0.0 ? 1.0E-16 : t4487 ) ; t3609 = t2806 * t3609 * ( 1.0 / (
zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ) * 0.55 / ( t2850 == 0.0 ? 1.0E-16
: t2850 ) ; t3611 = ( t3610 - 2000.0 ) / 2000.0 ; t3613 = t3611 * t3611 * 3.0
- t3611 * t3611 * t3611 * 2.0 ; intrm_sf_mf_261 = U_idx_2 * intrm_sf_mf_261 *
- 35.2 / ( U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) * 1.0E-5 ; if ( t3610 <=
2000.0 ) { t3611 = t3612 * 9.9999999999999991E-11 ; } else if ( t3610 >=
4000.0 ) { t3611 = t3609 * 9.9999999999999991E-11 ; } else { t3611 = ( ( 1.0
- t3613 ) * t3612 + t3609 * t3613 ) * 9.9999999999999991E-11 ; } if ( - X [
186ULL ] >= 0.0 ) { t3609 = - X [ 186ULL ] ; } else { t3609 = X [ 186ULL ] ;
} t3610 = t3609 * 0.01 / ( t4494 == 0.0 ? 1.0E-16 : t4494 ) ; t3612 = t3610
>= 1.0 ? t3610 : 1.0 ; zc_int350 = pmf_log10 ( 6.9 / ( t3612 == 0.0 ? 1.0E-16
: t3612 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3612 == 0.0 ?
1.0E-16 : t3612 ) + 0.00017169489553429715 ) * 3.24 ; t3613 = X [ 186ULL ] *
t2818 * - 35.2 / ( t4487 == 0.0 ? 1.0E-16 : t4487 ) ; t3609 = X [ 186ULL ] *
t3609 * ( 1.0 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ) * - 0.55 / (
t2850 == 0.0 ? 1.0E-16 : t2850 ) ; t3612 = ( t3610 - 2000.0 ) / 2000.0 ;
U_idx_7 = t3612 * t3612 * 3.0 - t3612 * t3612 * t3612 * 2.0 ; if ( t3610 <=
2000.0 ) { t3612 = t3613 * 9.9999999999999991E-11 ; } else if ( t3610 >=
4000.0 ) { t3612 = t3609 * 9.9999999999999991E-11 ; } else { t3612 = ( ( 1.0
- U_idx_7 ) * t3613 + t3609 * U_idx_7 ) * 9.9999999999999991E-11 ; } t2860 =
- ( U_idx_2 * t3600 * t2860 ) / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) * 1.0E-5 ;
t3609 = ( intrm_sf_mf_393 - 2000.0 ) / 2000.0 ; t3610 = t3609 * t3609 * 3.0 -
t3609 * t3609 * t3609 * 2.0 ; if ( X [ 182ULL ] <= 0.0 ) { t3609 = 0.0 ; }
else { t3609 = X [ 182ULL ] >= 1.0 ? 1.0 : X [ 182ULL ] ; } if ( X [ 181ULL ]
<= 0.0 ) { t3613 = 0.0 ; } else { t3613 = X [ 181ULL ] >= 1.0 ? 1.0 : X [
181ULL ] ; } U_idx_7 = ( ( ( 1.0 - t3609 ) - t3613 ) * 296.802103844292 +
t3609 * 461.523 ) + t3613 * 4124.48151675695 ; t2049 [ 0ULL ] = X [ 180ULL ]
; tlu2_linear_linear_prelookup ( & ly_efOut . mField0 [ 0ULL ] , & ly_efOut .
mField1 [ 0ULL ] , & ly_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t99 = ly_efOut ; tlu2_1d_linear_linear_value ( & my_efOut [ 0ULL ] , & t99
. mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
my_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ny_efOut [ 0ULL ] , & t99 .
mField0 [ 0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = ny_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & oy_efOut [ 0ULL ] , & t99 . mField0 [
0ULL ] , & t99 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = oy_efOut [ 0
] ; t2815 = ( ( ( 1.0 - t3609 ) - t3613 ) * t2585_idx_0 + t2586_idx_0 * t3609
) + t2587_idx_0 * t3613 ; t2049 [ 0ULL ] = X [ 223ULL ] ;
tlu2_linear_linear_prelookup ( & py_efOut . mField0 [ 0ULL ] , & py_efOut .
mField1 [ 0ULL ] , & py_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t166 = py_efOut ; tlu2_1d_linear_linear_value ( & qy_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
qy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ry_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ry_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & sy_efOut [ 0ULL ] , & t166 .
mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
sy_efOut [ 0 ] ; t3609 = ( ( ( 1.0 - t2881 ) - intrm_sf_mf_517 ) *
t2585_idx_0 + t2586_idx_0 * t2881 ) + t2587_idx_0 * intrm_sf_mf_517 ; if (
intrm_sf_mf_393 <= 2000.0 ) { t3613 = intrm_sf_mf_261 ; } else if (
intrm_sf_mf_393 >= 4000.0 ) { t3613 = t2860 ; } else { t3613 = ( 1.0 - t3610
) * intrm_sf_mf_261 + t2860 * t3610 ; } t2049 [ 0ULL ] = X [ 224ULL ] ;
tlu2_linear_linear_prelookup ( & ty_efOut . mField0 [ 0ULL ] , & ty_efOut .
mField1 [ 0ULL ] , & ty_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] )
; t55 = ty_efOut ; tlu2_1d_linear_linear_value ( & uy_efOut [ 0ULL ] , & t55
. mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
uy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & vy_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = vy_efOut
[ 0 ] ; tlu2_1d_linear_linear_value ( & wy_efOut [ 0ULL ] , & t55 . mField0 [
0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = wy_efOut [ 0
] ; intrm_sf_mf_261 = ( ( ( 1.0 - t2881 ) - intrm_sf_mf_517 ) * t2585_idx_0 +
t2586_idx_0 * t2881 ) + t2587_idx_0 * intrm_sf_mf_517 ; t2049 [ 0ULL ] = X [
219ULL ] ; tlu2_linear_linear_prelookup ( & xy_efOut . mField0 [ 0ULL ] , &
xy_efOut . mField1 [ 0ULL ] , & xy_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = xy_efOut ; tlu2_1d_linear_linear_value ( &
yy_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = yy_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
aab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = aab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
bab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = bab_efOut [ 0 ] ; t2860 = ( ( ( 1.0 - t2881 ) -
intrm_sf_mf_517 ) * t2585_idx_0 + t2586_idx_0 * t2881 ) + t2587_idx_0 *
intrm_sf_mf_517 ; zc_int350 = intrm_sf_mf_383 - ( - intrm_sf_mf_383 ) ; t2881
= ( ( X [ 195ULL ] - 1.01325 ) - ( - intrm_sf_mf_383 ) ) / ( zc_int350 == 0.0
? 1.0E-16 : zc_int350 ) ; intrm_sf_mf_517 = t2881 * t2881 * 3.0 - t2881 *
t2881 * t2881 * 2.0 ; if ( X [ 195ULL ] - 1.01325 <= - intrm_sf_mf_383 ) {
t2881 = 1.01325 ; } else if ( X [ 195ULL ] - 1.01325 >= intrm_sf_mf_383 ) {
t2881 = X [ 195ULL ] ; } else { t2881 = ( 1.0 - intrm_sf_mf_517 ) * 1.01325 +
X [ 195ULL ] * intrm_sf_mf_517 ; } intrm_sf_mf_517 = ( X [ 81ULL ] - 0.9 ) /
0.099999999999999978 ; t4251 = t2766 * 7.8539816339744827E-5 ;
intrm_sf_mf_383 = t4165 / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ;
intrm_sf_mf_393 = intrm_sf_mf_383 >= 2000.0 ? intrm_sf_mf_383 : 1.0 ;
zc_int350 = pmf_log10 ( 6.9 / ( intrm_sf_mf_393 == 0.0 ? 1.0E-16 :
intrm_sf_mf_393 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_393 == 0.0 ? 1.0E-16 : intrm_sf_mf_393 ) + 0.00017169489553429715
) * 3.24 ; U_idx_10 = t2761 * 1.5707963267948965E-8 ; t3610 = U_idx_2 * t2766
* 35.2 / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) * 1.0E-5 ; t5294 = t2761 *
1.2337005501361696E-8 ; t2761 = U_idx_2 * ( 1.0 / ( zc_int350 == 0.0 ?
1.0E-16 : zc_int350 ) * 0.55 / 0.01 ) * t3578 / ( t5294 == 0.0 ? 1.0E-16 :
t5294 ) * 1.0E-5 ; intrm_sf_mf_393 = ( intrm_sf_mf_383 - 2000.0 ) / 2000.0 ;
t2049 [ 0ULL ] = X [ 240ULL ] ; tlu2_linear_linear_prelookup ( & cab_efOut .
mField0 [ 0ULL ] , & cab_efOut . mField1 [ 0ULL ] , & cab_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = cab_efOut ;
tlu2_1d_linear_linear_value ( & dab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = dab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & eab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = eab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & fab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = fab_efOut [ 0 ] ;
t3616 = ( ( ( 1.0 - zc_int220 ) - t2919 ) * t2585_idx_0 + t2586_idx_0 *
zc_int220 ) + t2587_idx_0 * t2919 ; zc_int220 = intrm_sf_mf_393 *
intrm_sf_mf_393 * 3.0 - intrm_sf_mf_393 * intrm_sf_mf_393 * intrm_sf_mf_393 *
2.0 ; t2049 [ 0ULL ] = X [ 226ULL ] ; tlu2_linear_linear_prelookup ( &
gab_efOut . mField0 [ 0ULL ] , & gab_efOut . mField1 [ 0ULL ] , & gab_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t171 = gab_efOut ;
tlu2_1d_linear_linear_value ( & hab_efOut [ 0ULL ] , & t171 . mField0 [ 0ULL
] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = hab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & iab_efOut [ 0ULL ] , & t171 . mField0 [ 0ULL
] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = iab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & jab_efOut [ 0ULL ] , & t171 . mField0 [ 0ULL
] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = jab_efOut [ 0 ] ;
t2919 = ( ( ( 1.0 - t2923 ) - t2926 ) * t2585_idx_0 + t2586_idx_0 * t2923 ) +
t2587_idx_0 * t2926 ; if ( intrm_sf_mf_383 <= 2000.0 ) { t2923 = t3610 ; }
else if ( intrm_sf_mf_383 >= 4000.0 ) { t2923 = t2761 ; } else { t2923 = (
1.0 - zc_int220 ) * t3610 + t2761 * zc_int220 ; } t2049 [ 0ULL ] = X [ 245ULL
] ; tlu2_linear_linear_prelookup ( & kab_efOut . mField0 [ 0ULL ] , &
kab_efOut . mField1 [ 0ULL ] , & kab_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t166 = kab_efOut ; tlu2_1d_linear_linear_value ( &
lab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = lab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
mab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = mab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
nab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = nab_efOut [ 0 ] ; t2761 = ( ( ( 1.0 -
intrm_sf_mf_249 ) - t2888 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_249 ) +
t2587_idx_0 * t2888 ; t2049 [ 0ULL ] = X [ 248ULL ] ;
tlu2_linear_linear_prelookup ( & oab_efOut . mField0 [ 0ULL ] , & oab_efOut .
mField1 [ 0ULL ] , & oab_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = oab_efOut ; tlu2_1d_linear_linear_value ( & pab_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
pab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & qab_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
qab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & rab_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
rab_efOut [ 0 ] ; intrm_sf_mf_383 = ( ( ( 1.0 - intrm_sf_mf_249 ) - t2888 ) *
t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_249 ) + t2587_idx_0 * t2888 ;
zc_int220 = X [ 244ULL ] >= 0.0 ? X [ 244ULL ] : - X [ 244ULL ] ; t2926 =
zc_int220 * 0.01 / ( t2966 == 0.0 ? 1.0E-16 : t2966 ) ; intrm_sf_mf_393 =
t2926 >= 1.0 ? t2926 : 1.0 ; zc_int350 = pmf_log10 ( 6.9 / ( intrm_sf_mf_393
== 0.0 ? 1.0E-16 : intrm_sf_mf_393 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( intrm_sf_mf_393 == 0.0 ? 1.0E-16 : intrm_sf_mf_393 ) +
0.00017169489553429715 ) * 3.24 ; t3610 = X [ 244ULL ] * t2898 *
2.9973120849090416 / ( t2970 == 0.0 ? 1.0E-16 : t2970 ) ; zc_int220 = X [
244ULL ] * zc_int220 * ( 1.0 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ) *
0.046833001326703774 / ( t2973 == 0.0 ? 1.0E-16 : t2973 ) ; intrm_sf_mf_393 =
( t2926 - 2000.0 ) / 2000.0 ; t3617 = intrm_sf_mf_393 * intrm_sf_mf_393 * 3.0
- intrm_sf_mf_393 * intrm_sf_mf_393 * intrm_sf_mf_393 * 2.0 ; if ( t2926 <=
2000.0 ) { intrm_sf_mf_393 = t3610 * 9.9999999999999991E-11 ; } else if (
t2926 >= 4000.0 ) { intrm_sf_mf_393 = zc_int220 * 9.9999999999999991E-11 ; }
else { intrm_sf_mf_393 = ( ( 1.0 - t3617 ) * t3610 + zc_int220 * t3617 ) *
9.9999999999999991E-11 ; } zc_int220 = X [ 247ULL ] >= 0.0 ? X [ 247ULL ] : -
X [ 247ULL ] ; t2926 = zc_int220 * 0.01 / ( t2966 == 0.0 ? 1.0E-16 : t2966 )
; t3610 = t2926 >= 1.0 ? t2926 : 1.0 ; zc_int350 = pmf_log10 ( 6.9 / ( t3610
== 0.0 ? 1.0E-16 : t3610 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t3610 == 0.0 ? 1.0E-16 : t3610 ) + 0.00017169489553429715 ) * 3.24 ; t3617 =
intrm_sf_mf_517 * intrm_sf_mf_517 * 3.0 - intrm_sf_mf_517 * intrm_sf_mf_517 *
intrm_sf_mf_517 * 2.0 ; intrm_sf_mf_517 = t4221 / ( t4251 == 0.0 ? 1.0E-16 :
t4251 ) ; t3618 = X [ 247ULL ] * t2898 * 2.9973120849090416 / ( t2970 == 0.0
? 1.0E-16 : t2970 ) ; zc_int220 = X [ 247ULL ] * zc_int220 * ( 1.0 / (
zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ) * 0.046833001326703774 / ( t2973
== 0.0 ? 1.0E-16 : t2973 ) ; t3610 = ( t2926 - 2000.0 ) / 2000.0 ; t3620 =
t3610 * t3610 * 3.0 - t3610 * t3610 * t3610 * 2.0 ; if ( t2926 <= 2000.0 ) {
t3610 = t3618 * 9.9999999999999991E-11 ; } else if ( t2926 >= 4000.0 ) {
t3610 = zc_int220 * 9.9999999999999991E-11 ; } else { t3610 = ( ( 1.0 - t3620
) * t3618 + zc_int220 * t3620 ) * 9.9999999999999991E-11 ; } zc_int220 =
intrm_sf_mf_517 >= 2000.0 ? intrm_sf_mf_517 : 1.0 ; t4251 = pmf_log10 ( 6.9 /
( zc_int220 == 0.0 ? 1.0E-16 : zc_int220 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( zc_int220 == 0.0 ? 1.0E-16 : zc_int220 ) +
0.00017169489553429715 ) * 3.24 ; t2766 = U_idx_2 * t2766 * - 35.2 / (
U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) * 1.0E-5 ; zc_int220 = - ( U_idx_2 *
t3600 * ( 1.0 / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) * 0.55 / 0.01 ) ) / (
t5294 == 0.0 ? 1.0E-16 : t5294 ) * 1.0E-5 ; t2926 = ( intrm_sf_mf_517 -
2000.0 ) / 2000.0 ; t3618 = t2926 * t2926 * 3.0 - t2926 * t2926 * t2926 * 2.0
; if ( intrm_sf_mf_517 <= 2000.0 ) { t2926 = t2766 ; } else if (
intrm_sf_mf_517 >= 4000.0 ) { t2926 = zc_int220 ; } else { t2926 = ( 1.0 -
t3618 ) * t2766 + zc_int220 * t3618 ; } if ( X [ 81ULL ] <= 0.9 ) { t2766 =
0.0 ; } else { t2766 = X [ 81ULL ] >= 1.0 ? 1.0 : t3617 ; } t2049 [ 0ULL ] =
X [ 263ULL ] ; tlu2_linear_linear_prelookup ( & sab_efOut . mField0 [ 0ULL ]
, & sab_efOut . mField1 [ 0ULL ] , & sab_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t3 = sab_efOut ; tlu2_1d_linear_linear_value ( &
tab_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2585_idx_0 = tab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
uab_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2586_idx_0 = uab_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
vab_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2587_idx_0 = vab_efOut [ 0 ] ; intrm_sf_mf_517 = ( ( ( 1.0 - t2911 ) -
t2951 ) * t2585_idx_0 + t2586_idx_0 * t2911 ) + t2587_idx_0 * t2951 ; t4251 =
t2774 * 7.8539816339744827E-5 ; zc_int220 = t4165 / ( t4251 == 0.0 ? 1.0E-16
: t4251 ) ; t2049 [ 0ULL ] = X [ 265ULL ] ; tlu2_linear_linear_prelookup ( &
wab_efOut . mField0 [ 0ULL ] , & wab_efOut . mField1 [ 0ULL ] , & wab_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [
0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = wab_efOut ;
tlu2_1d_linear_linear_value ( & xab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & yab_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = yab_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & abb_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = abb_efOut [ 0 ] ;
t3617 = ( ( ( 1.0 - t2911 ) - t2951 ) * t2585_idx_0 + t2586_idx_0 * t2911 ) +
t2587_idx_0 * t2951 ; if ( - X [ 247ULL ] >= 0.0 ) { t3618 = - X [ 247ULL ] ;
} else { t3618 = X [ 247ULL ] ; } t3620 = t3618 * 0.01 / ( t3060 == 0.0 ?
1.0E-16 : t3060 ) ; t3621 = t3620 >= 1.0 ? t3620 : 1.0 ; zc_int350 =
pmf_log10 ( 6.9 / ( t3621 == 0.0 ? 1.0E-16 : t3621 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t3621 == 0.0 ? 1.0E-16 : t3621 ) +
0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_541 = X [ 247ULL ] * piece81 *
- 2.9973120849090416 / ( t3064 == 0.0 ? 1.0E-16 : t3064 ) ; t3618 = X [
247ULL ] * t3618 * ( 1.0 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) ) * -
0.046833001326703774 / ( t3067 == 0.0 ? 1.0E-16 : t3067 ) ; t3621 = zc_int220
>= 2000.0 ? zc_int220 : 1.0 ; t3623 = ( t3620 - 2000.0 ) / 2000.0 ; t4473 =
t3623 * t3623 * 3.0 - t3623 * t3623 * t3623 * 2.0 ; if ( t3620 <= 2000.0 ) {
t3623 = intrm_sf_mf_541 * 9.9999999999999991E-11 ; } else if ( t3620 >=
4000.0 ) { t3623 = t3618 * 9.9999999999999991E-11 ; } else { t3623 = ( ( 1.0
- t4473 ) * intrm_sf_mf_541 + t3618 * t4473 ) * 9.9999999999999991E-11 ; }
t3618 = X [ 198ULL ] >= 0.0 ? X [ 198ULL ] : - X [ 198ULL ] ; t3620 = t3618 *
0.01 / ( t3060 == 0.0 ? 1.0E-16 : t3060 ) ; intrm_sf_mf_541 = t3620 >= 1.0 ?
t3620 : 1.0 ; zc_int350 = pmf_log10 ( 6.9 / ( intrm_sf_mf_541 == 0.0 ?
1.0E-16 : intrm_sf_mf_541 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_541 == 0.0 ? 1.0E-16 : intrm_sf_mf_541 ) + 0.00017169489553429715
) * 3.24 ; t4473 = X [ 198ULL ] * piece81 * 2.9973120849090416 / ( t3064 ==
0.0 ? 1.0E-16 : t3064 ) ; t3618 = X [ 198ULL ] * t3618 * ( 1.0 / ( zc_int350
== 0.0 ? 1.0E-16 : zc_int350 ) ) * 0.046833001326703774 / ( t3067 == 0.0 ?
1.0E-16 : t3067 ) ; intrm_sf_mf_541 = ( t3620 - 2000.0 ) / 2000.0 ; zc_int350
= pmf_log10 ( 6.9 / ( t3621 == 0.0 ? 1.0E-16 : t3621 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3621 == 0.0 ? 1.0E-16 : t3621
) + 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_821 = intrm_sf_mf_541 *
intrm_sf_mf_541 * 3.0 - intrm_sf_mf_541 * intrm_sf_mf_541 * intrm_sf_mf_541 *
2.0 ; if ( t3620 <= 2000.0 ) { intrm_sf_mf_541 = t4473 *
9.9999999999999991E-11 ; } else if ( t3620 >= 4000.0 ) { intrm_sf_mf_541 =
t3618 * 9.9999999999999991E-11 ; } else { intrm_sf_mf_541 = ( ( 1.0 -
intrm_sf_mf_821 ) * t4473 + t3618 * intrm_sf_mf_821 ) *
9.9999999999999991E-11 ; } t4165 = t2743 * 1.5707963267948965E-8 ; t3618 =
U_idx_2 * t2774 * 35.2 / ( t4165 == 0.0 ? 1.0E-16 : t4165 ) * 1.0E-5 ;
U_idx_10 = t2743 * 1.2337005501361696E-8 ; t2743 = U_idx_2 * ( 1.0 / (
zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) * 0.55 / 0.01 ) * t3578 / ( U_idx_10
== 0.0 ? 1.0E-16 : U_idx_10 ) * 1.0E-5 ; t3578 = ( zc_int220 - 2000.0 ) /
2000.0 ; t3620 = t3578 * t3578 * 3.0 - t3578 * t3578 * t3578 * 2.0 ; if (
zc_int220 <= 2000.0 ) { t3578 = t3618 ; } else if ( zc_int220 >= 4000.0 ) {
t3578 = t2743 ; } else { t3578 = ( 1.0 - t3620 ) * t3618 + t2743 * t3620 ; }
t2743 = t4221 / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ; zc_int220 = t2743 >=
2000.0 ? t2743 : 1.0 ; t4221 = pmf_log10 ( 6.9 / ( zc_int220 == 0.0 ? 1.0E-16
: zc_int220 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( zc_int220 ==
0.0 ? 1.0E-16 : zc_int220 ) + 0.00017169489553429715 ) * 3.24 ; t2774 =
U_idx_2 * t2774 * - 35.2 / ( t4165 == 0.0 ? 1.0E-16 : t4165 ) * 1.0E-5 ;
zc_int220 = - ( U_idx_2 * t3600 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 )
* 0.55 / 0.01 ) ) / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) * 1.0E-5 ; t2049
[ 0ULL ] = X [ 289ULL ] ; tlu2_linear_linear_prelookup ( & bbb_efOut .
mField0 [ 0ULL ] , & bbb_efOut . mField1 [ 0ULL ] , & bbb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t193 = bbb_efOut ;
tlu2_1d_linear_linear_value ( & cbb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL
] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = cbb_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & dbb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL
] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 = dbb_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ebb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL
] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 = ebb_efOut [ 0 ] ;
t3600 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) - t3002 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) +
t2587_idx_0 * t3002 ; t2049 [ 0ULL ] = X [ 291ULL ] ;
tlu2_linear_linear_prelookup ( & fbb_efOut . mField0 [ 0ULL ] , & fbb_efOut .
mField1 [ 0ULL ] , & fbb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = fbb_efOut ; tlu2_1d_linear_linear_value ( & gbb_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
gbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & hbb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
hbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ibb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField27 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ibb_efOut [ 0 ] ; t3618 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) - t3002 ) *
t2585_idx_0 + t2586_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ) +
t2587_idx_0 * t3002 ; t3620 = ( t2743 - 2000.0 ) / 2000.0 ; t3621 = X [
288ULL ] >= 0.0 ? X [ 288ULL ] : - X [ 288ULL ] ; t4473 = t3621 * 0.05 / (
t4426 == 0.0 ? 1.0E-16 : t4426 ) ; intrm_sf_mf_821 = t4473 >= 1.0 ? t4473 :
1.0 ; t4221 = pmf_log10 ( 6.9 / ( intrm_sf_mf_821 == 0.0 ? 1.0E-16 :
intrm_sf_mf_821 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_821 == 0.0 ? 1.0E-16 : intrm_sf_mf_821 ) + 2.8767404433520813E-5
) * 3.24 ; t3626 = X [ 288ULL ] * t3009 * 11.2 / ( t4440 == 0.0 ? 1.0E-16 :
t4440 ) ; t3621 = X [ 288ULL ] * t3621 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 :
t4221 ) ) * 0.175 / ( t4298 == 0.0 ? 1.0E-16 : t4298 ) ; intrm_sf_mf_821 = (
t4473 - 2000.0 ) / 2000.0 ; t3627 = intrm_sf_mf_821 * intrm_sf_mf_821 * 3.0 -
intrm_sf_mf_821 * intrm_sf_mf_821 * intrm_sf_mf_821 * 2.0 ; intrm_sf_mf_821 =
t3620 * t3620 * 3.0 - t3620 * t3620 * t3620 * 2.0 ; if ( t4473 <= 2000.0 ) {
t3620 = t3626 * 9.9999999999999991E-11 ; } else if ( t4473 >= 4000.0 ) {
t3620 = t3621 * 9.9999999999999991E-11 ; } else { t3620 = ( ( 1.0 - t3627 ) *
t3626 + t3621 * t3627 ) * 9.9999999999999991E-11 ; } if ( - X [ 244ULL ] >=
0.0 ) { t3621 = - X [ 244ULL ] ; } else { t3621 = X [ 244ULL ] ; } t4473 =
t3621 * 0.05 / ( t4426 == 0.0 ? 1.0E-16 : t4426 ) ; t3626 = t4473 >= 1.0 ?
t4473 : 1.0 ; t4221 = pmf_log10 ( 6.9 / ( t3626 == 0.0 ? 1.0E-16 : t3626 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3626 == 0.0 ? 1.0E-16 : t3626
) + 2.8767404433520813E-5 ) * 3.24 ; t3627 = X [ 244ULL ] * t3009 * - 11.2 /
( t4440 == 0.0 ? 1.0E-16 : t4440 ) ; t3621 = X [ 244ULL ] * t3621 * ( 1.0 / (
t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * - 0.175 / ( t4298 == 0.0 ? 1.0E-16 :
t4298 ) ; t3626 = ( t4473 - 2000.0 ) / 2000.0 ; intrm_sf_mf_826 = t3626 *
t3626 * 3.0 - t3626 * t3626 * t3626 * 2.0 ; if ( t4473 <= 2000.0 ) { t3626 =
t3627 * 9.9999999999999991E-11 ; } else if ( t4473 >= 4000.0 ) { t3626 =
t3621 * 9.9999999999999991E-11 ; } else { t3626 = ( ( 1.0 - intrm_sf_mf_826 )
* t3627 + t3621 * intrm_sf_mf_826 ) * 9.9999999999999991E-11 ; } if ( t2743
<= 2000.0 ) { t3621 = t2774 ; } else if ( t2743 >= 4000.0 ) { t3621 =
zc_int220 ; } else { t3621 = ( 1.0 - intrm_sf_mf_821 ) * t2774 + zc_int220 *
intrm_sf_mf_821 ; } if ( X [ 309ULL ] <= 0.0 ) { t2743 = 0.0 ; } else { t2743
= X [ 309ULL ] >= 1.0 ? 1.0 : X [ 309ULL ] ; } if ( X [ 308ULL ] <= 0.0 ) {
t2774 = 0.0 ; } else { t2774 = X [ 308ULL ] >= 1.0 ? 1.0 : X [ 308ULL ] ; }
zc_int220 = ( ( ( 1.0 - t2743 ) - t2774 ) * 296.802103844292 + t2743 *
461.523 ) + t2774 * 259.836612622973 ; t2049 [ 0ULL ] = X [ 307ULL ] ;
tlu2_linear_linear_prelookup ( & jbb_efOut . mField0 [ 0ULL ] , & jbb_efOut .
mField1 [ 0ULL ] , & jbb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t171 = jbb_efOut ; tlu2_1d_linear_linear_value ( & kbb_efOut [ 0ULL ] , &
t171 . mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
kbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & lbb_efOut [ 0ULL ] , & t171
. mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
lbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & mbb_efOut [ 0ULL ] , & t171
. mField0 [ 0ULL ] , & t171 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
mbb_efOut [ 0 ] ; t4473 = ( ( ( 1.0 - t2743 ) - t2774 ) * t2585_idx_0 +
t2586_idx_0 * t2743 ) + t2587_idx_0 * t2774 ; t2049 [ 0ULL ] = X [ 321ULL ] ;
tlu2_linear_linear_prelookup ( & nbb_efOut . mField0 [ 0ULL ] , & nbb_efOut .
mField1 [ 0ULL ] , & nbb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t45 = nbb_efOut ; tlu2_1d_linear_linear_value ( & obb_efOut [ 0ULL ] , &
t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
obb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & pbb_efOut [ 0ULL ] , & t45
. mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
pbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & qbb_efOut [ 0ULL ] , & t45
. mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
qbb_efOut [ 0 ] ; t2743 = ( ( ( 1.0 - t3098 ) - t3100 ) * t2585_idx_0 +
t2586_idx_0 * t3098 ) + t2587_idx_0 * t3100 ; t2049 [ 0ULL ] = X [ 326ULL ] ;
tlu2_linear_linear_prelookup ( & rbb_efOut . mField0 [ 0ULL ] , & rbb_efOut .
mField1 [ 0ULL ] , & rbb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = rbb_efOut ; tlu2_1d_linear_linear_value ( & sbb_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
sbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & tbb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
tbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ubb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ubb_efOut [ 0 ] ; t2774 = ( ( ( 1.0 - t3049 ) - t3050 ) * t2585_idx_0 +
t2586_idx_0 * t3049 ) + t2587_idx_0 * t3050 ; t2049 [ 0ULL ] = X [ 330ULL ] ;
tlu2_linear_linear_prelookup ( & vbb_efOut . mField0 [ 0ULL ] , & vbb_efOut .
mField1 [ 0ULL ] , & vbb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = vbb_efOut ; tlu2_1d_linear_linear_value ( & wbb_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
wbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & xbb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
xbb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ybb_efOut [ 0ULL ] , & t166
. mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
ybb_efOut [ 0 ] ; t3098 = ( ( ( 1.0 - t3049 ) - t3050 ) * t2585_idx_0 +
t2586_idx_0 * t3049 ) + t2587_idx_0 * t3050 ; t3100 = X [ 325ULL ] >= 0.0 ? X
[ 325ULL ] : - X [ 325ULL ] ; intrm_sf_mf_821 = t3100 * 0.05 / ( t4363 == 0.0
? 1.0E-16 : t4363 ) ; t3627 = intrm_sf_mf_821 >= 1.0 ? intrm_sf_mf_821 : 1.0
; t4221 = pmf_log10 ( 6.9 / ( t3627 == 0.0 ? 1.0E-16 : t3627 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3627 == 0.0 ? 1.0E-16 : t3627
) + 2.8767404433520813E-5 ) * 3.24 ; intrm_sf_mf_826 = X [ 325ULL ] * t3066 *
35.2 / ( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; t3100 = X [ 325ULL ] * t3100 * (
1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * 0.55 / ( t4367 == 0.0 ? 1.0E-16
: t4367 ) ; t3627 = ( intrm_sf_mf_821 - 2000.0 ) / 2000.0 ; intrm_sf_mf_863 =
t3627 * t3627 * 3.0 - t3627 * t3627 * t3627 * 2.0 ; if ( intrm_sf_mf_821 <=
2000.0 ) { t3627 = intrm_sf_mf_826 * 9.9999999999999991E-11 ; } else if (
intrm_sf_mf_821 >= 4000.0 ) { t3627 = t3100 * 9.9999999999999991E-11 ; } else
{ t3627 = ( ( 1.0 - intrm_sf_mf_863 ) * intrm_sf_mf_826 + t3100 *
intrm_sf_mf_863 ) * 9.9999999999999991E-11 ; } if ( - X [ 313ULL ] >= 0.0 ) {
t3100 = - X [ 313ULL ] ; } else { t3100 = X [ 313ULL ] ; } intrm_sf_mf_821 =
t3100 * 0.05 / ( t4363 == 0.0 ? 1.0E-16 : t4363 ) ; intrm_sf_mf_826 =
intrm_sf_mf_821 >= 1.0 ? intrm_sf_mf_821 : 1.0 ; t4221 = pmf_log10 ( 6.9 / (
intrm_sf_mf_826 == 0.0 ? 1.0E-16 : intrm_sf_mf_826 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( intrm_sf_mf_826 == 0.0 ? 1.0E-16 : intrm_sf_mf_826 )
+ 2.8767404433520813E-5 ) * 3.24 ; intrm_sf_mf_863 = X [ 313ULL ] * t3066 * -
35.2 / ( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; t3100 = X [ 313ULL ] * t3100 * (
1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) * - 0.55 / ( t4367 == 0.0 ?
1.0E-16 : t4367 ) ; intrm_sf_mf_826 = ( intrm_sf_mf_821 - 2000.0 ) / 2000.0 ;
t3631 = intrm_sf_mf_826 * intrm_sf_mf_826 * 3.0 - intrm_sf_mf_826 *
intrm_sf_mf_826 * intrm_sf_mf_826 * 2.0 ; if ( intrm_sf_mf_821 <= 2000.0 ) {
intrm_sf_mf_826 = intrm_sf_mf_863 * 9.9999999999999991E-11 ; } else if (
intrm_sf_mf_821 >= 4000.0 ) { intrm_sf_mf_826 = t3100 *
9.9999999999999991E-11 ; } else { intrm_sf_mf_826 = ( ( 1.0 - t3631 ) *
intrm_sf_mf_863 + t3100 * t3631 ) * 9.9999999999999991E-11 ; } t2049 [ 0ULL ]
= X [ 347ULL ] ; tlu2_linear_linear_prelookup ( & acb_efOut . mField0 [ 0ULL
] , & acb_efOut . mField1 [ 0ULL ] , & acb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t55 = acb_efOut ; tlu2_1d_linear_linear_value ( &
bcb_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = bcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
ccb_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = ccb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
dcb_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = dcb_efOut [ 0 ] ; t3100 = ( ( ( 1.0 -
intrm_sf_mf_866 ) - t3118 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_866 ) +
t2587_idx_0 * t3118 ; t2049 [ 0ULL ] = X [ 348ULL ] ;
tlu2_linear_linear_prelookup ( & ecb_efOut . mField0 [ 0ULL ] , & ecb_efOut .
mField1 [ 0ULL ] , & ecb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t3 = ecb_efOut ; tlu2_1d_linear_linear_value ( & fcb_efOut [ 0ULL ] , &
t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
fcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & gcb_efOut [ 0ULL ] , & t3 .
mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
gcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & hcb_efOut [ 0ULL ] , & t3 .
mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
hcb_efOut [ 0 ] ; intrm_sf_mf_821 = ( ( ( 1.0 - intrm_sf_mf_866 ) - t3118 ) *
t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_866 ) + t2587_idx_0 * t3118 ; t2049 [
0ULL ] = X [ 343ULL ] ; tlu2_linear_linear_prelookup ( & icb_efOut . mField0
[ 0ULL ] , & icb_efOut . mField1 [ 0ULL ] , & icb_efOut . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [
0ULL ] , & t225 [ 0ULL ] ) ; t187 = icb_efOut ; tlu2_1d_linear_linear_value (
& jcb_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = jcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
kcb_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = kcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
lcb_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = lcb_efOut [ 0 ] ; intrm_sf_mf_863 = ( ( ( 1.0 -
intrm_sf_mf_866 ) - t3118 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_866 ) +
t2587_idx_0 * t3118 ; t4251 = t3125 - ( - t3125 ) ; intrm_sf_mf_866 = ( (
t3047 - 1.01325 ) - ( - t3125 ) ) / ( t4251 == 0.0 ? 1.0E-16 : t4251 ) ;
t3118 = intrm_sf_mf_866 * intrm_sf_mf_866 * 3.0 - intrm_sf_mf_866 *
intrm_sf_mf_866 * intrm_sf_mf_866 * 2.0 ; if ( t3047 - 1.01325 <= - t3125 ) {
intrm_sf_mf_866 = 1.01325 ; } else if ( t3047 - 1.01325 >= t3125 ) {
intrm_sf_mf_866 = t3047 ; } else { intrm_sf_mf_866 = ( 1.0 - t3118 ) *
1.01325 + t3047 * t3118 ; } t2049 [ 0ULL ] = X [ 369ULL ] ;
tlu2_linear_linear_prelookup ( & mcb_efOut . mField0 [ 0ULL ] , & mcb_efOut .
mField1 [ 0ULL ] , & mcb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t3 = mcb_efOut ; tlu2_1d_linear_linear_value ( & ncb_efOut [ 0ULL ] , &
t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
ncb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & ocb_efOut [ 0ULL ] , & t3 .
mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2586_idx_0 =
ocb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & pcb_efOut [ 0ULL ] , & t3 .
mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2587_idx_0 =
pcb_efOut [ 0 ] ; t3118 = ( ( ( 1.0 - intrm_sf_mf_867 ) - t3124 ) *
t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_867 ) + t2587_idx_0 * t3124 ; t2049 [
0ULL ] = X [ 372ULL ] ; tlu2_linear_linear_prelookup ( & qcb_efOut . mField0
[ 0ULL ] , & qcb_efOut . mField1 [ 0ULL ] , & qcb_efOut . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [
0ULL ] , & t225 [ 0ULL ] ) ; t193 = qcb_efOut ; tlu2_1d_linear_linear_value (
& rcb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = rcb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
scb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2586_idx_0 = scb_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( &
tcb_efOut [ 0ULL ] , & t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2587_idx_0 = tcb_efOut [ 0 ] ; t3125 = ( ( ( 1.0 -
intrm_sf_mf_867 ) - t3124 ) * t2585_idx_0 + t2586_idx_0 * intrm_sf_mf_867 ) +
t2587_idx_0 * t3124 ; t3631 = X [ 368ULL ] >= 0.0 ? X [ 368ULL ] : - X [
368ULL ] ; t4396 = t3631 * 0.01 / ( t3365 == 0.0 ? 1.0E-16 : t3365 ) ; t3633
= t4396 >= 1.0 ? t4396 : 1.0 ; t4221 = pmf_log10 ( 6.9 / ( t3633 == 0.0 ?
1.0E-16 : t3633 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3633 ==
0.0 ? 1.0E-16 : t3633 ) + 0.00017169489553429715 ) * 3.24 ; t4237 = X [
368ULL ] * t3133 * 2.9973120849090416 / ( t3369 == 0.0 ? 1.0E-16 : t3369 ) ;
t3631 = X [ 368ULL ] * t3631 * ( 1.0 / ( t4221 == 0.0 ? 1.0E-16 : t4221 ) ) *
0.046833001326703774 / ( t3372 == 0.0 ? 1.0E-16 : t3372 ) ; t3633 = ( t4396 -
2000.0 ) / 2000.0 ; t4240 = t3633 * t3633 * 3.0 - t3633 * t3633 * t3633 * 2.0
; if ( t4396 <= 2000.0 ) { t3633 = t4237 * 9.9999999999999991E-11 ; } else if
( t4396 >= 4000.0 ) { t3633 = t3631 * 9.9999999999999991E-11 ; } else { t3633
= ( ( 1.0 - t4240 ) * t4237 + t3631 * t4240 ) * 9.9999999999999991E-11 ; } if
( M [ 0ULL ] != 0 ) { t2571 [ 0ULL ] = 0ULL ; for ( t2618 = 0ULL ; t2618 <
42ULL ; t2618 ++ ) { t2619 = t2618 / 42ULL ; t2620 = ( t2618 - t2618 % 42ULL
) + t2571 [ t2619 > 0ULL ? 0ULL : t2619 ] ; if ( ( ( _NeDynamicSystem * ) (
LC ) ) -> mField0 [ t2618 ] * 1.0E-5 < ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField0 [ t2620 > 41ULL ? 41ULL : t2620 ] * 1.0E-5 ) { t2571 [ t2619 > 0ULL ?
0ULL : t2619 ] = t2618 % 42ULL ; } } t2618 = t2571 [ 0ULL ] ; t3631 = ( (
_NeDynamicSystem * ) ( LC ) ) -> mField0 [ t2618 > 41ULL ? 41ULL : t2618 ] *
1.0E-5 ; } else { t3631 = X [ 80ULL ] ; } if ( M [ 1ULL ] != 0 ) { t2572 [
0ULL ] = 0ULL ; for ( t2618 = 0ULL ; t2618 < 7ULL ; t2618 ++ ) { t2619 =
t2618 / 7ULL ; t2620 = ( t2618 - t2618 % 7ULL ) + t2572 [ t2619 > 0ULL ? 0ULL
: t2619 ] ; if ( nonscalar1 [ t2618 ] * 1.0E-5 < nonscalar1 [ t2620 > 6ULL ?
6ULL : t2620 ] * 1.0E-5 ) { t2572 [ t2619 > 0ULL ? 0ULL : t2619 ] = t2618 %
7ULL ; } } t2618 = t2572 [ 0ULL ] ; t5708 = nonscalar1 [ t2618 > 6ULL ? 6ULL
: t2618 ] * 1.0E-5 ; } else { t5708 = X [ 85ULL ] * X [ 87ULL ] ; } t4396 =
pmf_sqrt ( zc_int36 * zc_int36 * 9.999999999999999E-14 + ( ( real_T ) ( M [
32ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 199ULL ] * t2812 * t2810 * 1.0E-9 ) ;
zc_int36 = - pmf_sqrt ( ( ( real_T ) ( M [ 306ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4247 / ( t2953 == 0.0 ? 1.0E-16 : t2953 ) / ( X [ 265ULL ] == 0.0 ? 1.0E-16
: X [ 265ULL ] ) ) ) * 0.32 ; t2812 = piece81 * zc_int36 * 2.9973120849090416
/ ( t3064 == 0.0 ? 1.0E-16 : t3064 ) ; if ( zc_int132 >= 0.0 ) { t4237 =
zc_int36 * 100000.0 ; } else { t4237 = - zc_int36 * 100000.0 ; } zc_int132 =
t4237 * 0.01 / ( t3060 == 0.0 ? 1.0E-16 : t3060 ) ; t4240 = t2989 >= 1.0 ?
zc_int132 : 1.0 ; U_idx_1 = pmf_log10 ( 6.9 / ( t4240 == 0.0 ? 1.0E-16 :
t4240 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t4240 == 0.0 ?
1.0E-16 : t4240 ) + 0.00017169489553429715 ) * 3.24 ; zc_int36 = zc_int36 *
t4237 * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) *
0.046833001326703774 / ( t3067 == 0.0 ? 1.0E-16 : t3067 ) ; zc_int132 = (
zc_int132 - 2000.0 ) / 2000.0 ; t4237 = zc_int132 * zc_int132 * 3.0 -
zc_int132 * zc_int132 * zc_int132 * 2.0 ; if ( t2989 <= 2000.0 ) { zc_int132
= t2812 * 1.0E-5 ; } else if ( t2989 >= 4000.0 ) { zc_int132 = zc_int36 *
1.0E-5 ; } else { zc_int132 = ( ( 1.0 - t4237 ) * t2812 + zc_int36 * t4237 )
* 1.0E-5 ; } zc_int36 = pmf_sqrt ( zc_int113 * zc_int113 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 39ULL ] != 0 ) * 2.0 - 1.0 ) * X [
203ULL ] * t2828 * t2810 * 1.0E-9 ) ; t2812 = pmf_sqrt ( t2980 * t2980 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 303ULL ] != 0 ) * 2.0 - 1.0 ) * X
[ 265ULL ] * t213 * t2953 * 1.0E-9 ) ; t4237 = X [ 198ULL ] * t2812 ; t2812 =
t4237 / 0.32 * 0.00031622776601683789 + zc_int132 ; U_idx_1 = - t2812 - t2812
* - 0.95 ; zc_int113 = ( - t2987 - t2812 * - 0.95 ) / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ; t2828 = zc_int113 * zc_int113 * 3.0 - zc_int113 *
zc_int113 * zc_int113 * 2.0 ; if ( - t2987 <= zc_int147 * - 0.95 ) {
zc_int113 = t2987 ; } else if ( - t2987 >= - zc_int147 ) { zc_int113 = t2812
; } else { zc_int113 = ( 1.0 - t2828 ) * t2987 + t2812 * t2828 ; } if ( M [
310ULL ] != 0 ) { t2812 = 216.59999999999997 ; } else { t2812 = M [ 311ULL ]
!= 0 ? 623.15 : U_idx_6 ; } t2049 [ 0ULL ] = U_idx_5 >= 0.0 ? t2812 : X [
34ULL ] ; tlu2_linear_linear_prelookup ( & ucb_efOut . mField0 [ 0ULL ] , &
ucb_efOut . mField1 [ 0ULL ] , & ucb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t45 = ucb_efOut ; tlu2_1d_linear_linear_value ( &
vcb_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = vcb_efOut [ 0 ] ; t2812 = t2585_idx_0 ; t4240 = X [
278ULL ] * t3030 ; t4247 = X [ 240ULL ] * t2920 ; t2980 = pmf_sqrt ( t3004 *
t3004 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 312ULL ] != 0 ) * 2.0 -
1.0 ) * X [ 289ULL ] * zc_int182 * t3003 * 1.0E-9 ) ; t213 = - pmf_sqrt ( ( (
real_T ) ( M [ 50ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4284 / ( t2810 == 0.0 ?
1.0E-16 : t2810 ) / ( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) *
7.8539816339744827E-5 ; zc_int147 = pmf_sqrt ( zc_int186 * zc_int186 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 314ULL ] != 0 ) * 2.0 - 1.0 ) * X
[ 291ULL ] * t220 * t3003 * 1.0E-9 ) ; zc_int132 = - pmf_sqrt ( ( ( real_T )
( M [ 315ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4289 / ( t3003 == 0.0 ? 1.0E-16 :
t3003 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16 : X [ 289ULL ] ) ) ) *
0.0019634954084936209 ; t2989 = t3009 * zc_int132 * 11.2 / ( t4440 == 0.0 ?
1.0E-16 : t4440 ) ; if ( zc_int192 >= 0.0 ) { t3004 = zc_int132 * 100000.0 ;
} else { t3004 = - zc_int132 * 100000.0 ; } zc_int182 = t3004 * 0.05 / (
t4426 == 0.0 ? 1.0E-16 : t4426 ) ; zc_int192 = t3012 >= 1.0 ? zc_int182 : 1.0
; t2920 = pmf_log10 ( 6.9 / ( zc_int192 == 0.0 ? 1.0E-16 : zc_int192 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( zc_int192 == 0.0 ? 1.0E-16 :
zc_int192 ) + 2.8767404433520813E-5 ) * 3.24 ; zc_int132 = zc_int132 * t3004
* ( 1.0 / ( t2920 == 0.0 ? 1.0E-16 : t2920 ) ) * 0.175 / ( t4298 == 0.0 ?
1.0E-16 : t4298 ) ; t3004 = ( zc_int182 - 2000.0 ) / 2000.0 ; zc_int182 =
t3004 * t3004 * 3.0 - t3004 * t3004 * t3004 * 2.0 ; t3004 = t2818 * t213 *
35.2 / ( t4487 == 0.0 ? 1.0E-16 : t4487 ) ; if ( t3012 <= 2000.0 ) {
zc_int192 = t2989 * 1.0E-5 ; } else if ( t3012 >= 4000.0 ) { zc_int192 =
zc_int132 * 1.0E-5 ; } else { zc_int192 = ( ( 1.0 - zc_int182 ) * t2989 +
zc_int132 * zc_int182 ) * 1.0E-5 ; } t2920 = X [ 288ULL ] * t2980 ; t2980 =
t2920 / 0.0019634954084936209 * 0.00031622776601683789 + zc_int192 ; U_idx_3
= - t2980 - t2980 * - 0.95 ; zc_int132 = ( - t3011 - t2980 * - 0.95 ) / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; t2989 = zc_int132 * zc_int132 * 3.0 -
zc_int132 * zc_int132 * zc_int132 * 2.0 ; if ( - t3011 <= zc_int181 * - 0.95
) { zc_int132 = t3011 ; } else if ( - t3011 >= - zc_int181 ) { zc_int132 =
t2980 ; } else { zc_int132 = ( 1.0 - t2989 ) * t3011 + t2980 * t2989 ; }
t2980 = - pmf_sqrt ( ( ( real_T ) ( M [ 316ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4303 / ( t3003 == 0.0 ? 1.0E-16 : t3003 ) / ( X [ 291ULL ] == 0.0 ? 1.0E-16
: X [ 291ULL ] ) ) ) * 0.0019634954084936209 ; t2989 = t3009 * t2980 * 11.2 /
( t4440 == 0.0 ? 1.0E-16 : t4440 ) ; if ( t2671 >= 0.0 ) { zc_int182 = t2980
* 100000.0 ; } else { zc_int182 = - t2980 * 100000.0 ; } zc_int181 =
zc_int182 * 0.05 / ( t4426 == 0.0 ? 1.0E-16 : t4426 ) ; t3009 = zc_int324 >=
1.0 ? zc_int181 : 1.0 ; if ( t2820 >= 0.0 ) { zc_int192 = t213 * 100000.0 ; }
else { zc_int192 = - t213 * 100000.0 ; } t4284 = pmf_log10 ( 6.9 / ( t3009 ==
0.0 ? 1.0E-16 : t3009 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t3009
== 0.0 ? 1.0E-16 : t3009 ) + 2.8767404433520813E-5 ) * 3.24 ; t2820 = t2980 *
zc_int182 * ( 1.0 / ( t4284 == 0.0 ? 1.0E-16 : t4284 ) ) * 0.175 / ( t4298 ==
0.0 ? 1.0E-16 : t4298 ) ; t2980 = ( zc_int181 - 2000.0 ) / 2000.0 ; zc_int182
= t2980 * t2980 * 3.0 - t2980 * t2980 * t2980 * 2.0 ; if ( zc_int324 <=
2000.0 ) { t2980 = t2989 * 1.0E-5 ; } else if ( zc_int324 >= 4000.0 ) { t2980
= t2820 * 1.0E-5 ; } else { t2980 = ( ( 1.0 - zc_int182 ) * t2989 + t2820 *
zc_int182 ) * 1.0E-5 ; } t4284 = - ( X [ 244ULL ] * zc_int147 ) ; t2820 =
t4284 / 0.0019634954084936209 * 0.00031622776601683789 + t2980 ; t4289 = -
t2820 - t2820 * - 0.95 ; t2980 = ( - t222 - t2820 * - 0.95 ) / ( t4289 == 0.0
? 1.0E-16 : t4289 ) ; zc_int147 = t2980 * t2980 * 3.0 - t2980 * t2980 * t2980
* 2.0 ; if ( - t222 <= zc_int209 * - 0.95 ) { t2980 = t222 ; } else if ( -
t222 >= - zc_int209 ) { t2980 = t2820 ; } else { t2980 = ( 1.0 - zc_int147 )
* t222 + t2820 * zc_int147 ; } U_idx_3 = X [ 307ULL ] * zc_int220 ; t2820 = (
( real_T ) ( M [ 320ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_3 / 1.01325 ) * (
U_idx_3 / 1.01325 ) * ( X [ 313ULL ] / 0.0019634954084936209 ) * ( X [ 313ULL
] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t4473 ; zc_int220
= zc_int192 * 0.01 / ( t4494 == 0.0 ? 1.0E-16 : t4494 ) ; t4426 = X [ 302ULL
] * t3095 ; zc_int147 = ( ( real_T ) ( M [ 322ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4426 / ( X [ 303ULL ] == 0.0 ? 1.0E-16 : X [ 303ULL ] ) ) * ( t4426 / ( X [
303ULL ] == 0.0 ? 1.0E-16 : X [ 303ULL ] ) ) * ( X [ 325ULL ] /
0.0019634954084936209 ) * ( X [ 325ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3176 ; U_idx_1 = X [ 321ULL ] * t3102 ; t2989 = ( (
real_T ) ( M [ 323ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_1 / ( t3047 == 0.0 ?
1.0E-16 : t3047 ) ) * ( U_idx_1 / ( t3047 == 0.0 ? 1.0E-16 : t3047 ) ) * ( -
X [ 313ULL ] / 0.0019634954084936209 ) * ( - X [ 313ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t2743 ; zc_int182 =
pmf_sqrt ( t3055 * t3055 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 325ULL
] != 0 ) * 2.0 - 1.0 ) * X [ 326ULL ] * zc_int305 * t3054 * 1.0E-9 ) ;
zc_int181 = pmf_sqrt ( t3077 * t3077 * 9.999999999999999E-14 + ( ( real_T ) (
M [ 326ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 330ULL ] * t3079 * t3054 * 1.0E-9 ) ;
t3009 = - pmf_sqrt ( ( ( real_T ) ( M [ 327ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4332 / ( t3054 == 0.0 ? 1.0E-16 : t3054 ) / ( X [ 326ULL ] == 0.0 ? 1.0E-16
: X [ 326ULL ] ) ) ) * 0.0019634954084936209 ; t3012 = t3066 * t3009 * 35.2 /
( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; if ( t3068 >= 0.0 ) { zc_int186 = t3009
* 100000.0 ; } else { zc_int186 = - t3009 * 100000.0 ; } t220 = zc_int186 *
0.05 / ( t4363 == 0.0 ? 1.0E-16 : t4363 ) ; zc_int209 = t3074 >= 1.0 ? t220 :
1.0 ; t4298 = pmf_log10 ( 6.9 / ( zc_int209 == 0.0 ? 1.0E-16 : zc_int209 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( zc_int209 == 0.0 ? 1.0E-16 :
zc_int209 ) + 2.8767404433520813E-5 ) * 3.24 ; t2671 = t2823 >= 1.0 ?
zc_int220 : 1.0 ; t3009 = t3009 * zc_int186 * ( 1.0 / ( t4298 == 0.0 ?
1.0E-16 : t4298 ) ) * 0.55 / ( t4367 == 0.0 ? 1.0E-16 : t4367 ) ; zc_int186 =
( t220 - 2000.0 ) / 2000.0 ; t220 = zc_int186 * zc_int186 * 3.0 - zc_int186 *
zc_int186 * zc_int186 * 2.0 ; if ( t3074 <= 2000.0 ) { zc_int186 = t3012 *
1.0E-5 ; } else if ( t3074 >= 4000.0 ) { zc_int186 = t3009 * 1.0E-5 ; } else
{ zc_int186 = ( ( 1.0 - t220 ) * t3012 + t3009 * t220 ) * 1.0E-5 ; } t4298 =
X [ 325ULL ] * zc_int182 ; zc_int182 = t4298 / 0.0019634954084936209 *
0.00031622776601683789 + zc_int186 ; zc_int350 = - zc_int182 - zc_int182 * -
0.95 ; t3009 = ( - t3069 - zc_int182 * - 0.95 ) / ( zc_int350 == 0.0 ?
1.0E-16 : zc_int350 ) ; t3012 = t3009 * t3009 * 3.0 - t3009 * t3009 * t3009 *
2.0 ; if ( - t3069 <= t3059 * - 0.95 ) { t3009 = t3069 ; } else if ( - t3069
>= - t3059 ) { t3009 = zc_int182 ; } else { t3009 = ( 1.0 - t3012 ) * t3069 +
zc_int182 * t3012 ; } zc_int182 = - pmf_sqrt ( ( ( real_T ) ( M [ 328ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t4394 / ( t3054 == 0.0 ? 1.0E-16 : t3054 ) / ( X [
330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) * 0.0019634954084936209 ;
t3012 = t3066 * zc_int182 * 35.2 / ( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; t4332
= pmf_log10 ( 6.9 / ( t2671 == 0.0 ? 1.0E-16 : t2671 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2671 == 0.0 ? 1.0E-16 : t2671
) + 0.00017169489553429715 ) * 3.24 ; zc_int186 = 1.0 / ( t4332 == 0.0 ?
1.0E-16 : t4332 ) ; if ( t3083 >= 0.0 ) { t220 = zc_int182 * 100000.0 ; }
else { t220 = - zc_int182 * 100000.0 ; } zc_int209 = t220 * 0.05 / ( t4363 ==
0.0 ? 1.0E-16 : t4363 ) ; t2671 = t3086 >= 1.0 ? zc_int209 : 1.0 ; t4332 =
pmf_log10 ( 6.9 / ( t2671 == 0.0 ? 1.0E-16 : t2671 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t2671 == 0.0 ? 1.0E-16 : t2671 ) +
2.8767404433520813E-5 ) * 3.24 ; zc_int182 = zc_int182 * t220 * ( 1.0 / (
t4332 == 0.0 ? 1.0E-16 : t4332 ) ) * 0.55 / ( t4367 == 0.0 ? 1.0E-16 : t4367
) ; t220 = ( zc_int209 - 2000.0 ) / 2000.0 ; zc_int209 = t220 * t220 * 3.0 -
t220 * t220 * t220 * 2.0 ; if ( t3086 <= 2000.0 ) { t220 = t3012 * 1.0E-5 ; }
else if ( t3086 >= 4000.0 ) { t220 = zc_int182 * 1.0E-5 ; } else { t220 = ( (
1.0 - zc_int209 ) * t3012 + zc_int182 * zc_int209 ) * 1.0E-5 ; } t4332 = - (
X [ 313ULL ] * zc_int181 ) ; zc_int182 = t4332 / 0.0019634954084936209 *
0.00031622776601683789 + t220 ; t4451 = - zc_int182 - zc_int182 * - 0.95 ;
zc_int181 = ( - t3084 - zc_int182 * - 0.95 ) / ( t4451 == 0.0 ? 1.0E-16 :
t4451 ) ; t213 = t213 * zc_int192 * zc_int186 * 0.55 / ( t2850 == 0.0 ?
1.0E-16 : t2850 ) ; zc_int192 = zc_int181 * zc_int181 * 3.0 - zc_int181 *
zc_int181 * zc_int181 * 2.0 ; if ( - t3084 <= zc_int339 * - 0.95 ) {
zc_int181 = t3084 ; } else if ( - t3084 >= - zc_int339 ) { zc_int181 =
zc_int182 ; } else { zc_int181 = ( 1.0 - zc_int192 ) * t3084 + zc_int182 *
zc_int192 ; } zc_int182 = ( ( real_T ) ( M [ 323ULL ] != 0 ) * 2.0 - 1.0 ) *
( U_idx_1 / ( t3047 == 0.0 ? 1.0E-16 : t3047 ) ) * ( U_idx_1 / ( t3047 == 0.0
? 1.0E-16 : t3047 ) ) * ( X [ 313ULL ] / 0.0019634954084936209 ) * ( X [
313ULL ] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t2743 ;
t2743 = ( ( real_T ) ( M [ 320ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_3 /
1.01325 ) * ( U_idx_3 / 1.01325 ) * ( - X [ 313ULL ] / 0.0019634954084936209
) * ( - X [ 313ULL ] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14
+ t4473 ; zc_int192 = ( t3047 - 1.01325 ) * pmf_sqrt ( ( ( real_T ) ( M [
332ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3354 / ( zc_int307 == 0.0 ? 1.0E-16 :
zc_int307 ) ) ) * t3087 * 0.64 ; t3012 = pmf_sqrt ( ( ( real_T ) ( M [ 334ULL
] != 0 ) * 2.0 - 1.0 ) * ( t4405 / ( t3119 == 0.0 ? 1.0E-16 : t3119 ) / ( X [
343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ) * t3087 * 0.64 ; U_idx_3 =
t3012 - t3012 * 0.95 ; zc_int186 = ( zc_int192 - t3012 * 0.95 ) / ( U_idx_3
== 0.0 ? 1.0E-16 : U_idx_3 ) ; t220 = zc_int186 * zc_int186 * 3.0 - zc_int186
* zc_int186 * zc_int186 * 2.0 ; if ( t3120 <= t3121 * 0.95 ) { zc_int186 =
zc_int192 * 100000.0 ; } else if ( t3120 >= t3121 ) { zc_int186 = t3012 *
100000.0 ; } else { zc_int186 = ( ( 1.0 - t220 ) * zc_int192 + t3012 * t220 )
* 100000.0 ; } t220 = ( - zc_int192 - t3012 * 0.95 ) / ( U_idx_3 == 0.0 ?
1.0E-16 : U_idx_3 ) ; zc_int220 = ( zc_int220 - 2000.0 ) / 2000.0 ; zc_int209
= t220 * t220 * 3.0 - t220 * t220 * t220 * 2.0 ; if ( - t3120 <= t3121 * 0.95
) { t220 = zc_int192 * 100000.0 ; } else if ( - t3120 >= t3121 ) { t220 = -
t3012 * 100000.0 ; } else { t220 = ( ( 1.0 - zc_int209 ) * zc_int192 + -
t3012 * zc_int209 ) * 100000.0 ; } t4473 = X [ 364ULL ] * zc_int363 ;
zc_int192 = ( ( real_T ) ( M [ 338ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4473 / ( X
[ 365ULL ] == 0.0 ? 1.0E-16 : X [ 365ULL ] ) ) * ( t4473 / ( X [ 365ULL ] ==
0.0 ? 1.0E-16 : X [ 365ULL ] ) ) * ( X [ 368ULL ] / 0.32 ) * ( X [ 368ULL ] /
0.32 ) / 2.0 * 9.999999999999999E-14 + t3272 ; t4363 = X [ 350ULL ] *
zc_int366 ; t3012 = ( ( real_T ) ( M [ 339ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4363 / ( X [ 351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ) * ( t4363 / ( X [
351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ) * ( X [ 371ULL ] / 0.32 ) * ( X
[ 371ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_1104 ;
zc_int209 = pmf_sqrt ( t3127 * t3127 * 9.999999999999999E-14 + ( ( real_T ) (
M [ 340ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 369ULL ] * zc_int357 *
intrm_sf_mf_869 * 1.0E-9 ) ; t2671 = pmf_sqrt ( t3139 * t3139 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 341ULL ] != 0 ) * 2.0 - 1.0 ) * X
[ 372ULL ] * t3140 * intrm_sf_mf_869 * 1.0E-9 ) ; zc_int324 = - pmf_sqrt ( (
( real_T ) ( M [ 342ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3361 / ( intrm_sf_mf_869
== 0.0 ? 1.0E-16 : intrm_sf_mf_869 ) / ( X [ 369ULL ] == 0.0 ? 1.0E-16 : X [
369ULL ] ) ) ) * 0.32 ; t3030 = t3133 * zc_int324 * 2.9973120849090416 / (
t3369 == 0.0 ? 1.0E-16 : t3369 ) ; if ( t3134 >= 0.0 ) { t3055 = zc_int324 *
100000.0 ; } else { t3055 = - zc_int324 * 100000.0 ; } zc_int305 = t3055 *
0.01 / ( t3365 == 0.0 ? 1.0E-16 : t3365 ) ; if ( M [ 105ULL ] != 0 ) { t3059
= 4.03416E-7 ; } else { t3059 = X [ 84ULL ] * X [ 86ULL ] ; } t3066 =
zc_int220 * zc_int220 * 3.0 - zc_int220 * zc_int220 * zc_int220 * 2.0 ;
zc_int220 = zc_int348 >= 1.0 ? zc_int305 : 1.0 ; t4289 = pmf_log10 ( 6.9 / (
zc_int220 == 0.0 ? 1.0E-16 : zc_int220 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( zc_int220 == 0.0 ? 1.0E-16 : zc_int220 ) +
0.00017169489553429715 ) * 3.24 ; zc_int220 = zc_int324 * t3055 * ( 1.0 / (
t4289 == 0.0 ? 1.0E-16 : t4289 ) ) * 0.046833001326703774 / ( t3372 == 0.0 ?
1.0E-16 : t3372 ) ; zc_int324 = ( zc_int305 - 2000.0 ) / 2000.0 ; t3055 =
zc_int324 * zc_int324 * 3.0 - zc_int324 * zc_int324 * zc_int324 * 2.0 ; if (
zc_int348 <= 2000.0 ) { zc_int324 = t3030 * 1.0E-5 ; } else if ( zc_int348 >=
4000.0 ) { zc_int324 = zc_int220 * 1.0E-5 ; } else { zc_int324 = ( ( 1.0 -
t3055 ) * t3030 + zc_int220 * t3055 ) * 1.0E-5 ; } t4289 = X [ 368ULL ] *
zc_int209 ; zc_int220 = t4289 / 0.32 * 0.00031622776601683789 + zc_int324 ;
U_idx_1 = - zc_int220 - zc_int220 * - 0.95 ; zc_int209 = ( - t3135 -
zc_int220 * - 0.95 ) / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; zc_int324 =
zc_int209 * zc_int209 * 3.0 - zc_int209 * zc_int209 * zc_int209 * 2.0 ; if (
- t3135 <= zc_int349 * - 0.95 ) { zc_int209 = t3135 ; } else if ( - t3135 >=
- zc_int349 ) { zc_int209 = zc_int220 ; } else { zc_int209 = ( 1.0 -
zc_int324 ) * t3135 + zc_int220 * zc_int324 ; } if ( t2823 <= 2000.0 ) {
zc_int220 = t3004 * 1.0E-5 ; } else if ( t2823 >= 4000.0 ) { zc_int220 = t213
* 1.0E-5 ; } else { zc_int220 = ( ( 1.0 - t3066 ) * t3004 + t213 * t3066 ) *
1.0E-5 ; } t2823 = - pmf_sqrt ( ( ( real_T ) ( M [ 343ULL ] != 0 ) * 2.0 -
1.0 ) * ( t3381 / ( intrm_sf_mf_869 == 0.0 ? 1.0E-16 : intrm_sf_mf_869 ) / (
X [ 372ULL ] == 0.0 ? 1.0E-16 : X [ 372ULL ] ) ) ) * 0.32 ; t213 = t3133 *
t2823 * 2.9973120849090416 / ( t3369 == 0.0 ? 1.0E-16 : t3369 ) ; if ( t3145
>= 0.0 ) { t3004 = t2823 * 100000.0 ; } else { t3004 = - t2823 * 100000.0 ; }
zc_int324 = t3004 * 0.01 / ( t3365 == 0.0 ? 1.0E-16 : t3365 ) ; t3030 = t3149
>= 1.0 ? zc_int324 : 1.0 ; t4394 = pmf_log10 ( 6.9 / ( t3030 == 0.0 ? 1.0E-16
: t3030 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3030 == 0.0 ?
1.0E-16 : t3030 ) + 0.00017169489553429715 ) * 3.24 ; t2823 = t2823 * t3004 *
( 1.0 / ( t4394 == 0.0 ? 1.0E-16 : t4394 ) ) * 0.046833001326703774 / ( t3372
== 0.0 ? 1.0E-16 : t3372 ) ; t3004 = ( zc_int324 - 2000.0 ) / 2000.0 ;
zc_int324 = t3004 * t3004 * 3.0 - t3004 * t3004 * t3004 * 2.0 ; if ( t3149 <=
2000.0 ) { t3004 = t213 * 1.0E-5 ; } else if ( t3149 >= 4000.0 ) { t3004 =
t2823 * 1.0E-5 ; } else { t3004 = ( ( 1.0 - zc_int324 ) * t213 + t2823 *
zc_int324 ) * 1.0E-5 ; } t4394 = t2806 * t4396 ; t2823 = t4394 /
7.8539816339744827E-5 * 0.00031622776601683789 + zc_int220 ; t4396 = X [
371ULL ] * t2671 ; zc_int220 = t4396 / 0.32 * 0.00031622776601683789 + t3004
; t4405 = - zc_int220 - zc_int220 * - 0.95 ; t213 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 - zc_int220 * -
0.95 ) / ( t4405 == 0.0 ? 1.0E-16 : t4405 ) ; t3004 = t213 * t213 * 3.0 -
t213 * t213 * t213 * 2.0 ; if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 <=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 * - 0.95 ) {
t213 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 ; } else
if ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 >= -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 ) { t213 =
zc_int220 ; } else { t213 = ( 1.0 - t3004 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 + zc_int220 *
t3004 ; } zc_int220 = ( ( real_T ) ( M [ 339ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4363 / ( X [ 351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ) * ( t4363 / ( X [
351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ) * ( - X [ 371ULL ] / 0.32 ) * (
- X [ 371ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_1104 ;
t3004 = ( ( real_T ) ( M [ 322ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4426 / ( X [
303ULL ] == 0.0 ? 1.0E-16 : X [ 303ULL ] ) ) * ( t4426 / ( X [ 303ULL ] ==
0.0 ? 1.0E-16 : X [ 303ULL ] ) ) * ( - X [ 325ULL ] / 0.32 ) * ( - X [ 325ULL
] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t3176 ; t2671 = pmf_sqrt (
zc_int52 * zc_int52 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 348ULL ] !=
0 ) * 2.0 - 1.0 ) * X [ 387ULL ] * zc_int368 * t3197 * 1.0E-9 ) ; zc_int324 =
pmf_sqrt ( t3210 * t3210 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 349ULL
] != 0 ) * 2.0 - 1.0 ) * X [ 389ULL ] * t3211 * t3197 * 1.0E-9 ) ; t3030 = -
pmf_sqrt ( ( ( real_T ) ( M [ 350ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3455 / (
t3197 == 0.0 ? 1.0E-16 : t3197 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X [
387ULL ] ) ) ) * 0.32 ; t3055 = t3204 * t3030 * 2.9973120849090416 / ( t3463
== 0.0 ? 1.0E-16 : t3463 ) ; t4440 = - t2823 - t2823 * - 0.95 ; zc_int305 = (
- t2821 - t2823 * - 0.95 ) / ( t4440 == 0.0 ? 1.0E-16 : t4440 ) ; if ( t3205
>= 0.0 ) { t3066 = t3030 * 100000.0 ; } else { t3066 = - t3030 * 100000.0 ; }
t3068 = t3066 * 0.01 / ( t3459 == 0.0 ? 1.0E-16 : t3459 ) ; t3074 = zc_int6
>= 1.0 ? t3068 : 1.0 ; t4426 = pmf_log10 ( 6.9 / ( t3074 == 0.0 ? 1.0E-16 :
t3074 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3074 == 0.0 ?
1.0E-16 : t3074 ) + 0.00017169489553429715 ) * 3.24 ; t3030 = t3030 * t3066 *
( 1.0 / ( t4426 == 0.0 ? 1.0E-16 : t4426 ) ) * 0.046833001326703774 / ( t3466
== 0.0 ? 1.0E-16 : t3466 ) ; t3066 = ( t3068 - 2000.0 ) / 2000.0 ; t3068 =
t3066 * t3066 * 3.0 - t3066 * t3066 * t3066 * 2.0 ; if ( zc_int6 <= 2000.0 )
{ t3066 = t3055 * 1.0E-5 ; } else if ( zc_int6 >= 4000.0 ) { t3066 = t3030 *
1.0E-5 ; } else { t3066 = ( ( 1.0 - t3068 ) * t3055 + t3030 * t3068 ) *
1.0E-5 ; } t4426 = - ( X [ 371ULL ] * t2671 ) ; t2671 = t4426 / 0.32 *
0.00031622776601683789 + t3066 ; t4363 = - t2671 - t2671 * - 0.95 ; t3030 = (
- t3206 - t2671 * - 0.95 ) / ( t4363 == 0.0 ? 1.0E-16 : t4363 ) ; t3055 =
zc_int305 * zc_int305 * 3.0 - zc_int305 * zc_int305 * zc_int305 * 2.0 ;
zc_int305 = t3030 * t3030 * 3.0 - t3030 * t3030 * t3030 * 2.0 ; if ( - t3206
<= t3201 * - 0.95 ) { t3030 = t3206 ; } else if ( - t3206 >= - t3201 ) {
t3030 = t2671 ; } else { t3030 = ( 1.0 - zc_int305 ) * t3206 + t2671 *
zc_int305 ; } t2671 = - pmf_sqrt ( ( ( real_T ) ( M [ 351ULL ] != 0 ) * 2.0 -
1.0 ) * ( t3475 / ( t3197 == 0.0 ? 1.0E-16 : t3197 ) / ( X [ 389ULL ] == 0.0
? 1.0E-16 : X [ 389ULL ] ) ) ) * 0.32 ; zc_int305 = t3204 * t2671 *
2.9973120849090416 / ( t3463 == 0.0 ? 1.0E-16 : t3463 ) ; if ( piece237 >=
0.0 ) { t3066 = t2671 * 100000.0 ; } else { t3066 = - t2671 * 100000.0 ; }
t3068 = t3066 * 0.01 / ( t3459 == 0.0 ? 1.0E-16 : t3459 ) ; t3074 = piece354
>= 1.0 ? t3068 : 1.0 ; t4440 = pmf_log10 ( 6.9 / ( t3074 == 0.0 ? 1.0E-16 :
t3074 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3074 == 0.0 ?
1.0E-16 : t3074 ) + 0.00017169489553429715 ) * 3.24 ; t2671 = t2671 * t3066 *
( 1.0 / ( t4440 == 0.0 ? 1.0E-16 : t4440 ) ) * 0.046833001326703774 / ( t3466
== 0.0 ? 1.0E-16 : t3466 ) ; t3066 = ( t3068 - 2000.0 ) / 2000.0 ; if ( -
t2821 <= t2813 * - 0.95 ) { t3068 = t2821 ; } else if ( - t2821 >= - t2813 )
{ t3068 = t2823 ; } else { t3068 = ( 1.0 - t3055 ) * t2821 + t2823 * t3055 ;
} t2813 = t3066 * t3066 * 3.0 - t3066 * t3066 * t3066 * 2.0 ; if ( piece354
<= 2000.0 ) { t2823 = zc_int305 * 1.0E-5 ; } else if ( piece354 >= 4000.0 ) {
t2823 = t2671 * 1.0E-5 ; } else { t2823 = ( ( 1.0 - t2813 ) * zc_int305 +
t2671 * t2813 ) * 1.0E-5 ; } t4440 = - ( X [ 325ULL ] * zc_int324 ) ; t2813 =
t4440 / 0.32 * 0.00031622776601683789 + t2823 ; t4451 = - t2813 - t2813 * -
0.95 ; t2823 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 - t2813 * -
0.95 ) / ( t4451 == 0.0 ? 1.0E-16 : t4451 ) ; t2671 = t2823 * t2823 * 3.0 -
t2823 * t2823 * t2823 * 2.0 ; if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 <= t3212 * -
0.95 ) { t2823 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 ; } else if (
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 >= - t3212 )
{ t2823 = t2813 ; } else { t2823 = ( 1.0 - t2671 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 + t2813 *
t2671 ; } if ( M [ 355ULL ] != 0 ) { t2813 = 216.59999999999997 ; } else {
t2813 = M [ 356ULL ] != 0 ? 623.15 : U_idx_9 ; } t2049 [ 0ULL ] = U_idx_8 >=
0.0 ? t2813 : X [ 51ULL ] ; tlu2_linear_linear_prelookup ( & wcb_efOut .
mField0 [ 0ULL ] , & wcb_efOut . mField1 [ 0ULL ] , & wcb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t45 = wcb_efOut ;
tlu2_1d_linear_linear_value ( & xcb_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = xcb_efOut [ 0 ] ; t2813
= t2585_idx_0 ; t4363 = X [ 403ULL ] * t4447 ; zc_int324 = - pmf_sqrt ( ( (
real_T ) ( M [ 61ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4498 / ( t2810 == 0.0 ?
1.0E-16 : t2810 ) / ( X [ 203ULL ] == 0.0 ? 1.0E-16 : X [ 203ULL ] ) ) ) *
7.8539816339744827E-5 ; t3055 = ( ( real_T ) ( M [ 338ULL ] != 0 ) * 2.0 -
1.0 ) * ( t4473 / ( X [ 365ULL ] == 0.0 ? 1.0E-16 : X [ 365ULL ] ) ) * (
t4473 / ( X [ 365ULL ] == 0.0 ? 1.0E-16 : X [ 365ULL ] ) ) * ( - X [ 368ULL ]
/ 0.0019634954084936209 ) * ( - X [ 368ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 + t3272 ; zc_int305 = pmf_sqrt ( t3231 * t3231 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 357ULL ] != 0 ) * 2.0 - 1.0 ) * X
[ 414ULL ] * t3232 * t3229 * 1.0E-9 ) ; t3066 = pmf_sqrt ( piece422 *
piece422 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 358ULL ] != 0 ) * 2.0 -
1.0 ) * X [ 416ULL ] * t3252 * t3229 * 1.0E-9 ) ; t3074 = - pmf_sqrt ( ( (
real_T ) ( M [ 359ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3545 / ( t3229 == 0.0 ?
1.0E-16 : t3229 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [ 414ULL ] ) ) ) *
0.0019634954084936209 ; t3077 = t3240 * t3074 * 11.2 / ( t3553 == 0.0 ?
1.0E-16 : t3553 ) ; if ( t3242 >= 0.0 ) { t3079 = t3074 * 100000.0 ; } else {
t3079 = - t3074 * 100000.0 ; } zc_int339 = t3079 * 0.05 / ( t3549 == 0.0 ?
1.0E-16 : t3549 ) ; t3083 = t3248 >= 1.0 ? zc_int339 : 1.0 ; t4473 =
pmf_log10 ( 6.9 / ( t3083 == 0.0 ? 1.0E-16 : t3083 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t3083 == 0.0 ? 1.0E-16 : t3083 ) +
2.8767404433520813E-5 ) * 3.24 ; t3074 = t3074 * t3079 * ( 1.0 / ( t4473 ==
0.0 ? 1.0E-16 : t4473 ) ) * 0.175 / ( t3556 == 0.0 ? 1.0E-16 : t3556 ) ;
t2818 = t2818 * zc_int324 * 35.2 / ( t4487 == 0.0 ? 1.0E-16 : t4487 ) ; t3079
= ( zc_int339 - 2000.0 ) / 2000.0 ; zc_int339 = t3079 * t3079 * 3.0 - t3079 *
t3079 * t3079 * 2.0 ; if ( t3248 <= 2000.0 ) { t3079 = t3077 * 1.0E-5 ; }
else if ( t3248 >= 4000.0 ) { t3079 = t3074 * 1.0E-5 ; } else { t3079 = ( (
1.0 - zc_int339 ) * t3077 + t3074 * zc_int339 ) * 1.0E-5 ; } t4473 = X [
413ULL ] * zc_int305 ; zc_int305 = t4473 / 0.0019634954084936209 *
0.00031622776601683789 + t3079 ; t4498 = - zc_int305 - zc_int305 * - 0.95 ;
t3074 = ( - t3246 - zc_int305 * - 0.95 ) / ( t4498 == 0.0 ? 1.0E-16 : t4498 )
; t3077 = t3074 * t3074 * 3.0 - t3074 * t3074 * t3074 * 2.0 ; if ( - t3246 <=
t3233 * - 0.95 ) { t3074 = t3246 ; } else if ( - t3246 >= - t3233 ) { t3074 =
zc_int305 ; } else { t3074 = ( 1.0 - t3077 ) * t3246 + zc_int305 * t3077 ; }
zc_int305 = - pmf_sqrt ( ( ( real_T ) ( M [ 360ULL ] != 0 ) * 2.0 - 1.0 ) * (
t3565 / ( t3229 == 0.0 ? 1.0E-16 : t3229 ) / ( X [ 416ULL ] == 0.0 ? 1.0E-16
: X [ 416ULL ] ) ) ) * 0.0019634954084936209 ; t3077 = t3240 * zc_int305 *
11.2 / ( t3553 == 0.0 ? 1.0E-16 : t3553 ) ; if ( t3258 >= 0.0 ) { t3079 =
zc_int305 * 100000.0 ; } else { t3079 = - zc_int305 * 100000.0 ; } if ( t2634
>= 0.0 ) { zc_int339 = zc_int324 * 100000.0 ; } else { zc_int339 = -
zc_int324 * 100000.0 ; } t2634 = t3079 * 0.05 / ( t3549 == 0.0 ? 1.0E-16 :
t3549 ) ; t3083 = t3262 >= 1.0 ? t2634 : 1.0 ; t4487 = pmf_log10 ( 6.9 / (
t3083 == 0.0 ? 1.0E-16 : t3083 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9
/ ( t3083 == 0.0 ? 1.0E-16 : t3083 ) + 2.8767404433520813E-5 ) * 3.24 ;
zc_int305 = zc_int305 * t3079 * ( 1.0 / ( t4487 == 0.0 ? 1.0E-16 : t4487 ) )
* 0.175 / ( t3556 == 0.0 ? 1.0E-16 : t3556 ) ; t2634 = ( t2634 - 2000.0 ) /
2000.0 ; t3079 = t2634 * t2634 * 3.0 - t2634 * t2634 * t2634 * 2.0 ; if (
t3262 <= 2000.0 ) { t2634 = t3077 * 1.0E-5 ; } else if ( t3262 >= 4000.0 ) {
t2634 = zc_int305 * 1.0E-5 ; } else { t2634 = ( ( 1.0 - t3079 ) * t3077 +
zc_int305 * t3079 ) * 1.0E-5 ; } t4487 = - ( X [ 368ULL ] * t3066 ) ;
zc_int305 = t4487 / 0.0019634954084936209 * 0.00031622776601683789 + t2634 ;
U_idx_3 = - zc_int305 - zc_int305 * - 0.95 ; t2634 = ( - t3260 - zc_int305 *
- 0.95 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; t3066 = t2634 * t2634 *
3.0 - t2634 * t2634 * t2634 * 2.0 ; t2634 = zc_int339 * 0.01 / ( t4494 == 0.0
? 1.0E-16 : t4494 ) ; if ( - t3260 <= t3257 * - 0.95 ) { t3077 = t3260 ; }
else if ( - t3260 >= - t3257 ) { t3077 = zc_int305 ; } else { t3077 = ( 1.0 -
t3066 ) * t3260 + zc_int305 * t3066 ; } if ( M [ 6ULL ] != 0 ) { zc_int305 =
216.59999999999997 ; } else { zc_int305 = M [ 7ULL ] != 0 ? 623.15 : X [
32ULL ] ; } t2049 [ 0ULL ] = X [ 465ULL ] >= 0.0 ? zc_int305 : X [ 46ULL ] ;
tlu2_linear_linear_prelookup ( & ycb_efOut . mField0 [ 0ULL ] , & ycb_efOut .
mField1 [ 0ULL ] , & ycb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = ycb_efOut ; tlu2_1d_linear_linear_value ( & adb_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
adb_efOut [ 0 ] ; t3066 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 276ULL ] >= 0.0
? zc_int305 : X [ 28ULL ] ; tlu2_linear_linear_prelookup ( & bdb_efOut .
mField0 [ 0ULL ] , & bdb_efOut . mField1 [ 0ULL ] , & bdb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t166 = bdb_efOut ;
tlu2_1d_linear_linear_value ( & cdb_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = cdb_efOut [ 0 ] ;
t3079 = t2585_idx_0 ; t2049 [ 0ULL ] = X [ 401ULL ] >= 0.0 ? zc_int305 : X [
46ULL ] ; tlu2_linear_linear_prelookup ( & ddb_efOut . mField0 [ 0ULL ] , &
ddb_efOut . mField1 [ 0ULL ] , & ddb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL
] , & t225 [ 0ULL ] ) ; t45 = ddb_efOut ; tlu2_1d_linear_linear_value ( &
edb_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2585_idx_0 = edb_efOut [ 0 ] ; t3083 = t2585_idx_0 ; t4494 = ( (
real_T ) ( M [ 304ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 162ULL ] ; t3086 = X [
154ULL ] / 0.001 * ( X [ 154ULL ] / 0.001 ) / ( X [ 162ULL ] == 0.0 ? 1.0E-16
: X [ 162ULL ] ) / ( t4494 == 0.0 ? 1.0E-16 : t4494 ) / 2.0 * 0.001 + ( ( X [
148ULL ] - 293.15 ) + 420.0 ) ; zc_int350 = zc_int352 >= 1.0 ? t2634 : 1.0 ;
t2049 [ 0ULL ] = X [ 277ULL ] >= 0.0 ? zc_int305 : X [ 28ULL ] ;
tlu2_linear_linear_prelookup ( & fdb_efOut . mField0 [ 0ULL ] , & fdb_efOut .
mField1 [ 0ULL ] , & fdb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ]
) ; t166 = fdb_efOut ; tlu2_1d_linear_linear_value ( & gdb_efOut [ 0ULL ] , &
t166 . mField0 [ 0ULL ] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 =
gdb_efOut [ 0 ] ; t3095 = t2585_idx_0 ; t2049 [ 0ULL ] = t3393 >= 0.0 ?
zc_int305 : X [ 46ULL ] ; tlu2_linear_linear_prelookup ( & hdb_efOut .
mField0 [ 0ULL ] , & hdb_efOut . mField1 [ 0ULL ] , & hdb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t2049 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3 = hdb_efOut ;
tlu2_1d_linear_linear_value ( & idb_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ]
, & t3 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2585_idx_0 = idb_efOut [ 0 ] ;
zc_int305 = t2585_idx_0 ; t4494 = X [ 469ULL ] * t4503 ; t3102 = ( ( real_T )
( M [ 8ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4494 / ( X [ 64ULL ] == 0.0 ? 1.0E-16
: X [ 64ULL ] ) ) * ( t4494 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] )
) * ( X [ 478ULL ] / 7.8539816339744827E-5 ) * ( X [ 478ULL ] /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t4626 ; t4498 = X [
484ULL ] * t4510 ; zc_int307 = ( ( real_T ) ( M [ 10ULL ] != 0 ) * 2.0 - 1.0
) * ( t4498 / ( X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( t4498 /
( X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( - X [ 478ULL ] /
7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + zc_int365 ; U_idx_3 = X [ 466ULL ] * t4517 ; t3121 =
( ( real_T ) ( M [ 11ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_3 / ( X [ 38ULL ]
== 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( U_idx_3 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( X [ 492ULL ] / 7.8539816339744827E-5 ) * ( X [
492ULL ] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t3304 ;
t3127 = pmf_sqrt ( t4534 * t4534 * 9.999999999999999E-14 + ( ( real_T ) ( M [
12ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 488ULL ] * t4548 * t3418 * 1.0E-9 ) ;
t4534 = pmf_log10 ( 6.9 / ( zc_int350 == 0.0 ? 1.0E-16 : zc_int350 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( zc_int350 == 0.0 ? 1.0E-16 :
zc_int350 ) + 0.00017169489553429715 ) * 3.24 ; zc_int350 = 1.0 / ( t4534 ==
0.0 ? 1.0E-16 : t4534 ) ; zc_int357 = pmf_sqrt ( t4658 * t4658 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 14ULL ] != 0 ) * 2.0 - 1.0 ) * X [
493ULL ] * t4677 * t3418 * 1.0E-9 ) ; zc_int349 = - pmf_sqrt ( ( ( real_T ) (
M [ 15ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3734 / ( t3418 == 0.0 ? 1.0E-16 : t3418
) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) ) *
7.8539816339744827E-5 ; t3133 = t4641 * zc_int349 * 35.2 / ( t3742 == 0.0 ?
1.0E-16 : t3742 ) ; if ( t4803 >= 0.0 ) { t3134 = zc_int349 * 100000.0 ; }
else { t3134 = - zc_int349 * 100000.0 ; } zc_int348 = t3134 * 0.01 / ( t3738
== 0.0 ? 1.0E-16 : t3738 ) ; t3139 = t4813 >= 1.0 ? zc_int348 : 1.0 ; t4534 =
pmf_log10 ( 6.9 / ( t3139 == 0.0 ? 1.0E-16 : t3139 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t3139 == 0.0 ? 1.0E-16 : t3139 ) +
0.00017169489553429715 ) * 3.24 ; zc_int349 = zc_int349 * t3134 * ( 1.0 / (
t4534 == 0.0 ? 1.0E-16 : t4534 ) ) * 0.55 / ( t3745 == 0.0 ? 1.0E-16 : t3745
) ; t3134 = ( zc_int348 - 2000.0 ) / 2000.0 ; zc_int348 = t3134 * t3134 * 3.0
- t3134 * t3134 * t3134 * 2.0 ; zc_int350 = zc_int324 * zc_int339 * zc_int350
* 0.55 / ( t2850 == 0.0 ? 1.0E-16 : t2850 ) ; if ( t4813 <= 2000.0 ) {
zc_int324 = t3133 * 1.0E-5 ; } else if ( t4813 >= 4000.0 ) { zc_int324 =
zc_int349 * 1.0E-5 ; } else { zc_int324 = ( ( 1.0 - zc_int348 ) * t3133 +
zc_int349 * zc_int348 ) * 1.0E-5 ; } t4534 = - ( X [ 478ULL ] * t3127 ) ;
zc_int339 = t4534 / 7.8539816339744827E-5 * 0.00031622776601683789 +
zc_int324 ; t4803 = - zc_int339 - zc_int339 * - 0.95 ; zc_int324 = ( - t3427
- zc_int339 * - 0.95 ) / ( t4803 == 0.0 ? 1.0E-16 : t4803 ) ; t3127 =
zc_int324 * zc_int324 * 3.0 - zc_int324 * zc_int324 * zc_int324 * 2.0 ; if (
- t3427 <= t4581 * - 0.95 ) { zc_int324 = t3427 ; } else if ( - t3427 >= -
t4581 ) { zc_int324 = zc_int339 ; } else { zc_int324 = ( 1.0 - t3127 ) *
t3427 + zc_int339 * t3127 ; } zc_int339 = - pmf_sqrt ( ( ( real_T ) ( M [
16ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3754 / ( t3418 == 0.0 ? 1.0E-16 : t3418 ) /
( X [ 493ULL ] == 0.0 ? 1.0E-16 : X [ 493ULL ] ) ) ) * 7.8539816339744827E-5
; t3127 = t4641 * zc_int339 * 35.2 / ( t3742 == 0.0 ? 1.0E-16 : t3742 ) ; if
( t4766 >= 0.0 ) { zc_int349 = zc_int339 * 100000.0 ; } else { zc_int349 = -
zc_int339 * 100000.0 ; } t3133 = zc_int349 * 0.01 / ( t3738 == 0.0 ? 1.0E-16
: t3738 ) ; t3134 = t4703 >= 1.0 ? t3133 : 1.0 ; t2634 = ( t2634 - 2000.0 ) /
2000.0 ; t4548 = pmf_log10 ( 6.9 / ( t3134 == 0.0 ? 1.0E-16 : t3134 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3134 == 0.0 ? 1.0E-16 : t3134
) + 0.00017169489553429715 ) * 3.24 ; zc_int339 = zc_int339 * zc_int349 * (
1.0 / ( t4548 == 0.0 ? 1.0E-16 : t4548 ) ) * 0.55 / ( t3745 == 0.0 ? 1.0E-16
: t3745 ) ; zc_int349 = ( t3133 - 2000.0 ) / 2000.0 ; t3133 = zc_int349 *
zc_int349 * 3.0 - zc_int349 * zc_int349 * zc_int349 * 2.0 ; if ( t4703 <=
2000.0 ) { zc_int349 = t3127 * 1.0E-5 ; } else if ( t4703 >= 4000.0 ) {
zc_int349 = zc_int339 * 1.0E-5 ; } else { zc_int349 = ( ( 1.0 - t3133 ) *
t3127 + zc_int339 * t3133 ) * 1.0E-5 ; } t4548 = X [ 492ULL ] * zc_int357 ;
zc_int339 = t4548 / 7.8539816339744827E-5 * 0.00031622776601683789 +
zc_int349 ; t4641 = - zc_int339 - zc_int339 * - 0.95 ; t3127 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 - zc_int339 *
- 0.95 ) / ( t4641 == 0.0 ? 1.0E-16 : t4641 ) ; zc_int357 = t3127 * t3127 *
3.0 - t3127 * t3127 * t3127 * 2.0 ; if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 <= t3432 * -
0.95 ) { t3127 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 ; } else if (
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 >= - t3432 )
{ t3127 = zc_int339 ; } else { t3127 = ( 1.0 - zc_int357 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 + zc_int339 *
zc_int357 ; } zc_int339 = ( ( real_T ) ( M [ 8ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4494 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ) * ( t4494 / ( X [
64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ) * ( - X [ 478ULL ] /
7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t4626 ; zc_int357 = t2634 * t2634 * 3.0 - t2634 *
t2634 * t2634 * 2.0 ; t2634 = ( ( real_T ) ( M [ 10ULL ] != 0 ) * 2.0 - 1.0 )
* ( t4498 / ( X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( t4498 / (
X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( X [ 478ULL ] /
7.8539816339744827E-5 ) * ( X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + zc_int365 ; zc_int349 = ( X [ 64ULL ] - X [ 485ULL ]
) * pmf_sqrt ( ( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3851 / (
t4716 == 0.0 ? 1.0E-16 : t4716 ) ) ) * t3478 * 0.64 ; t3133 = pmf_sqrt ( ( (
real_T ) ( M [ 21ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3848 / ( t3483 == 0.0 ?
1.0E-16 : t3483 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) *
t3478 * 0.64 ; t4581 = t3133 - t3133 * 0.95 ; t3134 = ( zc_int349 - t3133 *
0.95 ) / ( t4581 == 0.0 ? 1.0E-16 : t4581 ) ; zc_int348 = t3134 * t3134 * 3.0
- t3134 * t3134 * t3134 * 2.0 ; if ( U_idx_11 <= t4768 * 0.95 ) { t3134 =
zc_int349 * 100000.0 ; } else if ( U_idx_11 >= t4768 ) { t3134 = t3133 *
100000.0 ; } else { t3134 = ( ( 1.0 - zc_int348 ) * zc_int349 + t3133 *
zc_int348 ) * 100000.0 ; } zc_int348 = ( - zc_int349 - t3133 * 0.95 ) / (
t4581 == 0.0 ? 1.0E-16 : t4581 ) ; t3139 = zc_int348 * zc_int348 * 3.0 -
zc_int348 * zc_int348 * zc_int348 * 2.0 ; if ( - U_idx_11 <= t4768 * 0.95 ) {
zc_int348 = zc_int349 * 100000.0 ; } else if ( - U_idx_11 >= t4768 ) {
zc_int348 = - t3133 * 100000.0 ; } else { zc_int348 = ( ( 1.0 - t3139 ) *
zc_int349 + - t3133 * t3139 ) * 100000.0 ; } t4626 = X [ 513ULL ] * t4576 ;
zc_int349 = ( ( real_T ) ( M [ 26ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4626 /
1.01325 ) * ( t4626 / 1.01325 ) * ( X [ 519ULL ] / 0.0019634954084936209 ) *
( X [ 519ULL ] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 +
t4628 ; if ( zc_int352 <= 2000.0 ) { t3133 = t2818 * 1.0E-5 ; } else if (
zc_int352 >= 4000.0 ) { t3133 = zc_int350 * 1.0E-5 ; } else { t3133 = ( ( 1.0
- zc_int357 ) * t2818 + zc_int350 * zc_int357 ) * 1.0E-5 ; } zc_int350 = ( (
real_T ) ( M [ 26ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4626 / 1.01325 ) * ( t4626 /
1.01325 ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) * ( - X [ 519ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t4628 ; t4626 = X [
527ULL ] * t4747 ; t2818 = ( ( real_T ) ( M [ 28ULL ] != 0 ) * 2.0 - 1.0 ) *
( t4626 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( t4626 / ( X [
55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( X [ 519ULL ] /
0.0019634954084936209 ) * ( X [ 519ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t4785 ; t4628 = X [ 534ULL ] * t3498 ; zc_int352 = (
( real_T ) ( M [ 29ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4628 / ( X [ 55ULL ] ==
0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( t4628 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 :
X [ 55ULL ] ) ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) * ( - X [ 519ULL
] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3500 ; t4628 = X
[ 531ULL ] * t3498 ; zc_int357 = ( ( real_T ) ( M [ 30ULL ] != 0 ) * 2.0 -
1.0 ) * ( t4628 / 1.01325 ) * ( t4628 / 1.01325 ) * ( - X [ 519ULL ] /
0.0019634954084936209 ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3499 ; t4628 = X [ 533ULL ] * t3498 ; t3139 = ( (
real_T ) ( M [ 31ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4628 / 1.01325 ) * ( t4628 /
1.01325 ) * ( X [ 519ULL ] / 0.0019634954084936209 ) * ( X [ 519ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3502 ; t4628 = X [
532ULL ] * t3498 ; if ( - X [ 519ULL ] >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = - ( (
zc_int352 - zc_int357 ) * X [ 519ULL ] ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 = ( t3139 - ( (
( real_T ) ( M [ 33ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4628 / ( X [ 55ULL ] ==
0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( t4628 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 :
X [ 55ULL ] ) ) * ( X [ 519ULL ] / 0.0019634954084936209 ) * ( X [ 519ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3501 ) ) * X [
519ULL ] ; } zc_int357 = ( ( real_T ) ( M [ 28ULL ] != 0 ) * 2.0 - 1.0 ) * (
t4626 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( t4626 / ( X [
55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( - X [ 519ULL ] /
0.0019634954084936209 ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t4785 ; t3145 = ( ( real_T ) ( M [ 11ULL ] != 0 ) *
2.0 - 1.0 ) * ( U_idx_3 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) *
( U_idx_3 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - X [ 492ULL
] / 7.8539816339744827E-5 ) * ( - X [ 492ULL ] / 7.8539816339744827E-5 ) /
2.0 * 9.999999999999999E-14 + t3304 ; t3304 = - ( X [ 186ULL ] * zc_int36 ) ;
zc_int36 = t3304 / 7.8539816339744827E-5 * 0.00031622776601683789 + t3133 ;
t4747 = X [ 553ULL ] * t4729 ; t3133 = ( ( real_T ) ( M [ 36ULL ] != 0 ) *
2.0 - 1.0 ) * ( t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * (
t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t3538 /
7.8539816339744827E-5 ) * ( t3538 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t4767 ; t4803 = X [ 175ULL ] * t2852 ; t2852 = ( (
real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4803 / ( X [ 176ULL ] == 0.0
? 1.0E-16 : X [ 176ULL ] ) ) * ( t4803 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X
[ 176ULL ] ) ) * ( t3538 / 7.8539816339744827E-5 ) * ( t3538 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t3028 ; zc_int363 = (
( real_T ) ( M [ 36ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4747 / ( X [ 38ULL ] ==
0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 :
X [ 38ULL ] ) ) * ( - t3538 / 7.8539816339744827E-5 ) * ( - t3538 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t4767 ; t4747 = X [
573ULL ] * t3572 ; t3176 = ( ( real_T ) ( M [ 40ULL ] != 0 ) * 2.0 - 1.0 ) *
( t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t4747 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t3538 / 7.8539816339744827E-5
) * ( t3538 / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t3575 ;
t4747 = X [ 570ULL ] * t3572 ; zc_int365 = ( ( real_T ) ( M [ 41ULL ] != 0 )
* 2.0 - 1.0 ) * ( t4747 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) )
* ( t4747 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t3538 /
7.8539816339744827E-5 ) * ( t3538 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3573 ; t4747 = X [ 572ULL ] * t3572 ; zc_int366 = (
( real_T ) ( M [ 42ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4747 / ( X [ 176ULL ] ==
0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t4747 / ( X [ 176ULL ] == 0.0 ? 1.0E-16
: X [ 176ULL ] ) ) * ( - t3538 / 7.8539816339744827E-5 ) * ( - t3538 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t3577 ; t4747 = X [
571ULL ] * t3572 ; if ( t3538 >= 0.0 ) { zc_int368 = ( t3176 - zc_int365 ) *
t3538 ; } else { zc_int368 = - ( ( zc_int366 - ( ( ( real_T ) ( M [ 43ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ]
) ) * ( t4747 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - t3538
/ 7.8539816339744827E-5 ) * ( - t3538 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3576 ) ) * t3538 ) ; } t4658 = - zc_int36 - zc_int36
* - 0.95 ; zc_int365 = ( - t2832 - zc_int36 * - 0.95 ) / ( t4658 == 0.0 ?
1.0E-16 : t4658 ) ; zc_int52 = zc_int365 * zc_int365 * 3.0 - zc_int365 *
zc_int365 * zc_int365 * 2.0 ; if ( - t2832 <= t2830 * - 0.95 ) { zc_int365 =
t2832 ; } else if ( - t2832 >= - t2830 ) { zc_int365 = zc_int36 ; } else {
zc_int365 = ( 1.0 - zc_int52 ) * t2832 + zc_int36 * zc_int52 ; } t4747 = ( (
real_T ) ( M [ 313ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 161ULL ] ; zc_int36 = X [
154ULL ] / 0.001 * ( X [ 154ULL ] / 0.001 ) / ( X [ 161ULL ] == 0.0 ? 1.0E-16
: X [ 161ULL ] ) / ( t4747 == 0.0 ? 1.0E-16 : t4747 ) / 2.0 * 0.001 + ( X [
7ULL ] + 126.84999999999997 ) ; t4677 = X [ 194ULL ] * t2867 ; t2830 = ( (
real_T ) ( M [ 22ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4677 / ( X [ 195ULL ] == 0.0
? 1.0E-16 : X [ 195ULL ] ) ) * ( t4677 / ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X
[ 195ULL ] ) ) * ( X [ 186ULL ] / 7.8539816339744827E-5 ) * ( X [ 186ULL ] /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_199 ;
t4766 = X [ 180ULL ] * U_idx_7 ; t2867 = ( ( real_T ) ( M [ 116ULL ] != 0 ) *
2.0 - 1.0 ) * ( t4766 / 1.01325 ) * ( t4766 / 1.01325 ) * ( - X [ 186ULL ] /
7.8539816339744827E-5 ) * ( - X [ 186ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t2815 ; zc_int52 = ( X [ 195ULL ] - 1.01325 ) *
pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2955 / (
t2837 == 0.0 ? 1.0E-16 : t2837 ) ) ) * t2880 * 0.64 ; t2837 = pmf_sqrt ( ( (
real_T ) ( M [ 137ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2952 / ( t2883 == 0.0 ?
1.0E-16 : t2883 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) *
t2880 * 0.64 ; t4785 = t2837 - t2837 * 0.95 ; t3201 = ( zc_int52 - t2837 *
0.95 ) / ( t4785 == 0.0 ? 1.0E-16 : t4785 ) ; t3204 = t3201 * t3201 * 3.0 -
t3201 * t3201 * t3201 * 2.0 ; if ( t2884 <= zc_int50 * 0.95 ) { t3201 =
zc_int52 * 100000.0 ; } else if ( t2884 >= zc_int50 ) { t3201 = t2837 *
100000.0 ; } else { t3201 = ( ( 1.0 - t3204 ) * zc_int52 + t2837 * t3204 ) *
100000.0 ; } t3204 = ( - zc_int52 - t2837 * 0.95 ) / ( t4785 == 0.0 ? 1.0E-16
: t4785 ) ; t3205 = t3204 * t3204 * 3.0 - t3204 * t3204 * t3204 * 2.0 ; if (
- t2884 <= zc_int50 * 0.95 ) { t3204 = zc_int52 * 100000.0 ; } else if ( -
t2884 >= zc_int50 ) { t3204 = - t2837 * 100000.0 ; } else { t3204 = ( ( 1.0 -
t3205 ) * zc_int52 + - t2837 * t3205 ) * 100000.0 ; } t4716 = ( ( real_T ) (
M [ 324ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 163ULL ] ; t4785 = X [ 226ULL ] *
t2934 ; t2934 = ( ( real_T ) ( M [ 192ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4785 /
( X [ 227ULL ] == 0.0 ? 1.0E-16 : X [ 227ULL ] ) ) * ( t4785 / ( X [ 227ULL ]
== 0.0 ? 1.0E-16 : X [ 227ULL ] ) ) * ( X [ 247ULL ] / 0.32 ) * ( X [ 247ULL
] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t2919 ; zc_int52 = pmf_sqrt (
t2892 * t2892 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 203ULL ] != 0 ) *
2.0 - 1.0 ) * X [ 245ULL ] * zc_int81 * t2890 * 1.0E-9 ) ; t2892 = pmf_sqrt (
zc_int84 * zc_int84 * 9.999999999999999E-14 + ( ( real_T ) ( M [ 215ULL ] !=
0 ) * 2.0 - 1.0 ) * X [ 248ULL ] * t2905 * t2890 * 1.0E-9 ) ; zc_int81 = -
pmf_sqrt ( ( ( real_T ) ( M [ 226ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2962 / (
t2890 == 0.0 ? 1.0E-16 : t2890 ) / ( X [ 245ULL ] == 0.0 ? 1.0E-16 : X [
245ULL ] ) ) ) * 0.32 ; zc_int84 = t2898 * zc_int81 * 2.9973120849090416 / (
t2970 == 0.0 ? 1.0E-16 : t2970 ) ; if ( t2899 >= 0.0 ) { t2905 = zc_int81 *
100000.0 ; } else { t2905 = - zc_int81 * 100000.0 ; } t2899 = t2905 * 0.01 /
( t2966 == 0.0 ? 1.0E-16 : t2966 ) ; t3205 = t2902 >= 1.0 ? t2899 : 1.0 ;
t4767 = pmf_log10 ( 6.9 / ( t3205 == 0.0 ? 1.0E-16 : t3205 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t3205 == 0.0 ? 1.0E-16 : t3205
) + 0.00017169489553429715 ) * 3.24 ; zc_int6 = 0.0 / ( X [ 161ULL ] == 0.0 ?
1.0E-16 : X [ 161ULL ] ) / ( t4747 == 0.0 ? 1.0E-16 : t4747 ) / 2.0 * 0.001 +
( X [ 7ULL ] + 126.84999999999997 ) ; zc_int81 = zc_int81 * t2905 * ( 1.0 / (
t4767 == 0.0 ? 1.0E-16 : t4767 ) ) * 0.046833001326703774 / ( t2973 == 0.0 ?
1.0E-16 : t2973 ) ; t2899 = ( t2899 - 2000.0 ) / 2000.0 ; t2905 = t2899 *
t2899 * 3.0 - t2899 * t2899 * t2899 * 2.0 ; if ( t2902 <= 2000.0 ) { t2899 =
zc_int84 * 1.0E-5 ; } else if ( t2902 >= 4000.0 ) { t2899 = zc_int81 * 1.0E-5
; } else { t2899 = ( ( 1.0 - t2905 ) * zc_int84 + zc_int81 * t2905 ) * 1.0E-5
; } t4747 = X [ 244ULL ] * zc_int52 ; zc_int81 = t4747 / 0.32 *
0.00031622776601683789 + t2899 ; t4768 = - zc_int81 - zc_int81 * - 0.95 ;
t2899 = ( - t2900 - zc_int81 * - 0.95 ) / ( t4768 == 0.0 ? 1.0E-16 : t4768 )
; t2902 = t2899 * t2899 * 3.0 - t2899 * t2899 * t2899 * 2.0 ; if ( - t2900 <=
t2894 * - 0.95 ) { t2899 = t2900 ; } else if ( - t2900 >= - t2894 ) { t2899 =
zc_int81 ; } else { t2899 = ( 1.0 - t2902 ) * t2900 + zc_int81 * t2902 ; }
zc_int81 = - pmf_sqrt ( ( ( real_T ) ( M [ 237ULL ] != 0 ) * 2.0 - 1.0 ) * (
t2982 / ( t2890 == 0.0 ? 1.0E-16 : t2890 ) / ( X [ 248ULL ] == 0.0 ? 1.0E-16
: X [ 248ULL ] ) ) ) * 0.32 ; t2894 = t2898 * zc_int81 * 2.9973120849090416 /
( t2970 == 0.0 ? 1.0E-16 : t2970 ) ; t2898 = ( ( real_T ) ( M [ 116ULL ] != 0
) * 2.0 - 1.0 ) * ( t4766 / 1.01325 ) * ( t4766 / 1.01325 ) * ( X [ 186ULL ]
/ 7.8539816339744827E-5 ) * ( X [ 186ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t2815 ; if ( t2907 >= 0.0 ) { t2902 = zc_int81 *
100000.0 ; } else { t2902 = - zc_int81 * 100000.0 ; } zc_int84 = t2902 * 0.01
/ ( t2966 == 0.0 ? 1.0E-16 : t2966 ) ; t2905 = t2909 >= 1.0 ? zc_int84 : 1.0
; t4766 = pmf_log10 ( 6.9 / ( t2905 == 0.0 ? 1.0E-16 : t2905 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2905 == 0.0 ? 1.0E-16 : t2905
) + 0.00017169489553429715 ) * 3.24 ; zc_int81 = zc_int81 * t2902 * ( 1.0 / (
t4766 == 0.0 ? 1.0E-16 : t4766 ) ) * 0.046833001326703774 / ( t2973 == 0.0 ?
1.0E-16 : t2973 ) ; t2902 = ( zc_int84 - 2000.0 ) / 2000.0 ; zc_int84 = t2902
* t2902 * 3.0 - t2902 * t2902 * t2902 * 2.0 ; if ( t2909 <= 2000.0 ) { t2902
= t2894 * 1.0E-5 ; } else if ( t2909 >= 4000.0 ) { t2902 = zc_int81 * 1.0E-5
; } else { t2902 = ( ( 1.0 - zc_int84 ) * t2894 + zc_int81 * zc_int84 ) *
1.0E-5 ; } t4766 = X [ 247ULL ] * t2892 ; t2892 = t4766 / 0.32 *
0.00031622776601683789 + t2902 ; t4768 = - t2892 - t2892 * - 0.95 ; zc_int81
= ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 - t2892 *
- 0.95 ) / ( t4768 == 0.0 ? 1.0E-16 : t4768 ) ; t2894 = ( ( real_T ) ( M [
13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4803 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X
[ 176ULL ] ) ) * ( t4803 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) )
* ( t2806 / 7.8539816339744827E-5 ) * ( t2806 / 7.8539816339744827E-5 ) / 2.0
* 9.999999999999999E-14 + t3028 ; t2902 = zc_int81 * zc_int81 * 3.0 -
zc_int81 * zc_int81 * zc_int81 * 2.0 ; if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 <= t2906 * -
0.95 ) { zc_int81 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 ; } else if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 >= - t2906 ) {
zc_int81 = t2892 ; } else { zc_int81 = ( 1.0 - t2902 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 + t2892 * t2902
; } t2892 = ( ( real_T ) ( M [ 192ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4785 / ( X
[ 227ULL ] == 0.0 ? 1.0E-16 : X [ 227ULL ] ) ) * ( t4785 / ( X [ 227ULL ] ==
0.0 ? 1.0E-16 : X [ 227ULL ] ) ) * ( - X [ 247ULL ] / 0.32 ) * ( - X [ 247ULL
] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t2919 ; t2902 = ( ( real_T ) ( M [
13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4803 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X
[ 176ULL ] ) ) * ( t4803 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) )
* ( X [ 198ULL ] / 0.32 ) * ( X [ 198ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t3028 ; zc_int84 = pmf_sqrt ( t2956 * t2956 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 301ULL ] != 0 ) * 2.0 - 1.0 ) * X
[ 263ULL ] * t2960 * t2953 * 1.0E-9 ) ; t2905 = - pmf_sqrt ( ( ( real_T ) ( M
[ 305ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3056 / ( t2953 == 0.0 ? 1.0E-16 : t2953
) / ( X [ 263ULL ] == 0.0 ? 1.0E-16 : X [ 263ULL ] ) ) ) * 0.32 ; t2906 =
piece81 * t2905 * 2.9973120849090416 / ( t3064 == 0.0 ? 1.0E-16 : t3064 ) ;
if ( t2971 >= 0.0 ) { t2907 = t2905 * 100000.0 ; } else { t2907 = - t2905 *
100000.0 ; } t2909 = t2907 * 0.01 / ( t3060 == 0.0 ? 1.0E-16 : t3060 ) ;
t2919 = ( ( real_T ) ( M [ 22ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4677 / ( X [
195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) ) * ( t4677 / ( X [ 195ULL ] ==
0.0 ? 1.0E-16 : X [ 195ULL ] ) ) * ( - X [ 186ULL ] / 7.8539816339744827E-5 )
* ( - X [ 186ULL ] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
intrm_sf_mf_199 ; t2956 = t2974 >= 1.0 ? t2909 : 1.0 ; t4803 = pmf_log10 (
6.9 / ( t2956 == 0.0 ? 1.0E-16 : t2956 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t2956 == 0.0 ? 1.0E-16 : t2956 ) + 0.00017169489553429715
) * 3.24 ; t2905 = t2905 * t2907 * ( 1.0 / ( t4803 == 0.0 ? 1.0E-16 : t4803 )
) * 0.046833001326703774 / ( t3067 == 0.0 ? 1.0E-16 : t3067 ) ; t2907 = (
t2909 - 2000.0 ) / 2000.0 ; t2909 = t2907 * t2907 * 3.0 - t2907 * t2907 *
t2907 * 2.0 ; if ( t2974 <= 2000.0 ) { t2907 = t2906 * 1.0E-5 ; } else if (
t2974 >= 4000.0 ) { t2907 = t2905 * 1.0E-5 ; } else { t2907 = ( ( 1.0 - t2909
) * t2906 + t2905 * t2909 ) * 1.0E-5 ; } t4803 = - ( X [ 247ULL ] * zc_int84
) ; zc_int84 = t4803 / 0.32 * 0.00031622776601683789 + t2907 ; t4677 = -
zc_int84 - zc_int84 * - 0.95 ; t2905 = ( - t2972 - zc_int84 * - 0.95 ) / (
t4677 == 0.0 ? 1.0E-16 : t4677 ) ; t2906 = t2905 * t2905 * 3.0 - t2905 *
t2905 * t2905 * 2.0 ; if ( - t2972 <= t2961 * - 0.95 ) { t2905 = t2972 ; }
else if ( - t2972 >= - t2961 ) { t2905 = zc_int84 ; } else { t2905 = ( 1.0 -
t2906 ) * t2972 + zc_int84 * t2906 ; } t2906 = - ( piece20 * 100000.0 ) ;
t2956 = - ( t2840 * 100000.0 ) ; t2840 = - ( piece45 * 100000.0 ) ; piece45 =
- ( t2913 * 100000.0 ) ; t2913 = - ( t2975 * 100000.0 ) ; t2960 = - ( t2994 *
100000.0 ) ; t2961 = - ( t3013 * 100000.0 ) ; piece81 = - ( intrm_sf_mf_636 *
100000.0 ) ; t2971 = - ( t3075 * 100000.0 ) ; t2994 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 * 100000.0 ) ;
t3013 = - ( t3137 * 100000.0 ) ; intrm_sf_mf_636 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 * 100000.0 ) ;
t3028 = - ( piece199 * 100000.0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 = - ( piece416
* 100000.0 ) ; t3137 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 * 100000.0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 = - ( t4815 *
100000.0 ) ; t3205 = - ( t3429 * 100000.0 ) ; t3210 = - ( t3511 * 100000.0 )
; t3212 = - ( t3531 * 100000.0 ) ; t2793 = X [ 154ULL ] / 0.001 / ( t2793 ==
0.0 ? 1.0E-16 : t2793 ) * ( X [ 154ULL ] / 0.001 / ( t2793 == 0.0 ? 1.0E-16 :
t2793 ) ) / 2.0 * 0.001 ; t2049 [ 0 ] = 293.15 ; tlu2_linear_linear_prelookup
( & jdb_efOut . mField0 [ 0ULL ] , & jdb_efOut . mField1 [ 0ULL ] , &
jdb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13
, & t2049 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t193 = jdb_efOut
; tlu2_1d_linear_linear_value ( & kdb_efOut [ 0ULL ] , & t193 . mField0 [
0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField26 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t226 [ 0 ] = kdb_efOut [ 0
] ; tlu2_1d_linear_linear_value ( & ldb_efOut [ 0ULL ] , & t193 . mField0 [
0ULL ] , & t193 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t1941 [ 0 ] = ldb_efOut [ 0
] ; t2626 [ 0ULL ] = t193 . mField0 [ 0ULL ] ; t2626 [ 1ULL ] = t193 .
mField0 [ 1ULL ] ; t1921 [ 0ULL ] = t193 . mField2 [ 0ULL ] ;
tlu2_1d_linear_linear_value ( & mdb_efOut [ 0ULL ] , & t2626 [ 0ULL ] , &
t1921 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t1924 [
0ULL ] , & t225 [ 0ULL ] ) ; t2049 [ 0 ] = mdb_efOut [ 0 ] ; t3231 = ( ( -
t2801 - t2802 ) * t226 [ 0ULL ] + t1941 [ 0ULL ] * t2801 ) + t2049 [ 0ULL ] *
t2802 ; t3232 = ( ( - t3043 - t3044 ) * 296.802103844292 + t3043 * 461.523 )
+ t3044 * 259.836612622973 ; tlu2_1d_linear_linear_value ( & ndb_efOut [ 0ULL
] , & t193 . mField0 [ 0ULL ] , & t193 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField31 , & t1924 [ 0ULL ] , & t225 [ 0ULL
] ) ; t2583 [ 0 ] = ndb_efOut [ 0 ] ; t3233 = ( ( - t3043 - t3044 ) * t226 [
0ULL ] + t1941 [ 0ULL ] * t3043 ) + t2583 [ 0ULL ] * t3044 ; t3242 = t3708 /
192970.66424 * pmf_log ( t3718 / ( t3386 == 0.0 ? 1.0E-16 : t3386 ) ) ; t3248
= ( ( t3242 - t2689 ) - t3396 * 0.01 ) - t2681 ; t3242 = ( ( - t3492 - t3493
) * 296.802103844292 + t3492 * 461.523 ) + t3493 * 259.836612622973 ;
piece422 = ( ( - t3492 - t3493 ) * t226 [ 0ULL ] + t1941 [ 0ULL ] * t3492 ) +
t2583 [ 0ULL ] * t3493 ; t3252 = ( ( - t3496 - t2796 ) * 296.802103844292 +
t3496 * 461.523 ) + t2796 * 259.836612622973 ; t3258 = ( ( t4823 - pmf_log (
X [ 55ULL ] * 100000.0 ) * t3498 ) - t3350 ) + t3252 * 11.526088451496509 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 = ( ( t3382 -
t3252 * 11.526088451496509 ) - t4821 ) + pmf_log ( X [ 55ULL ] * 100000.0 ) *
t3498 ; t1941 [ 0ULL ] = X [ 83ULL ] ; t1921 [ 0 ] = 6ULL ;
tlu2_linear_linear_prelookup ( & odb_efOut . mField0 [ 0ULL ] , & odb_efOut .
mField1 [ 0ULL ] , & odb_efOut . mField2 [ 0ULL ] , & nonscalar58 [ 0ULL ] ,
& t1941 [ 0ULL ] , & t1921 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3 = odb_efOut ;
t1941 [ 0ULL ] = X [ 0ULL ] ; t1924 [ 0 ] = 7ULL ;
tlu2_linear_linear_prelookup ( & pdb_efOut . mField0 [ 0ULL ] , & pdb_efOut .
mField1 [ 0ULL ] , & pdb_efOut . mField2 [ 0ULL ] , & nonscalar59 [ 0ULL ] ,
& t1941 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t187 = pdb_efOut ;
t1941 [ 0ULL ] = X [ 156ULL ] ; tlu2_linear_linear_prelookup ( & qdb_efOut .
mField0 [ 0ULL ] , & qdb_efOut . mField1 [ 0ULL ] , & qdb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1941 [ 0ULL ] , &
t224 [ 0ULL ] , & t225 [ 0ULL ] ) ; t55 = qdb_efOut ; t1941 [ 0ULL ] = X [
157ULL ] ; tlu2_linear_linear_prelookup ( & rdb_efOut . mField0 [ 0ULL ] , &
rdb_efOut . mField1 [ 0ULL ] , & rdb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1941 [ 0ULL ] , & t224 [ 0ULL ]
, & t225 [ 0ULL ] ) ; t170 = rdb_efOut ; t1941 [ 0ULL ] = X [ 8ULL ] ;
tlu2_linear_linear_prelookup ( & sdb_efOut . mField0 [ 0ULL ] , & sdb_efOut .
mField1 [ 0ULL ] , & sdb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField2 , & t1941 [ 0ULL ] , & t224 [ 0ULL ] , & t225 [ 0ULL ] )
; t153 = sdb_efOut ; t1941 [ 0ULL ] = X [ 15ULL ] ;
tlu2_linear_linear_prelookup ( & tdb_efOut . mField0 [ 0ULL ] , & tdb_efOut .
mField1 [ 0ULL ] , & tdb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField3 , & t1941 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] )
; t178 = tdb_efOut ; t1941 [ 0ULL ] = X [ 538ULL ] ; t2571 [ 0 ] = 5ULL ;
tlu2_linear_nearest_prelookup ( & udb_efOut . mField0 [ 0ULL ] , & udb_efOut
. mField1 [ 0ULL ] , & udb_efOut . mField2 [ 0ULL ] , & nonscalar63 [ 0ULL ]
, & t1941 [ 0ULL ] , & t2571 [ 0ULL ] , & t225 [ 0ULL ] ) ; t99 = udb_efOut ;
t1941 [ 0ULL ] = U_idx_12 * 376.99111843077515 * 0.99999999999999978 /
0.99999999999999978 * 0.99999999999999978 / 0.99999999999999978 ; t2572 [ 0 ]
= 3ULL ; tlu2_linear_nearest_prelookup ( & vdb_efOut . mField0 [ 0ULL ] , &
vdb_efOut . mField1 [ 0ULL ] , & vdb_efOut . mField2 [ 0ULL ] , & nonscalar64
[ 0ULL ] , & t1941 [ 0ULL ] , & t2572 [ 0ULL ] , & t225 [ 0ULL ] ) ; t45 =
vdb_efOut ; if ( X [ 78ULL ] != X [ 78ULL ] ) { t3382 = X [ 78ULL ] ; } else
if ( X [ 78ULL ] > 0.0 ) { t3382 = 1.0 ; } else { t3382 = X [ 78ULL ] < 0.0 ?
- 1.0 : 0.0 ; } t1941 [ 0ULL ] = t3382 * X [ 77ULL ] ;
tlu2_linear_nearest_prelookup ( & wdb_efOut . mField0 [ 0ULL ] , & wdb_efOut
. mField1 [ 0ULL ] , & wdb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField47 , & t1941 [ 0ULL ] , & t1647 [ 0ULL ] , & t225 [ 0ULL
] ) ; t166 = wdb_efOut ; t3252 = - ( ( X [ 88ULL ] * 0.1 + 650.0 ) * t2766 +
( 1.0 - t2766 ) * X [ 88ULL ] * 1000.0 ) ; t3350 = M [ 214ULL ] != 0 ? X [
81ULL ] : 0.9 ; t2766 = - ( ( X [ 90ULL ] - X [ 88ULL ] * X [ 89ULL ] * 0.001
) * t5690 / ( t3350 == 0.0 ? 1.0E-16 : t3350 ) * 1000.0 + ( 1.0 - t5690 ) * X
[ 81ULL ] / 1000.0 ) ; if ( M [ 333ULL ] != 0 ) { t5690 = ( ( t2795 - X [
171ULL ] ) - 0.799999992 ) * 1000.0 ; } else { t5690 = ( t2795 - X [ 171ULL ]
) * 1.0E-5 ; } if ( M [ 344ULL ] != 0 ) { t3272 = t2795 - ( ( ( ( ( ( X [
18ULL ] * 0.1 - X [ 88ULL ] ) + X [ 89ULL ] * - 0.1 ) + X [ 172ULL ] * 1.0E-9
) - X [ 174ULL ] ) + X [ 19ULL ] ) - t2794 ) * t3599 * 0.001 ; } else { t3272
= ( X [ 89ULL ] - X [ 171ULL ] ) - ( t2794 * 0.001 + X [ 89ULL ] ) * t3599 ;
} if ( t2806 >= 0.0 ) { t2795 = ( X [ 200ULL ] - X [ 22ULL ] ) - t2821 ; }
else { t2795 = ( X [ 200ULL ] - X [ 22ULL ] ) - t3068 ; } if ( - X [ 186ULL ]
>= 0.0 ) { t2796 = ( X [ 204ULL ] - X [ 22ULL ] ) - t2832 ; } else { t2796 =
( X [ 204ULL ] - X [ 22ULL ] ) - zc_int365 ; } if ( t2884 >= 0.0 ) { t2821 =
X [ 186ULL ] - t3201 ; } else { t2821 = X [ 186ULL ] - t3204 ; } if ( X [
244ULL ] >= 0.0 ) { t2832 = ( X [ 246ULL ] - X [ 31ULL ] ) - t2900 ; } else {
t2832 = ( X [ 246ULL ] - X [ 31ULL ] ) - t2899 ; } if ( X [ 247ULL ] >= 0.0 )
{ t2884 = ( X [ 249ULL ] - X [ 31ULL ] ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 ; } else {
t2884 = ( X [ 249ULL ] - X [ 31ULL ] ) - zc_int81 ; } if ( - X [ 247ULL ] >=
0.0 ) { zc_int81 = ( X [ 264ULL ] - X [ 33ULL ] ) - t2972 ; } else { zc_int81
= ( X [ 264ULL ] - X [ 33ULL ] ) - t2905 ; } if ( X [ 198ULL ] >= 0.0 ) {
t2899 = ( X [ 266ULL ] - X [ 33ULL ] ) - t2987 ; } else { t2899 = ( X [
266ULL ] - X [ 33ULL ] ) - zc_int113 ; } if ( X [ 288ULL ] >= 0.0 ) {
zc_int113 = ( X [ 290ULL ] - X [ 37ULL ] ) - t3011 ; } else { zc_int113 = ( X
[ 290ULL ] - X [ 37ULL ] ) - zc_int132 ; } if ( - X [ 244ULL ] >= 0.0 ) {
t2900 = ( X [ 292ULL ] - X [ 37ULL ] ) - t222 ; } else { t2900 = ( X [ 292ULL
] - X [ 37ULL ] ) - t2980 ; } if ( X [ 325ULL ] >= 0.0 ) { t2905 = ( X [
327ULL ] - X [ 40ULL ] ) - t3069 ; } else { t2905 = ( X [ 327ULL ] - X [
40ULL ] ) - t3009 ; } if ( - X [ 313ULL ] >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = ( X [ 331ULL
] - X [ 40ULL ] ) - t3084 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 = ( X [ 331ULL
] - X [ 40ULL ] ) - zc_int181 ; } if ( t3120 >= 0.0 ) { t2972 = X [ 313ULL ]
- zc_int186 ; } else { t2972 = X [ 313ULL ] - t220 ; } if ( X [ 368ULL ] >=
0.0 ) { t2980 = ( X [ 370ULL ] - X [ 49ULL ] ) - t3135 ; } else { t2980 = ( X
[ 370ULL ] - X [ 49ULL ] ) - zc_int209 ; } if ( X [ 371ULL ] >= 0.0 ) {
zc_int132 = ( X [ 373ULL ] - X [ 49ULL ] ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_3 ; } else {
zc_int132 = ( X [ 373ULL ] - X [ 49ULL ] ) - t213 ; } if ( - X [ 371ULL ] >=
0.0 ) { t213 = ( X [ 388ULL ] - X [ 50ULL ] ) - t3206 ; } else { t213 = ( X [
388ULL ] - X [ 50ULL ] ) - t3030 ; } if ( - X [ 325ULL ] >= 0.0 ) { t2987 = (
X [ 390ULL ] - X [ 50ULL ] ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_59 ; } else {
t2987 = ( X [ 390ULL ] - X [ 50ULL ] ) - t2823 ; } if ( X [ 413ULL ] >= 0.0 )
{ t2823 = ( X [ 415ULL ] - X [ 54ULL ] ) - t3246 ; } else { t2823 = ( X [
415ULL ] - X [ 54ULL ] ) - t3074 ; } if ( - X [ 368ULL ] >= 0.0 ) { zc_int181
= ( X [ 417ULL ] - X [ 54ULL ] ) - t3260 ; } else { zc_int181 = ( X [ 417ULL
] - X [ 54ULL ] ) - t3077 ; } if ( - X [ 478ULL ] >= 0.0 ) { t3009 = ( X [
489ULL ] - X [ 68ULL ] ) - t3427 ; } else { t3009 = ( X [ 489ULL ] - X [
68ULL ] ) - zc_int324 ; } if ( X [ 492ULL ] >= 0.0 ) { t3011 = ( X [ 494ULL ]
- X [ 68ULL ] ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M3 ; } else {
t3011 = ( X [ 494ULL ] - X [ 68ULL ] ) - t3127 ; } if ( U_idx_11 >= 0.0 ) {
zc_int186 = - X [ 478ULL ] - t3134 ; } else { zc_int186 = - X [ 478ULL ] -
zc_int348 ; } if ( M [ 44ULL ] != 0 ) { t220 = - X [ 173ULL ] - ( X [ 464ULL
] - 0.59999999819999994 ) / 0.3 ; } else { t220 = - X [ 173ULL ] - X [ 464ULL
] * 1.0E-8 ; } if ( M [ 45ULL ] != 0 ) { zc_int209 = X [ 581ULL ] - X [
580ULL ] ; } else if ( M [ 46ULL ] != 0 ) { zc_int209 = X [ 581ULL ] - ( - X
[ 580ULL ] ) ; } else { zc_int209 = X [ 581ULL ] - X [ 78ULL ] ; }
tlu2_2d_linear_linear_value ( & xdb_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ]
, & t3 . mField2 [ 0ULL ] , & t187 . mField0 [ 0ULL ] , & t187 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField0 , & t1921 [ 0ULL ] , &
t1924 [ 0ULL ] , & t225 [ 0ULL ] ) ; t1941 [ 0 ] = xdb_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ydb_efOut [ 0ULL ] , & t187 . mField0 [ 0ULL
] , & t187 . mField2 [ 0ULL ] , & nonscalar1 [ 0ULL ] , & t1924 [ 0ULL ] , &
t225 [ 0ULL ] ) ; t226 [ 0 ] = ydb_efOut [ 0 ] ; tlu2_2d_linear_linear_value
( & aeb_efOut [ 0ULL ] , & t3 . mField0 [ 0ULL ] , & t3 . mField2 [ 0ULL ] ,
& t187 . mField0 [ 0ULL ] , & t187 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField50 , & t1921 [ 0ULL ] , & t1924 [ 0ULL ] , & t225 [
0ULL ] ) ; t2583 [ 0 ] = aeb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( &
beb_efOut [ 0ULL ] , & t190 . mField0 [ 0ULL ] , & t190 . mField2 [ 0ULL ] ,
& t182 . mField0 [ 0ULL ] , & t182 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ]
) ; t2049 [ 0 ] = beb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & ceb_efOut
[ 0ULL ] , & t180 . mField0 [ 0ULL ] , & t180 . mField2 [ 0ULL ] , & t179 .
mField0 [ 0ULL ] , & t179 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2585_idx_0 = ceb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & deb_efOut [
0ULL ] , & t163 . mField0 [ 0ULL ] , & t163 . mField2 [ 0ULL ] , & t159 .
mField0 [ 0ULL ] , & t159 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2586_idx_0 = deb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & eeb_efOut [
0ULL ] , & t158 . mField0 [ 0ULL ] , & t158 . mField2 [ 0ULL ] , & t156 .
mField0 [ 0ULL ] , & t156 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
t2587_idx_0 = eeb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & feb_efOut [
0ULL ] , & t148 . mField0 [ 0ULL ] , & t148 . mField2 [ 0ULL ] , & t146 .
mField0 [ 0ULL ] , & t146 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ;
U_idx_1 = feb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & geb_efOut [ 0ULL
] , & t139 . mField0 [ 0ULL ] , & t139 . mField2 [ 0ULL ] , & t137 . mField0
[ 0ULL ] , & t137 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField4 , & t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_3 =
geb_efOut [ 0 ] ; tlu2_2d_linear_linear_value ( & heb_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , & t137 . mField0 [ 0ULL ] ,
& t137 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t224 [ 0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t2815 = heb_efOut [ 0 ]
; tlu2_2d_linear_linear_value ( & ieb_efOut [ 0ULL ] , & t154 . mField0 [
0ULL ] , & t154 . mField2 [ 0ULL ] , & t142 . mField0 [ 0ULL ] , & t142 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [
0ULL ] , & t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_7 = ieb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & jeb_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , & t179 . mField0 [ 0ULL ] , & t179 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_11 = jeb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & keb_efOut [ 0ULL ] , & t136 . mField0 [ 0ULL
] , & t136 . mField2 [ 0ULL ] , & t159 . mField0 [ 0ULL ] , & t159 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_10 = keb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & leb_efOut [ 0ULL ] , & t123 . mField0 [ 0ULL
] , & t123 . mField2 [ 0ULL ] , & t156 . mField0 [ 0ULL ] , & t156 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_4 = leb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & meb_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , & t146 . mField0 [ 0ULL ] , & t146 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t4165 = meb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & neb_efOut [ 0ULL ] , & t102 . mField0 [ 0ULL
] , & t102 . mField2 [ 0ULL ] , & t101 . mField0 [ 0ULL ] , & t101 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; intrm_sf_mf_199 = neb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & oeb_efOut [ 0ULL ] , & t140 . mField0 [ 0ULL
] , & t140 . mField2 [ 0ULL ] , & t182 . mField0 [ 0ULL ] , & t182 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t4251 = oeb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & peb_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , & t101 . mField0 [ 0ULL ] , & t101 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t4221 = peb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & qeb_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL
] , & t170 . mField2 [ 0ULL ] , & t142 . mField0 [ 0ULL ] , & t142 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3573 = qeb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & reb_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , & t101 . mField0 [ 0ULL ] , & t101 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3575 = reb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & seb_efOut [ 0ULL ] , & t170 . mField0 [ 0ULL
] , & t170 . mField2 [ 0ULL ] , & t142 . mField0 [ 0ULL ] , & t142 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3576 = seb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & teb_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , & t178 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3577 = teb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & ueb_efOut [ 0ULL ] , & t153 . mField0 [ 0ULL
] , & t153 . mField2 [ 0ULL ] , & t178 . mField0 [ 0ULL ] , & t178 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t224 [ 0ULL ] , &
t227 [ 0ULL ] , & t225 [ 0ULL ] ) ; U_idx_13 = ueb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & veb_efOut [ 0ULL ] , & t62 . mField0 [ 0ULL ]
, & t62 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3511 = veb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & web_efOut [ 0ULL ] , & t59 . mField0 [ 0ULL ]
, & t59 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3531 = web_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & xeb_efOut [ 0ULL ] , & t173 . mField0 [ 0ULL
] , & t173 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; intrm_sf_mf_1104 = xeb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & yeb_efOut [ 0ULL ] , & t56 . mField0 [ 0ULL ]
, & t56 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t4767 = yeb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & afb_efOut [ 0ULL ] , & t95 . mField0 [ 0ULL ]
, & t95 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t4768 = afb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & bfb_efOut [ 0ULL ] , & t54 . mField0 [ 0ULL ]
, & t54 . mField2 [ 0ULL ] , & t177 . mField0 [ 0ULL ] , & t177 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3848 = bfb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & cfb_efOut [ 0ULL ] , & t53 . mField0 [ 0ULL ]
, & t53 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3851 = cfb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & dfb_efOut [ 0ULL ] , & t77 . mField0 [ 0ULL ]
, & t77 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3496 = dfb_efOut [ 0 ] ;
tlu2_2d_linear_linear_value ( & efb_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t1006 [ 0ULL ] , &
t1009 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3499 = efb_efOut [ 0 ] ;
tlu2_2d_linear_nearest_value ( & ffb_efOut [ 0ULL ] , & t99 . mField0 [ 0ULL
] , & t99 . mField2 [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField51 , & t2571 [ 0ULL ] , &
t2572 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3501 = ffb_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & gfb_efOut [ 0ULL ] , & t166 . mField0 [ 0ULL
] , & t166 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField52
, & t1647 [ 0ULL ] , & t225 [ 0ULL ] ) ; t3572 = gfb_efOut [ 0 ] ; t2047 [
0ULL ] = - 0.0 ; t2047 [ 1ULL ] = - X [ 79ULL ] * ( real_T ) ( X [ 79ULL ] <
0.0 ) / ( t5708 == 0.0 ? 1.0E-16 : t5708 ) ; t2047 [ 2ULL ] = - 0.0 ; t2047 [
3ULL ] = 0.0 ; t2047 [ 4ULL ] = - 0.0 ; t2047 [ 5ULL ] = - 0.0 ; t2047 [ 6ULL
] = - 0.0 ; t2047 [ 7ULL ] = - 0.0 ; t2047 [ 8ULL ] = - ( - ( ( - U_idx_2 +
U_idx_2 ) * ( X [ 161ULL ] / ( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [ 164ULL ] )
) ) / 1.1843079200592157 ) ; t2047 [ 9ULL ] = - 0.0 ; t2047 [ 10ULL ] = ( -
U_idx_2 + U_idx_2 ) * ( X [ 161ULL ] / ( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [
164ULL ] ) ) * ( X [ 7ULL ] + 126.84999999999997 ) ; t2047 [ 11ULL ] = ( (
0.01 - t2790 ) * U_idx_2 * - 0.009810000000000001 + ( 0.01 - t2790 ) *
U_idx_2 * 0.009810000000000001 ) - ( - U_idx_2 + U_idx_2 ) * ( X [ 15ULL ] /
( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [ 164ULL ] ) * 100.0 + X [ 167ULL ] ) ;
t2047 [ 12ULL ] = - 0.0 ; t2047 [ 13ULL ] = - 0.0 ; t2047 [ 14ULL ] = - 0.0 ;
t2047 [ 15ULL ] = - 0.0 ; t2047 [ 16ULL ] = - 0.0 ; t2047 [ 17ULL ] = - 0.0 ;
t2047 [ 18ULL ] = - ( ( ( ( t2877 - t2869 * X [ 23ULL ] ) * ( -
164.72089615570803 / ( t2810 == 0.0 ? 1.0E-16 : t2810 ) ) + ( t2876 - t2869 *
X [ 24ULL ] ) * ( - 3827.6794129126583 / ( t2810 == 0.0 ? 1.0E-16 : t2810 ) )
) - t2906 ) / 12.896402563644669 ) ; t2047 [ 19ULL ] = - ( -
8.1984652990144453E-5 + ( ( ( ( t2875 - t2879 ) * ( t2877 - t2869 * X [ 23ULL
] ) + ( t2874 - t2879 ) * ( t2876 - t2869 * X [ 24ULL ] ) ) + t2869 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 - X [ 21ULL ]
* t2810 * 0.001 ) ) - t2956 ) / 2246.65922904024 ) ; t2047 [ 20ULL ] = - (
t2869 * X [ 23ULL ] - t2906 ) ; t2047 [ 21ULL ] = - ( t2869 * X [ 24ULL ] ) ;
t2047 [ 22ULL ] = - ( ( ( ( t2947 - t2946 * X [ 27ULL ] ) * ( -
164.72089615570803 / ( t2890 == 0.0 ? 1.0E-16 : t2890 ) ) + ( t2945 - t2946 *
X [ 26ULL ] ) * ( - 3827.6794129126583 / ( t2890 == 0.0 ? 1.0E-16 : t2890 ) )
) - t2840 ) / 12.896402563644669 ) ; t2047 [ 23ULL ] = - ( ( ( ( ( t2944 -
t2950 ) * ( t2947 - t2946 * X [ 27ULL ] ) + ( t2943 - t2950 ) * ( t2945 -
t2946 * X [ 26ULL ] ) ) + t2946 * ( t2948 - X [ 25ULL ] * t2890 * 0.001 ) ) -
piece45 ) / 2246.65922904024 ) ; t2047 [ 24ULL ] = - ( t2946 * X [ 27ULL ] -
t2840 ) ; t2047 [ 25ULL ] = - ( t2946 * X [ 26ULL ] ) ; t2047 [ 26ULL ] = - (
( ( ( t2998 - intrm_sf_mf_454 * X [ 30ULL ] ) * ( - 164.72089615570803 / (
t2953 == 0.0 ? 1.0E-16 : t2953 ) ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 -
intrm_sf_mf_454 * X [ 29ULL ] ) * ( - 3827.6794129126583 / ( t2953 == 0.0 ?
1.0E-16 : t2953 ) ) ) - t2913 ) / 13.896402563644669 ) ; t2047 [ 27ULL ] = -
( ( ( ( ( t2963 - t3001 ) * ( t2998 - intrm_sf_mf_454 * X [ 30ULL ] ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi103 - t3001 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi95 -
intrm_sf_mf_454 * X [ 29ULL ] ) ) + intrm_sf_mf_454 * ( t2999 - X [ 28ULL ] *
t2953 * 0.001 ) ) - t2960 ) / 2448.8207083326588 ) ; t2047 [ 28ULL ] = - (
intrm_sf_mf_454 * X [ 30ULL ] - t2913 ) ; t2047 [ 29ULL ] = - (
intrm_sf_mf_454 * X [ 29ULL ] ) ; t2047 [ 30ULL ] = - ( ( ( ( t3036 - t3035 *
X [ 36ULL ] ) * ( - 164.72089615570803 / ( t3003 == 0.0 ? 1.0E-16 : t3003 ) )
+ ( t3034 - t3035 * X [ 35ULL ] ) * ( - 3827.6794129126583 / ( t3003 == 0.0 ?
1.0E-16 : t3003 ) ) ) - t2961 ) / 12.896402563644669 ) ; t2047 [ 31ULL ] = -
( ( ( ( ( t3033 - t3040 ) * ( t3036 - t3035 * X [ 36ULL ] ) + ( t3032 - t3040
) * ( t3034 - t3035 * X [ 35ULL ] ) ) + t3035 * ( intrm_sf_mf_661 - X [ 34ULL
] * t3003 * 0.001 ) ) - piece81 ) / 2246.65922904024 ) ; t2047 [ 32ULL ] = -
( t3035 * X [ 36ULL ] - t2961 ) ; t2047 [ 33ULL ] = - ( t3035 * X [ 35ULL ] )
; t2047 [ 34ULL ] = - ( ( ( t3111 - t3110 * X [ 41ULL ] ) * ( -
164.72089615570803 / ( t3054 == 0.0 ? 1.0E-16 : t3054 ) ) + ( t3109 - t3110 *
X [ 42ULL ] ) * ( 36.965491221318985 / ( t3054 == 0.0 ? 1.0E-16 : t3054 ) ) )
- t2971 ) ; t2047 [ 35ULL ] = - ( - 0.00042386385785324375 + ( ( ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M47 - t3114 ) * (
t3111 - t3110 * X [ 41ULL ] ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M46 - t3114 ) * (
t3109 - t3110 * X [ 42ULL ] ) ) + t3110 * ( t3112 - X [ 39ULL ] * t3054 *
0.001 ) ) - t2994 ) / 2172.7681408465714 ) ; t2047 [ 36ULL ] = - ( t3110 * X
[ 41ULL ] - t2971 ) ; t2047 [ 37ULL ] = - ( t3110 * X [ 42ULL ] ) ; t2047 [
38ULL ] = - ( ( ( t3192 - t3191 * X [ 45ULL ] ) * ( - 164.72089615570803 / (
intrm_sf_mf_869 == 0.0 ? 1.0E-16 : intrm_sf_mf_869 ) ) + ( t3190 - t3191 * X
[ 44ULL ] ) * ( 36.965491221318985 / ( intrm_sf_mf_869 == 0.0 ? 1.0E-16 :
intrm_sf_mf_869 ) ) ) - t3013 ) ; t2047 [ 39ULL ] = - ( ( ( ( ( t3189 - t3195
) * ( t3192 - t3191 * X [ 45ULL ] ) + ( t3188 - t3195 ) * ( t3190 - t3191 * X
[ 44ULL ] ) ) + t3191 * ( t3193 - X [ 43ULL ] * intrm_sf_mf_869 * 0.001 ) ) -
intrm_sf_mf_636 ) / 2172.7681408465714 ) ; t2047 [ 40ULL ] = - ( t3191 * X [
45ULL ] - t3013 ) ; t2047 [ 41ULL ] = - ( t3191 * X [ 44ULL ] ) ; t2047 [
42ULL ] = - ( ( ( ( t3224 - t3218 * X [ 48ULL ] ) * ( - 164.72089615570803 /
( t3197 == 0.0 ? 1.0E-16 : t3197 ) ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 - t3218 * X [
47ULL ] ) * ( 36.965491221318985 / ( t3197 == 0.0 ? 1.0E-16 : t3197 ) ) ) -
t3028 ) / 1.5549856083302016 ) ; t2047 [ 43ULL ] = - ( ( ( ( ( t2705 -
intrm_sf_mf_1064 ) * ( t3224 - t3218 * X [ 48ULL ] ) + ( t3184 -
intrm_sf_mf_1064 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_95 - t3218 * X [
47ULL ] ) ) + t3218 * ( t3225 - X [ 46ULL ] * t3197 * 0.001 ) ) - ( - ( t3219
* 100000.0 ) ) ) / 2374.9296201389902 ) ; t2047 [ 44ULL ] = - ( t3218 * X [
48ULL ] - t3028 ) ; t2047 [ 45ULL ] = - ( t3218 * X [ 47ULL ] ) ; t2047 [
46ULL ] = - ( ( ( t3280 - t3279 * X [ 53ULL ] ) * ( - 164.72089615570803 / (
t3229 == 0.0 ? 1.0E-16 : t3229 ) ) + ( t3278 - t3279 * X [ 52ULL ] ) * (
36.965491221318985 / ( t3229 == 0.0 ? 1.0E-16 : t3229 ) ) ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 ) ; t2047 [
47ULL ] = - ( ( ( ( ( ( t3264 - X [ 51ULL ] * 0.461523 ) - t3283 ) * ( t3280
- t3279 * X [ 53ULL ] ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip44 - t3283 ) * (
t3278 - t3279 * X [ 52ULL ] ) ) + t3279 * ( t3281 - X [ 51ULL ] * t3229 *
0.001 ) ) - t3137 ) / 2172.7681408465714 ) ; t2047 [ 48ULL ] = - ( t3279 * X
[ 53ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M9 )
; t2047 [ 49ULL ] = - ( t3279 * X [ 52ULL ] ) ; t2047 [ 50ULL ] = - ( t3292 *
t3293 * t3289 / 8385.55841330098 ) ; t2047 [ 51ULL ] = 0.0 ; t2047 [ 52ULL ]
= - 0.0 ; t2047 [ 53ULL ] = - 0.0 ; t2047 [ 54ULL ] = - 0.0 ; t2047 [ 55ULL ]
= - 0.0 ; t2047 [ 56ULL ] = - 0.0 ; t2047 [ 57ULL ] = - ( ( ( ( t3412 - t3411
* X [ 66ULL ] ) * ( - 164.72089615570803 / ( t3401 == 0.0 ? 1.0E-16 : t3401 )
) + ( X [ 479ULL ] - t3411 * X [ 65ULL ] ) * ( - 3827.6794129126583 / ( t3401
== 0.0 ? 1.0E-16 : t3401 ) ) ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 ) /
12.896402563644669 ) ; t2047 [ 58ULL ] = - ( ( ( ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T22 - t3416 ) * (
t3412 - t3411 * X [ 66ULL ] ) + ( t3408 - t3416 ) * ( X [ 479ULL ] - t3411 *
X [ 65ULL ] ) ) + t3411 * ( t3414 - X [ 63ULL ] * t3401 * 0.001 ) ) - ( - (
t4812 * 100000.0 ) ) ) / 2246.65922904024 ) ; t2047 [ 59ULL ] = - ( t3411 * X
[ 66ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_8 ) ;
t2047 [ 60ULL ] = - ( t3411 * X [ 65ULL ] ) ; t2047 [ 61ULL ] = - ( ( ( (
t3468 - t3467 * X [ 69ULL ] ) * ( - 164.72089615570803 / ( t3418 == 0.0 ?
1.0E-16 : t3418 ) ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 - t3467 * X [
70ULL ] ) * ( - 3827.6794129126583 / ( t3418 == 0.0 ? 1.0E-16 : t3418 ) ) ) -
t3205 ) / 12.896402563644669 ) ; t2047 [ 62ULL ] = - ( ( ( ( ( t3464 - t3476
) * ( t3468 - t3467 * X [ 69ULL ] ) + ( t3462 - t3476 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M37 - t3467 * X [
70ULL ] ) ) + t3467 * ( t3473 - X [ 67ULL ] * t3418 * 0.001 ) ) - ( - ( t3439
* 100000.0 ) ) ) / 2246.65922904024 ) ; t2047 [ 63ULL ] = - ( t3467 * X [
69ULL ] - t3205 ) ; t2047 [ 64ULL ] = - ( t3467 * X [ 70ULL ] ) ; t2047 [
65ULL ] = - 0.0 ; t2047 [ 66ULL ] = - ( ( ( t3522 - t3521 * X [ 73ULL ] ) * (
- 164.72089615570803 / ( t3510 == 0.0 ? 1.0E-16 : t3510 ) ) + ( t3520 - t3521
* X [ 72ULL ] ) * ( 36.965491221318985 / ( t3510 == 0.0 ? 1.0E-16 : t3510 ) )
) - t3210 ) ; t2047 [ 67ULL ] = - ( ( ( ( ( t3519 - t3525 ) * ( t3522 - t3521
* X [ 73ULL ] ) + ( t3518 - t3525 ) * ( t3520 - t3521 * X [ 72ULL ] ) ) +
t3521 * ( t3523 - X [ 71ULL ] * t3510 * 0.001 ) ) - ( - ( t3513 * 100000.0 )
) ) / 2172.7681408465714 ) ; t2047 [ 68ULL ] = - ( t3521 * X [ 73ULL ] -
t3210 ) ; t2047 [ 69ULL ] = - ( t3521 * X [ 72ULL ] ) ; t2047 [ 70ULL ] = - (
( ( ( t3563 - t3558 * X [ 76ULL ] ) * ( - 164.72089615570803 / ( t3530 == 0.0
? 1.0E-16 : t3530 ) ) + ( t3557 - t3558 * X [ 75ULL ] ) * ( -
3827.6794129126583 / ( t3530 == 0.0 ? 1.0E-16 : t3530 ) ) ) - t3212 ) /
12.896402563644669 ) ; t2047 [ 71ULL ] = - ( ( ( ( ( t3555 - t3568 ) * (
t3563 - t3558 * X [ 76ULL ] ) + ( t3554 - t3568 ) * ( t3557 - t3558 * X [
75ULL ] ) ) + t3558 * ( t3564 - X [ 74ULL ] * t3530 * 0.001 ) ) - ( - ( t3533
* 100000.0 ) ) ) / 2246.65922904024 ) ; t2047 [ 72ULL ] = - ( t3558 * X [
76ULL ] - t3212 ) ; t2047 [ 73ULL ] = - ( t3558 * X [ 75ULL ] ) ; t2047 [
74ULL ] = - 0.0 ; t2047 [ 75ULL ] = - 0.0 ; t2047 [ 76ULL ] = - 0.0 ; t2047 [
77ULL ] = - 0.0 ; t2047 [ 78ULL ] = - 0.0 ; t5294 = - t1941 [ 0ULL ] ; t2047
[ 79ULL ] = t5294 / 285.84000000000015 ; t2047 [ 80ULL ] = - t226 [ 0ULL ] ;
t2047 [ 81ULL ] = - 0.0 - ( X [ 79ULL ] * t3059 + t3631 ) ; t2047 [ 82ULL ] =
- ( X [ 79ULL ] * X [ 79ULL ] * t3059 * 0.001 ) ; t2047 [ 83ULL ] = - ( X [
1ULL ] / ( t5708 == 0.0 ? 1.0E-16 : t5708 ) ) ; t2047 [ 84ULL ] = - 1.0 ;
t2047 [ 85ULL ] = - 1.0 ; t5708 = - t2583 [ 0ULL ] ; t2047 [ 86ULL ] = t5708
/ 2.865772800000002 ; t2047 [ 87ULL ] = t3252 / 1000.0 ; t2047 [ 88ULL ] =
t2766 ; t2047 [ 89ULL ] = - ( X [ 88ULL ] * X [ 88ULL ] *
0.00010037240412334386 ) - 0.001 ; t2047 [ 90ULL ] = - ( X [ 88ULL ] * X [
88ULL ] ) / 1.0E+6 ; t2047 [ 91ULL ] = ( X [ 96ULL ] / ( t5007 == 0.0 ?
1.0E-16 : t5007 ) - ( ( t2728 * t2729 - t2727 * X [ 98ULL ] ) + t5250 * 100.0
) ) / 2.6578958850679178E+7 ; t5294 = t2049 [ 0ULL ] - ( t2728 * t2729 +
t2727 * X [ 98ULL ] ) ; t2047 [ 92ULL ] = t5294 / 1.3398809999599461E+7 ;
t2047 [ 93ULL ] = ( - X [ 96ULL ] / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) - ( (
t2733 * t2735 - X [ 98ULL ] * t2731 ) + t4901 * 100.0 ) ) /
2.6578958850679178E+7 ; t2047 [ 94ULL ] = ( t2585_idx_0 - ( t2733 * t2735 + X
[ 98ULL ] * t2731 ) ) / 1.3398809999599461E+7 ; t2047 [ 95ULL ] = - ( t5267 *
X [ 100ULL ] *
Electrical_Cooling_System_Flow_Restriction_Converter_Motor_vel0 *
1.7057302038528544E-6 ) ; t2047 [ 96ULL ] = - ( t5267 * X [ 100ULL ] *
2.7488935718910689E-5 ) ; t2047 [ 97ULL ] = ( X [ 105ULL ] / ( t5007 == 0.0 ?
1.0E-16 : t5007 ) - ( ( t2728 * t2736 - t2727 * X [ 107ULL ] ) +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co0 * 100.0 ) ) /
2.6578958850679178E+7 ; t2047 [ 98ULL ] = ( t2586_idx_0 - ( t2728 * t2736 +
t2727 * X [ 107ULL ] ) ) / 1.3398809999599461E+7 ; t2047 [ 99ULL ] = ( - X [
105ULL ] / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) - ( ( t2733 * t2739 - t2731 * X
[ 107ULL ] ) + t2738 * 100.0 ) ) / 2.6578958850679178E+7 ; t2047 [ 100ULL ] =
( t2587_idx_0 - ( t2733 * t2739 + t2731 * X [ 107ULL ] ) ) /
1.3398809999599461E+7 ; t2047 [ 101ULL ] = - ( t4891 * X [ 109ULL ] * t2741 *
1.7057302038528544E-6 ) ; t2047 [ 102ULL ] = - ( t4891 * X [ 109ULL ] *
2.7488935718910689E-5 ) ; t2047 [ 103ULL ] = ( X [ 114ULL ] / ( t5007 == 0.0
? 1.0E-16 : t5007 ) - ( ( t2728 * t2742 - t2727 * X [ 116ULL ] ) +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio0 * 100.0 ) ) /
2.6578958850679178E+7 ; t2047 [ 104ULL ] = ( U_idx_1 - ( t2728 * t2742 +
t2727 * X [ 116ULL ] ) ) / 1.3398809999599461E+7 ; t2047 [ 105ULL ] = ( - X [
114ULL ] / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) - ( ( t2733 * t2745 - t2731 * X
[ 116ULL ] ) + t2744 * 100.0 ) ) / 2.6578958850679178E+7 ; t2047 [ 106ULL ] =
( U_idx_3 - ( t2733 * t2745 + t2731 * X [ 116ULL ] ) ) /
1.3398809999599461E+7 ; t2047 [ 107ULL ] = - ( t2737 * X [ 118ULL ] * t2747 *
1.7057302038528544E-6 ) ; t2047 [ 108ULL ] = - ( t2737 * X [ 118ULL ] *
2.7488935718910689E-5 ) ; t2047 [ 109ULL ] = ( X [ 114ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( ( t2745 *
t2751 - Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X [
124ULL ] ) + t2750 * 100.0 ) ) / 1.328947942533959E+8 ; t2047 [ 110ULL ] = (
t2815 - ( t2745 * t2751 +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X [ 124ULL ]
) ) / 6.6994049997997306E+7 ; t2047 [ 111ULL ] = ( X [ 121ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( ( t2755 *
t2756 - t2752 * X [ 126ULL ] ) + t2753 * 100.0 ) ) / 1.328947942533959E+8 ;
t2047 [ 112ULL ] = ( U_idx_7 - ( t2755 * t2756 + t2752 * X [ 126ULL ] ) ) /
6.6994049997997306E+7 ; t2047 [ 113ULL ] = - ( ( ( U_idx_0 - X [ 6ULL ] ) * (
t2758 * 0.031415926535897927 / 0.01 ) + t2749 ) * 0.001 ) /
28.173600337531049 ; t2047 [ 114ULL ] = - t2760 / 4.10734471884094 ; t2047 [
115ULL ] = - t2760 / 4.10734471884094 ; t2047 [ 116ULL ] = - ( t2851 - t3613
) ; t2047 [ 117ULL ] = ( X [ 96ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( ( t2735 *
t2751 - Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X [
129ULL ] ) + Electrical_Cooling_System_Pipe_Converter_pipe_model_convection0
* 100.0 ) ) / 1.328947942533959E+8 ; t2047 [ 118ULL ] = ( U_idx_11 - ( t2735
* t2751 + Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X
[ 129ULL ] ) ) / 6.6994049997997306E+7 ; t2047 [ 119ULL ] = ( - X [ 105ULL ]
/ ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ?
1.0E-16 : Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( (
t2736 * t2755 - t2752 * X [ 131ULL ] ) +
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU * 100.0 ) ) /
1.328947942533959E+8 ; t2047 [ 120ULL ] = ( U_idx_10 - ( t2736 * t2755 +
t2752 * X [ 131ULL ] ) ) / 6.6994049997997306E+7 ; t2047 [ 121ULL ] = - ( ( (
X [ 10ULL ] - X [ 9ULL ] ) * (
Electrical_Cooling_System_Pipe_Converter_pipe_model_delta_T *
0.031415926535897927 / 0.01 ) + t2763 ) * 0.001 ) ; t2047 [ 122ULL ] = -
t2767 / 4.10734471884094 ; t2047 [ 123ULL ] = - t2767 / 4.10734471884094 ;
t2047 [ 124ULL ] = - ( t2923 - t2926 ) ; t2047 [ 125ULL ] = ( X [ 105ULL ] /
( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( ( t2739 *
t2751 - Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X [
134ULL ] ) + t2769 * 100.0 ) ) / 1.328947942533959E+8 ; t2047 [ 126ULL ] = (
U_idx_4 - ( t2739 * t2751 +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio3 * X [ 134ULL ]
) ) / 6.6994049997997306E+7 ; t2047 [ 127ULL ] = ( - X [ 114ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_avg ) - ( ( t2742 *
t2755 - t2752 * X [ 136ULL ] ) +
Electrical_Cooling_System_Pipe_Motor_pipe_model_NTU * 100.0 ) ) /
1.328947942533959E+8 ; t2047 [ 128ULL ] = ( t4165 - ( t2742 * t2755 + t2752 *
X [ 136ULL ] ) ) / 6.6994049997997306E+7 ; t2047 [ 129ULL ] = - ( ( ( X [
12ULL ] - X [ 11ULL ] ) * (
Electrical_Cooling_System_Pipe_Motor_pipe_model_k_I * 0.031415926535897927 /
0.01 ) + t2771 ) * 0.001 ) ; t2047 [ 130ULL ] = - t2775 / 4.10734471884094 ;
t2047 [ 131ULL ] = - t2775 / 4.10734471884094 ; t2047 [ 132ULL ] = - ( t3578
- t3621 ) ; t2047 [ 133ULL ] = ( X [ 139ULL ] / ( t5007 == 0.0 ? 1.0E-16 :
t5007 ) - ( ( t2728 * t2779 - t2727 * X [ 141ULL ] ) + t2778 * 100.0 ) ) /
2.6578958850679178E+7 ; t2047 [ 134ULL ] = ( intrm_sf_mf_199 - ( t2728 *
t2779 + t2727 * X [ 141ULL ] ) ) / 1.3398809999599461E+7 ; t2047 [ 135ULL ] =
( - X [ 96ULL ] / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) - ( ( t2729 * t2733 -
t2731 * X [ 141ULL ] ) + t2781 * 100.0 ) ) / 2.6578958850679178E+7 ; t2047 [
136ULL ] = ( t4251 - ( t2729 * t2733 + t2731 * X [ 141ULL ] ) ) /
1.3398809999599461E+7 ; t2047 [ 137ULL ] = ( X [ 93ULL ] - X [ 138ULL ] ) *
U_idx_2 / ( t4834 == 0.0 ? 1.0E-16 : t4834 ) * 100.0 ; t2047 [ 138ULL ] = X [
143ULL ] * t2757 * 1.0E-6 ; t2047 [ 139ULL ] = ( X [ 150ULL ] / ( t2782 ==
0.0 ? 1.0E-16 : t2782 ) - ( ( X [ 154ULL ] / ( t2782 == 0.0 ? 1.0E-16 : t2782
) + 1.0 ) / 2.0 * t2783 - ( 1.0 - X [ 154ULL ] / ( t2782 == 0.0 ? 1.0E-16 :
t2782 ) ) / 2.0 * X [ 153ULL ] ) ) / 1.0491143727428995E+6 ; t2047 [ 140ULL ]
= ( - X [ 150ULL ] / ( t2787 == 0.0 ? 1.0E-16 : t2787 ) - ( ( - X [ 154ULL ]
/ ( t2787 == 0.0 ? 1.0E-16 : t2787 ) + 1.0 ) / 2.0 * t2789 - ( 1.0 - - X [
154ULL ] / ( t2787 == 0.0 ? 1.0E-16 : t2787 ) ) / 2.0 * X [ 153ULL ] ) ) /
1.0491143727428995E+6 ; t2047 [ 141ULL ] = - ( t2784 * 0.99999999999999978 )
; t2047 [ 142ULL ] = 126.84999999999997 + t2793 ; t2047 [ 143ULL ] =
126.84999999999997 + - X [ 154ULL ] / 0.001 / ( piece313 == 0.0 ? 1.0E-16 :
piece313 ) * ( - X [ 154ULL ] / 0.001 / ( piece313 == 0.0 ? 1.0E-16 :
piece313 ) ) / 2.0 * 0.001 ; t2047 [ 144ULL ] = ( - X [ 150ULL ] / ( t2782 ==
0.0 ? 1.0E-16 : t2782 ) - ( ( - X [ 154ULL ] / ( t2782 == 0.0 ? 1.0E-16 :
t2782 ) + 1.0 ) / 2.0 * t2785 - ( 1.0 - - X [ 154ULL ] / ( t2782 == 0.0 ?
1.0E-16 : t2782 ) ) / 2.0 * X [ 155ULL ] ) ) / 1.0491143727428995E+6 ; t2047
[ 145ULL ] = - 1.01325 ; t2047 [ 146ULL ] = - 426.85 - - X [ 154ULL ] / 0.001
/ 1.1768292682926846 * ( - X [ 154ULL ] / 0.001 / 1.1768292682926846 ) / 2.0
* 0.001 ; t2047 [ 147ULL ] = ( X [ 150ULL ] / ( t2819 == 0.0 ? 1.0E-16 :
t2819 ) - ( ( X [ 154ULL ] / ( t2819 == 0.0 ? 1.0E-16 : t2819 ) + 1.0 ) / 2.0
* t3086 - ( 1.0 - X [ 154ULL ] / ( t2819 == 0.0 ? 1.0E-16 : t2819 ) ) / 2.0 *
zc_int36 ) ) / 1.0154029933632419E+6 ; t2047 [ 148ULL ] = ( 0.0 / ( t3590 ==
0.0 ? 1.0E-16 : t3590 ) - ( ( 0.0 / ( t3590 == 0.0 ? 1.0E-16 : t3590 ) + 1.0
) / 2.0 * ( 0.0 / ( X [ 163ULL ] == 0.0 ? 1.0E-16 : X [ 163ULL ] ) / ( t4716
== 0.0 ? 1.0E-16 : t4716 ) / 2.0 * 0.001 + ( ( X [ 144ULL ] - 293.15 ) +
420.0 ) ) - ( 1.0 - 0.0 / ( t3590 == 0.0 ? 1.0E-16 : t3590 ) ) / 2.0 *
zc_int6 ) ) / 0.5 ; t2047 [ 149ULL ] = ( t3570 - ( t3482 - t2849 ) ) /
0.98692326671601283 + 5.7344703551184342 ; t2047 [ 150ULL ] = ( t3579 - (
t3490 - intrm_sf_mf_1748 ) ) / 0.83333333333333337 + 6.791378658911543 ;
t2047 [ 151ULL ] = ( t3582 - ( t3506 - intrm_sf_mf_1462 ) ) /
0.83333333333333337 + 6.791378658911543 ; t2047 [ 152ULL ] = ( - X [ 139ULL ]
/ ( t5007 == 0.0 ? 1.0E-16 : t5007 ) - ( ( t2733 * t2779 - t2731 * X [ 167ULL
] ) + - U_idx_2 / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) * X [ 138ULL ] / ( X [
159ULL ] == 0.0 ? 1.0E-16 : X [ 159ULL ] ) * 100.0 ) ) / 2.65794426837838E+7
; t2047 [ 153ULL ] = ( - X [ 121ULL ] / ( t5007 == 0.0 ? 1.0E-16 : t5007 ) -
( ( t2728 * t2756 - t2727 * X [ 167ULL ] ) + U_idx_2 / ( t5007 == 0.0 ?
1.0E-16 : t5007 ) * X [ 120ULL ] / ( X [ 160ULL ] == 0.0 ? 1.0E-16 : X [
160ULL ] ) * 100.0 ) ) / 2.65794426837838E+7 ; t2047 [ 154ULL ] = - t4221 ;
t2047 [ 155ULL ] = - t3573 ; t2047 [ 156ULL ] = - ( t2733 * t2779 + t2731 * X
[ 167ULL ] ) / 1.3398809999599461E+7 ; t2047 [ 157ULL ] = - ( t2728 * t2756 +
t2727 * X [ 167ULL ] ) / 1.3398809999599461E+7 ; t2047 [ 158ULL ] = - t3575 /
4.10734471884094 ; t2047 [ 159ULL ] = - t3576 / 4.10734471884094 ; t2047 [
160ULL ] = - t3577 / 4.0757781197154195 ; t2047 [ 161ULL ] = 0.0 ; t2047 [
162ULL ] = 0.0 ; t2047 [ 163ULL ] = ( 0.01 - t2790 ) * X [ 159ULL ] *
9.8100000000000013E-5 + t3596 ; t2047 [ 164ULL ] = ( 0.01 - t2790 ) * X [
160ULL ] * 9.8100000000000013E-5 + t3598 ; t2047 [ 165ULL ] = - ( t2790 * X [
164ULL ] * 0.005 ) / 5.0 ; t2047 [ 166ULL ] = - U_idx_13 ; t2047 [ 167ULL ] =
0.0 ; t2047 [ 168ULL ] = 0.0 ; t2047 [ 169ULL ] = 0.0 ; t2047 [ 170ULL ] = -
t5690 ; t2047 [ 171ULL ] = t3272 ; t2047 [ 172ULL ] = - ( t2794 * t3599 ) ;
t5708 = X [ 186ULL ] + t2800 ; U_idx_11 = t2800 - X [ 186ULL ] ; t2047 [
173ULL ] = - ( t5708 / 2.0 * t2898 - U_idx_11 / 2.0 * X [ 185ULL ] ) /
365.59674280784293 ; U_idx_7 = X [ 186ULL ] + t2799 ; t5294 = t2799 - X [
186ULL ] ; t2047 [ 174ULL ] = - ( U_idx_7 / 2.0 * X [ 182ULL ] - t5294 / 2.0
* X [ 190ULL ] ) ; t5690 = X [ 186ULL ] + t2798 ; U_idx_10 = t2798 - X [
186ULL ] ; t2047 [ 175ULL ] = - ( t5690 / 2.0 * X [ 181ULL ] - U_idx_10 / 2.0
* X [ 189ULL ] ) ; t2047 [ 176ULL ] = 0.0 ; t2047 [ 177ULL ] = X [ 193ULL ] *
t2803 / 461.523 ; t2047 [ 178ULL ] = X [ 183ULL ] * t2805 ; t2047 [ 179ULL ]
= 0.071939481849452439 + ( ( ( - t2801 - t2802 ) * 296.802103844292 + t2801 *
461.523 ) + t2802 * 4124.48151675695 ) * 0.9997 / 4124.48151675695 ; t2815 =
t2803 * 293.15 ; t2047 [ 180ULL ] = - 304.06022922571 - ( ( ( real_T ) ( M [
2ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2815 / 1.01325 ) * ( t2815 / 1.01325 ) * ( X
[ 186ULL ] / 7.8539816339744827E-5 ) * ( X [ 186ULL ] / 7.8539816339744827E-5
) / 2.0 * 9.999999999999999E-14 + t3231 ) ; t2047 [ 181ULL ] = - t2801 ;
t2047 [ 182ULL ] = - t2802 ; t2047 [ 183ULL ] = - ( ( t2806 + t2862 ) / 2.0 *
t2894 - ( t2862 - t2806 ) / 2.0 * X [ 209ULL ] ) ; t2047 [ 184ULL ] = - ( (
t2806 + intrm_sf_mf_157 ) / 2.0 * X [ 178ULL ] - ( intrm_sf_mf_157 - t2806 )
/ 2.0 * X [ 215ULL ] ) ; t2047 [ 185ULL ] = - ( ( t2806 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1 ) / 2.0 * X [
177ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c1
- t2806 ) / 2.0 * X [ 214ULL ] ) ; t2047 [ 186ULL ] = - ( ( - X [ 186ULL ] +
t2873 ) / 2.0 * t2919 - ( t2873 - ( - X [ 186ULL ] ) ) / 2.0 * X [ 216ULL ] )
; t2047 [ 187ULL ] = - ( ( - X [ 186ULL ] + t2872 ) / 2.0 * X [ 197ULL ] - (
t2872 - ( - X [ 186ULL ] ) ) / 2.0 * X [ 218ULL ] ) ; t2047 [ 188ULL ] = - (
( - X [ 186ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6 ) / 2.0 * X [
196ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c6
- ( - X [ 186ULL ] ) ) / 2.0 * X [ 217ULL ] ) ; t2047 [ 189ULL ] = - ( (
t2848 + t2838 ) * 0.001 ) - - 0.18419157727996954 ; t2047 [ 190ULL ] = - (
t4394 / 7.8539816339744827E-5 * 0.00031622776601683789 + t3611 ) ; t2047 [
191ULL ] = - ( t3304 / 7.8539816339744827E-5 * 0.00031622776601683789 + t3612
) ; t2047 [ 192ULL ] = t2795 ; t2047 [ 193ULL ] = t2796 ; t2815 = X [ 199ULL
] * t2810 ; t2047 [ 194ULL ] = - ( ( ( real_T ) ( M [ 72ULL ] != 0 ) * 2.0 -
1.0 ) * ( t2815 / ( X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * (
t2815 / ( X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * ( t2806 /
7.8539816339744827E-5 ) * ( t2806 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t2864 ) ; t2815 = X [ 203ULL ] * t2810 ; t2047 [
195ULL ] = - ( ( ( real_T ) ( M [ 83ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2815 / (
X [ 204ULL ] == 0.0 ? 1.0E-16 : X [ 204ULL ] ) ) * ( t2815 / ( X [ 204ULL ]
== 0.0 ? 1.0E-16 : X [ 204ULL ] ) ) * ( - X [ 186ULL ] /
7.8539816339744827E-5 ) * ( - X [ 186ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3608 ) ; t2047 [ 196ULL ] = ( X [ 206ULL ] * t2810 /
461.523 - t2846 * X [ 23ULL ] ) / 0.64309276860371423 ; t2047 [ 197ULL ] = X
[ 201ULL ] * t2810 / 461.523 ; t2047 [ 198ULL ] = X [ 205ULL ] * t2842 ;
t2047 [ 199ULL ] = X [ 202ULL ] * t2810 / 4124.48151675695 ; t2047 [ 200ULL ]
= - ( ( ( real_T ) ( M [ 94ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2845 / ( X [ 22ULL
] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) ) * ( t2845 / ( X [ 22ULL ] == 0.0 ?
1.0E-16 : X [ 22ULL ] ) ) * ( t2806 / 7.8539816339744827E-5 ) * ( t2806 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) ; t2047 [
201ULL ] = - t2808 ; t2047 [ 202ULL ] = - t2809 ; t2047 [ 203ULL ] = - ( ( (
real_T ) ( M [ 94ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2845 / ( X [ 22ULL ] == 0.0
? 1.0E-16 : X [ 22ULL ] ) ) * ( t2845 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [
22ULL ] ) ) * ( - X [ 186ULL ] / 7.8539816339744827E-5 ) * ( - X [ 186ULL ] /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) ; t2047 [
204ULL ] = - t2808 ; t2047 [ 205ULL ] = - t2809 ; t2047 [ 206ULL ] = - (
t5708 / 2.0 * t2830 - U_idx_11 / 2.0 * X [ 225ULL ] ) ; t2047 [ 207ULL ] = -
( U_idx_7 / 2.0 * X [ 197ULL ] - t5294 / 2.0 * X [ 221ULL ] ) ; t2047 [
208ULL ] = - ( t5690 / 2.0 * X [ 196ULL ] - U_idx_10 / 2.0 * X [ 222ULL ] ) ;
t2047 [ 209ULL ] = - ( ( - X [ 186ULL ] + t2800 ) / 2.0 * t2867 - ( t2800 - (
- X [ 186ULL ] ) ) / 2.0 * X [ 225ULL ] ) / 365.59674280784293 ; t2047 [
210ULL ] = - ( ( - X [ 186ULL ] + t2799 ) / 2.0 * X [ 182ULL ] - ( t2799 - (
- X [ 186ULL ] ) ) / 2.0 * X [ 221ULL ] ) ; t2047 [ 211ULL ] = - ( ( - X [
186ULL ] + t2798 ) / 2.0 * X [ 181ULL ] - ( t2798 - ( - X [ 186ULL ] ) ) /
2.0 * X [ 222ULL ] ) ; t2047 [ 212ULL ] = t2821 ; t2047 [ 213ULL ] = - (
t2881 - t2887 ) ; t5708 = X [ 223ULL ] * t2883 ; t2047 [ 214ULL ] = - ( ( (
real_T ) ( M [ 148ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / ( X [ 195ULL ] ==
0.0 ? 1.0E-16 : X [ 195ULL ] ) ) * ( t5708 / ( X [ 195ULL ] == 0.0 ? 1.0E-16
: X [ 195ULL ] ) ) * ( X [ 186ULL ] / 0.64 / 7.8539816339744827E-5 ) * ( X [
186ULL ] / 0.64 / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
t3609 ) ; t5708 = X [ 224ULL ] * t2883 ; t2047 [ 215ULL ] = - ( ( ( real_T )
( M [ 159ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / 1.01325 ) * ( t5708 / 1.01325
) * ( X [ 186ULL ] / 0.64 / 7.8539816339744827E-5 ) * ( X [ 186ULL ] / 0.64 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_261 ) /
1.0413512978067061 ; t2047 [ 216ULL ] = - ( ( ( real_T ) ( M [ 170ULL ] != 0
) * 2.0 - 1.0 ) * ( t2928 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 : X [ 220ULL ] )
) * ( t2928 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 : X [ 220ULL ] ) ) * ( X [
186ULL ] / 0.64 / ( t2880 == 0.0 ? 1.0E-16 : t2880 ) ) * ( X [ 186ULL ] /
0.64 / ( t2880 == 0.0 ? 1.0E-16 : t2880 ) ) / 2.0 * 9.999999999999999E-14 +
t2860 ) ; t2047 [ 217ULL ] = - ( ( X [ 244ULL ] + t2938 ) / 2.0 * ( ( (
real_T ) ( M [ 181ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4247 / ( X [ 241ULL ] ==
0.0 ? 1.0E-16 : X [ 241ULL ] ) ) * ( t4247 / ( X [ 241ULL ] == 0.0 ? 1.0E-16
: X [ 241ULL ] ) ) * ( X [ 244ULL ] / 0.32 ) * ( X [ 244ULL ] / 0.32 ) / 2.0
* 9.999999999999999E-14 + t3616 ) - ( t2938 - X [ 244ULL ] ) / 2.0 * X [
253ULL ] ) ; t2047 [ 218ULL ] = - ( ( X [ 244ULL ] + t2937 ) / 2.0 * X [
243ULL ] - ( t2937 - X [ 244ULL ] ) / 2.0 * X [ 257ULL ] ) ; t2047 [ 219ULL ]
= - ( ( X [ 244ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 ) / 2.0 * X [
242ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi17 -
X [ 244ULL ] ) / 2.0 * X [ 256ULL ] ) ; t2047 [ 220ULL ] = - ( ( X [ 247ULL ]
+ intrm_sf_mf_352 ) / 2.0 * t2934 - ( intrm_sf_mf_352 - X [ 247ULL ] ) / 2.0
* X [ 258ULL ] ) ; t2047 [ 221ULL ] = - ( ( X [ 247ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 ) / 2.0 * X [
229ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 -
X [ 247ULL ] ) / 2.0 * X [ 262ULL ] ) ; t2047 [ 222ULL ] = - ( ( X [ 247ULL ]
+ t2940 ) / 2.0 * X [ 228ULL ] - ( t2940 - X [ 247ULL ] ) / 2.0 * X [ 261ULL
] ) ; t2047 [ 223ULL ] = - ( ( ( X [ 32ULL ] - X [ 25ULL ] ) * (
intrm_sf_mf_356 * 10.709248339636167 / 0.01 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi10 ) * 0.001 ) ;
t2047 [ 224ULL ] = - ( t4747 / 0.32 * 0.00031622776601683789 +
intrm_sf_mf_393 ) ; t2047 [ 225ULL ] = - ( t4766 / 0.32 *
0.00031622776601683789 + t3610 ) ; t2047 [ 226ULL ] = t2832 ; t2047 [ 227ULL
] = t2884 ; t5708 = X [ 245ULL ] * t2890 ; t2047 [ 228ULL ] = - ( ( ( real_T
) ( M [ 248ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / ( X [ 246ULL ] == 0.0 ?
1.0E-16 : X [ 246ULL ] ) ) * ( t5708 / ( X [ 246ULL ] == 0.0 ? 1.0E-16 : X [
246ULL ] ) ) * ( X [ 244ULL ] / 0.32 ) * ( X [ 244ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t2761 ) ; t5708 = X [ 248ULL ] * t2890 ; t2047 [
229ULL ] = - ( ( ( real_T ) ( M [ 259ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / (
X [ 249ULL ] == 0.0 ? 1.0E-16 : X [ 249ULL ] ) ) * ( t5708 / ( X [ 249ULL ]
== 0.0 ? 1.0E-16 : X [ 249ULL ] ) ) * ( X [ 247ULL ] / 0.32 ) * ( X [ 247ULL
] / 0.32 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_383 ) ; t2047 [ 230ULL
] = ( X [ 231ULL ] * t2890 / 461.523 - t2916 * X [ 27ULL ] ) /
0.64309276860371423 ; t2047 [ 231ULL ] = X [ 232ULL ] * t2890 / 461.523 ;
t2047 [ 232ULL ] = X [ 233ULL ] * t2914 ; t2047 [ 233ULL ] = X [ 234ULL ] *
t2890 / 4124.48151675695 ; t2047 [ 234ULL ] = 0.0 ; t2047 [ 235ULL ] = - ( (
( real_T ) ( M [ 270ULL ] != 0 ) * 2.0 - 1.0 ) * ( t2968 / ( X [ 31ULL ] ==
0.0 ? 1.0E-16 : X [ 31ULL ] ) ) * ( t2968 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 :
X [ 31ULL ] ) ) * ( X [ 244ULL ] / 0.32 ) * ( X [ 244ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t2948 ) ; t2047 [ 236ULL ] = - intrm_sf_mf_249 ;
t2047 [ 237ULL ] = - t2888 ; t2047 [ 238ULL ] = - ( ( ( real_T ) ( M [ 270ULL
] != 0 ) * 2.0 - 1.0 ) * ( t2968 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL
] ) ) * ( t2968 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) ) * ( X [
247ULL ] / 0.32 ) * ( X [ 247ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 +
t2948 ) ; t2047 [ 239ULL ] = - intrm_sf_mf_249 ; t2047 [ 240ULL ] = - t2888 ;
t2047 [ 241ULL ] = - ( ( - X [ 247ULL ] + intrm_sf_mf_352 ) / 2.0 * t2892 - (
intrm_sf_mf_352 - ( - X [ 247ULL ] ) ) / 2.0 * X [ 270ULL ] ) ; t2047 [
242ULL ] = - ( ( - X [ 247ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 ) / 2.0 * X [
229ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi21 -
( - X [ 247ULL ] ) ) / 2.0 * X [ 272ULL ] ) ; t2047 [ 243ULL ] = - ( ( - X [
247ULL ] + t2940 ) / 2.0 * X [ 228ULL ] - ( t2940 - ( - X [ 247ULL ] ) ) /
2.0 * X [ 271ULL ] ) ; t2047 [ 244ULL ] = - ( ( X [ 198ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 ) / 2.0 *
t2902 - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi79 - X
[ 198ULL ] ) / 2.0 * X [ 273ULL ] ) ; t2047 [ 245ULL ] = - ( ( X [ 198ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 ) / 2.0 * X [
178ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi78 -
X [ 198ULL ] ) / 2.0 * X [ 275ULL ] ) ; t2047 [ 246ULL ] = - ( ( X [ 198ULL ]
+ t2866 ) / 2.0 * X [ 177ULL ] - ( t2866 - X [ 198ULL ] ) / 2.0 * X [ 274ULL
] ) ; t2047 [ 247ULL ] = - ( ( t2997 + t2857 ) * 0.001 ) ; t2047 [ 248ULL ] =
- ( t4803 / 0.32 * 0.00031622776601683789 + t3623 ) ; t2047 [ 249ULL ] = - (
t4237 / 0.32 * 0.00031622776601683789 + intrm_sf_mf_541 ) ; t2047 [ 250ULL ]
= zc_int81 ; t2047 [ 251ULL ] = t2899 ; t5708 = X [ 263ULL ] * t2953 ; t2047
[ 252ULL ] = - ( ( ( real_T ) ( M [ 307ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 /
( X [ 264ULL ] == 0.0 ? 1.0E-16 : X [ 264ULL ] ) ) * ( t5708 / ( X [ 264ULL ]
== 0.0 ? 1.0E-16 : X [ 264ULL ] ) ) * ( - X [ 247ULL ] / 0.32 ) * ( - X [
247ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_517 ) ; t5708 =
X [ 265ULL ] * t2953 ; t2047 [ 253ULL ] = - ( ( ( real_T ) ( M [ 308ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t5708 / ( X [ 266ULL ] == 0.0 ? 1.0E-16 : X [ 266ULL ]
) ) * ( t5708 / ( X [ 266ULL ] == 0.0 ? 1.0E-16 : X [ 266ULL ] ) ) * ( X [
198ULL ] / 0.32 ) * ( X [ 198ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 +
t3617 ) ; t2047 [ 254ULL ] = ( X [ 236ULL ] * t2953 / 461.523 - t2996 * X [
30ULL ] ) / 0.64309276860371423 ; t2047 [ 255ULL ] = X [ 237ULL ] * t2953 /
461.523 ; t2047 [ 256ULL ] = X [ 238ULL ] * t2995 ; t2047 [ 257ULL ] = X [
239ULL ] * t2953 / 4124.48151675695 ; t2047 [ 258ULL ] = 0.0 ; t2047 [ 259ULL
] = - ( ( ( real_T ) ( M [ 309ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3062 / ( X [
33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) ) * ( t3062 / ( X [ 33ULL ] == 0.0 ?
1.0E-16 : X [ 33ULL ] ) ) * ( - X [ 247ULL ] / 0.32 ) * ( - X [ 247ULL ] /
0.32 ) / 2.0 * 9.999999999999999E-14 + t2999 ) ; t2047 [ 260ULL ] = - t2911 ;
t2047 [ 261ULL ] = - t2951 ; t2047 [ 262ULL ] = - ( ( ( real_T ) ( M [ 309ULL
] != 0 ) * 2.0 - 1.0 ) * ( t3062 / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL
] ) ) * ( t3062 / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) ) * ( X [
198ULL ] / 0.32 ) * ( X [ 198ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 +
t2999 ) ; t2047 [ 263ULL ] = - t2911 ; t2047 [ 264ULL ] = - t2951 ; t2047 [
265ULL ] = U_idx_5 * t2812 ; t2047 [ 266ULL ] = - ( ( X [ 288ULL ] + t3007 )
/ 2.0 * ( ( ( real_T ) ( M [ 37ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4240 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t4240 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( X [ 288ULL ] / 0.0019634954084936209 ) * ( X [
288ULL ] / 0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t4726 ) -
( t3007 - X [ 288ULL ] ) / 2.0 * X [ 294ULL ] ) ; t2047 [ 267ULL ] = - ( ( X
[ 288ULL ] + t2931 ) / 2.0 * X [ 280ULL ] - ( t2931 - X [ 288ULL ] ) / 2.0 *
X [ 298ULL ] ) ; t2047 [ 268ULL ] = - ( ( X [ 288ULL ] + t2656 ) / 2.0 * X [
279ULL ] - ( t2656 - X [ 288ULL ] ) / 2.0 * X [ 297ULL ] ) ; t2047 [ 269ULL ]
= - ( ( - X [ 244ULL ] + t3031 ) / 2.0 * ( ( ( real_T ) ( M [ 181ULL ] != 0 )
* 2.0 - 1.0 ) * ( t4247 / ( X [ 241ULL ] == 0.0 ? 1.0E-16 : X [ 241ULL ] ) )
* ( t4247 / ( X [ 241ULL ] == 0.0 ? 1.0E-16 : X [ 241ULL ] ) ) * ( - X [
244ULL ] / 0.0019634954084936209 ) * ( - X [ 244ULL ] / 0.0019634954084936209
) / 2.0 * 9.999999999999999E-14 + t3616 ) - ( t3031 - ( - X [ 244ULL ] ) ) /
2.0 * X [ 299ULL ] ) ; t2047 [ 270ULL ] = - ( ( - X [ 244ULL ] + t3022 ) /
2.0 * X [ 243ULL ] - ( t3022 - ( - X [ 244ULL ] ) ) / 2.0 * X [ 301ULL ] ) ;
t2047 [ 271ULL ] = - ( ( - X [ 244ULL ] + t3008 ) / 2.0 * X [ 242ULL ] - (
t3008 - ( - X [ 244ULL ] ) ) / 2.0 * X [ 300ULL ] ) ; t2047 [ 272ULL ] = - (
( t3027 + t2921 ) * 0.001 ) / 1.8850371198102225E-5 ; t2047 [ 273ULL ] = - (
t2920 / 0.0019634954084936209 * 0.00031622776601683789 + t3620 ) ; t2047 [
274ULL ] = - ( t4284 / 0.0019634954084936209 * 0.00031622776601683789 + t3626
) ; t2047 [ 275ULL ] = zc_int113 ; t2047 [ 276ULL ] = t2900 ; t5708 = X [
289ULL ] * t3003 ; t2047 [ 277ULL ] = - ( ( ( real_T ) ( M [ 317ULL ] != 0 )
* 2.0 - 1.0 ) * ( t5708 / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X [ 290ULL ] ) )
* ( t5708 / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X [ 290ULL ] ) ) * ( X [ 288ULL
] / 0.0019634954084936209 ) * ( X [ 288ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 + t3600 ) ; t5708 = X [ 291ULL ] * t3003 ; t2047 [
278ULL ] = - ( ( ( real_T ) ( M [ 318ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / (
X [ 292ULL ] == 0.0 ? 1.0E-16 : X [ 292ULL ] ) ) * ( t5708 / ( X [ 292ULL ]
== 0.0 ? 1.0E-16 : X [ 292ULL ] ) ) * ( - X [ 244ULL ] /
0.0019634954084936209 ) * ( - X [ 244ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3618 ) ; t2047 [ 279ULL ] = ( X [ 283ULL ] * t3003 /
461.523 - t3026 * X [ 36ULL ] ) / 0.64309276860371423 ; t2047 [ 280ULL ] = X
[ 285ULL ] * t3003 / 461.523 ; t2047 [ 281ULL ] = X [ 282ULL ] * t3025 ;
t2047 [ 282ULL ] = X [ 284ULL ] * t3003 / 4124.48151675695 ; t2047 [ 283ULL ]
= 0.0 ; t2047 [ 284ULL ] = - ( ( ( real_T ) ( M [ 319ULL ] != 0 ) * 2.0 - 1.0
) * ( t3152 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) ) * ( t3152 / (
X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) ) * ( X [ 288ULL ] /
0.0019634954084936209 ) * ( X [ 288ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + intrm_sf_mf_661 ) ; t2047 [ 285ULL ] = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ; t2047 [
286ULL ] = - t3002 ; t2047 [ 287ULL ] = - ( ( ( real_T ) ( M [ 319ULL ] != 0
) * 2.0 - 1.0 ) * ( t3152 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) )
* ( t3152 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) ) * ( - X [ 244ULL
] / 0.0019634954084936209 ) * ( - X [ 244ULL ] / 0.0019634954084936209 ) /
2.0 * 9.999999999999999E-14 + intrm_sf_mf_661 ) ; t2047 [ 288ULL ] = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi88 ; t2047 [
289ULL ] = - t3002 ; t5708 = X [ 313ULL ] + t3042 ; U_idx_11 = t3042 - X [
313ULL ] ; t2047 [ 290ULL ] = - ( t5708 / 2.0 * t2820 - U_idx_11 / 2.0 * X [
312ULL ] ) / 365.59674280784293 ; U_idx_7 = X [ 313ULL ] + t3041 ; t5294 =
t3041 - X [ 313ULL ] ; t2047 [ 291ULL ] = - ( U_idx_7 / 2.0 * X [ 309ULL ] -
t5294 / 2.0 * X [ 317ULL ] ) ; t5690 = X [ 313ULL ] + t3021 ; U_idx_10 =
t3021 - X [ 313ULL ] ; t2047 [ 292ULL ] = - ( t5690 / 2.0 * X [ 308ULL ] -
U_idx_10 / 2.0 * X [ 316ULL ] ) ; t2815 = 148.401051922146 ; t2047 [ 293ULL ]
= t2815 / 461.523 / 43.3158175294914 + t3232 * 0.5 / 461.523 /
43.3158175294914 ; t2047 [ 294ULL ] = X [ 320ULL ] * t3045 / 461.523 ; t2047
[ 295ULL ] = X [ 310ULL ] * t3046 ; t5007 = 62.328441807301317 ; t2047 [
296ULL ] = t5007 / 259.836612622973 + t3232 * 0.21 / 259.836612622973 ; t5267
= t3045 * 293.15 ; t2047 [ 297ULL ] = - 304.06022922571 - ( ( ( real_T ) ( M
[ 321ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5267 / 1.01325 ) * ( t5267 / 1.01325 ) *
( X [ 313ULL ] / 0.0019634954084936209 ) * ( X [ 313ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3233 ) ; t2047 [
298ULL ] = - t3043 ; t2047 [ 299ULL ] = - t3044 ; t2047 [ 300ULL ] = - ( ( X
[ 325ULL ] + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19
) / 2.0 * zc_int147 - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M19 - X [ 325ULL
] ) / 2.0 * X [ 335ULL ] ) ; t2047 [ 301ULL ] = - ( ( X [ 325ULL ] + t3097 )
/ 2.0 * X [ 305ULL ] - ( t3097 - X [ 325ULL ] ) / 2.0 * X [ 339ULL ] ) ;
t2047 [ 302ULL ] = - ( ( X [ 325ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17 ) / 2.0 * X [
304ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M17
- X [ 325ULL ] ) / 2.0 * X [ 338ULL ] ) ; t2047 [ 303ULL ] = - ( ( - X [
313ULL ] + t3105 ) / 2.0 * t2989 - ( t3105 - ( - X [ 313ULL ] ) ) / 2.0 * X [
340ULL ] ) ; t2047 [ 304ULL ] = - ( ( - X [ 313ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21 ) / 2.0 * X [
324ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M21
- ( - X [ 313ULL ] ) ) / 2.0 * X [ 342ULL ] ) ; t2047 [ 305ULL ] = - ( ( - X
[ 313ULL ] + t3103 ) / 2.0 * X [ 323ULL ] - ( t3103 - ( - X [ 313ULL ] ) ) /
2.0 * X [ 341ULL ] ) ; t2047 [ 306ULL ] = - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M10 + t3088 ) *
0.001 ) - - 0.92095788639984788 ; t2047 [ 307ULL ] = - ( t4298 /
0.0019634954084936209 * 0.00031622776601683789 + t3627 ) ; t2047 [ 308ULL ] =
- ( t4332 / 0.0019634954084936209 * 0.00031622776601683789 + intrm_sf_mf_826
) ; t2047 [ 309ULL ] = t2905 ; t2047 [ 310ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi3 ; t5267 = X [
326ULL ] * t3054 ; t2047 [ 311ULL ] = - ( ( ( real_T ) ( M [ 329ULL ] != 0 )
* 2.0 - 1.0 ) * ( t5267 / ( X [ 327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) )
* ( t5267 / ( X [ 327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) ) * ( X [ 325ULL
] / 0.0019634954084936209 ) * ( X [ 325ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 + t2774 ) ; t5267 = X [ 330ULL ] * t3054 ; t2047 [
312ULL ] = - ( ( ( real_T ) ( M [ 330ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5267 / (
X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] ) ) * ( t5267 / ( X [ 331ULL ]
== 0.0 ? 1.0E-16 : X [ 331ULL ] ) ) * ( - X [ 313ULL ] /
0.0019634954084936209 ) * ( - X [ 313ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3098 ) ; t2047 [ 313ULL ] = ( X [ 333ULL ] * t3054 /
461.523 - t3091 * X [ 41ULL ] ) / 0.64309276860371423 ; t2047 [ 314ULL ] = X
[ 328ULL ] * t3054 / 461.523 ; t2047 [ 315ULL ] = X [ 332ULL ] * t3090 ;
t2047 [ 316ULL ] = X [ 329ULL ] * t3054 / 259.836612622973 /
1.1422643670118826 ; t2047 [ 317ULL ] = - ( ( ( real_T ) ( M [ 331ULL ] != 0
) * 2.0 - 1.0 ) * ( t3245 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) )
* ( t3245 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) ) * ( X [ 325ULL ]
/ 0.0019634954084936209 ) * ( X [ 325ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3112 ) ; t2047 [ 318ULL ] = - t3049 ; t2047 [ 319ULL
] = - t3050 ; t2047 [ 320ULL ] = - ( ( ( real_T ) ( M [ 331ULL ] != 0 ) * 2.0
- 1.0 ) * ( t3245 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) ) * (
t3245 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) ) * ( - X [ 313ULL ] /
0.0019634954084936209 ) * ( - X [ 313ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + t3112 ) ; t2047 [ 321ULL ] = - t3049 ; t2047 [ 322ULL
] = - t3050 ; t2047 [ 323ULL ] = - ( t5708 / 2.0 * zc_int182 - U_idx_11 / 2.0
* X [ 349ULL ] ) ; t2047 [ 324ULL ] = - ( U_idx_7 / 2.0 * X [ 324ULL ] -
t5294 / 2.0 * X [ 345ULL ] ) ; t2047 [ 325ULL ] = - ( t5690 / 2.0 * X [
323ULL ] - U_idx_10 / 2.0 * X [ 346ULL ] ) ; t2047 [ 326ULL ] = - ( ( - X [
313ULL ] + t3042 ) / 2.0 * t2743 - ( t3042 - ( - X [ 313ULL ] ) ) / 2.0 * X [
349ULL ] ) / 365.59674280784293 ; t2047 [ 327ULL ] = - ( ( - X [ 313ULL ] +
t3041 ) / 2.0 * X [ 309ULL ] - ( t3041 - ( - X [ 313ULL ] ) ) / 2.0 * X [
345ULL ] ) ; t2047 [ 328ULL ] = - ( ( - X [ 313ULL ] + t3021 ) / 2.0 * X [
308ULL ] - ( t3021 - ( - X [ 313ULL ] ) ) / 2.0 * X [ 346ULL ] ) ; t2047 [
329ULL ] = t2972 ; t2047 [ 330ULL ] = - ( intrm_sf_mf_866 - t3123 ) ; t5708 =
X [ 347ULL ] * t3119 ; t2047 [ 331ULL ] = - ( ( ( real_T ) ( M [ 335ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t5708 / ( t3047 == 0.0 ? 1.0E-16 : t3047 ) ) * ( t5708
/ ( t3047 == 0.0 ? 1.0E-16 : t3047 ) ) * ( X [ 313ULL ] / 0.64 /
0.0019634954084936209 ) * ( X [ 313ULL ] / 0.64 / 0.0019634954084936209 ) /
2.0 * 9.999999999999999E-14 + t3100 ) ; t5708 = X [ 348ULL ] * t3119 ; t2047
[ 332ULL ] = - ( ( ( real_T ) ( M [ 336ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 /
1.01325 ) * ( t5708 / 1.01325 ) * ( X [ 313ULL ] / 0.64 /
0.0019634954084936209 ) * ( X [ 313ULL ] / 0.64 / 0.0019634954084936209 ) /
2.0 * 9.999999999999999E-14 + intrm_sf_mf_821 ) / 1.0413512978067061 ; t2047
[ 333ULL ] = - ( ( ( real_T ) ( M [ 337ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3328 /
( X [ 344ULL ] == 0.0 ? 1.0E-16 : X [ 344ULL ] ) ) * ( t3328 / ( X [ 344ULL ]
== 0.0 ? 1.0E-16 : X [ 344ULL ] ) ) * ( X [ 313ULL ] / 0.64 / ( t3087 == 0.0
? 1.0E-16 : t3087 ) ) * ( X [ 313ULL ] / 0.64 / ( t3087 == 0.0 ? 1.0E-16 :
t3087 ) ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_863 ) ; t2047 [ 334ULL
] = - ( ( X [ 368ULL ] + t3183 ) / 2.0 * zc_int192 - ( t3183 - X [ 368ULL ] )
/ 2.0 * X [ 377ULL ] ) ; t2047 [ 335ULL ] = - ( ( X [ 368ULL ] + t3182 ) /
2.0 * X [ 367ULL ] - ( t3182 - X [ 368ULL ] ) / 2.0 * X [ 381ULL ] ) ; t2047
[ 336ULL ] = - ( ( X [ 368ULL ] + t3174 ) / 2.0 * X [ 366ULL ] - ( t3174 - X
[ 368ULL ] ) / 2.0 * X [ 380ULL ] ) ; t2047 [ 337ULL ] = - ( ( X [ 371ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 ) / 2.0 *
t3012 - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 - X
[ 371ULL ] ) / 2.0 * X [ 382ULL ] ) ; t2047 [ 338ULL ] = - ( ( X [ 371ULL ] +
t3186 ) / 2.0 * X [ 353ULL ] - ( t3186 - X [ 371ULL ] ) / 2.0 * X [ 386ULL ]
) ; t2047 [ 339ULL ] = - ( ( X [ 371ULL ] + t3185 ) / 2.0 * X [ 352ULL ] - (
t3185 - X [ 371ULL ] ) / 2.0 * X [ 385ULL ] ) ; t2047 [ 340ULL ] = - ( ( ( X
[ 32ULL ] - X [ 43ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_11 *
10.709248339636167 / 0.01 ) + t3177 ) * 0.001 ) ; t2047 [ 341ULL ] = - (
t4289 / 0.32 * 0.00031622776601683789 + t3633 ) ; t2047 [ 342ULL ] = - (
t4396 / 0.32 * 0.00031622776601683789 + t3584 ) ; t2047 [ 343ULL ] = t2980 ;
t2047 [ 344ULL ] = zc_int132 ; t5708 = X [ 369ULL ] * intrm_sf_mf_869 ; t2047
[ 345ULL ] = - ( ( ( real_T ) ( M [ 345ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 /
( X [ 370ULL ] == 0.0 ? 1.0E-16 : X [ 370ULL ] ) ) * ( t5708 / ( X [ 370ULL ]
== 0.0 ? 1.0E-16 : X [ 370ULL ] ) ) * ( X [ 368ULL ] / 0.32 ) * ( X [ 368ULL
] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t3118 ) ; t5708 = X [ 372ULL ] *
intrm_sf_mf_869 ; t2047 [ 346ULL ] = - ( ( ( real_T ) ( M [ 346ULL ] != 0 ) *
2.0 - 1.0 ) * ( t5708 / ( X [ 373ULL ] == 0.0 ? 1.0E-16 : X [ 373ULL ] ) ) *
( t5708 / ( X [ 373ULL ] == 0.0 ? 1.0E-16 : X [ 373ULL ] ) ) * ( X [ 371ULL ]
/ 0.32 ) * ( X [ 371ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t3125 ) ;
t2047 [ 347ULL ] = ( X [ 355ULL ] * intrm_sf_mf_869 / 461.523 - t3164 * X [
45ULL ] ) / 0.64309276860371423 ; t2047 [ 348ULL ] = X [ 356ULL ] *
intrm_sf_mf_869 / 461.523 ; t2047 [ 349ULL ] = X [ 357ULL ] * t3159 ; t2047 [
350ULL ] = X [ 358ULL ] * intrm_sf_mf_869 / 259.836612622973 /
1.1422643670118826 ; t2047 [ 351ULL ] = 0.0 ; t2047 [ 352ULL ] = - ( ( (
real_T ) ( M [ 347ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3367 / ( X [ 49ULL ] == 0.0
? 1.0E-16 : X [ 49ULL ] ) ) * ( t3367 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [
49ULL ] ) ) * ( X [ 368ULL ] / 0.32 ) * ( X [ 368ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t3193 ) ; t2047 [ 353ULL ] = - intrm_sf_mf_867 ;
t2047 [ 354ULL ] = - t3124 ; t2047 [ 355ULL ] = - ( ( ( real_T ) ( M [ 347ULL
] != 0 ) * 2.0 - 1.0 ) * ( t3367 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL
] ) ) * ( t3367 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) ) * ( X [
371ULL ] / 0.32 ) * ( X [ 371ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 +
t3193 ) ; t2047 [ 356ULL ] = - intrm_sf_mf_867 ; t2047 [ 357ULL ] = - t3124 ;
t2047 [ 358ULL ] = - ( ( - X [ 371ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22 ) / 2.0 *
zc_int220 - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_22
- ( - X [ 371ULL ] ) ) / 2.0 * X [ 395ULL ] ) ; t2047 [ 359ULL ] = - ( ( - X
[ 371ULL ] + t3186 ) / 2.0 * X [ 353ULL ] - ( t3186 - ( - X [ 371ULL ] ) ) /
2.0 * X [ 397ULL ] ) ; t2047 [ 360ULL ] = - ( ( - X [ 371ULL ] + t3185 ) /
2.0 * X [ 352ULL ] - ( t3185 - ( - X [ 371ULL ] ) ) / 2.0 * X [ 396ULL ] ) ;
t2047 [ 361ULL ] = - ( ( - X [ 325ULL ] + t3181 ) / 2.0 * t3004 - ( t3181 - (
- X [ 325ULL ] ) ) / 2.0 * X [ 398ULL ] ) ; t2047 [ 362ULL ] = - ( ( - X [
325ULL ] + t3132 ) / 2.0 * X [ 305ULL ] - ( t3132 - ( - X [ 325ULL ] ) ) /
2.0 * X [ 400ULL ] ) ; t2047 [ 363ULL ] = - ( ( - X [ 325ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 ) / 2.0 * X [
304ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_77 -
( - X [ 325ULL ] ) ) / 2.0 * X [ 399ULL ] ) ; t2047 [ 364ULL ] = - ( ( t3223
+ t3096 ) * 0.001 ) ; t2047 [ 365ULL ] = - ( t4426 / 0.32 *
0.00031622776601683789 + t3583 ) ; t2047 [ 366ULL ] = - ( t4440 / 0.32 *
0.00031622776601683789 + t3585 ) ; t2047 [ 367ULL ] = t213 ; t2047 [ 368ULL ]
= t2987 ; t5708 = X [ 387ULL ] * t3197 ; t2047 [ 369ULL ] = - ( ( ( real_T )
( M [ 352ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / ( X [ 388ULL ] == 0.0 ?
1.0E-16 : X [ 388ULL ] ) ) * ( t5708 / ( X [ 388ULL ] == 0.0 ? 1.0E-16 : X [
388ULL ] ) ) * ( - X [ 371ULL ] / 0.32 ) * ( - X [ 371ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t3093 ) ; t5708 = X [ 389ULL ] * t3197 ; t2047 [
370ULL ] = - ( ( ( real_T ) ( M [ 353ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / (
X [ 390ULL ] == 0.0 ? 1.0E-16 : X [ 390ULL ] ) ) * ( t5708 / ( X [ 390ULL ]
== 0.0 ? 1.0E-16 : X [ 390ULL ] ) ) * ( - X [ 325ULL ] / 0.32 ) * ( - X [
325ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + intrm_sf_mf_1119 ) ; t2047
[ 371ULL ] = ( X [ 360ULL ] * t3197 / 461.523 - t3222 * X [ 48ULL ] ) /
0.64309276860371423 ; t2047 [ 372ULL ] = X [ 361ULL ] * t3197 / 461.523 ;
t2047 [ 373ULL ] = X [ 362ULL ] * t3221 ; t2047 [ 374ULL ] = X [ 363ULL ] *
t3197 / 259.836612622973 / 1.1422643670118826 ; t2047 [ 375ULL ] = 0.0 ;
t2047 [ 376ULL ] = - ( ( ( real_T ) ( M [ 354ULL ] != 0 ) * 2.0 - 1.0 ) * (
t3461 / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) ) * ( t3461 / ( X [
50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) ) * ( - X [ 371ULL ] / 0.32 ) * ( -
X [ 371ULL ] / 0.32 ) / 2.0 * 9.999999999999999E-14 + t3225 ) ; t2047 [
377ULL ] = - t3155 ; t2047 [ 378ULL ] = - t3196 ; t2047 [ 379ULL ] = - ( ( (
real_T ) ( M [ 354ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3461 / ( X [ 50ULL ] == 0.0
? 1.0E-16 : X [ 50ULL ] ) ) * ( t3461 / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [
50ULL ] ) ) * ( - X [ 325ULL ] / 0.32 ) * ( - X [ 325ULL ] / 0.32 ) / 2.0 *
9.999999999999999E-14 + t3225 ) ; t2047 [ 380ULL ] = - t3155 ; t2047 [ 381ULL
] = - t3196 ; t2047 [ 382ULL ] = U_idx_8 * t2813 ; t2047 [ 383ULL ] = - ( ( X
[ 413ULL ] + t2711 ) / 2.0 * ( ( ( real_T ) ( M [ 34ULL ] != 0 ) * 2.0 - 1.0
) * ( t4363 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( t4363 / (
X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( X [ 413ULL ] /
0.0019634954084936209 ) * ( X [ 413ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + intrm_sf_mf_11 ) - ( t2711 - X [ 413ULL ] ) / 2.0 * X
[ 419ULL ] ) ; t2047 [ 384ULL ] = - ( ( X [ 413ULL ] + t3179 ) / 2.0 * X [
405ULL ] - ( t3179 - X [ 413ULL ] ) / 2.0 * X [ 423ULL ] ) ; t2047 [ 385ULL ]
= - ( ( X [ 413ULL ] + t2680 ) / 2.0 * X [ 404ULL ] - ( t2680 - X [ 413ULL ]
) / 2.0 * X [ 422ULL ] ) ; t2047 [ 386ULL ] = - ( ( - X [ 368ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 ) / 2.0 *
t3055 - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip20 - (
- X [ 368ULL ] ) ) / 2.0 * X [ 424ULL ] ) ; t2047 [ 387ULL ] = - ( ( - X [
368ULL ] + t3266 ) / 2.0 * X [ 367ULL ] - ( t3266 - ( - X [ 368ULL ] ) ) /
2.0 * X [ 426ULL ] ) ; t2047 [ 388ULL ] = - ( ( - X [ 368ULL ] +
intrm_sf_mf_1220 ) / 2.0 * X [ 366ULL ] - ( intrm_sf_mf_1220 - ( - X [ 368ULL
] ) ) / 2.0 * X [ 425ULL ] ) ; t2047 [ 389ULL ] = - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip8 +
intrm_sf_mf_1229 ) * 0.001 ) / 1.8850371198102225E-5 ; t2047 [ 390ULL ] = - (
t4473 / 0.0019634954084936209 * 0.00031622776601683789 + intrm_sf_mf_1267 ) ;
t2047 [ 391ULL ] = - ( t4487 / 0.0019634954084936209 * 0.00031622776601683789
+ t3587 ) ; t2047 [ 392ULL ] = t2823 ; t2047 [ 393ULL ] = zc_int181 ; t5708 =
X [ 414ULL ] * t3229 ; t2047 [ 394ULL ] = - ( ( ( real_T ) ( M [ 3ULL ] != 0
) * 2.0 - 1.0 ) * ( t5708 / ( X [ 415ULL ] == 0.0 ? 1.0E-16 : X [ 415ULL ] )
) * ( t5708 / ( X [ 415ULL ] == 0.0 ? 1.0E-16 : X [ 415ULL ] ) ) * ( X [
413ULL ] / 0.0019634954084936209 ) * ( X [ 413ULL ] / 0.0019634954084936209 )
/ 2.0 * 9.999999999999999E-14 + intrm_sf_mf_1254 ) ; t5708 = X [ 416ULL ] *
t3229 ; t2047 [ 395ULL ] = - ( ( ( real_T ) ( M [ 4ULL ] != 0 ) * 2.0 - 1.0 )
* ( t5708 / ( X [ 417ULL ] == 0.0 ? 1.0E-16 : X [ 417ULL ] ) ) * ( t5708 / (
X [ 417ULL ] == 0.0 ? 1.0E-16 : X [ 417ULL ] ) ) * ( - X [ 368ULL ] /
0.0019634954084936209 ) * ( - X [ 368ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + intrm_sf_mf_1257 ) ; t2047 [ 396ULL ] = ( X [ 408ULL
] * t3229 / 461.523 - t3270 * X [ 53ULL ] ) / 0.64309276860371423 ; t2047 [
397ULL ] = X [ 410ULL ] * t3229 / 461.523 ; t2047 [ 398ULL ] = X [ 407ULL ] *
t3269 ; t2047 [ 399ULL ] = X [ 409ULL ] * t3229 / 259.836612622973 /
1.1422643670118826 ; t2047 [ 400ULL ] = 0.0 ; t2047 [ 401ULL ] = - ( ( (
real_T ) ( M [ 5ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3551 / ( X [ 54ULL ] == 0.0 ?
1.0E-16 : X [ 54ULL ] ) ) * ( t3551 / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [
54ULL ] ) ) * ( X [ 413ULL ] / 0.0019634954084936209 ) * ( X [ 413ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3281 ) ; t2047 [
402ULL ] = - t3217 ; t2047 [ 403ULL ] = - t3228 ; t2047 [ 404ULL ] = - ( ( (
real_T ) ( M [ 5ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3551 / ( X [ 54ULL ] == 0.0 ?
1.0E-16 : X [ 54ULL ] ) ) * ( t3551 / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [
54ULL ] ) ) * ( - X [ 368ULL ] / 0.0019634954084936209 ) * ( - X [ 368ULL ] /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 + t3281 ) ; t2047 [
405ULL ] = - t3217 ; t2047 [ 406ULL ] = - t3228 ; t2047 [ 407ULL ] = 293.15 ;
t2047 [ 408ULL ] = ( ( - X [ 430ULL ] - X [ 431ULL ] ) / ( t3285 == 0.0 ?
1.0E-16 : t3285 ) - ( ( t3284 * t3288 - t3286 * X [ 435ULL ] ) + t3287 *
100.0 ) ) / 1.233284047215034E+6 ; t2047 [ 409ULL ] = ( t3511 - ( t3284 *
t3288 + t3286 * X [ 435ULL ] ) ) / 171803.29647667333 ; t2047 [ 410ULL ] = -
t3290 / 4.1888 ; t2047 [ 411ULL ] = t3292 * t3289 / 99.820599640000012 ;
t2047 [ 412ULL ] = ( X [ 440ULL ] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) - ( (
t3297 * t3298 - t3295 * X [ 443ULL ] ) + t3296 * 100.0 ) ) /
8.80132724281134E+6 ; t2047 [ 413ULL ] = ( t3531 - ( t3297 * t3298 + t3295 *
X [ 443ULL ] ) ) / 1.2260736179143097E+6 ; t2047 [ 414ULL ] = ( - X [ 440ULL
] / ( t3294 == 0.0 ? 1.0E-16 : t3294 ) - ( ( t3302 * t3303 - X [ 443ULL ] *
t3299 ) + t3300 * 100.0 ) ) / 8.80132724281134E+6 ; t2047 [ 415ULL ] = (
intrm_sf_mf_1104 - ( t3302 * t3303 + X [ 443ULL ] * t3299 ) ) /
1.2260736179143097E+6 ; t2047 [ 416ULL ] = - ( pmf_sqrt ( X [ 442ULL ] * X [
442ULL ] + 1.0E-8 ) * X [ 442ULL ] * 0.99999999999999978 ) ; t2047 [ 417ULL ]
= ( X [ 440ULL ] / ( t3312 == 0.0 ? 1.0E-16 : t3312 ) - ( ( t3303 * t3316 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce10 * X [ 447ULL
] ) + t3314 * 100.0 ) ) / 4.3603175645747058E+7 ; t2047 [ 418ULL ] = ( t4767
- ( t3303 * t3316 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce10 * X [ 447ULL
] ) ) / 6.0741637984429337E+6 ; t2047 [ 419ULL ] = ( X [ 430ULL ] / ( t3317
== 0.0 ? 1.0E-16 : t3317 ) - ( ( t3288 * t3320 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce15 * X [ 449ULL
] ) + t3319 * 100.0 ) ) / 4.3603175645747058E+7 ; t2047 [ 420ULL ] = ( t4768
- ( t3288 * t3320 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce15 * X [ 449ULL
] ) ) / 6.0741637984429337E+6 ; t2047 [ 421ULL ] = - ( t3308 * 0.001 + t3305
) ; t2047 [ 422ULL ] = - t3322 / 4.1887953489795917 ; t2047 [ 423ULL ] = -
t3322 / 4.1887953489795917 ; t2047 [ 424ULL ] = - intrm_sf_mf_1314 ; t2047 [
425ULL ] = - t3307 + 1.01325 ; t2047 [ 426ULL ] = ( X [ 431ULL ] / ( t3336 ==
0.0 ? 1.0E-16 : t3336 ) - ( ( t3288 * t3340 - t3339 * X [ 454ULL ] ) + t3338
* 100.0 ) ) / 8.80132724281134E+6 ; t2047 [ 427ULL ] = ( t3848 - ( t3288 *
t3340 + t3339 * X [ 454ULL ] ) ) / 1.2260736179143097E+6 ; t2047 [ 428ULL ] =
( X [ 452ULL ] / ( t3336 == 0.0 ? 1.0E-16 : t3336 ) - ( ( t3344 * t3345 - X [
454ULL ] * t3343 ) + t3342 * 100.0 ) ) / 8.80132724281134E+6 ; t2047 [ 429ULL
] = ( t3851 - ( t3344 * t3345 + X [ 454ULL ] * t3343 ) ) /
1.2260736179143097E+6 ; t2047 [ 430ULL ] = t3335 * 100.0 ; t2047 [ 431ULL ] =
( - X [ 452ULL ] / ( t3355 == 0.0 ? 1.0E-16 : t3355 ) - ( ( t3345 * t3362 -
t3359 * X [ 457ULL ] ) + t3360 * 100.0 ) ) / 6.3686514346761458E+7 ; t2047 [
432ULL ] = ( t3496 - ( t3345 * t3362 + t3359 * X [ 457ULL ] ) ) /
8.87188408103589E+6 ; t2047 [ 433ULL ] = ( - X [ 440ULL ] / ( t3364 == 0.0 ?
1.0E-16 : t3364 ) - ( ( t3298 * t3371 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato15 * X [ 459ULL
] ) + t3370 * 100.0 ) ) / 6.3686514346761458E+7 ; t2047 [ 434ULL ] = ( t3499
- ( t3298 * t3371 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato15 * X [ 459ULL
] ) ) / 8.87188408103589E+6 ; t2047 [ 435ULL ] = - ( t3348 * 0.001 +
intrm_sf_mf_1350 ) ; t2047 [ 436ULL ] = - t3374 / 4.1887953489795917 ; t2047
[ 437ULL ] = - t3374 / 4.1887953489795917 ; t2047 [ 438ULL ] = -
intrm_sf_mf_1359 ; t2047 [ 439ULL ] = - t3311 ; t2047 [ 440ULL ] = X [ 460ULL
] * t3601 * 1.0E-6 ; t2047 [ 441ULL ] = X [ 465ULL ] * t3066 /
2500.99462758899 ; t2047 [ 442ULL ] = X [ 276ULL ] * t3079 / 3575.42283463482
; t2047 [ 443ULL ] = X [ 401ULL ] * t3083 / 248.058058319568 ; t2047 [ 444ULL
] = X [ 277ULL ] * t3095 / 2500.99462758899 ; t2047 [ 445ULL ] = t3393 *
zc_int305 / 2500.99462758899 ; t2047 [ 446ULL ] = - 0.20883314131306652 + - (
t3248 * 400.0 ) / 2353.8245806357045 ; t2047 [ 447ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 *
241812.2160511087 / 0.0020158806832745466 * 0.001 - t3395 * 0.001 ) /
3931.85243448965 ; t2047 [ 448ULL ] = ( t2638 * 0.20177105219743391 - t3392 )
/ 0.25205662255327149 ; t2047 [ 449ULL ] = ( t2646 * 0.20177105219743391 - (
t3394 + t3392 ) ) / 0.25205662255327149 ; t2047 [ 450ULL ] = t3392 ; t2047 [
451ULL ] = - t3392 ; t2047 [ 452ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra5 ; t2047 [
453ULL ] = t3391 ; t2047 [ 454ULL ] = - t3394 ; t5708 = X [ 478ULL ] + t3407
; U_idx_3 = t3407 - X [ 478ULL ] ; t2047 [ 455ULL ] = - ( t5708 / 2.0 * t3102
- U_idx_3 / 2.0 * X [ 477ULL ] ) ; U_idx_11 = X [ 478ULL ] + t3406 ; U_idx_7
= t3406 - X [ 478ULL ] ; t2047 [ 456ULL ] = - ( U_idx_11 / 2.0 * X [ 471ULL ]
- U_idx_7 / 2.0 * X [ 482ULL ] ) ; U_idx_1 = X [ 478ULL ] + t194 ; t5294 =
t194 - X [ 478ULL ] ; t2047 [ 457ULL ] = - ( U_idx_1 / 2.0 * X [ 470ULL ] -
t5294 / 2.0 * X [ 481ULL ] ) ; t2047 [ 458ULL ] = ( X [ 473ULL ] * t3401 /
461.523 - t3405 * X [ 66ULL ] ) / 0.64309276860371423 ; t2047 [ 459ULL ] = X
[ 475ULL ] * t3401 / 461.523 ; t2047 [ 460ULL ] = X [ 472ULL ] * t3403 ;
t2047 [ 461ULL ] = X [ 474ULL ] * t3401 / 4124.48151675695 ; t2047 [ 462ULL ]
= - ( ( ( real_T ) ( M [ 9ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3721 / ( X [ 64ULL
] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ) * ( t3721 / ( X [ 64ULL ] == 0.0 ?
1.0E-16 : X [ 64ULL ] ) ) * ( X [ 478ULL ] / 7.8539816339744827E-5 ) * ( X [
478ULL ] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t3414 ) ;
t2047 [ 463ULL ] = - t3399 ; t2047 [ 464ULL ] = - t3400 ; t2047 [ 465ULL ] =
- ( ( - X [ 478ULL ] + t3453 ) / 2.0 * zc_int307 - ( t3453 - ( - X [ 478ULL ]
) ) / 2.0 * X [ 498ULL ] ) ; t2047 [ 466ULL ] = - ( ( - X [ 478ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17 ) / 2.0 * X [
487ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M17
- ( - X [ 478ULL ] ) ) / 2.0 * X [ 500ULL ] ) ; t2047 [ 467ULL ] = - ( ( - X
[ 478ULL ] + t2717 ) / 2.0 * X [ 486ULL ] - ( t2717 - ( - X [ 478ULL ] ) ) /
2.0 * X [ 499ULL ] ) ; t2047 [ 468ULL ] = - ( ( X [ 492ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 ) / 2.0 *
t3121 - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M21 - X
[ 492ULL ] ) / 2.0 * X [ 501ULL ] ) ; t2047 [ 469ULL ] = - ( ( X [ 492ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20 ) / 2.0 * X [
468ULL ] - ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M20
- X [ 492ULL ] ) / 2.0 * X [ 505ULL ] ) ; t2047 [ 470ULL ] = - ( ( X [ 492ULL
] + t3454 ) / 2.0 * X [ 467ULL ] - ( t3454 - X [ 492ULL ] ) / 2.0 * X [
504ULL ] ) ; t2047 [ 471ULL ] = - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M9 + t3438 ) *
0.001 ) / 7.5401484792408886E-5 ; t2047 [ 472ULL ] = - ( t4534 /
7.8539816339744827E-5 * 0.00031622776601683789 + intrm_sf_mf_1524 ) ; t2047 [
473ULL ] = - ( t4548 / 7.8539816339744827E-5 * 0.00031622776601683789 + t3346
) ; t2047 [ 474ULL ] = t3009 ; t2047 [ 475ULL ] = t3011 ; t5690 = X [ 488ULL
] * t3418 ; t2047 [ 476ULL ] = - ( ( ( real_T ) ( M [ 17ULL ] != 0 ) * 2.0 -
1.0 ) * ( t5690 / ( X [ 489ULL ] == 0.0 ? 1.0E-16 : X [ 489ULL ] ) ) * (
t5690 / ( X [ 489ULL ] == 0.0 ? 1.0E-16 : X [ 489ULL ] ) ) * ( - X [ 478ULL ]
/ 7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0
* 9.999999999999999E-14 + intrm_sf_mf_1299 ) ; t5690 = X [ 493ULL ] * t3418 ;
t2047 [ 477ULL ] = - ( ( ( real_T ) ( M [ 18ULL ] != 0 ) * 2.0 - 1.0 ) * (
t5690 / ( X [ 494ULL ] == 0.0 ? 1.0E-16 : X [ 494ULL ] ) ) * ( t5690 / ( X [
494ULL ] == 0.0 ? 1.0E-16 : X [ 494ULL ] ) ) * ( X [ 492ULL ] /
7.8539816339744827E-5 ) * ( X [ 492ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + intrm_sf_mf_1295 ) ; t2047 [ 478ULL ] = ( X [ 496ULL
] * t3418 / 461.523 - t3441 * X [ 69ULL ] ) / 0.64309276860371423 ; t2047 [
479ULL ] = X [ 490ULL ] * t3418 / 461.523 ; t2047 [ 480ULL ] = X [ 495ULL ] *
t3440 ; t2047 [ 481ULL ] = X [ 491ULL ] * t3418 / 4124.48151675695 ; t2047 [
482ULL ] = - ( ( ( real_T ) ( M [ 19ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3740 / (
X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) ) * ( t3740 / ( X [ 68ULL ] ==
0.0 ? 1.0E-16 : X [ 68ULL ] ) ) * ( - X [ 478ULL ] / 7.8539816339744827E-5 )
* ( - X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
t3473 ) ; t2047 [ 483ULL ] = - t3397 ; t2047 [ 484ULL ] = - t3417 ; t2047 [
485ULL ] = - ( ( ( real_T ) ( M [ 19ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3740 / (
X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) ) * ( t3740 / ( X [ 68ULL ] ==
0.0 ? 1.0E-16 : X [ 68ULL ] ) ) * ( X [ 492ULL ] / 7.8539816339744827E-5 ) *
( X [ 492ULL ] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
t3473 ) ; t2047 [ 486ULL ] = - t3397 ; t2047 [ 487ULL ] = - t3417 ; t2047 [
488ULL ] = - ( ( - X [ 478ULL ] + t3407 ) / 2.0 * zc_int339 - ( t3407 - ( - X
[ 478ULL ] ) ) / 2.0 * X [ 512ULL ] ) ; t2047 [ 489ULL ] = - ( ( - X [ 478ULL
] + t3406 ) / 2.0 * X [ 471ULL ] - ( t3406 - ( - X [ 478ULL ] ) ) / 2.0 * X [
508ULL ] ) ; t2047 [ 490ULL ] = - ( ( - X [ 478ULL ] + t194 ) / 2.0 * X [
470ULL ] - ( t194 - ( - X [ 478ULL ] ) ) / 2.0 * X [ 509ULL ] ) ; t2047 [
491ULL ] = - ( t5708 / 2.0 * t2634 - U_idx_3 / 2.0 * X [ 512ULL ] ) ; t2047 [
492ULL ] = - ( U_idx_11 / 2.0 * X [ 487ULL ] - U_idx_7 / 2.0 * X [ 508ULL ] )
; t2047 [ 493ULL ] = - ( U_idx_1 / 2.0 * X [ 486ULL ] - t5294 / 2.0 * X [
509ULL ] ) ; t2047 [ 494ULL ] = zc_int186 ; t2047 [ 495ULL ] = - (
intrm_sf_mf_1569 - t3488 ) ; t5708 = X [ 510ULL ] * t3483 ; t2047 [ 496ULL ]
= - ( ( ( real_T ) ( M [ 23ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / ( X [ 64ULL
] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ) * ( t5708 / ( X [ 64ULL ] == 0.0 ?
1.0E-16 : X [ 64ULL ] ) ) * ( - X [ 478ULL ] / 0.64 / 7.8539816339744827E-5 )
* ( - X [ 478ULL ] / 0.64 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3333 ) ; t5708 = X [ 511ULL ] * t3483 ; t2047 [
497ULL ] = - ( ( ( real_T ) ( M [ 24ULL ] != 0 ) * 2.0 - 1.0 ) * ( t5708 / (
X [ 485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( t5708 / ( X [ 485ULL ]
== 0.0 ? 1.0E-16 : X [ 485ULL ] ) ) * ( - X [ 478ULL ] / 0.64 /
7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 0.64 / 7.8539816339744827E-5 ) /
2.0 * 9.999999999999999E-14 + t3337 ) ; t2047 [ 498ULL ] = - ( ( ( real_T ) (
M [ 25ULL ] != 0 ) * 2.0 - 1.0 ) * ( t3819 / ( X [ 507ULL ] == 0.0 ? 1.0E-16
: X [ 507ULL ] ) ) * ( t3819 / ( X [ 507ULL ] == 0.0 ? 1.0E-16 : X [ 507ULL ]
) ) * ( - X [ 478ULL ] / 0.64 / ( t3478 == 0.0 ? 1.0E-16 : t3478 ) ) * ( - X
[ 478ULL ] / 0.64 / ( t3478 == 0.0 ? 1.0E-16 : t3478 ) ) / 2.0 *
9.999999999999999E-14 + t3347 ) ; t5708 = X [ 519ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; U_idx_3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 - X [ 519ULL
] ; t2047 [ 499ULL ] = - ( t5708 / 2.0 * zc_int349 - U_idx_3 / 2.0 * X [
518ULL ] ) / 365.59674280784293 ; U_idx_11 = X [ 519ULL ] + t3489 ; U_idx_7 =
t3489 - X [ 519ULL ] ; t2047 [ 500ULL ] = - ( U_idx_11 / 2.0 * X [ 515ULL ] -
U_idx_7 / 2.0 * X [ 523ULL ] ) ; U_idx_1 = X [ 519ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ; t5294 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 - X [ 519ULL
] ; t2047 [ 501ULL ] = - ( U_idx_1 / 2.0 * X [ 514ULL ] - t5294 / 2.0 * X [
522ULL ] ) ; t2047 [ 502ULL ] = t2815 / 461.523 / 43.3158175294914 + t3242 *
0.5 / 461.523 / 43.3158175294914 ; t2047 [ 503ULL ] = X [ 526ULL ] * t3494 /
461.523 ; t2047 [ 504ULL ] = X [ 516ULL ] * t3495 ; t2047 [ 505ULL ] = t5007
/ 259.836612622973 + t3242 * 0.21 / 259.836612622973 ; t5690 = t3494 * 293.15
; t2047 [ 506ULL ] = - 304.06022922571 - ( ( ( real_T ) ( M [ 27ULL ] != 0 )
* 2.0 - 1.0 ) * ( t5690 / 1.01325 ) * ( t5690 / 1.01325 ) * ( X [ 519ULL ] /
0.0019634954084936209 ) * ( X [ 519ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 + piece422 ) ; t2047 [ 507ULL ] = - t3492 ; t2047 [
508ULL ] = - t3493 ; t5690 = - X [ 519ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 ; U_idx_10 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak2 - ( - X [
519ULL ] ) ; t2047 [ 509ULL ] = - ( t5690 / 2.0 * zc_int350 - U_idx_10 / 2.0
* X [ 535ULL ] ) / 365.59674280784293 ; t2815 = - X [ 519ULL ] + t3489 ;
t5007 = t3489 - ( - X [ 519ULL ] ) ; t2047 [ 510ULL ] = - ( t2815 / 2.0 * X [
515ULL ] - t5007 / 2.0 * X [ 537ULL ] ) ; t5267 = - X [ 519ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 ; t5250 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Air_Intak0 - ( - X [
519ULL ] ) ; t2047 [ 511ULL ] = - ( t5267 / 2.0 * X [ 514ULL ] - t5250 / 2.0
* X [ 536ULL ] ) ; t2047 [ 512ULL ] = - ( t5708 / 2.0 * t2818 - U_idx_3 / 2.0
* X [ 535ULL ] ) ; t2047 [ 513ULL ] = - ( U_idx_11 / 2.0 * X [ 529ULL ] -
U_idx_7 / 2.0 * X [ 537ULL ] ) ; t2047 [ 514ULL ] = - ( U_idx_1 / 2.0 * X [
528ULL ] - t5294 / 2.0 * X [ 536ULL ] ) ; t2047 [ 515ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_2 ; t2047 [
516ULL ] = 979.36765375297466 + t3258 / 3.4930368471842854 ; t2047 [ 517ULL ]
= - 979.36765375297466 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip7 /
3.4930368471842854 ; t2047 [ 518ULL ] = t3139 / 1.0413512978067061 ; t2047 [
519ULL ] = zc_int352 ; t2047 [ 520ULL ] = - t3501 ; t2047 [ 521ULL ] = 0.0 ;
t2047 [ 522ULL ] = - ( X [ 540ULL ] / ( X [ 541ULL ] == 0.0 ? 1.0E-16 : X [
541ULL ] ) ) ; t2047 [ 523ULL ] = 0.0 ; t2047 [ 524ULL ] = - pmf_sqrt ( X [
513ULL ] * 0.00347041471455839 ) ; t2047 [ 525ULL ] = - ( t5690 / 2.0 *
zc_int357 - U_idx_10 / 2.0 * X [ 546ULL ] ) ; t2047 [ 526ULL ] = - ( t2815 /
2.0 * X [ 529ULL ] - t5007 / 2.0 * X [ 548ULL ] ) ; t2047 [ 527ULL ] = - (
t5267 / 2.0 * X [ 528ULL ] - t5250 / 2.0 * X [ 547ULL ] ) ; t2047 [ 528ULL ]
= - ( ( - X [ 413ULL ] + t3517 ) / 2.0 * ( ( ( real_T ) ( M [ 34ULL ] != 0 )
* 2.0 - 1.0 ) * ( t4363 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) *
( t4363 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( - X [ 413ULL ]
/ 0.0019634954084936209 ) * ( - X [ 413ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 + intrm_sf_mf_11 ) - ( t3517 - ( - X [ 413ULL ] ) ) /
2.0 * X [ 549ULL ] ) ; t2047 [ 529ULL ] = - ( ( - X [ 413ULL ] + t3516 ) /
2.0 * X [ 405ULL ] - ( t3516 - ( - X [ 413ULL ] ) ) / 2.0 * X [ 551ULL ] ) ;
t2047 [ 530ULL ] = - ( ( - X [ 413ULL ] + t3507 ) / 2.0 * X [ 404ULL ] - (
t3507 - ( - X [ 413ULL ] ) ) / 2.0 * X [ 550ULL ] ) ; t2047 [ 531ULL ] = ( X
[ 543ULL ] * t3510 / 461.523 - t3514 * X [ 73ULL ] ) / 0.64309276860371423 ;
t2047 [ 532ULL ] = X [ 545ULL ] * t3510 / 461.523 ; t2047 [ 533ULL ] = X [
542ULL ] * t3512 ; t2047 [ 534ULL ] = X [ 544ULL ] * t3510 / 259.836612622973
/ 1.1422643670118826 ; t2047 [ 535ULL ] = - ( ( ( real_T ) ( M [ 35ULL ] != 0
) * 2.0 - 1.0 ) * ( t3856 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) )
* ( t3856 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( - X [ 519ULL
] / 0.0019634954084936209 ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) /
2.0 * 9.999999999999999E-14 + t3523 ) ; t2047 [ 536ULL ] = - t3508 ; t2047 [
537ULL ] = - t3509 ; t2047 [ 538ULL ] = - ( ( ( real_T ) ( M [ 35ULL ] != 0 )
* 2.0 - 1.0 ) * ( t3856 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) *
( t3856 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ) * ( - X [ 413ULL ]
/ 0.0019634954084936209 ) * ( - X [ 413ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 + t3523 ) ; t2047 [ 539ULL ] = - t3508 ; t2047 [
540ULL ] = - t3509 ; t2047 [ 541ULL ] = X [ 552ULL ] * t3603 * 0.1 ; t2047 [
542ULL ] = - ( ( - X [ 492ULL ] + t3536 ) / 2.0 * t3145 - ( t3536 - ( - X [
492ULL ] ) ) / 2.0 * X [ 561ULL ] ) ; t2047 [ 543ULL ] = - ( ( - X [ 492ULL ]
+ t3535 ) / 2.0 * X [ 468ULL ] - ( t3535 - ( - X [ 492ULL ] ) ) / 2.0 * X [
563ULL ] ) ; t2047 [ 544ULL ] = - ( ( - X [ 492ULL ] + t3526 ) / 2.0 * X [
467ULL ] - ( t3526 - ( - X [ 492ULL ] ) ) / 2.0 * X [ 562ULL ] ) ; t5708 =
t3538 + t3544 ; U_idx_3 = t3544 - t3538 ; t2047 [ 545ULL ] = - ( t5708 / 2.0
* t3133 - U_idx_3 / 2.0 * X [ 564ULL ] ) ; U_idx_11 = t3538 + t3543 ; U_idx_7
= t3543 - t3538 ; t2047 [ 546ULL ] = - ( U_idx_11 / 2.0 * X [ 555ULL ] -
U_idx_7 / 2.0 * X [ 566ULL ] ) ; U_idx_1 = t3538 + t3539 ; t5294 = t3539 -
t3538 ; t2047 [ 547ULL ] = - ( U_idx_1 / 2.0 * X [ 554ULL ] - t5294 / 2.0 * X
[ 565ULL ] ) ; t2047 [ 548ULL ] = - ( ( - X [ 288ULL ] + t3552 ) / 2.0 * ( (
( real_T ) ( M [ 37ULL ] != 0 ) * 2.0 - 1.0 ) * ( t4240 / ( X [ 38ULL ] ==
0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t4240 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 :
X [ 38ULL ] ) ) * ( - X [ 288ULL ] / 7.8539816339744827E-5 ) * ( - X [ 288ULL
] / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t4726 ) - ( t3552
- ( - X [ 288ULL ] ) ) / 2.0 * X [ 567ULL ] ) ; t2047 [ 549ULL ] = - ( ( - X
[ 288ULL ] + t3548 ) / 2.0 * X [ 280ULL ] - ( t3548 - ( - X [ 288ULL ] ) ) /
2.0 * X [ 569ULL ] ) ; t2047 [ 550ULL ] = - ( ( - X [ 288ULL ] + t3546 ) /
2.0 * X [ 279ULL ] - ( t3546 - ( - X [ 288ULL ] ) ) / 2.0 * X [ 568ULL ] ) ;
t2047 [ 551ULL ] = ( X [ 557ULL ] * t3530 / 461.523 - t3534 * X [ 76ULL ] ) /
0.64309276860371423 ; t2047 [ 552ULL ] = X [ 559ULL ] * t3530 / 461.523 ;
t2047 [ 553ULL ] = X [ 556ULL ] * t3532 ; t2047 [ 554ULL ] = X [ 558ULL ] *
t3530 / 4124.48151675695 ; t2047 [ 555ULL ] = - ( ( ( real_T ) ( M [ 38ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ]
) ) * ( t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - X [
492ULL ] / 7.8539816339744827E-5 ) * ( - X [ 492ULL ] / 7.8539816339744827E-5
) / 2.0 * 9.999999999999999E-14 + t3564 ) ; t2047 [ 556ULL ] = - t3528 ;
t2047 [ 557ULL ] = - t3529 ; t2047 [ 558ULL ] = - ( ( ( real_T ) ( M [ 38ULL
] != 0 ) * 2.0 - 1.0 ) * ( t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL
] ) ) * ( t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t3538
/ 7.8539816339744827E-5 ) * ( t3538 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3564 ) ; t2047 [ 559ULL ] = - t3528 ; t2047 [ 560ULL
] = - t3529 ; t2047 [ 561ULL ] = - ( ( ( real_T ) ( M [ 38ULL ] != 0 ) * 2.0
- 1.0 ) * ( t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * (
t3861 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - X [ 288ULL ] /
7.8539816339744827E-5 ) * ( - X [ 288ULL ] / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t3564 ) ; t2047 [ 562ULL ] = - t3528 ; t2047 [ 563ULL
] = - t3529 ; t2047 [ 564ULL ] = - ( t5708 / 2.0 * t2852 - U_idx_3 / 2.0 * X
[ 574ULL ] ) ; t2047 [ 565ULL ] = - ( U_idx_11 / 2.0 * X [ 178ULL ] - U_idx_7
/ 2.0 * X [ 576ULL ] ) ; t2047 [ 566ULL ] = - ( U_idx_1 / 2.0 * X [ 177ULL ]
- t5294 / 2.0 * X [ 575ULL ] ) ; t2047 [ 567ULL ] = - ( ( - t3538 + t3544 ) /
2.0 * zc_int363 - ( t3544 - ( - t3538 ) ) / 2.0 * X [ 574ULL ] ) ; t2047 [
568ULL ] = - ( ( - t3538 + t3543 ) / 2.0 * X [ 555ULL ] - ( t3543 - ( - t3538
) ) / 2.0 * X [ 576ULL ] ) ; t2047 [ 569ULL ] = - ( ( - t3538 + t3539 ) / 2.0
* X [ 554ULL ] - ( t3539 - ( - t3538 ) ) / 2.0 * X [ 575ULL ] ) ; t2047 [
570ULL ] = zc_int368 ; t2047 [ 571ULL ] = t3029 / 3.4930368471842854 ; t2047
[ 572ULL ] = intrm_sf_mf_1296 / 3.4930368471842854 ; t2047 [ 573ULL ] =
zc_int366 ; t2047 [ 574ULL ] = t3176 ; t2047 [ 575ULL ] = t220 ; t2047 [
576ULL ] = - ( t2797 * t2797 ) / 1.0E+6 ; t2047 [ 577ULL ] = zc_int209 ;
t2047 [ 578ULL ] = - ( ( X [ 77ULL ] * X [ 581ULL ] * 0.001 + t3606 ) / ( X [
89ULL ] == 0.0 ? 1.0E-16 : X [ 89ULL ] ) * 1000.0 ) ; t2047 [ 579ULL ] = -
t3606 ; t2047 [ 580ULL ] = - t3572 ; t2047 [ 581ULL ] = 0.0 ; for ( b = 0 ; b
< 582 ; b ++ ) { out . mX [ b ] = t2047 [ b ] ; } ( void ) LC ; ( void )
t5711 ; return 0 ; }
