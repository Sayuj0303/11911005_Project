#ifdef __cplusplus
extern "C" {
#endif
#ifndef FCELECTRICPLANT_AC851AFD_1_DS_ASSERT_H
#define FCELECTRICPLANT_AC851AFD_1_DS_ASSERT_H 1
int32_T FCElectricPlant_ac851afd_1_ds_assert ( const NeDynamicSystem * sys ,
const NeDynamicSystemInput * Q , NeDsMethodOutput * M ) ;
#endif
#ifdef __cplusplus
}
#endif
