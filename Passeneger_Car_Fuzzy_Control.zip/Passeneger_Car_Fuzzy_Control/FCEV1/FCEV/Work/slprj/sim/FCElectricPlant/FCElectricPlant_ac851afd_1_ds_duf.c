#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_duf.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_duf ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t1926 , NeDsMethodOutput * t1927 ) { ETTS0
ab_efOut ; ETTS0 ad_efOut ; ETTS0 b_efOut ; ETTS0 bb_efOut ; ETTS0 bc_efOut ;
ETTS0 bf_efOut ; ETTS0 cd_efOut ; ETTS0 ch_efOut ; ETTS0 d_efOut ; ETTS0
db_efOut ; ETTS0 dc_efOut ; ETTS0 df_efOut ; ETTS0 dg_efOut ; ETTS0 efOut ;
ETTS0 f_efOut ; ETTS0 fb_efOut ; ETTS0 fc_efOut ; ETTS0 ff_efOut ; ETTS0
g_efOut ; ETTS0 gb_efOut ; ETTS0 gd_efOut ; ETTS0 gf_efOut ; ETTS0 gh_efOut ;
ETTS0 hg_efOut ; ETTS0 i_efOut ; ETTS0 ic_efOut ; ETTS0 if_efOut ; ETTS0
ih_efOut ; ETTS0 jc_efOut ; ETTS0 k_efOut ; ETTS0 kb_efOut ; ETTS0 kf_efOut ;
ETTS0 l_efOut ; ETTS0 ld_efOut ; ETTS0 le_efOut ; ETTS0 lf_efOut ; ETTS0
lg_efOut ; ETTS0 mb_efOut ; ETTS0 mh_efOut ; ETTS0 n_efOut ; ETTS0 nb_efOut ;
ETTS0 nc_efOut ; ETTS0 nf_efOut ; ETTS0 nh_efOut ; ETTS0 p_efOut ; ETTS0
pb_efOut ; ETTS0 pc_efOut ; ETTS0 pe_efOut ; ETTS0 pf_efOut ; ETTS0 pg_efOut
; ETTS0 q_efOut ; ETTS0 rb_efOut ; ETTS0 rc_efOut ; ETTS0 s_efOut ; ETTS0 t2
; ETTS0 t31 ; ETTS0 t45 ; ETTS0 t46 ; ETTS0 t47 ; ETTS0 t51 ; ETTS0 t57 ;
ETTS0 t58 ; ETTS0 t63 ; ETTS0 t67 ; ETTS0 te_efOut ; ETTS0 tf_efOut ; ETTS0
tg_efOut ; ETTS0 u_efOut ; ETTS0 uc_efOut ; ETTS0 v_efOut ; ETTS0 vb_efOut ;
ETTS0 vc_efOut ; ETTS0 vf_efOut ; ETTS0 wb_efOut ; ETTS0 wf_efOut ; ETTS0
x_efOut ; ETTS0 xc_efOut ; ETTS0 xe_efOut ; ETTS0 xg_efOut ; ETTS0 yd_efOut ;
ETTS0 ye_efOut ; PmRealVector out ; real_T X [ 582 ] ; real_T t579 [ 113 ] ;
real_T t698 [ 44 ] ; real_T t700 [ 29 ] ; real_T t704 [ 11 ] ; real_T t702 [
6 ] ; real_T t701 [ 5 ] ; real_T t703 [ 5 ] ; real_T nonscalar64 [ 3 ] ;
real_T ac_efOut [ 1 ] ; real_T ae_efOut [ 1 ] ; real_T af_efOut [ 1 ] ;
real_T ag_efOut [ 1 ] ; real_T ah_efOut [ 1 ] ; real_T bd_efOut [ 1 ] ;
real_T be_efOut [ 1 ] ; real_T bg_efOut [ 1 ] ; real_T bh_efOut [ 1 ] ;
real_T c_efOut [ 1 ] ; real_T cb_efOut [ 1 ] ; real_T cc_efOut [ 1 ] ; real_T
ce_efOut [ 1 ] ; real_T cf_efOut [ 1 ] ; real_T cg_efOut [ 1 ] ; real_T
dd_efOut [ 1 ] ; real_T de_efOut [ 1 ] ; real_T dh_efOut [ 1 ] ; real_T
e_efOut [ 1 ] ; real_T eb_efOut [ 1 ] ; real_T ec_efOut [ 1 ] ; real_T
ed_efOut [ 1 ] ; real_T ee_efOut [ 1 ] ; real_T ef_efOut [ 1 ] ; real_T
eg_efOut [ 1 ] ; real_T eh_efOut [ 1 ] ; real_T fd_efOut [ 1 ] ; real_T
fe_efOut [ 1 ] ; real_T fg_efOut [ 1 ] ; real_T fh_efOut [ 1 ] ; real_T
gc_efOut [ 1 ] ; real_T ge_efOut [ 1 ] ; real_T gg_efOut [ 1 ] ; real_T
h_efOut [ 1 ] ; real_T hb_efOut [ 1 ] ; real_T hc_efOut [ 1 ] ; real_T
hd_efOut [ 1 ] ; real_T he_efOut [ 1 ] ; real_T hf_efOut [ 1 ] ; real_T
hh_efOut [ 1 ] ; real_T ib_efOut [ 1 ] ; real_T id_efOut [ 1 ] ; real_T
ie_efOut [ 1 ] ; real_T ig_efOut [ 1 ] ; real_T j_efOut [ 1 ] ; real_T
jb_efOut [ 1 ] ; real_T jd_efOut [ 1 ] ; real_T je_efOut [ 1 ] ; real_T
jf_efOut [ 1 ] ; real_T jg_efOut [ 1 ] ; real_T jh_efOut [ 1 ] ; real_T
kc_efOut [ 1 ] ; real_T kd_efOut [ 1 ] ; real_T ke_efOut [ 1 ] ; real_T
kg_efOut [ 1 ] ; real_T kh_efOut [ 1 ] ; real_T lb_efOut [ 1 ] ; real_T
lc_efOut [ 1 ] ; real_T lh_efOut [ 1 ] ; real_T m_efOut [ 1 ] ; real_T
mc_efOut [ 1 ] ; real_T md_efOut [ 1 ] ; real_T me_efOut [ 1 ] ; real_T
mf_efOut [ 1 ] ; real_T mg_efOut [ 1 ] ; real_T nd_efOut [ 1 ] ; real_T
ne_efOut [ 1 ] ; real_T ng_efOut [ 1 ] ; real_T o_efOut [ 1 ] ; real_T
ob_efOut [ 1 ] ; real_T oc_efOut [ 1 ] ; real_T od_efOut [ 1 ] ; real_T
oe_efOut [ 1 ] ; real_T of_efOut [ 1 ] ; real_T og_efOut [ 1 ] ; real_T
oh_efOut [ 1 ] ; real_T pd_efOut [ 1 ] ; real_T qb_efOut [ 1 ] ; real_T
qc_efOut [ 1 ] ; real_T qd_efOut [ 1 ] ; real_T qe_efOut [ 1 ] ; real_T
qf_efOut [ 1 ] ; real_T qg_efOut [ 1 ] ; real_T r_efOut [ 1 ] ; real_T
rd_efOut [ 1 ] ; real_T re_efOut [ 1 ] ; real_T rf_efOut [ 1 ] ; real_T
rg_efOut [ 1 ] ; real_T sb_efOut [ 1 ] ; real_T sc_efOut [ 1 ] ; real_T
sd_efOut [ 1 ] ; real_T se_efOut [ 1 ] ; real_T sf_efOut [ 1 ] ; real_T
sg_efOut [ 1 ] ; real_T t706 [ 1 ] ; real_T t_efOut [ 1 ] ; real_T tb_efOut [
1 ] ; real_T tc_efOut [ 1 ] ; real_T td_efOut [ 1 ] ; real_T ub_efOut [ 1 ] ;
real_T ud_efOut [ 1 ] ; real_T ue_efOut [ 1 ] ; real_T uf_efOut [ 1 ] ;
real_T ug_efOut [ 1 ] ; real_T vd_efOut [ 1 ] ; real_T ve_efOut [ 1 ] ;
real_T vg_efOut [ 1 ] ; real_T w_efOut [ 1 ] ; real_T wc_efOut [ 1 ] ; real_T
wd_efOut [ 1 ] ; real_T we_efOut [ 1 ] ; real_T wg_efOut [ 1 ] ; real_T
xb_efOut [ 1 ] ; real_T xd_efOut [ 1 ] ; real_T xf_efOut [ 1 ] ; real_T
y_efOut [ 1 ] ; real_T yb_efOut [ 1 ] ; real_T yc_efOut [ 1 ] ; real_T
yf_efOut [ 1 ] ; real_T yg_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I ; real_T
Electrical_Cooling_System_Pump_convection_A_u_in ; real_T
Fuel_Cell_Boost_Converter_L_i ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 ; real_T
U_idx_0 ; real_T U_idx_1 ; real_T U_idx_10 ; real_T U_idx_11 ; real_T
U_idx_12 ; real_T U_idx_13 ; real_T U_idx_2 ; real_T U_idx_3 ; real_T U_idx_4
; real_T U_idx_5 ; real_T U_idx_6 ; real_T U_idx_7 ; real_T U_idx_8 ; real_T
U_idx_9 ; real_T intermediate_der0 ; real_T intermediate_der10272 ; real_T
intermediate_der10282 ; real_T intermediate_der10355 ; real_T
intermediate_der10658 ; real_T intermediate_der10891 ; real_T
intermediate_der1148 ; real_T intermediate_der11504 ; real_T
intermediate_der11513 ; real_T intermediate_der11607 ; real_T
intermediate_der11622 ; real_T intermediate_der11627 ; real_T
intermediate_der11651 ; real_T intermediate_der11730 ; real_T
intermediate_der11984 ; real_T intermediate_der1227 ; real_T
intermediate_der1237 ; real_T intermediate_der1258 ; real_T
intermediate_der149 ; real_T intermediate_der197 ; real_T intermediate_der231
; real_T intermediate_der239 ; real_T intermediate_der242 ; real_T
intermediate_der3088 ; real_T intermediate_der316 ; real_T
intermediate_der349 ; real_T intermediate_der3732 ; real_T
intermediate_der3734 ; real_T intermediate_der3747 ; real_T
intermediate_der539 ; real_T intermediate_der5446 ; real_T
intermediate_der5455 ; real_T intermediate_der546 ; real_T
intermediate_der553 ; real_T intermediate_der5545 ; real_T
intermediate_der5549 ; real_T intermediate_der5557 ; real_T
intermediate_der5594 ; real_T intermediate_der5597 ; real_T
intermediate_der5598 ; real_T intermediate_der693 ; real_T
intermediate_der6946 ; real_T intermediate_der7294 ; real_T
intermediate_der8069 ; real_T intermediate_der8390 ; real_T
intermediate_der8465 ; real_T intermediate_der8498 ; real_T
intermediate_der8500 ; real_T intermediate_der8829 ; real_T
intermediate_der9120 ; real_T intermediate_der9282 ; real_T intrm_sf_mf_10 ;
real_T intrm_sf_mf_11 ; real_T intrm_sf_mf_1142 ; real_T intrm_sf_mf_1324 ;
real_T intrm_sf_mf_133 ; real_T intrm_sf_mf_1332 ; real_T intrm_sf_mf_1336 ;
real_T intrm_sf_mf_1337 ; real_T intrm_sf_mf_1348 ; real_T intrm_sf_mf_1534 ;
real_T intrm_sf_mf_1543 ; real_T intrm_sf_mf_41 ; real_T intrm_sf_mf_52 ;
real_T intrm_sf_mf_543 ; real_T intrm_sf_mf_545 ; real_T intrm_sf_mf_864 ;
real_T intrm_sf_mf_9 ; real_T intrm_sf_mf_95 ; real_T t1001 ; real_T t1002 ;
real_T t1004 ; real_T t1005 ; real_T t1007 ; real_T t1009 ; real_T t1011 ;
real_T t1012 ; real_T t1013 ; real_T t1015 ; real_T t1016 ; real_T t1017 ;
real_T t1018 ; real_T t1019 ; real_T t1020 ; real_T t1021 ; real_T t1022 ;
real_T t1023 ; real_T t1024 ; real_T t1026 ; real_T t1028 ; real_T t1030 ;
real_T t1032 ; real_T t1033 ; real_T t1037 ; real_T t1038 ; real_T t1040 ;
real_T t1042 ; real_T t1044 ; real_T t1045 ; real_T t1048 ; real_T t1049 ;
real_T t1050 ; real_T t1051 ; real_T t1054 ; real_T t1055 ; real_T t1058 ;
real_T t1060 ; real_T t1062 ; real_T t1063 ; real_T t1065 ; real_T t1066 ;
real_T t1067 ; real_T t1068 ; real_T t1069 ; real_T t1072 ; real_T t1076 ;
real_T t1078 ; real_T t1080 ; real_T t1084 ; real_T t1086 ; real_T t1089 ;
real_T t1093 ; real_T t1096 ; real_T t1101 ; real_T t1103 ; real_T t1109 ;
real_T t1110 ; real_T t1111 ; real_T t1116 ; real_T t1122 ; real_T t1125 ;
real_T t1130 ; real_T t1181 ; real_T t1190 ; real_T t1234 ; real_T t1243 ;
real_T t1372 ; real_T t1377 ; real_T t1378 ; real_T t1381 ; real_T t1385 ;
real_T t1386 ; real_T t1387 ; real_T t1388 ; real_T t1389 ; real_T t1390 ;
real_T t1391 ; real_T t1392 ; real_T t1408 ; real_T t1421 ; real_T t1430 ;
real_T t1454 ; real_T t1468 ; real_T t1470 ; real_T t1471 ; real_T t1473 ;
real_T t1474 ; real_T t1477 ; real_T t1479 ; real_T t1481 ; real_T t1482 ;
real_T t1483 ; real_T t1484 ; real_T t1485 ; real_T t1486 ; real_T t1487 ;
real_T t1488 ; real_T t1489 ; real_T t1490 ; real_T t1491 ; real_T t1492 ;
real_T t1494 ; real_T t1499 ; real_T t1527 ; real_T t1528 ; real_T t1553 ;
real_T t1556 ; real_T t1660 ; real_T t1665 ; real_T t1673 ; real_T t1734 ;
real_T t1753 ; real_T t1762 ; real_T t1771 ; real_T t1778 ; real_T t1781 ;
real_T t1789 ; real_T t1794 ; real_T t1860 ; real_T t1862 ; real_T t1867 ;
real_T t1921 ; real_T t1923 ; real_T t1924 ; real_T t1925 ; real_T t690_idx_0
; real_T t697_idx_0 ; real_T t72 ; real_T t762 ; real_T t765 ; real_T t771 ;
real_T t774 ; real_T t775 ; real_T t785 ; real_T t786 ; real_T t789 ; real_T
t790 ; real_T t793 ; real_T t795 ; real_T t796 ; real_T t801 ; real_T t802 ;
real_T t805 ; real_T t808 ; real_T t810 ; real_T t813 ; real_T t814 ; real_T
t816 ; real_T t817 ; real_T t820 ; real_T t826 ; real_T t827 ; real_T t828 ;
real_T t831 ; real_T t832 ; real_T t834 ; real_T t836 ; real_T t837 ; real_T
t838 ; real_T t839 ; real_T t841 ; real_T t842 ; real_T t843 ; real_T t844 ;
real_T t846 ; real_T t847 ; real_T t850 ; real_T t851 ; real_T t853 ; real_T
t858 ; real_T t860 ; real_T t872 ; real_T t874 ; real_T t877 ; real_T t878 ;
real_T t880 ; real_T t881 ; real_T t882 ; real_T t883 ; real_T t886 ; real_T
t897 ; real_T t898 ; real_T t899 ; real_T t901 ; real_T t902 ; real_T t904 ;
real_T t907 ; real_T t908 ; real_T t909 ; real_T t910 ; real_T t911 ; real_T
t914 ; real_T t915 ; real_T t916 ; real_T t917 ; real_T t919 ; real_T t921 ;
real_T t922 ; real_T t923 ; real_T t930 ; real_T t931 ; real_T t933 ; real_T
t934 ; real_T t935 ; real_T t937 ; real_T t938 ; real_T t939 ; real_T t940 ;
real_T t941 ; real_T t943 ; real_T t945 ; real_T t949 ; real_T t952 ; real_T
t953 ; real_T t954 ; real_T t955 ; real_T t956 ; real_T t957 ; real_T t959 ;
real_T t960 ; real_T t961 ; real_T t962 ; real_T t963 ; real_T t964 ; real_T
t966 ; real_T t967 ; real_T t968 ; real_T t970 ; real_T t971 ; real_T t972 ;
real_T t973 ; real_T t974 ; real_T t975 ; real_T t976 ; real_T t977 ; real_T
t979 ; real_T t980 ; real_T t981 ; real_T t982 ; real_T t983 ; real_T t984 ;
real_T t985 ; real_T t986 ; real_T t987 ; real_T t989 ; real_T t990 ; real_T
t991 ; real_T t992 ; real_T t993 ; real_T t994 ; real_T t995 ; real_T t996 ;
real_T t997 ; real_T t998 ; real_T t999 ; real_T zc_int10 ; real_T zc_int116
; real_T zc_int17 ; real_T zc_int174 ; real_T zc_int179 ; real_T zc_int180 ;
real_T zc_int186 ; real_T zc_int365 ; real_T zc_int366 ; real_T zc_int367 ;
real_T zc_int42 ; real_T zc_int43 ; size_t t305 [ 1 ] ; size_t t407 [ 1 ] ;
size_t t574 [ 1 ] ; size_t t75 [ 1 ] ; size_t t714 ; int32_T M [ 361 ] ;
int32_T b ; for ( b = 0 ; b < 361 ; b ++ ) { M [ b ] = t1926 -> mM . mX [ b ]
; } U_idx_0 = t1926 -> mU . mX [ 0 ] ; U_idx_1 = t1926 -> mU . mX [ 1 ] ;
U_idx_2 = t1926 -> mU . mX [ 2 ] ; U_idx_3 = t1926 -> mU . mX [ 3 ] ; U_idx_4
= t1926 -> mU . mX [ 4 ] ; U_idx_5 = t1926 -> mU . mX [ 5 ] ; U_idx_6 = t1926
-> mU . mX [ 6 ] ; U_idx_7 = t1926 -> mU . mX [ 7 ] ; U_idx_8 = t1926 -> mU .
mX [ 8 ] ; U_idx_9 = t1926 -> mU . mX [ 9 ] ; U_idx_10 = t1926 -> mU . mX [
10 ] ; U_idx_11 = t1926 -> mU . mX [ 11 ] ; U_idx_12 = t1926 -> mU . mX [ 12
] ; U_idx_13 = t1926 -> mU . mX [ 13 ] ; for ( b = 0 ; b < 582 ; b ++ ) { X [
b ] = t1926 -> mX . mX [ b ] ; } out = t1927 -> mDUF ; t701 [ 0 ] = 1.0 ;
t701 [ 1 ] = 1.25 ; t701 [ 2 ] = 1.5 ; t701 [ 3 ] = 1.75 ; t701 [ 4 ] = 2.0 ;
nonscalar64 [ 0 ] = 0.0 ; nonscalar64 [ 1 ] = 188.49555921538757 ;
nonscalar64 [ 2 ] = 376.99111843077515 ; t775 = - X [ 79ULL ] - U_idx_1 ; t72
= ( ( ( real_T ) ( t775 >= 0.0 ) * t775 * 1000.0 + ( real_T ) ( t775 < 0.0 )
* X [ 81ULL ] ) - 0.9 ) / 0.099999999999999978 ; t1924 = pmf_sqrt ( U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 ) ; t706 [ 0ULL ] = X [ 97ULL ] ; t305 [ 0 ]
= 20ULL ; t75 [ 0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut . mField0
[ 0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t67 = efOut ; t706 [ 0ULL ] = X [ 93ULL ] ; t574 [ 0 ] =
19ULL ; tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , &
b_efOut . mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [ 0ULL ] , & t574 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t63 = b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut
[ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t63 .
mField0 [ 0ULL ] , & t63 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField1 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = c_efOut [ 0 ] ; t1925 = t697_idx_0 ; t706 [ 0ULL ] = X [ 92ULL ]
; tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = d_efOut ; tlu2_2d_linear_linear_value ( & e_efOut [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , & t63 . mField0 [ 0ULL ] , &
t63 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = e_efOut [ 0
] ; t1921 = t697_idx_0 ; t706 [ 0ULL ] = X [ 99ULL ] ;
tlu2_linear_linear_prelookup ( & f_efOut . mField0 [ 0ULL ] , & f_efOut .
mField1 [ 0ULL ] , & f_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = f_efOut ; t706 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup (
& g_efOut . mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t58 = g_efOut ;
tlu2_2d_linear_linear_value ( & h_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] ,
& t67 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [
0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = h_efOut [ 0 ] ; t1923 = t697_idx_0 ;
t706 [ 0ULL ] = X [ 94ULL ] ; tlu2_linear_linear_prelookup ( & i_efOut .
mField0 [ 0ULL ] , & i_efOut . mField1 [ 0ULL ] , & i_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [
0ULL ] , & t75 [ 0ULL ] ) ; t67 = i_efOut ; tlu2_2d_linear_linear_value ( &
j_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t58 . mField0 [ 0ULL ] , & t58 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = j_efOut [ 0 ] ; t1860 = t697_idx_0 ; t706 [ 0ULL ] = X [ 106ULL
] ; tlu2_linear_linear_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = k_efOut ; t706 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_linear_prelookup (
& l_efOut . mField0 [ 0ULL ] , & l_efOut . mField1 [ 0ULL ] , & l_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t51 = l_efOut ;
tlu2_2d_linear_linear_value ( & m_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] ,
& t67 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [
0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = m_efOut [ 0 ] ; t1794 = t697_idx_0 ;
t706 [ 0ULL ] = X [ 101ULL ] ; tlu2_linear_linear_prelookup ( & n_efOut .
mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [
0ULL ] , & t75 [ 0ULL ] ) ; t31 = n_efOut ; tlu2_2d_linear_linear_value ( &
o_efOut [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , &
t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = o_efOut [ 0 ] ; t1862 = t697_idx_0 ; t706 [ 0ULL ] = X [ 108ULL
] ; tlu2_linear_linear_prelookup ( & p_efOut . mField0 [ 0ULL ] , & p_efOut .
mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = p_efOut ; t706 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup (
& q_efOut . mField0 [ 0ULL ] , & q_efOut . mField1 [ 0ULL ] , & q_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t45 = q_efOut ;
tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] ,
& t67 . mField2 [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [
0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = r_efOut [ 0 ] ; t1778 = t697_idx_0 ;
t706 [ 0ULL ] = X [ 103ULL ] ; tlu2_linear_linear_prelookup ( & s_efOut .
mField0 [ 0ULL ] , & s_efOut . mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [
0ULL ] , & t75 [ 0ULL ] ) ; t67 = s_efOut ; tlu2_2d_linear_linear_value ( &
t_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = t_efOut [ 0 ] ; t1867 = t697_idx_0 ; t706 [ 0ULL ] = X [ 115ULL
] ; tlu2_linear_linear_prelookup ( & u_efOut . mField0 [ 0ULL ] , & u_efOut .
mField1 [ 0ULL ] , & u_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = u_efOut ; t706 [ 0ULL ] = X [ 111ULL ] ; tlu2_linear_linear_prelookup (
& v_efOut . mField0 [ 0ULL ] , & v_efOut . mField1 [ 0ULL ] , & v_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t2 = v_efOut ;
tlu2_2d_linear_linear_value ( & w_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ] ,
& t47 . mField2 [ 0ULL ] , & t2 . mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [
0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = w_efOut [ 0 ] ; t1789 = t697_idx_0 ;
t706 [ 0ULL ] = X [ 110ULL ] ; tlu2_linear_linear_prelookup ( & x_efOut .
mField0 [ 0ULL ] , & x_efOut . mField1 [ 0ULL ] , & x_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [
0ULL ] , & t75 [ 0ULL ] ) ; t47 = x_efOut ; tlu2_2d_linear_linear_value ( &
y_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , & t2
. mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField4 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = y_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 = t697_idx_0
; t706 [ 0ULL ] = X [ 117ULL ] ; tlu2_linear_linear_prelookup ( & ab_efOut .
mField0 [ 0ULL ] , & ab_efOut . mField1 [ 0ULL ] , & ab_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , &
t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = ab_efOut ; t706 [ 0ULL ] = X [
113ULL ] ; tlu2_linear_linear_prelookup ( & bb_efOut . mField0 [ 0ULL ] , &
bb_efOut . mField1 [ 0ULL ] , & bb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [ 0ULL ] , & t574 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t47 = bb_efOut ; tlu2_2d_linear_linear_value ( &
cb_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = cb_efOut [ 0 ] ; intermediate_der149 = t697_idx_0 ; t706 [ 0ULL
] = X [ 112ULL ] ; tlu2_linear_linear_prelookup ( & db_efOut . mField0 [ 0ULL
] , & db_efOut . mField1 [ 0ULL ] , & db_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t67 = db_efOut ; tlu2_2d_linear_linear_value ( &
eb_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = eb_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 = t697_idx_0
; intermediate_der197 = ( U_idx_2 - ( - U_idx_2 ) ) / 2.0 ;
intermediate_der231 = intermediate_der197 >= 0.0 ? X [ 112ULL ] : X [ 119ULL
] ; t706 [ 0ULL ] = ( X [ 6ULL ] + intermediate_der231 ) / 2.0 ;
tlu2_linear_linear_prelookup ( & fb_efOut . mField0 [ 0ULL ] , & fb_efOut .
mField1 [ 0ULL ] , & fb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = fb_efOut ; t706 [ 0ULL ] = ( X [ 113ULL ] + X [ 120ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & gb_efOut . mField0 [ 0ULL ] , & gb_efOut .
mField1 [ 0ULL ] , & gb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t57 = gb_efOut ; tlu2_2d_linear_linear_value ( & hb_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , &
t57 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = hb_efOut [
0 ] ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg = t697_idx_0
; tlu2_2d_linear_linear_value ( & ib_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL
] , & t67 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ib_efOut [ 0 ] ;
intermediate_der5545 = ( intermediate_der197 >= 0.0 ? intermediate_der197 : -
intermediate_der197 ) * 0.01 ; t1234 = t697_idx_0 * 7.8539816339744827E-5 ;
t785 = intermediate_der5545 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) ; t786 =
t785 > 1000.0 ? t785 : 1000.0 ; intermediate_der239 = t785 >= 2000.0 ? t785 :
1.0 ; t789 = pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ? 1.0E-16 :
intermediate_der239 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * 3.24 ; intermediate_der242 = 1.0 / ( t789 == 0.0 ?
1.0E-16 : t789 ) ; t1494 = ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ; t789 = ( t786 - 1000.0 ) * ( intermediate_der242 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg / ( t1494 == 0.0 ?
1.0E-16 : t1494 ) ; t790 = ( t785 - 2000.0 ) / 2000.0 ; intermediate_der316 =
t790 * t790 * 3.0 - t790 * t790 * t790 * 2.0 ; if ( t785 <= 2000.0 ) {
intermediate_der349 = 3.66 ; } else if ( t785 >= 4000.0 ) {
intermediate_der349 = t789 ; } else { intermediate_der349 = ( 1.0 -
intermediate_der316 ) * 3.66 + t789 * intermediate_der316 ; } t793 =
intermediate_der349 * 0.031415926535897927 / ( t785 + 1.0 == 0.0 ? 1.0E-16 :
t785 + 1.0 ) / 7.8539816339744827E-5 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) ; t795 = (
U_idx_0 - intermediate_der231 ) * ( 1.0 - pmf_exp ( - t793 ) ) ;
tlu2_2d_linear_linear_value ( & jb_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = jb_efOut [ 0 ] ; t796 =
t697_idx_0 ; intermediate_der539 = pmf_sqrt ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) ; t706 [ 0ULL ] = X [ 123ULL ] ;
tlu2_linear_linear_prelookup ( & kb_efOut . mField0 [ 0ULL ] , & kb_efOut .
mField1 [ 0ULL ] , & kb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = kb_efOut ; tlu2_2d_linear_linear_value ( & lb_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , &
t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = lb_efOut [
0 ] ; intermediate_der546 = t697_idx_0 ; t706 [ 0ULL ] = X [ 125ULL ] ;
tlu2_linear_linear_prelookup ( & mb_efOut . mField0 [ 0ULL ] , & mb_efOut .
mField1 [ 0ULL ] , & mb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = mb_efOut ; t706 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_linear_prelookup
( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut . mField1 [ 0ULL ] , & nb_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t46 = nb_efOut ;
tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ob_efOut [ 0 ] ;
intermediate_der553 = t697_idx_0 ; t706 [ 0ULL ] = X [ 119ULL ] ;
tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t31 = pb_efOut ; tlu2_2d_linear_linear_value ( & qb_efOut [ 0ULL ] , & t31 .
mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , & t46 . mField0 [ 0ULL ] , &
t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = qb_efOut [
0 ] ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 =
t697_idx_0 ; t706 [ 0ULL ] = X [ 6ULL ] ; tlu2_linear_linear_prelookup ( &
rb_efOut . mField0 [ 0ULL ] , & rb_efOut . mField1 [ 0ULL ] , & rb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t46 = rb_efOut ;
tlu2_2d_linear_linear_value ( & sb_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = sb_efOut [ 0 ] ;
intermediate_der8465 = t697_idx_0 ; tlu2_2d_linear_linear_value ( & tb_efOut
[ 0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [ 0ULL ] , & t57 .
mField0 [ 0ULL ] , & t57 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField8 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = tb_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I = t697_idx_0 ;
tlu2_2d_linear_linear_value ( & ub_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , & t57 . mField0 [ 0ULL ] , & t57 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ub_efOut [ 0 ] ;
intermediate_der10891 = t697_idx_0 ; intermediate_der693 =
intermediate_der197 >= 0.0 ? X [ 94ULL ] : X [ 101ULL ] ; t706 [ 0ULL ] = ( X
[ 9ULL ] + intermediate_der693 ) / 2.0 ; tlu2_linear_linear_prelookup ( &
vb_efOut . mField0 [ 0ULL ] , & vb_efOut . mField1 [ 0ULL ] , & vb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = vb_efOut ; t706 [ 0ULL ]
= ( X [ 95ULL ] + X [ 102ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( &
wb_efOut . mField0 [ 0ULL ] , & wb_efOut . mField1 [ 0ULL ] , & wb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t47 = wb_efOut ;
tlu2_2d_linear_linear_value ( & xb_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , & t47 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = xb_efOut [ 0 ] ;
intermediate_der1227 = t697_idx_0 ; tlu2_2d_linear_linear_value ( & yb_efOut
[ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField7 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = yb_efOut [ 0 ] ; t1377 = t697_idx_0 * 7.8539816339744827E-5 ;
intermediate_der1258 = intermediate_der5545 / ( t1377 == 0.0 ? 1.0E-16 :
t1377 ) ; intermediate_der1237 = intermediate_der1258 > 1000.0 ?
intermediate_der1258 : 1000.0 ; intermediate_der1148 = intermediate_der1258
>= 2000.0 ? intermediate_der1258 : 1.0 ; t801 = pmf_log10 ( 6.9 / (
intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ?
1.0E-16 : intermediate_der1148 ) + 0.00017169489553429715 ) * 3.24 ;
intermediate_der11984 = 1.0 / ( t801 == 0.0 ? 1.0E-16 : t801 ) ; t1378 = (
pmf_pow ( intermediate_der1227 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der11984 / 8.0 ) * 12.7 + 1.0 ; t801 = ( intermediate_der1237 -
1000.0 ) * ( intermediate_der11984 / 8.0 ) * intermediate_der1227 / ( t1378
== 0.0 ? 1.0E-16 : t1378 ) ; t802 = ( intermediate_der1258 - 2000.0 ) /
2000.0 ; intermediate_der3088 = t802 * t802 * 3.0 - t802 * t802 * t802 * 2.0
; if ( intermediate_der1258 <= 2000.0 ) { intermediate_der3747 = 3.66 ; }
else if ( intermediate_der1258 >= 4000.0 ) { intermediate_der3747 = t801 ; }
else { intermediate_der3747 = ( 1.0 - intermediate_der3088 ) * 3.66 + t801 *
intermediate_der3088 ; } t805 = intermediate_der3747 * 0.031415926535897927 /
( intermediate_der1258 + 1.0 == 0.0 ? 1.0E-16 : intermediate_der1258 + 1.0 )
/ 7.8539816339744827E-5 / ( intermediate_der1227 == 0.0 ? 1.0E-16 :
intermediate_der1227 ) ; intermediate_der5455 = ( X [ 10ULL ] -
intermediate_der693 ) * ( 1.0 - pmf_exp ( - t805 ) ) ;
tlu2_2d_linear_linear_value ( & ac_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , & t47 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ac_efOut [ 0 ] ; t808 =
t697_idx_0 ; t706 [ 0ULL ] = X [ 128ULL ] ; tlu2_linear_linear_prelookup ( &
bc_efOut . mField0 [ 0ULL ] , & bc_efOut . mField1 [ 0ULL ] , & bc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = bc_efOut ;
tlu2_2d_linear_linear_value ( & cc_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = cc_efOut [ 0 ] ;
intermediate_der5446 = t697_idx_0 ; t706 [ 0ULL ] = X [ 130ULL ] ;
tlu2_linear_linear_prelookup ( & dc_efOut . mField0 [ 0ULL ] , & dc_efOut .
mField1 [ 0ULL ] , & dc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t31 = dc_efOut ; tlu2_2d_linear_linear_value ( & ec_efOut [ 0ULL ] , & t31 .
mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , & t51 . mField0 [ 0ULL ] , &
t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ec_efOut [
0 ] ; intermediate_der3732 = t697_idx_0 ; t706 [ 0ULL ] = X [ 9ULL ] ;
tlu2_linear_linear_prelookup ( & fc_efOut . mField0 [ 0ULL ] , & fc_efOut .
mField1 [ 0ULL ] , & fc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = fc_efOut ; tlu2_2d_linear_linear_value ( & gc_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , &
t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = gc_efOut [
0 ] ; intermediate_der9282 = t697_idx_0 ; tlu2_2d_linear_linear_value ( &
hc_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField7 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = hc_efOut [ 0 ] ; intermediate_der10272 = t697_idx_0 ;
intermediate_der3734 = intermediate_der197 >= 0.0 ? X [ 103ULL ] : X [ 110ULL
] ; t706 [ 0ULL ] = ( X [ 11ULL ] + intermediate_der3734 ) / 2.0 ;
tlu2_linear_linear_prelookup ( & ic_efOut . mField0 [ 0ULL ] , & ic_efOut .
mField1 [ 0ULL ] , & ic_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = ic_efOut ; t706 [ 0ULL ] = ( X [ 104ULL ] + X [ 111ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & jc_efOut . mField0 [ 0ULL ] , & jc_efOut .
mField1 [ 0ULL ] , & jc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = jc_efOut ; tlu2_2d_linear_linear_value ( & kc_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , &
t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = kc_efOut [
0 ] ; intermediate_der8498 = t697_idx_0 ; tlu2_2d_linear_linear_value ( &
lc_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , &
t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField7 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = lc_efOut [ 0 ] ; t1499 = t697_idx_0 * 7.8539816339744827E-5 ;
intermediate_der8069 = intermediate_der5545 / ( t1499 == 0.0 ? 1.0E-16 :
t1499 ) ; intermediate_der5545 = intermediate_der8069 > 1000.0 ?
intermediate_der8069 : 1000.0 ; t810 = intermediate_der8069 >= 2000.0 ?
intermediate_der8069 : 1.0 ; t813 = pmf_log10 ( 6.9 / ( t810 == 0.0 ? 1.0E-16
: t810 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t810 == 0.0 ?
1.0E-16 : t810 ) + 0.00017169489553429715 ) * 3.24 ; intermediate_der5549 =
1.0 / ( t813 == 0.0 ? 1.0E-16 : t813 ) ; t1381 = ( pmf_pow (
intermediate_der8498 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der5549 / 8.0 ) * 12.7 + 1.0 ; t813 = ( intermediate_der5545 -
1000.0 ) * ( intermediate_der5549 / 8.0 ) * intermediate_der8498 / ( t1381 ==
0.0 ? 1.0E-16 : t1381 ) ; t814 = ( intermediate_der8069 - 2000.0 ) / 2000.0 ;
t816 = t814 * t814 * 3.0 - t814 * t814 * t814 * 2.0 ; if (
intermediate_der8069 <= 2000.0 ) { intermediate_der5557 = 3.66 ; } else if (
intermediate_der8069 >= 4000.0 ) { intermediate_der5557 = t813 ; } else {
intermediate_der5557 = ( 1.0 - t816 ) * 3.66 + t813 * t816 ; } t817 =
intermediate_der5557 * 0.031415926535897927 / ( intermediate_der8069 + 1.0 ==
0.0 ? 1.0E-16 : intermediate_der8069 + 1.0 ) / 7.8539816339744827E-5 / (
intermediate_der8498 == 0.0 ? 1.0E-16 : intermediate_der8498 ) ;
intermediate_der8390 = ( X [ 12ULL ] - intermediate_der3734 ) * ( 1.0 -
pmf_exp ( - t817 ) ) ; tlu2_2d_linear_linear_value ( & mc_efOut [ 0ULL ] , &
t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = mc_efOut [
0 ] ; t820 = t697_idx_0 ; t706 [ 0ULL ] = X [ 133ULL ] ;
tlu2_linear_linear_prelookup ( & nc_efOut . mField0 [ 0ULL ] , & nc_efOut .
mField1 [ 0ULL ] , & nc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = nc_efOut ; tlu2_2d_linear_linear_value ( & oc_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t45 . mField0 [ 0ULL ] , &
t45 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = oc_efOut [
0 ] ; intermediate_der5594 = t697_idx_0 ; t706 [ 0ULL ] = X [ 135ULL ] ;
tlu2_linear_linear_prelookup ( & pc_efOut . mField0 [ 0ULL ] , & pc_efOut .
mField1 [ 0ULL ] , & pc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = pc_efOut ; tlu2_2d_linear_linear_value ( & qc_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t2 . mField0 [ 0ULL ] , & t2
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t305 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = qc_efOut [ 0 ] ;
intermediate_der5597 = t697_idx_0 ; t706 [ 0ULL ] = X [ 11ULL ] ;
tlu2_linear_linear_prelookup ( & rc_efOut . mField0 [ 0ULL ] , & rc_efOut .
mField1 [ 0ULL ] , & rc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t31 = rc_efOut ; tlu2_2d_linear_linear_value ( & sc_efOut [ 0ULL ] , & t31 .
mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , & t47 . mField0 [ 0ULL ] , &
t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = sc_efOut [
0 ] ; intermediate_der10282 = t697_idx_0 ; tlu2_2d_linear_linear_value ( &
tc_efOut [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , &
t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField7 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = tc_efOut [ 0 ] ; intermediate_der10658 = t697_idx_0 ; t706 [
0ULL ] = X [ 140ULL ] ; tlu2_linear_linear_prelookup ( & uc_efOut . mField0 [
0ULL ] , & uc_efOut . mField1 [ 0ULL ] , & uc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t47 = uc_efOut ; t706 [ 0ULL ] = X [ 138ULL ] ;
tlu2_linear_linear_prelookup ( & vc_efOut . mField0 [ 0ULL ] , & vc_efOut .
mField1 [ 0ULL ] , & vc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = vc_efOut ; tlu2_2d_linear_linear_value ( & wc_efOut [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , & t67 . mField0 [ 0ULL ] , &
t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = wc_efOut [
0 ] ; intermediate_der5598 = t697_idx_0 ; t706 [ 0ULL ] = X [ 137ULL ] ;
tlu2_linear_linear_prelookup ( & xc_efOut . mField0 [ 0ULL ] , & xc_efOut .
mField1 [ 0ULL ] , & xc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t2
= xc_efOut ; tlu2_2d_linear_linear_value ( & yc_efOut [ 0ULL ] , & t2 .
mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t305 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = yc_efOut [ 0 ] ;
Electrical_Cooling_System_Pump_convection_A_u_in = t697_idx_0 ; t706 [ 0ULL ]
= X [ 142ULL ] ; tlu2_linear_linear_prelookup ( & ad_efOut . mField0 [ 0ULL ]
, & ad_efOut . mField1 [ 0ULL ] , & ad_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t51 = ad_efOut ; tlu2_2d_linear_linear_value ( &
bd_efOut [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , &
t63 . mField0 [ 0ULL ] , & t63 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t305 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = bd_efOut [ 0 ] ; intermediate_der11607 = t697_idx_0 ;
intermediate_der6946 = ( intermediate_der5598 + t697_idx_0 ) / 2.0 ; t1762 =
X [ 158ULL ] * - 0.2 + 0.2 ; Fuel_Cell_Boost_Converter_L_i = X [ 172ULL ] *
1.0E-9 + X [ 19ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = - X [
198ULL ] + U_idx_4 * - 0.01 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = X [
24ULL ] >= 1.0 ? 1.0 : X [ 24ULL ] ; } intrm_sf_mf_95 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 *
4124.48151675695 ; intermediate_der10355 = ( X [ 21ULL ] / ( X [ 22ULL ] ==
0.0 ? 1.0E-16 : X [ 22ULL ] ) - X [ 199ULL ] / ( X [ 200ULL ] == 0.0 ?
1.0E-16 : X [ 200ULL ] ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intrm_sf_mf_95 / 7.8539816339744827E-5 ; if ( X [ 199ULL ] <=
216.59999999999997 ) { t826 = 216.59999999999997 ; } else { t826 = X [ 199ULL
] >= 623.15 ? 623.15 : X [ 199ULL ] ; } t762 = t826 * t826 ;
intermediate_der11504 = ( ( ( 1074.1165326382554 + t826 * -
0.22145652610641059 ) + t762 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) + ( (
1479.6504774710402 + t826 * 1.2002114337050787 ) + t762 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) + ( (
12825.281119789837 + t826 * 6.9647057412840034 ) + t762 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ; t827 =
intermediate_der11504 - intrm_sf_mf_95 ; t826 = intermediate_der11504 / (
t827 == 0.0 ? 1.0E-16 : t827 ) ; intermediate_der11504 = pmf_sqrt (
intermediate_der10355 * intermediate_der10355 * 9.999999999999999E-14 + fabs
( X [ 199ULL ] * t826 * intrm_sf_mf_95 ) * 1.0E-9 ) ; if ( X [ 201ULL ] <=
0.0 ) { t762 = 0.0 ; } else { t762 = X [ 201ULL ] >= 1.0 ? 1.0 : X [ 201ULL ]
; } if ( X [ 202ULL ] <= 0.0 ) { t827 = 0.0 ; } else { t827 = X [ 202ULL ] >=
1.0 ? 1.0 : X [ 202ULL ] ; } t706 [ 0ULL ] = X [ 21ULL ] ; t305 [ 0 ] = 52ULL
; tlu2_linear_nearest_prelookup ( & cd_efOut . mField0 [ 0ULL ] , & cd_efOut
. mField1 [ 0ULL ] , & cd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t46 = cd_efOut ; tlu2_1d_linear_nearest_value ( & dd_efOut [ 0ULL ] , & t46 .
mField0 [ 0ULL ] , & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField15 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = dd_efOut [
0 ] ; tlu2_1d_linear_nearest_value ( & ed_efOut [ 0ULL ] , & t46 . mField0 [
0ULL ] , & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField16 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = ed_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = fd_efOut [ 0 ] ;
intermediate_der9120 = ( ( ( 1.0 - t762 ) - t827 ) * t697_idx_0 + U_idx_1 *
t762 ) + t690_idx_0 * t827 ; t828 = X [ 200ULL ] * X [ 200ULL ] * t826 ;
intermediate_der11513 = - pmf_sqrt ( fabs ( t828 / ( intrm_sf_mf_95 == 0.0 ?
1.0E-16 : intrm_sf_mf_95 ) / ( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] )
) ) * 7.8539816339744827E-5 ; if ( intermediate_der11513 >= 0.0 ) {
intermediate_der11622 = intermediate_der11513 * 100000.0 ; } else {
intermediate_der11622 = - intermediate_der11513 * 100000.0 ; } t832 =
intermediate_der9120 * 7.8539816339744827E-5 ; intermediate_der11627 =
intermediate_der11622 * 0.01 / ( t832 == 0.0 ? 1.0E-16 : t832 ) ; t834 = X [
21ULL ] * intrm_sf_mf_95 ; t831 = X [ 22ULL ] / ( t834 == 0.0 ? 1.0E-16 :
t834 ) ; t836 = t831 * 1.5707963267948965E-8 ; intermediate_der7294 =
intermediate_der11513 * intermediate_der9120 * 35.2 / ( t836 == 0.0 ? 1.0E-16
: t836 ) ; t1771 = intermediate_der11627 >= 1.0 ? intermediate_der11627 : 1.0
; t837 = pmf_log10 ( 6.9 / ( t1771 == 0.0 ? 1.0E-16 : t1771 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1771 == 0.0 ? 1.0E-16 : t1771
) + 0.00017169489553429715 ) * 3.24 ; t839 = t831 * 1.2337005501361697E-10 ;
intermediate_der11622 = intermediate_der11513 * intermediate_der11622 * ( 1.0
/ ( t837 == 0.0 ? 1.0E-16 : t837 ) ) * 0.55 / ( t839 == 0.0 ? 1.0E-16 : t839
) ; t831 = ( intermediate_der11627 - 2000.0 ) / 2000.0 ; t1771 = t831 * t831
* 3.0 - t831 * t831 * t831 * 2.0 ; if ( intermediate_der11627 <= 2000.0 ) {
t831 = intermediate_der7294 * 1.0E-5 ; } else if ( intermediate_der11627 >=
4000.0 ) { t831 = intermediate_der11622 * 1.0E-5 ; } else { t831 = ( ( 1.0 -
t1771 ) * intermediate_der7294 + intermediate_der11622 * t1771 ) * 1.0E-5 ; }
intermediate_der11504 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der11504 / 7.8539816339744827E-5 * 0.00031622776601683789 + t831
; intermediate_der11622 = X [ 176ULL ] - X [ 22ULL ] ; t706 [ 0ULL ] = X [
21ULL ] ; tlu2_linear_linear_prelookup ( & gd_efOut . mField0 [ 0ULL ] , &
gd_efOut . mField1 [ 0ULL ] , & gd_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t51 = gd_efOut ; tlu2_1d_linear_linear_value ( &
hd_efOut [ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t697_idx_0 = hd_efOut [ 0 ] ; t831 = t697_idx_0 ;
tlu2_1d_linear_nearest_value ( & id_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = id_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = jd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & kd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = kd_efOut [ 0 ] ;
intermediate_der7294 = ( ( ( 1.0 - t762 ) - t827 ) * t697_idx_0 + U_idx_1 *
t762 ) + t690_idx_0 * t827 ; if ( X [ 178ULL ] <= 0.0 ) { t1771 = 0.0 ; }
else { t1771 = X [ 178ULL ] >= 1.0 ? 1.0 : X [ 178ULL ] ; } if ( X [ 177ULL ]
<= 0.0 ) { t837 = 0.0 ; } else { t837 = X [ 177ULL ] >= 1.0 ? 1.0 : X [
177ULL ] ; } t838 = ( ( ( 1.0 - t1771 ) - t837 ) * 296.802103844292 + t1771 *
461.523 ) + t837 * 4124.48151675695 ; intrm_sf_mf_133 = X [ 178ULL ] *
461.523 / ( t838 == 0.0 ? 1.0E-16 : t838 ) ; if ( intrm_sf_mf_133 <= 0.0 ) {
t841 = 0.0 ; } else { t841 = intrm_sf_mf_133 >= 1.0 ? 1.0 : intrm_sf_mf_133 ;
} intrm_sf_mf_133 = X [ 177ULL ] * 4124.48151675695 / ( t838 == 0.0 ? 1.0E-16
: t838 ) ; if ( intrm_sf_mf_133 <= 0.0 ) { t842 = 0.0 ; } else { t842 =
intrm_sf_mf_133 >= 1.0 ? 1.0 : intrm_sf_mf_133 ; } t706 [ 0ULL ] = X [ 175ULL
] ; tlu2_linear_nearest_prelookup ( & ld_efOut . mField0 [ 0ULL ] , &
ld_efOut . mField1 [ 0ULL ] , & ld_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t67 = ld_efOut ; tlu2_1d_linear_nearest_value ( &
md_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField23 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t697_idx_0 = md_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & nd_efOut [
0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; U_idx_1 = nd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & od_efOut [
0ULL ] , & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField25 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t690_idx_0 = od_efOut [ 0 ] ; intrm_sf_mf_133 = ( ( ( 1.0 - t841 ) - t842
) * t697_idx_0 + U_idx_1 * t841 ) + t690_idx_0 * t842 ;
tlu2_1d_linear_nearest_value ( & pd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = pd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & qd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = qd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & rd_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = rd_efOut [ 0 ] ; t843 = ( (
( 1.0 - t762 ) - t827 ) * t697_idx_0 + U_idx_1 * t762 ) + t690_idx_0 * t827 ;
tlu2_1d_linear_nearest_value ( & sd_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = sd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & td_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = td_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ud_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = ud_efOut [ 0 ] ; t762 = ( (
( 1.0 - t841 ) - t842 ) * t697_idx_0 + U_idx_1 * t841 ) + t690_idx_0 * t842 ;
t827 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 - (
- X [ 186ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & vd_efOut [ 0ULL ]
, & t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField15 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 =
vd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & wd_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = wd_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & xd_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL
] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = xd_efOut [ 0 ] ; t1385 =
intermediate_der9120 + ( ( ( ( 1.0 - t841 ) - t842 ) * t697_idx_0 + U_idx_1 *
t841 ) + t690_idx_0 * t842 ) ; t847 = t1385 / 2.0 * 7.8539816339744827E-5 ;
t841 = ( t827 >= 0.0 ? t827 : 0.0 ) * 0.01 / ( t847 == 0.0 ? 1.0E-16 : t847 )
; t842 = t841 >= 0.0 ? t841 : - t841 ; t844 = t842 > 1000.0 ? t842 : 1000.0 ;
t1386 = intrm_sf_mf_133 + t843 ; if ( t1386 / 2.0 > 0.5 ) {
intermediate_der8500 = ( intrm_sf_mf_133 + t843 ) / 2.0 ; } else {
intermediate_der8500 = 0.5 ; } t850 = pmf_log10 ( 6.9 / ( t844 == 0.0 ?
1.0E-16 : t844 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t844 == 0.0
? 1.0E-16 : t844 ) + 0.00017169489553429715 ) * 3.24 ; t846 = 1.0 / ( t850 ==
0.0 ? 1.0E-16 : t850 ) ; t1387 = ( pmf_pow ( intermediate_der8500 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t846 / 8.0 ) * 12.7 + 1.0 ; t847 =
( t844 - 1000.0 ) * ( t846 / 8.0 ) * intermediate_der8500 / ( t1387 == 0.0 ?
1.0E-16 : t1387 ) ; intermediate_der11730 = ( t842 - 2000.0 ) / 2000.0 ; t850
= intermediate_der11730 * intermediate_der11730 * 3.0 - intermediate_der11730
* intermediate_der11730 * intermediate_der11730 * 2.0 ; if ( t842 <= 2000.0 )
{ t851 = 3.66 ; } else if ( t842 >= 4000.0 ) { t851 = t847 ; } else { t851 =
( 1.0 - t850 ) * 3.66 + t847 * t850 ; } t1388 = t851 * 0.031415926535897927 ;
intermediate_der8829 = t1386 / 2.0 ; if ( t842 > t1388 /
7.8539816339744827E-5 / ( intermediate_der8829 == 0.0 ? 1.0E-16 :
intermediate_der8829 ) / 30.0 ) { t1660 = ( intrm_sf_mf_133 + t843 ) / 2.0 ;
t853 = t851 * 0.031415926535897927 / ( t842 == 0.0 ? 1.0E-16 : t842 ) /
7.8539816339744827E-5 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ; } else { t853 =
30.0 ; } intermediate_der11651 = ( X [ 179ULL ] - X [ 175ULL ] ) * ( 1.0 -
pmf_exp ( - t853 ) ) ; if ( X [ 197ULL ] <= 0.0 ) { intermediate_der8829 =
0.0 ; } else { intermediate_der8829 = X [ 197ULL ] >= 1.0 ? 1.0 : X [ 197ULL
] ; } if ( X [ 196ULL ] <= 0.0 ) { t858 = 0.0 ; } else { t858 = X [ 196ULL ]
>= 1.0 ? 1.0 : X [ 196ULL ] ; } t1781 = ( ( ( 1.0 - intermediate_der8829 ) -
t858 ) * 296.802103844292 + intermediate_der8829 * 461.523 ) + t858 *
4124.48151675695 ; intermediate_der8829 = X [ 197ULL ] * 461.523 / ( t1781 ==
0.0 ? 1.0E-16 : t1781 ) ; if ( intermediate_der8829 <= 0.0 ) { t858 = 0.0 ; }
else { t858 = intermediate_der8829 >= 1.0 ? 1.0 : intermediate_der8829 ; }
intermediate_der8829 = X [ 196ULL ] * 4124.48151675695 / ( t1781 == 0.0 ?
1.0E-16 : t1781 ) ; if ( intermediate_der8829 <= 0.0 ) { t1781 = 0.0 ; } else
{ t1781 = intermediate_der8829 >= 1.0 ? 1.0 : intermediate_der8829 ; } t706 [
0ULL ] = X [ 194ULL ] ; tlu2_linear_nearest_prelookup ( & yd_efOut . mField0
[ 0ULL ] , & yd_efOut . mField1 [ 0ULL ] , & yd_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL
] , & t75 [ 0ULL ] ) ; t46 = yd_efOut ; tlu2_1d_linear_nearest_value ( &
ae_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField23 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t697_idx_0 = ae_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & be_efOut [
0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; U_idx_1 = be_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ce_efOut [
0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField25 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t690_idx_0 = ce_efOut [ 0 ] ; intermediate_der8829 = ( ( ( 1.0 - t858 ) -
t1781 ) * t697_idx_0 + U_idx_1 * t858 ) + t690_idx_0 * t1781 ;
tlu2_1d_linear_nearest_value ( & de_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = de_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ee_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = ee_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fe_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = fe_efOut [ 0 ] ; t860 = ( (
( 1.0 - t858 ) - t1781 ) * t697_idx_0 + U_idx_1 * t858 ) + t690_idx_0 * t1781
; tlu2_1d_linear_nearest_value ( & ge_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL
] , & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ge_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & he_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = he_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ie_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = ie_efOut [ 0 ] ; t1389 =
intermediate_der9120 + ( ( ( ( 1.0 - t858 ) - t1781 ) * t697_idx_0 + U_idx_1
* t858 ) + t690_idx_0 * t1781 ) ; t1734 = t1389 / 2.0 * 7.8539816339744827E-5
; t858 = - ( t827 <= 0.0 ? t827 : 0.0 ) * 0.01 / ( t1734 == 0.0 ? 1.0E-16 :
t1734 ) ; t1781 = t858 >= 0.0 ? t858 : - t858 ; t1665 = t1781 > 1000.0 ?
t1781 : 1000.0 ; t1390 = t843 + intermediate_der8829 ; if ( t1390 / 2.0 > 0.5
) { t1753 = ( t843 + intermediate_der8829 ) / 2.0 ; } else { t1753 = 0.5 ; }
t1454 = pmf_log10 ( 6.9 / ( t1665 == 0.0 ? 1.0E-16 : t1665 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1665 == 0.0 ? 1.0E-16 : t1665
) + 0.00017169489553429715 ) * 3.24 ; t1660 = 1.0 / ( t1454 == 0.0 ? 1.0E-16
: t1454 ) ; t1391 = ( pmf_pow ( t1753 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1660 / 8.0 ) * 12.7 + 1.0 ; t1408 = ( t1665 - 1000.0 ) * ( t1660
/ 8.0 ) * t1753 / ( t1391 == 0.0 ? 1.0E-16 : t1391 ) ; t1421 = ( t1781 -
2000.0 ) / 2000.0 ; t1430 = t1421 * t1421 * 3.0 - t1421 * t1421 * t1421 * 2.0
; if ( t1781 <= 2000.0 ) { t1734 = 3.66 ; } else if ( t1781 >= 4000.0 ) {
t1734 = t1408 ; } else { t1734 = ( 1.0 - t1430 ) * 3.66 + t1408 * t1430 ; }
t1392 = t1734 * 0.031415926535897927 ; t878 = t1390 / 2.0 ; if ( t1781 >
t1392 / 7.8539816339744827E-5 / ( t878 == 0.0 ? 1.0E-16 : t878 ) / 30.0 ) {
t1553 = ( t843 + intermediate_der8829 ) / 2.0 ; t1372 = t1734 *
0.031415926535897927 / ( t1781 == 0.0 ? 1.0E-16 : t1781 ) /
7.8539816339744827E-5 / ( t1553 == 0.0 ? 1.0E-16 : t1553 ) ; } else { t1372 =
30.0 ; } t1454 = ( X [ 179ULL ] - X [ 194ULL ] ) * ( 1.0 - pmf_exp ( - t1372
) ) ; t872 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) ; tlu2_1d_linear_linear_value ( & je_efOut [ 0ULL ]
, & t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 =
je_efOut [ 0 ] ; t874 = t697_idx_0 ; tlu2_1d_linear_linear_value ( & ke_efOut
[ 0ULL ] , & t51 . mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField27 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t697_idx_0 = ke_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = ( ( ( ( 1.0
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) * t874 +
t831 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) +
t697_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1
) - X [ 21ULL ] * intrm_sf_mf_95 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = t874 - X [
21ULL ] * 0.296802103844292 ; t874 = t697_idx_0 - X [ 21ULL ] *
4.12448151675695 ; t877 = t831 - X [ 21ULL ] * 0.461523 ; t831 = U_idx_3 *
0.031415926535897927 ; if ( t831 * 0.0001 <= 7.8539816339744857E-13 ) { t878
= 7.8539816339744857E-13 ; } else if ( t831 * 0.0001 >= 3.1415926535897929E-6
) { t878 = 3.1415926535897929E-6 ; } else { t878 = t831 * 0.0001 ; } t1673 =
t878 / 7.8539816339744827E-5 ; if ( X [ 221ULL ] <= 0.0 ) { t880 = 0.0 ; }
else { t880 = X [ 221ULL ] >= 1.0 ? 1.0 : X [ 221ULL ] ; } if ( X [ 222ULL ]
<= 0.0 ) { t881 = 0.0 ; } else { t881 = X [ 222ULL ] >= 1.0 ? 1.0 : X [
222ULL ] ; } t882 = ( ( ( 1.0 - t880 ) - t881 ) * 296.802103844292 + t880 *
461.523 ) + t881 * 4124.48151675695 ; t886 = X [ 219ULL ] * t882 ; t883 = X [
220ULL ] / ( t886 == 0.0 ? 1.0E-16 : t886 ) ; t1553 = X [ 220ULL ] / ( X [
195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [ 219ULL ]
== 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t1527 = X [ 220ULL ] / 1.01325 * ( X [
224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t1556 = ( X [
195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ; t1528 = ( 1.0 - t1673 )
* ( 1.0 - t1673 ) ; intrm_sf_mf_543 = t1556 * t1528 ; t1468 = ( t1673 + 1.0 )
* ( 1.0 - t1673 * t1553 ) - ( 1.0 - t1673 * t1527 ) * t1673 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( X [ 195ULL
] - 1.01325 ) * ( t1468 >= t1528 ? t1468 : t1528 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = ( X [
195ULL ] - 1.01325 ) / ( t1556 == 0.0 ? 1.0E-16 : t1556 ) ; t1470 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 * 2.0 ; if (
X [ 195ULL ] - 1.01325 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 =
intrm_sf_mf_543 ; } else if ( X [ 195ULL ] - 1.01325 >= t1556 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = ( 1.0 -
t1470 ) * intrm_sf_mf_543 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 * t1470 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( t1673 +
1.0 ) * ( 1.0 - t1673 * t1527 ) - ( 1.0 - t1673 * t1553 ) * t1673 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.01325 -
X [ 195ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >= t1528 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 : t1528 ) ;
intrm_sf_mf_545 = ( 1.01325 - X [ 195ULL ] ) / ( t1556 == 0.0 ? 1.0E-16 :
t1556 ) ; t1471 = intrm_sf_mf_545 * intrm_sf_mf_545 * 3.0 - intrm_sf_mf_545 *
intrm_sf_mf_545 * intrm_sf_mf_545 * 2.0 ; if ( 1.01325 - X [ 195ULL ] <= 0.0
) { intrm_sf_mf_545 = intrm_sf_mf_543 ; } else if ( 1.01325 - X [ 195ULL ] >=
t1556 ) { intrm_sf_mf_545 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } else {
intrm_sf_mf_545 = ( 1.0 - t1471 ) * intrm_sf_mf_543 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t1471 ; } if
( X [ 195ULL ] > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 195ULL ]
< 1.01325 ? intrm_sf_mf_545 : intrm_sf_mf_543 ; } if ( X [ 219ULL ] <=
216.59999999999997 ) { intrm_sf_mf_543 = 216.59999999999997 ; } else {
intrm_sf_mf_543 = X [ 219ULL ] >= 623.15 ? 623.15 : X [ 219ULL ] ; } t765 =
intrm_sf_mf_543 * intrm_sf_mf_543 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = ( ( (
1074.1165326382554 + intrm_sf_mf_543 * - 0.22145652610641059 ) + t765 *
0.0003721298010901061 ) * ( ( 1.0 - t880 ) - t881 ) + ( ( 1479.6504774710402
+ intrm_sf_mf_543 * 1.2002114337050787 ) + t765 * - 0.00038614513167845434 )
* t880 ) + ( ( 12825.281119789837 + intrm_sf_mf_543 * 6.9647057412840034 ) +
t765 * - 0.0070524868246844051 ) * t881 ; t897 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 - t882 ; t898
= X [ 220ULL ] * X [ 220ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 / ( t897 ==
0.0 ? 1.0E-16 : t897 ) ) ; t880 = pmf_sqrt ( fabs ( t898 / ( t882 == 0.0 ?
1.0E-16 : t882 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) *
t878 * 0.64 ; t901 = t883 * 2.0 ; t881 = ( X [ 195ULL ] - 1.01325 ) *
pmf_sqrt ( fabs ( t901 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t878 * 0.64 ; if ( X [ 36ULL ] <= 0.0 ) { intrm_sf_mf_543 = 0.0 ; } else
{ intrm_sf_mf_543 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL
] <= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43
= 0.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = X [ 35ULL ]
>= 1.0 ? 1.0 : X [ 35ULL ] ; } intrm_sf_mf_545 = ( ( ( 1.0 - intrm_sf_mf_543
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) *
296.802103844292 + intrm_sf_mf_543 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
4124.48151675695 ; t706 [ 0ULL ] = X [ 34ULL ] ; tlu2_linear_linear_prelookup
( & le_efOut . mField0 [ 0ULL ] , & le_efOut . mField1 [ 0ULL ] , & le_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = le_efOut ;
tlu2_1d_linear_linear_value ( & me_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = me_efOut [ 0 ] ; t765 =
t697_idx_0 ; tlu2_1d_linear_linear_value ( & ne_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ne_efOut [
0 ] ; t897 = t697_idx_0 ; tlu2_1d_linear_linear_value ( & oe_efOut [ 0ULL ] ,
& t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField27 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 =
oe_efOut [ 0 ] ; intrm_sf_mf_543 = ( ( ( ( 1.0 - intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) * t897 +
t765 * intrm_sf_mf_543 ) + t697_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) - X [ 34ULL
] * intrm_sf_mf_545 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = t897 - X [
34ULL ] * 0.296802103844292 ; t897 = t697_idx_0 - X [ 34ULL ] *
4.12448151675695 ; t899 = t765 - X [ 34ULL ] * 0.461523 ; t765 = pmf_sqrt ( X
[ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( X [ 322ULL
] * 0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X
[ 41ULL ] <= 0.0 ) { zc_int17 = 0.0 ; } else { zc_int17 = X [ 41ULL ] >= 1.0
? 1.0 : X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = X [ 42ULL
] >= 1.0 ? 1.0 : X [ 42ULL ] ; } zc_int174 = ( ( ( 1.0 - zc_int17 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) *
296.802103844292 + zc_int17 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 *
259.836612622973 ; if ( X [ 328ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = X [
328ULL ] >= 1.0 ? 1.0 : X [ 328ULL ] ; } if ( X [ 329ULL ] <= 0.0 ) {
zc_int179 = 0.0 ; } else { zc_int179 = X [ 329ULL ] >= 1.0 ? 1.0 : X [ 329ULL
] ; } t706 [ 0ULL ] = X [ 39ULL ] ; tlu2_linear_nearest_prelookup ( &
pe_efOut . mField0 [ 0ULL ] , & pe_efOut . mField1 [ 0ULL ] , & pe_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t46 = pe_efOut ;
tlu2_1d_linear_nearest_value ( & qe_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = qe_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & re_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = re_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & se_efOut [ 0ULL ] , & t46 . mField0 [ 0ULL ]
, & t46 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = se_efOut [ 0 ] ; zc_int180
= ( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43
) - zc_int179 ) * t697_idx_0 + U_idx_1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) +
t690_idx_0 * zc_int179 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = X [ 39ULL ]
* zc_int174 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43
= X [ 40ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) ;
zc_int179 = - ( ( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ]
) - X [ 330ULL ] / ( X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] ) ) * X [
313ULL ] * zc_int174 ) / 0.0019634954084936209 ; if ( X [ 330ULL ] <=
216.59999999999997 ) { t902 = 216.59999999999997 ; } else { t902 = X [ 330ULL
] >= 623.15 ? 623.15 : X [ 330ULL ] ; } t904 = t902 * t902 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = ( ( (
1074.1165326382554 + t902 * - 0.22145652610641059 ) + t904 *
0.0003721298010901061 ) * ( ( 1.0 - zc_int17 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) + ( (
1479.6504774710402 + t902 * 1.2002114337050787 ) + t904 * -
0.00038614513167845434 ) * zc_int17 ) + ( ( 900.639412248396 + t902 * -
0.044484923911441127 ) + t904 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ; t909 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 - zc_int174 ;
zc_int17 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 /
( t909 == 0.0 ? 1.0E-16 : t909 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = pmf_sqrt (
zc_int179 * zc_int179 * 9.999999999999999E-14 + fabs ( X [ 330ULL ] *
zc_int17 * zc_int174 ) * 1.0E-9 ) ; t910 = X [ 331ULL ] * X [ 331ULL ] *
zc_int17 ; t902 = - pmf_sqrt ( fabs ( t910 / ( zc_int174 == 0.0 ? 1.0E-16 :
zc_int174 ) / ( X [ 330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) *
0.0019634954084936209 ; if ( t902 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = t902 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = - t902 *
100000.0 ; } t914 = zc_int180 * 0.0019634954084936209 ; t904 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 0.05 / (
t914 == 0.0 ? 1.0E-16 : t914 ) ; t916 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
9.8174770424681068E-6 ; t907 = t902 * zc_int180 * 35.2 / ( t916 == 0.0 ?
1.0E-16 : t916 ) ; t908 = t904 >= 1.0 ? t904 : 1.0 ; t917 = pmf_log10 ( 6.9 /
( t908 == 0.0 ? 1.0E-16 : t908 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9
/ ( t908 == 0.0 ? 1.0E-16 : t908 ) + 2.8767404433520813E-5 ) * 3.24 ; t919 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
3.855314219175531E-7 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = t902 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * ( 1.0 / (
t917 == 0.0 ? 1.0E-16 : t917 ) ) * 0.55 / ( t919 == 0.0 ? 1.0E-16 : t919 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = ( t904 -
2000.0 ) / 2000.0 ; t908 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 2.0 ; if (
t904 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = t907 *
1.0E-5 ; } else if ( t904 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 * 1.0E-5 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = ( (
1.0 - t908 ) * t907 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 * t908 ) *
1.0E-5 ; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = -
( X [ 313ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) /
0.0019634954084936209 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - X [ 40ULL ]
; if ( X [ 324ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = X [
324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X [ 323ULL ] <= 0.0 ) { t907 =
0.0 ; } else { t907 = X [ 323ULL ] >= 1.0 ? 1.0 : X [ 323ULL ] ; } t908 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) -
t907 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 461.523 ) +
t907 * 259.836612622973 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = pmf_sqrt (
X [ 313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 ) ; if ( X [ 322ULL ] *
0.0019634954084936209 <= 1.9634954084936209E-11 ) { t907 =
1.9634954084936209E-11 ; } else if ( X [ 322ULL ] * 0.0019634954084936209 >=
0.0012566370614359179 ) { t907 = 0.0012566370614359179 ; } else { t907 = X [
322ULL ] * 0.0019634954084936209 ; } t909 = t907 / 0.0019634954084936209 ; if
( X [ 345ULL ] <= 0.0 ) { t911 = 0.0 ; } else { t911 = X [ 345ULL ] >= 1.0 ?
1.0 : X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 = X [
346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ; } t915 = ( ( ( 1.0 - t911 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 ) *
296.802103844292 + t911 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 *
259.836612622973 ; t923 = X [ 343ULL ] * t915 ; t917 = X [ 344ULL ] / ( t923
== 0.0 ? 1.0E-16 : t923 ) ; t1473 = X [ 344ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; t1474 =
X [ 344ULL ] / 1.01325 * ( X [ 348ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X
[ 343ULL ] ) ) ; t922 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 + 1.01325 ) /
2.0 * 0.0010000000000000009 ; t921 = ( 1.0 - t909 ) * ( 1.0 - t909 ) ; t923 =
t922 * t921 ; t1477 = ( t909 + 1.0 ) * ( 1.0 - t909 * t1473 ) - ( 1.0 - t909
* t1474 ) * t909 * 2.0 ; t930 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( t1477 >= t921 ? t1477 : t921 ) ; t1479 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t922 == 0.0 ? 1.0E-16 : t922 ) ; t931 = t1479 * t1479 * 3.0 - t1479 * t1479
* t1479 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { intrm_sf_mf_1142 = t923 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t922 ) { intrm_sf_mf_1142 = t930 ; } else { intrm_sf_mf_1142 = ( 1.0 - t931 )
* t923 + t930 * t931 ; } t1481 = ( t909 + 1.0 ) * ( 1.0 - t909 * t1474 ) - (
1.0 - t909 * t1473 ) * t909 * 2.0 ; t1473 = ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) * ( t1481 >=
t921 ? t1481 : t921 ) ; t1474 = ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / ( t922 ==
0.0 ? 1.0E-16 : t922 ) ; t1482 = t1474 * t1474 * 3.0 - t1474 * t1474 * t1474
* 2.0 ; if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t923 ; }
else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t922 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t1473 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = (
1.0 - t1482 ) * t923 + t1473 * t1482 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 =
intrm_sf_mf_1142 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 : t923 ; } if
( X [ 343ULL ] <= 216.59999999999997 ) { intrm_sf_mf_1142 =
216.59999999999997 ; } else { intrm_sf_mf_1142 = X [ 343ULL ] >= 623.15 ?
623.15 : X [ 343ULL ] ; } t771 = intrm_sf_mf_1142 * intrm_sf_mf_1142 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = ( ( (
1074.1165326382554 + intrm_sf_mf_1142 * - 0.22145652610641059 ) + t771 *
0.0003721298010901061 ) * ( ( 1.0 - t911 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 ) + ( (
1479.6504774710402 + intrm_sf_mf_1142 * 1.2002114337050787 ) + t771 * -
0.00038614513167845434 ) * t911 ) + ( ( 900.639412248396 + intrm_sf_mf_1142 *
- 0.044484923911441127 ) + t771 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 ; t933 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 - t915 ; t934
= X [ 344ULL ] * X [ 344ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 / ( t933 ==
0.0 ? 1.0E-16 : t933 ) ) ; t911 = pmf_sqrt ( fabs ( t934 / ( t915 == 0.0 ?
1.0E-16 : t915 ) / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ) *
t907 * 0.64 ; t937 = t917 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
pmf_sqrt ( fabs ( t937 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * t907 * 0.64 ; if ( X [ 53ULL ] <= 0.0 ) { intrm_sf_mf_1142 = 0.0 ; } else
{ intrm_sf_mf_1142 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; } if ( X [
52ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = X [
52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t771 = ( ( ( 1.0 - intrm_sf_mf_1142 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) *
296.802103844292 + intrm_sf_mf_1142 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 *
259.836612622973 ; t706 [ 0ULL ] = X [ 51ULL ] ; tlu2_linear_linear_prelookup
( & te_efOut . mField0 [ 0ULL ] , & te_efOut . mField1 [ 0ULL ] , & te_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [
0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = te_efOut ;
tlu2_1d_linear_linear_value ( & ue_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ue_efOut [ 0 ] ; t933 =
t697_idx_0 ; tlu2_1d_linear_linear_value ( & ve_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ve_efOut [
0 ] ; t935 = t697_idx_0 ; tlu2_1d_linear_linear_value ( & we_efOut [ 0ULL ] ,
& t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField31 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 =
we_efOut [ 0 ] ; intrm_sf_mf_1142 = ( ( ( ( 1.0 - intrm_sf_mf_1142 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) * t935 +
t933 * intrm_sf_mf_1142 ) + t697_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) - X [ 51ULL
] * t771 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t935 - X [
51ULL ] * 0.296802103844292 ; t935 = t697_idx_0 - X [ 51ULL ] *
0.25983661262297303 ; t1483 = - X [ 434ULL ] + U_idx_10 * - 2.0 ; t1484 =
pmf_sqrt ( t1483 * t1483 + 6.4274470286298274E-9 ) ; t706 [ 0ULL ] = X [
433ULL ] ; t574 [ 0 ] = 11ULL ; tlu2_linear_linear_prelookup ( & xe_efOut .
mField0 [ 0ULL ] , & xe_efOut . mField1 [ 0ULL ] , & xe_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t706 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t45 = xe_efOut ; t706 [ 0ULL ] = 1.01325 ;
t407 [ 0 ] = 12ULL ; tlu2_linear_linear_prelookup ( & ye_efOut . mField0 [
0ULL ] , & ye_efOut . mField1 [ 0ULL ] , & ye_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t706 [ 0ULL ] , & t407 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t67 = ye_efOut ; tlu2_2d_linear_linear_value ( &
af_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , &
t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t697_idx_0 = af_efOut [ 0 ] ; t1485 = t697_idx_0 ; t706 [ 0ULL ] = X [ 429ULL
] ; tlu2_linear_linear_prelookup ( & bf_efOut . mField0 [ 0ULL ] , & bf_efOut
. mField1 [ 0ULL ] , & bf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t51 = bf_efOut ; tlu2_2d_linear_linear_value ( & cf_efOut [ 0ULL ] , & t51 .
mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , & t67 . mField0 [ 0ULL ] , &
t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , &
t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = cf_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 =
t697_idx_0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 =
U_idx_10 * 2.0 ; t1486 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
1.2620262729050631E-10 ) ; t706 [ 0ULL ] = X [ 453ULL ] ;
tlu2_linear_linear_prelookup ( & df_efOut . mField0 [ 0ULL ] , & df_efOut .
mField1 [ 0ULL ] , & df_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t58 = df_efOut ; tlu2_2d_linear_linear_value ( & ef_efOut [ 0ULL ] , & t58 .
mField0 [ 0ULL ] , & t58 . mField2 [ 0ULL ] , & t67 . mField0 [ 0ULL ] , &
t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ef_efOut [
0 ] ; t1487 = t697_idx_0 ; t706 [ 0ULL ] = X [ 455ULL ] ;
tlu2_linear_linear_prelookup ( & ff_efOut . mField0 [ 0ULL ] , & ff_efOut .
mField1 [ 0ULL ] , & ff_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = ff_efOut ; t706 [ 0ULL ] = X [ 451ULL ] ; tlu2_linear_linear_prelookup
( & gf_efOut . mField0 [ 0ULL ] , & gf_efOut . mField1 [ 0ULL ] , & gf_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t706 [
0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t58 = gf_efOut ;
tlu2_2d_linear_linear_value ( & hf_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = hf_efOut [ 0 ] ; t1488 =
t697_idx_0 ; t706 [ 0ULL ] = X [ 450ULL ] ; tlu2_linear_linear_prelookup ( &
if_efOut . mField0 [ 0ULL ] , & if_efOut . mField1 [ 0ULL ] , & if_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = if_efOut ;
tlu2_2d_linear_linear_value ( & jf_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = jf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 = t697_idx_0
; t1489 = ( t1487 + t1488 ) / 2.0 ; t706 [ 0ULL ] = X [ 450ULL ] ;
tlu2_linear_nearest_prelookup ( & kf_efOut . mField0 [ 0ULL ] , & kf_efOut .
mField1 [ 0ULL ] , & kf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t45 = kf_efOut ; t706 [ 0ULL ] = X [ 60ULL ] ; tlu2_linear_nearest_prelookup
( & lf_efOut . mField0 [ 0ULL ] , & lf_efOut . mField1 [ 0ULL ] , & lf_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t706 [
0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t31 = lf_efOut ;
tlu2_2d_linear_nearest_value ( & mf_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = mf_efOut [ 0 ] ; t938 =
t697_idx_0 ; t706 [ 0ULL ] = X [ 436ULL ] ; tlu2_linear_nearest_prelookup ( &
nf_efOut . mField0 [ 0ULL ] , & nf_efOut . mField1 [ 0ULL ] , & nf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t706 [
0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t2 = nf_efOut ;
tlu2_2d_linear_nearest_value ( & of_efOut [ 0ULL ] , & t2 . mField0 [ 0ULL ]
, & t2 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , & t574 [ 0ULL ] , & t407
[ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = of_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 = t697_idx_0 ;
t706 [ 0ULL ] = X [ 61ULL ] ; tlu2_linear_nearest_prelookup ( & pf_efOut .
mField0 [ 0ULL ] , & pf_efOut . mField1 [ 0ULL ] , & pf_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t706 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 = pf_efOut ;
tlu2_2d_linear_nearest_value ( & qf_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = qf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 = t697_idx_0 ;
tlu2_2d_linear_nearest_value ( & rf_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = rf_efOut [ 0 ] ; U_idx_7 =
t697_idx_0 ; intrm_sf_mf_1336 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 - ( - X [
442ULL ] ) ) / 2.0 ; tlu2_2d_linear_nearest_value ( & sf_efOut [ 0ULL ] , &
t67 . mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ]
, & t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 ,
& t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = sf_efOut
[ 0 ] ; t939 = t697_idx_0 ; t940 = intrm_sf_mf_1336 * 0.0028301886792452828 ;
t941 = t697_idx_0 * 0.00093750000000000007 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 = t940 / (
t941 == 0.0 ? 1.0E-16 : t941 ) ; t1490 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
2.4102926357361849E-12 ) ; t706 [ 0ULL ] = X [ 456ULL ] ;
tlu2_linear_linear_prelookup ( & tf_efOut . mField0 [ 0ULL ] , & tf_efOut .
mField1 [ 0ULL ] , & tf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = tf_efOut ; tlu2_2d_linear_linear_value ( & uf_efOut [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , &
t58 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = uf_efOut [
0 ] ; t1491 = t697_idx_0 ; t706 [ 0ULL ] = X [ 61ULL ] ;
tlu2_linear_linear_prelookup ( & vf_efOut . mField0 [ 0ULL ] , & vf_efOut .
mField1 [ 0ULL ] , & vf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t706 [ 0ULL ] , & t574 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t51 = vf_efOut ; t706 [ 0ULL ] = X [ 60ULL ] ; tlu2_linear_linear_prelookup (
& wf_efOut . mField0 [ 0ULL ] , & wf_efOut . mField1 [ 0ULL ] , & wf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t706 [
0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t46 = wf_efOut ;
tlu2_2d_linear_linear_value ( & xf_efOut [ 0ULL ] , & t51 . mField0 [ 0ULL ]
, & t51 . mField2 [ 0ULL ] , & t46 . mField0 [ 0ULL ] , & t46 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = xf_efOut [ 0 ] ; U_idx_10 =
t697_idx_0 ; tlu2_2d_linear_nearest_value ( & yf_efOut [ 0ULL ] , & t45 .
mField0 [ 0ULL ] , & t45 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , &
t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , &
t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = yf_efOut [
0 ] ; U_idx_3 = t697_idx_0 ; tlu2_2d_linear_nearest_value ( & ag_efOut [ 0ULL
] , & t2 . mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , & t31 . mField0 [
0ULL ] , & t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField40 , & t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0
= ag_efOut [ 0 ] ; intrm_sf_mf_1348 = t697_idx_0 ;
tlu2_2d_linear_nearest_value ( & bg_efOut [ 0ULL ] , & t45 . mField0 [ 0ULL ]
, & t45 . mField2 [ 0ULL ] , & t31 . mField0 [ 0ULL ] , & t31 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t574 [ 0ULL ] , &
t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = bg_efOut [ 0 ] ;
intrm_sf_mf_1324 = t697_idx_0 ; tlu2_2d_linear_nearest_value ( & cg_efOut [
0ULL ] , & t2 . mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , & t31 . mField0
[ 0ULL ] , & t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField41 , & t574 [ 0ULL ] , & t407 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0
= cg_efOut [ 0 ] ; intrm_sf_mf_1337 = t697_idx_0 ; t1492 = ( X [ 485ULL ] * -
0.7999998 + U_idx_11 * 7.9999980000000006 ) + 9.9999999947364415E-9 ; if (
t1492 * 7.8539816339744827E-5 <= 7.8539816339744857E-13 ) { intrm_sf_mf_1534
= 7.8539816339744857E-13 ; } else if ( t1492 * 7.8539816339744827E-5 >=
3.1415926535897929E-6 ) { intrm_sf_mf_1534 = 3.1415926535897929E-6 ; } else {
intrm_sf_mf_1534 = t1492 * 7.8539816339744827E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 =
intrm_sf_mf_1534 / 7.8539816339744827E-5 ; if ( X [ 508ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 = X [
508ULL ] >= 1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 = X [
509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } intrm_sf_mf_1543 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 *
4124.48151675695 ; t943 = X [ 506ULL ] * intrm_sf_mf_1543 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 = X [ 507ULL
] / ( t943 == 0.0 ? 1.0E-16 : t943 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 = X [ 507ULL
] / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) * ( X [ 510ULL ] / ( X [
506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; t945 = X [ 507ULL ] / ( X [
485ULL ] == 0.0 ? 1.0E-16 : X [ 485ULL ] ) * ( X [ 511ULL ] / ( X [ 506ULL ]
== 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; t949 = ( X [ 64ULL ] + X [ 485ULL ] ) /
2.0 * 0.0010000000000000009 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 ) ; U_idx_1 =
t949 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ; t952
= ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) *
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * t945 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 = ( X [ 64ULL
] - X [ 485ULL ] ) * ( t952 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ? t952 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ) ;
intrm_sf_mf_9 = ( X [ 64ULL ] - X [ 485ULL ] ) / ( t949 == 0.0 ? 1.0E-16 :
t949 ) ; t953 = intrm_sf_mf_9 * intrm_sf_mf_9 * 3.0 - intrm_sf_mf_9 *
intrm_sf_mf_9 * intrm_sf_mf_9 * 2.0 ; if ( X [ 64ULL ] - X [ 485ULL ] <= 0.0
) { intrm_sf_mf_9 = U_idx_1 ; } else if ( X [ 64ULL ] - X [ 485ULL ] >= t949
) { intrm_sf_mf_9 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 ; } else {
intrm_sf_mf_9 = ( 1.0 - t953 ) * U_idx_1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 * t953 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * t945
) - ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 = ( X [
485ULL ] - X [ 64ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = ( X [
485ULL ] - X [ 64ULL ] ) / ( t949 == 0.0 ? 1.0E-16 : t949 ) ; t954 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 * 2.0 ; if (
X [ 485ULL ] - X [ 64ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = U_idx_1 ; }
else if ( X [ 485ULL ] - X [ 64ULL ] >= t949 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = ( 1.0 -
t954 ) * U_idx_1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 * t954 ; } if
( X [ 64ULL ] > X [ 485ULL ] ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 =
intrm_sf_mf_9 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 = X [ 64ULL ]
< X [ 485ULL ] ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 : U_idx_1 ; }
if ( X [ 506ULL ] <= 216.59999999999997 ) { U_idx_1 = 216.59999999999997 ; }
else { U_idx_1 = X [ 506ULL ] >= 623.15 ? 623.15 : X [ 506ULL ] ; } t774 =
U_idx_1 * U_idx_1 ; intrm_sf_mf_9 = ( ( ( 1074.1165326382554 + U_idx_1 * -
0.22145652610641059 ) + t774 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 ) + ( (
1479.6504774710402 + U_idx_1 * 1.2002114337050787 ) + t774 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ) + ( (
12825.281119789837 + U_idx_1 * 6.9647057412840034 ) + t774 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 ; t955 =
intrm_sf_mf_9 - intrm_sf_mf_1543 ; t956 = X [ 507ULL ] * X [ 507ULL ] * (
intrm_sf_mf_9 / ( t955 == 0.0 ? 1.0E-16 : t955 ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 = pmf_sqrt (
fabs ( t956 / ( intrm_sf_mf_1543 == 0.0 ? 1.0E-16 : intrm_sf_mf_1543 ) / ( X
[ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) * intrm_sf_mf_1534 * 0.64 ;
t959 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 * 2.0
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 = ( X [
64ULL ] - X [ 485ULL ] ) * pmf_sqrt ( fabs ( t959 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ) )
) * intrm_sf_mf_1534 * 0.64 ; t706 [ 0ULL ] = X [ 74ULL ] ;
tlu2_linear_linear_prelookup ( & dg_efOut . mField0 [ 0ULL ] , & dg_efOut .
mField1 [ 0ULL ] , & dg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = dg_efOut ; tlu2_1d_linear_linear_value ( & eg_efOut [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = eg_efOut [
0 ] ; intrm_sf_mf_9 = t697_idx_0 ; if ( X [ 76ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = X [
76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) { t774 = 0.0
; } else { t774 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; } t955 = ( ( ( 1.0
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 ) - t774 )
* 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 * 461.523 ) +
t774 * 4124.48151675695 ; t957 = U_idx_4 * 0.01 ; t960 = pmf_sqrt ( t957 *
t957 + 1.4768645655431184E-13 ) ; tlu2_1d_linear_linear_value ( & fg_efOut [
0ULL ] , & t47 . mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ]
) ; t697_idx_0 = fg_efOut [ 0 ] ; t961 = t697_idx_0 ;
tlu2_1d_linear_linear_value ( & gg_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = gg_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 = ( ( ( ( 1.0
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 ) - t774 )
* t961 + intrm_sf_mf_9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 ) +
t697_idx_0 * t774 ) - X [ 74ULL ] * t955 * 0.001 ; t774 = t961 - X [ 74ULL ]
* 0.296802103844292 ; t961 = t697_idx_0 - X [ 74ULL ] * 4.12448151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 =
intrm_sf_mf_9 - X [ 74ULL ] * 0.461523 ; if ( X [ 576ULL ] <= 0.0 ) {
intrm_sf_mf_9 = 0.0 ; } else { intrm_sf_mf_9 = X [ 576ULL ] >= 1.0 ? 1.0 : X
[ 576ULL ] ; } if ( X [ 575ULL ] <= 0.0 ) { intrm_sf_mf_10 = 0.0 ; } else {
intrm_sf_mf_10 = X [ 575ULL ] >= 1.0 ? 1.0 : X [ 575ULL ] ; } zc_int367 = ( (
( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * 296.802103844292 + intrm_sf_mf_9
* 461.523 ) + intrm_sf_mf_10 * 4124.48151675695 ; t706 [ 0ULL ] = X [ 570ULL
] ; tlu2_linear_linear_prelookup ( & hg_efOut . mField0 [ 0ULL ] , & hg_efOut
. mField1 [ 0ULL ] , & hg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = hg_efOut ; tlu2_1d_linear_linear_value ( & ig_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ig_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & jg_efOut [ 0ULL ] , & t67 . mField0 [
0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = jg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & kg_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = kg_efOut [ 0 ] ; zc_int366
= ( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t697_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t690_idx_0 * intrm_sf_mf_10 ; t706 [ 0ULL ] = X [ 573ULL ]
; tlu2_linear_linear_prelookup ( & lg_efOut . mField0 [ 0ULL ] , & lg_efOut .
mField1 [ 0ULL ] , & lg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t2 = lg_efOut ; tlu2_1d_linear_linear_value ( & mg_efOut [ 0ULL ] , & t2 .
mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = mg_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & ng_efOut [ 0ULL ] , & t2 . mField0 [
0ULL ] , & t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = ng_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & og_efOut [ 0ULL ] , & t2 . mField0 [ 0ULL ] ,
& t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , &
t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = og_efOut [ 0 ] ; zc_int365 =
( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t697_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t690_idx_0 * intrm_sf_mf_10 ; t706 [ 0ULL ] = X [ 571ULL ]
; tlu2_linear_linear_prelookup ( & pg_efOut . mField0 [ 0ULL ] , & pg_efOut .
mField1 [ 0ULL ] , & pg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t51 = pg_efOut ; tlu2_1d_linear_linear_value ( & qg_efOut [ 0ULL ] , & t51 .
mField0 [ 0ULL ] , & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = qg_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & rg_efOut [ 0ULL ] , & t51 . mField0 [
0ULL ] , & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = rg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & sg_efOut [ 0ULL ] , & t51 . mField0 [ 0ULL ]
, & t51 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = sg_efOut [ 0 ] ; zc_int42 =
( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t697_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t690_idx_0 * intrm_sf_mf_10 ; t706 [ 0ULL ] = X [ 572ULL ]
; tlu2_linear_linear_prelookup ( & tg_efOut . mField0 [ 0ULL ] , & tg_efOut .
mField1 [ 0ULL ] , & tg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t2 = tg_efOut ; tlu2_1d_linear_linear_value ( & ug_efOut [ 0ULL ] , & t2 .
mField0 [ 0ULL ] , & t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = ug_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & vg_efOut [ 0ULL ] , & t2 . mField0 [
0ULL ] , & t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = vg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & wg_efOut [ 0ULL ] , & t2 . mField0 [ 0ULL ] ,
& t2 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , &
t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = wg_efOut [ 0 ] ; zc_int43 = (
( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t697_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t690_idx_0 * intrm_sf_mf_10 ; intrm_sf_mf_9 = U_idx_2 >=
0.0 ? U_idx_2 : - U_idx_2 ; t962 = intrm_sf_mf_9 * 0.01 ; t963 =
intermediate_der10891 * 7.8539816339744827E-5 ; intrm_sf_mf_10 = t962 / (
t963 == 0.0 ? 1.0E-16 : t963 ) ; intrm_sf_mf_11 = intrm_sf_mf_10 >= 2000.0 ?
intrm_sf_mf_10 : 1.0 ; t964 = pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ?
1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* 3.24 ; t964 = 1.0 / ( t964 == 0.0 ? 1.0E-16 : t964 ) * 0.55 / 0.01 ; t967 =
intermediate_der8465 * 1.5707963267948965E-8 ; t968 = intrm_sf_mf_1324 + t939
; t970 = t968 / 2.0 * 0.00093750000000000007 ; intrm_sf_mf_1324 = t940 / (
t970 == 0.0 ? 1.0E-16 : t970 ) ; t940 = intrm_sf_mf_1324 >= 0.0 ?
intrm_sf_mf_1324 : - intrm_sf_mf_1324 ; t966 = t940 > 1000.0 ? t940 : 1000.0
; t971 = t938 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; if ( t971 /
2.0 > 0.5 ) { t970 = ( t938 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; }
else { t970 = 0.5 ; } t973 = pmf_log10 ( 6.9 / ( t966 == 0.0 ? 1.0E-16 : t966
) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t966 == 0.0 ? 1.0E-16 :
t966 ) + 0.00069701528436089772 ) * 3.24 ; t972 = 1.0 / ( t973 == 0.0 ?
1.0E-16 : t973 ) ; t975 = ( pmf_pow ( t970 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t972 / 8.0 ) * 12.7 + 1.0 ; t973 = ( t966 - 1000.0 ) * ( t972 /
8.0 ) * t970 / ( t975 == 0.0 ? 1.0E-16 : t975 ) ; t974 = ( t940 - 2000.0 ) /
2000.0 ; t976 = t974 * t974 * 3.0 - t974 * t974 * t974 * 2.0 ; if ( t940 <=
2000.0 ) { intrm_sf_mf_1332 = 3.66 ; } else if ( t940 >= 4000.0 ) {
intrm_sf_mf_1332 = t973 ; } else { intrm_sf_mf_1332 = ( 1.0 - t976 ) * 3.66 +
t973 * t976 ; } t977 = intrm_sf_mf_1332 * 1.3250000000000002 ; t980 = t971 /
2.0 ; if ( t940 > t977 / 0.00093750000000000007 / ( t980 == 0.0 ? 1.0E-16 :
t980 ) / 30.0 ) { t986 = ( t938 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; t979
= intrm_sf_mf_1332 * 1.3250000000000002 / ( t940 == 0.0 ? 1.0E-16 : t940 ) /
0.00093750000000000007 / ( t986 == 0.0 ? 1.0E-16 : t986 ) ; } else { t979 =
30.0 ; } t980 = ( X [ 62ULL ] - X [ 450ULL ] ) * ( 1.0 - pmf_exp ( - t979 ) )
; t987 = intrm_sf_mf_1324 * 0.00093750000000000007 ; t989 = U_idx_3 + U_idx_7
; t990 = intrm_sf_mf_1337 + t939 ; t992 = t990 / 2.0 * 0.00093750000000000007
; intrm_sf_mf_1336 = - intrm_sf_mf_1336 * 0.0028301886792452828 / ( t992 ==
0.0 ? 1.0E-16 : t992 ) ; intrm_sf_mf_1337 = intrm_sf_mf_1336 >= 0.0 ?
intrm_sf_mf_1336 : - intrm_sf_mf_1336 ; t981 = intrm_sf_mf_1337 > 1000.0 ?
intrm_sf_mf_1337 : 1000.0 ; t993 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; if ( t993 /
2.0 > 0.5 ) { t982 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; }
else { t982 = 0.5 ; } t995 = pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16 : t981
) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16 :
t981 ) + 0.00069701528436089772 ) * 3.24 ; t983 = 1.0 / ( t995 == 0.0 ?
1.0E-16 : t995 ) ; t997 = ( pmf_pow ( t982 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t983 / 8.0 ) * 12.7 + 1.0 ; t984 = ( t981 - 1000.0 ) * ( t983 /
8.0 ) * t982 / ( t997 == 0.0 ? 1.0E-16 : t997 ) ; t985 = ( intrm_sf_mf_1337 -
2000.0 ) / 2000.0 ; t986 = t985 * t985 * 3.0 - t985 * t985 * t985 * 2.0 ; if
( intrm_sf_mf_1337 <= 2000.0 ) { t991 = 3.66 ; } else if ( intrm_sf_mf_1337
>= 4000.0 ) { t991 = t984 ; } else { t991 = ( 1.0 - t986 ) * 3.66 + t984 *
t986 ; } t999 = t991 * 1.3250000000000002 ; t1002 = t993 / 2.0 ; if (
intrm_sf_mf_1337 > t999 / 0.00093750000000000007 / ( t1002 == 0.0 ? 1.0E-16 :
t1002 ) / 30.0 ) { intermediate_der0 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; t992
= t991 * 1.3250000000000002 / ( intrm_sf_mf_1337 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1337 ) / 0.00093750000000000007 / ( intermediate_der0 == 0.0 ?
1.0E-16 : intermediate_der0 ) ; } else { t992 = 30.0 ; } t994 = ( X [ 62ULL ]
- X [ 436ULL ] ) * ( 1.0 - pmf_exp ( - t992 ) ) ; t1009 = intrm_sf_mf_1336 *
0.00093750000000000007 ; t1011 = intrm_sf_mf_1348 + U_idx_7 ;
intrm_sf_mf_1348 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 - - 20.0 ) /
40.0 ; t995 = intrm_sf_mf_1348 * intrm_sf_mf_1348 * 3.0 - intrm_sf_mf_1348 *
intrm_sf_mf_1348 * intrm_sf_mf_1348 * 2.0 ; t996 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 ; t998 = t996
* 0.0028301886792452828 / ( t941 == 0.0 ? 1.0E-16 : t941 ) ; t1001 = t998 >=
1.0 ? t998 : 1.0 ; t1015 = pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001
) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 :
t1001 ) + 0.00069701528436089772 ) * 3.24 ; t1002 = 1.0 / ( t1015 == 0.0 ?
1.0E-16 : t1015 ) ; t1017 = U_idx_10 * 1.50186899252403E-8 ; t1019 = U_idx_10
* 4.97494103773585E-9 ; t1004 = ( t998 - 2000.0 ) / 2000.0 ; t1005 = t1004 *
t1004 * 3.0 - t1004 * t1004 * t1004 * 2.0 ; t1022 = intermediate_der8465 *
1.2337005501361696E-8 ; intermediate_der8465 = ( intrm_sf_mf_10 - 2000.0 ) /
2000.0 ; t1007 = intermediate_der8465 * intermediate_der8465 * 3.0 -
intermediate_der8465 * intermediate_der8465 * intermediate_der8465 * 2.0 ; if
( X [ 555ULL ] <= 0.0 ) { intermediate_der0 = 0.0 ; } else {
intermediate_der0 = X [ 555ULL ] >= 1.0 ? 1.0 : X [ 555ULL ] ; } if ( X [
554ULL ] <= 0.0 ) { t1012 = 0.0 ; } else { t1012 = X [ 554ULL ] >= 1.0 ? 1.0
: X [ 554ULL ] ; } t1013 = ( ( ( 1.0 - intermediate_der0 ) - t1012 ) *
296.802103844292 + intermediate_der0 * 461.523 ) + t1012 * 4124.48151675695 ;
t706 [ 0ULL ] = X [ 553ULL ] ; tlu2_linear_linear_prelookup ( & xg_efOut .
mField0 [ 0ULL ] , & xg_efOut . mField1 [ 0ULL ] , & xg_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t706 [ 0ULL ] , &
t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t47 = xg_efOut ;
tlu2_1d_linear_linear_value ( & yg_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = yg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ah_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = ah_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & bh_efOut [ 0ULL ] , & t47 . mField0 [ 0ULL ]
, & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = bh_efOut [ 0 ] ; t1015 = (
( ( 1.0 - intermediate_der0 ) - t1012 ) * t697_idx_0 + U_idx_1 *
intermediate_der0 ) + t690_idx_0 * t1012 ; t706 [ 0ULL ] = X [ 175ULL ] ;
tlu2_linear_linear_prelookup ( & ch_efOut . mField0 [ 0ULL ] , & ch_efOut .
mField1 [ 0ULL ] , & ch_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t67 = ch_efOut ; tlu2_1d_linear_linear_value ( & dh_efOut [ 0ULL ] , & t67 .
mField0 [ 0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = dh_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & eh_efOut [ 0ULL ] , & t67 . mField0 [
0ULL ] , & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; U_idx_1 = eh_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & fh_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t690_idx_0 = fh_efOut [ 0 ] ;
intermediate_der0 = ( ( ( 1.0 - t1771 ) - t837 ) * t697_idx_0 + U_idx_1 *
t1771 ) + t690_idx_0 * t837 ; if ( - U_idx_2 >= 0.0 ) { t837 = - U_idx_2 ; }
else { t837 = U_idx_2 ; } t1026 = t837 * 0.01 ; t1012 = t1026 / ( t963 == 0.0
? 1.0E-16 : t963 ) ; t1016 = t1012 >= 2000.0 ? t1012 : 1.0 ; t1028 =
pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016 ) +
0.00017169489553429715 ) * 3.24 ; t1018 = 1.0 / ( t1028 == 0.0 ? 1.0E-16 :
t1028 ) * 0.55 / 0.01 ; t1020 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t1021 =
t1020 * 0.01 / ( t832 == 0.0 ? 1.0E-16 : t832 ) ; t1023 = t1021 >= 1.0 ?
t1021 : 1.0 ; t1032 = pmf_log10 ( 6.9 / ( t1023 == 0.0 ? 1.0E-16 : t1023 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1023 == 0.0 ? 1.0E-16 : t1023
) + 0.00017169489553429715 ) * 3.24 ; t1024 = 1.0 / ( t1032 == 0.0 ? 1.0E-16
: t1032 ) ; t1028 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der9120 * 35.2 / ( t836 == 0.0 ? 1.0E-16 : t836 ) ; t1030 = (
t1021 - 2000.0 ) / 2000.0 ; t1032 = t1030 * t1030 * 3.0 - t1030 * t1030 *
t1030 * 2.0 ; t1033 = U_idx_2 * intermediate_der10891 * - 35.2 / ( t967 ==
0.0 ? 1.0E-16 : t967 ) * 1.0E-5 ; t1037 = ( t1012 - 2000.0 ) / 2000.0 ; t1038
= t1037 * t1037 * 3.0 - t1037 * t1037 * t1037 * 2.0 ; t1044 =
intermediate_der10272 * 7.8539816339744827E-5 ; t1040 = t962 / ( t1044 == 0.0
? 1.0E-16 : t1044 ) ; t1042 = t1040 >= 2000.0 ? t1040 : 1.0 ; t1045 =
pmf_log10 ( 6.9 / ( t1042 == 0.0 ? 1.0E-16 : t1042 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1042 == 0.0 ? 1.0E-16 : t1042 ) +
0.00017169489553429715 ) * 3.24 ; t1045 = 1.0 / ( t1045 == 0.0 ? 1.0E-16 :
t1045 ) * 0.55 / 0.01 ; t1048 = intermediate_der9282 * 1.5707963267948965E-8
; t1050 = intermediate_der9282 * 1.2337005501361696E-8 ; intermediate_der9282
= ( t1040 - 2000.0 ) / 2000.0 ; t1049 = intermediate_der9282 *
intermediate_der9282 * 3.0 - intermediate_der9282 * intermediate_der9282 *
intermediate_der9282 * 2.0 ; t1051 = t1026 / ( t1044 == 0.0 ? 1.0E-16 : t1044
) ; intrm_sf_mf_41 = t1051 >= 2000.0 ? t1051 : 1.0 ; t1054 = pmf_log10 ( 6.9
/ ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ?
1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 ) * 3.24 ; t1054 = 1.0 /
( t1054 == 0.0 ? 1.0E-16 : t1054 ) * 0.55 / 0.01 ; t1055 = U_idx_2 *
intermediate_der10272 * - 35.2 / ( t1048 == 0.0 ? 1.0E-16 : t1048 ) * 1.0E-5
; t1058 = ( t1051 - 2000.0 ) / 2000.0 ; t1060 = t1058 * t1058 * 3.0 - t1058 *
t1058 * t1058 * 2.0 ; t1062 = intermediate_der10658 * 7.8539816339744827E-5 ;
intrm_sf_mf_52 = t962 / ( t1062 == 0.0 ? 1.0E-16 : t1062 ) ; t962 =
intrm_sf_mf_52 >= 2000.0 ? intrm_sf_mf_52 : 1.0 ; t1063 = pmf_log10 ( 6.9 / (
t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 /
( t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) * 3.24 ; t1063 =
1.0 / ( t1063 == 0.0 ? 1.0E-16 : t1063 ) * 0.55 / 0.01 ; t1066 =
intermediate_der10282 * 1.5707963267948965E-8 ; t1068 = intermediate_der10282
* 1.2337005501361696E-8 ; t1065 = ( intrm_sf_mf_52 - 2000.0 ) / 2000.0 ;
t1067 = t1065 * t1065 * 3.0 - t1065 * t1065 * t1065 * 2.0 ; t1069 = t1026 / (
t1062 == 0.0 ? 1.0E-16 : t1062 ) ; t1026 = t1069 >= 2000.0 ? t1069 : 1.0 ;
t1072 = pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026
) + 0.00017169489553429715 ) * 3.24 ; t1072 = 1.0 / ( t1072 == 0.0 ? 1.0E-16
: t1072 ) * 0.55 / 0.01 ; t1076 = ( t1069 - 2000.0 ) / 2000.0 ; t1078 = t1076
* t1076 * 3.0 - t1076 * t1076 * t1076 * 2.0 ; t1080 = t922 - ( - t922 ) ;
intrm_sf_mf_864 = ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) -
( - t922 ) ) / ( t1080 == 0.0 ? 1.0E-16 : t1080 ) ; zc_int10 = pmf_sqrt (
intermediate_der10355 * intermediate_der10355 * 9.999999999999999E-14 + ( (
real_T ) ( M [ 32ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 199ULL ] * t826 *
intrm_sf_mf_95 * 1.0E-9 ) ; if ( M [ 310ULL ] != 0 ) { zc_int116 =
216.59999999999997 ; } else { zc_int116 = M [ 311ULL ] != 0 ? 623.15 :
U_idx_6 ; } t706 [ 0ULL ] = U_idx_5 >= 0.0 ? zc_int116 : X [ 34ULL ] ;
tlu2_linear_linear_prelookup ( & gh_efOut . mField0 [ 0ULL ] , & gh_efOut .
mField1 [ 0ULL ] , & gh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t47 = gh_efOut ; tlu2_1d_linear_linear_value ( & hh_efOut [ 0ULL ] , & t47 .
mField0 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = hh_efOut [
0 ] ; zc_int116 = t697_idx_0 ; zc_int186 = - pmf_sqrt ( ( ( real_T ) ( M [
50ULL ] != 0 ) * 2.0 - 1.0 ) * ( t828 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 :
intrm_sf_mf_95 ) / ( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) *
7.8539816339744827E-5 ; t828 = intermediate_der9120 * zc_int186 * 35.2 / (
t836 == 0.0 ? 1.0E-16 : t836 ) ; if ( intermediate_der11513 >= 0.0 ) {
U_idx_3 = zc_int186 * 100000.0 ; } else { U_idx_3 = - zc_int186 * 100000.0 ;
} intermediate_der11513 = U_idx_3 * 0.01 / ( t832 == 0.0 ? 1.0E-16 : t832 ) ;
t1084 = pmf_sqrt ( zc_int179 * zc_int179 * 9.999999999999999E-14 + ( ( real_T
) ( M [ 326ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 330ULL ] * zc_int17 * zc_int174 *
1.0E-9 ) ; zc_int17 = intermediate_der11627 >= 1.0 ? intermediate_der11513 :
1.0 ; zc_int174 = - pmf_sqrt ( ( ( real_T ) ( M [ 328ULL ] != 0 ) * 2.0 - 1.0
) * ( t910 / ( zc_int174 == 0.0 ? 1.0E-16 : zc_int174 ) / ( X [ 330ULL ] ==
0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) * 0.0019634954084936209 ; zc_int179 =
zc_int180 * zc_int174 * 35.2 / ( t916 == 0.0 ? 1.0E-16 : t916 ) ; t1093 =
pmf_log10 ( 6.9 / ( zc_int17 == 0.0 ? 1.0E-16 : zc_int17 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( zc_int17 == 0.0 ? 1.0E-16 :
zc_int17 ) + 0.00017169489553429715 ) * 3.24 ; if ( t902 >= 0.0 ) { zc_int180
= zc_int174 * 100000.0 ; } else { zc_int180 = - zc_int174 * 100000.0 ; } t902
= zc_int180 * 0.05 / ( t914 == 0.0 ? 1.0E-16 : t914 ) ; U_idx_1 = t904 >= 1.0
? t902 : 1.0 ; t1096 = pmf_log10 ( 6.9 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1
) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) + 2.8767404433520813E-5 ) * 3.24 ; zc_int174 = zc_int174 *
zc_int180 * ( 1.0 / ( t1096 == 0.0 ? 1.0E-16 : t1096 ) ) * 0.55 / ( t919 ==
0.0 ? 1.0E-16 : t919 ) ; zc_int180 = ( t902 - 2000.0 ) / 2000.0 ; t902 =
zc_int180 * zc_int180 * 3.0 - zc_int180 * zc_int180 * zc_int180 * 2.0 ; if (
t904 <= 2000.0 ) { zc_int180 = zc_int179 * 1.0E-5 ; } else if ( t904 >=
4000.0 ) { zc_int180 = zc_int174 * 1.0E-5 ; } else { zc_int180 = ( ( 1.0 -
t902 ) * zc_int179 + zc_int174 * t902 ) * 1.0E-5 ; } zc_int174 = - ( X [
313ULL ] * t1084 ) / 0.0019634954084936209 * 0.00031622776601683789 +
zc_int180 ; intermediate_der10282 = - zc_int174 - zc_int174 * - 0.95 ;
zc_int179 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 - zc_int174 *
- 0.95 ) / ( intermediate_der10282 == 0.0 ? 1.0E-16 : intermediate_der10282 )
; zc_int17 = zc_int186 * U_idx_3 * ( 1.0 / ( t1093 == 0.0 ? 1.0E-16 : t1093 )
) * 0.55 / ( t839 == 0.0 ? 1.0E-16 : t839 ) ; t902 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 - 1.0 ) * ( t937 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * t907 * 0.64 ; t904 = pmf_sqrt ( ( ( real_T ) ( M [ 334ULL ] != 0 ) * 2.0
- 1.0 ) * ( t934 / ( t915 == 0.0 ? 1.0E-16 : t915 ) / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ) * t907 * 0.64 ; t1110 = t904 - t904 * 0.95 ;
zc_int186 = ( t902 - t904 * 0.95 ) / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ;
t1084 = ( - t902 - t904 * 0.95 ) / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ;
intermediate_der11513 = ( intermediate_der11513 - 2000.0 ) / 2000.0 ; t910 =
intermediate_der11513 * intermediate_der11513 * 3.0 - intermediate_der11513 *
intermediate_der11513 * intermediate_der11513 * 2.0 ; if (
intermediate_der11627 <= 2000.0 ) { intermediate_der11513 = t828 * 1.0E-5 ; }
else if ( intermediate_der11627 >= 4000.0 ) { intermediate_der11513 =
zc_int17 * 1.0E-5 ; } else { intermediate_der11513 = ( ( 1.0 - t910 ) * t828
+ zc_int17 * t910 ) * 1.0E-5 ; } intermediate_der11627 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * zc_int10 /
7.8539816339744827E-5 * 0.00031622776601683789 + intermediate_der11513 ;
t1116 = - intermediate_der11627 - intermediate_der11627 * - 0.95 ;
intermediate_der11513 = ( - intermediate_der11622 - intermediate_der11627 * -
0.95 ) / ( t1116 == 0.0 ? 1.0E-16 : t1116 ) ; if ( M [ 355ULL ] != 0 ) { t828
= 216.59999999999997 ; } else { t828 = M [ 356ULL ] != 0 ? 623.15 : U_idx_9 ;
} t706 [ 0ULL ] = U_idx_8 >= 0.0 ? t828 : X [ 51ULL ] ;
tlu2_linear_linear_prelookup ( & ih_efOut . mField0 [ 0ULL ] , & ih_efOut .
mField1 [ 0ULL ] , & ih_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ;
t31 = ih_efOut ; tlu2_1d_linear_linear_value ( & jh_efOut [ 0ULL ] , & t31 .
mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = jh_efOut [
0 ] ; t828 = t697_idx_0 ; t910 = ( X [ 64ULL ] - X [ 485ULL ] ) * pmf_sqrt (
( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( t959 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ) )
) * intrm_sf_mf_1534 * 0.64 ; t914 = pmf_sqrt ( ( ( real_T ) ( M [ 21ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t956 / ( intrm_sf_mf_1543 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1543 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) *
intrm_sf_mf_1534 * 0.64 ; t1122 = t914 - t914 * 0.95 ; t916 = ( t910 - t914 *
0.95 ) / ( t1122 == 0.0 ? 1.0E-16 : t1122 ) ; t919 = t916 * t916 * 3.0 - t916
* t916 * t916 * 2.0 ; t934 = ( - t910 - t914 * 0.95 ) / ( t1122 == 0.0 ?
1.0E-16 : t1122 ) ; t1086 = t934 * t934 * 3.0 - t934 * t934 * t934 * 2.0 ;
t1125 = X [ 553ULL ] * t1013 ; t1013 = ( ( real_T ) ( M [ 36ULL ] != 0 ) *
2.0 - 1.0 ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * (
t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t957 /
7.8539816339744827E-5 ) * ( t957 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + t1015 ; t1130 = X [ 175ULL ] * t838 ; t1089 = ( (
real_T ) ( M [ 36ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1125 / ( X [ 38ULL ] == 0.0
? 1.0E-16 : X [ 38ULL ] ) ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [
38ULL ] ) ) * ( - t957 / 7.8539816339744827E-5 ) * ( - t957 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + t1015 ; U_idx_11 = X
[ 573ULL ] * zc_int367 ; t1015 = ( ( real_T ) ( M [ 40ULL ] != 0 ) * 2.0 -
1.0 ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * (
U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t957 /
7.8539816339744827E-5 ) * ( t957 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + zc_int365 ; U_idx_4 = X [ 570ULL ] * zc_int367 ;
zc_int365 = ( ( real_T ) ( M [ 41ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_4 / ( X
[ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( U_idx_4 / ( X [ 176ULL ]
== 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t957 / 7.8539816339744827E-5 ) * (
t957 / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + zc_int366 ;
t690_idx_0 = X [ 572ULL ] * zc_int367 ; zc_int366 = ( ( real_T ) ( M [ 42ULL
] != 0 ) * 2.0 - 1.0 ) * ( t690_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [
176ULL ] ) ) * ( t690_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ]
) ) * ( - t957 / 7.8539816339744827E-5 ) * ( - t957 / 7.8539816339744827E-5 )
/ 2.0 * 9.999999999999999E-14 + zc_int43 ; t1771 = X [ 571ULL ] * zc_int367 ;
zc_int367 = ( ( real_T ) ( M [ 43ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1771 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t1771 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( - t957 / 7.8539816339744827E-5 ) * ( - t957 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + zc_int42 ; zc_int42 =
( X [ 195ULL ] - 1.01325 ) * pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) *
2.0 - 1.0 ) * ( t901 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t878 * 0.64 ; zc_int43 = pmf_sqrt ( ( ( real_T ) ( M [ 137ULL ] != 0 ) *
2.0 - 1.0 ) * ( t898 / ( t882 == 0.0 ? 1.0E-16 : t882 ) / ( X [ 219ULL ] ==
0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) * t878 * 0.64 ; U_idx_6 = zc_int43 -
zc_int43 * 0.95 ; zc_int17 = ( zc_int42 - zc_int43 * 0.95 ) / ( U_idx_6 ==
0.0 ? 1.0E-16 : U_idx_6 ) ; t1093 = zc_int17 * zc_int17 * 3.0 - zc_int17 *
zc_int17 * zc_int17 * 2.0 ; zc_int180 = ( - zc_int42 - zc_int43 * 0.95 ) / (
U_idx_6 == 0.0 ? 1.0E-16 : U_idx_6 ) ; t1096 = zc_int180 * zc_int180 * 3.0 -
zc_int180 * zc_int180 * zc_int180 * 2.0 ; U_idx_9 = - ( real_T ) ( t775 >=
0.0 ) * 1000.0 / 0.099999999999999978 ; if ( ( real_T ) ( t775 >= 0.0 ) *
t775 * 1000.0 + ( real_T ) ( t775 < 0.0 ) * X [ 81ULL ] <= 0.9 ) { t72 = 0.0
; } else { t72 = ( real_T ) ( t775 >= 0.0 ) * t775 * 1000.0 + ( real_T ) (
t775 < 0.0 ) * X [ 81ULL ] >= 1.0 ? 0.0 : U_idx_9 * t72 * 6.0 - t72 * t72 *
U_idx_9 * 6.0 ; } t838 = pmf_sqrt ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) * 2.0 ; t775 = 1.0 / ( t838 == 0.0 ? 1.0E-16 : t838
) * U_idx_2 * 2.0 ; t1181 = t1924 * t1924 ; U_idx_9 = ( - U_idx_2 / ( t1181
== 0.0 ? 1.0E-16 : t1181 ) * t775 + 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 )
) * X [ 93ULL ] / ( t1925 == 0.0 ? 1.0E-16 : t1925 ) ; t1925 = - ( - U_idx_2
/ ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 + 1.0 / ( t1924 == 0.0 ? 1.0E-16
: t1924 ) ) / 2.0 ; t1101 = ( - U_idx_2 / ( t1181 == 0.0 ? 1.0E-16 : t1181 )
* t775 + 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) / 2.0 ; t1103 = 1.0 / (
t838 == 0.0 ? 1.0E-16 : t838 ) * U_idx_2 * 2.0 ; t1190 = t1924 * t1924 ; t838
= ( U_idx_2 / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 + - 1.0 / ( t1924 ==
0.0 ? 1.0E-16 : t1924 ) ) * X [ 95ULL ] / ( t1923 == 0.0 ? 1.0E-16 : t1923 )
; t1923 = - ( U_idx_2 / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 + - 1.0 /
( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) / 2.0 ; t1109 = ( U_idx_2 / ( t1190 ==
0.0 ? 1.0E-16 : t1190 ) * t1103 + - 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 )
) / 2.0 ; t1111 = ( - U_idx_2 / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 +
1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X [ 102ULL ] / ( t1794 == 0.0 ?
1.0E-16 : t1794 ) ; t1794 = ( U_idx_2 / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) *
t1103 + - 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X [ 104ULL ] / ( t1778
== 0.0 ? 1.0E-16 : t1778 ) ; t1778 = ( - U_idx_2 / ( t1181 == 0.0 ? 1.0E-16 :
t1181 ) * t775 + 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X [ 111ULL ] /
( t1789 == 0.0 ? 1.0E-16 : t1789 ) ; t1789 = ( U_idx_2 / ( t1190 == 0.0 ?
1.0E-16 : t1190 ) * t1103 + - 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X
[ 113ULL ] / ( intermediate_der149 == 0.0 ? 1.0E-16 : intermediate_der149 ) ;
intermediate_der149 = 1.0 ; U_idx_7 = ( intermediate_der197 >= 0.0 ?
intermediate_der149 : - intermediate_der149 ) * 0.01 ; intermediate_der149 =
U_idx_7 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) ; t1243 = ( 6.9 / (
intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; U_idx_3 = pmf_log10 ( 6.9 / (
intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ?
1.0E-16 : intermediate_der239 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ?
1.0E-16 : intermediate_der239 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_1 = intermediate_der239 * intermediate_der239 ;
t1234 = - 1.0 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * ( - 6.9 / ( U_idx_1
== 0.0 ? 1.0E-16 : U_idx_1 ) ) * ( 1.0 / ( t1243 == 0.0 ? 1.0E-16 : t1243 ) )
* pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ? 1.0E-16 :
intermediate_der239 ) + 0.00017169489553429715 ) * ( t785 >= 2000.0 ?
intermediate_der149 : 0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt ( intermediate_der242
/ 8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ) * ( ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ) ; intermediate_der197 = ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * ( - ( ( t786 - 1000.0 ) * (
intermediate_der242 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) / ( U_idx_3 ==
0.0 ? 1.0E-16 : U_idx_3 ) ) * ( t1234 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t786 - 1000.0 ) * ( t1234 / 8.0 ) +
intermediate_der242 / 8.0 * ( t785 > 1000.0 ? intermediate_der149 : 0.0 ) ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg / ( t1494 == 0.0 ?
1.0E-16 : t1494 ) ; t786 = intermediate_der149 / 2000.0 ; intermediate_der239
= t786 * t790 * 6.0 - t790 * t790 * t786 * 6.0 ; if ( t785 <= 2000.0 ) { t786
= 0.0 ; } else if ( t785 >= 4000.0 ) { t786 = intermediate_der197 ; } else {
t786 = ( - intermediate_der239 * 3.66 + t789 * intermediate_der239 ) +
intermediate_der197 * intermediate_der316 ; } t1243 = ( t785 + 1.0 ) * ( t785
+ 1.0 ) ; t1234 = ( - ( intermediate_der349 * 0.031415926535897927 ) / (
t1243 == 0.0 ? 1.0E-16 : t1243 ) * intermediate_der149 + t786 *
0.031415926535897927 / ( t785 + 1.0 == 0.0 ? 1.0E-16 : t785 + 1.0 ) ) /
7.8539816339744827E-5 ; t786 = 1.0 - pmf_exp ( - t793 ) ; intermediate_der239
= - ( - ( t1234 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) ) * pmf_exp ( -
t793 ) ) * ( U_idx_0 - intermediate_der231 ) ; t1243 = t785 *
7.8539816339744827E-5 ; U_idx_10 = intermediate_der149 *
7.8539816339744827E-5 / 0.01 *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg * t795 * t796 +
t1243 / 0.01 * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg *
t796 * intermediate_der239 ; intermediate_der149 = t1243 / 0.01 *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg * t796 * t786 ;
U_idx_1 = pmf_sqrt ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) * 2.0 ;
intermediate_der197 = 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) * U_idx_2
* 2.0 ; t1234 = intermediate_der539 * intermediate_der539 ;
intermediate_der231 = ( - U_idx_2 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) *
intermediate_der197 + 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 :
intermediate_der539 ) ) * X [ 113ULL ] / ( intermediate_der546 == 0.0 ?
1.0E-16 : intermediate_der546 ) ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg = - ( - U_idx_2 /
( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 + 1.0 / (
intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ; t785 =
( - U_idx_2 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 + 1.0
/ ( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ;
t786 = 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) * U_idx_2 * 2.0 ; t1243 =
intermediate_der539 * intermediate_der539 ; intermediate_der239 = ( U_idx_2 /
( t1243 == 0.0 ? 1.0E-16 : t1243 ) * t786 + - 1.0 / ( intermediate_der539 ==
0.0 ? 1.0E-16 : intermediate_der539 ) ) * X [ 120ULL ] / (
intermediate_der553 == 0.0 ? 1.0E-16 : intermediate_der553 ) ;
intermediate_der242 = - ( U_idx_2 / ( t1243 == 0.0 ? 1.0E-16 : t1243 ) * t786
+ - 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) /
2.0 ; t789 = ( U_idx_2 / ( t1243 == 0.0 ? 1.0E-16 : t1243 ) * t786 + - 1.0 /
( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ; t790
= U_idx_7 / ( t1377 == 0.0 ? 1.0E-16 : t1377 ) ; U_idx_1 = ( 6.9 / (
intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1494 = pmf_log10 ( 6.9 / (
intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ?
1.0E-16 : intermediate_der1148 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ?
1.0E-16 : intermediate_der1148 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_3 = intermediate_der1148 * intermediate_der1148 ;
t793 = - 1.0 / ( t1494 == 0.0 ? 1.0E-16 : t1494 ) * ( - 6.9 / ( U_idx_3 ==
0.0 ? 1.0E-16 : U_idx_3 ) ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 )
) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ? 1.0E-16 :
intermediate_der1148 ) + 0.00017169489553429715 ) * ( intermediate_der1258 >=
2000.0 ? t790 : 0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt ( intermediate_der11984 /
8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow ( intermediate_der1227 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der11984 / 8.0 ) *
12.7 + 1.0 ) * ( ( pmf_pow ( intermediate_der1227 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( intermediate_der11984 / 8.0 ) * 12.7 + 1.0 ) ;
intermediate_der316 = ( pmf_pow ( intermediate_der1227 , 0.66666666666666663
) - 1.0 ) * ( - ( ( intermediate_der1237 - 1000.0 ) * ( intermediate_der11984
/ 8.0 ) * intermediate_der1227 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) *
( t793 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * 12.7 + (
( intermediate_der1237 - 1000.0 ) * ( t793 / 8.0 ) + intermediate_der11984 /
8.0 * ( intermediate_der1258 > 1000.0 ? t790 : 0.0 ) ) * intermediate_der1227
/ ( t1378 == 0.0 ? 1.0E-16 : t1378 ) ; intermediate_der349 = t790 / 2000.0 ;
t793 = intermediate_der349 * t802 * 6.0 - t802 * t802 * intermediate_der349 *
6.0 ; if ( intermediate_der1258 <= 2000.0 ) { intermediate_der349 = 0.0 ; }
else if ( intermediate_der1258 >= 4000.0 ) { intermediate_der349 =
intermediate_der316 ; } else { intermediate_der349 = ( - t793 * 3.66 + t801 *
t793 ) + intermediate_der316 * intermediate_der3088 ; } U_idx_3 = (
intermediate_der1258 + 1.0 ) * ( intermediate_der1258 + 1.0 ) ;
intermediate_der349 = - ( - ( ( - ( intermediate_der3747 *
0.031415926535897927 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * t790 +
intermediate_der349 * 0.031415926535897927 / ( intermediate_der1258 + 1.0 ==
0.0 ? 1.0E-16 : intermediate_der1258 + 1.0 ) ) / 7.8539816339744827E-5 / (
intermediate_der1227 == 0.0 ? 1.0E-16 : intermediate_der1227 ) ) * pmf_exp (
- t805 ) ) * ( X [ 10ULL ] - intermediate_der693 ) ; t790 = t790 *
7.8539816339744827E-5 / 0.01 * intermediate_der1227 * intermediate_der5455 *
t808 + intermediate_der1258 * 7.8539816339744827E-5 / 0.01 *
intermediate_der1227 * t808 * intermediate_der349 ; intermediate_der316 = ( -
U_idx_2 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 + 1.0 / (
intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) * X [ 95ULL ]
/ ( intermediate_der5446 == 0.0 ? 1.0E-16 : intermediate_der5446 ) ;
intermediate_der349 = ( U_idx_2 / ( t1243 == 0.0 ? 1.0E-16 : t1243 ) * t786 +
- 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) * X
[ 102ULL ] / ( intermediate_der3732 == 0.0 ? 1.0E-16 : intermediate_der3732 )
; t793 = U_idx_7 / ( t1499 == 0.0 ? 1.0E-16 : t1499 ) ; U_idx_1 = ( 6.9 / (
t810 == 0.0 ? 1.0E-16 : t810 ) + 0.00017169489553429715 ) *
2.3025850929940459 ; t1494 = pmf_log10 ( 6.9 / ( t810 == 0.0 ? 1.0E-16 : t810
) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t810 == 0.0 ? 1.0E-16 :
t810 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t810 == 0.0 ? 1.0E-16
: t810 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t810 == 0.0 ?
1.0E-16 : t810 ) + 0.00017169489553429715 ) * 10.497600000000002 ; U_idx_3 =
t810 * t810 ; intermediate_der546 = - 1.0 / ( t1494 == 0.0 ? 1.0E-16 : t1494
) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( 1.0 / ( U_idx_1 ==
0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 ( 6.9 / ( t810 == 0.0 ? 1.0E-16 :
t810 ) + 0.00017169489553429715 ) * ( intermediate_der8069 >= 2000.0 ? t793 :
0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt ( intermediate_der5549 / 8.0 ) * 2.0 ;
U_idx_3 = ( ( pmf_pow ( intermediate_der8498 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( intermediate_der5549 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow (
intermediate_der8498 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der5549 / 8.0 ) * 12.7 + 1.0 ) ; t795 = ( pmf_pow (
intermediate_der8498 , 0.66666666666666663 ) - 1.0 ) * ( - ( (
intermediate_der5545 - 1000.0 ) * ( intermediate_der5549 / 8.0 ) *
intermediate_der8498 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * (
intermediate_der546 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 )
) * 12.7 + ( ( intermediate_der5545 - 1000.0 ) * ( intermediate_der546 / 8.0
) + intermediate_der5549 / 8.0 * ( intermediate_der8069 > 1000.0 ? t793 : 0.0
) ) * intermediate_der8498 / ( t1381 == 0.0 ? 1.0E-16 : t1381 ) ; t796 = t793
/ 2000.0 ; intermediate_der546 = t796 * t814 * 6.0 - t814 * t814 * t796 * 6.0
; if ( intermediate_der8069 <= 2000.0 ) { t796 = 0.0 ; } else if (
intermediate_der8069 >= 4000.0 ) { t796 = t795 ; } else { t796 = ( -
intermediate_der546 * 3.66 + t813 * intermediate_der546 ) + t795 * t816 ; }
U_idx_3 = ( intermediate_der8069 + 1.0 ) * ( intermediate_der8069 + 1.0 ) ;
t796 = - ( - ( ( - ( intermediate_der5557 * 0.031415926535897927 ) / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * t793 + t796 * 0.031415926535897927 / (
intermediate_der8069 + 1.0 == 0.0 ? 1.0E-16 : intermediate_der8069 + 1.0 ) )
/ 7.8539816339744827E-5 / ( intermediate_der8498 == 0.0 ? 1.0E-16 :
intermediate_der8498 ) ) * pmf_exp ( - t817 ) ) * ( X [ 12ULL ] -
intermediate_der3734 ) ; t793 = t793 * 7.8539816339744827E-5 / 0.01 *
intermediate_der8498 * intermediate_der8390 * t820 + intermediate_der8069 *
7.8539816339744827E-5 / 0.01 * intermediate_der8498 * t820 * t796 ; t795 = (
- U_idx_2 / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 + 1.0 /
( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) * X [ 104ULL
] / ( intermediate_der5594 == 0.0 ? 1.0E-16 : intermediate_der5594 ) ; t796 =
( U_idx_2 / ( t1243 == 0.0 ? 1.0E-16 : t1243 ) * t786 + - 1.0 / (
intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) * X [ 111ULL ]
/ ( intermediate_der5597 == 0.0 ? 1.0E-16 : intermediate_der5597 ) ;
intermediate_der539 = ( - U_idx_2 / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775
+ 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X [ 138ULL ] / (
intermediate_der5598 == 0.0 ? 1.0E-16 : intermediate_der5598 ) ;
intermediate_der546 = ( U_idx_2 / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103
+ - 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * X [ 93ULL ] / (
intermediate_der11607 == 0.0 ? 1.0E-16 : intermediate_der11607 ) ;
intermediate_der553 = ( X [ 93ULL ] - X [ 138ULL ] ) / ( intermediate_der6946
== 0.0 ? 1.0E-16 : intermediate_der6946 ) ; intermediate_der1227 = - 0.005 ;
U_idx_3 = t1385 / 2.0 * 7.8539816339744827E-5 ; intermediate_der1258 = ( t827
>= 0.0 ? intermediate_der1227 : 0.0 ) * 0.01 / ( U_idx_3 == 0.0 ? 1.0E-16 :
U_idx_3 ) ; intermediate_der1237 = t841 >= 0.0 ? intermediate_der1258 : -
intermediate_der1258 ; intermediate_der1148 = t842 > 1000.0 ?
intermediate_der1237 : 0.0 ; U_idx_1 = ( 6.9 / ( t844 == 0.0 ? 1.0E-16 : t844
) + 0.00017169489553429715 ) * 2.3025850929940459 ; t1494 = pmf_log10 ( 6.9 /
( t844 == 0.0 ? 1.0E-16 : t844 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t844 == 0.0 ? 1.0E-16 : t844 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t844 == 0.0 ? 1.0E-16 : t844 ) + 0.00017169489553429715 ) * pmf_log10
( 6.9 / ( t844 == 0.0 ? 1.0E-16 : t844 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_3 = t844 * t844 ; intermediate_der11984 = - 1.0 /
( t1494 == 0.0 ? 1.0E-16 : t1494 ) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 :
U_idx_3 ) ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 (
6.9 / ( t844 == 0.0 ? 1.0E-16 : t844 ) + 0.00017169489553429715 ) *
intermediate_der1148 * 6.48 ; U_idx_1 = pmf_sqrt ( t846 / 8.0 ) * 2.0 ;
U_idx_3 = ( ( pmf_pow ( intermediate_der8500 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( t846 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow ( intermediate_der8500
, 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t846 / 8.0 ) * 12.7 + 1.0 ) ;
intermediate_der1148 = ( pmf_pow ( intermediate_der8500 , 0.66666666666666663
) - 1.0 ) * ( - ( ( t844 - 1000.0 ) * ( t846 / 8.0 ) * intermediate_der8500 )
/ ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( intermediate_der11984 / 8.0 )
* ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t844 - 1000.0
) * ( intermediate_der11984 / 8.0 ) + t846 / 8.0 * intermediate_der1148 ) *
intermediate_der8500 / ( t1387 == 0.0 ? 1.0E-16 : t1387 ) ;
intermediate_der11984 = intermediate_der1237 / 2000.0 ; t801 =
intermediate_der11984 * intermediate_der11730 * 6.0 - intermediate_der11730 *
intermediate_der11730 * intermediate_der11984 * 6.0 ; if ( t842 <= 2000.0 ) {
intermediate_der11984 = 0.0 ; } else if ( t842 >= 4000.0 ) {
intermediate_der11984 = intermediate_der1148 ; } else { intermediate_der11984
= ( - t801 * 3.66 + t801 * t847 ) + intermediate_der1148 * t850 ; } U_idx_3 =
t1386 / 2.0 ; if ( t842 > t1388 / 7.8539816339744827E-5 / ( U_idx_3 == 0.0 ?
1.0E-16 : U_idx_3 ) / 30.0 ) { U_idx_3 = t842 * t842 ; U_idx_1 = (
intrm_sf_mf_133 + t843 ) / 2.0 ; intermediate_der1148 = ( - ( t851 *
0.031415926535897927 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) *
intermediate_der1237 + intermediate_der11984 * 0.031415926535897927 / ( t842
== 0.0 ? 1.0E-16 : t842 ) ) / 7.8539816339744827E-5 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ; } else { intermediate_der1148 = 0.0 ; }
intermediate_der1237 = - ( - intermediate_der1148 * pmf_exp ( - t853 ) ) * (
X [ 179ULL ] - X [ 175ULL ] ) ; t1494 = t762 + intermediate_der7294 ;
intermediate_der1258 = t1494 / 2.0 * ( t1386 / 2.0 ) * ( intermediate_der1258
* 7.8539816339744827E-5 / 0.01 ) * intermediate_der11651 + t841 *
7.8539816339744827E-5 / 0.01 * ( t1386 / 2.0 ) * ( t1494 / 2.0 ) *
intermediate_der1237 ; U_idx_3 = t1389 / 2.0 * 7.8539816339744827E-5 ;
intermediate_der1227 = - ( t827 <= 0.0 ? intermediate_der1227 : 0.0 ) * 0.01
/ ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; intermediate_der1237 = t858 >= 0.0
? intermediate_der1227 : - intermediate_der1227 ; intermediate_der1148 =
t1781 > 1000.0 ? intermediate_der1237 : 0.0 ; U_idx_1 = ( 6.9 / ( t1665 ==
0.0 ? 1.0E-16 : t1665 ) + 0.00017169489553429715 ) * 2.3025850929940459 ;
t1494 = pmf_log10 ( 6.9 / ( t1665 == 0.0 ? 1.0E-16 : t1665 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1665 == 0.0 ? 1.0E-16 : t1665
) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1665 == 0.0 ? 1.0E-16 :
t1665 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1665 == 0.0 ?
1.0E-16 : t1665 ) + 0.00017169489553429715 ) * 10.497600000000002 ; U_idx_3 =
t1665 * t1665 ; intermediate_der11984 = - 1.0 / ( t1494 == 0.0 ? 1.0E-16 :
t1494 ) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( 1.0 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 ( 6.9 / ( t1665 == 0.0 ?
1.0E-16 : t1665 ) + 0.00017169489553429715 ) * intermediate_der1148 * 6.48 ;
U_idx_1 = pmf_sqrt ( t1660 / 8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow ( t1753 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1660 / 8.0 ) * 12.7 + 1.0 ) * ( (
pmf_pow ( t1753 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1660 / 8.0 ) *
12.7 + 1.0 ) ; intermediate_der1148 = ( pmf_pow ( t1753 , 0.66666666666666663
) - 1.0 ) * ( - ( ( t1665 - 1000.0 ) * ( t1660 / 8.0 ) * t1753 ) / ( U_idx_3
== 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( intermediate_der11984 / 8.0 ) * ( 1.0 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t1665 - 1000.0 ) * (
intermediate_der11984 / 8.0 ) + t1660 / 8.0 * intermediate_der1148 ) * t1753
/ ( t1391 == 0.0 ? 1.0E-16 : t1391 ) ; intermediate_der11984 =
intermediate_der1237 / 2000.0 ; t801 = intermediate_der11984 * t1421 * 6.0 -
t1421 * t1421 * intermediate_der11984 * 6.0 ; if ( t1781 <= 2000.0 ) {
intermediate_der11984 = 0.0 ; } else if ( t1781 >= 4000.0 ) {
intermediate_der11984 = intermediate_der1148 ; } else { intermediate_der11984
= ( - t801 * 3.66 + t801 * t1408 ) + intermediate_der1148 * t1430 ; } t1408 =
t1390 / 2.0 ; if ( t1781 > t1392 / 7.8539816339744827E-5 / ( t1408 == 0.0 ?
1.0E-16 : t1408 ) / 30.0 ) { t1408 = t1781 * t1781 ; t1377 = ( t843 +
intermediate_der8829 ) / 2.0 ; intermediate_der1148 = ( - ( t1734 *
0.031415926535897927 ) / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) *
intermediate_der1237 + intermediate_der11984 * 0.031415926535897927 / ( t1781
== 0.0 ? 1.0E-16 : t1781 ) ) / 7.8539816339744827E-5 / ( t1377 == 0.0 ?
1.0E-16 : t1377 ) ; } else { intermediate_der1148 = 0.0 ; }
intermediate_der1237 = - ( - intermediate_der1148 * pmf_exp ( - t1372 ) ) * (
X [ 179ULL ] - X [ 194ULL ] ) ; t1660 = intermediate_der7294 + t860 ;
intermediate_der1237 = intermediate_der1258 + ( t1660 / 2.0 * ( t1390 / 2.0 )
* ( intermediate_der1227 * 7.8539816339744827E-5 / 0.01 ) * t1454 + t858 *
7.8539816339744827E-5 / 0.01 * ( t1390 / 2.0 ) * ( t1660 / 2.0 ) *
intermediate_der1237 ) ; t860 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) * 2.0 ; intermediate_der1227 = 1.0 / ( t860 == 0.0 ?
1.0E-16 : t860 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; t860 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) * 2.0 ; intermediate_der1258 = 1.0 / ( t860 == 0.0 ?
1.0E-16 : t860 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; t860 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) * 2.0 ; intermediate_der1148 = 1.0 / ( t860 == 0.0 ?
1.0E-16 : t860 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; if ( t831 * 0.0001 <= 7.8539816339744857E-13 ) { t801 = 0.0 ; } else if
( t831 * 0.0001 >= 3.1415926535897929E-6 ) { t801 = 0.0 ; } else { t801 =
3.1415926535897929E-6 ; } intermediate_der11984 = t801 /
7.8539816339744827E-5 ; if ( X [ 186ULL ] > 0.0 ) { t1734 = t878 * t878 ;
t802 = ( ( ( t1673 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t878 == 0.0 ? 1.0E-16
: t878 ) * ( - ( X [ 186ULL ] / 0.64 ) / ( t1734 == 0.0 ? 1.0E-16 : t1734 ) )
* t801 * 2.0 / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) ) + X [ 186ULL ] / 0.64
/ ( t878 == 0.0 ? 1.0E-16 : t878 ) * ( X [ 186ULL ] / 0.64 / ( t878 == 0.0 ?
1.0E-16 : t878 ) ) / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) *
intermediate_der11984 ) * ( 1.0 - t1673 * t1553 ) + - ( t1553 *
intermediate_der11984 ) * ( t1673 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t878 ==
0.0 ? 1.0E-16 : t878 ) * ( X [ 186ULL ] / 0.64 / ( t878 == 0.0 ? 1.0E-16 :
t878 ) ) / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) ) ) *
9.9999999999999991E-11 ; } else if ( X [ 186ULL ] < 0.0 ) { t1390 = t878 *
t878 ; t802 = ( ( ( t1673 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t878 == 0.0 ?
1.0E-16 : t878 ) * ( - ( X [ 186ULL ] / 0.64 ) / ( t1390 == 0.0 ? 1.0E-16 :
t1390 ) ) * t801 * 2.0 / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) ) + X [
186ULL ] / 0.64 / ( t878 == 0.0 ? 1.0E-16 : t878 ) * ( X [ 186ULL ] / 0.64 /
( t878 == 0.0 ? 1.0E-16 : t878 ) ) / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) *
intermediate_der11984 ) * ( 1.0 - t1673 * t1527 ) + - ( t1527 *
intermediate_der11984 ) * ( t1673 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t878 ==
0.0 ? 1.0E-16 : t878 ) * ( X [ 186ULL ] / 0.64 / ( t878 == 0.0 ? 1.0E-16 :
t878 ) ) / 2.0 / ( t883 == 0.0 ? 1.0E-16 : t883 ) ) ) *
9.9999999999999991E-11 ; } else { t802 = 0.0 ; } intermediate_der3088 = -
intermediate_der11984 * ( 1.0 - t1673 ) * 2.0 ; intermediate_der3747 = t1556
* intermediate_der3088 ; intermediate_der5455 = ( X [ 195ULL ] - 1.01325 ) *
( t1468 >= t1528 ? ( ( 1.0 - t1673 * t1553 ) * intermediate_der11984 + - (
t1553 * intermediate_der11984 ) * ( t1673 + 1.0 ) ) - ( ( 1.0 - t1673 * t1527
) * intermediate_der11984 * 2.0 + - ( t1527 * intermediate_der11984 ) * t1673
* 2.0 ) : intermediate_der3088 ) ; if ( X [ 195ULL ] - 1.01325 <= 0.0 ) {
t805 = intermediate_der3747 ; } else if ( X [ 195ULL ] - 1.01325 >= t1556 ) {
t805 = intermediate_der5455 ; } else { t805 = ( 1.0 - t1470 ) *
intermediate_der3747 + intermediate_der5455 * t1470 ; } intermediate_der11984
= ( 1.01325 - X [ 195ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >= t1528 ? ( (
1.0 - t1673 * t1527 ) * intermediate_der11984 + - ( t1527 *
intermediate_der11984 ) * ( t1673 + 1.0 ) ) - ( ( 1.0 - t1673 * t1553 ) *
intermediate_der11984 * 2.0 + - ( t1553 * intermediate_der11984 ) * t1673 *
2.0 ) : intermediate_der3088 ) ; if ( 1.01325 - X [ 195ULL ] <= 0.0 ) {
intermediate_der3088 = intermediate_der3747 ; } else if ( 1.01325 - X [
195ULL ] >= t1556 ) { intermediate_der3088 = intermediate_der11984 ; } else {
intermediate_der3088 = ( 1.0 - t1471 ) * intermediate_der3747 +
intermediate_der11984 * t1471 ; } if ( X [ 195ULL ] > 1.01325 ) {
intermediate_der11984 = t805 ; } else { intermediate_der11984 = X [ 195ULL ]
< 1.01325 ? intermediate_der3088 : intermediate_der3747 ; } t1408 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ;
intermediate_der3747 = X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [
343ULL ] ) * ( - X [ 344ULL ] / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 ;
if ( X [ 313ULL ] > 0.0 ) { t805 = - ( t909 * intermediate_der3747 ) * ( t909
+ 1.0 ) * ( X [ 313ULL ] / 0.64 / ( t907 == 0.0 ? 1.0E-16 : t907 ) * ( X [
313ULL ] / 0.64 / ( t907 == 0.0 ? 1.0E-16 : t907 ) ) / 2.0 / ( t917 == 0.0 ?
1.0E-16 : t917 ) ) * 9.9999999999999991E-11 ; } else { t805 = 0.0 ; } t808 =
0.0050000000000000044 ; intermediate_der5455 = t921 * t808 ;
intermediate_der3732 = ( t1477 >= t921 ? t1477 : t921 ) * 10.0 + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( t1477 >= t921 ? - ( t909 * intermediate_der3747 ) * ( t909 + 1.0 ) : 0.0 )
; t1421 = t922 * t922 ; intermediate_der5446 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t1421 == 0.0 ? 1.0E-16 : t1421 ) * t808 + 10.0 / ( t922 == 0.0 ? 1.0E-16 :
t922 ) ; intermediate_der3734 = intermediate_der5446 * t1479 * 6.0 - t1479 *
t1479 * intermediate_der5446 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { intermediate_der5446 = intermediate_der5455 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t922 ) { intermediate_der5446 = intermediate_der3732 ; } else {
intermediate_der5446 = ( ( - intermediate_der3734 * t923 + ( 1.0 - t931 ) *
intermediate_der5455 ) + t930 * intermediate_der3734 ) + intermediate_der3732
* t931 ; } intermediate_der3747 = - 10.0 * ( t1481 >= t921 ? t1481 : t921 ) +
( 1.01325 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 )
* ( t1481 >= t921 ? - ( - ( t909 * intermediate_der3747 ) * t909 * 2.0 ) :
0.0 ) ; intermediate_der3732 = - ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / ( t1421 ==
0.0 ? 1.0E-16 : t1421 ) * t808 + - 10.0 / ( t922 == 0.0 ? 1.0E-16 : t922 ) ;
intermediate_der3734 = intermediate_der3732 * t1474 * 6.0 - t1474 * t1474 *
intermediate_der3732 * 6.0 ; if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <= 0.0 ) {
intermediate_der3732 = intermediate_der5455 ; } else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t922 ) {
intermediate_der3732 = intermediate_der3747 ; } else { intermediate_der3732 =
( ( - intermediate_der3734 * t923 + ( 1.0 - t1482 ) * intermediate_der5455 )
+ t1473 * intermediate_der3734 ) + intermediate_der3747 * t1482 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 ) {
intermediate_der3747 = intermediate_der5446 ; } else { intermediate_der3747 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
intermediate_der3732 : intermediate_der5455 ; } t860 = pmf_sqrt ( t1483 *
t1483 + 6.4274470286298274E-9 ) * 2.0 ; intermediate_der5446 = 1.0 / ( t860
== 0.0 ? 1.0E-16 : t860 ) * t1483 * - 2.0 * 2.0 ; t1421 = t1484 * t1484 ;
intermediate_der3732 = ( - t1483 / ( t1421 == 0.0 ? 1.0E-16 : t1421 ) *
intermediate_der5446 + - 2.0 / ( t1484 == 0.0 ? 1.0E-16 : t1484 ) ) * 1.01325
/ ( t1485 == 0.0 ? 1.0E-16 : t1485 ) ; intermediate_der3734 = - ( - t1483 / (
t1421 == 0.0 ? 1.0E-16 : t1421 ) * intermediate_der5446 + - 2.0 / ( t1484 ==
0.0 ? 1.0E-16 : t1484 ) ) / 2.0 ; intermediate_der5455 = ( - t1483 / ( t1421
== 0.0 ? 1.0E-16 : t1421 ) * intermediate_der5446 + - 2.0 / ( t1484 == 0.0 ?
1.0E-16 : t1484 ) ) / 2.0 ; t860 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
1.2620262729050631E-10 ) * 2.0 ; intermediate_der5545 = 1.0 / ( t860 == 0.0 ?
1.0E-16 : t860 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * 2.0 * 2.0 ;
t1430 = t1486 * t1486 ; intermediate_der5549 = - ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1430 ==
0.0 ? 1.0E-16 : t1430 ) * intermediate_der5545 + 2.0 / ( t1486 == 0.0 ?
1.0E-16 : t1486 ) ) / 2.0 ; t813 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1430 ==
0.0 ? 1.0E-16 : t1430 ) * intermediate_der5545 + 2.0 / ( t1486 == 0.0 ?
1.0E-16 : t1486 ) ) / 2.0 ; t814 = 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * 2.0 * 2.0 ;
t1372 = t1486 * t1486 ; intermediate_der5557 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1372 ==
0.0 ? 1.0E-16 : t1372 ) * t814 + - 2.0 / ( t1486 == 0.0 ? 1.0E-16 : t1486 ) )
/ 2.0 ; t817 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1372 ==
0.0 ? 1.0E-16 : t1372 ) * t814 + - 2.0 / ( t1486 == 0.0 ? 1.0E-16 : t1486 ) )
/ 2.0 ; intermediate_der8498 = 1.0 ; t1734 = intermediate_der8498 *
0.0028301886792452828 ; t860 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
2.4102926357361849E-12 ) * 2.0 ; t820 = 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860
) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * 2.0 *
2.0 ; t1454 = t1490 * t1490 ; intermediate_der5597 = - ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1454 ==
0.0 ? 1.0E-16 : t1454 ) * t820 + 2.0 / ( t1490 == 0.0 ? 1.0E-16 : t1490 ) ) /
2.0 ; intermediate_der5598 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1454 ==
0.0 ? 1.0E-16 : t1454 ) * t820 + 2.0 / ( t1490 == 0.0 ? 1.0E-16 : t1490 ) ) /
2.0 ; if ( t1492 * 7.8539816339744827E-5 <= 7.8539816339744857E-13 ) {
intermediate_der6946 = 0.0 ; } else if ( t1492 * 7.8539816339744827E-5 >=
3.1415926535897929E-6 ) { intermediate_der6946 = 0.0 ; } else {
intermediate_der6946 = 0.000628318373638326 ; } intermediate_der11607 =
intermediate_der6946 / 7.8539816339744827E-5 ; if ( - X [ 478ULL ] > 0.0 ) {
t1528 = intrm_sf_mf_1534 * intrm_sf_mf_1534 ; t762 = ( ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) * ( -
X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 : intrm_sf_mf_1534
) * ( - ( - X [ 478ULL ] / 0.64 ) / ( t1528 == 0.0 ? 1.0E-16 : t1528 ) ) *
intermediate_der6946 * 2.0 / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) )
+ - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1534 ) * ( - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ?
1.0E-16 : intrm_sf_mf_1534 ) ) / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) *
intermediate_der11607 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) + - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 *
intermediate_der11607 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) * ( -
X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 : intrm_sf_mf_1534
) * ( - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1534 ) ) / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) )
) * 9.9999999999999991E-11 ; } else if ( - X [ 478ULL ] < 0.0 ) { t1485 =
intrm_sf_mf_1534 * intrm_sf_mf_1534 ; t762 = ( ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) * ( -
X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 : intrm_sf_mf_1534
) * ( - ( - X [ 478ULL ] / 0.64 ) / ( t1485 == 0.0 ? 1.0E-16 : t1485 ) ) *
intermediate_der6946 * 2.0 / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) )
+ - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1534 ) * ( - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ?
1.0E-16 : intrm_sf_mf_1534 ) ) / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) *
intermediate_der11607 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * t945 ) + -
( t945 * intermediate_der11607 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) * ( -
X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 : intrm_sf_mf_1534
) * ( - X [ 478ULL ] / 0.64 / ( intrm_sf_mf_1534 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1534 ) ) / 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 ) )
) * 9.9999999999999991E-11 ; } else { t762 = 0.0 ; } t827 = -
intermediate_der11607 * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 ) * 2.0 ;
t831 = t949 * t827 ; intrm_sf_mf_133 = ( X [ 64ULL ] - X [ 485ULL ] ) * (
t952 >= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ? ( (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) *
intermediate_der11607 + - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 *
intermediate_der11607 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) ) - (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
t945 ) * intermediate_der11607 * 2.0 + - ( t945 * intermediate_der11607 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * 2.0 ) :
t827 ) ; if ( X [ 64ULL ] - X [ 485ULL ] <= 0.0 ) { intermediate_der7294 =
t831 ; } else if ( X [ 64ULL ] - X [ 485ULL ] >= t949 ) {
intermediate_der7294 = intrm_sf_mf_133 ; } else { intermediate_der7294 = (
1.0 - t953 ) * t831 + intrm_sf_mf_133 * t953 ; } intermediate_der11607 = ( X
[ 485ULL ] - X [ 64ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu18 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ? ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * t945 ) *
intermediate_der11607 + - ( t945 * intermediate_der11607 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 + 1.0 ) ) - (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) *
intermediate_der11607 * 2.0 + - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 *
intermediate_der11607 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu21 * 2.0 ) :
t827 ) ; if ( X [ 485ULL ] - X [ 64ULL ] <= 0.0 ) { t827 = t831 ; } else if (
X [ 485ULL ] - X [ 64ULL ] >= t949 ) { t827 = intermediate_der11607 ; } else
{ t827 = ( 1.0 - t954 ) * t831 + intermediate_der11607 * t954 ; } if ( X [
64ULL ] > X [ 485ULL ] ) { intermediate_der11607 = intermediate_der7294 ; }
else { intermediate_der11607 = X [ 64ULL ] < X [ 485ULL ] ? t827 : t831 ; }
t860 = pmf_sqrt ( t957 * t957 + 1.8324100759713822E-12 ) * 2.0 ; t831 = 1.0 /
( t860 == 0.0 ? 1.0E-16 : t860 ) * t957 * 0.01 * 2.0 ; t1665 = pmf_sqrt (
t957 * t957 + 2.0914103314136477E-13 ) * 2.0 ; intermediate_der7294 = 1.0 / (
t1665 == 0.0 ? 1.0E-16 : t1665 ) * t957 * 0.01 * 2.0 ; t1753 = pmf_sqrt (
t957 * t957 + 1.4768645655431184E-13 ) * 2.0 ; intrm_sf_mf_133 = 1.0 / (
t1753 == 0.0 ? 1.0E-16 : t1753 ) * t957 * 0.01 * 2.0 ; t841 = 1.0 / ( t860 ==
0.0 ? 1.0E-16 : t860 ) * t957 * 0.01 * 2.0 ; t842 = 1.0 / ( t1665 == 0.0 ?
1.0E-16 : t1665 ) * t957 * 0.01 * 2.0 ; t843 = 1.0 / ( t1753 == 0.0 ? 1.0E-16
: t1753 ) * t957 * 0.01 * 2.0 ; t844 = U_idx_2 >= 0.0 ? 1.0 : - 1.0 ; t1665 =
t844 * 0.01 ; intermediate_der8500 = t1665 / ( t963 == 0.0 ? 1.0E-16 : t963 )
; t860 = ( 6.9 / ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1753 = pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ?
1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* 10.497600000000002 ; t1660 = intrm_sf_mf_11 * intrm_sf_mf_11 ; t1673 = -
1.0 / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) * ( - 6.9 / ( t1660 == 0.0 ? 1.0E-16
: t1660 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 /
( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715
) * ( intrm_sf_mf_10 >= 2000.0 ? intermediate_der8500 : 0.0 ) *
3.5640000000000005 ; t847 = intermediate_der10891 * 35.2 / ( t967 == 0.0 ?
1.0E-16 : t967 ) * 1.0E-5 ; t1753 = t968 / 2.0 * 0.00093750000000000007 ;
intermediate_der11730 = t1734 / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) ; t850 =
intrm_sf_mf_1324 >= 0.0 ? intermediate_der11730 : - intermediate_der11730 ;
t851 = t940 > 1000.0 ? t850 : 0.0 ; t860 = ( 6.9 / ( t966 == 0.0 ? 1.0E-16 :
t966 ) + 0.00069701528436089772 ) * 2.3025850929940459 ; t1753 = pmf_log10 (
6.9 / ( t966 == 0.0 ? 1.0E-16 : t966 ) + 0.00069701528436089772 ) * pmf_log10
( 6.9 / ( t966 == 0.0 ? 1.0E-16 : t966 ) + 0.00069701528436089772 ) *
pmf_log10 ( 6.9 / ( t966 == 0.0 ? 1.0E-16 : t966 ) + 0.00069701528436089772 )
* pmf_log10 ( 6.9 / ( t966 == 0.0 ? 1.0E-16 : t966 ) + 0.00069701528436089772
) * 10.497600000000002 ; t1660 = t966 * t966 ; t853 = - 1.0 / ( t1753 == 0.0
? 1.0E-16 : t1753 ) * ( - 6.9 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ) * ( 1.0
/ ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 / ( t966 == 0.0 ?
1.0E-16 : t966 ) + 0.00069701528436089772 ) * t851 * 6.48 ; t860 = pmf_sqrt (
t972 / 8.0 ) * 2.0 ; t1660 = ( ( pmf_pow ( t970 , 0.66666666666666663 ) - 1.0
) * pmf_sqrt ( t972 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow ( t970 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t972 / 8.0 ) * 12.7 + 1.0 ) ; t851
= ( pmf_pow ( t970 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t966 - 1000.0 )
* ( t972 / 8.0 ) * t970 ) / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ) * ( t853 /
8.0 ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * 12.7 + ( ( t966 - 1000.0
) * ( t853 / 8.0 ) + t972 / 8.0 * t851 ) * t970 / ( t975 == 0.0 ? 1.0E-16 :
t975 ) ; t853 = t850 / 2000.0 ; intermediate_der11651 = t853 * t974 * 6.0 -
t974 * t974 * t853 * 6.0 ; if ( t940 <= 2000.0 ) { t853 = 0.0 ; } else if (
t940 >= 4000.0 ) { t853 = t851 ; } else { t853 = ( - intermediate_der11651 *
3.66 + intermediate_der11651 * t973 ) + t851 * t976 ; } t1660 = t971 / 2.0 ;
if ( t940 > t977 / 0.00093750000000000007 / ( t1660 == 0.0 ? 1.0E-16 : t1660
) / 30.0 ) { t1660 = t940 * t940 ; t1556 = ( t938 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; t851
= ( - ( intrm_sf_mf_1332 * 1.3250000000000002 ) / ( t1660 == 0.0 ? 1.0E-16 :
t1660 ) * t850 + t853 * 1.3250000000000002 / ( t940 == 0.0 ? 1.0E-16 : t940 )
) / 0.00093750000000000007 / ( t1556 == 0.0 ? 1.0E-16 : t1556 ) ; } else {
t851 = 0.0 ; } t850 = - ( - t851 * pmf_exp ( - t979 ) ) * ( X [ 62ULL ] - X [
450ULL ] ) ; intermediate_der11730 = t989 / 2.0 * ( t971 / 2.0 ) * (
intermediate_der11730 * 0.00093750000000000007 / 0.0028301886792452828 ) *
t980 + t987 / 0.0028301886792452828 * ( t971 / 2.0 ) * ( t989 / 2.0 ) * t850
; t1660 = t990 / 2.0 * 0.00093750000000000007 ; intermediate_der8498 = -
intermediate_der8498 * 0.0028301886792452828 / ( t1660 == 0.0 ? 1.0E-16 :
t1660 ) ; t850 = intrm_sf_mf_1336 >= 0.0 ? intermediate_der8498 : -
intermediate_der8498 ; t851 = intrm_sf_mf_1337 > 1000.0 ? t850 : 0.0 ; t860 =
( 6.9 / ( t981 == 0.0 ? 1.0E-16 : t981 ) + 0.00069701528436089772 ) *
2.3025850929940459 ; t1753 = pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16 : t981
) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16 :
t981 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16
: t981 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t981 == 0.0 ?
1.0E-16 : t981 ) + 0.00069701528436089772 ) * 10.497600000000002 ; t1660 =
t981 * t981 ; t853 = - 1.0 / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) * ( - 6.9 / (
t1660 == 0.0 ? 1.0E-16 : t1660 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 )
) * pmf_log10 ( 6.9 / ( t981 == 0.0 ? 1.0E-16 : t981 ) +
0.00069701528436089772 ) * t851 * 6.48 ; t860 = pmf_sqrt ( t983 / 8.0 ) * 2.0
; t1660 = ( ( pmf_pow ( t982 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
t983 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow ( t982 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t983 / 8.0 ) * 12.7 + 1.0 ) ; t851 = ( pmf_pow ( t982 ,
0.66666666666666663 ) - 1.0 ) * ( - ( ( t981 - 1000.0 ) * ( t983 / 8.0 ) *
t982 ) / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ) * ( t853 / 8.0 ) * ( 1.0 / (
t860 == 0.0 ? 1.0E-16 : t860 ) ) * 12.7 + ( ( t981 - 1000.0 ) * ( t853 / 8.0
) + t983 / 8.0 * t851 ) * t982 / ( t997 == 0.0 ? 1.0E-16 : t997 ) ; t853 =
t850 / 2000.0 ; intermediate_der11651 = t853 * t985 * 6.0 - t985 * t985 *
t853 * 6.0 ; if ( intrm_sf_mf_1337 <= 2000.0 ) { t853 = 0.0 ; } else if (
intrm_sf_mf_1337 >= 4000.0 ) { t853 = t851 ; } else { t853 = ( -
intermediate_der11651 * 3.66 + intermediate_der11651 * t984 ) + t851 * t986 ;
} t1660 = t993 / 2.0 ; if ( intrm_sf_mf_1337 > t999 / 0.00093750000000000007
/ ( t1660 == 0.0 ? 1.0E-16 : t1660 ) / 30.0 ) { t1660 = intrm_sf_mf_1337 *
intrm_sf_mf_1337 ; t1556 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; t851
= ( - ( t991 * 1.3250000000000002 ) / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) *
t850 + t853 * 1.3250000000000002 / ( intrm_sf_mf_1337 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1337 ) ) / 0.00093750000000000007 / ( t1556 == 0.0 ? 1.0E-16 :
t1556 ) ; } else { t851 = 0.0 ; } t850 = - ( - t851 * pmf_exp ( - t992 ) ) *
( X [ 62ULL ] - X [ 436ULL ] ) ; intermediate_der8498 = t1011 / 2.0 * ( t993
/ 2.0 ) * ( intermediate_der8498 * 0.00093750000000000007 /
0.0028301886792452828 ) * t994 + t1009 / 0.0028301886792452828 * ( t993 / 2.0
) * ( t1011 / 2.0 ) * t850 ; t850 = t1734 / ( t941 == 0.0 ? 1.0E-16 : t941 )
/ 40.0 ; intermediate_der8390 = t850 * intrm_sf_mf_1348 * 6.0 -
intrm_sf_mf_1348 * intrm_sf_mf_1348 * t850 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 <= - 20.0 ) {
t850 = intermediate_der8498 * 0.001 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 >= 20.0 ) {
t850 = intermediate_der11730 * 0.001 ; } else { t850 = ( ( ( -
intermediate_der8390 * ( t1009 / 0.0028301886792452828 * ( t993 / 2.0 ) * (
t1011 / 2.0 ) * t994 ) + ( 1.0 - t995 ) * intermediate_der8498 ) +
intermediate_der8390 * ( t987 / 0.0028301886792452828 * ( t971 / 2.0 ) * (
t989 / 2.0 ) * t980 ) ) + intermediate_der11730 * t995 ) * 0.001 ; }
intermediate_der8498 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 >= 0.0 ? 2.0 :
- 2.0 ; intermediate_der8390 = intermediate_der8498 * 0.0028301886792452828 /
( t941 == 0.0 ? 1.0E-16 : t941 ) ; t860 = ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 :
t1001 ) + 0.00069701528436089772 ) * 2.3025850929940459 ; t1753 = pmf_log10 (
6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001 ) + 0.00069701528436089772 ) *
pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001 ) + 0.00069701528436089772
) * pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001
) + 0.00069701528436089772 ) * 10.497600000000002 ; t1660 = t1001 * t1001 ;
t851 = - 1.0 / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) * ( - 6.9 / ( t1660 == 0.0
? 1.0E-16 : t1660 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) *
pmf_log10 ( 6.9 / ( t1001 == 0.0 ? 1.0E-16 : t1001 ) + 0.00069701528436089772
) * ( t998 >= 1.0 ? intermediate_der8390 : 0.0 ) * 6.48 ;
intermediate_der11730 = t939 * 2.0 * 112.0 / ( t1017 == 0.0 ? 1.0E-16 : t1017
) ; intermediate_der8498 = ( ( 2.0 * t996 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
intermediate_der8498 ) * t1002 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t851 * t996
) * 1.75 / ( t1019 == 0.0 ? 1.0E-16 : t1019 ) ; intermediate_der8069 =
intermediate_der8390 / 2000.0 ; intermediate_der8390 = intermediate_der8069 *
t1004 * 6.0 - t1004 * t1004 * intermediate_der8069 * 6.0 ; if ( t998 <=
2000.0 ) { intermediate_der8069 = intermediate_der11730 * 1.0E-5 ; } else if
( t998 >= 4000.0 ) { intermediate_der8069 = intermediate_der8498 * 1.0E-5 ; }
else { intermediate_der8069 = ( ( ( - intermediate_der8390 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t939 * 112.0
/ ( t1017 == 0.0 ? 1.0E-16 : t1017 ) ) + ( 1.0 - t1005 ) *
intermediate_der11730 ) + intermediate_der8390 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t996 * t1002
* 1.75 / ( t1019 == 0.0 ? 1.0E-16 : t1019 ) ) ) + intermediate_der8498 *
t1005 ) * 1.0E-5 ; } intermediate_der8498 = ( ( intrm_sf_mf_9 + U_idx_2 *
t844 ) * t964 + U_idx_2 * ( t1673 / 0.01 ) * intrm_sf_mf_9 ) / ( t1022 == 0.0
? 1.0E-16 : t1022 ) * 1.0E-5 ; intermediate_der8390 = intermediate_der8500 /
2000.0 ; intermediate_der8500 = intermediate_der8390 * intermediate_der8465 *
6.0 - intermediate_der8465 * intermediate_der8465 * intermediate_der8390 *
6.0 ; if ( intrm_sf_mf_10 <= 2000.0 ) { intermediate_der8390 = t847 ; } else
if ( intrm_sf_mf_10 >= 4000.0 ) { intermediate_der8390 = intermediate_der8498
; } else { intermediate_der8390 = ( ( - intermediate_der8500 * ( U_idx_2 *
intermediate_der10891 * 35.2 / ( t967 == 0.0 ? 1.0E-16 : t967 ) * 1.0E-5 ) +
( 1.0 - t1007 ) * t847 ) + intermediate_der8500 * ( U_idx_2 * t964 *
intrm_sf_mf_9 / ( t1022 == 0.0 ? 1.0E-16 : t1022 ) * 1.0E-5 ) ) +
intermediate_der8498 * t1007 ; } intermediate_der8465 = ( U_idx_2 / ( t1190
== 0.0 ? 1.0E-16 : t1190 ) * t1103 + - 1.0 / ( t1924 == 0.0 ? 1.0E-16 : t1924
) ) * X [ 138ULL ] / ( X [ 159ULL ] == 0.0 ? 1.0E-16 : X [ 159ULL ] ) ; t1924
= ( - U_idx_2 / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 + 1.0 / ( t1924 ==
0.0 ? 1.0E-16 : t1924 ) ) * X [ 120ULL ] / ( X [ 160ULL ] == 0.0 ? 1.0E-16 :
X [ 160ULL ] ) ; if ( - U_idx_2 >= 0.0 ) { intermediate_der8498 = 0.0 ; }
else { t1660 = X [ 159ULL ] * 1.2337005501361696E-8 ; intermediate_der8498 =
U_idx_2 * 2.0 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) * 1.0E-5 ; } if ( U_idx_2
>= 0.0 ) { intermediate_der8500 = 0.0 ; } else { t1660 = X [ 160ULL ] *
1.2337005501361696E-8 ; intermediate_der8500 = U_idx_2 * 2.0 / ( t1660 == 0.0
? 1.0E-16 : t1660 ) * 1.0E-5 ; } if ( U_idx_13 >= 1.0 ) { t846 = 0.0 ; } else
{ t846 = ( real_T ) ! ( U_idx_13 <= 0.0 ) ; } if ( - U_idx_2 >= 0.0 ) { t847
= - 1.0 ; } else { t847 = 1.0 ; } t1753 = t847 * 0.01 ; intermediate_der11730
= t1753 / ( t963 == 0.0 ? 1.0E-16 : t963 ) ; t860 = ( 6.9 / ( t1016 == 0.0 ?
1.0E-16 : t1016 ) + 0.00017169489553429715 ) * 2.3025850929940459 ; t1660 =
pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016
) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 :
t1016 ) + 0.00017169489553429715 ) * 10.497600000000002 ; t1734 = t1016 *
t1016 ; t1673 = - 1.0 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) * ( - 6.9 / (
t1734 == 0.0 ? 1.0E-16 : t1734 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 )
) * pmf_log10 ( 6.9 / ( t1016 == 0.0 ? 1.0E-16 : t1016 ) +
0.00017169489553429715 ) * ( t1012 >= 2000.0 ? intermediate_der11730 : 0.0 )
* 3.5640000000000005 ; t853 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ? -
0.01 : 0.01 ; intermediate_der11651 = t853 * 0.01 / ( t832 == 0.0 ? 1.0E-16 :
t832 ) ; t860 = ( 6.9 / ( t1023 == 0.0 ? 1.0E-16 : t1023 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1660 = pmf_log10 ( 6.9 / (
t1023 == 0.0 ? 1.0E-16 : t1023 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t1023 == 0.0 ? 1.0E-16 : t1023 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1023 == 0.0 ? 1.0E-16 : t1023 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1023 == 0.0 ? 1.0E-16 : t1023 ) + 0.00017169489553429715
) * 10.497600000000002 ; t1734 = t1023 * t1023 ; t858 = - 1.0 / ( t1660 ==
0.0 ? 1.0E-16 : t1660 ) * ( - 6.9 / ( t1734 == 0.0 ? 1.0E-16 : t1734 ) ) * (
1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 / ( t1023 == 0.0 ?
1.0E-16 : t1023 ) + 0.00017169489553429715 ) * ( t1021 >= 1.0 ?
intermediate_der11651 : 0.0 ) * 6.48 ; intermediate_der9120 = - 0.01 *
intermediate_der9120 * 35.2 / ( t836 == 0.0 ? 1.0E-16 : t836 ) ; t853 = ( ( -
0.01 * t1020 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * t853 ) *
t1024 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
t858 * t1020 ) * 0.55 / ( t839 == 0.0 ? 1.0E-16 : t839 ) ;
intermediate_der8829 = intermediate_der11651 / 2000.0 ; intermediate_der11651
= intermediate_der8829 * t1030 * 6.0 - t1030 * t1030 * intermediate_der8829 *
6.0 ; intermediate_der10891 = intermediate_der10891 * - 35.2 / ( t967 == 0.0
? 1.0E-16 : t967 ) * 1.0E-5 ; if ( t1021 <= 2000.0 ) { intermediate_der8829 =
intermediate_der9120 * 9.9999999999999991E-11 ; } else if ( t1021 >= 4000.0 )
{ intermediate_der8829 = t853 * 9.9999999999999991E-11 ; } else {
intermediate_der8829 = ( ( ( - intermediate_der11651 * t1028 + ( 1.0 - t1032
) * intermediate_der9120 ) + intermediate_der11651 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * t1020 *
t1024 * 0.55 / ( t839 == 0.0 ? 1.0E-16 : t839 ) ) ) + t853 * t1032 ) *
9.9999999999999991E-11 ; } intermediate_der9120 = ( ( - t837 - U_idx_2 * t847
) * t1018 - U_idx_2 * ( t1673 / 0.01 ) * t837 ) / ( t1022 == 0.0 ? 1.0E-16 :
t1022 ) * 1.0E-5 ; t851 = intermediate_der11730 / 2000.0 ;
intermediate_der11730 = t851 * t1037 * 6.0 - t1037 * t1037 * t851 * 6.0 ; if
( t1012 <= 2000.0 ) { t851 = intermediate_der10891 ; } else if ( t1012 >=
4000.0 ) { t851 = intermediate_der9120 ; } else { t851 = ( ( -
intermediate_der11730 * t1033 + ( 1.0 - t1038 ) * intermediate_der10891 ) +
intermediate_der11730 * ( - ( U_idx_2 * t837 * t1018 ) / ( t1022 == 0.0 ?
1.0E-16 : t1022 ) * 1.0E-5 ) ) + intermediate_der9120 * t1038 ; }
intermediate_der10891 = t1665 / ( t1044 == 0.0 ? 1.0E-16 : t1044 ) ; t860 = (
6.9 / ( t1042 == 0.0 ? 1.0E-16 : t1042 ) + 0.00017169489553429715 ) *
2.3025850929940459 ; t1660 = pmf_log10 ( 6.9 / ( t1042 == 0.0 ? 1.0E-16 :
t1042 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1042 == 0.0 ?
1.0E-16 : t1042 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1042 ==
0.0 ? 1.0E-16 : t1042 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t1042 == 0.0 ? 1.0E-16 : t1042 ) + 0.00017169489553429715 ) *
10.497600000000002 ; t1734 = t1042 * t1042 ; t1673 = - 1.0 / ( t1660 == 0.0 ?
1.0E-16 : t1660 ) * ( - 6.9 / ( t1734 == 0.0 ? 1.0E-16 : t1734 ) ) * ( 1.0 /
( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 / ( t1042 == 0.0 ?
1.0E-16 : t1042 ) + 0.00017169489553429715 ) * ( t1040 >= 2000.0 ?
intermediate_der10891 : 0.0 ) * 3.5640000000000005 ; intermediate_der11730 =
intermediate_der10272 * 35.2 / ( t1048 == 0.0 ? 1.0E-16 : t1048 ) * 1.0E-5 ;
intermediate_der9120 = ( ( intrm_sf_mf_9 + U_idx_2 * t844 ) * t1045 + U_idx_2
* ( t1673 / 0.01 ) * intrm_sf_mf_9 ) / ( t1050 == 0.0 ? 1.0E-16 : t1050 ) *
1.0E-5 ; t853 = intermediate_der10891 / 2000.0 ; intermediate_der10891 = t853
* intermediate_der9282 * 6.0 - intermediate_der9282 * intermediate_der9282 *
t853 * 6.0 ; if ( t1040 <= 2000.0 ) { t853 = intermediate_der11730 ; } else
if ( t1040 >= 4000.0 ) { t853 = intermediate_der9120 ; } else { t853 = ( ( -
intermediate_der10891 * ( U_idx_2 * intermediate_der10272 * 35.2 / ( t1048 ==
0.0 ? 1.0E-16 : t1048 ) * 1.0E-5 ) + ( 1.0 - t1049 ) * intermediate_der11730
) + intermediate_der10891 * ( U_idx_2 * t1045 * intrm_sf_mf_9 / ( t1050 ==
0.0 ? 1.0E-16 : t1050 ) * 1.0E-5 ) ) + intermediate_der9120 * t1049 ; }
intermediate_der10891 = t1753 / ( t1044 == 0.0 ? 1.0E-16 : t1044 ) ; t860 = (
6.9 / ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1660 = pmf_log10 ( 6.9 / (
intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ?
1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 )
* 10.497600000000002 ; t1734 = intrm_sf_mf_41 * intrm_sf_mf_41 ; t1673 = -
1.0 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) * ( - 6.9 / ( t1734 == 0.0 ? 1.0E-16
: t1734 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 /
( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715
) * ( t1051 >= 2000.0 ? intermediate_der10891 : 0.0 ) * 3.5640000000000005 ;
intermediate_der10272 = intermediate_der10272 * - 35.2 / ( t1048 == 0.0 ?
1.0E-16 : t1048 ) * 1.0E-5 ; intermediate_der9282 = ( ( - t837 - U_idx_2 *
t847 ) * t1054 - U_idx_2 * ( t1673 / 0.01 ) * t837 ) / ( t1050 == 0.0 ?
1.0E-16 : t1050 ) * 1.0E-5 ; intermediate_der9120 = intermediate_der10891 /
2000.0 ; intermediate_der10891 = intermediate_der9120 * t1058 * 6.0 - t1058 *
t1058 * intermediate_der9120 * 6.0 ; if ( t1051 <= 2000.0 ) {
intermediate_der9120 = intermediate_der10272 ; } else if ( t1051 >= 4000.0 )
{ intermediate_der9120 = intermediate_der9282 ; } else { intermediate_der9120
= ( ( - intermediate_der10891 * t1055 + ( 1.0 - t1060 ) *
intermediate_der10272 ) + intermediate_der10891 * ( - ( U_idx_2 * t837 *
t1054 ) / ( t1050 == 0.0 ? 1.0E-16 : t1050 ) * 1.0E-5 ) ) +
intermediate_der9282 * t1060 ; } intermediate_der10891 = t1665 / ( t1062 ==
0.0 ? 1.0E-16 : t1062 ) ; t860 = ( 6.9 / ( t962 == 0.0 ? 1.0E-16 : t962 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1665 = pmf_log10 ( 6.9 / (
t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 /
( t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t962 == 0.0 ? 1.0E-16 : t962 ) + 0.00017169489553429715 ) *
10.497600000000002 ; t1660 = t962 * t962 ; t1734 = - 1.0 / ( t1665 == 0.0 ?
1.0E-16 : t1665 ) * ( - 6.9 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ) * ( 1.0 /
( t860 == 0.0 ? 1.0E-16 : t860 ) ) * pmf_log10 ( 6.9 / ( t962 == 0.0 ?
1.0E-16 : t962 ) + 0.00017169489553429715 ) * ( intrm_sf_mf_52 >= 2000.0 ?
intermediate_der10891 : 0.0 ) * 3.5640000000000005 ; intermediate_der10272 =
intermediate_der10658 * 35.2 / ( t1066 == 0.0 ? 1.0E-16 : t1066 ) * 1.0E-5 ;
intermediate_der9282 = ( ( intrm_sf_mf_9 + U_idx_2 * t844 ) * t1063 + U_idx_2
* ( t1734 / 0.01 ) * intrm_sf_mf_9 ) / ( t1068 == 0.0 ? 1.0E-16 : t1068 ) *
1.0E-5 ; t844 = intermediate_der10891 / 2000.0 ; intermediate_der10891 = t844
* t1065 * 6.0 - t1065 * t1065 * t844 * 6.0 ; if ( intrm_sf_mf_52 <= 2000.0 )
{ t844 = intermediate_der10272 ; } else if ( intrm_sf_mf_52 >= 4000.0 ) {
t844 = intermediate_der9282 ; } else { t844 = ( ( - intermediate_der10891 * (
U_idx_2 * intermediate_der10658 * 35.2 / ( t1066 == 0.0 ? 1.0E-16 : t1066 ) *
1.0E-5 ) + ( 1.0 - t1067 ) * intermediate_der10272 ) + intermediate_der10891
* ( U_idx_2 * t1063 * intrm_sf_mf_9 / ( t1068 == 0.0 ? 1.0E-16 : t1068 ) *
1.0E-5 ) ) + intermediate_der9282 * t1067 ; } intermediate_der10891 = t1753 /
( t1062 == 0.0 ? 1.0E-16 : t1062 ) ; t860 = ( 6.9 / ( t1026 == 0.0 ? 1.0E-16
: t1026 ) + 0.00017169489553429715 ) * 2.3025850929940459 ; t1665 = pmf_log10
( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026
) + 0.00017169489553429715 ) * 10.497600000000002 ; t1753 = t1026 * t1026 ;
t1660 = - 1.0 / ( t1665 == 0.0 ? 1.0E-16 : t1665 ) * ( - 6.9 / ( t1753 == 0.0
? 1.0E-16 : t1753 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) *
pmf_log10 ( 6.9 / ( t1026 == 0.0 ? 1.0E-16 : t1026 ) + 0.00017169489553429715
) * ( t1069 >= 2000.0 ? intermediate_der10891 : 0.0 ) * 3.5640000000000005 ;
intermediate_der10272 = intermediate_der10658 * - 35.2 / ( t1066 == 0.0 ?
1.0E-16 : t1066 ) * 1.0E-5 ; U_idx_3 = ( ( - t837 - U_idx_2 * t847 ) * t1072
- U_idx_2 * ( t1660 / 0.01 ) * t837 ) / ( t1068 == 0.0 ? 1.0E-16 : t1068 ) *
1.0E-5 ; intermediate_der9282 = intermediate_der10891 / 2000.0 ;
intermediate_der10891 = intermediate_der9282 * t1076 * 6.0 - t1076 * t1076 *
intermediate_der9282 * 6.0 ; if ( t1069 <= 2000.0 ) { intermediate_der9282 =
intermediate_der10272 ; } else if ( t1069 >= 4000.0 ) { intermediate_der9282
= U_idx_3 ; } else { intermediate_der9282 = ( ( - intermediate_der10891 * (
U_idx_2 * intermediate_der10658 * - 35.2 / ( t1066 == 0.0 ? 1.0E-16 : t1066 )
* 1.0E-5 ) + ( 1.0 - t1078 ) * intermediate_der10272 ) +
intermediate_der10891 * ( - ( U_idx_2 * t837 * t1072 ) / ( t1068 == 0.0 ?
1.0E-16 : t1068 ) * 1.0E-5 ) ) + U_idx_3 * t1078 ; } t1753 = ( t922 - ( -
t922 ) ) * ( t922 - ( - t922 ) ) ; U_idx_3 = ( t808 - ( - t808 ) ) * ( - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) -
( - t922 ) ) / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) ) + ( 10.0 - ( - t808 ) ) /
( t1080 == 0.0 ? 1.0E-16 : t1080 ) ; intermediate_der10891 = U_idx_3 *
intrm_sf_mf_864 * 6.0 - intrm_sf_mf_864 * intrm_sf_mf_864 * U_idx_3 * 6.0 ;
if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325
<= - t922 ) { U_idx_3 = 0.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t922 ) { U_idx_3 = 10.0 ; } else { U_idx_3 = ( - intermediate_der10891 *
1.01325 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
intermediate_der10891 ) + 10.0 * ( intrm_sf_mf_864 * intrm_sf_mf_864 * 3.0 -
intrm_sf_mf_864 * intrm_sf_mf_864 * intrm_sf_mf_864 * 2.0 ) ; } t860 =
pmf_sqrt ( intermediate_der10355 * intermediate_der10355 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 32ULL ] != 0 ) * 2.0 - 1.0 ) * X [
199ULL ] * t826 * intrm_sf_mf_95 * 1.0E-9 ) * 2.0 ; intermediate_der10891 =
1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) * intermediate_der10355 * ( ( X [
21ULL ] / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) - X [ 199ULL ] / ( X
[ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * - 0.01 * intrm_sf_mf_95 /
7.8539816339744827E-5 ) * 1.9999999999999998E-13 ; if ( M [ 310ULL ] != 0 ) {
intermediate_der693 = 0.0 ; } else { intermediate_der693 = ( real_T ) ( M [
311ULL ] == 0 ) ; } tlu2_1d_linear_linear_value ( & kh_efOut [ 0ULL ] , & t47
. mField1 [ 0ULL ] , & t47 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = kh_efOut
[ 0 ] ; intermediate_der693 = t697_idx_0 * ( U_idx_5 >= 0.0 ?
intermediate_der693 : 0.0 ) ; t1665 = X [ 321ULL ] * t908 ; t1753 = - ( X [
321ULL ] * t908 ) ; t808 = ( ( ( real_T ) ( M [ 323ULL ] != 0 ) * 2.0 - 1.0 )
* ( t1665 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ) * ( t1753
/ ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 + ( ( real_T ) ( M [ 323ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t1665 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1753 / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 ) * ( - X [ 313ULL ]
/ 0.0019634954084936209 ) * ( - X [ 313ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 ; intermediate_der10272 = - 10.0 / (
intermediate_der10282 == 0.0 ? 1.0E-16 : intermediate_der10282 ) ;
intermediate_der10282 = intermediate_der10272 * zc_int179 * 6.0 - zc_int179 *
zc_int179 * intermediate_der10272 * 6.0 ; if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 <=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 * - 0.95 ) {
intermediate_der10272 = 10.0 ; } else if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 >= -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) {
intermediate_der10272 = 0.0 ; } else { intermediate_der10272 = ( -
intermediate_der10282 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 + ( 1.0 - (
zc_int179 * zc_int179 * 3.0 - zc_int179 * zc_int179 * zc_int179 * 2.0 ) ) *
10.0 ) + intermediate_der10282 * zc_int174 ; } intermediate_der10282 = ( ( (
real_T ) ( M [ 323ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1665 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1753 / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 + ( ( real_T ) ( M [
323ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1665 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1753 / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 ) * ( X [ 313ULL ] /
0.0019634954084936209 ) * ( X [ 313ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 ; t860 = pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 )
* 2.0 - 1.0 ) * ( t937 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) ; t1753 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ;
intermediate_der10658 = pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 -
1.0 ) * ( t937 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * 10.0 * t907 * 0.64 + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 - 1.0 ) * ( - ( t917 * 2.0 ) / (
t1753 == 0.0 ? 1.0E-16 : t1753 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 )
) * intermediate_der3747 * t907 * 0.32 ; intermediate_der3747 =
intermediate_der10658 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ;
intermediate_der10355 = intermediate_der3747 * zc_int186 * 6.0 - zc_int186 *
zc_int186 * intermediate_der3747 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 <= t911 *
0.95 ) { intermediate_der3747 = intermediate_der10658 * 100000.0 ; } else if
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 >= t911 ) {
intermediate_der3747 = 0.0 ; } else { intermediate_der3747 = ( ( -
intermediate_der10355 * t902 + ( 1.0 - ( zc_int186 * zc_int186 * 3.0 -
zc_int186 * zc_int186 * zc_int186 * 2.0 ) ) * intermediate_der10658 ) +
intermediate_der10355 * t904 ) * 100000.0 ; } intermediate_der10355 = -
intermediate_der10658 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ; t826 =
intermediate_der10355 * t1084 * 6.0 - t1084 * t1084 * intermediate_der10355 *
6.0 ; if ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21
<= t911 * 0.95 ) { intermediate_der10355 = intermediate_der10658 * 100000.0 ;
} else if ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21
>= t911 ) { intermediate_der10355 = 0.0 ; } else { intermediate_der10355 = (
( - t826 * t902 + ( 1.0 - ( t1084 * t1084 * 3.0 - t1084 * t1084 * t1084 * 2.0
) ) * intermediate_der10658 ) + - t904 * t826 ) * 100000.0 ; } t1665 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der10891 + - 0.01 * zc_int10 ; intermediate_der10891 = t1665 /
7.8539816339744827E-5 * 0.00031622776601683789 ; t1734 = ( -
intermediate_der11627 - intermediate_der11627 * - 0.95 ) * ( -
intermediate_der11627 - intermediate_der11627 * - 0.95 ) ;
intermediate_der10658 = ( - intermediate_der10891 - intermediate_der10891 * -
0.95 ) * ( - ( - intermediate_der11622 - intermediate_der11627 * - 0.95 ) / (
t1734 == 0.0 ? 1.0E-16 : t1734 ) ) + - ( intermediate_der10891 * - 0.95 ) / (
t1116 == 0.0 ? 1.0E-16 : t1116 ) ; t826 = intermediate_der10658 *
intermediate_der11513 * 6.0 - intermediate_der11513 * intermediate_der11513 *
intermediate_der10658 * 6.0 ; if ( - intermediate_der11622 <=
intermediate_der11504 * - 0.95 ) { intermediate_der10658 = 0.0 ; } else if (
- intermediate_der11622 >= - intermediate_der11504 ) { intermediate_der10658
= intermediate_der10891 ; } else { intermediate_der10658 = ( - t826 *
intermediate_der11622 + t826 * intermediate_der11627 ) +
intermediate_der10891 * ( intermediate_der11513 * intermediate_der11513 * 3.0
- intermediate_der11513 * intermediate_der11513 * intermediate_der11513 * 2.0
) ; } if ( M [ 355ULL ] != 0 ) { intermediate_der10891 = 0.0 ; } else {
intermediate_der10891 = ( real_T ) ( M [ 356ULL ] == 0 ) ; }
tlu2_1d_linear_linear_value ( & lh_efOut [ 0ULL ] , & t31 . mField1 [ 0ULL ]
, & t31 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t697_idx_0 = lh_efOut [ 0 ] ;
intermediate_der10891 = t697_idx_0 * ( U_idx_8 >= 0.0 ? intermediate_der10891
: 0.0 ) ; t860 = pmf_sqrt ( ( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) *
( t959 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ) ) ) ; t1734
= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ; t826 = ( X
[ 64ULL ] - X [ 485ULL ] ) * pmf_sqrt ( ( ( real_T ) ( M [ 20ULL ] != 0 ) *
2.0 - 1.0 ) * ( t959 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ) )
) * intermediate_der6946 * 0.64 + ( X [ 64ULL ] - X [ 485ULL ] ) * ( ( real_T
) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu29 * 2.0 ) / (
t1734 == 0.0 ? 1.0E-16 : t1734 ) ) * ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 )
) * intermediate_der11607 * intrm_sf_mf_1534 * 0.32 ; intermediate_der11607 =
pmf_sqrt ( ( ( real_T ) ( M [ 21ULL ] != 0 ) * 2.0 - 1.0 ) * ( t956 / (
intrm_sf_mf_1543 == 0.0 ? 1.0E-16 : intrm_sf_mf_1543 ) / ( X [ 506ULL ] ==
0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) * intermediate_der6946 * 0.64 ; t1734 = (
t914 - t914 * 0.95 ) * ( t914 - t914 * 0.95 ) ; intermediate_der11504 = (
intermediate_der11607 - intermediate_der11607 * 0.95 ) * ( - ( t910 - t914 *
0.95 ) / ( t1734 == 0.0 ? 1.0E-16 : t1734 ) ) + ( t826 -
intermediate_der11607 * 0.95 ) / ( t1122 == 0.0 ? 1.0E-16 : t1122 ) ;
intermediate_der11513 = intermediate_der11504 * t916 * 6.0 - t916 * t916 *
intermediate_der11504 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 <=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 * 0.95 ) {
intermediate_der11504 = t826 * 100000.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ) {
intermediate_der11504 = intermediate_der11607 * 100000.0 ; } else {
intermediate_der11504 = ( ( ( - intermediate_der11513 * t910 + ( 1.0 - t919 )
* t826 ) + intermediate_der11513 * t914 ) + intermediate_der11607 * t919 ) *
100000.0 ; } intermediate_der11513 = ( intermediate_der11607 -
intermediate_der11607 * 0.95 ) * ( - ( - t910 - t914 * 0.95 ) / ( t1734 ==
0.0 ? 1.0E-16 : t1734 ) ) + ( - t826 - intermediate_der11607 * 0.95 ) / (
t1122 == 0.0 ? 1.0E-16 : t1122 ) ; intermediate_der11622 =
intermediate_der11513 * t934 * 6.0 - t934 * t934 * intermediate_der11513 *
6.0 ; if ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27
<= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 * 0.95 ) {
intermediate_der11513 = t826 * 100000.0 ; } else if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu26 ) {
intermediate_der11513 = - intermediate_der11607 * 100000.0 ; } else {
intermediate_der11513 = ( ( ( - intermediate_der11622 * t910 + ( 1.0 - t1086
) * t826 ) + - t914 * intermediate_der11622 ) + - intermediate_der11607 *
t1086 ) * 100000.0 ; } intermediate_der11627 = ( ( real_T ) ( M [ 40ULL ] !=
0 ) * 2.0 - 1.0 ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ]
) ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t957
/ 7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ; t847 = ( ( real_T ) ( M [ 42ULL ] != 0 ) * 2.0 - 1.0
) * ( t690_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
t690_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( - t957 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ; if ( t957 >= 0.0 ) { intermediate_der11651 = ( t1015
- zc_int365 ) * 0.01 + ( intermediate_der11627 - ( ( real_T ) ( M [ 41ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [
176ULL ] ) ) * ( U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) )
* ( t957 / 7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) * t957 ; } else { intermediate_der11651 = - ( (
zc_int366 - zc_int367 ) * 0.01 ) - ( t847 - ( ( real_T ) ( M [ 43ULL ] != 0 )
* 2.0 - 1.0 ) * ( t1771 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) *
( t1771 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - t957 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) * t957 ; } t860 = pmf_sqrt ( ( ( real_T ) ( M [
126ULL ] != 0 ) * 2.0 - 1.0 ) * ( t901 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) ; t1734 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t837 = ( X [
195ULL ] - 1.01325 ) * pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) * 2.0 -
1.0 ) * ( t901 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t801 * 0.64 + ( X [ 195ULL ] - 1.01325 ) * ( ( real_T ) ( M [ 126ULL ] !=
0 ) * 2.0 - 1.0 ) * ( - ( t883 * 2.0 ) / ( t1734 == 0.0 ? 1.0E-16 : t1734 ) )
* ( 1.0 / ( t860 == 0.0 ? 1.0E-16 : t860 ) ) * intermediate_der11984 * t878 *
0.32 ; intermediate_der11984 = pmf_sqrt ( ( ( real_T ) ( M [ 137ULL ] != 0 )
* 2.0 - 1.0 ) * ( t898 / ( t882 == 0.0 ? 1.0E-16 : t882 ) / ( X [ 219ULL ] ==
0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) * t801 * 0.64 ; t1753 = ( zc_int43 -
zc_int43 * 0.95 ) * ( zc_int43 - zc_int43 * 0.95 ) ; intermediate_der11730 =
( intermediate_der11984 - intermediate_der11984 * 0.95 ) * ( - ( zc_int42 -
zc_int43 * 0.95 ) / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) ) + ( t837 -
intermediate_der11984 * 0.95 ) / ( U_idx_6 == 0.0 ? 1.0E-16 : U_idx_6 ) ;
t858 = intermediate_der11730 * zc_int17 * 6.0 - zc_int17 * zc_int17 *
intermediate_der11730 * 6.0 ; if ( t881 <= t880 * 0.95 ) {
intermediate_der11730 = t837 * 100000.0 ; } else if ( t881 >= t880 ) {
intermediate_der11730 = intermediate_der11984 * 100000.0 ; } else {
intermediate_der11730 = ( ( ( - t858 * zc_int42 + ( 1.0 - t1093 ) * t837 ) +
t858 * zc_int43 ) + intermediate_der11984 * t1093 ) * 100000.0 ; } t858 = (
intermediate_der11984 - intermediate_der11984 * 0.95 ) * ( - ( - zc_int42 -
zc_int43 * 0.95 ) / ( t1753 == 0.0 ? 1.0E-16 : t1753 ) ) + ( - t837 -
intermediate_der11984 * 0.95 ) / ( U_idx_6 == 0.0 ? 1.0E-16 : U_idx_6 ) ;
t1781 = t858 * zc_int180 * 6.0 - zc_int180 * zc_int180 * t858 * 6.0 ; if ( -
t881 <= t880 * 0.95 ) { t858 = t837 * 100000.0 ; } else if ( - t881 >= t880 )
{ t858 = - intermediate_der11984 * 100000.0 ; } else { t858 = ( ( ( - t1781 *
zc_int42 + ( 1.0 - t1096 ) * t837 ) + - zc_int43 * t1781 ) + -
intermediate_der11984 * t1096 ) * 100000.0 ; } t706 [ 0ULL ] = X [ 538ULL ] ;
t305 [ 0 ] = 5ULL ; tlu2_linear_nearest_prelookup ( & mh_efOut . mField0 [
0ULL ] , & mh_efOut . mField1 [ 0ULL ] , & mh_efOut . mField2 [ 0ULL ] , &
t701 [ 0ULL ] , & t706 [ 0ULL ] , & t305 [ 0ULL ] , & t75 [ 0ULL ] ) ; t67 =
mh_efOut ; t706 [ 0ULL ] = U_idx_12 * 376.99111843077515 *
0.99999999999999978 / 0.99999999999999978 * 0.99999999999999978 /
0.99999999999999978 ; t574 [ 0 ] = 3ULL ; tlu2_linear_nearest_prelookup ( &
nh_efOut . mField0 [ 0ULL ] , & nh_efOut . mField1 [ 0ULL ] , & nh_efOut .
mField2 [ 0ULL ] , & nonscalar64 [ 0ULL ] , & t706 [ 0ULL ] , & t574 [ 0ULL ]
, & t75 [ 0ULL ] ) ; t47 = nh_efOut ; t860 = M [ 214ULL ] != 0 ? X [ 81ULL ]
: 0.9 ; t837 = - ( ( X [ 90ULL ] - X [ 88ULL ] * X [ 89ULL ] * 0.001 ) * t72
/ ( t860 == 0.0 ? 1.0E-16 : t860 ) * 1000.0 + - t72 * X [ 81ULL ] / 1000.0 )
; if ( M [ 344ULL ] != 0 ) { t72 = - ( ( ( ( ( ( ( X [ 18ULL ] * 0.1 - X [
88ULL ] ) + X [ 89ULL ] * - 0.1 ) + X [ 172ULL ] * 1.0E-9 ) - X [ 174ULL ] )
+ X [ 19ULL ] ) - Fuel_Cell_Boost_Converter_L_i ) * t846 * 0.001 ) ; } else {
t72 = - ( ( Fuel_Cell_Boost_Converter_L_i * 0.001 + X [ 89ULL ] ) * t846 ) ;
} t698 [ 0ULL ] = - ( - ( 0.0 * ( X [ 161ULL ] / ( X [ 164ULL ] == 0.0 ?
1.0E-16 : X [ 164ULL ] ) ) ) / 1.1843079200592157 ) ; t698 [ 1ULL ] = 0.0 * (
X [ 161ULL ] / ( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [ 164ULL ] ) ) * ( X [
7ULL ] + 126.84999999999997 ) ; t698 [ 2ULL ] = ( ( 0.01 - t1762 ) * -
0.009810000000000001 + ( 0.01 - t1762 ) * 0.009810000000000001 ) - 0.0 * ( X
[ 15ULL ] / ( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [ 164ULL ] ) * 100.0 + X [
167ULL ] ) ; t698 [ 3ULL ] = ( - X [ 96ULL ] / ( t1181 == 0.0 ? 1.0E-16 :
t1181 ) * t775 - ( ( t1921 * t1101 - X [ 98ULL ] * t1925 ) + U_idx_9 * 100.0
) ) / 2.6578958850679178E+7 ; t698 [ 4ULL ] = - ( t1921 * t1101 + X [ 98ULL ]
* t1925 ) / 1.3398809999599461E+7 ; t698 [ 5ULL ] = ( X [ 96ULL ] / ( t1190
== 0.0 ? 1.0E-16 : t1190 ) * t1103 - ( ( t1860 * t1109 - X [ 98ULL ] * t1923
) + t838 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [ 6ULL ] = - ( t1860 *
t1109 + X [ 98ULL ] * t1923 ) / 1.3398809999599461E+7 ; t698 [ 7ULL ] = ( - X
[ 105ULL ] / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 - ( ( t1862 * t1101 -
X [ 107ULL ] * t1925 ) + t1111 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [
8ULL ] = - ( t1862 * t1101 + X [ 107ULL ] * t1925 ) / 1.3398809999599461E+7 ;
t698 [ 9ULL ] = ( X [ 105ULL ] / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 -
( ( t1867 * t1109 - X [ 107ULL ] * t1923 ) + t1794 * 100.0 ) ) /
2.6578958850679178E+7 ; t698 [ 10ULL ] = - ( t1867 * t1109 + X [ 107ULL ] *
t1923 ) / 1.3398809999599461E+7 ; t698 [ 11ULL ] = ( - X [ 114ULL ] / ( t1181
== 0.0 ? 1.0E-16 : t1181 ) * t775 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t1101 - X [
116ULL ] * t1925 ) + t1778 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [ 12ULL
] = - ( Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 *
t1101 + X [ 116ULL ] * t1925 ) / 1.3398809999599461E+7 ; t698 [ 13ULL ] = ( X
[ 114ULL ] / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t1109 - X [
116ULL ] * t1923 ) + t1789 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [ 14ULL
] = - ( Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 *
t1109 + X [ 116ULL ] * t1923 ) / 1.3398809999599461E+7 ; t698 [ 15ULL ] = ( -
X [ 114ULL ] / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t785 - X [
124ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) +
intermediate_der231 * 100.0 ) ) / 1.328947942533959E+8 ; t698 [ 16ULL ] = - (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t785 + X [
124ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t698 [ 17ULL ] = ( - X [ 121ULL ] / ( t1243 == 0.0 ?
1.0E-16 : t1243 ) * t786 - ( (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t789 - X [
126ULL ] * intermediate_der242 ) + intermediate_der239 * 100.0 ) ) /
1.328947942533959E+8 ; t698 [ 18ULL ] = - (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t789 + X [
126ULL ] * intermediate_der242 ) / 6.6994049997997306E+7 ; t698 [ 19ULL ] = -
( U_idx_10 * 0.001 ) / 28.173600337531049 ; t698 [ 20ULL ] = - (
intermediate_der8390 - t851 ) ; t698 [ 21ULL ] = ( - X [ 96ULL ] / ( t1234 ==
0.0 ? 1.0E-16 : t1234 ) * intermediate_der197 - ( ( t1860 * t785 - X [ 129ULL
] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) +
intermediate_der316 * 100.0 ) ) / 1.328947942533959E+8 ; t698 [ 22ULL ] = - (
t1860 * t785 + X [ 129ULL ] *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t698 [ 23ULL ] = ( X [ 105ULL ] / ( t1243 == 0.0 ?
1.0E-16 : t1243 ) * t786 - ( ( t1862 * t789 - X [ 131ULL ] *
intermediate_der242 ) + intermediate_der349 * 100.0 ) ) /
1.328947942533959E+8 ; t698 [ 24ULL ] = - ( t1862 * t789 + X [ 131ULL ] *
intermediate_der242 ) / 6.6994049997997306E+7 ; t698 [ 25ULL ] = - ( t790 *
0.001 ) ; t698 [ 26ULL ] = - ( t853 - intermediate_der9120 ) ; t698 [ 27ULL ]
= ( - X [ 105ULL ] / ( t1234 == 0.0 ? 1.0E-16 : t1234 ) * intermediate_der197
- ( ( t1867 * t785 - X [ 134ULL ] *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) + t795 * 100.0 )
) / 1.328947942533959E+8 ; t698 [ 28ULL ] = - ( t1867 * t785 + X [ 134ULL ] *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t698 [ 29ULL ] = ( X [ 114ULL ] / ( t1243 == 0.0 ?
1.0E-16 : t1243 ) * t786 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t789 - X [
136ULL ] * intermediate_der242 ) + t796 * 100.0 ) ) / 1.328947942533959E+8 ;
t698 [ 30ULL ] = - (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t789 + X [
136ULL ] * intermediate_der242 ) / 6.6994049997997306E+7 ; t698 [ 31ULL ] = -
( t793 * 0.001 ) ; t698 [ 32ULL ] = - ( t844 - intermediate_der9282 ) ; t698
[ 33ULL ] = ( - X [ 139ULL ] / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 - (
( Electrical_Cooling_System_Pump_convection_A_u_in * t1101 - X [ 141ULL ] *
t1925 ) + intermediate_der539 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [
34ULL ] = - ( Electrical_Cooling_System_Pump_convection_A_u_in * t1101 + X [
141ULL ] * t1925 ) / 1.3398809999599461E+7 ; t698 [ 35ULL ] = ( X [ 96ULL ] /
( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 - ( ( t1921 * t1109 - X [ 141ULL ]
* t1923 ) + intermediate_der546 * 100.0 ) ) / 2.6578958850679178E+7 ; t698 [
36ULL ] = - ( t1921 * t1109 + X [ 141ULL ] * t1923 ) / 1.3398809999599461E+7
; t698 [ 37ULL ] = intermediate_der553 * 100.0 ; t698 [ 38ULL ] = ( X [
139ULL ] / ( t1190 == 0.0 ? 1.0E-16 : t1190 ) * t1103 - ( (
Electrical_Cooling_System_Pump_convection_A_u_in * t1109 - X [ 167ULL ] *
t1923 ) + intermediate_der8465 * 100.0 ) ) / 2.65794426837838E+7 ; t698 [
39ULL ] = ( X [ 121ULL ] / ( t1181 == 0.0 ? 1.0E-16 : t1181 ) * t775 - ( (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t1101 - X [
167ULL ] * t1925 ) + t1924 * 100.0 ) ) / 2.65794426837838E+7 ; t698 [ 40ULL ]
= - ( Electrical_Cooling_System_Pump_convection_A_u_in * t1109 + X [ 167ULL ]
* t1923 ) / 1.3398809999599461E+7 ; t698 [ 41ULL ] = - (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t1101 + X [
167ULL ] * t1925 ) / 1.3398809999599461E+7 ; t698 [ 42ULL ] =
intermediate_der8498 ; t698 [ 43ULL ] = intermediate_der8500 ; t1924 = t878 *
t878 ; U_idx_1 = - ( ( ( real_T ) ( M [ 170ULL ] != 0 ) * 2.0 - 1.0 ) * (
t886 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 : X [ 220ULL ] ) ) * ( t886 / ( X [
220ULL ] == 0.0 ? 1.0E-16 : X [ 220ULL ] ) ) * ( X [ 186ULL ] / 0.64 / ( t878
== 0.0 ? 1.0E-16 : t878 ) ) * ( - ( X [ 186ULL ] / 0.64 ) / ( t1924 == 0.0 ?
1.0E-16 : t1924 ) ) * t801 * 2.0 / 2.0 * 9.999999999999999E-14 ) ; t700 [
0ULL ] = - ( ( - ( X [ 23ULL ] * - 0.01 ) * ( - 164.72089615570803 / (
intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) ) + - ( X [ 24ULL ] * -
0.01 ) * ( - 3827.6794129126583 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 :
intrm_sf_mf_95 ) ) ) / 12.896402563644669 ) ; t700 [ 1ULL ] = - ( ( ( - ( X [
23ULL ] * - 0.01 ) * ( t877 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) + - ( X [
24ULL ] * - 0.01 ) * ( t874 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 * - 0.01 ) /
2246.65922904024 ) ; t700 [ 2ULL ] = - ( X [ 23ULL ] * - 0.01 ) ; t700 [ 3ULL
] = - ( X [ 24ULL ] * - 0.01 ) ; t700 [ 4ULL ] = - ( ( - ( X [ 76ULL ] * 0.01
) * ( - 164.72089615570803 / ( t955 == 0.0 ? 1.0E-16 : t955 ) ) + - ( X [
75ULL ] * 0.01 ) * ( - 3827.6794129126583 / ( t955 == 0.0 ? 1.0E-16 : t955 )
) ) / 12.896402563644669 ) ; t700 [ 5ULL ] = - ( ( ( - ( X [ 76ULL ] * 0.01 )
* ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 - t774 )
+ - ( X [ 75ULL ] * 0.01 ) * ( t961 - t774 ) ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant26 * 0.01 ) /
2246.65922904024 ) ; t700 [ 6ULL ] = - ( X [ 76ULL ] * 0.01 ) ; t700 [ 7ULL ]
= - ( X [ 75ULL ] * 0.01 ) ; t700 [ 8ULL ] = - ( ( ( - 0.01 +
intermediate_der1148 ) / 2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 -
1.0 ) * ( t1130 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
t1130 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intermediate_der0 ) +
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 + t872 ) /
2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1130 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1130 / ( X [ 176ULL ] ==
0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( intermediate_der1148 - - 0.01 ) / 2.0 * X [
209ULL ] ) ; t700 [ 9ULL ] = - ( ( - 0.01 + intermediate_der1258 ) / 2.0 * X
[ 178ULL ] - ( intermediate_der1258 - - 0.01 ) / 2.0 * X [ 215ULL ] ) ; t700
[ 10ULL ] = - ( ( - 0.01 + intermediate_der1227 ) / 2.0 * X [ 177ULL ] - (
intermediate_der1227 - - 0.01 ) / 2.0 * X [ 214ULL ] ) ; t700 [ 11ULL ] = - (
intermediate_der1237 * 0.001 ) ; t700 [ 12ULL ] = - ( t1665 /
7.8539816339744827E-5 * 0.00031622776601683789 + intermediate_der8829 ) ;
t700 [ 13ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ? 0.0
: - intermediate_der10658 ; t1924 = X [ 199ULL ] * intrm_sf_mf_95 ; t700 [
14ULL ] = - ( ( ( real_T ) ( M [ 72ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1924 / ( X
[ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * ( t1924 / ( X [ 200ULL ] ==
0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t700 [ 15ULL ] = - ( ( ( real_T ) ( M [ 94ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t834 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) )
* ( t834 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t1925 = t957 + t960 ; t700 [ 16ULL ] = - ( ( ( 0.01
+ intrm_sf_mf_133 ) / 2.0 * t1013 + t1925 / 2.0 * ( ( ( real_T ) ( M [ 36ULL
] != 0 ) * 2.0 - 1.0 ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL
] ) ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t957 /
7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( intrm_sf_mf_133 - 0.01 ) / 2.0 * X [ 564ULL ] )
; t700 [ 17ULL ] = - ( ( 0.01 + intermediate_der7294 ) / 2.0 * X [ 555ULL ] -
( intermediate_der7294 - 0.01 ) / 2.0 * X [ 566ULL ] ) ; t700 [ 18ULL ] = - (
( 0.01 + t831 ) / 2.0 * X [ 554ULL ] - ( t831 - 0.01 ) / 2.0 * X [ 565ULL ] )
; t1778 = X [ 74ULL ] * t955 ; t700 [ 19ULL ] = - ( ( ( real_T ) ( M [ 38ULL
] != 0 ) * 2.0 - 1.0 ) * ( t1778 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL
] ) ) * ( t1778 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t957 /
7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t700 [ 20ULL ] = - ( ( ( 0.01 + intrm_sf_mf_133 ) /
2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1130 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1130 / ( X [ 176ULL ] ==
0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t957 / 7.8539816339744827E-5 ) * ( t957
/ 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intermediate_der0 )
+ t1925 / 2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1130 /
( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1130 / ( X [ 176ULL ]
== 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t957 / 7.8539816339744827E-5 ) *
127.32395447351628 * 2.0 / 2.0 * 9.999999999999999E-14 ) ) - (
intrm_sf_mf_133 - 0.01 ) / 2.0 * X [ 574ULL ] ) ; t700 [ 21ULL ] = - ( ( 0.01
+ intermediate_der7294 ) / 2.0 * X [ 178ULL ] - ( intermediate_der7294 - 0.01
) / 2.0 * X [ 576ULL ] ) ; t700 [ 22ULL ] = - ( ( 0.01 + t831 ) / 2.0 * X [
177ULL ] - ( t831 - 0.01 ) / 2.0 * X [ 575ULL ] ) ; t700 [ 23ULL ] = - ( ( (
- 0.01 + t843 ) / 2.0 * t1089 + ( - t957 + t960 ) / 2.0 * ( ( ( real_T ) ( M
[ 36ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X
[ 38ULL ] ) ) * ( t1125 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) *
( - t957 / 7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( t843 - - 0.01 ) / 2.0 * X [ 574ULL ] ) ; t700 [
24ULL ] = - ( ( - 0.01 + t842 ) / 2.0 * X [ 555ULL ] - ( t842 - - 0.01 ) /
2.0 * X [ 576ULL ] ) ; t700 [ 25ULL ] = - ( ( - 0.01 + t841 ) / 2.0 * X [
554ULL ] - ( t841 - - 0.01 ) / 2.0 * X [ 575ULL ] ) ; t700 [ 26ULL ] =
intermediate_der11651 ; t700 [ 27ULL ] = t847 ; t700 [ 28ULL ] =
intermediate_der11627 ; t701 [ 0ULL ] = - ( ( ( 1.0 - X [ 36ULL ] ) * ( -
164.72089615570803 / ( intrm_sf_mf_545 == 0.0 ? 1.0E-16 : intrm_sf_mf_545 ) )
+ - X [ 35ULL ] * ( - 3827.6794129126583 / ( intrm_sf_mf_545 == 0.0 ? 1.0E-16
: intrm_sf_mf_545 ) ) ) / 12.896402563644669 ) ; t701 [ 1ULL ] = - ( ( ( (
t899 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) * (
1.0 - X [ 36ULL ] ) + - X [ 35ULL ] * ( t897 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) ) +
intrm_sf_mf_543 ) / 2246.65922904024 ) ; t701 [ 2ULL ] = - X [ 36ULL ] ; t701
[ 3ULL ] = - X [ 35ULL ] ; t701 [ 4ULL ] = zc_int116 ; t702 [ 0ULL ] = - ( (
- X [ 313ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) / 2.0 *
t808 ) ; t702 [ 1ULL ] = - X [ 313ULL ] >= 0.0 ? - 10.0 : -
intermediate_der10272 ; t702 [ 2ULL ] = - ( ( X [ 313ULL ] + t765 ) / 2.0 *
intermediate_der10282 ) ; t702 [ 3ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu21 >= 0.0 ? -
intermediate_der3747 : - intermediate_der10355 ; t702 [ 4ULL ] = - ( U_idx_3
- t805 ) ; t1924 = X [ 347ULL ] * t915 ; t1925 = - ( X [ 347ULL ] * t915 ) ;
t702 [ 5ULL ] = - ( ( ( ( real_T ) ( M [ 335ULL ] != 0 ) * 2.0 - 1.0 ) * (
t1924 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ) * ( t1925
/ ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 + ( ( real_T ) ( M [ 335ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t1924 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1925 / ( t1408 == 0.0 ? 1.0E-16 : t1408 ) ) * 10.0 ) * ( X [ 313ULL ] /
0.64 / 0.0019634954084936209 ) * ( X [ 313ULL ] / 0.64 /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 ) ; t703 [ 0ULL ] = - (
( 1.0 - X [ 53ULL ] ) * ( - 164.72089615570803 / ( t771 == 0.0 ? 1.0E-16 :
t771 ) ) + - X [ 52ULL ] * ( 36.965491221318985 / ( t771 == 0.0 ? 1.0E-16 :
t771 ) ) ) ; t703 [ 1ULL ] = - ( ( ( ( ( t933 - X [ 51ULL ] * 0.461523 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) * ( 1.0 - X
[ 53ULL ] ) + - X [ 52ULL ] * ( t935 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) ) +
intrm_sf_mf_1142 ) / 2172.7681408465714 ) ; t703 [ 2ULL ] = - X [ 53ULL ] ;
t703 [ 3ULL ] = - X [ 52ULL ] ; t703 [ 4ULL ] = t828 ; t704 [ 0ULL ] = ( - (
- X [ 430ULL ] - X [ 431ULL ] ) / ( t1421 == 0.0 ? 1.0E-16 : t1421 ) *
intermediate_der5446 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 *
intermediate_der5455 - X [ 435ULL ] * intermediate_der3734 ) +
intermediate_der3732 * 100.0 ) ) / 1.233284047215034E+6 ; t704 [ 1ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 *
intermediate_der5455 + X [ 435ULL ] * intermediate_der3734 ) /
171803.29647667333 ; t704 [ 2ULL ] = ( - X [ 431ULL ] / ( t1430 == 0.0 ?
1.0E-16 : t1430 ) * intermediate_der5545 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 * t813 - X [
454ULL ] * intermediate_der5549 ) + ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1430 ==
0.0 ? 1.0E-16 : t1430 ) * intermediate_der5545 + 2.0 / ( t1486 == 0.0 ?
1.0E-16 : t1486 ) ) * 1.01325 / ( t1487 == 0.0 ? 1.0E-16 : t1487 ) * 100.0 )
) / 8.80132724281134E+6 ; t704 [ 3ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 * t813 + X [
454ULL ] * intermediate_der5549 ) / 1.2260736179143097E+6 ; t704 [ 4ULL ] = (
- X [ 452ULL ] / ( t1372 == 0.0 ? 1.0E-16 : t1372 ) * t814 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 * t817 - X [
454ULL ] * intermediate_der5557 ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1372 ==
0.0 ? 1.0E-16 : t1372 ) * t814 + - 2.0 / ( t1486 == 0.0 ? 1.0E-16 : t1486 ) )
* X [ 451ULL ] / ( t1488 == 0.0 ? 1.0E-16 : t1488 ) * 100.0 ) ) /
8.80132724281134E+6 ; t704 [ 5ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 * t817 + X [
454ULL ] * intermediate_der5557 ) / 1.2260736179143097E+6 ; t704 [ 6ULL ] = (
X [ 451ULL ] - 1.01325 ) * 2.0 / ( t1489 == 0.0 ? 1.0E-16 : t1489 ) * 100.0 ;
t704 [ 7ULL ] = ( X [ 452ULL ] / ( t1454 == 0.0 ? 1.0E-16 : t1454 ) * t820 -
( ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 *
intermediate_der5598 - X [ 457ULL ] * intermediate_der5597 ) + ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1454 ==
0.0 ? 1.0E-16 : t1454 ) * t820 + 2.0 / ( t1490 == 0.0 ? 1.0E-16 : t1490 ) ) *
X [ 451ULL ] / ( t1491 == 0.0 ? 1.0E-16 : t1491 ) * 100.0 ) ) /
6.3686514346761458E+7 ; t704 [ 8ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 *
intermediate_der5598 + X [ 457ULL ] * intermediate_der5597 ) /
8.87188408103589E+6 ; t704 [ 9ULL ] = - t850 ; t704 [ 10ULL ] = -
intermediate_der8069 ; t1924 = intrm_sf_mf_1534 * intrm_sf_mf_1534 ;
tlu2_2d_linear_nearest_value ( & oh_efOut [ 0ULL ] , & t67 . mField0 [ 0ULL ]
, & t67 . mField2 [ 0ULL ] , & t47 . mField1 [ 0ULL ] , & t47 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField51 , & t305 [ 0ULL ] , &
t574 [ 0ULL ] , & t75 [ 0ULL ] ) ; t706 [ 0 ] = oh_efOut [ 0 ] ; t579 [ 0ULL
] = - ( ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I *
0.031415926535897927 / 0.01 + intermediate_der149 ) * 0.001 ) /
28.173600337531049 ; t579 [ 1ULL ] = t837 ; for ( t714 = 0ULL ; t714 < 44ULL
; t714 ++ ) { t579 [ t714 + 2ULL ] = t698 [ t714 ] ; } t579 [ 46ULL ] = t881
>= 0.0 ? - intermediate_der11730 : - t858 ; t579 [ 47ULL ] = t802 ; t579 [
48ULL ] = U_idx_1 ; for ( t714 = 0ULL ; t714 < 29ULL ; t714 ++ ) { t579 [
t714 + 49ULL ] = t700 [ t714 ] ; } for ( t714 = 0ULL ; t714 < 5ULL ; t714 ++
) { t579 [ t714 + 78ULL ] = t701 [ t714 ] ; } t579 [ 83ULL ] = U_idx_5 *
intermediate_der693 ; for ( t714 = 0ULL ; t714 < 6ULL ; t714 ++ ) { t579 [
t714 + 84ULL ] = t702 [ t714 ] ; } for ( t714 = 0ULL ; t714 < 5ULL ; t714 ++
) { t579 [ t714 + 90ULL ] = t703 [ t714 ] ; } t579 [ 95ULL ] = U_idx_8 *
intermediate_der10891 ; for ( t714 = 0ULL ; t714 < 11ULL ; t714 ++ ) { t579 [
t714 + 96ULL ] = t704 [ t714 ] ; } t579 [ 107ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu27 >= 0.0 ? -
intermediate_der11504 : - intermediate_der11513 ; t579 [ 108ULL ] = t762 ;
t579 [ 109ULL ] = - ( ( ( real_T ) ( M [ 25ULL ] != 0 ) * 2.0 - 1.0 ) * (
t943 / ( X [ 507ULL ] == 0.0 ? 1.0E-16 : X [ 507ULL ] ) ) * ( t943 / ( X [
507ULL ] == 0.0 ? 1.0E-16 : X [ 507ULL ] ) ) * ( - X [ 478ULL ] / 0.64 / (
intrm_sf_mf_1534 == 0.0 ? 1.0E-16 : intrm_sf_mf_1534 ) ) * ( - ( - X [ 478ULL
] / 0.64 ) / ( t1924 == 0.0 ? 1.0E-16 : t1924 ) ) * intermediate_der6946 *
2.0 / 2.0 * 9.999999999999999E-14 ) ; t579 [ 110ULL ] = - ( t706 [ 0ULL ] *
376.99111843077515 ) ; t579 [ 111ULL ] = t72 ; t579 [ 112ULL ] = - (
Fuel_Cell_Boost_Converter_L_i * t846 ) ; for ( b = 0 ; b < 113 ; b ++ ) { out
. mX [ b ] = t579 [ b ] ; } ( void ) LC ; ( void ) t1927 ; return 0 ; }
