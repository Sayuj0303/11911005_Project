#ifndef __FCElectricPlant_ac851afd_1_gateway_h__
#define __FCElectricPlant_ac851afd_1_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void FCElectricPlant_ac851afd_1_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
