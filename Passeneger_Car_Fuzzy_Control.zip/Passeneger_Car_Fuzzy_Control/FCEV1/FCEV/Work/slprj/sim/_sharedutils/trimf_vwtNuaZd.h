#ifndef RTW_HEADER_trimf_vwtNuaZd_h_
#define RTW_HEADER_trimf_vwtNuaZd_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T trimf_vwtNuaZd(real_T x, const real_T params[3]);

#endif
