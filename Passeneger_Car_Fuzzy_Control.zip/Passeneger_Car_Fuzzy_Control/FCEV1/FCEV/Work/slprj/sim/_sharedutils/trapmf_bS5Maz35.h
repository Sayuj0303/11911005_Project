#ifndef RTW_HEADER_trapmf_bS5Maz35_h_
#define RTW_HEADER_trapmf_bS5Maz35_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T trapmf_bS5Maz35(real_T x, const real_T params[4]);

#endif
