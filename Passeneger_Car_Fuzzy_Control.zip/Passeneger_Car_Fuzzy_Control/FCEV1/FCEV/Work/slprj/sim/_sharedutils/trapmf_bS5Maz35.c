#include "rtwtypes.h"
#include "trapmf_bS5Maz35.h"
#include "mwmathutil.h"

real_T trapmf_bS5Maz35(real_T x, const real_T params[4])
{
  real_T b_x;
  real_T b_y;
  b_x = 0.0;
  b_y = 0.0;
  if (x >= params[1]) {
    b_x = 1.0;
  }

  if (x < params[0]) {
    b_x = 0.0;
  }

  if ((params[0] <= x) && (x < params[1]) && (params[0] != params[1])) {
    b_x = 1.0 / (params[1] - params[0]) * (x - params[0]);
  }

  if (x <= params[2]) {
    b_y = 1.0;
  }

  if (x > params[3]) {
    b_y = 0.0;
  }

  if ((params[2] < x) && (x <= params[3]) && (params[2] != params[3])) {
    b_y = 1.0 / (params[3] - params[2]) * (params[3] - x);
  }

  return muDoubleScalarMin(b_x, b_y);
}
