#ifndef RTW_HEADER_interp2_0XbyHNhZ_h_
#define RTW_HEADER_interp2_0XbyHNhZ_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T interp2_0XbyHNhZ(const real_T varargin_1[3], const real_T
  varargin_2[3], const real_T varargin_3[9], real_T varargin_4, real_T
  varargin_5);

#endif
