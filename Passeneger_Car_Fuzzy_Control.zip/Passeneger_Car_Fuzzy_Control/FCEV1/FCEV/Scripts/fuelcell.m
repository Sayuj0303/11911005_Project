function out = fuelcell(~)
%fc = sugfis("Name","fuelcell.fis");
fc= sugfis;

fc = addInput(fc,[0 100],"Name","SOC");
fc = addInput(fc,[0 500],"Name","Power_Required");    %kw

fc = addOutput(fc,[0 1000],"Name","Output_Power");    %kw

% MF for input1
fc = addMF(fc,"SOC","trimf",[0 10 20],"Name","L");
fc = addMF(fc,"SOC","trimf",[20 40 60],"Name","M");
fc = addMF(fc,"SOC","trimf",[60 80 100],"Name","H");

% MF for input2
fc = addMF(fc,"Power_Required","trimf",[0 50 100],"Name","VL");
fc = addMF(fc,"Power_Required","trimf",[100 150 200],"Name","L");
fc = addMF(fc,"Power_Required","trimf",[200 250 300],"Name","M");
fc = addMF(fc,"Power_Required","trimf",[300 350 400],"Name","H");
fc = addMF(fc,"Power_Required","trimf",[400 450 500],"Name","VH");

% MF for output1 
fc = addMF(fc,"Output_Power","constant",10,"Name","VL");
fc = addMF(fc,"Output_Power","constant",100,"Name","L");
fc = addMF(fc,"Output_Power","constant",250,"Name","M");
fc = addMF(fc,"Output_Power","constant",500,"Name","H");
fc = addMF(fc,"Output_Power","constant",1000,"Name","VH");

ruleList =[ 1 1 1 1 2;
            2 0 2 1 1;
            3 2 3 1 2;
];

fc = addRule(fc,ruleList);

%writeFIS(fc,fuelcell);

out= evalfis(fc, [1 2]);
