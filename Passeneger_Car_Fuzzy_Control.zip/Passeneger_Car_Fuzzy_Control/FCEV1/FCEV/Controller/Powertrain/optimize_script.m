%fitness= 0.5*max((Sys_Out1.Data(end))); %ITAE + IAU
warning off
rng default
lb = 1*ones(1,4);     % You can change the lower and upper bounds on the search domain.
ub = 1000*ones(1,4);  % You can change the lower and upper bounds on the search domain.
options = optimoptions('particleswarm','PlotFcns',@pswplotbestf,'MaxIter',100,'SwarmSize',30);
[x,fval,exitflag] = particleswarm(func,lb,ub,options)

function func(~)
%only T
%assignin('base', 'Ta', [x(1) x(2) x(3) x(4)]);
sim("Controller\Powertrain\FCEvPowertrainController.slx",15);
%Step = stepinfo(system);
%fitness=(Step.Peak-1)+Step.Overshoot;
%fitness=max(Sys_Out1.Data);
%fitness=0.5*max(system); %ITAE + IAU
end
