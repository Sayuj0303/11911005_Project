function fitness=func(~)
%only T
assignin('base', 'Ta', [x(1) x(2) x(3) x(4)]);
sim( "Controller\Powertrain\FCEvPowertrainController.slx",15);
%Step = stepinfo(Sys_Out.Data,Sys_Out.Time);
%fitness=(Step.Peak-1)+Step.Overshoot;
%fitness=max(Sys_Out1.Data);
fitness=0.5*max((Sys_Out1.Data(end)))+0.5*max((Sys_Out2.Data(end))); %ITAE + IAU
end