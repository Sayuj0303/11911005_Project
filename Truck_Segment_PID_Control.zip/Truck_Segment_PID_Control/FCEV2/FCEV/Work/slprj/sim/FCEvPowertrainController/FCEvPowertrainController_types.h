#ifndef RTW_HEADER_FCEvPowertrainController_types_h_
#define RTW_HEADER_FCEvPowertrainController_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_IDgMmAocjV2Mcx0AXuhokB_
#define DEFINED_TYPEDEF_FOR_struct_IDgMmAocjV2Mcx0AXuhokB_
typedef struct { real_T maxPWR ; real_T opLimit ; real_T minV ; real_T SOCtgt
; real_T tempTgt ; } struct_IDgMmAocjV2Mcx0AXuhokB ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 18
#endif
#ifndef SS_INT64
#define SS_INT64 19
#endif
typedef struct gdngfg3ibwc_ gdngfg3ibwc ; typedef struct ax55bwwar2
ezkw1qrycv ;
#endif
