#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_zc.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_zc ( const NeDynamicSystem * LC , const
NeDynamicSystemInput * t558 , NeDsMethodOutput * t559 ) { ETTS0 ab_efOut ;
ETTS0 b_efOut ; ETTS0 cb_efOut ; ETTS0 d_efOut ; ETTS0 db_efOut ; ETTS0
e_efOut ; ETTS0 efOut ; ETTS0 fb_efOut ; ETTS0 g_efOut ; ETTS0 h_efOut ;
ETTS0 hb_efOut ; ETTS0 j_efOut ; ETTS0 jb_efOut ; ETTS0 k_efOut ; ETTS0
lb_efOut ; ETTS0 m_efOut ; ETTS0 n_efOut ; ETTS0 nb_efOut ; ETTS0 p_efOut ;
ETTS0 pb_efOut ; ETTS0 q_efOut ; ETTS0 qb_efOut ; ETTS0 s_efOut ; ETTS0
sb_efOut ; ETTS0 t1 ; ETTS0 t21 ; ETTS0 t22 ; ETTS0 t24 ; ETTS0 t25 ; ETTS0
t27 ; ETTS0 t28 ; ETTS0 t8 ; ETTS0 t_efOut ; ETTS0 ub_efOut ; ETTS0 v_efOut ;
ETTS0 w_efOut ; ETTS0 wb_efOut ; ETTS0 xb_efOut ; ETTS0 y_efOut ;
PmRealVector out ; real_T X [ 582 ] ; real_T t186 [ 381 ] ; real_T nonscalar1
[ 7 ] ; real_T bb_efOut [ 1 ] ; real_T c_efOut [ 1 ] ; real_T eb_efOut [ 1 ]
; real_T f_efOut [ 1 ] ; real_T gb_efOut [ 1 ] ; real_T i_efOut [ 1 ] ;
real_T ib_efOut [ 1 ] ; real_T kb_efOut [ 1 ] ; real_T l_efOut [ 1 ] ; real_T
mb_efOut [ 1 ] ; real_T o_efOut [ 1 ] ; real_T ob_efOut [ 1 ] ; real_T
r_efOut [ 1 ] ; real_T rb_efOut [ 1 ] ; real_T t180 [ 1 ] ; real_T t207 [ 1 ]
; real_T tb_efOut [ 1 ] ; real_T u_efOut [ 1 ] ; real_T vb_efOut [ 1 ] ;
real_T x_efOut [ 1 ] ; real_T yb_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B ; real_T
Electrical_Cooling_System_Tank_Tank_level ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ; real_T
U_idx_11 ; real_T U_idx_13 ; real_T U_idx_3 ; real_T U_idx_6 ; real_T U_idx_7
; real_T U_idx_9 ; real_T intrm_sf_mf_1006 ; real_T intrm_sf_mf_1144 ; real_T
intrm_sf_mf_1387 ; real_T intrm_sf_mf_1399 ; real_T intrm_sf_mf_1543 ; real_T
intrm_sf_mf_1634 ; real_T intrm_sf_mf_1659 ; real_T intrm_sf_mf_1670 ; real_T
intrm_sf_mf_1672 ; real_T intrm_sf_mf_1696 ; real_T intrm_sf_mf_1739 ; real_T
intrm_sf_mf_1740 ; real_T intrm_sf_mf_1741 ; real_T intrm_sf_mf_1742 ; real_T
intrm_sf_mf_1743 ; real_T intrm_sf_mf_1744 ; real_T intrm_sf_mf_1772 ; real_T
intrm_sf_mf_1773 ; real_T intrm_sf_mf_1774 ; real_T intrm_sf_mf_1799 ; real_T
intrm_sf_mf_237 ; real_T intrm_sf_mf_239 ; real_T intrm_sf_mf_252 ; real_T
intrm_sf_mf_290 ; real_T intrm_sf_mf_335 ; real_T intrm_sf_mf_543 ; real_T
intrm_sf_mf_684 ; real_T intrm_sf_mf_685 ; real_T intrm_sf_mf_694 ; real_T
intrm_sf_mf_83 ; real_T intrm_sf_mf_836 ; real_T intrm_sf_mf_838 ; real_T
intrm_sf_mf_904 ; real_T intrm_sf_mf_934 ; real_T intrm_sf_mf_95 ; real_T
t220 ; real_T t247 ; real_T t268 ; real_T t274 ; real_T t283 ; real_T t284 ;
real_T t285 ; real_T t287 ; real_T t290 ; real_T t293 ; real_T t296 ; real_T
t298 ; real_T t299 ; real_T t301 ; real_T t302 ; real_T t303 ; real_T t305 ;
real_T t306 ; real_T t308 ; real_T t310 ; real_T t313 ; real_T t315 ; real_T
t316 ; real_T t319 ; real_T t320 ; real_T t321 ; real_T t323 ; real_T t324 ;
real_T t325 ; real_T t328 ; real_T t331 ; real_T t336 ; real_T t338 ; real_T
t339 ; real_T t480 ; real_T t482 ; real_T t485 ; real_T t499 ; real_T t504 ;
real_T t511 ; real_T t512 ; real_T t523 ; real_T t524 ; size_t t37 [ 1 ] ;
size_t t38 [ 1 ] ; size_t t40 [ 1 ] ; size_t t210 ; size_t t211 ; int32_T M [
361 ] ; int32_T b ; for ( b = 0 ; b < 361 ; b ++ ) { M [ b ] = t558 -> mM .
mX [ b ] ; } U_idx_3 = t558 -> mU . mX [ 3 ] ; U_idx_6 = t558 -> mU . mX [ 6
] ; U_idx_7 = t558 -> mU . mX [ 7 ] ; U_idx_9 = t558 -> mU . mX [ 9 ] ;
U_idx_11 = t558 -> mU . mX [ 11 ] ; U_idx_13 = t558 -> mU . mX [ 13 ] ; for (
b = 0 ; b < 582 ; b ++ ) { X [ b ] = t558 -> mX . mX [ b ] ; } out = t559 ->
mZC ; nonscalar1 [ 0 ] = 190800.0 ; nonscalar1 [ 1 ] = 190800.0 ; nonscalar1
[ 2 ] = 190800.0 ; nonscalar1 [ 3 ] = 190800.0 ; nonscalar1 [ 4 ] = 190800.0
; nonscalar1 [ 5 ] = 190800.0 ; nonscalar1 [ 6 ] = 190800.0 ; t480 = ( X [
113ULL ] + X [ 120ULL ] ) / 2.0 ; t180 [ 0ULL ] = X [ 6ULL ] ; t37 [ 0 ] =
20ULL ; t38 [ 0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut . mField0 [
0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] ,
& t38 [ 0ULL ] ) ; t1 = efOut ; t180 [ 0ULL ] = t480 ; t40 [ 0 ] = 19ULL ;
tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = c_efOut [ 0 ] ;
t482 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 123ULL ] ;
tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= d_efOut ; t180 [ 0ULL ] = X [ 113ULL ] ; tlu2_linear_linear_prelookup ( &
e_efOut . mField0 [ 0ULL ] , & e_efOut . mField1 [ 0ULL ] , & e_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t21 = e_efOut ;
tlu2_2d_linear_linear_value ( & f_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ] ,
& t25 . mField2 [ 0ULL ] , & t21 . mField0 [ 0ULL ] , & t21 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = f_efOut [ 0 ] ; t485 = t207 [ 0ULL ]
; t180 [ 0ULL ] = X [ 125ULL ] ; tlu2_linear_linear_prelookup ( & g_efOut .
mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [
0ULL ] , & t38 [ 0ULL ] ) ; t25 = g_efOut ; t180 [ 0ULL ] = X [ 120ULL ] ;
tlu2_linear_linear_prelookup ( & h_efOut . mField0 [ 0ULL ] , & h_efOut .
mField1 [ 0ULL ] , & h_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t28
= h_efOut ; tlu2_2d_linear_linear_value ( & i_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t28 . mField0 [ 0ULL ] , &
t28 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t37 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = i_efOut [ 0 ]
; t504 = t207 [ 0ULL ] ; t499 = ( X [ 95ULL ] + X [ 102ULL ] ) / 2.0 ; t180 [
0ULL ] = X [ 9ULL ] ; tlu2_linear_linear_prelookup ( & j_efOut . mField0 [
0ULL ] , & j_efOut . mField1 [ 0ULL ] , & j_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] ,
& t38 [ 0ULL ] ) ; t1 = j_efOut ; t180 [ 0ULL ] = t499 ;
tlu2_linear_linear_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= k_efOut ; tlu2_2d_linear_linear_value ( & l_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = l_efOut [ 0 ] ;
t523 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 128ULL ] ;
tlu2_linear_linear_prelookup ( & m_efOut . mField0 [ 0ULL ] , & m_efOut .
mField1 [ 0ULL ] , & m_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= m_efOut ; t180 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup ( &
n_efOut . mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t24 = n_efOut ;
tlu2_2d_linear_linear_value ( & o_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ] ,
& t25 . mField2 [ 0ULL ] , & t24 . mField0 [ 0ULL ] , & t24 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = o_efOut [ 0 ] ; t524 = t207 [ 0ULL ]
; t180 [ 0ULL ] = X [ 130ULL ] ; tlu2_linear_linear_prelookup ( & p_efOut .
mField0 [ 0ULL ] , & p_efOut . mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [
0ULL ] , & t38 [ 0ULL ] ) ; t22 = p_efOut ; t180 [ 0ULL ] = X [ 102ULL ] ;
tlu2_linear_linear_prelookup ( & q_efOut . mField0 [ 0ULL ] , & q_efOut .
mField1 [ 0ULL ] , & q_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t27
= q_efOut ; tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t22 .
mField0 [ 0ULL ] , & t22 . mField2 [ 0ULL ] , & t27 . mField0 [ 0ULL ] , &
t27 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t37 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = r_efOut [ 0 ]
; t511 = t207 [ 0ULL ] ; t512 = ( X [ 104ULL ] + X [ 111ULL ] ) / 2.0 ; t180
[ 0ULL ] = X [ 11ULL ] ; tlu2_linear_linear_prelookup ( & s_efOut . mField0 [
0ULL ] , & s_efOut . mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] ,
& t38 [ 0ULL ] ) ; t1 = s_efOut ; t180 [ 0ULL ] = t512 ;
tlu2_linear_linear_prelookup ( & t_efOut . mField0 [ 0ULL ] , & t_efOut .
mField1 [ 0ULL ] , & t_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= t_efOut ; tlu2_2d_linear_linear_value ( & u_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = u_efOut [ 0 ] ;
t283 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 133ULL ] ;
tlu2_linear_linear_prelookup ( & v_efOut . mField0 [ 0ULL ] , & v_efOut .
mField1 [ 0ULL ] , & v_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t22
= v_efOut ; t180 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup ( &
w_efOut . mField0 [ 0ULL ] , & w_efOut . mField1 [ 0ULL ] , & w_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t8 = w_efOut ;
tlu2_2d_linear_linear_value ( & x_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ] ,
& t22 . mField2 [ 0ULL ] , & t8 . mField0 [ 0ULL ] , & t8 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = x_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A = t207 [ 0ULL
] ; t180 [ 0ULL ] = X [ 135ULL ] ; tlu2_linear_linear_prelookup ( & y_efOut .
mField0 [ 0ULL ] , & y_efOut . mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [
0ULL ] , & t38 [ 0ULL ] ) ; t25 = y_efOut ; t180 [ 0ULL ] = X [ 111ULL ] ;
tlu2_linear_linear_prelookup ( & ab_efOut . mField0 [ 0ULL ] , & ab_efOut .
mField1 [ 0ULL ] , & ab_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t180 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t22
= ab_efOut ; tlu2_2d_linear_linear_value ( & bb_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t22 . mField0 [ 0ULL ] , &
t22 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t37 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = bb_efOut [ 0
] ; Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B = t207 [
0ULL ] ; Electrical_Cooling_System_Tank_Tank_level = X [ 158ULL ] * - 0.2 +
0.2 ; if ( X [ 191ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
191ULL ] >= 1.0 ? 1.0 : X [ 191ULL ] ; } if ( X [ 192ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = X [
192ULL ] >= 1.0 ? 1.0 : X [ 192ULL ] ; } intrm_sf_mf_83 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
4124.48151675695 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 24ULL
] >= 1.0 ? 1.0 : X [ 24ULL ] ; } intrm_sf_mf_95 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
4124.48151675695 ; if ( X [ 199ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 = X [ 199ULL
] >= 623.15 ? 623.15 : X [ 199ULL ] ; } t220 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 ;
intrm_sf_mf_237 = ( ( ( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 * -
0.22145652610641059 ) + t220 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
1.2002114337050787 ) + t220 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
6.9647057412840034 ) + t220 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t284 =
intrm_sf_mf_237 - intrm_sf_mf_95 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 =
intrm_sf_mf_237 / ( t284 == 0.0 ? 1.0E-16 : t284 ) ; if ( X [ 203ULL ] <=
216.59999999999997 ) { intrm_sf_mf_237 = 216.59999999999997 ; } else {
intrm_sf_mf_237 = X [ 203ULL ] >= 623.15 ? 623.15 : X [ 203ULL ] ; } t284 =
intrm_sf_mf_237 * intrm_sf_mf_237 ; t220 = ( ( ( 1074.1165326382554 +
intrm_sf_mf_237 * - 0.22145652610641059 ) + t284 * 0.0003721298010901061 ) *
( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) + ( (
1479.6504774710402 + intrm_sf_mf_237 * 1.2002114337050787 ) + t284 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) + ( (
12825.281119789837 + intrm_sf_mf_237 * 6.9647057412840034 ) + t284 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t285 = t220
- intrm_sf_mf_95 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = t220 / (
t285 == 0.0 ? 1.0E-16 : t285 ) ; if ( X [ 178ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 178ULL
] >= 1.0 ? 1.0 : X [ 178ULL ] ; } if ( X [ 177ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 177ULL ] >= 1.0 ? 1.0
: X [ 177ULL ] ; } t220 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) -
intrm_sf_mf_237 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 461.523 ) +
intrm_sf_mf_237 * 4124.48151675695 ; if ( X [ 197ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 197ULL
] >= 1.0 ? 1.0 : X [ 197ULL ] ; } if ( X [ 196ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 196ULL ] >= 1.0 ? 1.0
: X [ 196ULL ] ; } t284 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) -
intrm_sf_mf_237 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 461.523 ) +
intrm_sf_mf_237 * 4124.48151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = U_idx_3 *
0.031415926535897927 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 <=
7.8539816339744857E-13 ) { intrm_sf_mf_237 = 7.8539816339744857E-13 ; } else
if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001
>= 3.1415926535897929E-6 ) { intrm_sf_mf_237 = 3.1415926535897929E-6 ; } else
{ intrm_sf_mf_237 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
intrm_sf_mf_237 / 7.8539816339744827E-5 ; if ( X [ 221ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 221ULL ] >= 1.0 ? 1.0
: X [ 221ULL ] ; } if ( X [ 222ULL ] <= 0.0 ) { t285 = 0.0 ; } else { t285 =
X [ 222ULL ] >= 1.0 ? 1.0 : X [ 222ULL ] ; } intrm_sf_mf_239 = ( ( ( 1.0 -
intrm_sf_mf_237 ) - t285 ) * 296.802103844292 + intrm_sf_mf_237 * 461.523 ) +
t285 * 4124.48151675695 ; t287 = X [ 219ULL ] * intrm_sf_mf_239 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 220ULL ]
/ ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [
219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t290 = X [ 220ULL ] / 1.01325
* ( X [ 224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ;
intrm_sf_mf_543 = ( X [ 195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ;
t293 = ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3
) * ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 )
; intrm_sf_mf_290 = intrm_sf_mf_543 * t293 ; intrm_sf_mf_335 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t290 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( X [ 195ULL
] - 1.01325 ) * ( intrm_sf_mf_335 >= t293 ? intrm_sf_mf_335 : t293 ) ;
intrm_sf_mf_335 = ( X [ 195ULL ] - 1.01325 ) / ( intrm_sf_mf_543 == 0.0 ?
1.0E-16 : intrm_sf_mf_543 ) ; t296 = intrm_sf_mf_335 * intrm_sf_mf_335 * 3.0
- intrm_sf_mf_335 * intrm_sf_mf_335 * intrm_sf_mf_335 * 2.0 ; if ( X [ 195ULL
] - 1.01325 <= 0.0 ) { intrm_sf_mf_335 = intrm_sf_mf_290 ; } else if ( X [
195ULL ] - 1.01325 >= intrm_sf_mf_543 ) { intrm_sf_mf_335 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; } else {
intrm_sf_mf_335 = ( 1.0 - t296 ) * intrm_sf_mf_290 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 * t296 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t290 )
- ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.01325 -
X [ 195ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >= t293 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 : t293 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = ( 1.01325 -
X [ 195ULL ] ) / ( intrm_sf_mf_543 == 0.0 ? 1.0E-16 : intrm_sf_mf_543 ) ;
t290 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 2.0 ; if (
1.01325 - X [ 195ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
intrm_sf_mf_290 ; } else if ( 1.01325 - X [ 195ULL ] >= intrm_sf_mf_543 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = ( 1.0 - t290
) * intrm_sf_mf_290 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t290 ; } if
( X [ 195ULL ] > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
intrm_sf_mf_335 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 195ULL ]
< 1.01325 ? Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 :
intrm_sf_mf_290 ; } if ( X [ 219ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 219ULL ]
>= 623.15 ? 623.15 : X [ 219ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; t290 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_237 ) - t285 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.00038614513167845434 ) * intrm_sf_mf_237 ) + ( ( 12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.0070524868246844051 ) * t285 ; t298 = t290 - intrm_sf_mf_239 ;
intrm_sf_mf_237 = t290 / ( t298 == 0.0 ? 1.0E-16 : t298 ) ; if ( X [ 27ULL ]
<= 0.0 ) { t285 = 0.0 ; } else { t285 = X [ 27ULL ] >= 1.0 ? 1.0 : X [ 27ULL
] ; } if ( X [ 26ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 26ULL
] >= 1.0 ? 1.0 : X [ 26ULL ] ; } t290 = ( ( ( 1.0 - t285 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) *
296.802103844292 + t285 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
4124.48151675695 ; if ( X [ 245ULL ] <= 216.59999999999997 ) { t293 =
216.59999999999997 ; } else { t293 = X [ 245ULL ] >= 623.15 ? 623.15 : X [
245ULL ] ; } t298 = t293 * t293 ; intrm_sf_mf_543 = ( ( ( 1074.1165326382554
+ t293 * - 0.22145652610641059 ) + t298 * 0.0003721298010901061 ) * ( ( 1.0 -
t285 ) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + (
( 1479.6504774710402 + t293 * 1.2002114337050787 ) + t298 * -
0.00038614513167845434 ) * t285 ) + ( ( 12825.281119789837 + t293 *
6.9647057412840034 ) + t298 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; t299 =
intrm_sf_mf_543 - t290 ; t293 = intrm_sf_mf_543 / ( t299 == 0.0 ? 1.0E-16 :
t299 ) ; if ( X [ 248ULL ] <= 216.59999999999997 ) { intrm_sf_mf_543 =
216.59999999999997 ; } else { intrm_sf_mf_543 = X [ 248ULL ] >= 623.15 ?
623.15 : X [ 248ULL ] ; } t299 = intrm_sf_mf_543 * intrm_sf_mf_543 ;
intrm_sf_mf_290 = ( ( ( 1074.1165326382554 + intrm_sf_mf_543 * -
0.22145652610641059 ) + t299 * 0.0003721298010901061 ) * ( ( 1.0 - t285 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
1479.6504774710402 + intrm_sf_mf_543 * 1.2002114337050787 ) + t299 * -
0.00038614513167845434 ) * t285 ) + ( ( 12825.281119789837 + intrm_sf_mf_543
* 6.9647057412840034 ) + t299 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 =
intrm_sf_mf_290 - t290 ; t285 = intrm_sf_mf_290 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ;
if ( X [ 243ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 243ULL
] >= 1.0 ? 1.0 : X [ 243ULL ] ; } if ( X [ 242ULL ] <= 0.0 ) {
intrm_sf_mf_543 = 0.0 ; } else { intrm_sf_mf_543 = X [ 242ULL ] >= 1.0 ? 1.0
: X [ 242ULL ] ; } intrm_sf_mf_290 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 229ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 229ULL
] >= 1.0 ? 1.0 : X [ 229ULL ] ; } if ( X [ 228ULL ] <= 0.0 ) {
intrm_sf_mf_543 = 0.0 ; } else { intrm_sf_mf_543 = X [ 228ULL ] >= 1.0 ? 1.0
: X [ 228ULL ] ; } intrm_sf_mf_335 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 30ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 30ULL
] >= 1.0 ? 1.0 : X [ 30ULL ] ; } if ( X [ 29ULL ] <= 0.0 ) { intrm_sf_mf_543
= 0.0 ; } else { intrm_sf_mf_543 = X [ 29ULL ] >= 1.0 ? 1.0 : X [ 29ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 263ULL ] <= 216.59999999999997
) { t296 = 216.59999999999997 ; } else { t296 = X [ 263ULL ] >= 623.15 ?
623.15 : X [ 263ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = t296 * t296
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = ( ( (
1074.1165326382554 + t296 * - 0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) + ( ( 1479.6504774710402 + t296 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
12825.281119789837 + t296 * 6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 * -
0.0070524868246844051 ) * intrm_sf_mf_543 ; t301 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; t296 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( t301 ==
0.0 ? 1.0E-16 : t301 ) ; if ( X [ 265ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [ 265ULL
] >= 623.15 ? 623.15 : X [ 265ULL ] ; } t301 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t298 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.22145652610641059 ) + t301 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
1.2002114337050787 ) + t301 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
6.9647057412840034 ) + t301 * - 0.0070524868246844051 ) * intrm_sf_mf_543 ;
t302 = t298 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = t298 / (
t302 == 0.0 ? 1.0E-16 : t302 ) ; if ( X [ 36ULL ] <= 0.0 ) { intrm_sf_mf_543
= 0.0 ; } else { intrm_sf_mf_543 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; }
if ( X [ 35ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t298 = ( ( ( 1.0 - intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + intrm_sf_mf_543 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
4124.48151675695 ; if ( X [ 289ULL ] <= 216.59999999999997 ) { t299 =
216.59999999999997 ; } else { t299 = X [ 289ULL ] >= 623.15 ? 623.15 : X [
289ULL ] ; } t302 = t299 * t299 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( ( (
1074.1165326382554 + t299 * - 0.22145652610641059 ) + t302 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t299 * 1.2002114337050787 ) + t302 * -
0.00038614513167845434 ) * intrm_sf_mf_543 ) + ( ( 12825.281119789837 + t299
* 6.9647057412840034 ) + t302 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - t298 ; t299
= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 / ( t303 ==
0.0 ? 1.0E-16 : t303 ) ; if ( X [ 291ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = X [ 291ULL ]
>= 623.15 ? 623.15 : X [ 291ULL ] ; } t303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; t301 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 * -
0.22145652610641059 ) + t303 * 0.0003721298010901061 ) * ( ( 1.0 -
intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
1.2002114337050787 ) + t303 * - 0.00038614513167845434 ) * intrm_sf_mf_543 )
+ ( ( 12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
6.9647057412840034 ) + t303 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ;
intrm_sf_mf_836 = t301 - t298 ; intrm_sf_mf_543 = t301 / ( intrm_sf_mf_836 ==
0.0 ? 1.0E-16 : intrm_sf_mf_836 ) ; if ( X [ 280ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
280ULL ] >= 1.0 ? 1.0 : X [ 280ULL ] ; } if ( X [ 279ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = X [ 279ULL
] >= 1.0 ? 1.0 : X [ 279ULL ] ; } t301 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
4124.48151675695 ; if ( X [ 318ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
318ULL ] >= 1.0 ? 1.0 : X [ 318ULL ] ; } if ( X [ 319ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = X [ 319ULL
] >= 1.0 ? 1.0 : X [ 319ULL ] ; } t302 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
259.836612622973 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( X [ 322ULL
] * 0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X
[ 41ULL ] <= 0.0 ) { t303 = 0.0 ; } else { t303 = X [ 41ULL ] >= 1.0 ? 1.0 :
X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) { intrm_sf_mf_836 = 0.0 ; } else {
intrm_sf_mf_836 = X [ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; } intrm_sf_mf_694
= ( ( ( 1.0 - t303 ) - intrm_sf_mf_836 ) * 296.802103844292 + t303 * 461.523
) + intrm_sf_mf_836 * 259.836612622973 ; if ( X [ 326ULL ] <=
216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 = X [ 326ULL
] >= 623.15 ? 623.15 : X [ 326ULL ] ; } t247 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 * -
0.22145652610641059 ) + t247 * 0.0003721298010901061 ) * ( ( 1.0 - t303 ) -
intrm_sf_mf_836 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
1.2002114337050787 ) + t247 * - 0.00038614513167845434 ) * t303 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 * -
0.044484923911441127 ) + t247 * 0.00036936011832051582 ) * intrm_sf_mf_836 ;
t305 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 -
intrm_sf_mf_694 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 / ( t305 ==
0.0 ? 1.0E-16 : t305 ) ; if ( X [ 330ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 330ULL ]
>= 623.15 ? 623.15 : X [ 330ULL ] ; } t305 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; t247 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * -
0.22145652610641059 ) + t305 * 0.0003721298010901061 ) * ( ( 1.0 - t303 ) -
intrm_sf_mf_836 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
1.2002114337050787 ) + t305 * - 0.00038614513167845434 ) * t303 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * -
0.044484923911441127 ) + t305 * 0.00036936011832051582 ) * intrm_sf_mf_836 ;
t306 = t247 - intrm_sf_mf_694 ; t303 = t247 / ( t306 == 0.0 ? 1.0E-16 : t306
) ; if ( X [ 305ULL ] <= 0.0 ) { intrm_sf_mf_836 = 0.0 ; } else {
intrm_sf_mf_836 = X [ 305ULL ] >= 1.0 ? 1.0 : X [ 305ULL ] ; } if ( X [
304ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 304ULL
] >= 1.0 ? 1.0 : X [ 304ULL ] ; } t247 = ( ( ( 1.0 - intrm_sf_mf_836 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) *
296.802103844292 + intrm_sf_mf_836 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
259.836612622973 ; if ( X [ 324ULL ] <= 0.0 ) { intrm_sf_mf_836 = 0.0 ; }
else { intrm_sf_mf_836 = X [ 324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X
[ 323ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 323ULL
] >= 1.0 ? 1.0 : X [ 323ULL ] ; } t305 = ( ( ( 1.0 - intrm_sf_mf_836 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) *
296.802103844292 + intrm_sf_mf_836 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
259.836612622973 ; if ( X [ 322ULL ] * 0.0019634954084936209 <=
1.9634954084936209E-11 ) { intrm_sf_mf_836 = 1.9634954084936209E-11 ; } else
if ( X [ 322ULL ] * 0.0019634954084936209 >= 0.0012566370614359179 ) {
intrm_sf_mf_836 = 0.0012566370614359179 ; } else { intrm_sf_mf_836 = X [
322ULL ] * 0.0019634954084936209 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
intrm_sf_mf_836 / 0.0019634954084936209 ; if ( X [ 345ULL ] <= 0.0 ) {
intrm_sf_mf_836 = 0.0 ; } else { intrm_sf_mf_836 = X [ 345ULL ] >= 1.0 ? 1.0
: X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0 ) { t306 = 0.0 ; } else { t306 =
X [ 346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ; } intrm_sf_mf_838 = ( ( ( 1.0 -
intrm_sf_mf_836 ) - t306 ) * 296.802103844292 + intrm_sf_mf_836 * 461.523 ) +
t306 * 259.836612622973 ; t308 = X [ 343ULL ] * intrm_sf_mf_838 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 344ULL ]
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; t310 =
X [ 344ULL ] / 1.01325 * ( X [ 348ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X
[ 343ULL ] ) ) ; t315 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 + 1.01325 ) /
2.0 * 0.0010000000000000009 ; t313 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) ;
intrm_sf_mf_904 = t315 * t313 ; intrm_sf_mf_934 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t310 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * 2.0 ;
intrm_sf_mf_1006 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( intrm_sf_mf_934 >= t313 ? intrm_sf_mf_934 : t313 ) ; intrm_sf_mf_934 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t315 == 0.0 ? 1.0E-16 : t315 ) ; t316 = intrm_sf_mf_934 * intrm_sf_mf_934 *
3.0 - intrm_sf_mf_934 * intrm_sf_mf_934 * intrm_sf_mf_934 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { intrm_sf_mf_934 = intrm_sf_mf_904 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t315 ) { intrm_sf_mf_934 = intrm_sf_mf_1006 ; } else { intrm_sf_mf_934 = (
1.0 - t316 ) * intrm_sf_mf_904 + intrm_sf_mf_1006 * t316 ; } intrm_sf_mf_1006
= ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 + 1.0 ) *
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t310
) - ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) * (
intrm_sf_mf_1006 >= t313 ? intrm_sf_mf_1006 : t313 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / ( t315 ==
0.0 ? 1.0E-16 : t315 ) ; t310 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 2.0 ; if (
1.01325 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <=
0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
intrm_sf_mf_904 ; } else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t315 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = ( 1.0 - t310
) * intrm_sf_mf_904 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t310 ; } if
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 )
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
intrm_sf_mf_934 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 :
intrm_sf_mf_904 ; } if ( X [ 343ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 343ULL ]
>= 623.15 ? 623.15 : X [ 343ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t310 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_836 ) - t306 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.00038614513167845434 ) * intrm_sf_mf_836 ) + ( ( 900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * -
0.044484923911441127 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.00036936011832051582 ) * t306 ; intrm_sf_mf_1144 = t310 - intrm_sf_mf_838 ;
intrm_sf_mf_836 = t310 / ( intrm_sf_mf_1144 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1144 ) ; if ( X [ 45ULL ] <= 0.0 ) { t306 = 0.0 ; } else { t306 =
X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; } if ( X [ 44ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 44ULL
] >= 1.0 ? 1.0 : X [ 44ULL ] ; } t310 = ( ( ( 1.0 - t306 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) *
296.802103844292 + t306 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
259.836612622973 ; if ( X [ 369ULL ] <= 216.59999999999997 ) { t313 =
216.59999999999997 ; } else { t313 = X [ 369ULL ] >= 623.15 ? 623.15 : X [
369ULL ] ; } intrm_sf_mf_1144 = t313 * t313 ; t315 = ( ( ( 1074.1165326382554
+ t313 * - 0.22145652610641059 ) + intrm_sf_mf_1144 * 0.0003721298010901061 )
* ( ( 1.0 - t306 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
1479.6504774710402 + t313 * 1.2002114337050787 ) + intrm_sf_mf_1144 * -
0.00038614513167845434 ) * t306 ) + ( ( 900.639412248396 + t313 * -
0.044484923911441127 ) + intrm_sf_mf_1144 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t319 = t315
- t310 ; t313 = t315 / ( t319 == 0.0 ? 1.0E-16 : t319 ) ; if ( X [ 372ULL ]
<= 216.59999999999997 ) { t315 = 216.59999999999997 ; } else { t315 = X [
372ULL ] >= 623.15 ? 623.15 : X [ 372ULL ] ; } t319 = t315 * t315 ;
intrm_sf_mf_904 = ( ( ( 1074.1165326382554 + t315 * - 0.22145652610641059 ) +
t319 * 0.0003721298010901061 ) * ( ( 1.0 - t306 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
1479.6504774710402 + t315 * 1.2002114337050787 ) + t319 * -
0.00038614513167845434 ) * t306 ) + ( ( 900.639412248396 + t315 * -
0.044484923911441127 ) + t319 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t320 =
intrm_sf_mf_904 - t310 ; t306 = intrm_sf_mf_904 / ( t320 == 0.0 ? 1.0E-16 :
t320 ) ; if ( X [ 367ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 367ULL
] >= 1.0 ? 1.0 : X [ 367ULL ] ; } if ( X [ 366ULL ] <= 0.0 ) { t315 = 0.0 ; }
else { t315 = X [ 366ULL ] >= 1.0 ? 1.0 : X [ 366ULL ] ; } intrm_sf_mf_904 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 )
- t315 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
t315 * 259.836612622973 ; if ( X [ 353ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 353ULL
] >= 1.0 ? 1.0 : X [ 353ULL ] ; } if ( X [ 352ULL ] <= 0.0 ) { t315 = 0.0 ; }
else { t315 = X [ 352ULL ] >= 1.0 ? 1.0 : X [ 352ULL ] ; } intrm_sf_mf_934 =
( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 )
- t315 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
t315 * 259.836612622973 ; if ( X [ 48ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 48ULL
] >= 1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { t315 = 0.0 ; }
else { t315 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ; } intrm_sf_mf_1006 = (
( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
t315 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
t315 * 259.836612622973 ; if ( X [ 387ULL ] <= 216.59999999999997 ) { t316 =
216.59999999999997 ; } else { t316 = X [ 387ULL ] >= 623.15 ? 623.15 : X [
387ULL ] ; } t320 = t316 * t316 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = ( ( (
1074.1165326382554 + t316 * - 0.22145652610641059 ) + t320 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) - t315 ) + (
( 1479.6504774710402 + t316 * 1.2002114337050787 ) + t320 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
900.639412248396 + t316 * - 0.044484923911441127 ) + t320 *
0.00036936011832051582 ) * t315 ; t321 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 -
intrm_sf_mf_1006 ; t316 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( t321 ==
0.0 ? 1.0E-16 : t321 ) ; if ( X [ 389ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [ 389ULL
] >= 623.15 ? 623.15 : X [ 389ULL ] ; } t321 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ;
intrm_sf_mf_1144 = ( ( ( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.22145652610641059 ) + t321 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) - t315 ) + (
( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
1.2002114337050787 ) + t321 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.044484923911441127 ) + t321 * 0.00036936011832051582 ) * t315 ; t268 =
intrm_sf_mf_1144 - intrm_sf_mf_1006 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
intrm_sf_mf_1144 / ( t268 == 0.0 ? 1.0E-16 : t268 ) ; if ( X [ 53ULL ] <= 0.0
) { t315 = 0.0 ; } else { t315 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; }
if ( X [ 52ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } intrm_sf_mf_1144 = ( ( ( 1.0 - t315 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + t315 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
259.836612622973 ; if ( X [ 414ULL ] <= 216.59999999999997 ) { t319 =
216.59999999999997 ; } else { t319 = X [ 414ULL ] >= 623.15 ? 623.15 : X [
414ULL ] ; } t268 = t319 * t319 ; t320 = ( ( ( 1074.1165326382554 + t319 * -
0.22145652610641059 ) + t268 * 0.0003721298010901061 ) * ( ( 1.0 - t315 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t319 * 1.2002114337050787 ) + t268 * -
0.00038614513167845434 ) * t315 ) + ( ( 900.639412248396 + t319 * -
0.044484923911441127 ) + t268 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t323 = t320
- intrm_sf_mf_1144 ; t319 = t320 / ( t323 == 0.0 ? 1.0E-16 : t323 ) ; if ( X
[ 416ULL ] <= 216.59999999999997 ) { t320 = 216.59999999999997 ; } else {
t320 = X [ 416ULL ] >= 623.15 ? 623.15 : X [ 416ULL ] ; } t323 = t320 * t320
; t321 = ( ( ( 1074.1165326382554 + t320 * - 0.22145652610641059 ) + t323 *
0.0003721298010901061 ) * ( ( 1.0 - t315 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t320 * 1.2002114337050787 ) + t323 * -
0.00038614513167845434 ) * t315 ) + ( ( 900.639412248396 + t320 * -
0.044484923911441127 ) + t323 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t324 = t321
- intrm_sf_mf_1144 ; t315 = t321 / ( t324 == 0.0 ? 1.0E-16 : t324 ) ; if ( X
[ 405ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
405ULL ] >= 1.0 ? 1.0 : X [ 405ULL ] ; } if ( X [ 404ULL ] <= 0.0 ) { t320 =
0.0 ; } else { t320 = X [ 404ULL ] >= 1.0 ? 1.0 : X [ 404ULL ] ; } t321 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
t320 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
t320 * 259.836612622973 ; if ( X [ 66ULL ] <= 0.0 ) { t320 = 0.0 ; } else {
t320 = X [ 66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ] ; } if ( X [ 65ULL ] <= 0.0 ) {
t268 = 0.0 ; } else { t268 = X [ 65ULL ] >= 1.0 ? 1.0 : X [ 65ULL ] ; } t323
= ( ( ( 1.0 - t320 ) - t268 ) * 296.802103844292 + t320 * 461.523 ) + t268 *
4124.48151675695 ; t320 = ( X [ 485ULL ] * - 0.62500003906250234 + U_idx_11 *
10.0 ) + 6.2500003783494407E-9 ; if ( X [ 69ULL ] <= 0.0 ) { t268 = 0.0 ; }
else { t268 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <=
0.0 ) { t324 = 0.0 ; } else { t324 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ;
} intrm_sf_mf_1399 = ( ( ( 1.0 - t268 ) - t324 ) * 296.802103844292 + t268 *
461.523 ) + t324 * 4124.48151675695 ; if ( X [ 488ULL ] <= 216.59999999999997
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 = X [ 488ULL
] >= 623.15 ? 623.15 : X [ 488ULL ] ; } t274 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 * -
0.22145652610641059 ) + t274 * 0.0003721298010901061 ) * ( ( 1.0 - t268 ) -
t324 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
1.2002114337050787 ) + t274 * - 0.00038614513167845434 ) * t268 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
6.9647057412840034 ) + t274 * - 0.0070524868246844051 ) * t324 ; t325 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 -
intrm_sf_mf_1399 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 / ( t325 ==
0.0 ? 1.0E-16 : t325 ) ; if ( X [ 493ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [ 493ULL
] >= 623.15 ? 623.15 : X [ 493ULL ] ; } t325 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ; t274 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * -
0.22145652610641059 ) + t325 * 0.0003721298010901061 ) * ( ( 1.0 - t268 ) -
t324 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
1.2002114337050787 ) + t325 * - 0.00038614513167845434 ) * t268 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
6.9647057412840034 ) + t325 * - 0.0070524868246844051 ) * t324 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = t274 -
intrm_sf_mf_1399 ; t268 = t274 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) ;
if ( X [ 487ULL ] <= 0.0 ) { t324 = 0.0 ; } else { t324 = X [ 487ULL ] >= 1.0
? 1.0 : X [ 487ULL ] ; } if ( X [ 486ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [
486ULL ] >= 1.0 ? 1.0 : X [ 486ULL ] ; } t274 = ( ( ( 1.0 - t324 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) *
296.802103844292 + t324 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
4124.48151675695 ; if ( X [ 468ULL ] <= 0.0 ) { t324 = 0.0 ; } else { t324 =
X [ 468ULL ] >= 1.0 ? 1.0 : X [ 468ULL ] ; } if ( X [ 467ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [
467ULL ] >= 1.0 ? 1.0 : X [ 467ULL ] ; } t325 = ( ( ( 1.0 - t324 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) *
296.802103844292 + t324 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
4124.48151675695 ; if ( X [ 485ULL ] * 7.8539816339744827E-5 <=
7.8539816339744857E-13 ) { t324 = 7.8539816339744857E-13 ; } else if ( X [
485ULL ] * 7.8539816339744827E-5 >= 1.2566370614359172E-5 ) { t324 =
1.2566370614359172E-5 ; } else { t324 = X [ 485ULL ] * 7.8539816339744827E-5
; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = t324 /
7.8539816339744827E-5 ; if ( X [ 508ULL ] <= 0.0 ) { t324 = 0.0 ; } else {
t324 = X [ 508ULL ] >= 1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL ] <= 0.0
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } intrm_sf_mf_1543 = ( ( ( 1.0 - t324
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + t324 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
4124.48151675695 ; t328 = X [ 506ULL ] * intrm_sf_mf_1543 ; intrm_sf_mf_1670
= X [ 507ULL ] / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) * ( X [
510ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; t331 = X [
507ULL ] / ( t320 == 0.0 ? 1.0E-16 : t320 ) * ( X [ 511ULL ] / ( X [ 506ULL ]
== 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; t336 = ( X [ 64ULL ] + t320 ) / 2.0 *
0.0010000000000000009 ; intrm_sf_mf_1739 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) ;
intrm_sf_mf_1634 = t336 * intrm_sf_mf_1739 ; intrm_sf_mf_1659 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1670 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * t331 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * 2.0 ;
intrm_sf_mf_1696 = ( X [ 64ULL ] - t320 ) * ( intrm_sf_mf_1659 >=
intrm_sf_mf_1739 ? intrm_sf_mf_1659 : intrm_sf_mf_1739 ) ; intrm_sf_mf_1659 =
( X [ 64ULL ] - t320 ) / ( t336 == 0.0 ? 1.0E-16 : t336 ) ; intrm_sf_mf_1387
= intrm_sf_mf_1659 * intrm_sf_mf_1659 * 3.0 - intrm_sf_mf_1659 *
intrm_sf_mf_1659 * intrm_sf_mf_1659 * 2.0 ; if ( X [ 64ULL ] - t320 <= 0.0 )
{ intrm_sf_mf_1659 = intrm_sf_mf_1634 ; } else if ( X [ 64ULL ] - t320 >=
t336 ) { intrm_sf_mf_1659 = intrm_sf_mf_1696 ; } else { intrm_sf_mf_1659 = (
1.0 - intrm_sf_mf_1387 ) * intrm_sf_mf_1634 + intrm_sf_mf_1696 *
intrm_sf_mf_1387 ; } intrm_sf_mf_1696 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * t331
) - ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1670 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = ( t320 - X
[ 64ULL ] ) * ( intrm_sf_mf_1696 >= intrm_sf_mf_1739 ? intrm_sf_mf_1696 :
intrm_sf_mf_1739 ) ; intrm_sf_mf_1670 = ( t320 - X [ 64ULL ] ) / ( t336 ==
0.0 ? 1.0E-16 : t336 ) ; t331 = intrm_sf_mf_1670 * intrm_sf_mf_1670 * 3.0 -
intrm_sf_mf_1670 * intrm_sf_mf_1670 * intrm_sf_mf_1670 * 2.0 ; if ( t320 - X
[ 64ULL ] <= 0.0 ) { intrm_sf_mf_1670 = intrm_sf_mf_1634 ; } else if ( t320 -
X [ 64ULL ] >= t336 ) { intrm_sf_mf_1670 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ; } else {
intrm_sf_mf_1670 = ( 1.0 - t331 ) * intrm_sf_mf_1634 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * t331 ; } if
( X [ 64ULL ] > t320 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 =
intrm_sf_mf_1659 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [ 64ULL ]
< t320 ? intrm_sf_mf_1670 : intrm_sf_mf_1634 ; } if ( X [ 506ULL ] <=
216.59999999999997 ) { intrm_sf_mf_1670 = 216.59999999999997 ; } else {
intrm_sf_mf_1670 = X [ 506ULL ] >= 623.15 ? 623.15 : X [ 506ULL ] ; } t338 =
intrm_sf_mf_1670 * intrm_sf_mf_1670 ; t331 = ( ( ( 1074.1165326382554 +
intrm_sf_mf_1670 * - 0.22145652610641059 ) + t338 * 0.0003721298010901061 ) *
( ( 1.0 - t324 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + intrm_sf_mf_1670 * 1.2002114337050787 ) + t338 * -
0.00038614513167845434 ) * t324 ) + ( ( 12825.281119789837 + intrm_sf_mf_1670
* 6.9647057412840034 ) + t338 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t339 = t331
- intrm_sf_mf_1543 ; t324 = t331 / ( t339 == 0.0 ? 1.0E-16 : t339 ) ; if ( X
[ 524ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
524ULL ] >= 1.0 ? 1.0 : X [ 524ULL ] ; } if ( X [ 525ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 525ULL ] >= 1.0 ?
1.0 : X [ 525ULL ] ; } t331 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
intrm_sf_mf_1670 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
intrm_sf_mf_1670 * 259.836612622973 ; if ( X [ 537ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 537ULL ] >= 1.0 ?
1.0 : X [ 537ULL ] ; } if ( X [ 536ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ;
} else { intrm_sf_mf_1739 = X [ 536ULL ] >= 1.0 ? 1.0 : X [ 536ULL ] ; } t336
= ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 +
intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 * 259.836612622973 ; if ( X [
73ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [
73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ] ; } if ( X [ 72ULL ] <= 0.0 ) {
intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X [ 72ULL ] >= 1.0 ? 1.0
: X [ 72ULL ] ; } intrm_sf_mf_1634 = ( ( ( 1.0 - intrm_sf_mf_1670 ) -
intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670 * 461.523 ) +
intrm_sf_mf_1739 * 259.836612622973 ; if ( X [ 76ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 76ULL ] >= 1.0 ? 1.0
: X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; } else
{ intrm_sf_mf_1739 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; }
intrm_sf_mf_1659 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) *
296.802103844292 + intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 *
4124.48151675695 ; if ( X [ 576ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; }
else { intrm_sf_mf_1670 = X [ 576ULL ] >= 1.0 ? 1.0 : X [ 576ULL ] ; } if ( X
[ 575ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X
[ 575ULL ] >= 1.0 ? 1.0 : X [ 575ULL ] ; } intrm_sf_mf_1696 = ( ( ( 1.0 -
intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670
* 461.523 ) + intrm_sf_mf_1739 * 4124.48151675695 ; if ( X [ 471ULL ] <= 0.0
) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 471ULL ] >= 1.0
? 1.0 : X [ 471ULL ] ; } if ( X [ 470ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0
; } else { intrm_sf_mf_1739 = X [ 470ULL ] >= 1.0 ? 1.0 : X [ 470ULL ] ; }
intrm_sf_mf_1387 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) *
296.802103844292 + intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 *
4124.48151675695 ; if ( X [ 515ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; }
else { intrm_sf_mf_1670 = X [ 515ULL ] >= 1.0 ? 1.0 : X [ 515ULL ] ; } if ( X
[ 514ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X
[ 514ULL ] >= 1.0 ? 1.0 : X [ 514ULL ] ; } t338 = ( ( ( 1.0 -
intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670
* 461.523 ) + intrm_sf_mf_1739 * 259.836612622973 ; if ( X [ 529ULL ] <= 0.0
) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 529ULL ] >= 1.0
? 1.0 : X [ 529ULL ] ; } if ( X [ 528ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0
; } else { intrm_sf_mf_1739 = X [ 528ULL ] >= 1.0 ? 1.0 : X [ 528ULL ] ; }
t339 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292
+ intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 * 259.836612622973 ; if ( X
[ 555ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X
[ 555ULL ] >= 1.0 ? 1.0 : X [ 555ULL ] ; } if ( X [ 554ULL ] <= 0.0 ) {
intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X [ 554ULL ] >= 1.0 ?
1.0 : X [ 554ULL ] ; } intrm_sf_mf_1672 = ( ( ( 1.0 - intrm_sf_mf_1670 ) -
intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670 * 461.523 ) +
intrm_sf_mf_1739 * 4124.48151675695 ; t180 [ 0ULL ] = X [ 92ULL ] ;
tlu2_linear_linear_prelookup ( & cb_efOut . mField0 [ 0ULL ] , & cb_efOut .
mField1 [ 0ULL ] , & cb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t1
= cb_efOut ; t180 [ 0ULL ] = X [ 93ULL ] ; tlu2_linear_linear_prelookup ( &
db_efOut . mField0 [ 0ULL ] , & db_efOut . mField1 [ 0ULL ] , & db_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25 = db_efOut ;
tlu2_2d_linear_linear_value ( & eb_efOut [ 0ULL ] , & t1 . mField0 [ 0ULL ] ,
& t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = eb_efOut [ 0 ] ; intrm_sf_mf_1670 =
t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 94ULL ] ; tlu2_linear_linear_prelookup (
& fb_efOut . mField0 [ 0ULL ] , & fb_efOut . mField1 [ 0ULL ] , & fb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [
0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25 = fb_efOut ;
tlu2_2d_linear_linear_value ( & gb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t24 . mField0 [ 0ULL ] , & t24 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , &
t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = gb_efOut [ 0 ] ;
intrm_sf_mf_1739 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 101ULL ] ;
tlu2_linear_linear_prelookup ( & hb_efOut . mField0 [ 0ULL ] , & hb_efOut .
mField1 [ 0ULL ] , & hb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t1
= hb_efOut ; tlu2_2d_linear_linear_value ( & ib_efOut [ 0ULL ] , & t1 .
mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t27 . mField0 [ 0ULL ] , & t27
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = ib_efOut [ 0 ] ;
intrm_sf_mf_1740 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 103ULL ] ;
tlu2_linear_linear_prelookup ( & jb_efOut . mField0 [ 0ULL ] , & jb_efOut .
mField1 [ 0ULL ] , & jb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t27
= jb_efOut ; tlu2_2d_linear_linear_value ( & kb_efOut [ 0ULL ] , & t27 .
mField0 [ 0ULL ] , & t27 . mField2 [ 0ULL ] , & t8 . mField0 [ 0ULL ] , & t8
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = kb_efOut [ 0 ] ;
intrm_sf_mf_1741 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_linear_prelookup ( & lb_efOut . mField0 [ 0ULL ] , & lb_efOut .
mField1 [ 0ULL ] , & lb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t27
= lb_efOut ; tlu2_2d_linear_linear_value ( & mb_efOut [ 0ULL ] , & t27 .
mField0 [ 0ULL ] , & t27 . mField2 [ 0ULL ] , & t22 . mField0 [ 0ULL ] , &
t22 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t37 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = mb_efOut [ 0
] ; intrm_sf_mf_1742 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 112ULL ] ;
tlu2_linear_linear_prelookup ( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut .
mField1 [ 0ULL ] , & nb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= nb_efOut ; tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t21 . mField0 [ 0ULL ] , &
t21 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t37 [ 0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = ob_efOut [ 0
] ; intrm_sf_mf_1743 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 137ULL ] ;
tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t22
= pb_efOut ; t180 [ 0ULL ] = X [ 138ULL ] ; tlu2_linear_linear_prelookup ( &
qb_efOut . mField0 [ 0ULL ] , & qb_efOut . mField1 [ 0ULL ] , & qb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t1 = qb_efOut ;
tlu2_2d_linear_linear_value ( & rb_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ]
, & t22 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = rb_efOut [ 0 ] ; intrm_sf_mf_1744 =
t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 156ULL ] ; tlu2_linear_linear_prelookup (
& sb_efOut . mField0 [ 0ULL ] , & sb_efOut . mField1 [ 0ULL ] , & sb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [
0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t22 = sb_efOut ;
tlu2_2d_linear_linear_value ( & tb_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ]
, & t22 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = tb_efOut [ 0 ] ; intrm_sf_mf_1772 =
t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 157ULL ] ; tlu2_linear_linear_prelookup (
& ub_efOut . mField0 [ 0ULL ] , & ub_efOut . mField1 [ 0ULL ] , & ub_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t180 [
0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25 = ub_efOut ;
tlu2_2d_linear_linear_value ( & vb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t28 . mField0 [ 0ULL ] , & t28 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , &
t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t207 [ 0 ] = vb_efOut [ 0 ] ;
intrm_sf_mf_1773 = t207 [ 0ULL ] ; t180 [ 0ULL ] = X [ 8ULL ] ;
tlu2_linear_linear_prelookup ( & wb_efOut . mField0 [ 0ULL ] , & wb_efOut .
mField1 [ 0ULL ] , & wb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t180 [ 0ULL ] , & t37 [ 0ULL ] , & t38 [ 0ULL ] ) ; t25
= wb_efOut ; t180 [ 0ULL ] = X [ 15ULL ] ; tlu2_linear_linear_prelookup ( &
xb_efOut . mField0 [ 0ULL ] , & xb_efOut . mField1 [ 0ULL ] , & xb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t180 [
0ULL ] , & t40 [ 0ULL ] , & t38 [ 0ULL ] ) ; t1 = xb_efOut ;
tlu2_2d_linear_linear_value ( & yb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t37 [ 0ULL ] , & t40 [
0ULL ] , & t38 [ 0ULL ] ) ; t180 [ 0 ] = yb_efOut [ 0 ] ; intrm_sf_mf_1774 =
t180 [ 0ULL ] ; if ( U_idx_13 >= 1.0 ) { intrm_sf_mf_1799 = 1.0 ; } else {
intrm_sf_mf_1799 = U_idx_13 <= 0.0 ? 0.0 : U_idx_13 ; } if ( X [ 182ULL ] <=
0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0
; } else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
X [ 182ULL ] >= 1.0 ? 1.0 : X [ 182ULL ] ; } if ( X [ 181ULL ] <= 0.0 ) {
intrm_sf_mf_684 = 0.0 ; } else { intrm_sf_mf_684 = X [ 181ULL ] >= 1.0 ? 1.0
: X [ 181ULL ] ; } intrm_sf_mf_252 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
intrm_sf_mf_684 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
intrm_sf_mf_684 * 4124.48151675695 ; if ( X [ 309ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
309ULL ] >= 1.0 ? 1.0 : X [ 309ULL ] ; } if ( X [ 308ULL ] <= 0.0 ) {
intrm_sf_mf_684 = 0.0 ; } else { intrm_sf_mf_684 = X [ 308ULL ] >= 1.0 ? 1.0
: X [ 308ULL ] ; } intrm_sf_mf_685 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
intrm_sf_mf_684 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
intrm_sf_mf_684 * 259.836612622973 ; if ( M [ 45ULL ] == 0 ) {
intrm_sf_mf_684 = - X [ 580ULL ] - X [ 78ULL ] ; } else { intrm_sf_mf_684 =
0.0 ; } if ( M [ 310ULL ] == 0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = U_idx_6 -
623.15 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; } if
( M [ 355ULL ] == 0 ) { U_idx_3 = U_idx_9 - 623.15 ; } else { U_idx_3 = 0.0 ;
} if ( M [ 6ULL ] == 0 ) { U_idx_7 = X [ 32ULL ] - 623.15 ; } else { U_idx_7
= 0.0 ; } t180 [ 0ULL ] = pmf_get_inf ( ) ; for ( t210 = 0ULL ; t210 < 42ULL
; t210 ++ ) { t211 = t210 / 42ULL ; U_idx_11 = t180 [ t211 > 0ULL ? 0ULL :
t211 ] ; U_idx_13 = ( ( _NeDynamicSystem * ) ( LC ) ) -> mField0 [ t210 ] *
1.0E-5 ; t180 [ t211 > 0ULL ? 0ULL : t211 ] = U_idx_11 > U_idx_13 ? U_idx_13
: U_idx_11 ; } t207 [ 0ULL ] = pmf_get_inf ( ) ; for ( t210 = 0ULL ; t210 <
7ULL ; t210 ++ ) { t211 = t210 / 7ULL ; U_idx_11 = t207 [ t211 > 0ULL ? 0ULL
: t211 ] ; U_idx_13 = nonscalar1 [ t210 ] * 1.0E-5 ; t207 [ t211 > 0ULL ?
0ULL : t211 ] = U_idx_11 > U_idx_13 ? U_idx_13 : U_idx_11 ; } t186 [ 0ULL ] =
t180 [ 0ULL ] - X [ 80ULL ] ; t186 [ 1ULL ] = 4.03416E-7 - X [ 84ULL ] * X [
86ULL ] ; t186 [ 2ULL ] = t207 [ 0ULL ] - X [ 85ULL ] * X [ 87ULL ] ; t186 [
3ULL ] = X [ 86ULL ] ; t186 [ 4ULL ] = X [ 85ULL ] ; t186 [ 5ULL ] = X [
84ULL ] ; t186 [ 6ULL ] = X [ 80ULL ] ; t186 [ 7ULL ] = X [ 87ULL ] ; t186 [
8ULL ] = X [ 81ULL ] - 0.9 ; t186 [ 9ULL ] = intrm_sf_mf_1670 ; t186 [ 10ULL
] = X [ 93ULL ] - 0.1 ; t186 [ 11ULL ] = 500.0 - X [ 93ULL ] ; t186 [ 12ULL ]
= X [ 92ULL ] - 268.4357 ; t186 [ 13ULL ] = 393.15 - X [ 92ULL ] ; t186 [
14ULL ] = intrm_sf_mf_1739 ; t186 [ 15ULL ] = X [ 95ULL ] - 0.1 ; t186 [
16ULL ] = 500.0 - X [ 95ULL ] ; t186 [ 17ULL ] = X [ 94ULL ] - 268.4357 ;
t186 [ 18ULL ] = 393.15 - X [ 94ULL ] ; t186 [ 19ULL ] = intrm_sf_mf_1740 ;
t186 [ 20ULL ] = X [ 102ULL ] - 0.1 ; t186 [ 21ULL ] = 500.0 - X [ 102ULL ] ;
t186 [ 22ULL ] = X [ 101ULL ] - 268.4357 ; t186 [ 23ULL ] = 393.15 - X [
101ULL ] ; t186 [ 24ULL ] = intrm_sf_mf_1741 ; t186 [ 25ULL ] = X [ 104ULL ]
- 0.1 ; t186 [ 26ULL ] = 500.0 - X [ 104ULL ] ; t186 [ 27ULL ] = X [ 103ULL ]
- 268.4357 ; t186 [ 28ULL ] = 393.15 - X [ 103ULL ] ; t186 [ 29ULL ] =
intrm_sf_mf_1742 ; t186 [ 30ULL ] = X [ 111ULL ] - 0.1 ; t186 [ 31ULL ] =
500.0 - X [ 111ULL ] ; t186 [ 32ULL ] = X [ 110ULL ] - 268.4357 ; t186 [
33ULL ] = 393.15 - X [ 110ULL ] ; t186 [ 34ULL ] = intrm_sf_mf_1743 ; t186 [
35ULL ] = X [ 113ULL ] - 0.1 ; t186 [ 36ULL ] = 500.0 - X [ 113ULL ] ; t186 [
37ULL ] = X [ 112ULL ] - 268.4357 ; t186 [ 38ULL ] = 393.15 - X [ 112ULL ] ;
t186 [ 39ULL ] = t482 ; t186 [ 40ULL ] = t480 - 0.1 ; t186 [ 41ULL ] = 500.0
- t480 ; t186 [ 42ULL ] = X [ 6ULL ] - 268.4357 ; t186 [ 43ULL ] = 393.15 - X
[ 6ULL ] ; t186 [ 44ULL ] = t485 ; t186 [ 45ULL ] = t504 ; t186 [ 46ULL ] = X
[ 120ULL ] - 0.1 ; t186 [ 47ULL ] = 500.0 - X [ 120ULL ] ; t186 [ 48ULL ] = X
[ 119ULL ] - 268.4357 ; t186 [ 49ULL ] = 393.15 - X [ 119ULL ] ; t186 [ 50ULL
] = t523 ; t186 [ 51ULL ] = t499 - 0.1 ; t186 [ 52ULL ] = 500.0 - t499 ; t186
[ 53ULL ] = X [ 9ULL ] - 268.4357 ; t186 [ 54ULL ] = 393.15 - X [ 9ULL ] ;
t186 [ 55ULL ] = t524 ; t186 [ 56ULL ] = t511 ; t186 [ 57ULL ] = t283 ; t186
[ 58ULL ] = t512 - 0.1 ; t186 [ 59ULL ] = 500.0 - t512 ; t186 [ 60ULL ] = X [
11ULL ] - 268.4357 ; t186 [ 61ULL ] = 393.15 - X [ 11ULL ] ; t186 [ 62ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A ; t186 [ 63ULL
] = Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B ; t186 [
64ULL ] = intrm_sf_mf_1744 ; t186 [ 65ULL ] = X [ 138ULL ] - 0.1 ; t186 [
66ULL ] = 500.0 - X [ 138ULL ] ; t186 [ 67ULL ] = X [ 137ULL ] - 268.4357 ;
t186 [ 68ULL ] = 393.15 - X [ 137ULL ] ; t186 [ 69ULL ] = intrm_sf_mf_1670 ;
t186 [ 70ULL ] = X [ 429ULL ] - 273.16 ; t186 [ 71ULL ] = 363.16 - X [ 429ULL
] ; t186 [ 72ULL ] = X [ 451ULL ] - 0.5 ; t186 [ 73ULL ] = 500.0 - X [ 451ULL
] ; t186 [ 74ULL ] = X [ 450ULL ] - 273.16 ; t186 [ 75ULL ] = 363.16 - X [
450ULL ] ; t186 [ 76ULL ] = X [ 147ULL ] - 1.0E-5 ; t186 [ 77ULL ] =
pmf_get_inf ( ) - X [ 147ULL ] ; t186 [ 78ULL ] = X [ 146ULL ] - 1.0 ; t186 [
79ULL ] = pmf_get_inf ( ) - X [ 146ULL ] ; t186 [ 80ULL ] = X [ 149ULL ] -
1.0E-5 ; t186 [ 81ULL ] = pmf_get_inf ( ) - X [ 149ULL ] ; t186 [ 82ULL ] = X
[ 148ULL ] - 1.0 ; t186 [ 83ULL ] = pmf_get_inf ( ) - X [ 148ULL ] ; t186 [
84ULL ] = 0.001 - Electrical_Cooling_System_Tank_Tank_level * 0.005 ; t186 [
85ULL ] = Electrical_Cooling_System_Tank_Tank_level - 0.01 ; t186 [ 86ULL ] =
( ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] * - 1.0000000000000011 ) + X [
173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ) - ( X [ 171ULL ] + 0.8 ) ; t186 [ 87ULL
] = intrm_sf_mf_1799 - 1.0 > 1.0 - intrm_sf_mf_1799 ? 1.0 - intrm_sf_mf_1799
: intrm_sf_mf_1799 - 1.0 ; t186 [ 88ULL ] = ( 1.0 - X [ 191ULL ] ) - X [
192ULL ] ; t186 [ 89ULL ] = intrm_sf_mf_83 * 293.15 / 1.01325 ; t186 [ 90ULL
] = ( 1.0 - X [ 318ULL ] ) - X [ 319ULL ] ; t186 [ 91ULL ] = t302 * 293.15 /
1.01325 ; t186 [ 92ULL ] = ( 1.0 - X [ 524ULL ] ) - X [ 525ULL ] ; t186 [
93ULL ] = t331 * 293.15 / 1.01325 ; t186 [ 94ULL ] = X [ 199ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
intrm_sf_mf_95 ; t186 [ 95ULL ] = X [ 200ULL ] * X [ 200ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 / (
intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [ 199ULL ] == 0.0 ?
1.0E-16 : X [ 199ULL ] ) ; t186 [ 96ULL ] = X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ; t186 [ 97ULL ] = X [ 204ULL ] * X [ 204ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 / (
intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [ 203ULL ] == 0.0 ?
1.0E-16 : X [ 203ULL ] ) ; t186 [ 98ULL ] = X [ 199ULL ] * intrm_sf_mf_95 / (
X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ; t186 [ 99ULL ] = X [ 203ULL
] * intrm_sf_mf_95 / ( X [ 204ULL ] == 0.0 ? 1.0E-16 : X [ 204ULL ] ) ; t186
[ 100ULL ] = X [ 176ULL ] - 0.01 ; t186 [ 101ULL ] = pmf_get_inf ( ) - X [
176ULL ] ; t186 [ 102ULL ] = X [ 175ULL ] - 216.59999999999997 ; t186 [
103ULL ] = 623.15 - X [ 175ULL ] ; t186 [ 104ULL ] = X [ 195ULL ] - 0.01 ;
t186 [ 105ULL ] = pmf_get_inf ( ) - X [ 195ULL ] ; t186 [ 106ULL ] = X [
194ULL ] - 216.59999999999997 ; t186 [ 107ULL ] = 623.15 - X [ 194ULL ] ;
t186 [ 108ULL ] = X [ 22ULL ] - 0.01 ; t186 [ 109ULL ] = pmf_get_inf ( ) - X
[ 22ULL ] ; t186 [ 110ULL ] = X [ 21ULL ] - 216.59999999999997 ; t186 [
111ULL ] = 623.15 - X [ 21ULL ] ; t186 [ 112ULL ] = X [ 21ULL ] *
intrm_sf_mf_95 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) ; t186 [
113ULL ] = X [ 245ULL ] * t293 * t290 ; t186 [ 114ULL ] = X [ 246ULL ] * X [
246ULL ] * t293 / ( t290 == 0.0 ? 1.0E-16 : t290 ) / ( X [ 245ULL ] == 0.0 ?
1.0E-16 : X [ 245ULL ] ) ; t186 [ 115ULL ] = X [ 248ULL ] * t285 * t290 ;
t186 [ 116ULL ] = X [ 249ULL ] * X [ 249ULL ] * t285 / ( t290 == 0.0 ?
1.0E-16 : t290 ) / ( X [ 248ULL ] == 0.0 ? 1.0E-16 : X [ 248ULL ] ) ; t186 [
117ULL ] = X [ 245ULL ] * t290 / ( X [ 246ULL ] == 0.0 ? 1.0E-16 : X [ 246ULL
] ) ; t186 [ 118ULL ] = X [ 248ULL ] * t290 / ( X [ 249ULL ] == 0.0 ? 1.0E-16
: X [ 249ULL ] ) ; t186 [ 119ULL ] = X [ 241ULL ] - 0.01 ; t186 [ 120ULL ] =
pmf_get_inf ( ) - X [ 241ULL ] ; t186 [ 121ULL ] = X [ 240ULL ] -
216.59999999999997 ; t186 [ 122ULL ] = 623.15 - X [ 240ULL ] ; t186 [ 123ULL
] = X [ 227ULL ] - 0.01 ; t186 [ 124ULL ] = pmf_get_inf ( ) - X [ 227ULL ] ;
t186 [ 125ULL ] = X [ 226ULL ] - 216.59999999999997 ; t186 [ 126ULL ] =
623.15 - X [ 226ULL ] ; t186 [ 127ULL ] = X [ 31ULL ] - 0.01 ; t186 [ 128ULL
] = pmf_get_inf ( ) - X [ 31ULL ] ; t186 [ 129ULL ] = X [ 25ULL ] -
216.59999999999997 ; t186 [ 130ULL ] = 623.15 - X [ 25ULL ] ; t186 [ 131ULL ]
= X [ 25ULL ] * t290 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) ; t186
[ 132ULL ] = X [ 263ULL ] * t296 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; t186 [
133ULL ] = X [ 264ULL ] * X [ 264ULL ] * t296 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ) /
( X [ 263ULL ] == 0.0 ? 1.0E-16 : X [ 263ULL ] ) ; t186 [ 134ULL ] = X [
265ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; t186 [
135ULL ] = X [ 266ULL ] * X [ 266ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ) /
( X [ 265ULL ] == 0.0 ? 1.0E-16 : X [ 265ULL ] ) ; t186 [ 136ULL ] = X [
263ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / (
X [ 264ULL ] == 0.0 ? 1.0E-16 : X [ 264ULL ] ) ; t186 [ 137ULL ] = X [ 265ULL
] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / ( X [
266ULL ] == 0.0 ? 1.0E-16 : X [ 266ULL ] ) ; t186 [ 138ULL ] = X [ 33ULL ] -
0.01 ; t186 [ 139ULL ] = pmf_get_inf ( ) - X [ 33ULL ] ; t186 [ 140ULL ] = X
[ 28ULL ] - 216.59999999999997 ; t186 [ 141ULL ] = 623.15 - X [ 28ULL ] ;
t186 [ 142ULL ] = X [ 28ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / ( X [ 33ULL
] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) ; t186 [ 143ULL ] = X [ 289ULL ] * t299 *
t298 ; t186 [ 144ULL ] = X [ 290ULL ] * X [ 290ULL ] * t299 / ( t298 == 0.0 ?
1.0E-16 : t298 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16 : X [ 289ULL ] ) ; t186 [
145ULL ] = X [ 291ULL ] * intrm_sf_mf_543 * t298 ; t186 [ 146ULL ] = X [
292ULL ] * X [ 292ULL ] * intrm_sf_mf_543 / ( t298 == 0.0 ? 1.0E-16 : t298 )
/ ( X [ 291ULL ] == 0.0 ? 1.0E-16 : X [ 291ULL ] ) ; t186 [ 147ULL ] = X [
289ULL ] * t298 / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X [ 290ULL ] ) ; t186 [
148ULL ] = X [ 291ULL ] * t298 / ( X [ 292ULL ] == 0.0 ? 1.0E-16 : X [ 292ULL
] ) ; t186 [ 149ULL ] = X [ 38ULL ] - 0.01 ; t186 [ 150ULL ] = pmf_get_inf (
) - X [ 38ULL ] ; t186 [ 151ULL ] = X [ 278ULL ] - 216.59999999999997 ; t186
[ 152ULL ] = 623.15 - X [ 278ULL ] ; t186 [ 153ULL ] = X [ 37ULL ] - 0.01 ;
t186 [ 154ULL ] = pmf_get_inf ( ) - X [ 37ULL ] ; t186 [ 155ULL ] = X [ 34ULL
] - 216.59999999999997 ; t186 [ 156ULL ] = 623.15 - X [ 34ULL ] ; t186 [
157ULL ] = X [ 34ULL ] * t298 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ]
) ; t186 [ 158ULL ] = X [ 326ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
intrm_sf_mf_694 ; t186 [ 159ULL ] = X [ 327ULL ] * X [ 327ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 / (
intrm_sf_mf_694 == 0.0 ? 1.0E-16 : intrm_sf_mf_694 ) / ( X [ 326ULL ] == 0.0
? 1.0E-16 : X [ 326ULL ] ) ; t186 [ 160ULL ] = X [ 330ULL ] * t303 *
intrm_sf_mf_694 ; t186 [ 161ULL ] = X [ 331ULL ] * X [ 331ULL ] * t303 / (
intrm_sf_mf_694 == 0.0 ? 1.0E-16 : intrm_sf_mf_694 ) / ( X [ 330ULL ] == 0.0
? 1.0E-16 : X [ 330ULL ] ) ; t186 [ 162ULL ] = X [ 326ULL ] * intrm_sf_mf_694
/ ( X [ 327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) ; t186 [ 163ULL ] = X [
330ULL ] * intrm_sf_mf_694 / ( X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] )
; t186 [ 164ULL ] = X [ 303ULL ] - 0.01 ; t186 [ 165ULL ] = pmf_get_inf ( ) -
X [ 303ULL ] ; t186 [ 166ULL ] = X [ 302ULL ] - 216.59999999999997 ; t186 [
167ULL ] = 623.15 - X [ 302ULL ] ; t186 [ 168ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 0.01 ; t186
[ 169ULL ] = pmf_get_inf ( ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; t186 [
170ULL ] = X [ 321ULL ] - 216.59999999999997 ; t186 [ 171ULL ] = 623.15 - X [
321ULL ] ; t186 [ 172ULL ] = X [ 40ULL ] - 0.01 ; t186 [ 173ULL ] =
pmf_get_inf ( ) - X [ 40ULL ] ; t186 [ 174ULL ] = X [ 39ULL ] -
216.59999999999997 ; t186 [ 175ULL ] = 623.15 - X [ 39ULL ] ; t186 [ 176ULL ]
= X [ 39ULL ] * intrm_sf_mf_694 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL
] ) ; t186 [ 177ULL ] = X [ 369ULL ] * t313 * t310 ; t186 [ 178ULL ] = X [
370ULL ] * X [ 370ULL ] * t313 / ( t310 == 0.0 ? 1.0E-16 : t310 ) / ( X [
369ULL ] == 0.0 ? 1.0E-16 : X [ 369ULL ] ) ; t186 [ 179ULL ] = X [ 372ULL ] *
t306 * t310 ; t186 [ 180ULL ] = X [ 373ULL ] * X [ 373ULL ] * t306 / ( t310
== 0.0 ? 1.0E-16 : t310 ) / ( X [ 372ULL ] == 0.0 ? 1.0E-16 : X [ 372ULL ] )
; t186 [ 181ULL ] = X [ 369ULL ] * t310 / ( X [ 370ULL ] == 0.0 ? 1.0E-16 : X
[ 370ULL ] ) ; t186 [ 182ULL ] = X [ 372ULL ] * t310 / ( X [ 373ULL ] == 0.0
? 1.0E-16 : X [ 373ULL ] ) ; t186 [ 183ULL ] = X [ 365ULL ] - 0.01 ; t186 [
184ULL ] = pmf_get_inf ( ) - X [ 365ULL ] ; t186 [ 185ULL ] = X [ 364ULL ] -
216.59999999999997 ; t186 [ 186ULL ] = 623.15 - X [ 364ULL ] ; t186 [ 187ULL
] = X [ 351ULL ] - 0.01 ; t186 [ 188ULL ] = pmf_get_inf ( ) - X [ 351ULL ] ;
t186 [ 189ULL ] = X [ 350ULL ] - 216.59999999999997 ; t186 [ 190ULL ] =
623.15 - X [ 350ULL ] ; t186 [ 191ULL ] = X [ 49ULL ] - 0.01 ; t186 [ 192ULL
] = pmf_get_inf ( ) - X [ 49ULL ] ; t186 [ 193ULL ] = X [ 43ULL ] -
216.59999999999997 ; t186 [ 194ULL ] = 623.15 - X [ 43ULL ] ; t186 [ 195ULL ]
= X [ 43ULL ] * t310 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) ; t186
[ 196ULL ] = X [ 387ULL ] * t316 * intrm_sf_mf_1006 ; t186 [ 197ULL ] = X [
388ULL ] * X [ 388ULL ] * t316 / ( intrm_sf_mf_1006 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1006 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X [ 387ULL ] ) ; t186
[ 198ULL ] = X [ 389ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
intrm_sf_mf_1006 ; t186 [ 199ULL ] = X [ 390ULL ] * X [ 390ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 / (
intrm_sf_mf_1006 == 0.0 ? 1.0E-16 : intrm_sf_mf_1006 ) / ( X [ 389ULL ] ==
0.0 ? 1.0E-16 : X [ 389ULL ] ) ; t186 [ 200ULL ] = X [ 387ULL ] *
intrm_sf_mf_1006 / ( X [ 388ULL ] == 0.0 ? 1.0E-16 : X [ 388ULL ] ) ; t186 [
201ULL ] = X [ 389ULL ] * intrm_sf_mf_1006 / ( X [ 390ULL ] == 0.0 ? 1.0E-16
: X [ 390ULL ] ) ; t186 [ 202ULL ] = X [ 50ULL ] - 0.01 ; t186 [ 203ULL ] =
pmf_get_inf ( ) - X [ 50ULL ] ; t186 [ 204ULL ] = X [ 46ULL ] -
216.59999999999997 ; t186 [ 205ULL ] = 623.15 - X [ 46ULL ] ; t186 [ 206ULL ]
= X [ 46ULL ] * intrm_sf_mf_1006 / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL
] ) ; t186 [ 207ULL ] = X [ 414ULL ] * t319 * intrm_sf_mf_1144 ; t186 [
208ULL ] = X [ 415ULL ] * X [ 415ULL ] * t319 / ( intrm_sf_mf_1144 == 0.0 ?
1.0E-16 : intrm_sf_mf_1144 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [ 414ULL ]
) ; t186 [ 209ULL ] = X [ 416ULL ] * t315 * intrm_sf_mf_1144 ; t186 [ 210ULL
] = X [ 417ULL ] * X [ 417ULL ] * t315 / ( intrm_sf_mf_1144 == 0.0 ? 1.0E-16
: intrm_sf_mf_1144 ) / ( X [ 416ULL ] == 0.0 ? 1.0E-16 : X [ 416ULL ] ) ;
t186 [ 211ULL ] = X [ 414ULL ] * intrm_sf_mf_1144 / ( X [ 415ULL ] == 0.0 ?
1.0E-16 : X [ 415ULL ] ) ; t186 [ 212ULL ] = X [ 416ULL ] * intrm_sf_mf_1144
/ ( X [ 417ULL ] == 0.0 ? 1.0E-16 : X [ 417ULL ] ) ; t186 [ 213ULL ] = X [
55ULL ] - 0.01 ; t186 [ 214ULL ] = pmf_get_inf ( ) - X [ 55ULL ] ; t186 [
215ULL ] = X [ 403ULL ] - 216.59999999999997 ; t186 [ 216ULL ] = 623.15 - X [
403ULL ] ; t186 [ 217ULL ] = X [ 54ULL ] - 0.01 ; t186 [ 218ULL ] =
pmf_get_inf ( ) - X [ 54ULL ] ; t186 [ 219ULL ] = X [ 51ULL ] -
216.59999999999997 ; t186 [ 220ULL ] = 623.15 - X [ 51ULL ] ; t186 [ 221ULL ]
= X [ 51ULL ] * intrm_sf_mf_1144 / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [ 54ULL
] ) ; t186 [ 222ULL ] = X [ 488ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
intrm_sf_mf_1399 ; t186 [ 223ULL ] = X [ 489ULL ] * X [ 489ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 / (
intrm_sf_mf_1399 == 0.0 ? 1.0E-16 : intrm_sf_mf_1399 ) / ( X [ 488ULL ] ==
0.0 ? 1.0E-16 : X [ 488ULL ] ) ; t186 [ 224ULL ] = X [ 493ULL ] * t268 *
intrm_sf_mf_1399 ; t186 [ 225ULL ] = X [ 494ULL ] * X [ 494ULL ] * t268 / (
intrm_sf_mf_1399 == 0.0 ? 1.0E-16 : intrm_sf_mf_1399 ) / ( X [ 493ULL ] ==
0.0 ? 1.0E-16 : X [ 493ULL ] ) ; t186 [ 226ULL ] = X [ 488ULL ] *
intrm_sf_mf_1399 / ( X [ 489ULL ] == 0.0 ? 1.0E-16 : X [ 489ULL ] ) ; t186 [
227ULL ] = X [ 493ULL ] * intrm_sf_mf_1399 / ( X [ 494ULL ] == 0.0 ? 1.0E-16
: X [ 494ULL ] ) ; t186 [ 228ULL ] = t320 - 0.01 ; t186 [ 229ULL ] =
pmf_get_inf ( ) - t320 ; t186 [ 230ULL ] = X [ 484ULL ] - 216.59999999999997
; t186 [ 231ULL ] = 623.15 - X [ 484ULL ] ; t186 [ 232ULL ] = X [ 466ULL ] -
216.59999999999997 ; t186 [ 233ULL ] = 623.15 - X [ 466ULL ] ; t186 [ 234ULL
] = X [ 68ULL ] - 0.01 ; t186 [ 235ULL ] = pmf_get_inf ( ) - X [ 68ULL ] ;
t186 [ 236ULL ] = X [ 67ULL ] - 216.59999999999997 ; t186 [ 237ULL ] = 623.15
- X [ 67ULL ] ; t186 [ 238ULL ] = X [ 67ULL ] * intrm_sf_mf_1399 / ( X [
68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) ; t186 [ 239ULL ] = X [ 220ULL ] * X
[ 220ULL ] * intrm_sf_mf_237 / ( intrm_sf_mf_239 == 0.0 ? 1.0E-16 :
intrm_sf_mf_239 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ; t186 [
240ULL ] = X [ 220ULL ] / ( t287 == 0.0 ? 1.0E-16 : t287 ) * 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) ;
t186 [ 241ULL ] = X [ 223ULL ] * intrm_sf_mf_239 / ( X [ 195ULL ] == 0.0 ?
1.0E-16 : X [ 195ULL ] ) ; t186 [ 242ULL ] = X [ 224ULL ] * intrm_sf_mf_239 /
1.01325 ; t186 [ 243ULL ] = t287 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 : X [
220ULL ] ) ; t186 [ 244ULL ] = X [ 180ULL ] - 216.59999999999997 ; t186 [
245ULL ] = 623.15 - X [ 180ULL ] ; t186 [ 246ULL ] = X [ 344ULL ] * X [
344ULL ] * intrm_sf_mf_836 / ( intrm_sf_mf_838 == 0.0 ? 1.0E-16 :
intrm_sf_mf_838 ) / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ; t186 [
247ULL ] = X [ 344ULL ] / ( t308 == 0.0 ? 1.0E-16 : t308 ) * 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) ;
t186 [ 248ULL ] = X [ 347ULL ] * intrm_sf_mf_838 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ;
t186 [ 249ULL ] = X [ 348ULL ] * intrm_sf_mf_838 / 1.01325 ; t186 [ 250ULL ]
= t308 / ( X [ 344ULL ] == 0.0 ? 1.0E-16 : X [ 344ULL ] ) ; t186 [ 251ULL ] =
X [ 307ULL ] - 216.59999999999997 ; t186 [ 252ULL ] = 623.15 - X [ 307ULL ] ;
t186 [ 253ULL ] = X [ 507ULL ] * X [ 507ULL ] * t324 / ( intrm_sf_mf_1543 ==
0.0 ? 1.0E-16 : intrm_sf_mf_1543 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [
506ULL ] ) ; t186 [ 254ULL ] = X [ 507ULL ] / ( t328 == 0.0 ? 1.0E-16 : t328
) * 2.0 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) ; t186 [
255ULL ] = X [ 510ULL ] * intrm_sf_mf_1543 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 :
X [ 64ULL ] ) ; t186 [ 256ULL ] = X [ 511ULL ] * intrm_sf_mf_1543 / ( t320 ==
0.0 ? 1.0E-16 : t320 ) ; t186 [ 257ULL ] = t328 / ( X [ 507ULL ] == 0.0 ?
1.0E-16 : X [ 507ULL ] ) ; t186 [ 258ULL ] = X [ 64ULL ] - 0.01 ; t186 [
259ULL ] = pmf_get_inf ( ) - X [ 64ULL ] ; t186 [ 260ULL ] = X [ 469ULL ] -
216.59999999999997 ; t186 [ 261ULL ] = 623.15 - X [ 469ULL ] ; t186 [ 262ULL
] = ( X [ 57ULL ] * 0.1 + 0.0001 ) - 1.0E-8 ; t186 [ 263ULL ] = X [ 56ULL ] -
273.16 ; t186 [ 264ULL ] = 363.16 - X [ 56ULL ] ; t186 [ 265ULL ] = X [
437ULL ] - 0.5 ; t186 [ 266ULL ] = 500.0 - X [ 437ULL ] ; t186 [ 267ULL ] = X
[ 436ULL ] - 273.16 ; t186 [ 268ULL ] = 363.16 - X [ 436ULL ] ; t186 [ 269ULL
] = X [ 439ULL ] - 0.5 ; t186 [ 270ULL ] = 500.0 - X [ 439ULL ] ; t186 [
271ULL ] = X [ 438ULL ] - 273.16 ; t186 [ 272ULL ] = 363.16 - X [ 438ULL ] ;
t186 [ 273ULL ] = X [ 58ULL ] - 0.5 ; t186 [ 274ULL ] = 500.0 - X [ 58ULL ] ;
t186 [ 275ULL ] = X [ 59ULL ] - 273.16 ; t186 [ 276ULL ] = 363.16 - X [ 59ULL
] ; t186 [ 277ULL ] = X [ 60ULL ] - 0.5 ; t186 [ 278ULL ] = 500.0 - X [ 60ULL
] ; t186 [ 279ULL ] = X [ 61ULL ] - 273.16 ; t186 [ 280ULL ] = 363.16 - X [
61ULL ] ; t186 [ 281ULL ] = X [ 63ULL ] - 216.59999999999997 ; t186 [ 282ULL
] = 623.15 - X [ 63ULL ] ; t186 [ 283ULL ] = X [ 63ULL ] * t323 / ( X [ 64ULL
] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ; t186 [ 284ULL ] = X [ 71ULL ] -
216.59999999999997 ; t186 [ 285ULL ] = 623.15 - X [ 71ULL ] ; t186 [ 286ULL ]
= X [ 71ULL ] * intrm_sf_mf_1634 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL
] ) ; t186 [ 287ULL ] = X [ 74ULL ] - 216.59999999999997 ; t186 [ 288ULL ] =
623.15 - X [ 74ULL ] ; t186 [ 289ULL ] = X [ 74ULL ] * intrm_sf_mf_1659 / ( X
[ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ; t186 [ 290ULL ] = X [ 513ULL ] -
216.59999999999997 ; t186 [ 291ULL ] = 623.15 - X [ 513ULL ] ; t186 [ 292ULL
] = X [ 527ULL ] - 216.59999999999997 ; t186 [ 293ULL ] = 623.15 - X [ 527ULL
] ; t186 [ 294ULL ] = X [ 553ULL ] - 216.59999999999997 ; t186 [ 295ULL ] =
623.15 - X [ 553ULL ] ; t186 [ 296ULL ] = ( real_T ) ( X [ 89ULL ] > 0.0 ) ;
t186 [ 297ULL ] = X [ 78ULL ] - X [ 580ULL ] ; t186 [ 298ULL ] =
intrm_sf_mf_684 ; t186 [ 299ULL ] = X [ 4ULL ] ; t186 [ 300ULL ] = X [ 10ULL
] ; t186 [ 301ULL ] = X [ 16ULL ] ; t186 [ 302ULL ] = X [ 12ULL ] ; t186 [
303ULL ] = X [ 17ULL ] ; t186 [ 304ULL ] = X [ 62ULL ] ; t186 [ 305ULL ] = X
[ 32ULL ] ; t186 [ 306ULL ] = X [ 5ULL ] ; t186 [ 307ULL ] = X [ 162ULL ] ;
t186 [ 308ULL ] = X [ 163ULL ] ; t186 [ 309ULL ] = X [ 161ULL ] ; t186 [
310ULL ] = pmf_get_inf ( ) - X [ 145ULL ] ; t186 [ 311ULL ] = X [ 145ULL ] -
1.0E-5 ; t186 [ 312ULL ] = pmf_get_inf ( ) - X [ 144ULL ] ; t186 [ 313ULL ] =
X [ 144ULL ] - 1.0 ; t186 [ 314ULL ] = pmf_get_inf ( ) - X [ 15ULL ] ; t186 [
315ULL ] = X [ 15ULL ] - 1.0E-5 ; t186 [ 316ULL ] = pmf_get_inf ( ) - X [
7ULL ] ; t186 [ 317ULL ] = X [ 7ULL ] - 1.0 ; t186 [ 318ULL ] =
intrm_sf_mf_1772 ; t186 [ 319ULL ] = 393.15 - X [ 156ULL ] ; t186 [ 320ULL ]
= X [ 156ULL ] - 268.4357 ; t186 [ 321ULL ] = intrm_sf_mf_1773 ; t186 [
322ULL ] = 393.15 - X [ 157ULL ] ; t186 [ 323ULL ] = X [ 157ULL ] - 268.4357
; t186 [ 324ULL ] = intrm_sf_mf_1774 ; t186 [ 325ULL ] = 500.0 - X [ 15ULL ]
; t186 [ 326ULL ] = X [ 15ULL ] - 0.1 ; t186 [ 327ULL ] = 393.15 - X [ 8ULL ]
; t186 [ 328ULL ] = X [ 8ULL ] - 268.4357 ; t186 [ 329ULL ] =
216.59999999999997 - U_idx_6 ; t186 [ 330ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t186 [
331ULL ] = 216.59999999999997 - U_idx_9 ; t186 [ 332ULL ] = U_idx_3 ; t186 [
333ULL ] = 216.59999999999997 - X [ 32ULL ] ; t186 [ 334ULL ] = U_idx_7 ;
U_idx_3 = X [ 180ULL ] * intrm_sf_mf_252 ; t186 [ 335ULL ] = U_idx_3 /
1.01325 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X
[ 175ULL ] * t220 ; t186 [ 336ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ; t504 = X [ 194ULL ] * t284 ;
t186 [ 337ULL ] = t504 / ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) ;
t186 [ 338ULL ] = t504 / ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) ;
t186 [ 339ULL ] = U_idx_3 / 1.01325 ; U_idx_3 = X [ 240ULL ] *
intrm_sf_mf_290 ; t186 [ 340ULL ] = U_idx_3 / ( X [ 241ULL ] == 0.0 ? 1.0E-16
: X [ 241ULL ] ) ; t499 = X [ 226ULL ] * intrm_sf_mf_335 ; t186 [ 341ULL ] =
t499 / ( X [ 227ULL ] == 0.0 ? 1.0E-16 : X [ 227ULL ] ) ; t186 [ 342ULL ] =
t499 / ( X [ 227ULL ] == 0.0 ? 1.0E-16 : X [ 227ULL ] ) ; t186 [ 343ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ; t499 = X [ 278ULL ] * t301 ;
t186 [ 344ULL ] = t499 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ;
t186 [ 345ULL ] = U_idx_3 / ( X [ 241ULL ] == 0.0 ? 1.0E-16 : X [ 241ULL ] )
; U_idx_3 = X [ 307ULL ] * intrm_sf_mf_685 ; t186 [ 346ULL ] = U_idx_3 /
1.01325 ; t504 = X [ 302ULL ] * t247 ; t186 [ 347ULL ] = t504 / ( X [ 303ULL
] == 0.0 ? 1.0E-16 : X [ 303ULL ] ) ; t524 = X [ 321ULL ] * t305 ; t186 [
348ULL ] = t524 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ;
t186 [ 349ULL ] = t524 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ;
t186 [ 350ULL ] = U_idx_3 / 1.01325 ; U_idx_3 = X [ 364ULL ] *
intrm_sf_mf_904 ; t186 [ 351ULL ] = U_idx_3 / ( X [ 365ULL ] == 0.0 ? 1.0E-16
: X [ 365ULL ] ) ; t511 = X [ 350ULL ] * intrm_sf_mf_934 ; t186 [ 352ULL ] =
t511 / ( X [ 351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ; t186 [ 353ULL ] =
t511 / ( X [ 351ULL ] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) ; t186 [ 354ULL ] =
t504 / ( X [ 303ULL ] == 0.0 ? 1.0E-16 : X [ 303ULL ] ) ; t504 = X [ 403ULL ]
* t321 ; t186 [ 355ULL ] = t504 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL
] ) ; t186 [ 356ULL ] = U_idx_3 / ( X [ 365ULL ] == 0.0 ? 1.0E-16 : X [
365ULL ] ) ; U_idx_3 = X [ 469ULL ] * intrm_sf_mf_1387 ; t186 [ 357ULL ] =
U_idx_3 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) ; t523 = X [ 484ULL
] * t274 ; t186 [ 358ULL ] = t523 / ( t320 == 0.0 ? 1.0E-16 : t320 ) ; t524 =
X [ 466ULL ] * t325 ; t186 [ 359ULL ] = t524 / ( X [ 38ULL ] == 0.0 ? 1.0E-16
: X [ 38ULL ] ) ; t186 [ 360ULL ] = U_idx_3 / ( X [ 64ULL ] == 0.0 ? 1.0E-16
: X [ 64ULL ] ) ; t186 [ 361ULL ] = t523 / ( t320 == 0.0 ? 1.0E-16 : t320 ) ;
U_idx_3 = X [ 513ULL ] * t338 ; t186 [ 362ULL ] = U_idx_3 / 1.01325 ; t186 [
363ULL ] = U_idx_3 / 1.01325 ; U_idx_3 = X [ 527ULL ] * t339 ; t186 [ 364ULL
] = U_idx_3 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ; t186 [ 365ULL
] = U_idx_3 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ; t186 [ 366ULL
] = t504 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ; t186 [ 367ULL ] =
t524 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ; U_idx_3 = X [ 553ULL
] * intrm_sf_mf_1672 ; t186 [ 368ULL ] = U_idx_3 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ; t186 [ 369ULL ] = t499 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ; t186 [ 370ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ; t186 [ 371ULL ] = U_idx_3 / ( X
[ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ; t186 [ 372ULL ] = X [ 531ULL ] *
t336 / 1.01325 ; t186 [ 373ULL ] = X [ 534ULL ] * t336 / ( X [ 55ULL ] == 0.0
? 1.0E-16 : X [ 55ULL ] ) ; t186 [ 374ULL ] = X [ 532ULL ] * t336 / ( X [
55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) ; t186 [ 375ULL ] = X [ 533ULL ] *
t336 / 1.01325 ; t186 [ 376ULL ] = X [ 570ULL ] * intrm_sf_mf_1696 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ; t186 [ 377ULL ] = X [ 573ULL ] *
intrm_sf_mf_1696 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ; t186 [
378ULL ] = X [ 571ULL ] * intrm_sf_mf_1696 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 :
X [ 38ULL ] ) ; t186 [ 379ULL ] = X [ 572ULL ] * intrm_sf_mf_1696 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ; t186 [ 380ULL ] = X [ 464ULL ] -
0.6 ; for ( b = 0 ; b < 381 ; b ++ ) { out . mX [ b ] = t186 [ b ] ; } ( void
) LC ; ( void ) t559 ; return 0 ; }
