#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_assert.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_assert ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t2780 , NeDsMethodOutput * t2781 ) { ETTS0
ab_efOut ; ETTS0 ad_efOut ; ETTS0 af_efOut ; ETTS0 ag_efOut ; ETTS0 ah_efOut
; ETTS0 aj_efOut ; ETTS0 al_efOut ; ETTS0 am_efOut ; ETTS0 b_efOut ; ETTS0
bi_efOut ; ETTS0 bj_efOut ; ETTS0 bk_efOut ; ETTS0 cb_efOut ; ETTS0 cc_efOut
; ETTS0 ce_efOut ; ETTS0 cg_efOut ; ETTS0 ck_efOut ; ETTS0 cm_efOut ; ETTS0
d_efOut ; ETTS0 db_efOut ; ETTS0 dj_efOut ; ETTS0 dm_efOut ; ETTS0 e_efOut ;
ETTS0 ec_efOut ; ETTS0 ed_efOut ; ETTS0 ee_efOut ; ETTS0 efOut ; ETTS0
ej_efOut ; ETTS0 ek_efOut ; ETTS0 el_efOut ; ETTS0 fb_efOut ; ETTS0 ff_efOut
; ETTS0 fi_efOut ; ETTS0 g_efOut ; ETTS0 gb_efOut ; ETTS0 gc_efOut ; ETTS0
gd_efOut ; ETTS0 gj_efOut ; ETTS0 gk_efOut ; ETTS0 gl_efOut ; ETTS0 h_efOut ;
ETTS0 hi_efOut ; ETTS0 ib_efOut ; ETTS0 ij_efOut ; ETTS0 j_efOut ; ETTS0
jb_efOut ; ETTS0 jc_efOut ; ETTS0 jf_efOut ; ETTS0 jk_efOut ; ETTS0 k_efOut ;
ETTS0 kc_efOut ; ETTS0 kh_efOut ; ETTS0 kk_efOut ; ETTS0 lb_efOut ; ETTS0
lf_efOut ; ETTS0 lj_efOut ; ETTS0 m_efOut ; ETTS0 mb_efOut ; ETTS0 mg_efOut ;
ETTS0 mj_efOut ; ETTS0 mk_efOut ; ETTS0 n_efOut ; ETTS0 nc_efOut ; ETTS0
oe_efOut ; ETTS0 oj_efOut ; ETTS0 ok_efOut ; ETTS0 p_efOut ; ETTS0 pb_efOut ;
ETTS0 pc_efOut ; ETTS0 q_efOut ; ETTS0 qd_efOut ; ETTS0 qj_efOut ; ETTS0
ql_efOut ; ETTS0 rb_efOut ; ETTS0 rc_efOut ; ETTS0 rh_efOut ; ETTS0 ri_efOut
; ETTS0 s_efOut ; ETTS0 sb_efOut ; ETTS0 si_efOut ; ETTS0 t109 ; ETTS0 t116 ;
ETTS0 t122 ; ETTS0 t123 ; ETTS0 t125 ; ETTS0 t128 ; ETTS0 t14 ; ETTS0 t20 ;
ETTS0 t70 ; ETTS0 t74 ; ETTS0 t86 ; ETTS0 t87 ; ETTS0 t88 ; ETTS0 t_efOut ;
ETTS0 tg_efOut ; ETTS0 tk_efOut ; ETTS0 ub_efOut ; ETTS0 uc_efOut ; ETTS0
ui_efOut ; ETTS0 v_efOut ; ETTS0 vc_efOut ; ETTS0 ve_efOut ; ETTS0 vf_efOut ;
ETTS0 vh_efOut ; ETTS0 vj_efOut ; ETTS0 vk_efOut ; ETTS0 w_efOut ; ETTS0
wi_efOut ; ETTS0 xb_efOut ; ETTS0 xc_efOut ; ETTS0 xd_efOut ; ETTS0 xg_efOut
; ETTS0 xi_efOut ; ETTS0 xj_efOut ; ETTS0 xk_efOut ; ETTS0 xl_efOut ; ETTS0
y_efOut ; ETTS0 yb_efOut ; ETTS0 yj_efOut ; PmIntVector out ; real_T X [ 582
] ; real_T nonscalar1 [ 7 ] ; real_T ac_efOut [ 1 ] ; real_T ae_efOut [ 1 ] ;
real_T ai_efOut [ 1 ] ; real_T ak_efOut [ 1 ] ; real_T bb_efOut [ 1 ] ;
real_T bc_efOut [ 1 ] ; real_T bd_efOut [ 1 ] ; real_T be_efOut [ 1 ] ;
real_T bf_efOut [ 1 ] ; real_T bg_efOut [ 1 ] ; real_T bh_efOut [ 1 ] ;
real_T bl_efOut [ 1 ] ; real_T bm_efOut [ 1 ] ; real_T c_efOut [ 1 ] ; real_T
cd_efOut [ 1 ] ; real_T cf_efOut [ 1 ] ; real_T ch_efOut [ 1 ] ; real_T
ci_efOut [ 1 ] ; real_T cj_efOut [ 1 ] ; real_T cl_efOut [ 1 ] ; real_T
dc_efOut [ 1 ] ; real_T dd_efOut [ 1 ] ; real_T de_efOut [ 1 ] ; real_T
df_efOut [ 1 ] ; real_T dg_efOut [ 1 ] ; real_T dh_efOut [ 1 ] ; real_T
di_efOut [ 1 ] ; real_T dk_efOut [ 1 ] ; real_T dl_efOut [ 1 ] ; real_T
eb_efOut [ 1 ] ; real_T ef_efOut [ 1 ] ; real_T eg_efOut [ 1 ] ; real_T
eh_efOut [ 1 ] ; real_T ei_efOut [ 1 ] ; real_T em_efOut [ 1 ] ; real_T
f_efOut [ 1 ] ; real_T fc_efOut [ 1 ] ; real_T fd_efOut [ 1 ] ; real_T
fe_efOut [ 1 ] ; real_T fg_efOut [ 1 ] ; real_T fh_efOut [ 1 ] ; real_T
fj_efOut [ 1 ] ; real_T fk_efOut [ 1 ] ; real_T fl_efOut [ 1 ] ; real_T
ge_efOut [ 1 ] ; real_T gf_efOut [ 1 ] ; real_T gg_efOut [ 1 ] ; real_T
gh_efOut [ 1 ] ; real_T gi_efOut [ 1 ] ; real_T hb_efOut [ 1 ] ; real_T
hc_efOut [ 1 ] ; real_T hd_efOut [ 1 ] ; real_T he_efOut [ 1 ] ; real_T
hf_efOut [ 1 ] ; real_T hg_efOut [ 1 ] ; real_T hh_efOut [ 1 ] ; real_T
hj_efOut [ 1 ] ; real_T hk_efOut [ 1 ] ; real_T hl_efOut [ 1 ] ; real_T
i_efOut [ 1 ] ; real_T ic_efOut [ 1 ] ; real_T id_efOut [ 1 ] ; real_T
ie_efOut [ 1 ] ; real_T if_efOut [ 1 ] ; real_T ig_efOut [ 1 ] ; real_T
ih_efOut [ 1 ] ; real_T ii_efOut [ 1 ] ; real_T ik_efOut [ 1 ] ; real_T
il_efOut [ 1 ] ; real_T jd_efOut [ 1 ] ; real_T je_efOut [ 1 ] ; real_T
jg_efOut [ 1 ] ; real_T jh_efOut [ 1 ] ; real_T ji_efOut [ 1 ] ; real_T
jj_efOut [ 1 ] ; real_T jl_efOut [ 1 ] ; real_T kb_efOut [ 1 ] ; real_T
kd_efOut [ 1 ] ; real_T ke_efOut [ 1 ] ; real_T kf_efOut [ 1 ] ; real_T
kg_efOut [ 1 ] ; real_T ki_efOut [ 1 ] ; real_T kj_efOut [ 1 ] ; real_T
kl_efOut [ 1 ] ; real_T l_efOut [ 1 ] ; real_T lc_efOut [ 1 ] ; real_T
ld_efOut [ 1 ] ; real_T le_efOut [ 1 ] ; real_T lg_efOut [ 1 ] ; real_T
lh_efOut [ 1 ] ; real_T li_efOut [ 1 ] ; real_T lk_efOut [ 1 ] ; real_T
ll_efOut [ 1 ] ; real_T mc_efOut [ 1 ] ; real_T md_efOut [ 1 ] ; real_T
me_efOut [ 1 ] ; real_T mf_efOut [ 1 ] ; real_T mh_efOut [ 1 ] ; real_T
mi_efOut [ 1 ] ; real_T ml_efOut [ 1 ] ; real_T nb_efOut [ 1 ] ; real_T
nd_efOut [ 1 ] ; real_T ne_efOut [ 1 ] ; real_T nf_efOut [ 1 ] ; real_T
ng_efOut [ 1 ] ; real_T nh_efOut [ 1 ] ; real_T ni_efOut [ 1 ] ; real_T
nj_efOut [ 1 ] ; real_T nk_efOut [ 1 ] ; real_T nl_efOut [ 1 ] ; real_T
o_efOut [ 1 ] ; real_T ob_efOut [ 1 ] ; real_T oc_efOut [ 1 ] ; real_T
od_efOut [ 1 ] ; real_T of_efOut [ 1 ] ; real_T og_efOut [ 1 ] ; real_T
oh_efOut [ 1 ] ; real_T oi_efOut [ 1 ] ; real_T ol_efOut [ 1 ] ; real_T
pd_efOut [ 1 ] ; real_T pe_efOut [ 1 ] ; real_T pf_efOut [ 1 ] ; real_T
pg_efOut [ 1 ] ; real_T ph_efOut [ 1 ] ; real_T pi_efOut [ 1 ] ; real_T
pj_efOut [ 1 ] ; real_T pk_efOut [ 1 ] ; real_T pl_efOut [ 1 ] ; real_T
qb_efOut [ 1 ] ; real_T qc_efOut [ 1 ] ; real_T qe_efOut [ 1 ] ; real_T
qf_efOut [ 1 ] ; real_T qg_efOut [ 1 ] ; real_T qh_efOut [ 1 ] ; real_T
qi_efOut [ 1 ] ; real_T qk_efOut [ 1 ] ; real_T r_efOut [ 1 ] ; real_T
rd_efOut [ 1 ] ; real_T re_efOut [ 1 ] ; real_T rf_efOut [ 1 ] ; real_T
rg_efOut [ 1 ] ; real_T rj_efOut [ 1 ] ; real_T rk_efOut [ 1 ] ; real_T
rl_efOut [ 1 ] ; real_T sc_efOut [ 1 ] ; real_T sd_efOut [ 1 ] ; real_T
se_efOut [ 1 ] ; real_T sf_efOut [ 1 ] ; real_T sg_efOut [ 1 ] ; real_T
sh_efOut [ 1 ] ; real_T sj_efOut [ 1 ] ; real_T sk_efOut [ 1 ] ; real_T
sl_efOut [ 1 ] ; real_T t1100 [ 1 ] ; real_T t141 [ 1 ] ; real_T t150 [ 1 ] ;
real_T t159 [ 1 ] ; real_T t168 [ 1 ] ; real_T t177 [ 1 ] ; real_T t186 [ 1 ]
; real_T t192 [ 1 ] ; real_T t914 [ 1 ] ; real_T t915 [ 1 ] ; real_T t916 [ 1
] ; real_T t917 [ 1 ] ; real_T t918 [ 1 ] ; real_T t919 [ 1 ] ; real_T
tb_efOut [ 1 ] ; real_T tc_efOut [ 1 ] ; real_T td_efOut [ 1 ] ; real_T
te_efOut [ 1 ] ; real_T tf_efOut [ 1 ] ; real_T th_efOut [ 1 ] ; real_T
ti_efOut [ 1 ] ; real_T tj_efOut [ 1 ] ; real_T tl_efOut [ 1 ] ; real_T
u_efOut [ 1 ] ; real_T ud_efOut [ 1 ] ; real_T ue_efOut [ 1 ] ; real_T
uf_efOut [ 1 ] ; real_T ug_efOut [ 1 ] ; real_T uh_efOut [ 1 ] ; real_T
uj_efOut [ 1 ] ; real_T uk_efOut [ 1 ] ; real_T ul_efOut [ 1 ] ; real_T
vb_efOut [ 1 ] ; real_T vd_efOut [ 1 ] ; real_T vg_efOut [ 1 ] ; real_T
vi_efOut [ 1 ] ; real_T vl_efOut [ 1 ] ; real_T wb_efOut [ 1 ] ; real_T
wc_efOut [ 1 ] ; real_T wd_efOut [ 1 ] ; real_T we_efOut [ 1 ] ; real_T
wf_efOut [ 1 ] ; real_T wg_efOut [ 1 ] ; real_T wh_efOut [ 1 ] ; real_T
wj_efOut [ 1 ] ; real_T wk_efOut [ 1 ] ; real_T wl_efOut [ 1 ] ; real_T
x_efOut [ 1 ] ; real_T xe_efOut [ 1 ] ; real_T xf_efOut [ 1 ] ; real_T
xh_efOut [ 1 ] ; real_T yc_efOut [ 1 ] ; real_T yd_efOut [ 1 ] ; real_T
ye_efOut [ 1 ] ; real_T yf_efOut [ 1 ] ; real_T yg_efOut [ 1 ] ; real_T
yh_efOut [ 1 ] ; real_T yi_efOut [ 1 ] ; real_T yk_efOut [ 1 ] ; real_T
yl_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co1 ; real_T
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio1 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg ; real_T
Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 ; real_T
Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_A ; real_T
Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_B ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 ; real_T
U_idx_10 ; real_T U_idx_11 ; real_T U_idx_13 ; real_T U_idx_2 ; real_T
U_idx_3 ; real_T U_idx_4 ; real_T U_idx_5 ; real_T U_idx_7 ; real_T U_idx_8 ;
real_T intrm_sf_mf_102 ; real_T intrm_sf_mf_1066 ; real_T intrm_sf_mf_1083 ;
real_T intrm_sf_mf_1085 ; real_T intrm_sf_mf_1220 ; real_T intrm_sf_mf_1227 ;
real_T intrm_sf_mf_1228 ; real_T intrm_sf_mf_1280 ; real_T intrm_sf_mf_1300 ;
real_T intrm_sf_mf_1327 ; real_T intrm_sf_mf_1340 ; real_T intrm_sf_mf_1464 ;
real_T intrm_sf_mf_148 ; real_T intrm_sf_mf_1574 ; real_T intrm_sf_mf_171 ;
real_T intrm_sf_mf_172 ; real_T intrm_sf_mf_179 ; real_T intrm_sf_mf_249 ;
real_T intrm_sf_mf_270 ; real_T intrm_sf_mf_290 ; real_T intrm_sf_mf_306 ;
real_T intrm_sf_mf_330 ; real_T intrm_sf_mf_483 ; real_T intrm_sf_mf_491 ;
real_T intrm_sf_mf_565 ; real_T intrm_sf_mf_621 ; real_T intrm_sf_mf_622 ;
real_T intrm_sf_mf_623 ; real_T intrm_sf_mf_71 ; real_T intrm_sf_mf_714 ;
real_T intrm_sf_mf_72 ; real_T intrm_sf_mf_73 ; real_T intrm_sf_mf_74 ;
real_T intrm_sf_mf_829 ; real_T intrm_sf_mf_83 ; real_T intrm_sf_mf_848 ;
real_T intrm_sf_mf_898 ; real_T intrm_sf_mf_95 ; real_T intrm_sf_mf_99 ;
real_T t1091_idx_0 ; real_T t1096_idx_0 ; real_T t1098_idx_0 ; real_T t1301 ;
real_T t1303 ; real_T t1304 ; real_T t1306 ; real_T t1308 ; real_T t1315 ;
real_T t1322 ; real_T t1323 ; real_T t1330 ; real_T t1333 ; real_T t1348 ;
real_T t1376 ; real_T t1388 ; real_T t1401 ; real_T t1403 ; real_T t1406 ;
real_T t1407 ; real_T t1408 ; real_T t1409 ; real_T t1410 ; real_T t1411 ;
real_T t1412 ; real_T t1413 ; real_T t1414 ; real_T t1415 ; real_T t1416 ;
real_T t1418 ; real_T t1419 ; real_T t1421 ; real_T t1423 ; real_T t1425 ;
real_T t1426 ; real_T t1427 ; real_T t1428 ; real_T t1429 ; real_T t1430 ;
real_T t1431 ; real_T t1432 ; real_T t1433 ; real_T t1435 ; real_T t1436 ;
real_T t1437 ; real_T t1438 ; real_T t1439 ; real_T t1440 ; real_T t1441 ;
real_T t1442 ; real_T t1443 ; real_T t1444 ; real_T t1446 ; real_T t1447 ;
real_T t1449 ; real_T t1450 ; real_T t1451 ; real_T t1454 ; real_T t1456 ;
real_T t1457 ; real_T t1458 ; real_T t1460 ; real_T t1461 ; real_T t1463 ;
real_T t1464 ; real_T t1465 ; real_T t1467 ; real_T t1468 ; real_T t1469 ;
real_T t1470 ; real_T t1474 ; real_T t1475 ; real_T t1477 ; real_T t1478 ;
real_T t1480 ; real_T t1482 ; real_T t1487 ; real_T t1488 ; real_T t1489 ;
real_T t1491 ; real_T t1492 ; real_T t1493 ; real_T t1494 ; real_T t1495 ;
real_T t1496 ; real_T t1498 ; real_T t1501 ; real_T t1503 ; real_T t1504 ;
real_T t1507 ; real_T t1508 ; real_T t1510 ; real_T t1511 ; real_T t1512 ;
real_T t1513 ; real_T t1516 ; real_T t1517 ; real_T t1519 ; real_T t1520 ;
real_T t1523 ; real_T t1524 ; real_T t1525 ; real_T t1527 ; real_T t1528 ;
real_T t1532 ; real_T t1533 ; real_T t1536 ; real_T t1542 ; real_T t1544 ;
real_T t1545 ; real_T t1546 ; real_T t1547 ; real_T t1548 ; real_T t1549 ;
real_T t1551 ; real_T t1552 ; real_T t1554 ; real_T t1555 ; real_T t1557 ;
real_T t1558 ; real_T t1560 ; real_T t1561 ; real_T t1563 ; real_T t1564 ;
real_T t1565 ; real_T t1566 ; real_T t1567 ; real_T t1568 ; real_T t1570 ;
real_T t1574 ; real_T t1575 ; real_T t1576 ; real_T t1577 ; real_T t1580 ;
real_T t1584 ; real_T t1585 ; real_T t1587 ; real_T t1588 ; real_T t1589 ;
real_T t1590 ; real_T t1591 ; real_T t1592 ; real_T t1595 ; real_T t1596 ;
real_T t1597 ; real_T t1598 ; real_T t1600 ; real_T t1601 ; real_T t1602 ;
real_T t1604 ; real_T t1606 ; real_T t1607 ; real_T t1608 ; real_T t1609 ;
real_T t1611 ; real_T t1613 ; real_T t1614 ; real_T t1616 ; real_T t1618 ;
real_T t1619 ; real_T t1620 ; real_T t1621 ; real_T t1622 ; real_T t1624 ;
real_T t1625 ; real_T t1627 ; real_T t1628 ; real_T t1630 ; real_T t1631 ;
real_T t1632 ; real_T t1633 ; real_T t1634 ; real_T t1635 ; real_T t1636 ;
real_T t1638 ; real_T t1639 ; real_T t1641 ; real_T t1642 ; real_T t1644 ;
real_T t1645 ; real_T t1647 ; real_T t1648 ; real_T t1649 ; real_T t1650 ;
real_T t1651 ; real_T t1652 ; real_T t1654 ; real_T t1659 ; real_T t1660 ;
real_T t1661 ; real_T t1664 ; real_T t1666 ; real_T t1668 ; real_T t1669 ;
real_T t1671 ; real_T t1673 ; real_T t1674 ; real_T t1675 ; real_T t1677 ;
real_T t1679 ; real_T t1680 ; real_T t1681 ; real_T t1683 ; real_T t1684 ;
real_T t1685 ; real_T t1686 ; real_T t1688 ; real_T t1689 ; real_T t1690 ;
real_T t1691 ; real_T t1692 ; real_T t1693 ; real_T t1694 ; real_T t1696 ;
real_T t1698 ; real_T t1699 ; real_T t1700 ; real_T t1701 ; real_T t1702 ;
real_T t1704 ; real_T t1705 ; real_T t1707 ; real_T t1709 ; real_T t1710 ;
real_T t1711 ; real_T t1712 ; real_T t1713 ; real_T t1715 ; real_T t1716 ;
real_T t1718 ; real_T t1719 ; real_T t1721 ; real_T t1722 ; real_T t1724 ;
real_T t1725 ; real_T t1727 ; real_T t1729 ; real_T t1731 ; real_T t1732 ;
real_T t1733 ; real_T t1738 ; real_T t1739 ; real_T t1740 ; real_T t1741 ;
real_T t1742 ; real_T t1744 ; real_T t1746 ; real_T t1748 ; real_T t1749 ;
real_T t1751 ; real_T t1752 ; real_T t1753 ; real_T t1754 ; real_T t1755 ;
real_T t1756 ; real_T t1758 ; real_T t1759 ; real_T t1760 ; real_T t1762 ;
real_T t1763 ; real_T t1764 ; real_T t1765 ; real_T t1766 ; real_T t1767 ;
real_T t1768 ; real_T t1771 ; real_T t1772 ; real_T t1773 ; real_T t1774 ;
real_T t1776 ; real_T t1777 ; real_T t1778 ; real_T t1779 ; real_T t1780 ;
real_T t1781 ; real_T t1782 ; real_T t1783 ; real_T t1784 ; real_T t1785 ;
real_T t1787 ; real_T t1790 ; real_T t1792 ; real_T t1793 ; real_T t1795 ;
real_T t1797 ; real_T t1800 ; real_T t1801 ; real_T t1802 ; real_T t1803 ;
real_T t1807 ; real_T t1809 ; real_T t1810 ; real_T t1811 ; real_T t1812 ;
real_T t1814 ; real_T t1815 ; real_T t1816 ; real_T t1820 ; real_T t1821 ;
real_T t1822 ; real_T t1823 ; real_T t1824 ; real_T t1826 ; real_T t1828 ;
real_T t1830 ; real_T t1831 ; real_T t1833 ; real_T t1834 ; real_T t1837 ;
real_T t1838 ; real_T t1839 ; real_T t1840 ; real_T t1841 ; real_T t1842 ;
real_T t1843 ; real_T t1844 ; real_T t1845 ; real_T t1846 ; real_T t1847 ;
real_T t1848 ; real_T t1849 ; real_T t1850 ; real_T t1852 ; real_T t1853 ;
real_T t1854 ; real_T t1855 ; real_T t1856 ; real_T t1857 ; real_T t1858 ;
real_T t1859 ; real_T t1860 ; real_T t1861 ; real_T t1862 ; real_T t1863 ;
real_T t1864 ; real_T t1865 ; real_T t1866 ; real_T t1867 ; real_T t1868 ;
real_T t1869 ; real_T t1870 ; real_T t1871 ; real_T t1873 ; real_T t1874 ;
real_T t1875 ; real_T t1876 ; real_T t1877 ; real_T t1878 ; real_T t1879 ;
real_T t1881 ; real_T t1882 ; real_T t1884 ; real_T t1887 ; real_T t1889 ;
real_T t1890 ; real_T t1891 ; real_T t1892 ; real_T t1893 ; real_T t1894 ;
real_T t1896 ; real_T t1899 ; real_T t1900 ; real_T t1901 ; real_T t1902 ;
real_T t1903 ; real_T t1905 ; real_T t1906 ; real_T t1909 ; real_T t1910 ;
real_T t1911 ; real_T t1912 ; real_T t1913 ; real_T t1914 ; real_T t1915 ;
real_T t1919 ; real_T t1921 ; real_T t1922 ; real_T t1923 ; real_T t1925 ;
real_T t1930 ; real_T t1933 ; real_T t1934 ; real_T t1935 ; real_T t1937 ;
real_T t1938 ; real_T t1939 ; real_T t1940 ; real_T t1941 ; real_T t1942 ;
real_T t1943 ; real_T t1944 ; real_T t1945 ; real_T t1947 ; real_T t1948 ;
real_T t1949 ; real_T t1951 ; real_T t1952 ; real_T t1953 ; real_T t1955 ;
real_T t1956 ; real_T t1958 ; real_T t1959 ; real_T t1960 ; real_T t1961 ;
real_T t1964 ; real_T t1965 ; real_T t1969 ; real_T t1970 ; real_T t1972 ;
real_T t1973 ; real_T t1974 ; real_T t1976 ; real_T t1978 ; real_T t1979 ;
real_T t1980 ; real_T t1981 ; real_T t1983 ; real_T t1984 ; real_T t1985 ;
real_T t1986 ; real_T t1987 ; real_T t1989 ; real_T t1990 ; real_T t1993 ;
real_T t1995 ; real_T t1996 ; real_T t1998 ; real_T t1999 ; real_T t2005 ;
real_T t2006 ; real_T t2011 ; real_T t2013 ; real_T t2014 ; real_T t2016 ;
real_T t2020 ; real_T t2022 ; real_T t2024 ; real_T t2025 ; real_T t2027 ;
real_T t2031 ; real_T t2036 ; real_T t2044 ; real_T t2050 ; real_T t2066 ;
real_T t2070 ; real_T t2085 ; real_T t2100 ; real_T t2107 ; real_T t2110 ;
real_T t2118 ; real_T t2126 ; real_T t2132 ; real_T t2164 ; real_T t2184 ;
real_T t2199 ; real_T t2205 ; real_T t2211 ; real_T t2223 ; real_T t2224 ;
real_T t2232 ; real_T t2255 ; real_T t2274 ; real_T t2282 ; real_T t2295 ;
real_T t2298 ; real_T t2303 ; real_T t2316 ; real_T t2319 ; real_T t2327 ;
real_T t2337 ; real_T t2340 ; real_T t2343 ; real_T t2678 ; real_T t2769 ;
real_T t2773 ; real_T t2779 ; size_t t139 [ 1 ] ; size_t t140 [ 1 ] ; size_t
t142 [ 1 ] ; size_t t364 [ 1 ] ; size_t t674 [ 1 ] ; size_t t677 [ 1 ] ;
size_t t1168 ; size_t t1170 ; int32_T t913 [ 3846 ] ; int32_T M [ 361 ] ;
int32_T b ; boolean_T intrm_sf_mf_1801 ; boolean_T t132 ; boolean_T t133 ;
boolean_T t134 ; boolean_T t135 ; boolean_T t136 ; boolean_T t137 ; for ( b =
0 ; b < 361 ; b ++ ) { M [ b ] = t2780 -> mM . mX [ b ] ; } U_idx_2 = t2780
-> mU . mX [ 2 ] ; U_idx_3 = t2780 -> mU . mX [ 3 ] ; U_idx_4 = t2780 -> mU .
mX [ 4 ] ; U_idx_5 = t2780 -> mU . mX [ 5 ] ; U_idx_7 = t2780 -> mU . mX [ 7
] ; U_idx_8 = t2780 -> mU . mX [ 8 ] ; U_idx_10 = t2780 -> mU . mX [ 10 ] ;
U_idx_11 = t2780 -> mU . mX [ 11 ] ; U_idx_13 = t2780 -> mU . mX [ 13 ] ; for
( b = 0 ; b < 582 ; b ++ ) { X [ b ] = t2780 -> mX . mX [ b ] ; } out = t2781
-> mASSERT ; nonscalar1 [ 0 ] = 190800.0 ; nonscalar1 [ 1 ] = 190800.0 ;
nonscalar1 [ 2 ] = 190800.0 ; nonscalar1 [ 3 ] = 190800.0 ; nonscalar1 [ 4 ]
= 190800.0 ; nonscalar1 [ 5 ] = 190800.0 ; nonscalar1 [ 6 ] = 190800.0 ; t914
[ 0ULL ] = pmf_get_inf ( ) ; for ( t1170 = 0ULL ; t1170 < 7ULL ; t1170 ++ ) {
t1168 = t1170 / 7ULL ; t1301 = t914 [ t1168 > 0ULL ? 0ULL : t1168 ] ; t1303 =
nonscalar1 [ t1170 ] * 1.0E-5 ; t914 [ t1168 > 0ULL ? 0ULL : t1168 ] = t1301
> t1303 ? t1303 : t1301 ; } t1303 = X [ 85ULL ] * X [ 87ULL ] ; t1304 = t914
[ 0ULL ] ; t1301 = t1303 > t1304 ? t1303 : t1304 ; t1304 = pmf_sqrt ( U_idx_2
* U_idx_2 + 4.5311819630628225E-12 ) ; t914 [ 0ULL ] = X [ 97ULL ] ; t139 [ 0
] = 20ULL ; t140 [ 0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut .
mField0 [ 0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t914 [ 0ULL ] , & t139 [
0ULL ] , & t140 [ 0ULL ] ) ; t116 = efOut ; t141 [ 0ULL ] = X [ 93ULL ] ;
t142 [ 0 ] = 19ULL ; tlu2_linear_linear_prelookup ( & b_efOut . mField0 [
0ULL ] , & b_efOut . mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t141 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t123 = b_efOut ; tlu2_2d_linear_linear_value ( &
c_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t123 . mField0 [ 0ULL ] , & t123 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t915 [ 0 ] = c_efOut [ 0 ] ; t2773 = t915 [ 0ULL ] ; t915 [ 0ULL ] = X [
99ULL ] ; tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , &
d_efOut . mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t915 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = d_efOut ; t150 [ 0ULL ] = X [ 95ULL ] ;
tlu2_linear_linear_prelookup ( & e_efOut . mField0 [ 0ULL ] , & e_efOut .
mField1 [ 0ULL ] , & e_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t150 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t87 = e_efOut ; tlu2_2d_linear_linear_value ( & f_efOut [ 0ULL ] , & t116 .
mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t87 . mField0 [ 0ULL ] , &
t87 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t916 [ 0 ] = f_efOut [
0 ] ; t2769 = t916 [ 0ULL ] ; t916 [ 0ULL ] = X [ 97ULL ] ;
tlu2_linear_nearest_prelookup ( & g_efOut . mField0 [ 0ULL ] , & g_efOut .
mField1 [ 0ULL ] , & g_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t916 [ 0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = g_efOut ; t159 [ 0ULL ] = X [ 93ULL ] ; tlu2_linear_nearest_prelookup (
& h_efOut . mField0 [ 0ULL ] , & h_efOut . mField1 [ 0ULL ] , & h_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t159 [
0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = h_efOut ;
tlu2_2d_linear_nearest_value ( & i_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t917 [ 0 ] = i_efOut [ 0 ] ; t2678 = t917
[ 0ULL ] ; t917 [ 0ULL ] = X [ 99ULL ] ; tlu2_linear_nearest_prelookup ( &
j_efOut . mField0 [ 0ULL ] , & j_efOut . mField1 [ 0ULL ] , & j_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t917 [
0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t74 = j_efOut ; t168 [ 0ULL ]
= X [ 95ULL ] ; tlu2_linear_nearest_prelookup ( & k_efOut . mField0 [ 0ULL ]
, & k_efOut . mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t168 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = k_efOut ; tlu2_2d_linear_nearest_value ( &
l_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField5 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t918 [ 0 ] = l_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co1 = t918 [ 0ULL
] ; t2678 = ( t2678 +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co1 ) / 2.0 ;
t2678 = t2678 * 1697.0562748477141 / 0.7 ; t918 [ 0ULL ] = X [ 106ULL ] ;
tlu2_linear_linear_prelookup ( & m_efOut . mField0 [ 0ULL ] , & m_efOut .
mField1 [ 0ULL ] , & m_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t918 [ 0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = m_efOut ; t177 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_linear_prelookup
( & n_efOut . mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t177 [
0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t14 = n_efOut ;
tlu2_2d_linear_linear_value ( & o_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t919 [ 0 ] = o_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co1 = t919 [ 0ULL
] ; t919 [ 0ULL ] = X [ 108ULL ] ; tlu2_linear_linear_prelookup ( & p_efOut .
mField0 [ 0ULL ] , & p_efOut . mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t919 [ 0ULL ] , & t139 [
0ULL ] , & t140 [ 0ULL ] ) ; t116 = p_efOut ; t186 [ 0ULL ] = X [ 104ULL ] ;
tlu2_linear_linear_prelookup ( & q_efOut . mField0 [ 0ULL ] , & q_efOut .
mField1 [ 0ULL ] , & q_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t186 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t20 = q_efOut ; tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t116 .
mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t20 . mField0 [ 0ULL ] , &
t20 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t192 [ 0 ] = r_efOut [
0 ] ; t1401 = t192 [ 0ULL ] ; t192 [ 0ULL ] = X [ 106ULL ] ;
tlu2_linear_nearest_prelookup ( & s_efOut . mField0 [ 0ULL ] , & s_efOut .
mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t192 [ 0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = s_efOut ; t1100 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_nearest_prelookup
( & t_efOut . mField0 [ 0ULL ] , & t_efOut . mField1 [ 0ULL ] , & t_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [
0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = t_efOut ;
tlu2_2d_linear_nearest_value ( & u_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = u_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 = t1091_idx_0
; t1100 [ 0ULL ] = X [ 108ULL ] ; tlu2_linear_nearest_prelookup ( & v_efOut .
mField0 [ 0ULL ] , & v_efOut . mField1 [ 0ULL ] , & v_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139
[ 0ULL ] , & t140 [ 0ULL ] ) ; t88 = v_efOut ; t1100 [ 0ULL ] = X [ 104ULL ]
; tlu2_linear_nearest_prelookup ( & w_efOut . mField0 [ 0ULL ] , & w_efOut .
mField1 [ 0ULL ] , & w_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t125 = w_efOut ; tlu2_2d_linear_nearest_value ( & x_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , &
t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = x_efOut [
0 ] ; Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 = (
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 + t1091_idx_0
) / 2.0 ; Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 =
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
1697.0562748477141 / 0.7 ; t1100 [ 0ULL ] = X [ 115ULL ] ;
tlu2_linear_linear_prelookup ( & y_efOut . mField0 [ 0ULL ] , & y_efOut .
mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t88 = y_efOut ; t1100 [ 0ULL ] = X [ 111ULL ] ; tlu2_linear_linear_prelookup
( & ab_efOut . mField0 [ 0ULL ] , & ab_efOut . mField1 [ 0ULL ] , & ab_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [
0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t86 = ab_efOut ;
tlu2_2d_linear_linear_value ( & bb_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , & t86 . mField0 [ 0ULL ] , & t86 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = bb_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio1 = t1091_idx_0
; t1100 [ 0ULL ] = X [ 117ULL ] ; tlu2_linear_linear_prelookup ( & cb_efOut .
mField0 [ 0ULL ] , & cb_efOut . mField1 [ 0ULL ] , & cb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , &
t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = cb_efOut ; t1100 [ 0ULL ] = X [
113ULL ] ; tlu2_linear_linear_prelookup ( & db_efOut . mField0 [ 0ULL ] , &
db_efOut . mField1 [ 0ULL ] , & db_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t125 = db_efOut ; tlu2_2d_linear_linear_value ( &
eb_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t125 . mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = eb_efOut [ 0 ] ; t1403 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
115ULL ] ; tlu2_linear_nearest_prelookup ( & fb_efOut . mField0 [ 0ULL ] , &
fb_efOut . mField1 [ 0ULL ] , & fb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t74 = fb_efOut ; t1100 [ 0ULL ] = X [ 111ULL ] ;
tlu2_linear_nearest_prelookup ( & gb_efOut . mField0 [ 0ULL ] , & gb_efOut .
mField1 [ 0ULL ] , & gb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = gb_efOut ; tlu2_2d_linear_nearest_value ( & hb_efOut [ 0ULL ] , & t74
. mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t116 . mField0 [ 0ULL ] , &
t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField5 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hb_efOut
[ 0 ] ; Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 117ULL ] ; tlu2_linear_nearest_prelookup (
& ib_efOut . mField0 [ 0ULL ] , & ib_efOut . mField1 [ 0ULL ] , & ib_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [
0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t122 = ib_efOut ; t1100 [ 0ULL
] = X [ 113ULL ] ; tlu2_linear_nearest_prelookup ( & jb_efOut . mField0 [
0ULL ] , & jb_efOut . mField1 [ 0ULL ] , & jb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t88 = jb_efOut ; tlu2_2d_linear_nearest_value ( &
kb_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , &
t88 . mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField5 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = kb_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c = (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c + t1091_idx_0
) / 2.0 ; Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c =
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
1697.0562748477141 / 0.7 ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg = ( U_idx_2 - ( -
U_idx_2 ) ) / 2.0 ; t1100 [ 0ULL ] = ( X [ 6ULL ] + (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0 ? X [ 112ULL ]
: X [ 119ULL ] ) ) / 2.0 ; tlu2_linear_linear_prelookup ( & lb_efOut .
mField0 [ 0ULL ] , & lb_efOut . mField1 [ 0ULL ] , & lb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , &
t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t74 = lb_efOut ; t1100 [ 0ULL ] = ( X [
113ULL ] + X [ 120ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( & mb_efOut .
mField0 [ 0ULL ] , & mb_efOut . mField1 [ 0ULL ] , & mb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t109 = mb_efOut ;
tlu2_2d_linear_linear_value ( & nb_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , & t109 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = nb_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg = t1091_idx_0 ;
tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , & t109 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ob_efOut [ 0 ] ; t1407 =
t1091_idx_0 ; t1410 = (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0 ?
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg : -
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg ) * 0.01 ; t1411 =
t1091_idx_0 * 7.8539816339744827E-5 ; t1406 = t1410 / ( t1411 == 0.0 ?
1.0E-16 : t1411 ) ; t1409 = t1406 >= 2000.0 ? t1406 : 1.0 ; t1412 = pmf_log10
( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409 ) + 0.00017169489553429715
) * 3.24 ; t1411 = 1.0 / ( t1412 == 0.0 ? 1.0E-16 : t1412 ) ; t1414 = (
pmf_pow ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1411 / 8.0 ) * 12.7 + 1.0 ; t1408
= ( ( t1406 > 1000.0 ? t1406 : 1000.0 ) - 1000.0 ) * ( t1411 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg / ( t1414 == 0.0 ?
1.0E-16 : t1414 ) ; t1412 = ( t1406 - 2000.0 ) / 2000.0 ; t1413 = t1412 *
t1412 * 3.0 - t1412 * t1412 * t1412 * 2.0 ; if ( t1406 <= 2000.0 ) { t1412 =
3.66 ; } else if ( t1406 >= 4000.0 ) { t1412 = t1408 ; } else { t1412 = ( 1.0
- t1413 ) * 3.66 + t1408 * t1413 ; } t1408 = t1412 * 0.031415926535897927 / (
t1406 + 1.0 == 0.0 ? 1.0E-16 : t1406 + 1.0 ) / 7.8539816339744827E-5 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) ; t1412 =
pmf_sqrt ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) ; t1100 [ 0ULL ] = X
[ 123ULL ] ; tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , &
pb_efOut . mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = pb_efOut ; tlu2_2d_linear_linear_value ( &
qb_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t125 . mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = qb_efOut [ 0 ] ; t1413 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
125ULL ] ; tlu2_linear_linear_prelookup ( & rb_efOut . mField0 [ 0ULL ] , &
rb_efOut . mField1 [ 0ULL ] , & rb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = rb_efOut ; t1100 [ 0ULL ] = X [ 120ULL ] ;
tlu2_linear_linear_prelookup ( & sb_efOut . mField0 [ 0ULL ] , & sb_efOut .
mField1 [ 0ULL ] , & sb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t70 = sb_efOut ; tlu2_2d_linear_linear_value ( & tb_efOut [ 0ULL ] , & t116 .
mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , &
t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = tb_efOut
[ 0 ] ; t1414 = t1091_idx_0 ; t1100 [ 0ULL ] = X [ 6ULL ] ;
tlu2_linear_linear_prelookup ( & ub_efOut . mField0 [ 0ULL ] , & ub_efOut .
mField1 [ 0ULL ] , & ub_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t70 = ub_efOut ; tlu2_2d_linear_linear_value ( & vb_efOut [ 0ULL ] , & t70 .
mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , &
t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = vb_efOut
[ 0 ] ; t1415 = t1091_idx_0 ; tlu2_2d_linear_linear_value ( & wb_efOut [ 0ULL
] , & t70 . mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , & t109 . mField0 [
0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField7 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0
= wb_efOut [ 0 ] ; t1416 = t1091_idx_0 ; t1100 [ 0ULL ] = ( X [ 9ULL ] + (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0 ? X [ 94ULL ] :
X [ 101ULL ] ) ) / 2.0 ; tlu2_linear_linear_prelookup ( & xb_efOut . mField0
[ 0ULL ] , & xb_efOut . mField1 [ 0ULL ] , & xb_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL
] , & t140 [ 0ULL ] ) ; t116 = xb_efOut ; t1100 [ 0ULL ] = ( X [ 95ULL ] + X
[ 102ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( & yb_efOut . mField0 [
0ULL ] , & yb_efOut . mField1 [ 0ULL ] , & yb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t74 = yb_efOut ; tlu2_2d_linear_linear_value ( &
ac_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t74 . mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField6 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = ac_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg = t1091_idx_0 ;
tlu2_2d_linear_linear_value ( & bc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = bc_efOut [ 0 ] ; t1418 =
t1091_idx_0 ; t1423 = t1091_idx_0 * 7.8539816339744827E-5 ; t1419 = t1410 / (
t1423 == 0.0 ? 1.0E-16 : t1423 ) ; t1421 = t1419 >= 2000.0 ? t1419 : 1.0 ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 = pmf_log10 (
6.9 / ( t1421 == 0.0 ? 1.0E-16 : t1421 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1421 == 0.0 ? 1.0E-16 : t1421 ) + 0.00017169489553429715
) * 3.24 ; t1423 = 1.0 / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 == 0.0 ?
1.0E-16 : Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 ) ;
t1426 = ( pmf_pow (
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1423 / 8.0 ) * 12.7 + 1.0 ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU = ( ( t1419 > 1000.0
? t1419 : 1000.0 ) - 1000.0 ) * ( t1423 / 8.0 ) *
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg / ( t1426 == 0.0 ?
1.0E-16 : t1426 ) ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 = ( t1419 -
2000.0 ) / 2000.0 ; t1425 =
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 *
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 * 3.0 -
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 *
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 *
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 * 2.0 ; if (
t1419 <= 2000.0 ) {
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 = 3.66 ; }
else if ( t1419 >= 4000.0 ) {
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 =
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU ; } else {
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 = ( 1.0 -
t1425 ) * 3.66 + Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU *
t1425 ; } Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU =
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 *
0.031415926535897927 / ( t1419 + 1.0 == 0.0 ? 1.0E-16 : t1419 + 1.0 ) /
7.8539816339744827E-5 / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg ) ; t1100 [ 0ULL ]
= X [ 128ULL ] ; tlu2_linear_linear_prelookup ( & cc_efOut . mField0 [ 0ULL ]
, & cc_efOut . mField1 [ 0ULL ] , & cc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t109 = cc_efOut ; tlu2_2d_linear_linear_value ( &
dc_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , &
t87 . mField0 [ 0ULL ] , & t87 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = dc_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 = t1091_idx_0
; t1100 [ 0ULL ] = X [ 130ULL ] ; tlu2_linear_linear_prelookup ( & ec_efOut .
mField0 [ 0ULL ] , & ec_efOut . mField1 [ 0ULL ] , & ec_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , &
t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t125 = ec_efOut ;
tlu2_2d_linear_linear_value ( & fc_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL ]
, & t125 . mField2 [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = fc_efOut [ 0 ] ; t1425 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 9ULL ] ; tlu2_linear_linear_prelookup ( &
gc_efOut . mField0 [ 0ULL ] , & gc_efOut . mField1 [ 0ULL ] , & gc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [
0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = gc_efOut ;
tlu2_2d_linear_linear_value ( & hc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hc_efOut [ 0 ] ; t1426 =
t1091_idx_0 ; tlu2_2d_linear_linear_value ( & ic_efOut [ 0ULL ] , & t116 .
mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , &
t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ic_efOut
[ 0 ] ; t1427 = t1091_idx_0 ; t1100 [ 0ULL ] = ( X [ 11ULL ] + (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0 ? X [ 103ULL ]
: X [ 110ULL ] ) ) / 2.0 ; tlu2_linear_linear_prelookup ( & jc_efOut .
mField0 [ 0ULL ] , & jc_efOut . mField1 [ 0ULL ] , & jc_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , &
t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = jc_efOut ; t1100 [ 0ULL ] = ( X [
104ULL ] + X [ 111ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( & kc_efOut .
mField0 [ 0ULL ] , & kc_efOut . mField1 [ 0ULL ] , & kc_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t74 = kc_efOut ;
tlu2_2d_linear_linear_value ( & lc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = lc_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg = t1091_idx_0 ;
tlu2_2d_linear_linear_value ( & mc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = mc_efOut [ 0 ] ; t1428 =
t1091_idx_0 ; t1435 = t1091_idx_0 * 7.8539816339744827E-5 ; t1429 = t1410 / (
t1435 == 0.0 ? 1.0E-16 : t1435 ) ; t1430 = t1429 >= 2000.0 ? t1429 : 1.0 ;
t1436 = pmf_log10 ( 6.9 / ( t1430 == 0.0 ? 1.0E-16 : t1430 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1430 == 0.0 ? 1.0E-16 : t1430
) + 0.00017169489553429715 ) * 3.24 ; t1431 = 1.0 / ( t1436 == 0.0 ? 1.0E-16
: t1436 ) ; t1438 = ( pmf_pow (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg , 0.66666666666666663
) - 1.0 ) * pmf_sqrt ( t1431 / 8.0 ) * 12.7 + 1.0 ; t1410 = ( ( t1429 >
1000.0 ? t1429 : 1000.0 ) - 1000.0 ) * ( t1431 / 8.0 ) *
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg / ( t1438 == 0.0 ?
1.0E-16 : t1438 ) ; t1432 = ( t1429 - 2000.0 ) / 2000.0 ; t1433 = t1432 *
t1432 * 3.0 - t1432 * t1432 * t1432 * 2.0 ; if ( t1429 <= 2000.0 ) { t1432 =
3.66 ; } else if ( t1429 >= 4000.0 ) { t1432 = t1410 ; } else { t1432 = ( 1.0
- t1433 ) * 3.66 + t1410 * t1433 ; } t1410 = t1432 * 0.031415926535897927 / (
t1429 + 1.0 == 0.0 ? 1.0E-16 : t1429 + 1.0 ) / 7.8539816339744827E-5 / (
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg ) ; t1100 [ 0ULL ] = X
[ 133ULL ] ; tlu2_linear_linear_prelookup ( & nc_efOut . mField0 [ 0ULL ] , &
nc_efOut . mField1 [ 0ULL ] , & nc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = nc_efOut ; tlu2_2d_linear_linear_value ( &
oc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = oc_efOut [ 0 ] ; t1432 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
135ULL ] ; tlu2_linear_linear_prelookup ( & pc_efOut . mField0 [ 0ULL ] , &
pc_efOut . mField1 [ 0ULL ] , & pc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = pc_efOut ; tlu2_2d_linear_linear_value ( &
qc_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , &
t86 . mField0 [ 0ULL ] , & t86 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = qc_efOut [ 0 ] ; t1433 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
11ULL ] ; tlu2_linear_linear_prelookup ( & rc_efOut . mField0 [ 0ULL ] , &
rc_efOut . mField1 [ 0ULL ] , & rc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t125 = rc_efOut ; tlu2_2d_linear_linear_value ( &
sc_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , &
t74 . mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = sc_efOut [ 0 ] ; t1435 = t1091_idx_0 ;
tlu2_2d_linear_linear_value ( & tc_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL ]
, & t125 . mField2 [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t139 [ 0ULL ] , &
t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = tc_efOut [ 0 ] ; t1436 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 140ULL ] ; tlu2_linear_linear_prelookup (
& uc_efOut . mField0 [ 0ULL ] , & uc_efOut . mField1 [ 0ULL ] , & uc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [
0ULL ] , & t139 [ 0ULL ] , & t140 [ 0ULL ] ) ; t74 = uc_efOut ; t1100 [ 0ULL
] = X [ 138ULL ] ; tlu2_linear_linear_prelookup ( & vc_efOut . mField0 [ 0ULL
] , & vc_efOut . mField1 [ 0ULL ] , & vc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t116 = vc_efOut ; tlu2_2d_linear_linear_value ( &
wc_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = wc_efOut [ 0 ] ; t1437 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
142ULL ] ; tlu2_linear_linear_prelookup ( & xc_efOut . mField0 [ 0ULL ] , &
xc_efOut . mField1 [ 0ULL ] , & xc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t86 = xc_efOut ; tlu2_2d_linear_linear_value ( &
yc_efOut [ 0ULL ] , & t86 . mField0 [ 0ULL ] , & t86 . mField2 [ 0ULL ] , &
t123 . mField0 [ 0ULL ] , & t123 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField1 , & t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = yc_efOut [ 0 ] ; t1438 = t1091_idx_0 ; t1439 = ( t1437 +
t1091_idx_0 ) / 2.0 ; t1440 = X [ 146ULL ] >= 1.0 ? X [ 146ULL ] : 1.0 ;
t1441 = pmf_sqrt ( t1440 * 402.5245441795231 ) ; if ( X [ 146ULL ] >= 1.0 ) {
t1442 = pmf_log ( X [ 146ULL ] ) ; } else { t1442 = X [ 146ULL ] - 1.0 ; } if
( X [ 147ULL ] / 1.0E-5 >= 1.0 ) { t1443 = pmf_log ( X [ 147ULL ] / 1.0E-5 )
; } else { t1443 = X [ 147ULL ] / 1.0E-5 - 1.0 ; } t1444 = pmf_exp ( ( t1443
- 5.65948221575962 ) - t1442 ) ; t1446 = t1441 * t1444 * 1.0E-6 ; t1441 =
pmf_sqrt ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 ) ; t1447 = X [ 148ULL
] >= 1.0 ? X [ 148ULL ] : 1.0 ;
Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 = pmf_sqrt (
t1447 * 402.5245441795231 ) ; if ( X [ 148ULL ] >= 1.0 ) { intrm_sf_mf_71 =
pmf_log ( X [ 148ULL ] ) ; } else { intrm_sf_mf_71 = X [ 148ULL ] - 1.0 ; }
if ( X [ 149ULL ] / 1.0E-5 >= 1.0 ) { intrm_sf_mf_72 = pmf_log ( X [ 149ULL ]
/ 1.0E-5 ) ; } else { intrm_sf_mf_72 = X [ 149ULL ] / 1.0E-5 - 1.0 ; } t1449
= pmf_exp ( ( intrm_sf_mf_72 - 5.65948221575962 ) - intrm_sf_mf_71 ) ; t1450
= Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 * t1449 *
1.0E-6 ; Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 =
pmf_sqrt ( X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 ) ; if ( X [ 151ULL ]
>= 1.0 ) { intrm_sf_mf_73 = pmf_log ( X [ 151ULL ] ) ; } else {
intrm_sf_mf_73 = X [ 151ULL ] - 1.0 ; }
Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_A = pmf_exp ( ( t1443 -
5.65948221575962 ) - intrm_sf_mf_73 ) ; if ( X [ 152ULL ] >= 1.0 ) {
intrm_sf_mf_74 = pmf_log ( X [ 152ULL ] ) ; } else { intrm_sf_mf_74 = X [
152ULL ] - 1.0 ; } Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_B =
pmf_exp ( ( intrm_sf_mf_72 - 5.65948221575962 ) - intrm_sf_mf_74 ) ; if ( X [
191ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = X [
191ULL ] >= 1.0 ? 1.0 : X [ 191ULL ] ; } if ( X [ 192ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = X [
192ULL ] >= 1.0 ? 1.0 : X [ 192ULL ] ; } intrm_sf_mf_83 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
4124.48151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = - X [
198ULL ] + U_idx_4 * - 0.01 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 = X [
24ULL ] >= 1.0 ? 1.0 : X [ 24ULL ] ; } intrm_sf_mf_95 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 *
4124.48151675695 ; t1454 = ( X [ 21ULL ] / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X
[ 22ULL ] ) - X [ 199ULL ] / ( X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] )
) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intrm_sf_mf_95 / 7.8539816339744827E-5 ; if ( X [ 199ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
199ULL ] >= 623.15 ? 623.15 : X [ 199ULL ] ; } t1308 = t1303 * t1303 ;
intrm_sf_mf_99 = ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) +
t1308 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1308 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) + ( (
12825.281119789837 + t1303 * 6.9647057412840034 ) + t1308 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ; t1456 =
intrm_sf_mf_99 - intrm_sf_mf_95 ; t1308 = intrm_sf_mf_99 / ( t1456 == 0.0 ?
1.0E-16 : t1456 ) ; t1456 = pmf_sqrt ( t1454 * t1454 * 9.999999999999999E-14
+ fabs ( X [ 199ULL ] * t1308 * intrm_sf_mf_95 ) * 1.0E-9 ) ; if ( X [ 201ULL
] <= 0.0 ) { intrm_sf_mf_172 = 0.0 ; } else { intrm_sf_mf_172 = X [ 201ULL ]
>= 1.0 ? 1.0 : X [ 201ULL ] ; } if ( X [ 202ULL ] <= 0.0 ) { intrm_sf_mf_148
= 0.0 ; } else { intrm_sf_mf_148 = X [ 202ULL ] >= 1.0 ? 1.0 : X [ 202ULL ] ;
} t1100 [ 0ULL ] = X [ 21ULL ] ; t364 [ 0 ] = 52ULL ;
tlu2_linear_nearest_prelookup ( & ad_efOut . mField0 [ 0ULL ] , & ad_efOut .
mField1 [ 0ULL ] , & ad_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t14 = ad_efOut ; tlu2_1d_linear_nearest_value ( & bd_efOut [ 0ULL ] , & t14 .
mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = bd_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & cd_efOut [ 0ULL ] , & t14 . mField0
[ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = cd_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & dd_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL
] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = dd_efOut [ 0 ] ;
intrm_sf_mf_102 = ( ( ( 1.0 - intrm_sf_mf_172 ) - intrm_sf_mf_148 ) *
t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_172 ) + t1096_idx_0 * intrm_sf_mf_148
; t1457 = X [ 200ULL ] * X [ 200ULL ] * t1308 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 = - pmf_sqrt
( fabs ( t1457 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [
199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) * 7.8539816339744827E-5 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 >= 0.0 ) {
t1458 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 *
100000.0 ; } else { t1458 = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 * 100000.0 ;
} t1461 = intrm_sf_mf_102 * 7.8539816339744827E-5 ; t1303 = t1458 * 0.01 / (
t1461 == 0.0 ? 1.0E-16 : t1461 ) ; t1463 = X [ 21ULL ] * intrm_sf_mf_95 ;
t1460 = X [ 22ULL ] / ( t1463 == 0.0 ? 1.0E-16 : t1463 ) ; t1465 = t1460 *
1.5707963267948965E-8 ; t1463 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 *
intrm_sf_mf_102 * 35.2 / ( t1465 == 0.0 ? 1.0E-16 : t1465 ) ; t1464 = t1303
>= 1.0 ? t1303 : 1.0 ; t1091_idx_0 = pmf_log10 ( 6.9 / ( t1464 == 0.0 ?
1.0E-16 : t1464 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1464 ==
0.0 ? 1.0E-16 : t1464 ) + 0.00017169489553429715 ) * 3.24 ; t1468 = t1460 *
1.2337005501361697E-10 ; t1458 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 * t1458 * (
1.0 / ( t1091_idx_0 == 0.0 ? 1.0E-16 : t1091_idx_0 ) ) * 0.55 / ( t1468 ==
0.0 ? 1.0E-16 : t1468 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = ( t1303 -
2000.0 ) / 2000.0 ; t1091_idx_0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 * 2.0 ; if (
t1303 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = t1463 *
1.0E-5 ; } else if ( t1303 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = t1458 *
1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = ( ( 1.0 -
t1091_idx_0 ) * t1463 + t1458 * t1091_idx_0 ) * 1.0E-5 ; } t1456 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * t1456 /
7.8539816339744827E-5 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ; t1458 = - (
( X [ 21ULL ] / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) - X [ 203ULL ]
/ ( X [ 204ULL ] == 0.0 ? 1.0E-16 : X [ 204ULL ] ) ) * X [ 186ULL ] *
intrm_sf_mf_95 ) / 7.8539816339744827E-5 ; if ( X [ 203ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
203ULL ] >= 623.15 ? 623.15 : X [ 203ULL ] ; } t1451 = t1303 * t1303 ; t1463
= ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1451 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1451 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ) + ( (
12825.281119789837 + t1303 * 6.9647057412840034 ) + t1451 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 ; t1303 =
t1463 - intrm_sf_mf_95 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 = t1463 / (
t1303 == 0.0 ? 1.0E-16 : t1303 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 = pmf_sqrt (
t1458 * t1458 * 9.999999999999999E-14 + fabs ( X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 ) ; t1477 = X [ 204ULL ] * X [ 204ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = - pmf_sqrt
( fabs ( t1477 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [
203ULL ] == 0.0 ? 1.0E-16 : X [ 203ULL ] ) ) ) * 7.8539816339744827E-5 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 >= 0.0 ) {
t1091_idx_0 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1
* 100000.0 ; } else { t1091_idx_0 = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 * 100000.0 ;
} t1451 = t1091_idx_0 * 0.01 / ( t1461 == 0.0 ? 1.0E-16 : t1461 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 *
intrm_sf_mf_102 * 35.2 / ( t1465 == 0.0 ? 1.0E-16 : t1465 ) ; t1465 = t1451
>= 1.0 ? t1451 : 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = pmf_log10 (
6.9 / ( t1465 == 0.0 ? 1.0E-16 : t1465 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1465 == 0.0 ? 1.0E-16 : t1465 ) + 0.00017169489553429715
) * 3.24 ; t1091_idx_0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 * t1091_idx_0
* ( 1.0 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) ) * 0.55 / (
t1468 == 0.0 ? 1.0E-16 : t1468 ) ; t1467 = ( t1451 - 2000.0 ) / 2000.0 ;
t1468 = t1467 * t1467 * 3.0 - t1467 * t1467 * t1467 * 2.0 ; if ( t1451 <=
2000.0 ) { t1467 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ * 1.0E-5 ; }
else if ( t1451 >= 4000.0 ) { t1467 = t1091_idx_0 * 1.0E-5 ; } else { t1467 =
( ( 1.0 - t1468 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ + t1091_idx_0
* t1468 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 = - ( X [
186ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 )
/ 7.8539816339744827E-5 * 0.00031622776601683789 + t1467 ; if ( 1.0 - X [
23ULL ] >= 0.01 ) { t1451 = 1.0 - X [ 23ULL ] ; } else if ( 1.0 - X [ 23ULL ]
>= - 0.1 ) { t1451 = pmf_exp ( ( ( 1.0 - X [ 23ULL ] ) - 0.01 ) / 0.01 ) *
0.01 ; } else { t1451 = 1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ = X [ 24ULL ]
/ ( t1451 == 0.0 ? 1.0E-16 : t1451 ) * 3827.6794129126583 + 296.802103844292
; t1100 [ 0ULL ] = X [ 21ULL ] ; tlu2_linear_linear_prelookup ( & ed_efOut .
mField0 [ 0ULL ] , & ed_efOut . mField1 [ 0ULL ] , & ed_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t128 = ed_efOut ;
tlu2_1d_linear_linear_value ( & fd_efOut [ 0ULL ] , & t128 . mField0 [ 0ULL ]
, & t128 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t168 [ 0 ] = fd_efOut [ 0 ] ; t1467 =
pmf_exp ( pmf_log ( X [ 22ULL ] * 100000.0 ) - t168 [ 0ULL ] ) ; if ( t1467
>= 1.0 ) { t1491 = ( t1467 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ ; t1468 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ / ( t1491 ==
0.0 ? 1.0E-16 : t1491 ) ; } else { t1468 = 1.0 ; } if ( X [ 178ULL ] <= 0.0 )
{ t1469 = 0.0 ; } else { t1469 = X [ 178ULL ] >= 1.0 ? 1.0 : X [ 178ULL ] ; }
if ( X [ 177ULL ] <= 0.0 ) { t1470 = 0.0 ; } else { t1470 = X [ 177ULL ] >=
1.0 ? 1.0 : X [ 177ULL ] ; } t1474 = ( ( ( 1.0 - t1469 ) - t1470 ) *
296.802103844292 + t1469 * 461.523 ) + t1470 * 4124.48151675695 ; t1469 = X [
178ULL ] * 461.523 / ( t1474 == 0.0 ? 1.0E-16 : t1474 ) ; if ( t1469 <= 0.0 )
{ t1470 = 0.0 ; } else { t1470 = t1469 >= 1.0 ? 1.0 : t1469 ; } t1469 = X [
177ULL ] * 4124.48151675695 / ( t1474 == 0.0 ? 1.0E-16 : t1474 ) ; if ( t1469
<= 0.0 ) { t1475 = 0.0 ; } else { t1475 = t1469 >= 1.0 ? 1.0 : t1469 ; }
t1100 [ 0ULL ] = X [ 175ULL ] ; tlu2_linear_nearest_prelookup ( & gd_efOut .
mField0 [ 0ULL ] , & gd_efOut . mField1 [ 0ULL ] , & gd_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = gd_efOut ;
tlu2_1d_linear_nearest_value ( & hd_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & id_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = id_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jd_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = jd_efOut [ 0 ] ; t1469
= ( ( ( 1.0 - t1470 ) - t1475 ) * t1091_idx_0 + t1098_idx_0 * t1470 ) +
t1096_idx_0 * t1475 ; tlu2_1d_linear_nearest_value ( & kd_efOut [ 0ULL ] , &
t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
kd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ld_efOut [ 0ULL ] , & t14 .
mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = ld_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & md_efOut [ 0ULL ] , & t14 . mField0
[ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = md_efOut [ 0 ]
; t1303 = ( ( ( 1.0 - intrm_sf_mf_172 ) - intrm_sf_mf_148 ) * t1091_idx_0 +
t1098_idx_0 * intrm_sf_mf_172 ) + t1096_idx_0 * intrm_sf_mf_148 ;
intrm_sf_mf_172 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 - ( - X [
186ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & nd_efOut [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
nd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & od_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
od_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & pd_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
pd_efOut [ 0 ] ; t1478 = ( ( ( 1.0 - t1470 ) - t1475 ) * t1091_idx_0 +
t1098_idx_0 * t1470 ) + t1096_idx_0 * t1475 ; t1495 = intrm_sf_mf_102 + t1478
; t1091_idx_0 = t1495 / 2.0 * 7.8539816339744827E-5 ; intrm_sf_mf_148 = (
intrm_sf_mf_172 >= 0.0 ? intrm_sf_mf_172 : 0.0 ) * 0.01 / ( t1091_idx_0 ==
0.0 ? 1.0E-16 : t1091_idx_0 ) ; t1470 = intrm_sf_mf_148 >= 0.0 ?
intrm_sf_mf_148 : - intrm_sf_mf_148 ; intrm_sf_mf_148 = t1470 > 1000.0 ?
t1470 : 1000.0 ; t1498 = t1469 + t1303 ; if ( t1498 / 2.0 > 0.5 ) { t1475 = (
t1469 + t1303 ) / 2.0 ; } else { t1475 = 0.5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 = pmf_log10 (
6.9 / ( intrm_sf_mf_148 == 0.0 ? 1.0E-16 : intrm_sf_mf_148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_148 == 0.0 ?
1.0E-16 : intrm_sf_mf_148 ) + 0.00017169489553429715 ) * 3.24 ; t1480 = 1.0 /
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) ;
intrm_sf_mf_270 = ( pmf_pow ( t1475 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1480 / 8.0 ) * 12.7 + 1.0 ; t1482 = ( intrm_sf_mf_148 - 1000.0 )
* ( t1480 / 8.0 ) * t1475 / ( intrm_sf_mf_270 == 0.0 ? 1.0E-16 :
intrm_sf_mf_270 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( t1470 -
2000.0 ) / 2000.0 ; intrm_sf_mf_171 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ; if (
t1470 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 3.66 ; }
else if ( t1470 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = t1482 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.0
- intrm_sf_mf_171 ) * 3.66 + t1482 * intrm_sf_mf_171 ; } t1504 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
0.031415926535897927 ; t1507 = t1498 / 2.0 ; if ( t1470 > t1504 /
7.8539816339744827E-5 / ( t1507 == 0.0 ? 1.0E-16 : t1507 ) / 30.0 ) { t1513 =
( t1469 + t1303 ) / 2.0 ; t1482 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
0.031415926535897927 / ( t1470 == 0.0 ? 1.0E-16 : t1470 ) /
7.8539816339744827E-5 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ; } else { t1482 =
30.0 ; } if ( X [ 197ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 197ULL
] >= 1.0 ? 1.0 : X [ 197ULL ] ; } if ( X [ 196ULL ] <= 0.0 ) {
intrm_sf_mf_171 = 0.0 ; } else { intrm_sf_mf_171 = X [ 196ULL ] >= 1.0 ? 1.0
: X [ 196ULL ] ; } t1487 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) -
intrm_sf_mf_171 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 461.523 ) +
intrm_sf_mf_171 * 4124.48151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 197ULL ]
* 461.523 / ( t1487 == 0.0 ? 1.0E-16 : t1487 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 <= 0.0 ) {
intrm_sf_mf_171 = 0.0 ; } else { intrm_sf_mf_171 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 >= 1.0 ? 1.0 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 196ULL ]
* 4124.48151675695 / ( t1487 == 0.0 ? 1.0E-16 : t1487 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 <= 0.0 ) {
t1488 = 0.0 ; } else { t1488 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 >= 1.0 ? 1.0 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } t1100 [
0ULL ] = X [ 194ULL ] ; tlu2_linear_nearest_prelookup ( & qd_efOut . mField0
[ 0ULL ] , & qd_efOut . mField1 [ 0ULL ] , & qd_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [
0ULL ] , & t140 [ 0ULL ] ) ; t122 = qd_efOut ; tlu2_1d_linear_nearest_value (
& rd_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [
0ULL ] ) ; t1091_idx_0 = rd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
sd_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1098_idx_0 = sd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
td_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1096_idx_0 = td_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( ( ( 1.0 -
intrm_sf_mf_171 ) - t1488 ) * t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_171 ) +
t1096_idx_0 * t1488 ; tlu2_1d_linear_nearest_value ( & ud_efOut [ 0ULL ] , &
t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
ud_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & vd_efOut [ 0ULL ] , & t122
. mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
vd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & wd_efOut [ 0ULL ] , & t122
. mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
wd_efOut [ 0 ] ; t1516 = intrm_sf_mf_102 + ( ( ( ( 1.0 - intrm_sf_mf_171 ) -
t1488 ) * t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_171 ) + t1096_idx_0 * t1488
) ; intrm_sf_mf_290 = t1516 / 2.0 * 7.8539816339744827E-5 ; intrm_sf_mf_172 =
- ( intrm_sf_mf_172 <= 0.0 ? intrm_sf_mf_172 : 0.0 ) * 0.01 / (
intrm_sf_mf_290 == 0.0 ? 1.0E-16 : intrm_sf_mf_290 ) ; intrm_sf_mf_171 =
intrm_sf_mf_172 >= 0.0 ? intrm_sf_mf_172 : - intrm_sf_mf_172 ;
intrm_sf_mf_172 = intrm_sf_mf_171 > 1000.0 ? intrm_sf_mf_171 : 1000.0 ; t1519
= t1303 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; if
( t1519 / 2.0 > 0.5 ) { t1488 = ( t1303 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) / 2.0 ; }
else { t1488 = 0.5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 = pmf_log10 (
6.9 / ( intrm_sf_mf_172 == 0.0 ? 1.0E-16 : intrm_sf_mf_172 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_172 == 0.0 ?
1.0E-16 : intrm_sf_mf_172 ) + 0.00017169489553429715 ) * 3.24 ; t1489 = 1.0 /
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 ) ;
t1523 = ( pmf_pow ( t1488 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1489
/ 8.0 ) * 12.7 + 1.0 ; intrm_sf_mf_179 = ( intrm_sf_mf_172 - 1000.0 ) * (
t1489 / 8.0 ) * t1488 / ( t1523 == 0.0 ? 1.0E-16 : t1523 ) ; t1491 = (
intrm_sf_mf_171 - 2000.0 ) / 2000.0 ; t1492 = t1491 * t1491 * 3.0 - t1491 *
t1491 * t1491 * 2.0 ; if ( intrm_sf_mf_171 <= 2000.0 ) { t1491 = 3.66 ; }
else if ( intrm_sf_mf_171 >= 4000.0 ) { t1491 = intrm_sf_mf_179 ; } else {
t1491 = ( 1.0 - t1492 ) * 3.66 + intrm_sf_mf_179 * t1492 ; } t1525 = t1491 *
0.031415926535897927 ; t1528 = t1519 / 2.0 ; if ( intrm_sf_mf_171 > t1525 /
7.8539816339744827E-5 / ( t1528 == 0.0 ? 1.0E-16 : t1528 ) / 30.0 ) { t1303 =
( t1303 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) /
2.0 ; intrm_sf_mf_179 = t1491 * 0.031415926535897927 / ( intrm_sf_mf_171 ==
0.0 ? 1.0E-16 : intrm_sf_mf_171 ) / 7.8539816339744827E-5 / ( t1303 == 0.0 ?
1.0E-16 : t1303 ) ; } else { intrm_sf_mf_179 = 30.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = U_idx_3 *
0.031415926535897927 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 <=
7.8539816339744857E-13 ) { t1491 = 7.8539816339744857E-13 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 >=
3.1415926535897929E-6 ) { t1491 = 3.1415926535897929E-6 ; } else { t1491 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = t1491 /
7.8539816339744827E-5 ; if ( X [ 221ULL ] <= 0.0 ) { t1492 = 0.0 ; } else {
t1492 = X [ 221ULL ] >= 1.0 ? 1.0 : X [ 221ULL ] ; } if ( X [ 222ULL ] <= 0.0
) { t1493 = 0.0 ; } else { t1493 = X [ 222ULL ] >= 1.0 ? 1.0 : X [ 222ULL ] ;
} t1494 = ( ( ( 1.0 - t1492 ) - t1493 ) * 296.802103844292 + t1492 * 461.523
) + t1493 * 4124.48151675695 ; t1536 = X [ 219ULL ] * t1494 ; t1496 = X [
220ULL ] / ( t1536 == 0.0 ? 1.0E-16 : t1536 ) ; t1091_idx_0 = X [ 220ULL ] /
( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [
219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; intrm_sf_mf_249 = X [ 220ULL ]
/ 1.01325 * ( X [ 224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] )
) ; t1501 = ( X [ 195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) ;
intrm_sf_mf_270 = t1501 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ; t1503 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
t1091_idx_0 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
intrm_sf_mf_249 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ; t1303
= ( X [ 195ULL ] - 1.01325 ) * ( t1503 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ? t1503 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) ; t1503 = ( X
[ 195ULL ] - 1.01325 ) / ( t1501 == 0.0 ? 1.0E-16 : t1501 ) ; t1507 = t1503 *
t1503 * 3.0 - t1503 * t1503 * t1503 * 2.0 ; if ( X [ 195ULL ] - 1.01325 <=
0.0 ) { t1503 = intrm_sf_mf_270 ; } else if ( X [ 195ULL ] - 1.01325 >= t1501
) { t1503 = t1303 ; } else { t1503 = ( 1.0 - t1507 ) * intrm_sf_mf_270 +
t1303 * t1507 ; } t1303 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
intrm_sf_mf_249 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t1091_idx_0
) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.01325 -
X [ 195ULL ] ) * ( t1303 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ? t1303 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) ; t1091_idx_0
= ( 1.01325 - X [ 195ULL ] ) / ( t1501 == 0.0 ? 1.0E-16 : t1501 ) ;
intrm_sf_mf_249 = t1091_idx_0 * t1091_idx_0 * 3.0 - t1091_idx_0 * t1091_idx_0
* t1091_idx_0 * 2.0 ; if ( 1.01325 - X [ 195ULL ] <= 0.0 ) { t1091_idx_0 =
intrm_sf_mf_270 ; } else if ( 1.01325 - X [ 195ULL ] >= t1501 ) { t1091_idx_0
= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } else {
t1091_idx_0 = ( 1.0 - intrm_sf_mf_249 ) * intrm_sf_mf_270 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
intrm_sf_mf_249 ; } if ( X [ 195ULL ] > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = t1503 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [
195ULL ] < 1.01325 ? t1091_idx_0 : intrm_sf_mf_270 ; } if ( X [ 219ULL ] <=
216.59999999999997 ) { t1091_idx_0 = 216.59999999999997 ; } else {
t1091_idx_0 = X [ 219ULL ] >= 623.15 ? 623.15 : X [ 219ULL ] ; } t1508 =
t1091_idx_0 * t1091_idx_0 ; intrm_sf_mf_249 = ( ( ( 1074.1165326382554 +
t1091_idx_0 * - 0.22145652610641059 ) + t1508 * 0.0003721298010901061 ) * ( (
1.0 - t1492 ) - t1493 ) + ( ( 1479.6504774710402 + t1091_idx_0 *
1.2002114337050787 ) + t1508 * - 0.00038614513167845434 ) * t1492 ) + ( (
12825.281119789837 + t1091_idx_0 * 6.9647057412840034 ) + t1508 * -
0.0070524868246844051 ) * t1493 ; t1547 = intrm_sf_mf_249 - t1494 ; t1548 = X
[ 220ULL ] * X [ 220ULL ] * ( intrm_sf_mf_249 / ( t1547 == 0.0 ? 1.0E-16 :
t1547 ) ) ; t1492 = pmf_sqrt ( fabs ( t1548 / ( t1494 == 0.0 ? 1.0E-16 :
t1494 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) * t1491 * 0.64
; if ( X [ 27ULL ] <= 0.0 ) { t1493 = 0.0 ; } else { t1493 = X [ 27ULL ] >=
1.0 ? 1.0 : X [ 27ULL ] ; } if ( X [ 26ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 = X [ 26ULL ]
>= 1.0 ? 1.0 : X [ 26ULL ] ; } intrm_sf_mf_270 = ( ( ( 1.0 - t1493 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) *
296.802103844292 + t1493 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 *
4124.48151675695 ; t1503 = ( X [ 25ULL ] / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X
[ 31ULL ] ) - X [ 245ULL ] / ( X [ 246ULL ] == 0.0 ? 1.0E-16 : X [ 246ULL ] )
) * X [ 244ULL ] * intrm_sf_mf_270 / 0.44 ; if ( X [ 245ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
245ULL ] >= 623.15 ? 623.15 : X [ 245ULL ] ; } t1333 = t1303 * t1303 ; t1507
= ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1333 *
0.0003721298010901061 ) * ( ( 1.0 - t1493 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1333 * -
0.00038614513167845434 ) * t1493 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1333 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ; t1303 = t1507
- intrm_sf_mf_270 ; t1508 = t1507 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ;
t1333 = pmf_sqrt ( t1503 * t1503 * 9.999999999999999E-14 + fabs ( X [ 245ULL
] * t1508 * intrm_sf_mf_270 ) * 1.0E-9 ) ; if ( X [ 232ULL ] <= 0.0 ) { t1511
= 0.0 ; } else { t1511 = X [ 232ULL ] >= 1.0 ? 1.0 : X [ 232ULL ] ; } if ( X
[ 234ULL ] <= 0.0 ) { t1510 = 0.0 ; } else { t1510 = X [ 234ULL ] >= 1.0 ?
1.0 : X [ 234ULL ] ; } t1100 [ 0ULL ] = X [ 25ULL ] ;
tlu2_linear_nearest_prelookup ( & xd_efOut . mField0 [ 0ULL ] , & xd_efOut .
mField1 [ 0ULL ] , & xd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = xd_efOut ; tlu2_1d_linear_nearest_value ( & yd_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = yd_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & ae_efOut [ 0ULL ] , & t74 . mField0
[ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = ae_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & be_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL
] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = be_efOut [ 0 ] ; t1512
= ( ( ( 1.0 - t1511 ) - t1510 ) * t1091_idx_0 + t1098_idx_0 * t1511 ) +
t1096_idx_0 * t1510 ; t1557 = X [ 246ULL ] * X [ 246ULL ] * t1508 ; t1513 = -
pmf_sqrt ( fabs ( t1557 / ( intrm_sf_mf_270 == 0.0 ? 1.0E-16 :
intrm_sf_mf_270 ) / ( X [ 245ULL ] == 0.0 ? 1.0E-16 : X [ 245ULL ] ) ) ) *
0.44 ; if ( t1513 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 = t1513 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 = - t1513 *
100000.0 ; } t1561 = t1512 * 0.44 ; t1303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 * 0.01 / (
t1561 == 0.0 ? 1.0E-16 : t1561 ) ; t1563 = X [ 25ULL ] * intrm_sf_mf_270 ;
t1517 = X [ 31ULL ] / ( t1563 == 0.0 ? 1.0E-16 : t1563 ) ; t1565 = t1517 *
8.8000000000000011E-5 ; intrm_sf_mf_290 = t1513 * t1512 * 2.9973120849090416
/ ( t1565 == 0.0 ? 1.0E-16 : t1565 ) ; t1520 = t1303 >= 1.0 ? t1303 : 1.0 ;
t1566 = pmf_log10 ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520
) + 0.00017169489553429715 ) * 3.24 ; t1568 = t1517 * 0.003872 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 = t1513 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 * ( 1.0 / (
t1566 == 0.0 ? 1.0E-16 : t1566 ) ) * 0.046833001326703774 / ( t1568 == 0.0 ?
1.0E-16 : t1568 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 = ( t1303 -
2000.0 ) / 2000.0 ; t1091_idx_0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 * 2.0 ; if (
t1303 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 =
intrm_sf_mf_290 * 1.0E-5 ; } else if ( t1303 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 * 1.0E-5 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 = ( (
1.0 - t1091_idx_0 ) * intrm_sf_mf_290 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 * t1091_idx_0
) * 1.0E-5 ; } t1333 = X [ 244ULL ] * t1333 / 0.44 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 = ( X [ 25ULL
] / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) - X [ 248ULL ] / ( X [
249ULL ] == 0.0 ? 1.0E-16 : X [ 249ULL ] ) ) * X [ 247ULL ] * intrm_sf_mf_270
/ 0.44 ; if ( X [ 248ULL ] <= 216.59999999999997 ) { t1303 =
216.59999999999997 ; } else { t1303 = X [ 248ULL ] >= 623.15 ? 623.15 : X [
248ULL ] ; } t1523 = t1303 * t1303 ; intrm_sf_mf_290 = ( ( (
1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1523 *
0.0003721298010901061 ) * ( ( 1.0 - t1493 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1523 * -
0.00038614513167845434 ) * t1493 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1523 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 ; t1576 =
intrm_sf_mf_290 - intrm_sf_mf_270 ; t1493 = intrm_sf_mf_290 / ( t1576 == 0.0
? 1.0E-16 : t1576 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 ) ; t1577 = X [ 249ULL ] * X [ 249ULL ] * t1493 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 = - pmf_sqrt (
fabs ( t1577 / ( intrm_sf_mf_270 == 0.0 ? 1.0E-16 : intrm_sf_mf_270 ) / ( X [
248ULL ] == 0.0 ? 1.0E-16 : X [ 248ULL ] ) ) ) * 0.44 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 >= 0.0 ) {
t1091_idx_0 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34
* 100000.0 ; } else { t1091_idx_0 = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 * 100000.0 ; }
t1523 = t1091_idx_0 * 0.01 / ( t1561 == 0.0 ? 1.0E-16 : t1561 ) ; t1524 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 * t1512 *
2.9973120849090416 / ( t1565 == 0.0 ? 1.0E-16 : t1565 ) ; t1527 = t1523 >=
1.0 ? t1523 : 1.0 ; t1584 = pmf_log10 ( 6.9 / ( t1527 == 0.0 ? 1.0E-16 :
t1527 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1527 == 0.0 ?
1.0E-16 : t1527 ) + 0.00017169489553429715 ) * 3.24 ; t1091_idx_0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34 * t1091_idx_0
* ( 1.0 / ( t1584 == 0.0 ? 1.0E-16 : t1584 ) ) * 0.046833001326703774 / (
t1568 == 0.0 ? 1.0E-16 : t1568 ) ; t1528 = ( t1523 - 2000.0 ) / 2000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 = t1528 *
t1528 * 3.0 - t1528 * t1528 * t1528 * 2.0 ; if ( t1523 <= 2000.0 ) { t1528 =
t1524 * 1.0E-5 ; } else if ( t1523 >= 4000.0 ) { t1528 = t1091_idx_0 * 1.0E-5
; } else { t1528 = ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 ) * t1524 +
t1091_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49
) * 1.0E-5 ; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2
= X [ 247ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 / 0.44 *
0.00031622776601683789 + t1528 ; if ( 1.0 - X [ 27ULL ] >= 0.01 ) { t1523 =
1.0 - X [ 27ULL ] ; } else if ( 1.0 - X [ 27ULL ] >= - 0.1 ) { t1523 =
pmf_exp ( ( ( 1.0 - X [ 27ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1523 =
1.6701700790245661E-7 ; } t1524 = X [ 26ULL ] / ( t1523 == 0.0 ? 1.0E-16 :
t1523 ) * 3827.6794129126583 + 296.802103844292 ; t1100 [ 0ULL ] = X [ 25ULL
] ; tlu2_linear_linear_prelookup ( & ce_efOut . mField0 [ 0ULL ] , & ce_efOut
. mField1 [ 0ULL ] , & ce_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] )
; t128 = ce_efOut ; tlu2_1d_linear_linear_value ( & de_efOut [ 0ULL ] , &
t128 . mField0 [ 0ULL ] , & t128 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t177 [ 0 ] =
de_efOut [ 0 ] ; t1528 = pmf_exp ( pmf_log ( X [ 31ULL ] * 100000.0 ) - t177
[ 0ULL ] ) ; if ( t1528 >= 1.0 ) { t1591 = ( t1528 - 1.0 ) * 461.523 + t1524
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 = t1524 / (
t1591 == 0.0 ? 1.0E-16 : t1591 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 = 1.0 ; } if (
X [ 243ULL ] <= 0.0 ) { U_idx_3 = 0.0 ; } else { U_idx_3 = X [ 243ULL ] >=
1.0 ? 1.0 : X [ 243ULL ] ; } if ( X [ 242ULL ] <= 0.0 ) { intrm_sf_mf_306 =
0.0 ; } else { intrm_sf_mf_306 = X [ 242ULL ] >= 1.0 ? 1.0 : X [ 242ULL ] ; }
t1532 = ( ( ( 1.0 - U_idx_3 ) - intrm_sf_mf_306 ) * 296.802103844292 +
U_idx_3 * 461.523 ) + intrm_sf_mf_306 * 4124.48151675695 ; U_idx_3 = X [
243ULL ] * 461.523 / ( t1532 == 0.0 ? 1.0E-16 : t1532 ) ; if ( U_idx_3 <= 0.0
) { intrm_sf_mf_306 = 0.0 ; } else { intrm_sf_mf_306 = U_idx_3 >= 1.0 ? 1.0 :
U_idx_3 ; } U_idx_3 = X [ 242ULL ] * 4124.48151675695 / ( t1532 == 0.0 ?
1.0E-16 : t1532 ) ; if ( U_idx_3 <= 0.0 ) { t1533 = 0.0 ; } else { t1533 =
U_idx_3 >= 1.0 ? 1.0 : U_idx_3 ; } t1100 [ 0ULL ] = X [ 240ULL ] ;
tlu2_linear_nearest_prelookup ( & ee_efOut . mField0 [ 0ULL ] , & ee_efOut .
mField1 [ 0ULL ] , & ee_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = ee_efOut ; tlu2_1d_linear_nearest_value ( & fe_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
fe_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ge_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
ge_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & he_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
he_efOut [ 0 ] ; U_idx_3 = ( ( ( 1.0 - intrm_sf_mf_306 ) - t1533 ) *
t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_306 ) + t1096_idx_0 * t1533 ;
tlu2_1d_linear_nearest_value ( & ie_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ie_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & je_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = je_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ke_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL ]
, & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ke_efOut [ 0 ] ; t1303 =
( ( ( 1.0 - t1511 ) - t1510 ) * t1091_idx_0 + t1098_idx_0 * t1511 ) +
t1096_idx_0 * t1510 ; t1510 = ( X [ 244ULL ] - X [ 247ULL ] ) / 2.0 ;
tlu2_1d_linear_nearest_value ( & le_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = le_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & me_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = me_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ne_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ne_efOut [ 0 ] ;
intrm_sf_mf_622 = ( ( ( 1.0 - intrm_sf_mf_306 ) - t1533 ) * t1091_idx_0 +
t1098_idx_0 * intrm_sf_mf_306 ) + t1096_idx_0 * t1533 ; t1595 = t1512 +
intrm_sf_mf_622 ; t1597 = t1595 / 2.0 * 0.44 ; t1511 = ( t1510 >= 0.0 ? t1510
: 0.0 ) * 0.01 / ( t1597 == 0.0 ? 1.0E-16 : t1597 ) ; intrm_sf_mf_306 = t1511
>= 0.0 ? t1511 : - t1511 ; t1511 = intrm_sf_mf_306 > 1000.0 ? intrm_sf_mf_306
: 1000.0 ; t1598 = U_idx_3 + t1303 ; if ( t1598 / 2.0 > 0.5 ) { t1533 = (
U_idx_3 + t1303 ) / 2.0 ; } else { t1533 = 0.5 ; } t1600 = pmf_log10 ( 6.9 /
( t1511 == 0.0 ? 1.0E-16 : t1511 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1511 == 0.0 ? 1.0E-16 : t1511 ) + 0.00017169489553429715 ) * 3.24 ;
t1536 = 1.0 / ( t1600 == 0.0 ? 1.0E-16 : t1600 ) ; t1602 = ( pmf_pow ( t1533
, 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1536 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_330 = ( t1511 - 1000.0 ) * ( t1536 / 8.0 ) * t1533 / ( t1602 ==
0.0 ? 1.0E-16 : t1602 ) ; intrm_sf_mf_483 = ( intrm_sf_mf_306 - 2000.0 ) /
2000.0 ; t1542 = intrm_sf_mf_483 * intrm_sf_mf_483 * 3.0 - intrm_sf_mf_483 *
intrm_sf_mf_483 * intrm_sf_mf_483 * 2.0 ; if ( intrm_sf_mf_306 <= 2000.0 ) {
intrm_sf_mf_483 = 3.66 ; } else if ( intrm_sf_mf_306 >= 4000.0 ) {
intrm_sf_mf_483 = intrm_sf_mf_330 ; } else { intrm_sf_mf_483 = ( 1.0 - t1542
) * 3.66 + intrm_sf_mf_330 * t1542 ; } t1604 = intrm_sf_mf_483 *
14.725216466999729 ; t1607 = t1598 / 2.0 ; if ( intrm_sf_mf_306 > t1604 /
0.44 / ( t1607 == 0.0 ? 1.0E-16 : t1607 ) / 30.0 ) { t1613 = ( U_idx_3 +
t1303 ) / 2.0 ; intrm_sf_mf_330 = intrm_sf_mf_483 * 14.725216466999729 / (
intrm_sf_mf_306 == 0.0 ? 1.0E-16 : intrm_sf_mf_306 ) / 0.44 / ( t1613 == 0.0
? 1.0E-16 : t1613 ) ; } else { intrm_sf_mf_330 = 30.0 ; } if ( X [ 229ULL ]
<= 0.0 ) { intrm_sf_mf_483 = 0.0 ; } else { intrm_sf_mf_483 = X [ 229ULL ] >=
1.0 ? 1.0 : X [ 229ULL ] ; } if ( X [ 228ULL ] <= 0.0 ) { t1542 = 0.0 ; }
else { t1542 = X [ 228ULL ] >= 1.0 ? 1.0 : X [ 228ULL ] ; } t1544 = ( ( ( 1.0
- intrm_sf_mf_483 ) - t1542 ) * 296.802103844292 + intrm_sf_mf_483 * 461.523
) + t1542 * 4124.48151675695 ; intrm_sf_mf_483 = X [ 229ULL ] * 461.523 / (
t1544 == 0.0 ? 1.0E-16 : t1544 ) ; if ( intrm_sf_mf_483 <= 0.0 ) { t1542 =
0.0 ; } else { t1542 = intrm_sf_mf_483 >= 1.0 ? 1.0 : intrm_sf_mf_483 ; }
intrm_sf_mf_483 = X [ 228ULL ] * 4124.48151675695 / ( t1544 == 0.0 ? 1.0E-16
: t1544 ) ; if ( intrm_sf_mf_483 <= 0.0 ) { t1545 = 0.0 ; } else { t1545 =
intrm_sf_mf_483 >= 1.0 ? 1.0 : intrm_sf_mf_483 ; } t1100 [ 0ULL ] = X [
226ULL ] ; tlu2_linear_nearest_prelookup ( & oe_efOut . mField0 [ 0ULL ] , &
oe_efOut . mField1 [ 0ULL ] , & oe_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t116 = oe_efOut ; tlu2_1d_linear_nearest_value ( &
pe_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1091_idx_0 = pe_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
qe_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1098_idx_0 = qe_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
re_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1096_idx_0 = re_efOut [ 0 ] ; intrm_sf_mf_483 = ( ( ( 1.0 - t1542 ) -
t1545 ) * t1091_idx_0 + t1098_idx_0 * t1542 ) + t1096_idx_0 * t1545 ; t1546 =
t1510 <= 0.0 ? t1510 : 0.0 ; tlu2_1d_linear_nearest_value ( & se_efOut [ 0ULL
] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = se_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & te_efOut
[ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1098_idx_0 = te_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ue_efOut
[ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1096_idx_0 = ue_efOut [ 0 ] ; t1510 = ( ( ( 1.0 - t1542 ) - t1545 ) *
t1091_idx_0 + t1098_idx_0 * t1542 ) + t1096_idx_0 * t1545 ; t1616 = t1512 +
t1510 ; t1618 = t1616 / 2.0 * 0.44 ; t1542 = - t1546 * 0.01 / ( t1618 == 0.0
? 1.0E-16 : t1618 ) ; t1545 = t1542 >= 0.0 ? t1542 : - t1542 ; t1542 = t1545
> 1000.0 ? t1545 : 1000.0 ; t1619 = t1303 + intrm_sf_mf_483 ; if ( t1619 /
2.0 > 0.5 ) { t1546 = ( t1303 + intrm_sf_mf_483 ) / 2.0 ; } else { t1546 =
0.5 ; } t1621 = pmf_log10 ( 6.9 / ( t1542 == 0.0 ? 1.0E-16 : t1542 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1542 == 0.0 ? 1.0E-16 : t1542
) + 0.00017169489553429715 ) * 3.24 ; t1547 = 1.0 / ( t1621 == 0.0 ? 1.0E-16
: t1621 ) ; intrm_sf_mf_623 = ( pmf_pow ( t1546 , 0.66666666666666663 ) - 1.0
) * pmf_sqrt ( t1547 / 8.0 ) * 12.7 + 1.0 ; t1549 = ( t1542 - 1000.0 ) * (
t1547 / 8.0 ) * t1546 / ( intrm_sf_mf_623 == 0.0 ? 1.0E-16 : intrm_sf_mf_623
) ; t1551 = ( t1545 - 2000.0 ) / 2000.0 ; t1552 = t1551 * t1551 * 3.0 - t1551
* t1551 * t1551 * 2.0 ; if ( t1545 <= 2000.0 ) { t1551 = 3.66 ; } else if (
t1545 >= 4000.0 ) { t1551 = t1549 ; } else { t1551 = ( 1.0 - t1552 ) * 3.66 +
t1549 * t1552 ; } t1625 = t1551 * 14.725216466999729 ; t1628 = t1619 / 2.0 ;
if ( t1545 > t1625 / 0.44 / ( t1628 == 0.0 ? 1.0E-16 : t1628 ) / 30.0 ) {
t1634 = ( t1303 + intrm_sf_mf_483 ) / 2.0 ; t1549 = t1551 *
14.725216466999729 / ( t1545 == 0.0 ? 1.0E-16 : t1545 ) / 0.44 / ( t1634 ==
0.0 ? 1.0E-16 : t1634 ) ; } else { t1549 = 30.0 ; } if ( X [ 30ULL ] <= 0.0 )
{ t1551 = 0.0 ; } else { t1551 = X [ 30ULL ] >= 1.0 ? 1.0 : X [ 30ULL ] ; }
if ( X [ 29ULL ] <= 0.0 ) { t1552 = 0.0 ; } else { t1552 = X [ 29ULL ] >= 1.0
? 1.0 : X [ 29ULL ] ; } t1554 = ( ( ( 1.0 - t1551 ) - t1552 ) *
296.802103844292 + t1551 * 461.523 ) + t1552 * 4124.48151675695 ; t1555 = - (
( X [ 28ULL ] / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) - X [ 263ULL ]
/ ( X [ 264ULL ] == 0.0 ? 1.0E-16 : X [ 264ULL ] ) ) * X [ 247ULL ] * t1554 )
/ 0.44 ; if ( X [ 263ULL ] <= 216.59999999999997 ) { t1303 =
216.59999999999997 ; } else { t1303 = X [ 263ULL ] >= 623.15 ? 623.15 : X [
263ULL ] ; } t1560 = t1303 * t1303 ; t1558 = ( ( ( 1074.1165326382554 + t1303
* - 0.22145652610641059 ) + t1560 * 0.0003721298010901061 ) * ( ( 1.0 - t1551
) - t1552 ) + ( ( 1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1560 *
- 0.00038614513167845434 ) * t1551 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1560 * - 0.0070524868246844051 ) * t1552 ; t1303 =
t1558 - t1554 ; t1560 = t1558 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; t1563 =
pmf_sqrt ( t1555 * t1555 * 9.999999999999999E-14 + fabs ( X [ 263ULL ] *
t1560 * t1554 ) * 1.0E-9 ) ; if ( X [ 237ULL ] <= 0.0 ) { t1565 = 0.0 ; }
else { t1565 = X [ 237ULL ] >= 1.0 ? 1.0 : X [ 237ULL ] ; } if ( X [ 239ULL ]
<= 0.0 ) { t1564 = 0.0 ; } else { t1564 = X [ 239ULL ] >= 1.0 ? 1.0 : X [
239ULL ] ; } t1100 [ 0ULL ] = X [ 28ULL ] ; tlu2_linear_nearest_prelookup ( &
ve_efOut . mField0 [ 0ULL ] , & ve_efOut . mField1 [ 0ULL ] , & ve_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [
0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t125 = ve_efOut ;
tlu2_1d_linear_nearest_value ( & we_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = we_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & xe_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = xe_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ye_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ye_efOut [ 0 ] ; t1566
= ( ( ( 1.0 - t1565 ) - t1564 ) * t1091_idx_0 + t1098_idx_0 * t1565 ) +
t1096_idx_0 * t1564 ; t1641 = X [ 264ULL ] * X [ 264ULL ] * t1560 ; t1567 = -
pmf_sqrt ( fabs ( t1641 / ( t1554 == 0.0 ? 1.0E-16 : t1554 ) / ( X [ 263ULL ]
== 0.0 ? 1.0E-16 : X [ 263ULL ] ) ) ) * 0.44 ; if ( t1567 >= 0.0 ) { t1568 =
t1567 * 100000.0 ; } else { t1568 = - t1567 * 100000.0 ; } t1645 = t1566 *
0.44 ; t1303 = t1568 * 0.01 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) ; t1647 = X
[ 28ULL ] * t1554 ; t1570 = X [ 33ULL ] / ( t1647 == 0.0 ? 1.0E-16 : t1647 )
; t1649 = t1570 * 8.8000000000000011E-5 ; t1574 = t1567 * t1566 *
2.9973120849090416 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) ; t1575 = t1303 >=
1.0 ? t1303 : 1.0 ; t1650 = pmf_log10 ( 6.9 / ( t1575 == 0.0 ? 1.0E-16 :
t1575 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1575 == 0.0 ?
1.0E-16 : t1575 ) + 0.00017169489553429715 ) * 3.24 ; t1652 = t1570 *
0.003872 ; t1568 = t1567 * t1568 * ( 1.0 / ( t1650 == 0.0 ? 1.0E-16 : t1650 )
) * 0.046833001326703774 / ( t1652 == 0.0 ? 1.0E-16 : t1652 ) ; t1576 = (
t1303 - 2000.0 ) / 2000.0 ; t1091_idx_0 = t1576 * t1576 * 3.0 - t1576 * t1576
* t1576 * 2.0 ; if ( t1303 <= 2000.0 ) { t1576 = t1574 * 1.0E-5 ; } else if (
t1303 >= 4000.0 ) { t1576 = t1568 * 1.0E-5 ; } else { t1576 = ( ( 1.0 -
t1091_idx_0 ) * t1574 + t1568 * t1091_idx_0 ) * 1.0E-5 ; } t1563 = - ( X [
247ULL ] * t1563 ) / 0.44 * 0.00031622776601683789 + t1576 ; t1568 = ( X [
28ULL ] / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) - X [ 265ULL ] / ( X
[ 266ULL ] == 0.0 ? 1.0E-16 : X [ 266ULL ] ) ) * X [ 198ULL ] * t1554 / 0.44
; if ( X [ 265ULL ] <= 216.59999999999997 ) { t1303 = 216.59999999999997 ; }
else { t1303 = X [ 265ULL ] >= 623.15 ? 623.15 : X [ 265ULL ] ; } t1580 =
t1303 * t1303 ; t1574 = ( ( ( 1074.1165326382554 + t1303 * -
0.22145652610641059 ) + t1580 * 0.0003721298010901061 ) * ( ( 1.0 - t1551 ) -
t1552 ) + ( ( 1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1580 * -
0.00038614513167845434 ) * t1551 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1580 * - 0.0070524868246844051 ) * t1552 ; t1660 =
t1574 - t1554 ; t1551 = t1574 / ( t1660 == 0.0 ? 1.0E-16 : t1660 ) ; t1552 =
pmf_sqrt ( t1568 * t1568 * 9.999999999999999E-14 + fabs ( X [ 265ULL ] *
t1551 * t1554 ) * 1.0E-9 ) ; t1661 = X [ 266ULL ] * X [ 266ULL ] * t1551 ;
t1576 = - pmf_sqrt ( fabs ( t1661 / ( t1554 == 0.0 ? 1.0E-16 : t1554 ) / ( X
[ 265ULL ] == 0.0 ? 1.0E-16 : X [ 265ULL ] ) ) ) * 0.44 ; if ( t1576 >= 0.0 )
{ t1091_idx_0 = t1576 * 100000.0 ; } else { t1091_idx_0 = - t1576 * 100000.0
; } t1580 = t1091_idx_0 * 0.01 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 = t1576 *
t1566 * 2.9973120849090416 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) ; t1584 =
t1580 >= 1.0 ? t1580 : 1.0 ; t1668 = pmf_log10 ( 6.9 / ( t1584 == 0.0 ?
1.0E-16 : t1584 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1584 ==
0.0 ? 1.0E-16 : t1584 ) + 0.00017169489553429715 ) * 3.24 ; t1091_idx_0 =
t1576 * t1091_idx_0 * ( 1.0 / ( t1668 == 0.0 ? 1.0E-16 : t1668 ) ) *
0.046833001326703774 / ( t1652 == 0.0 ? 1.0E-16 : t1652 ) ; t1585 = ( t1580 -
2000.0 ) / 2000.0 ; t1587 = t1585 * t1585 * 3.0 - t1585 * t1585 * t1585 * 2.0
; if ( t1580 <= 2000.0 ) { t1585 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 * 1.0E-5 ; }
else if ( t1580 >= 4000.0 ) { t1585 = t1091_idx_0 * 1.0E-5 ; } else { t1585 =
( ( 1.0 - t1587 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 + t1091_idx_0
* t1587 ) * 1.0E-5 ; } t1552 = X [ 198ULL ] * t1552 / 0.44 *
0.00031622776601683789 + t1585 ; if ( 1.0 - X [ 30ULL ] >= 0.01 ) { t1580 =
1.0 - X [ 30ULL ] ; } else if ( 1.0 - X [ 30ULL ] >= - 0.1 ) { t1580 =
pmf_exp ( ( ( 1.0 - X [ 30ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1580 =
1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 = X [ 29ULL ]
/ ( t1580 == 0.0 ? 1.0E-16 : t1580 ) * 3827.6794129126583 + 296.802103844292
; t1100 [ 0ULL ] = X [ 28ULL ] ; tlu2_linear_linear_prelookup ( & af_efOut .
mField0 [ 0ULL ] , & af_efOut . mField1 [ 0ULL ] , & af_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t128 = af_efOut ;
tlu2_1d_linear_linear_value ( & bf_efOut [ 0ULL ] , & t128 . mField0 [ 0ULL ]
, & t128 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t192 [ 0 ] = bf_efOut [ 0 ] ; t1585 =
pmf_exp ( pmf_log ( X [ 33ULL ] * 100000.0 ) - t192 [ 0ULL ] ) ; if ( t1585
>= 1.0 ) { t1675 = ( t1585 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 ; t1587 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 / ( t1675 ==
0.0 ? 1.0E-16 : t1675 ) ; } else { t1587 = 1.0 ; }
tlu2_1d_linear_nearest_value ( & cf_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = cf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & df_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = df_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ef_efOut [ 0ULL ] , & t125 . mField0 [ 0ULL
] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ef_efOut [ 0 ] ; t1588
= ( ( ( 1.0 - t1565 ) - t1564 ) * t1091_idx_0 + t1098_idx_0 * t1565 ) +
t1096_idx_0 * t1564 ; t1564 = ( - X [ 247ULL ] - X [ 198ULL ] ) / 2.0 ; t1677
= t1510 + t1566 ; t1679 = t1677 / 2.0 * 0.44 ; t1510 = ( t1564 >= 0.0 ? t1564
: 0.0 ) * 0.01 / ( t1679 == 0.0 ? 1.0E-16 : t1679 ) ; t1565 = t1510 >= 0.0 ?
t1510 : - t1510 ; t1510 = t1565 > 1000.0 ? t1565 : 1000.0 ; t1680 =
intrm_sf_mf_483 + t1588 ; if ( t1680 / 2.0 > 0.5 ) { t1589 = (
intrm_sf_mf_483 + t1588 ) / 2.0 ; } else { t1589 = 0.5 ; } intrm_sf_mf_829 =
pmf_log10 ( 6.9 / ( t1510 == 0.0 ? 1.0E-16 : t1510 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1510 == 0.0 ? 1.0E-16 : t1510 ) +
0.00017169489553429715 ) * 3.24 ; t1590 = 1.0 / ( intrm_sf_mf_829 == 0.0 ?
1.0E-16 : intrm_sf_mf_829 ) ; t1684 = ( pmf_pow ( t1589 , 0.66666666666666663
) - 1.0 ) * pmf_sqrt ( t1590 / 8.0 ) * 12.7 + 1.0 ; t1591 = ( t1510 - 1000.0
) * ( t1590 / 8.0 ) * t1589 / ( t1684 == 0.0 ? 1.0E-16 : t1684 ) ; t1592 = (
t1565 - 2000.0 ) / 2000.0 ; intrm_sf_mf_491 = t1592 * t1592 * 3.0 - t1592 *
t1592 * t1592 * 2.0 ; if ( t1565 <= 2000.0 ) { t1592 = 3.66 ; } else if (
t1565 >= 4000.0 ) { t1592 = t1591 ; } else { t1592 = ( 1.0 - intrm_sf_mf_491
) * 3.66 + t1591 * intrm_sf_mf_491 ; } t1686 = t1592 * 14.725216466999729 ;
t1689 = t1680 / 2.0 ; if ( t1565 > t1686 / 0.44 / ( t1689 == 0.0 ? 1.0E-16 :
t1689 ) / 30.0 ) { t1303 = ( intrm_sf_mf_483 + t1588 ) / 2.0 ; t1591 = t1592
* 14.725216466999729 / ( t1565 == 0.0 ? 1.0E-16 : t1565 ) / 0.44 / ( t1303 ==
0.0 ? 1.0E-16 : t1303 ) ; } else { t1591 = 30.0 ; } t1696 = t1478 + t1566 ;
t1698 = t1696 / 2.0 * 0.44 ; t1478 = - ( t1564 <= 0.0 ? t1564 : 0.0 ) * 0.01
/ ( t1698 == 0.0 ? 1.0E-16 : t1698 ) ; intrm_sf_mf_483 = t1478 >= 0.0 ? t1478
: - t1478 ; t1478 = intrm_sf_mf_483 > 1000.0 ? intrm_sf_mf_483 : 1000.0 ;
t1699 = t1469 + t1588 ; if ( t1699 / 2.0 > 0.5 ) { t1564 = ( t1469 + t1588 )
/ 2.0 ; } else { t1564 = 0.5 ; } t1701 = pmf_log10 ( 6.9 / ( t1478 == 0.0 ?
1.0E-16 : t1478 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1478 ==
0.0 ? 1.0E-16 : t1478 ) + 0.00017169489553429715 ) * 3.24 ; t1592 = 1.0 / (
t1701 == 0.0 ? 1.0E-16 : t1701 ) ; t1091_idx_0 = ( pmf_pow ( t1564 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1592 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_491 = ( t1478 - 1000.0 ) * ( t1592 / 8.0 ) * t1564 / (
t1091_idx_0 == 0.0 ? 1.0E-16 : t1091_idx_0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = (
intrm_sf_mf_483 - 2000.0 ) / 2000.0 ; t1596 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 * 2.0 ; if (
intrm_sf_mf_483 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = 3.66 ; }
else if ( intrm_sf_mf_483 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 =
intrm_sf_mf_491 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = ( 1.0 -
t1596 ) * 3.66 + intrm_sf_mf_491 * t1596 ; } t1705 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
14.725216466999729 ; t1376 = t1699 / 2.0 ; if ( intrm_sf_mf_483 > t1705 /
0.44 / ( t1376 == 0.0 ? 1.0E-16 : t1376 ) / 30.0 ) { t1303 = ( t1469 + t1588
) / 2.0 ; intrm_sf_mf_491 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
14.725216466999729 / ( intrm_sf_mf_483 == 0.0 ? 1.0E-16 : intrm_sf_mf_483 ) /
0.44 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else { intrm_sf_mf_491 = 30.0 ;
} if ( X [ 36ULL ] <= 0.0 ) { t1588 = 0.0 ; } else { t1588 = X [ 36ULL ] >=
1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = X [ 35ULL
] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t1596 = ( ( ( 1.0 - t1588 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ) *
296.802103844292 + t1588 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 *
4124.48151675695 ; t1597 = ( X [ 34ULL ] / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X
[ 37ULL ] ) - X [ 289ULL ] / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X [ 290ULL ] )
) * X [ 288ULL ] * t1596 / 0.0019634954084936209 ; if ( X [ 289ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
289ULL ] >= 623.15 ? 623.15 : X [ 289ULL ] ; } t1601 = t1303 * t1303 ; t1600
= ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1601 *
0.0003721298010901061 ) * ( ( 1.0 - t1588 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1601 * -
0.00038614513167845434 ) * t1588 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1601 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ; t1091_idx_0
= t1600 - t1596 ; t1601 = t1600 / ( t1091_idx_0 == 0.0 ? 1.0E-16 :
t1091_idx_0 ) ; t1602 = pmf_sqrt ( t1597 * t1597 * 9.999999999999999E-14 +
fabs ( X [ 289ULL ] * t1601 * t1596 ) * 1.0E-9 ) ; if ( X [ 285ULL ] <= 0.0 )
{ intrm_sf_mf_621 = 0.0 ; } else { intrm_sf_mf_621 = X [ 285ULL ] >= 1.0 ?
1.0 : X [ 285ULL ] ; } if ( X [ 284ULL ] <= 0.0 ) { t1606 = 0.0 ; } else {
t1606 = X [ 284ULL ] >= 1.0 ? 1.0 : X [ 284ULL ] ; } t1100 [ 0ULL ] = X [
34ULL ] ; tlu2_linear_nearest_prelookup ( & ff_efOut . mField0 [ 0ULL ] , &
ff_efOut . mField1 [ 0ULL ] , & ff_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t20 = ff_efOut ; tlu2_1d_linear_nearest_value ( &
gf_efOut [ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = gf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & hf_efOut
[ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1098_idx_0 = hf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & if_efOut
[ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1096_idx_0 = if_efOut [ 0 ] ; t1607 = ( ( ( 1.0 - intrm_sf_mf_621 ) -
t1606 ) * t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_621 ) + t1096_idx_0 * t1606
; t1721 = X [ 290ULL ] * X [ 290ULL ] * t1601 ; t1608 = - pmf_sqrt ( fabs (
t1721 / ( t1596 == 0.0 ? 1.0E-16 : t1596 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16
: X [ 289ULL ] ) ) ) * 0.0019634954084936209 ; if ( t1608 >= 0.0 ) { t1609 =
t1608 * 100000.0 ; } else { t1609 = - t1608 * 100000.0 ; } t1725 = t1607 *
0.0019634954084936209 ; t1303 = t1609 * 0.05 / ( t1725 == 0.0 ? 1.0E-16 :
t1725 ) ; t1727 = X [ 34ULL ] * t1596 ; t1611 = X [ 37ULL ] / ( t1727 == 0.0
? 1.0E-16 : t1727 ) ; t1729 = t1611 * 9.8174770424681068E-6 ; intrm_sf_mf_565
= t1608 * t1607 * 11.2 / ( t1729 == 0.0 ? 1.0E-16 : t1729 ) ; t1613 = t1303
>= 1.0 ? t1303 : 1.0 ; t1469 = pmf_log10 ( 6.9 / ( t1613 == 0.0 ? 1.0E-16 :
t1613 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1613 == 0.0 ?
1.0E-16 : t1613 ) + 2.8767404433520813E-5 ) * 3.24 ; t1732 = t1611 *
3.855314219175531E-7 ; t1609 = t1608 * t1609 * ( 1.0 / ( t1469 == 0.0 ?
1.0E-16 : t1469 ) ) * 0.175 / ( t1732 == 0.0 ? 1.0E-16 : t1732 ) ; t1614 = (
t1303 - 2000.0 ) / 2000.0 ; t1091_idx_0 = t1614 * t1614 * 3.0 - t1614 * t1614
* t1614 * 2.0 ; if ( t1303 <= 2000.0 ) { t1614 = intrm_sf_mf_565 * 1.0E-5 ; }
else if ( t1303 >= 4000.0 ) { t1614 = t1609 * 1.0E-5 ; } else { t1614 = ( (
1.0 - t1091_idx_0 ) * intrm_sf_mf_565 + t1609 * t1091_idx_0 ) * 1.0E-5 ; }
t1602 = X [ 288ULL ] * t1602 / 0.0019634954084936209 * 0.00031622776601683789
+ t1614 ; t1609 = - ( ( X [ 34ULL ] / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [
37ULL ] ) - X [ 291ULL ] / ( X [ 292ULL ] == 0.0 ? 1.0E-16 : X [ 292ULL ] ) )
* X [ 244ULL ] * t1596 ) / 0.0019634954084936209 ; if ( X [ 291ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
291ULL ] >= 623.15 ? 623.15 : X [ 291ULL ] ; } t1348 = t1303 * t1303 ;
intrm_sf_mf_565 = ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 )
+ t1348 * 0.0003721298010901061 ) * ( ( 1.0 - t1588 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1348 * -
0.00038614513167845434 ) * t1588 ) + ( ( 12825.281119789837 + t1303 *
6.9647057412840034 ) + t1348 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ; t1740 =
intrm_sf_mf_565 - t1596 ; t1588 = intrm_sf_mf_565 / ( t1740 == 0.0 ? 1.0E-16
: t1740 ) ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 =
pmf_sqrt ( t1609 * t1609 * 9.999999999999999E-14 + fabs ( X [ 291ULL ] *
t1588 * t1596 ) * 1.0E-9 ) ; t1741 = X [ 292ULL ] * X [ 292ULL ] * t1588 ;
t1614 = - pmf_sqrt ( fabs ( t1741 / ( t1596 == 0.0 ? 1.0E-16 : t1596 ) / ( X
[ 291ULL ] == 0.0 ? 1.0E-16 : X [ 291ULL ] ) ) ) * 0.0019634954084936209 ; if
( t1614 >= 0.0 ) { t1091_idx_0 = t1614 * 100000.0 ; } else { t1091_idx_0 = -
t1614 * 100000.0 ; } t1348 = t1091_idx_0 * 0.05 / ( t1725 == 0.0 ? 1.0E-16 :
t1725 ) ; t1618 = t1614 * t1607 * 11.2 / ( t1729 == 0.0 ? 1.0E-16 : t1729 ) ;
t1620 = t1348 >= 1.0 ? t1348 : 1.0 ; t1748 = pmf_log10 ( 6.9 / ( t1620 == 0.0
? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1620 ==
0.0 ? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 ) * 3.24 ; t1091_idx_0 =
t1614 * t1091_idx_0 * ( 1.0 / ( t1748 == 0.0 ? 1.0E-16 : t1748 ) ) * 0.175 /
( t1732 == 0.0 ? 1.0E-16 : t1732 ) ; t1621 = ( t1348 - 2000.0 ) / 2000.0 ;
t1622 = t1621 * t1621 * 3.0 - t1621 * t1621 * t1621 * 2.0 ; if ( t1348 <=
2000.0 ) { t1621 = t1618 * 1.0E-5 ; } else if ( t1348 >= 4000.0 ) { t1621 =
t1091_idx_0 * 1.0E-5 ; } else { t1621 = ( ( 1.0 - t1622 ) * t1618 +
t1091_idx_0 * t1622 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 = - ( X [
244ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 ) /
0.0019634954084936209 * 0.00031622776601683789 + t1621 ; if ( 1.0 - X [ 36ULL
] >= 0.01 ) { t1348 = 1.0 - X [ 36ULL ] ; } else if ( 1.0 - X [ 36ULL ] >= -
0.1 ) { t1348 = pmf_exp ( ( ( 1.0 - X [ 36ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ;
} else { t1348 = 1.6701700790245661E-7 ; } t1618 = X [ 35ULL ] / ( t1348 ==
0.0 ? 1.0E-16 : t1348 ) * 3827.6794129126583 + 296.802103844292 ; t1100 [
0ULL ] = X [ 34ULL ] ; tlu2_linear_linear_prelookup ( & jf_efOut . mField0 [
0ULL ] , & jf_efOut . mField1 [ 0ULL ] , & jf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t128 = jf_efOut ; tlu2_1d_linear_linear_value ( &
kf_efOut [ 0ULL ] , & t128 . mField0 [ 0ULL ] , & t128 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t917 [ 0 ] = kf_efOut [ 0 ] ; t1621 = pmf_exp ( pmf_log ( X [ 37ULL ] *
100000.0 ) - t917 [ 0ULL ] ) ; if ( t1621 >= 1.0 ) { t1755 = ( t1621 - 1.0 )
* 461.523 + t1618 ; t1622 = t1618 / ( t1755 == 0.0 ? 1.0E-16 : t1755 ) ; }
else { t1622 = 1.0 ; } if ( X [ 280ULL ] <= 0.0 ) { intrm_sf_mf_623 = 0.0 ; }
else { intrm_sf_mf_623 = X [ 280ULL ] >= 1.0 ? 1.0 : X [ 280ULL ] ; } if ( X
[ 279ULL ] <= 0.0 ) { t1624 = 0.0 ; } else { t1624 = X [ 279ULL ] >= 1.0 ?
1.0 : X [ 279ULL ] ; } t1627 = ( ( ( 1.0 - intrm_sf_mf_623 ) - t1624 ) *
296.802103844292 + intrm_sf_mf_623 * 461.523 ) + t1624 * 4124.48151675695 ;
intrm_sf_mf_623 = X [ 280ULL ] * 461.523 / ( t1627 == 0.0 ? 1.0E-16 : t1627 )
; if ( intrm_sf_mf_623 <= 0.0 ) { t1624 = 0.0 ; } else { t1624 =
intrm_sf_mf_623 >= 1.0 ? 1.0 : intrm_sf_mf_623 ; } intrm_sf_mf_623 = X [
279ULL ] * 4124.48151675695 / ( t1627 == 0.0 ? 1.0E-16 : t1627 ) ; if (
intrm_sf_mf_623 <= 0.0 ) { t1628 = 0.0 ; } else { t1628 = intrm_sf_mf_623 >=
1.0 ? 1.0 : intrm_sf_mf_623 ; } t1100 [ 0ULL ] = X [ 278ULL ] ;
tlu2_linear_nearest_prelookup ( & lf_efOut . mField0 [ 0ULL ] , & lf_efOut .
mField1 [ 0ULL ] , & lf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t88 = lf_efOut ; tlu2_1d_linear_nearest_value ( & mf_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = mf_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & nf_efOut [ 0ULL ] , & t88 . mField0
[ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = nf_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & of_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL
] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = of_efOut [ 0 ] ;
intrm_sf_mf_623 = ( ( ( 1.0 - t1624 ) - t1628 ) * t1091_idx_0 + t1098_idx_0 *
t1624 ) + t1096_idx_0 * t1628 ; tlu2_1d_linear_nearest_value ( & pf_efOut [
0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = pf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & qf_efOut
[ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1098_idx_0 = qf_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & rf_efOut
[ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1096_idx_0 = rf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( ( ( 1.0 -
intrm_sf_mf_621 ) - t1606 ) * t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_621 ) +
t1096_idx_0 * t1606 ; intrm_sf_mf_621 = ( X [ 288ULL ] - ( - X [ 244ULL ] ) )
/ 2.0 ; tlu2_1d_linear_nearest_value ( & sf_efOut [ 0ULL ] , & t88 . mField0
[ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = sf_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & tf_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL
] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = tf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & uf_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = uf_efOut [ 0 ] ; t1759 =
t1607 + ( ( ( ( 1.0 - t1624 ) - t1628 ) * t1091_idx_0 + t1098_idx_0 * t1624 )
+ t1096_idx_0 * t1628 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 = t1759 / 2.0
* 0.0019634954084936209 ; t1606 = ( intrm_sf_mf_621 >= 0.0 ? intrm_sf_mf_621
: 0.0 ) * 0.05 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 ) ;
t1624 = t1606 >= 0.0 ? t1606 : - t1606 ; t1606 = t1624 > 1000.0 ? t1624 :
1000.0 ; t1762 = intrm_sf_mf_623 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; if ( t1762 /
2.0 > 0.5 ) { t1628 = ( intrm_sf_mf_623 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / 2.0 ; }
else { t1628 = 0.5 ; } t1764 = pmf_log10 ( 6.9 / ( t1606 == 0.0 ? 1.0E-16 :
t1606 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1606 == 0.0 ?
1.0E-16 : t1606 ) + 2.8767404433520813E-5 ) * 3.24 ; t1630 = 1.0 / ( t1764 ==
0.0 ? 1.0E-16 : t1764 ) ; t1766 = ( pmf_pow ( t1628 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t1630 / 8.0 ) * 12.7 + 1.0 ; t1631 = ( t1606 - 1000.0 ) *
( t1630 / 8.0 ) * t1628 / ( t1766 == 0.0 ? 1.0E-16 : t1766 ) ; t1632 = (
t1624 - 2000.0 ) / 2000.0 ; t1633 = t1632 * t1632 * 3.0 - t1632 * t1632 *
t1632 * 2.0 ; if ( t1624 <= 2000.0 ) { t1632 = 3.66 ; } else if ( t1624 >=
4000.0 ) { t1632 = t1631 ; } else { t1632 = ( 1.0 - t1633 ) * 3.66 + t1631 *
t1633 ; } t1768 = t1632 * 0.039269908169872414 ; t1771 = t1762 / 2.0 ; if (
t1624 > t1768 / 0.0019634954084936209 / ( t1771 == 0.0 ? 1.0E-16 : t1771 ) /
30.0 ) { t1777 = ( intrm_sf_mf_623 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / 2.0 ;
t1631 = t1632 * 0.039269908169872414 / ( t1624 == 0.0 ? 1.0E-16 : t1624 ) /
0.0019634954084936209 / ( t1777 == 0.0 ? 1.0E-16 : t1777 ) ; } else { t1631 =
30.0 ; } t1778 = intrm_sf_mf_622 + t1607 ; t1780 = t1778 / 2.0 *
0.0019634954084936209 ; intrm_sf_mf_622 = - ( intrm_sf_mf_621 <= 0.0 ?
intrm_sf_mf_621 : 0.0 ) * 0.05 / ( t1780 == 0.0 ? 1.0E-16 : t1780 ) ;
intrm_sf_mf_621 = intrm_sf_mf_622 >= 0.0 ? intrm_sf_mf_622 : -
intrm_sf_mf_622 ; intrm_sf_mf_622 = intrm_sf_mf_621 > 1000.0 ?
intrm_sf_mf_621 : 1000.0 ; t1781 = U_idx_3 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; if ( t1781 /
2.0 > 0.5 ) { intrm_sf_mf_623 = ( U_idx_3 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / 2.0 ; }
else { intrm_sf_mf_623 = 0.5 ; } t1783 = pmf_log10 ( 6.9 / ( intrm_sf_mf_622
== 0.0 ? 1.0E-16 : intrm_sf_mf_622 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( intrm_sf_mf_622 == 0.0 ? 1.0E-16 : intrm_sf_mf_622 ) +
2.8767404433520813E-5 ) * 3.24 ; t1632 = 1.0 / ( t1783 == 0.0 ? 1.0E-16 :
t1783 ) ; t1785 = ( pmf_pow ( intrm_sf_mf_623 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( t1632 / 8.0 ) * 12.7 + 1.0 ; t1633 = ( intrm_sf_mf_622 - 1000.0
) * ( t1632 / 8.0 ) * intrm_sf_mf_623 / ( t1785 == 0.0 ? 1.0E-16 : t1785 ) ;
t1634 = ( intrm_sf_mf_621 - 2000.0 ) / 2000.0 ; t1635 = t1634 * t1634 * 3.0 -
t1634 * t1634 * t1634 * 2.0 ; if ( intrm_sf_mf_621 <= 2000.0 ) { t1634 = 3.66
; } else if ( intrm_sf_mf_621 >= 4000.0 ) { t1634 = t1633 ; } else { t1634 =
( 1.0 - t1635 ) * 3.66 + t1633 * t1635 ; } t1787 = t1634 *
0.039269908169872414 ; t1790 = t1781 / 2.0 ; if ( intrm_sf_mf_621 > t1787 /
0.0019634954084936209 / ( t1790 == 0.0 ? 1.0E-16 : t1790 ) / 30.0 ) { t1388 =
( U_idx_3 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 )
/ 2.0 ; t1633 = t1634 * 0.039269908169872414 / ( intrm_sf_mf_621 == 0.0 ?
1.0E-16 : intrm_sf_mf_621 ) / 0.0019634954084936209 / ( t1388 == 0.0 ?
1.0E-16 : t1388 ) ; } else { t1633 = 30.0 ; } if ( X [ 318ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = X [ 318ULL
] >= 1.0 ? 1.0 : X [ 318ULL ] ; } if ( X [ 319ULL ] <= 0.0 ) { t1634 = 0.0 ;
} else { t1634 = X [ 319ULL ] >= 1.0 ? 1.0 : X [ 319ULL ] ; } t1635 = ( ( (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) -
t1634 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 * 461.523 ) +
t1634 * 259.836612622973 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( X [ 322ULL
] * 0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X
[ 41ULL ] <= 0.0 ) { t1634 = 0.0 ; } else { t1634 = X [ 41ULL ] >= 1.0 ? 1.0
: X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) { t1636 = 0.0 ; } else { t1636 =
X [ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; } t1638 = ( ( ( 1.0 - t1634 ) -
t1636 ) * 296.802103844292 + t1634 * 461.523 ) + t1636 * 259.836612622973 ;
t1639 = ( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) - X [
326ULL ] / ( X [ 327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) ) * X [ 325ULL ]
* t1638 / 0.0019634954084936209 ; if ( X [ 326ULL ] <= 216.59999999999997 ) {
t1303 = 216.59999999999997 ; } else { t1303 = X [ 326ULL ] >= 623.15 ? 623.15
: X [ 326ULL ] ; } t1644 = t1303 * t1303 ; t1642 = ( ( ( 1074.1165326382554 +
t1303 * - 0.22145652610641059 ) + t1644 * 0.0003721298010901061 ) * ( ( 1.0 -
t1634 ) - t1636 ) + ( ( 1479.6504774710402 + t1303 * 1.2002114337050787 ) +
t1644 * - 0.00038614513167845434 ) * t1634 ) + ( ( 900.639412248396 + t1303 *
- 0.044484923911441127 ) + t1644 * 0.00036936011832051582 ) * t1636 ; t1802 =
t1642 - t1638 ; t1644 = t1642 / ( t1802 == 0.0 ? 1.0E-16 : t1802 ) ; t1647 =
pmf_sqrt ( t1639 * t1639 * 9.999999999999999E-14 + fabs ( X [ 326ULL ] *
t1644 * t1638 ) * 1.0E-9 ) ; if ( X [ 328ULL ] <= 0.0 ) { t1648 = 0.0 ; }
else { t1648 = X [ 328ULL ] >= 1.0 ? 1.0 : X [ 328ULL ] ; } if ( X [ 329ULL ]
<= 0.0 ) { t1649 = 0.0 ; } else { t1649 = X [ 329ULL ] >= 1.0 ? 1.0 : X [
329ULL ] ; } t1100 [ 0ULL ] = X [ 39ULL ] ; tlu2_linear_nearest_prelookup ( &
vf_efOut . mField0 [ 0ULL ] , & vf_efOut . mField1 [ 0ULL ] , & vf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [
0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t122 = vf_efOut ;
tlu2_1d_linear_nearest_value ( & wf_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = wf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & xf_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = xf_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & yf_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = yf_efOut [ 0 ] ; t1650
= ( ( ( 1.0 - t1648 ) - t1649 ) * t1091_idx_0 + t1098_idx_0 * t1648 ) +
t1096_idx_0 * t1649 ; t1803 = X [ 327ULL ] * X [ 327ULL ] * t1644 ; t1651 = -
pmf_sqrt ( fabs ( t1803 / ( t1638 == 0.0 ? 1.0E-16 : t1638 ) / ( X [ 326ULL ]
== 0.0 ? 1.0E-16 : X [ 326ULL ] ) ) ) * 0.0019634954084936209 ; if ( t1651 >=
0.0 ) { t1652 = t1651 * 100000.0 ; } else { t1652 = - t1651 * 100000.0 ; }
t1807 = t1650 * 0.0019634954084936209 ; t1303 = t1652 * 0.05 / ( t1807 == 0.0
? 1.0E-16 : t1807 ) ; t1809 = X [ 39ULL ] * t1638 ; t1654 = X [ 40ULL ] / (
t1809 == 0.0 ? 1.0E-16 : t1809 ) ; t1811 = t1654 * 9.8174770424681068E-6 ;
intrm_sf_mf_714 = t1651 * t1650 * 35.2 / ( t1811 == 0.0 ? 1.0E-16 : t1811 ) ;
t1659 = t1303 >= 1.0 ? t1303 : 1.0 ; t1812 = pmf_log10 ( 6.9 / ( t1659 == 0.0
? 1.0E-16 : t1659 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1659 ==
0.0 ? 1.0E-16 : t1659 ) + 2.8767404433520813E-5 ) * 3.24 ; t1814 = t1654 *
3.855314219175531E-7 ; t1652 = t1651 * t1652 * ( 1.0 / ( t1812 == 0.0 ?
1.0E-16 : t1812 ) ) * 0.55 / ( t1814 == 0.0 ? 1.0E-16 : t1814 ) ; t1660 = (
t1303 - 2000.0 ) / 2000.0 ; t1091_idx_0 = t1660 * t1660 * 3.0 - t1660 * t1660
* t1660 * 2.0 ; if ( t1303 <= 2000.0 ) { t1660 = intrm_sf_mf_714 * 1.0E-5 ; }
else if ( t1303 >= 4000.0 ) { t1660 = t1652 * 1.0E-5 ; } else { t1660 = ( (
1.0 - t1091_idx_0 ) * intrm_sf_mf_714 + t1652 * t1091_idx_0 ) * 1.0E-5 ; }
t1647 = X [ 325ULL ] * t1647 / 0.0019634954084936209 * 0.00031622776601683789
+ t1660 ; t1652 = - ( ( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [
40ULL ] ) - X [ 330ULL ] / ( X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] ) )
* X [ 313ULL ] * t1638 ) / 0.0019634954084936209 ; if ( X [ 330ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
330ULL ] >= 623.15 ? 623.15 : X [ 330ULL ] ; } t1664 = t1303 * t1303 ;
intrm_sf_mf_714 = ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 )
+ t1664 * 0.0003721298010901061 ) * ( ( 1.0 - t1634 ) - t1636 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1664 * -
0.00038614513167845434 ) * t1634 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1664 * 0.00036936011832051582 ) * t1636 ; t1822 =
intrm_sf_mf_714 - t1638 ; t1634 = intrm_sf_mf_714 / ( t1822 == 0.0 ? 1.0E-16
: t1822 ) ; t1636 = pmf_sqrt ( t1652 * t1652 * 9.999999999999999E-14 + fabs (
X [ 330ULL ] * t1634 * t1638 ) * 1.0E-9 ) ; t1823 = X [ 331ULL ] * X [ 331ULL
] * t1634 ; t1660 = - pmf_sqrt ( fabs ( t1823 / ( t1638 == 0.0 ? 1.0E-16 :
t1638 ) / ( X [ 330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) *
0.0019634954084936209 ; if ( t1660 >= 0.0 ) { t1091_idx_0 = t1660 * 100000.0
; } else { t1091_idx_0 = - t1660 * 100000.0 ; } t1664 = t1091_idx_0 * 0.05 /
( t1807 == 0.0 ? 1.0E-16 : t1807 ) ; t1666 = t1660 * t1650 * 35.2 / ( t1811
== 0.0 ? 1.0E-16 : t1811 ) ; t1668 = t1664 >= 1.0 ? t1664 : 1.0 ; t1830 =
pmf_log10 ( 6.9 / ( t1668 == 0.0 ? 1.0E-16 : t1668 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1668 == 0.0 ? 1.0E-16 : t1668 ) +
2.8767404433520813E-5 ) * 3.24 ; t1091_idx_0 = t1660 * t1091_idx_0 * ( 1.0 /
( t1830 == 0.0 ? 1.0E-16 : t1830 ) ) * 0.55 / ( t1814 == 0.0 ? 1.0E-16 :
t1814 ) ; t1669 = ( t1664 - 2000.0 ) / 2000.0 ; t1671 = t1669 * t1669 * 3.0 -
t1669 * t1669 * t1669 * 2.0 ; if ( t1664 <= 2000.0 ) { t1669 = t1666 * 1.0E-5
; } else if ( t1664 >= 4000.0 ) { t1669 = t1091_idx_0 * 1.0E-5 ; } else {
t1669 = ( ( 1.0 - t1671 ) * t1666 + t1091_idx_0 * t1671 ) * 1.0E-5 ; } t1636
= - ( X [ 313ULL ] * t1636 ) / 0.0019634954084936209 * 0.00031622776601683789
+ t1669 ; if ( 1.0 - X [ 41ULL ] >= 0.01 ) { t1664 = 1.0 - X [ 41ULL ] ; }
else if ( 1.0 - X [ 41ULL ] >= - 0.1 ) { t1664 = pmf_exp ( ( ( 1.0 - X [
41ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1664 = 1.6701700790245661E-7 ;
} t1666 = X [ 42ULL ] / ( t1664 == 0.0 ? 1.0E-16 : t1664 ) * -
36.965491221318985 + 296.802103844292 ; t1100 [ 0ULL ] = X [ 39ULL ] ;
tlu2_linear_linear_prelookup ( & ag_efOut . mField0 [ 0ULL ] , & ag_efOut .
mField1 [ 0ULL ] , & ag_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t128 = ag_efOut ; tlu2_1d_linear_linear_value ( & bg_efOut [ 0ULL ] , & t128
. mField0 [ 0ULL ] , & t128 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t919 [ 0 ] =
bg_efOut [ 0 ] ; t1669 = pmf_exp ( pmf_log ( X [ 40ULL ] * 100000.0 ) - t919
[ 0ULL ] ) ; if ( t1669 >= 1.0 ) { t1837 = ( t1669 - 1.0 ) * 461.523 + t1666
; t1671 = t1666 / ( t1837 == 0.0 ? 1.0E-16 : t1837 ) ; } else { t1671 = 1.0 ;
} if ( X [ 305ULL ] <= 0.0 ) { U_idx_3 = 0.0 ; } else { U_idx_3 = X [ 305ULL
] >= 1.0 ? 1.0 : X [ 305ULL ] ; } if ( X [ 304ULL ] <= 0.0 ) { t1673 = 0.0 ;
} else { t1673 = X [ 304ULL ] >= 1.0 ? 1.0 : X [ 304ULL ] ; } t1674 = ( ( (
1.0 - U_idx_3 ) - t1673 ) * 296.802103844292 + U_idx_3 * 461.523 ) + t1673 *
259.836612622973 ; U_idx_3 = X [ 305ULL ] * 461.523 / ( t1674 == 0.0 ?
1.0E-16 : t1674 ) ; if ( U_idx_3 <= 0.0 ) { t1673 = 0.0 ; } else { t1673 =
U_idx_3 >= 1.0 ? 1.0 : U_idx_3 ; } U_idx_3 = X [ 304ULL ] * 259.836612622973
/ ( t1674 == 0.0 ? 1.0E-16 : t1674 ) ; if ( U_idx_3 <= 0.0 ) { t1675 = 0.0 ;
} else { t1675 = U_idx_3 >= 1.0 ? 1.0 : U_idx_3 ; } t1100 [ 0ULL ] = X [
302ULL ] ; tlu2_linear_nearest_prelookup ( & cg_efOut . mField0 [ 0ULL ] , &
cg_efOut . mField1 [ 0ULL ] , & cg_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t116 = cg_efOut ; tlu2_1d_linear_nearest_value ( &
dg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1091_idx_0 = dg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
eg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1098_idx_0 = eg_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
fg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1096_idx_0 = fg_efOut [ 0 ] ; U_idx_3 = ( ( ( 1.0 - t1673 ) - t1675 )
* t1091_idx_0 + t1098_idx_0 * t1673 ) + t1096_idx_0 * t1675 ;
tlu2_1d_linear_nearest_value ( & gg_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = gg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & hg_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = hg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ig_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ig_efOut [ 0 ] ; t1303
= ( ( ( 1.0 - t1648 ) - t1649 ) * t1091_idx_0 + t1098_idx_0 * t1648 ) +
t1096_idx_0 * t1649 ; t1648 = ( X [ 325ULL ] - ( - X [ 313ULL ] ) ) / 2.0 ;
tlu2_1d_linear_nearest_value ( & jg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = jg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & kg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = kg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & lg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = lg_efOut [ 0 ] ;
intrm_sf_mf_1083 = ( ( ( 1.0 - t1673 ) - t1675 ) * t1091_idx_0 + t1098_idx_0
* t1673 ) + t1096_idx_0 * t1675 ; t1841 = t1650 + intrm_sf_mf_1083 ; t1843 =
t1841 / 2.0 * 0.0019634954084936209 ; t1649 = ( t1648 >= 0.0 ? t1648 : 0.0 )
* 0.05 / ( t1843 == 0.0 ? 1.0E-16 : t1843 ) ; t1673 = t1649 >= 0.0 ? t1649 :
- t1649 ; t1649 = t1673 > 1000.0 ? t1673 : 1000.0 ; t1844 = U_idx_3 + t1303 ;
if ( t1844 / 2.0 > 0.5 ) { t1675 = ( U_idx_3 + t1303 ) / 2.0 ; } else { t1675
= 0.5 ; } t1846 = pmf_log10 ( 6.9 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1649 == 0.0 ? 1.0E-16 : t1649
) + 2.8767404433520813E-5 ) * 3.24 ; t1679 = 1.0 / ( t1846 == 0.0 ? 1.0E-16 :
t1846 ) ; t1848 = ( pmf_pow ( t1675 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1679 / 8.0 ) * 12.7 + 1.0 ; t1681 = ( t1649 - 1000.0 ) * ( t1679
/ 8.0 ) * t1675 / ( t1848 == 0.0 ? 1.0E-16 : t1848 ) ; intrm_sf_mf_829 = (
t1673 - 2000.0 ) / 2000.0 ; t1683 = intrm_sf_mf_829 * intrm_sf_mf_829 * 3.0 -
intrm_sf_mf_829 * intrm_sf_mf_829 * intrm_sf_mf_829 * 2.0 ; if ( t1673 <=
2000.0 ) { intrm_sf_mf_829 = 3.66 ; } else if ( t1673 >= 4000.0 ) {
intrm_sf_mf_829 = t1681 ; } else { intrm_sf_mf_829 = ( 1.0 - t1683 ) * 3.66 +
t1681 * t1683 ; } t1850 = intrm_sf_mf_829 * 0.15707963267948966 ; t1853 =
t1844 / 2.0 ; if ( t1673 > t1850 / 0.0019634954084936209 / ( t1853 == 0.0 ?
1.0E-16 : t1853 ) / 30.0 ) { t1859 = ( U_idx_3 + t1303 ) / 2.0 ; t1681 =
intrm_sf_mf_829 * 0.15707963267948966 / ( t1673 == 0.0 ? 1.0E-16 : t1673 ) /
0.0019634954084936209 / ( t1859 == 0.0 ? 1.0E-16 : t1859 ) ; } else { t1681 =
30.0 ; } if ( X [ 324ULL ] <= 0.0 ) { intrm_sf_mf_829 = 0.0 ; } else {
intrm_sf_mf_829 = X [ 324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X [
323ULL ] <= 0.0 ) { t1683 = 0.0 ; } else { t1683 = X [ 323ULL ] >= 1.0 ? 1.0
: X [ 323ULL ] ; } t1684 = ( ( ( 1.0 - intrm_sf_mf_829 ) - t1683 ) *
296.802103844292 + intrm_sf_mf_829 * 461.523 ) + t1683 * 259.836612622973 ;
intrm_sf_mf_829 = X [ 324ULL ] * 461.523 / ( t1684 == 0.0 ? 1.0E-16 : t1684 )
; if ( intrm_sf_mf_829 <= 0.0 ) { t1683 = 0.0 ; } else { t1683 =
intrm_sf_mf_829 >= 1.0 ? 1.0 : intrm_sf_mf_829 ; } intrm_sf_mf_829 = X [
323ULL ] * 259.836612622973 / ( t1684 == 0.0 ? 1.0E-16 : t1684 ) ; if (
intrm_sf_mf_829 <= 0.0 ) { t1685 = 0.0 ; } else { t1685 = intrm_sf_mf_829 >=
1.0 ? 1.0 : intrm_sf_mf_829 ; } t1100 [ 0ULL ] = X [ 321ULL ] ;
tlu2_linear_nearest_prelookup ( & mg_efOut . mField0 [ 0ULL ] , & mg_efOut .
mField1 [ 0ULL ] , & mg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t109 = mg_efOut ; tlu2_1d_linear_nearest_value ( & ng_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
ng_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & og_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
og_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & pg_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
pg_efOut [ 0 ] ; intrm_sf_mf_829 = ( ( ( 1.0 - t1683 ) - t1685 ) *
t1091_idx_0 + t1098_idx_0 * t1683 ) + t1096_idx_0 * t1685 ;
tlu2_1d_linear_nearest_value ( & qg_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = qg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & rg_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = rg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & sg_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = sg_efOut [ 0 ] ; t1862
= t1650 + ( ( ( ( 1.0 - t1683 ) - t1685 ) * t1091_idx_0 + t1098_idx_0 * t1683
) + t1096_idx_0 * t1685 ) ; t1864 = t1862 / 2.0 * 0.0019634954084936209 ;
t1648 = - ( t1648 <= 0.0 ? t1648 : 0.0 ) * 0.05 / ( t1864 == 0.0 ? 1.0E-16 :
t1864 ) ; t1683 = t1648 >= 0.0 ? t1648 : - t1648 ; t1648 = t1683 > 1000.0 ?
t1683 : 1000.0 ; t1865 = t1303 + intrm_sf_mf_829 ; if ( t1865 / 2.0 > 0.5 ) {
t1685 = ( t1303 + intrm_sf_mf_829 ) / 2.0 ; } else { t1685 = 0.5 ; } t1867 =
pmf_log10 ( 6.9 / ( t1648 == 0.0 ? 1.0E-16 : t1648 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1648 == 0.0 ? 1.0E-16 : t1648 ) +
2.8767404433520813E-5 ) * 3.24 ; t1688 = 1.0 / ( t1867 == 0.0 ? 1.0E-16 :
t1867 ) ; t1869 = ( pmf_pow ( t1685 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1688 / 8.0 ) * 12.7 + 1.0 ; t1689 = ( t1648 - 1000.0 ) * ( t1688
/ 8.0 ) * t1685 / ( t1869 == 0.0 ? 1.0E-16 : t1869 ) ; t1690 = ( t1683 -
2000.0 ) / 2000.0 ; t1691 = t1690 * t1690 * 3.0 - t1690 * t1690 * t1690 * 2.0
; if ( t1683 <= 2000.0 ) { t1690 = 3.66 ; } else if ( t1683 >= 4000.0 ) {
t1690 = t1689 ; } else { t1690 = ( 1.0 - t1691 ) * 3.66 + t1689 * t1691 ; }
t1871 = t1690 * 0.15707963267948966 ; t1874 = t1865 / 2.0 ; if ( t1683 >
t1871 / 0.0019634954084936209 / ( t1874 == 0.0 ? 1.0E-16 : t1874 ) / 30.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = ( t1303 +
intrm_sf_mf_829 ) / 2.0 ; t1689 = t1690 * 0.15707963267948966 / ( t1683 ==
0.0 ? 1.0E-16 : t1683 ) / 0.0019634954084936209 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 ) ;
} else { t1689 = 30.0 ; } if ( X [ 322ULL ] * 0.0019634954084936209 <=
1.9634954084936209E-11 ) { intrm_sf_mf_829 = 1.9634954084936209E-11 ; } else
if ( X [ 322ULL ] * 0.0019634954084936209 >= 0.0012566370614359179 ) {
intrm_sf_mf_829 = 0.0012566370614359179 ; } else { intrm_sf_mf_829 = X [
322ULL ] * 0.0019634954084936209 ; } t1690 = intrm_sf_mf_829 /
0.0019634954084936209 ; if ( X [ 345ULL ] <= 0.0 ) { t1691 = 0.0 ; } else {
t1691 = X [ 345ULL ] >= 1.0 ? 1.0 : X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0
) { t1692 = 0.0 ; } else { t1692 = X [ 346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ;
} t1693 = ( ( ( 1.0 - t1691 ) - t1692 ) * 296.802103844292 + t1691 * 461.523
) + t1692 * 259.836612622973 ; t1882 = X [ 343ULL ] * t1693 ; t1694 = X [
344ULL ] / ( t1882 == 0.0 ? 1.0E-16 : t1882 ) ; t1303 = X [ 344ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ;
intrm_sf_mf_848 = X [ 344ULL ] / 1.01325 * ( X [ 348ULL ] / ( X [ 343ULL ] ==
0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; t1700 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 + 1.01325 ) /
2.0 * 0.0010000000000000009 ; t1698 = ( 1.0 - t1690 ) * ( 1.0 - t1690 ) ;
t1701 = t1700 * t1698 ; t1702 = ( t1690 + 1.0 ) * ( 1.0 - t1690 * t1303 ) - (
1.0 - t1690 * intrm_sf_mf_848 ) * t1690 * 2.0 ; t1091_idx_0 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( t1702 >= t1698 ? t1702 : t1698 ) ; t1702 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t1700 == 0.0 ? 1.0E-16 : t1700 ) ; t1704 = t1702 * t1702 * 3.0 - t1702 *
t1702 * t1702 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { t1702 = t1701 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t1700 ) { t1702 = t1091_idx_0 ; } else { t1702 = ( 1.0 - t1704 ) * t1701 +
t1091_idx_0 * t1704 ; } t1091_idx_0 = ( t1690 + 1.0 ) * ( 1.0 - t1690 *
intrm_sf_mf_848 ) - ( 1.0 - t1690 * t1303 ) * t1690 * 2.0 ; t1690 = ( 1.01325
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) * (
t1091_idx_0 >= t1698 ? t1091_idx_0 : t1698 ) ; t1303 = ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / ( t1700 ==
0.0 ? 1.0E-16 : t1700 ) ; intrm_sf_mf_848 = t1303 * t1303 * 3.0 - t1303 *
t1303 * t1303 * 2.0 ; if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <= 0.0 ) {
t1303 = t1701 ; } else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t1700 ) {
t1303 = t1690 ; } else { t1303 = ( 1.0 - intrm_sf_mf_848 ) * t1701 + t1690 *
intrm_sf_mf_848 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 ) {
t1690 = t1702 ; } else { t1690 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
t1303 : t1701 ; } if ( X [ 343ULL ] <= 216.59999999999997 ) { t1303 =
216.59999999999997 ; } else { t1303 = X [ 343ULL ] >= 623.15 ? 623.15 : X [
343ULL ] ; } t1707 = t1303 * t1303 ; intrm_sf_mf_848 = ( ( (
1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1707 *
0.0003721298010901061 ) * ( ( 1.0 - t1691 ) - t1692 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1707 * -
0.00038614513167845434 ) * t1691 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1707 * 0.00036936011832051582 ) * t1692 ; t1892 =
intrm_sf_mf_848 - t1693 ; t1893 = X [ 344ULL ] * X [ 344ULL ] * (
intrm_sf_mf_848 / ( t1892 == 0.0 ? 1.0E-16 : t1892 ) ) ; t1691 = pmf_sqrt (
fabs ( t1893 / ( t1693 == 0.0 ? 1.0E-16 : t1693 ) / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ) * intrm_sf_mf_829 * 0.64 ; if ( X [ 45ULL ] <=
0.0 ) { t1692 = 0.0 ; } else { t1692 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ]
; } if ( X [ 44ULL ] <= 0.0 ) { t1698 = 0.0 ; } else { t1698 = X [ 44ULL ] >=
1.0 ? 1.0 : X [ 44ULL ] ; } t1701 = ( ( ( 1.0 - t1692 ) - t1698 ) *
296.802103844292 + t1692 * 461.523 ) + t1698 * 259.836612622973 ; t1702 = ( X
[ 43ULL ] / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) - X [ 369ULL ] / (
X [ 370ULL ] == 0.0 ? 1.0E-16 : X [ 370ULL ] ) ) * X [ 368ULL ] * t1701 /
0.44 ; if ( X [ 369ULL ] <= 216.59999999999997 ) { t1091_idx_0 =
216.59999999999997 ; } else { t1091_idx_0 = X [ 369ULL ] >= 623.15 ? 623.15 :
X [ 369ULL ] ; } t1376 = t1091_idx_0 * t1091_idx_0 ; t1704 = ( ( (
1074.1165326382554 + t1091_idx_0 * - 0.22145652610641059 ) + t1376 *
0.0003721298010901061 ) * ( ( 1.0 - t1692 ) - t1698 ) + ( (
1479.6504774710402 + t1091_idx_0 * 1.2002114337050787 ) + t1376 * -
0.00038614513167845434 ) * t1692 ) + ( ( 900.639412248396 + t1091_idx_0 * -
0.044484923911441127 ) + t1376 * 0.00036936011832051582 ) * t1698 ; t1901 =
t1704 - t1701 ; t1707 = t1704 / ( t1901 == 0.0 ? 1.0E-16 : t1901 ) ; t1376 =
pmf_sqrt ( t1702 * t1702 * 9.999999999999999E-14 + fabs ( X [ 369ULL ] *
t1707 * t1701 ) * 1.0E-9 ) ; if ( X [ 356ULL ] <= 0.0 ) { t1709 = 0.0 ; }
else { t1709 = X [ 356ULL ] >= 1.0 ? 1.0 : X [ 356ULL ] ; } if ( X [ 358ULL ]
<= 0.0 ) { t1710 = 0.0 ; } else { t1710 = X [ 358ULL ] >= 1.0 ? 1.0 : X [
358ULL ] ; } t1100 [ 0ULL ] = X [ 43ULL ] ; tlu2_linear_nearest_prelookup ( &
tg_efOut . mField0 [ 0ULL ] , & tg_efOut . mField1 [ 0ULL ] , & tg_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [
0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = tg_efOut ;
tlu2_1d_linear_nearest_value ( & ug_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ug_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & vg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = vg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & wg_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = wg_efOut [ 0 ] ; t1711
= ( ( ( 1.0 - t1709 ) - t1710 ) * t1091_idx_0 + t1098_idx_0 * t1709 ) +
t1096_idx_0 * t1710 ; t1902 = X [ 370ULL ] * X [ 370ULL ] * t1707 ; t1712 = -
pmf_sqrt ( fabs ( t1902 / ( t1701 == 0.0 ? 1.0E-16 : t1701 ) / ( X [ 369ULL ]
== 0.0 ? 1.0E-16 : X [ 369ULL ] ) ) ) * 0.44 ; if ( t1712 >= 0.0 ) { t1713 =
t1712 * 100000.0 ; } else { t1713 = - t1712 * 100000.0 ; } t1906 = t1711 *
0.44 ; t1303 = t1713 * 0.01 / ( t1906 == 0.0 ? 1.0E-16 : t1906 ) ;
t1091_idx_0 = X [ 43ULL ] * t1701 ; t1715 = X [ 49ULL ] / ( t1091_idx_0 ==
0.0 ? 1.0E-16 : t1091_idx_0 ) ; t1910 = t1715 * 8.8000000000000011E-5 ; t1716
= t1712 * t1711 * 2.9973120849090416 / ( t1910 == 0.0 ? 1.0E-16 : t1910 ) ;
t1718 = t1303 >= 1.0 ? t1303 : 1.0 ; t1911 = pmf_log10 ( 6.9 / ( t1718 == 0.0
? 1.0E-16 : t1718 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1718 ==
0.0 ? 1.0E-16 : t1718 ) + 0.00017169489553429715 ) * 3.24 ; t1913 = t1715 *
0.003872 ; t1713 = t1712 * t1713 * ( 1.0 / ( t1911 == 0.0 ? 1.0E-16 : t1911 )
) * 0.046833001326703774 / ( t1913 == 0.0 ? 1.0E-16 : t1913 ) ; t1719 = (
t1303 - 2000.0 ) / 2000.0 ; t1091_idx_0 = t1719 * t1719 * 3.0 - t1719 * t1719
* t1719 * 2.0 ; if ( t1303 <= 2000.0 ) { t1719 = t1716 * 1.0E-5 ; } else if (
t1303 >= 4000.0 ) { t1719 = t1713 * 1.0E-5 ; } else { t1719 = ( ( 1.0 -
t1091_idx_0 ) * t1716 + t1713 * t1091_idx_0 ) * 1.0E-5 ; } t1376 = X [ 368ULL
] * t1376 / 0.44 * 0.00031622776601683789 + t1719 ; t1713 = ( X [ 43ULL ] / (
X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) - X [ 372ULL ] / ( X [ 373ULL ]
== 0.0 ? 1.0E-16 : X [ 373ULL ] ) ) * X [ 371ULL ] * t1701 / 0.44 ; if ( X [
372ULL ] <= 216.59999999999997 ) { t1303 = 216.59999999999997 ; } else {
t1303 = X [ 372ULL ] >= 623.15 ? 623.15 : X [ 372ULL ] ; } t1722 = t1303 *
t1303 ; t1716 = ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) +
t1722 * 0.0003721298010901061 ) * ( ( 1.0 - t1692 ) - t1698 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1722 * -
0.00038614513167845434 ) * t1692 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1722 * 0.00036936011832051582 ) * t1698 ; t1921 =
t1716 - t1701 ; t1692 = t1716 / ( t1921 == 0.0 ? 1.0E-16 : t1921 ) ; t1698 =
pmf_sqrt ( t1713 * t1713 * 9.999999999999999E-14 + fabs ( X [ 372ULL ] *
t1692 * t1701 ) * 1.0E-9 ) ; t1922 = X [ 373ULL ] * X [ 373ULL ] * t1692 ;
t1719 = - pmf_sqrt ( fabs ( t1922 / ( t1701 == 0.0 ? 1.0E-16 : t1701 ) / ( X
[ 372ULL ] == 0.0 ? 1.0E-16 : X [ 372ULL ] ) ) ) * 0.44 ; if ( t1719 >= 0.0 )
{ t1091_idx_0 = t1719 * 100000.0 ; } else { t1091_idx_0 = - t1719 * 100000.0
; } t1722 = t1091_idx_0 * 0.01 / ( t1906 == 0.0 ? 1.0E-16 : t1906 ) ; t1724 =
t1719 * t1711 * 2.9973120849090416 / ( t1910 == 0.0 ? 1.0E-16 : t1910 ) ;
t1727 = t1722 >= 1.0 ? t1722 : 1.0 ; t1303 = pmf_log10 ( 6.9 / ( t1727 == 0.0
? 1.0E-16 : t1727 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1727 ==
0.0 ? 1.0E-16 : t1727 ) + 0.00017169489553429715 ) * 3.24 ; t1091_idx_0 =
t1719 * t1091_idx_0 * ( 1.0 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ) *
0.046833001326703774 / ( t1913 == 0.0 ? 1.0E-16 : t1913 ) ; intrm_sf_mf_898 =
( t1722 - 2000.0 ) / 2000.0 ; t1729 = intrm_sf_mf_898 * intrm_sf_mf_898 * 3.0
- intrm_sf_mf_898 * intrm_sf_mf_898 * intrm_sf_mf_898 * 2.0 ; if ( t1722 <=
2000.0 ) { intrm_sf_mf_898 = t1724 * 1.0E-5 ; } else if ( t1722 >= 4000.0 ) {
intrm_sf_mf_898 = t1091_idx_0 * 1.0E-5 ; } else { intrm_sf_mf_898 = ( ( 1.0 -
t1729 ) * t1724 + t1091_idx_0 * t1729 ) * 1.0E-5 ; } t1698 = X [ 371ULL ] *
t1698 / 0.44 * 0.00031622776601683789 + intrm_sf_mf_898 ; if ( 1.0 - X [
45ULL ] >= 0.01 ) { t1722 = 1.0 - X [ 45ULL ] ; } else if ( 1.0 - X [ 45ULL ]
>= - 0.1 ) { t1722 = pmf_exp ( ( ( 1.0 - X [ 45ULL ] ) - 0.01 ) / 0.01 ) *
0.01 ; } else { t1722 = 1.6701700790245661E-7 ; } t1724 = X [ 44ULL ] / (
t1722 == 0.0 ? 1.0E-16 : t1722 ) * - 36.965491221318985 + 296.802103844292 ;
t1100 [ 0ULL ] = X [ 43ULL ] ; tlu2_linear_linear_prelookup ( & xg_efOut .
mField0 [ 0ULL ] , & xg_efOut . mField1 [ 0ULL ] , & xg_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t128 = xg_efOut ;
tlu2_1d_linear_linear_value ( & yg_efOut [ 0ULL ] , & t128 . mField0 [ 0ULL ]
, & t128 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t918 [ 0 ] = yg_efOut [ 0 ] ;
intrm_sf_mf_898 = pmf_exp ( pmf_log ( X [ 49ULL ] * 100000.0 ) - t918 [ 0ULL
] ) ; if ( intrm_sf_mf_898 >= 1.0 ) { t1303 = ( intrm_sf_mf_898 - 1.0 ) *
461.523 + t1724 ; t1729 = t1724 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else
{ t1729 = 1.0 ; } if ( X [ 367ULL ] <= 0.0 ) { t1469 = 0.0 ; } else { t1469 =
X [ 367ULL ] >= 1.0 ? 1.0 : X [ 367ULL ] ; } if ( X [ 366ULL ] <= 0.0 ) {
t1731 = 0.0 ; } else { t1731 = X [ 366ULL ] >= 1.0 ? 1.0 : X [ 366ULL ] ; }
t1732 = ( ( ( 1.0 - t1469 ) - t1731 ) * 296.802103844292 + t1469 * 461.523 )
+ t1731 * 259.836612622973 ; t1469 = X [ 367ULL ] * 461.523 / ( t1732 == 0.0
? 1.0E-16 : t1732 ) ; if ( t1469 <= 0.0 ) { t1731 = 0.0 ; } else { t1731 =
t1469 >= 1.0 ? 1.0 : t1469 ; } t1469 = X [ 366ULL ] * 259.836612622973 / (
t1732 == 0.0 ? 1.0E-16 : t1732 ) ; if ( t1469 <= 0.0 ) { t1733 = 0.0 ; } else
{ t1733 = t1469 >= 1.0 ? 1.0 : t1469 ; } t1100 [ 0ULL ] = X [ 364ULL ] ;
tlu2_linear_nearest_prelookup ( & ah_efOut . mField0 [ 0ULL ] , & ah_efOut .
mField1 [ 0ULL ] , & ah_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = ah_efOut ; tlu2_1d_linear_nearest_value ( & bh_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = bh_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & ch_efOut [ 0ULL ] , & t74 . mField0
[ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = ch_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & dh_efOut [ 0ULL ] , & t74 . mField0 [ 0ULL
] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = dh_efOut [ 0 ] ; t1469
= ( ( ( 1.0 - t1731 ) - t1733 ) * t1091_idx_0 + t1098_idx_0 * t1731 ) +
t1096_idx_0 * t1733 ; tlu2_1d_linear_nearest_value ( & eh_efOut [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
eh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & fh_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
fh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & gh_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
gh_efOut [ 0 ] ; t1303 = ( ( ( 1.0 - t1709 ) - t1710 ) * t1091_idx_0 +
t1098_idx_0 * t1709 ) + t1096_idx_0 * t1710 ; t1709 = ( X [ 368ULL ] - X [
371ULL ] ) / 2.0 ; tlu2_1d_linear_nearest_value ( & hh_efOut [ 0ULL ] , & t74
. mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
hh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ih_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = ih_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & jh_efOut [ 0ULL ] , & t74 . mField0
[ 0ULL ] , & t74 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField28 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = jh_efOut [ 0 ]
; t1738 = ( ( ( 1.0 - t1731 ) - t1733 ) * t1091_idx_0 + t1098_idx_0 * t1731 )
+ t1096_idx_0 * t1733 ; t1940 = t1711 + t1738 ; t1942 = t1940 / 2.0 * 0.44 ;
t1710 = ( t1709 >= 0.0 ? t1709 : 0.0 ) * 0.01 / ( t1942 == 0.0 ? 1.0E-16 :
t1942 ) ; t1731 = t1710 >= 0.0 ? t1710 : - t1710 ; t1710 = t1731 > 1000.0 ?
t1731 : 1000.0 ; t1943 = t1469 + t1303 ; if ( t1943 / 2.0 > 0.5 ) { t1733 = (
t1469 + t1303 ) / 2.0 ; } else { t1733 = 0.5 ; } t1945 = pmf_log10 ( 6.9 / (
t1710 == 0.0 ? 1.0E-16 : t1710 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t1710 == 0.0 ? 1.0E-16 : t1710 ) + 0.00017169489553429715 ) * 3.24 ;
t1739 = 1.0 / ( t1945 == 0.0 ? 1.0E-16 : t1945 ) ; t1947 = ( pmf_pow ( t1733
, 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1739 / 8.0 ) * 12.7 + 1.0 ;
t1740 = ( t1710 - 1000.0 ) * ( t1739 / 8.0 ) * t1733 / ( t1947 == 0.0 ?
1.0E-16 : t1947 ) ; t1742 = ( t1731 - 2000.0 ) / 2000.0 ; t1744 = t1742 *
t1742 * 3.0 - t1742 * t1742 * t1742 * 2.0 ; if ( t1731 <= 2000.0 ) { t1742 =
3.66 ; } else if ( t1731 >= 4000.0 ) { t1742 = t1740 ; } else { t1742 = ( 1.0
- t1744 ) * 3.66 + t1740 * t1744 ; } t1949 = t1742 * 14.725216466999729 ;
t1952 = t1943 / 2.0 ; if ( t1731 > t1949 / 0.44 / ( t1952 == 0.0 ? 1.0E-16 :
t1952 ) / 30.0 ) { t1958 = ( t1469 + t1303 ) / 2.0 ; t1740 = t1742 *
14.725216466999729 / ( t1731 == 0.0 ? 1.0E-16 : t1731 ) / 0.44 / ( t1958 ==
0.0 ? 1.0E-16 : t1958 ) ; } else { t1740 = 30.0 ; } if ( X [ 353ULL ] <= 0.0
) { t1742 = 0.0 ; } else { t1742 = X [ 353ULL ] >= 1.0 ? 1.0 : X [ 353ULL ] ;
} if ( X [ 352ULL ] <= 0.0 ) { t1744 = 0.0 ; } else { t1744 = X [ 352ULL ] >=
1.0 ? 1.0 : X [ 352ULL ] ; } t1746 = ( ( ( 1.0 - t1742 ) - t1744 ) *
296.802103844292 + t1742 * 461.523 ) + t1744 * 259.836612622973 ; t1742 = X [
353ULL ] * 461.523 / ( t1746 == 0.0 ? 1.0E-16 : t1746 ) ; if ( t1742 <= 0.0 )
{ t1744 = 0.0 ; } else { t1744 = t1742 >= 1.0 ? 1.0 : t1742 ; } t1742 = X [
352ULL ] * 259.836612622973 / ( t1746 == 0.0 ? 1.0E-16 : t1746 ) ; if ( t1742
<= 0.0 ) { t1748 = 0.0 ; } else { t1748 = t1742 >= 1.0 ? 1.0 : t1742 ; }
t1100 [ 0ULL ] = X [ 350ULL ] ; tlu2_linear_nearest_prelookup ( & kh_efOut .
mField0 [ 0ULL ] , & kh_efOut . mField1 [ 0ULL ] , & kh_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t122 = kh_efOut ;
tlu2_1d_linear_nearest_value ( & lh_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = lh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & mh_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = mh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & nh_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField30
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = nh_efOut [ 0 ] ; t1742
= ( ( ( 1.0 - t1744 ) - t1748 ) * t1091_idx_0 + t1098_idx_0 * t1744 ) +
t1096_idx_0 * t1748 ; t1749 = t1709 <= 0.0 ? t1709 : 0.0 ;
tlu2_1d_linear_nearest_value ( & oh_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = oh_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ph_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = ph_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & qh_efOut [ 0ULL ] , & t122 . mField0 [ 0ULL
] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = qh_efOut [ 0 ] ; t1709
= ( ( ( 1.0 - t1744 ) - t1748 ) * t1091_idx_0 + t1098_idx_0 * t1744 ) +
t1096_idx_0 * t1748 ; t1961 = t1711 + t1709 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = t1961 / 2.0
* 0.44 ; t1744 = - t1749 * 0.01 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 ) ;
t1748 = t1744 >= 0.0 ? t1744 : - t1744 ; t1744 = t1748 > 1000.0 ? t1748 :
1000.0 ; t1964 = t1303 + t1742 ; if ( t1964 / 2.0 > 0.5 ) { t1749 = ( t1303 +
t1742 ) / 2.0 ; } else { t1749 = 0.5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 = pmf_log10 (
6.9 / ( t1744 == 0.0 ? 1.0E-16 : t1744 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1744 == 0.0 ? 1.0E-16 : t1744 ) + 0.00017169489553429715
) * 3.24 ; t1751 = 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 = ( pmf_pow (
t1749 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1751 / 8.0 ) * 12.7 + 1.0
; t1752 = ( t1744 - 1000.0 ) * ( t1751 / 8.0 ) * t1749 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 ) ;
t1753 = ( t1748 - 2000.0 ) / 2000.0 ; t1754 = t1753 * t1753 * 3.0 - t1753 *
t1753 * t1753 * 2.0 ; if ( t1748 <= 2000.0 ) { t1753 = 3.66 ; } else if (
t1748 >= 4000.0 ) { t1753 = t1752 ; } else { t1753 = ( 1.0 - t1754 ) * 3.66 +
t1752 * t1754 ; } t1970 = t1753 * 14.725216466999729 ; t1973 = t1964 / 2.0 ;
if ( t1748 > t1970 / 0.44 / ( t1973 == 0.0 ? 1.0E-16 : t1973 ) / 30.0 ) {
t1979 = ( t1303 + t1742 ) / 2.0 ; t1752 = t1753 * 14.725216466999729 / (
t1748 == 0.0 ? 1.0E-16 : t1748 ) / 0.44 / ( t1979 == 0.0 ? 1.0E-16 : t1979 )
; } else { t1752 = 30.0 ; } if ( X [ 48ULL ] <= 0.0 ) { t1753 = 0.0 ; } else
{ t1753 = X [ 48ULL ] >= 1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0
) { t1754 = 0.0 ; } else { t1754 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ; }
t1755 = ( ( ( 1.0 - t1753 ) - t1754 ) * 296.802103844292 + t1753 * 461.523 )
+ t1754 * 259.836612622973 ; t1756 = - ( ( X [ 46ULL ] / ( X [ 50ULL ] == 0.0
? 1.0E-16 : X [ 50ULL ] ) - X [ 387ULL ] / ( X [ 388ULL ] == 0.0 ? 1.0E-16 :
X [ 388ULL ] ) ) * X [ 371ULL ] * t1755 ) / 0.44 ; if ( X [ 387ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
387ULL ] >= 623.15 ? 623.15 : X [ 387ULL ] ; } t1760 = t1303 * t1303 ; t1758
= ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1760 *
0.0003721298010901061 ) * ( ( 1.0 - t1753 ) - t1754 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1760 * -
0.00038614513167845434 ) * t1753 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1760 * 0.00036936011832051582 ) * t1754 ; t1985 =
t1758 - t1755 ; t1760 = t1758 / ( t1985 == 0.0 ? 1.0E-16 : t1985 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 = pmf_sqrt (
t1756 * t1756 * 9.999999999999999E-14 + fabs ( X [ 387ULL ] * t1760 * t1755 )
* 1.0E-9 ) ; if ( X [ 361ULL ] <= 0.0 ) { t1763 = 0.0 ; } else { t1763 = X [
361ULL ] >= 1.0 ? 1.0 : X [ 361ULL ] ; } if ( X [ 363ULL ] <= 0.0 ) { t1764 =
0.0 ; } else { t1764 = X [ 363ULL ] >= 1.0 ? 1.0 : X [ 363ULL ] ; } t1100 [
0ULL ] = X [ 46ULL ] ; tlu2_linear_nearest_prelookup ( & rh_efOut . mField0 [
0ULL ] , & rh_efOut . mField1 [ 0ULL ] , & rh_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t116 = rh_efOut ; tlu2_1d_linear_nearest_value ( &
sh_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1091_idx_0 = sh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
th_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1098_idx_0 = th_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
uh_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField28 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1096_idx_0 = uh_efOut [ 0 ] ; t1765 = ( ( ( 1.0 - t1763 ) - t1764 ) *
t1091_idx_0 + t1098_idx_0 * t1763 ) + t1096_idx_0 * t1764 ; t1986 = X [
388ULL ] * X [ 388ULL ] * t1760 ; t1766 = - pmf_sqrt ( fabs ( t1986 / ( t1755
== 0.0 ? 1.0E-16 : t1755 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X [ 387ULL ] )
) ) * 0.44 ; if ( t1766 >= 0.0 ) { t1767 = t1766 * 100000.0 ; } else { t1767
= - t1766 * 100000.0 ; } t1990 = t1765 * 0.44 ; t1303 = t1767 * 0.01 / (
t1990 == 0.0 ? 1.0E-16 : t1990 ) ; intrm_sf_mf_1300 = X [ 46ULL ] * t1755 ;
t1771 = X [ 50ULL ] / ( intrm_sf_mf_1300 == 0.0 ? 1.0E-16 : intrm_sf_mf_1300
) ; intrm_sf_mf_1327 = t1771 * 8.8000000000000011E-5 ; t1772 = t1766 * t1765
* 2.9973120849090416 / ( intrm_sf_mf_1327 == 0.0 ? 1.0E-16 : intrm_sf_mf_1327
) ; t1773 = t1303 >= 1.0 ? t1303 : 1.0 ; t1995 = pmf_log10 ( 6.9 / ( t1773 ==
0.0 ? 1.0E-16 : t1773 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t1773 == 0.0 ? 1.0E-16 : t1773 ) + 0.00017169489553429715 ) * 3.24 ;
intrm_sf_mf_1340 = t1771 * 0.003872 ; t1767 = t1766 * t1767 * ( 1.0 / ( t1995
== 0.0 ? 1.0E-16 : t1995 ) ) * 0.046833001326703774 / ( intrm_sf_mf_1340 ==
0.0 ? 1.0E-16 : intrm_sf_mf_1340 ) ; t1774 = ( t1303 - 2000.0 ) / 2000.0 ;
t1091_idx_0 = t1774 * t1774 * 3.0 - t1774 * t1774 * t1774 * 2.0 ; if ( t1303
<= 2000.0 ) { t1774 = t1772 * 1.0E-5 ; } else if ( t1303 >= 4000.0 ) { t1774
= t1767 * 1.0E-5 ; } else { t1774 = ( ( 1.0 - t1091_idx_0 ) * t1772 + t1767 *
t1091_idx_0 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 = - ( X [
371ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 ) /
0.44 * 0.00031622776601683789 + t1774 ; t1767 = - ( ( X [ 46ULL ] / ( X [
50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) - X [ 389ULL ] / ( X [ 390ULL ] ==
0.0 ? 1.0E-16 : X [ 390ULL ] ) ) * X [ 325ULL ] * t1755 ) / 0.44 ; if ( X [
389ULL ] <= 216.59999999999997 ) { t1303 = 216.59999999999997 ; } else {
t1303 = X [ 389ULL ] >= 623.15 ? 623.15 : X [ 389ULL ] ; } t1776 = t1303 *
t1303 ; t1772 = ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) +
t1776 * 0.0003721298010901061 ) * ( ( 1.0 - t1753 ) - t1754 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1776 * -
0.00038614513167845434 ) * t1753 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1776 * 0.00036936011832051582 ) * t1754 ; t2005 =
t1772 - t1755 ; t1753 = t1772 / ( t2005 == 0.0 ? 1.0E-16 : t2005 ) ; t1754 =
pmf_sqrt ( t1767 * t1767 * 9.999999999999999E-14 + fabs ( X [ 389ULL ] *
t1753 * t1755 ) * 1.0E-9 ) ; t2006 = X [ 390ULL ] * X [ 390ULL ] * t1753 ;
t1774 = - pmf_sqrt ( fabs ( t2006 / ( t1755 == 0.0 ? 1.0E-16 : t1755 ) / ( X
[ 389ULL ] == 0.0 ? 1.0E-16 : X [ 389ULL ] ) ) ) * 0.44 ; if ( t1774 >= 0.0 )
{ t1091_idx_0 = t1774 * 100000.0 ; } else { t1091_idx_0 = - t1774 * 100000.0
; } t1776 = t1091_idx_0 * 0.01 / ( t1990 == 0.0 ? 1.0E-16 : t1990 ) ; t1777 =
t1774 * t1765 * 2.9973120849090416 / ( intrm_sf_mf_1327 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1327 ) ; t1779 = t1776 >= 1.0 ? t1776 : 1.0 ; t2013 = pmf_log10 (
6.9 / ( t1779 == 0.0 ? 1.0E-16 : t1779 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1779 == 0.0 ? 1.0E-16 : t1779 ) + 0.00017169489553429715
) * 3.24 ; t1091_idx_0 = t1774 * t1091_idx_0 * ( 1.0 / ( t2013 == 0.0 ?
1.0E-16 : t2013 ) ) * 0.046833001326703774 / ( intrm_sf_mf_1340 == 0.0 ?
1.0E-16 : intrm_sf_mf_1340 ) ; t1780 = ( t1776 - 2000.0 ) / 2000.0 ; t1782 =
t1780 * t1780 * 3.0 - t1780 * t1780 * t1780 * 2.0 ; if ( t1776 <= 2000.0 ) {
t1780 = t1777 * 1.0E-5 ; } else if ( t1776 >= 4000.0 ) { t1780 = t1091_idx_0
* 1.0E-5 ; } else { t1780 = ( ( 1.0 - t1782 ) * t1777 + t1091_idx_0 * t1782 )
* 1.0E-5 ; } t1754 = - ( X [ 325ULL ] * t1754 ) / 0.44 *
0.00031622776601683789 + t1780 ; if ( 1.0 - X [ 48ULL ] >= 0.01 ) { t1776 =
1.0 - X [ 48ULL ] ; } else if ( 1.0 - X [ 48ULL ] >= - 0.1 ) { t1776 =
pmf_exp ( ( ( 1.0 - X [ 48ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1776 =
1.6701700790245661E-7 ; } t1777 = X [ 47ULL ] / ( t1776 == 0.0 ? 1.0E-16 :
t1776 ) * - 36.965491221318985 + 296.802103844292 ; t1100 [ 0ULL ] = X [
46ULL ] ; tlu2_linear_linear_prelookup ( & vh_efOut . mField0 [ 0ULL ] , &
vh_efOut . mField1 [ 0ULL ] , & vh_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t128 = vh_efOut ; tlu2_1d_linear_linear_value ( &
wh_efOut [ 0ULL ] , & t128 . mField0 [ 0ULL ] , & t128 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t186 [ 0 ] = wh_efOut [ 0 ] ; t1780 = pmf_exp ( pmf_log ( X [ 50ULL ] *
100000.0 ) - t186 [ 0ULL ] ) ; if ( t1780 >= 1.0 ) { t2020 = ( t1780 - 1.0 )
* 461.523 + t1777 ; t1782 = t1777 / ( t2020 == 0.0 ? 1.0E-16 : t2020 ) ; }
else { t1782 = 1.0 ; } tlu2_1d_linear_nearest_value ( & xh_efOut [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
xh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & yh_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
yh_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ai_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
ai_efOut [ 0 ] ; t1783 = ( ( ( 1.0 - t1763 ) - t1764 ) * t1091_idx_0 +
t1098_idx_0 * t1763 ) + t1096_idx_0 * t1764 ; t1763 = ( - X [ 371ULL ] - ( -
X [ 325ULL ] ) ) / 2.0 ; t2022 = t1765 + t1709 ; t2024 = t2022 / 2.0 * 0.44 ;
t1709 = ( t1763 >= 0.0 ? t1763 : 0.0 ) * 0.01 / ( t2024 == 0.0 ? 1.0E-16 :
t2024 ) ; t1764 = t1709 >= 0.0 ? t1709 : - t1709 ; t1709 = t1764 > 1000.0 ?
t1764 : 1000.0 ; t2025 = t1783 + t1742 ; if ( t2025 / 2.0 > 0.5 ) { t1784 = (
t1783 + t1742 ) / 2.0 ; } else { t1784 = 0.5 ; } t2027 = pmf_log10 ( 6.9 / (
t1709 == 0.0 ? 1.0E-16 : t1709 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t1709 == 0.0 ? 1.0E-16 : t1709 ) + 0.00017169489553429715 ) * 3.24 ;
t1785 = 1.0 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) ; t2036 = ( pmf_pow ( t1784
, 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1785 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_1066 = ( t1709 - 1000.0 ) * ( t1785 / 8.0 ) * t1784 / ( t2036 ==
0.0 ? 1.0E-16 : t2036 ) ; intrm_sf_mf_1085 = ( t1764 - 2000.0 ) / 2000.0 ;
t1790 = intrm_sf_mf_1085 * intrm_sf_mf_1085 * 3.0 - intrm_sf_mf_1085 *
intrm_sf_mf_1085 * intrm_sf_mf_1085 * 2.0 ; if ( t1764 <= 2000.0 ) {
intrm_sf_mf_1085 = 3.66 ; } else if ( t1764 >= 4000.0 ) { intrm_sf_mf_1085 =
intrm_sf_mf_1066 ; } else { intrm_sf_mf_1085 = ( 1.0 - t1790 ) * 3.66 +
intrm_sf_mf_1066 * t1790 ; } t2031 = intrm_sf_mf_1085 * 14.725216466999729 ;
t2044 = t2025 / 2.0 ; if ( t1764 > t2031 / 0.44 / ( t2044 == 0.0 ? 1.0E-16 :
t2044 ) / 30.0 ) { t1303 = ( t1783 + t1742 ) / 2.0 ; intrm_sf_mf_1066 =
intrm_sf_mf_1085 * 14.725216466999729 / ( t1764 == 0.0 ? 1.0E-16 : t1764 ) /
0.44 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else { intrm_sf_mf_1066 = 30.0
; } t2036 = t1765 + intrm_sf_mf_1083 ; t2050 = t2036 / 2.0 * 0.44 ;
intrm_sf_mf_1083 = - ( t1763 <= 0.0 ? t1763 : 0.0 ) * 0.01 / ( t2050 == 0.0 ?
1.0E-16 : t2050 ) ; t1742 = intrm_sf_mf_1083 >= 0.0 ? intrm_sf_mf_1083 : -
intrm_sf_mf_1083 ; intrm_sf_mf_1083 = t1742 > 1000.0 ? t1742 : 1000.0 ; t2044
= t1783 + U_idx_3 ; if ( t2044 / 2.0 > 0.5 ) { t1763 = ( t1783 + U_idx_3 ) /
2.0 ; } else { t1763 = 0.5 ; } t2050 = pmf_log10 ( 6.9 / ( intrm_sf_mf_1083
== 0.0 ? 1.0E-16 : intrm_sf_mf_1083 ) + 0.00017169489553429715 ) * pmf_log10
( 6.9 / ( intrm_sf_mf_1083 == 0.0 ? 1.0E-16 : intrm_sf_mf_1083 ) +
0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_1085 = 1.0 / ( t2050 == 0.0 ?
1.0E-16 : t2050 ) ; t2085 = ( pmf_pow ( t1763 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( intrm_sf_mf_1085 / 8.0 ) * 12.7 + 1.0 ; t1790 = (
intrm_sf_mf_1083 - 1000.0 ) * ( intrm_sf_mf_1085 / 8.0 ) * t1763 / ( t2085 ==
0.0 ? 1.0E-16 : t2085 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = ( t1742 -
2000.0 ) / 2000.0 ; t1792 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 * 2.0 ; if (
t1742 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = 3.66 ; }
else if ( t1742 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = t1790 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = ( 1.0
- t1792 ) * 3.66 + t1790 * t1792 ; } t2050 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
14.725216466999729 ; t2100 = t2044 / 2.0 ; if ( t1742 > t2050 / 0.44 / (
t2100 == 0.0 ? 1.0E-16 : t2100 ) / 30.0 ) { t2070 = ( t1783 + U_idx_3 ) / 2.0
; t1790 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
14.725216466999729 / ( t1742 == 0.0 ? 1.0E-16 : t1742 ) / 0.44 / ( t2070 ==
0.0 ? 1.0E-16 : t2070 ) ; } else { t1790 = 30.0 ; } if ( X [ 53ULL ] <= 0.0 )
{ t1783 = 0.0 ; } else { t1783 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; }
if ( X [ 52ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = X [ 52ULL
] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t1792 = ( ( ( 1.0 - t1783 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ) *
296.802103844292 + t1783 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 *
259.836612622973 ; t1793 = ( X [ 51ULL ] / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X
[ 54ULL ] ) - X [ 414ULL ] / ( X [ 415ULL ] == 0.0 ? 1.0E-16 : X [ 415ULL ] )
) * X [ 413ULL ] * t1792 / 0.0019634954084936209 ; if ( X [ 414ULL ] <=
216.59999999999997 ) { t1303 = 216.59999999999997 ; } else { t1303 = X [
414ULL ] >= 623.15 ? 623.15 : X [ 414ULL ] ; } t1388 = t1303 * t1303 ; t1795
= ( ( ( 1074.1165326382554 + t1303 * - 0.22145652610641059 ) + t1388 *
0.0003721298010901061 ) * ( ( 1.0 - t1783 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ) + ( (
1479.6504774710402 + t1303 * 1.2002114337050787 ) + t1388 * -
0.00038614513167845434 ) * t1783 ) + ( ( 900.639412248396 + t1303 * -
0.044484923911441127 ) + t1388 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ; t2066 =
t1795 - t1792 ; t1388 = t1795 / ( t2066 == 0.0 ? 1.0E-16 : t2066 ) ; t1797 =
pmf_sqrt ( t1793 * t1793 * 9.999999999999999E-14 + fabs ( X [ 414ULL ] *
t1388 * t1792 ) * 1.0E-9 ) ; if ( X [ 410ULL ] <= 0.0 ) { intrm_sf_mf_1220 =
0.0 ; } else { intrm_sf_mf_1220 = X [ 410ULL ] >= 1.0 ? 1.0 : X [ 410ULL ] ;
} if ( X [ 409ULL ] <= 0.0 ) { t1800 = 0.0 ; } else { t1800 = X [ 409ULL ] >=
1.0 ? 1.0 : X [ 409ULL ] ; } t1100 [ 0ULL ] = X [ 51ULL ] ;
tlu2_linear_nearest_prelookup ( & bi_efOut . mField0 [ 0ULL ] , & bi_efOut .
mField1 [ 0ULL ] , & bi_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t87 = bi_efOut ; tlu2_1d_linear_nearest_value ( & ci_efOut [ 0ULL ] , & t87 .
mField0 [ 0ULL ] , & t87 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ci_efOut
[ 0 ] ; tlu2_1d_linear_nearest_value ( & di_efOut [ 0ULL ] , & t87 . mField0
[ 0ULL ] , & t87 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = di_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & ei_efOut [ 0ULL ] , & t87 . mField0 [ 0ULL
] , & t87 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = ei_efOut [ 0 ] ; t1801
= ( ( ( 1.0 - intrm_sf_mf_1220 ) - t1800 ) * t1091_idx_0 + t1098_idx_0 *
intrm_sf_mf_1220 ) + t1096_idx_0 * t1800 ; t2066 = X [ 415ULL ] * X [ 415ULL
] * t1388 ; t1802 = - pmf_sqrt ( fabs ( t2066 / ( t1792 == 0.0 ? 1.0E-16 :
t1792 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [ 414ULL ] ) ) ) *
0.0019634954084936209 ; if ( t1802 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 = t1802 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 = - t1802 *
100000.0 ; } t2070 = t1801 * 0.0019634954084936209 ; t1091_idx_0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 * 0.05 / (
t2070 == 0.0 ? 1.0E-16 : t2070 ) ; t1303 = X [ 51ULL ] * t1792 ; t1809 = X [
54ULL ] / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; t2107 = t1809 *
9.8174770424681068E-6 ; t1810 = t1802 * t1801 * 11.2 / ( t2107 == 0.0 ?
1.0E-16 : t2107 ) ; t1811 = t1091_idx_0 >= 1.0 ? t1091_idx_0 : 1.0 ; t1303 =
pmf_log10 ( 6.9 / ( t1811 == 0.0 ? 1.0E-16 : t1811 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1811 == 0.0 ? 1.0E-16 : t1811 ) +
2.8767404433520813E-5 ) * 3.24 ; t2110 = t1809 * 3.855314219175531E-7 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 = t1802 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 * ( 1.0 / (
t1303 == 0.0 ? 1.0E-16 : t1303 ) ) * 0.175 / ( t2110 == 0.0 ? 1.0E-16 : t2110
) ; t1812 = ( t1091_idx_0 - 2000.0 ) / 2000.0 ; t1303 = t1812 * t1812 * 3.0 -
t1812 * t1812 * t1812 * 2.0 ; if ( t1091_idx_0 <= 2000.0 ) { t1812 = t1810 *
1.0E-5 ; } else if ( t1091_idx_0 >= 4000.0 ) { t1812 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 * 1.0E-5 ; }
else { t1812 = ( ( 1.0 - t1303 ) * t1810 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 * t1303 ) *
1.0E-5 ; } t1797 = X [ 413ULL ] * t1797 / 0.0019634954084936209 *
0.00031622776601683789 + t1812 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 = - ( ( X [
51ULL ] / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) - X [ 416ULL ] / ( X
[ 417ULL ] == 0.0 ? 1.0E-16 : X [ 417ULL ] ) ) * X [ 368ULL ] * t1792 ) /
0.0019634954084936209 ; if ( X [ 416ULL ] <= 216.59999999999997 ) {
t1091_idx_0 = 216.59999999999997 ; } else { t1091_idx_0 = X [ 416ULL ] >=
623.15 ? 623.15 : X [ 416ULL ] ; } t1814 = t1091_idx_0 * t1091_idx_0 ; t1810
= ( ( ( 1074.1165326382554 + t1091_idx_0 * - 0.22145652610641059 ) + t1814 *
0.0003721298010901061 ) * ( ( 1.0 - t1783 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ) + ( (
1479.6504774710402 + t1091_idx_0 * 1.2002114337050787 ) + t1814 * -
0.00038614513167845434 ) * t1783 ) + ( ( 900.639412248396 + t1091_idx_0 * -
0.044484923911441127 ) + t1814 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ; t2085 =
t1810 - t1792 ; t1783 = t1810 / ( t2085 == 0.0 ? 1.0E-16 : t2085 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ) ;
t2085 = X [ 417ULL ] * X [ 417ULL ] * t1783 ; t1812 = - pmf_sqrt ( fabs (
t2085 / ( t1792 == 0.0 ? 1.0E-16 : t1792 ) / ( X [ 416ULL ] == 0.0 ? 1.0E-16
: X [ 416ULL ] ) ) ) * 0.0019634954084936209 ; if ( t1812 >= 0.0 ) { t1303 =
t1812 * 100000.0 ; } else { t1303 = - t1812 * 100000.0 ; } t1814 = t1303 *
0.05 / ( t2070 == 0.0 ? 1.0E-16 : t2070 ) ; t1815 = t1812 * t1801 * 11.2 / (
t2107 == 0.0 ? 1.0E-16 : t2107 ) ; t1816 = t1814 >= 1.0 ? t1814 : 1.0 ; t2100
= pmf_log10 ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816
) + 2.8767404433520813E-5 ) * 3.24 ; t1303 = t1812 * t1303 * ( 1.0 / ( t2100
== 0.0 ? 1.0E-16 : t2100 ) ) * 0.175 / ( t2110 == 0.0 ? 1.0E-16 : t2110 ) ;
t1820 = ( t1814 - 2000.0 ) / 2000.0 ; t1821 = t1820 * t1820 * 3.0 - t1820 *
t1820 * t1820 * 2.0 ; if ( t1814 <= 2000.0 ) { t1820 = t1815 * 1.0E-5 ; }
else if ( t1814 >= 4000.0 ) { t1820 = t1303 * 1.0E-5 ; } else { t1820 = ( (
1.0 - t1821 ) * t1815 + t1303 * t1821 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 = - ( X [
368ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 ) /
0.0019634954084936209 * 0.00031622776601683789 + t1820 ; if ( 1.0 - X [ 53ULL
] >= 0.01 ) { t1814 = 1.0 - X [ 53ULL ] ; } else if ( 1.0 - X [ 53ULL ] >= -
0.1 ) { t1814 = pmf_exp ( ( ( 1.0 - X [ 53ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ;
} else { t1814 = 1.6701700790245661E-7 ; } t1815 = X [ 52ULL ] / ( t1814 ==
0.0 ? 1.0E-16 : t1814 ) * - 36.965491221318985 + 296.802103844292 ; t1100 [
0ULL ] = X [ 51ULL ] ; tlu2_linear_linear_prelookup ( & fi_efOut . mField0 [
0ULL ] , & fi_efOut . mField1 [ 0ULL ] , & fi_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL
] , & t140 [ 0ULL ] ) ; t123 = fi_efOut ; tlu2_1d_linear_linear_value ( &
gi_efOut [ 0ULL ] , & t123 . mField0 [ 0ULL ] , & t123 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t159 [ 0 ] = gi_efOut [ 0 ] ; t1820 = pmf_exp ( pmf_log ( X [ 54ULL ] *
100000.0 ) - t159 [ 0ULL ] ) ; if ( t1820 >= 1.0 ) { t2100 = ( t1820 - 1.0 )
* 461.523 + t1815 ; t1821 = t1815 / ( t2100 == 0.0 ? 1.0E-16 : t2100 ) ; }
else { t1821 = 1.0 ; } if ( X [ 405ULL ] <= 0.0 ) { t1822 = 0.0 ; } else {
t1822 = X [ 405ULL ] >= 1.0 ? 1.0 : X [ 405ULL ] ; } if ( X [ 404ULL ] <= 0.0
) { t1824 = 0.0 ; } else { t1824 = X [ 404ULL ] >= 1.0 ? 1.0 : X [ 404ULL ] ;
} t1826 = ( ( ( 1.0 - t1822 ) - t1824 ) * 296.802103844292 + t1822 * 461.523
) + t1824 * 259.836612622973 ; t1822 = X [ 405ULL ] * 461.523 / ( t1826 ==
0.0 ? 1.0E-16 : t1826 ) ; if ( t1822 <= 0.0 ) { t1824 = 0.0 ; } else { t1824
= t1822 >= 1.0 ? 1.0 : t1822 ; } t1822 = X [ 404ULL ] * 259.836612622973 / (
t1826 == 0.0 ? 1.0E-16 : t1826 ) ; if ( t1822 <= 0.0 ) { t1828 = 0.0 ; } else
{ t1828 = t1822 >= 1.0 ? 1.0 : t1822 ; } t1100 [ 0ULL ] = X [ 403ULL ] ;
tlu2_linear_nearest_prelookup ( & hi_efOut . mField0 [ 0ULL ] , & hi_efOut .
mField1 [ 0ULL ] , & hi_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t109 = hi_efOut ; tlu2_1d_linear_nearest_value ( & ii_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
ii_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ji_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
ji_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ki_efOut [ 0ULL ] , & t109
. mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
ki_efOut [ 0 ] ; t1822 = ( ( ( 1.0 - t1824 ) - t1828 ) * t1091_idx_0 +
t1098_idx_0 * t1824 ) + t1096_idx_0 * t1828 ; tlu2_1d_linear_nearest_value (
& li_efOut [ 0ULL ] , & t87 . mField0 [ 0ULL ] , & t87 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1091_idx_0 = li_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
mi_efOut [ 0ULL ] , & t87 . mField0 [ 0ULL ] , & t87 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1098_idx_0 = mi_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ni_efOut
[ 0ULL ] , & t87 . mField0 [ 0ULL ] , & t87 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField30 , & t364 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1096_idx_0 = ni_efOut [ 0 ] ; t1830 = ( ( ( 1.0 - intrm_sf_mf_1220 ) -
t1800 ) * t1091_idx_0 + t1098_idx_0 * intrm_sf_mf_1220 ) + t1096_idx_0 *
t1800 ; intrm_sf_mf_1220 = ( X [ 413ULL ] - ( - X [ 368ULL ] ) ) / 2.0 ;
tlu2_1d_linear_nearest_value ( & oi_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = oi_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & pi_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = pi_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & qi_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL
] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = qi_efOut [ 0 ] ; t2100
= t1801 + ( ( ( ( 1.0 - t1824 ) - t1828 ) * t1091_idx_0 + t1098_idx_0 * t1824
) + t1096_idx_0 * t1828 ) ; t2110 = t2100 / 2.0 * 0.0019634954084936209 ;
t1800 = ( intrm_sf_mf_1220 >= 0.0 ? intrm_sf_mf_1220 : 0.0 ) * 0.05 / ( t2110
== 0.0 ? 1.0E-16 : t2110 ) ; t1824 = t1800 >= 0.0 ? t1800 : - t1800 ; t1800 =
t1824 > 1000.0 ? t1824 : 1000.0 ; t2107 = t1822 + t1830 ; if ( t2107 / 2.0 >
0.5 ) { t1828 = ( t1822 + t1830 ) / 2.0 ; } else { t1828 = 0.5 ; } t2110 =
pmf_log10 ( 6.9 / ( t1800 == 0.0 ? 1.0E-16 : t1800 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1800 == 0.0 ? 1.0E-16 : t1800 ) +
2.8767404433520813E-5 ) * 3.24 ; t1831 = 1.0 / ( t2110 == 0.0 ? 1.0E-16 :
t2110 ) ; t2118 = ( pmf_pow ( t1828 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1831 / 8.0 ) * 12.7 + 1.0 ; t1833 = ( t1800 - 1000.0 ) * ( t1831
/ 8.0 ) * t1828 / ( t2118 == 0.0 ? 1.0E-16 : t2118 ) ; t1834 = ( t1824 -
2000.0 ) / 2000.0 ; intrm_sf_mf_1228 = t1834 * t1834 * 3.0 - t1834 * t1834 *
t1834 * 2.0 ; if ( t1824 <= 2000.0 ) { t1834 = 3.66 ; } else if ( t1824 >=
4000.0 ) { t1834 = t1833 ; } else { t1834 = ( 1.0 - intrm_sf_mf_1228 ) * 3.66
+ t1833 * intrm_sf_mf_1228 ; } t2110 = t1834 * 0.039269908169872414 ; t2126 =
t2107 / 2.0 ; if ( t1824 > t2110 / 0.0019634954084936209 / ( t2126 == 0.0 ?
1.0E-16 : t2126 ) / 30.0 ) { t2199 = ( t1822 + t1830 ) / 2.0 ; t1833 = t1834
* 0.039269908169872414 / ( t1824 == 0.0 ? 1.0E-16 : t1824 ) /
0.0019634954084936209 / ( t2199 == 0.0 ? 1.0E-16 : t2199 ) ; } else { t1833 =
30.0 ; } t2118 = t1801 + t1738 ; t2132 = t2118 / 2.0 * 0.0019634954084936209
; t1738 = - ( intrm_sf_mf_1220 <= 0.0 ? intrm_sf_mf_1220 : 0.0 ) * 0.05 / (
t2132 == 0.0 ? 1.0E-16 : t2132 ) ; intrm_sf_mf_1220 = t1738 >= 0.0 ? t1738 :
- t1738 ; t1738 = intrm_sf_mf_1220 > 1000.0 ? intrm_sf_mf_1220 : 1000.0 ;
t2126 = t1830 + t1469 ; if ( t2126 / 2.0 > 0.5 ) { t1822 = ( t1830 + t1469 )
/ 2.0 ; } else { t1822 = 0.5 ; } t2132 = pmf_log10 ( 6.9 / ( t1738 == 0.0 ?
1.0E-16 : t1738 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1738 ==
0.0 ? 1.0E-16 : t1738 ) + 2.8767404433520813E-5 ) * 3.24 ; t1834 = 1.0 / (
t2132 == 0.0 ? 1.0E-16 : t2132 ) ; t1303 = ( pmf_pow ( t1822 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1834 / 8.0 ) * 12.7 + 1.0 ;
intrm_sf_mf_1228 = ( t1738 - 1000.0 ) * ( t1834 / 8.0 ) * t1822 / ( t1303 ==
0.0 ? 1.0E-16 : t1303 ) ; intrm_sf_mf_1227 = ( intrm_sf_mf_1220 - 2000.0 ) /
2000.0 ; t1837 = intrm_sf_mf_1227 * intrm_sf_mf_1227 * 3.0 - intrm_sf_mf_1227
* intrm_sf_mf_1227 * intrm_sf_mf_1227 * 2.0 ; if ( intrm_sf_mf_1220 <= 2000.0
) { intrm_sf_mf_1227 = 3.66 ; } else if ( intrm_sf_mf_1220 >= 4000.0 ) {
intrm_sf_mf_1227 = intrm_sf_mf_1228 ; } else { intrm_sf_mf_1227 = ( 1.0 -
t1837 ) * 3.66 + intrm_sf_mf_1228 * t1837 ; } t2132 = intrm_sf_mf_1227 *
0.039269908169872414 ; t2184 = t2126 / 2.0 ; if ( intrm_sf_mf_1220 > t2132 /
0.0019634954084936209 / ( t2184 == 0.0 ? 1.0E-16 : t2184 ) / 30.0 ) { t1303 =
( t1830 + t1469 ) / 2.0 ; intrm_sf_mf_1228 = intrm_sf_mf_1227 *
0.039269908169872414 / ( intrm_sf_mf_1220 == 0.0 ? 1.0E-16 : intrm_sf_mf_1220
) / 0.0019634954084936209 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else {
intrm_sf_mf_1228 = 30.0 ; } t1830 = - X [ 434ULL ] + U_idx_10 * - 2.0 ;
intrm_sf_mf_1227 = pmf_sqrt ( t1830 * t1830 + 6.4274470286298274E-9 ) ; t1100
[ 0ULL ] = X [ 433ULL ] ; t674 [ 0 ] = 11ULL ; tlu2_linear_linear_prelookup (
& ri_efOut . mField0 [ 0ULL ] , & ri_efOut . mField1 [ 0ULL ] , & ri_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [
0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ; t70 = ri_efOut ; t1100 [ 0ULL
] = 1.01325 ; t677 [ 0 ] = 12ULL ; tlu2_linear_linear_prelookup ( & si_efOut
. mField0 [ 0ULL ] , & si_efOut . mField1 [ 0ULL ] , & si_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t1100 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t122 = si_efOut ;
tlu2_2d_linear_linear_value ( & ti_efOut [ 0ULL ] , & t70 . mField0 [ 0ULL ]
, & t70 . mField2 [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ti_efOut [ 0 ] ; t2779 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 56ULL ] ; tlu2_linear_linear_prelookup ( &
ui_efOut . mField0 [ 0ULL ] , & ui_efOut . mField1 [ 0ULL ] , & ui_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [
0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = ui_efOut ;
tlu2_2d_linear_linear_value ( & vi_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ]
, & t116 . mField2 [ 0ULL ] , & t122 . mField0 [ 0ULL ] , & t122 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = vi_efOut [ 0 ] ; t1837 =
t1091_idx_0 ; t1838 = pmf_sqrt ( X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 ) ; t1100 [ 0ULL ] = X [ 441ULL ] ;
tlu2_linear_linear_prelookup ( & wi_efOut . mField0 [ 0ULL ] , & wi_efOut .
mField1 [ 0ULL ] , & wi_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t86 = wi_efOut ; t1100 [ 0ULL ] = X [ 437ULL ] ; tlu2_linear_linear_prelookup
( & xi_efOut . mField0 [ 0ULL ] , & xi_efOut . mField1 [ 0ULL ] , & xi_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t1100
[ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t88 = xi_efOut ;
tlu2_2d_linear_linear_value ( & yi_efOut [ 0ULL ] , & t86 . mField0 [ 0ULL ]
, & t86 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , & t88 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = yi_efOut [ 0 ] ; t1839 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 444ULL ] ; tlu2_linear_linear_prelookup (
& aj_efOut . mField0 [ 0ULL ] , & aj_efOut . mField1 [ 0ULL ] , & aj_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [
0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ; t109 = aj_efOut ; t1100 [ 0ULL
] = X [ 439ULL ] ; tlu2_linear_linear_prelookup ( & bj_efOut . mField0 [ 0ULL
] , & bj_efOut . mField1 [ 0ULL ] , & bj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL
] , & t140 [ 0ULL ] ) ; t14 = bj_efOut ; tlu2_2d_linear_linear_value ( &
cj_efOut [ 0ULL ] , & t109 . mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , &
t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = cj_efOut [ 0 ] ; t1840 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
438ULL ] ; tlu2_linear_nearest_prelookup ( & dj_efOut . mField0 [ 0ULL ] , &
dj_efOut . mField1 [ 0ULL ] , & dj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL
] , & t140 [ 0ULL ] ) ; t125 = dj_efOut ; t1100 [ 0ULL ] = X [ 58ULL ] ;
tlu2_linear_nearest_prelookup ( & ej_efOut . mField0 [ 0ULL ] , & ej_efOut .
mField1 [ 0ULL ] , & ej_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t109 = ej_efOut ; tlu2_2d_linear_nearest_value ( & fj_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] ,
& t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = fj_efOut
[ 0 ] ; t1842 = t1091_idx_0 ; t1100 [ 0ULL ] = X [ 429ULL ] ;
tlu2_linear_nearest_prelookup ( & gj_efOut . mField0 [ 0ULL ] , & gj_efOut .
mField1 [ 0ULL ] , & gj_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = gj_efOut ; tlu2_2d_linear_nearest_value ( & hj_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , &
t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hj_efOut
[ 0 ] ; t1843 = t1091_idx_0 ; t1100 [ 0ULL ] = X [ 59ULL ] ;
tlu2_linear_nearest_prelookup ( & ij_efOut . mField0 [ 0ULL ] , & ij_efOut .
mField1 [ 0ULL ] , & ij_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = ij_efOut ; tlu2_2d_linear_nearest_value ( & jj_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] ,
& t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = jj_efOut
[ 0 ] ; t1845 = t1091_idx_0 ; t1846 = ( X [ 442ULL ] - X [ 434ULL ] ) / 2.0 ;
tlu2_2d_linear_nearest_value ( & kj_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , & t109 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t674 [ 0ULL ] ,
& t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = kj_efOut [ 0 ] ; t1847 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 59ULL ] ; tlu2_linear_linear_prelookup ( &
lj_efOut . mField0 [ 0ULL ] , & lj_efOut . mField1 [ 0ULL ] , & lj_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [
0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ; t86 = lj_efOut ; t1100 [ 0ULL
] = X [ 58ULL ] ; tlu2_linear_linear_prelookup ( & mj_efOut . mField0 [ 0ULL
] , & mj_efOut . mField1 [ 0ULL ] , & mj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL
] , & t140 [ 0ULL ] ) ; t20 = mj_efOut ; tlu2_2d_linear_linear_value ( &
nj_efOut [ 0ULL ] , & t86 . mField0 [ 0ULL ] , & t86 . mField2 [ 0ULL ] , &
t20 . mField0 [ 0ULL ] , & t20 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField35 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = nj_efOut [ 0 ] ; t1848 = t1091_idx_0 ; t1849 = pmf_sqrt ( X [
442ULL ] * X [ 442ULL ] + 5.1419576229038592E-12 ) ; t1100 [ 0ULL ] = X [
446ULL ] ; tlu2_linear_linear_prelookup ( & oj_efOut . mField0 [ 0ULL ] , &
oj_efOut . mField1 [ 0ULL ] , & oj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL
] , & t140 [ 0ULL ] ) ; t70 = oj_efOut ; tlu2_2d_linear_linear_value ( &
pj_efOut [ 0ULL ] , & t70 . mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , &
t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] )
; t1091_idx_0 = pj_efOut [ 0 ] ; t1852 = t1091_idx_0 ; t1853 = pmf_sqrt ( X [
434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 ) ; t1100 [ 0ULL ] = X [
448ULL ] ; tlu2_linear_linear_prelookup ( & qj_efOut . mField0 [ 0ULL ] , &
qj_efOut . mField1 [ 0ULL ] , & qj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL
] , & t140 [ 0ULL ] ) ; t14 = qj_efOut ; tlu2_2d_linear_linear_value ( &
rj_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = rj_efOut [ 0 ] ; t1854 = t1091_idx_0 ;
tlu2_2d_linear_linear_value ( & sj_efOut [ 0ULL ] , & t86 . mField0 [ 0ULL ]
, & t86 . mField2 [ 0ULL ] , & t20 . mField0 [ 0ULL ] , & t20 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = sj_efOut [ 0 ] ; t1855 =
t1091_idx_0 ; tlu2_2d_linear_nearest_value ( & tj_efOut [ 0ULL ] , & t125 .
mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , & t109 . mField0 [ 0ULL ] , &
t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = tj_efOut
[ 0 ] ; t1856 = t1091_idx_0 ; tlu2_2d_linear_nearest_value ( & uj_efOut [
0ULL ] , & t74 . mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t109 .
mField0 [ 0ULL ] , & t109 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField41 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = uj_efOut [ 0 ] ; t1857 = t1091_idx_0 ; t1858 = U_idx_10 * 2.0 ;
t1859 = pmf_sqrt ( t1858 * t1858 + 1.2620262729050631E-10 ) ; t1100 [ 0ULL ]
= X [ 453ULL ] ; tlu2_linear_linear_prelookup ( & vj_efOut . mField0 [ 0ULL ]
, & vj_efOut . mField1 [ 0ULL ] , & vj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL
] , & t140 [ 0ULL ] ) ; t14 = vj_efOut ; tlu2_2d_linear_linear_value ( &
wj_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField36 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = wj_efOut [ 0 ] ; t1860 = t1091_idx_0 ; t1100 [ 0ULL ] = X [
455ULL ] ; tlu2_linear_linear_prelookup ( & xj_efOut . mField0 [ 0ULL ] , &
xj_efOut . mField1 [ 0ULL ] , & xj_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL
] , & t140 [ 0ULL ] ) ; t116 = xj_efOut ; t1100 [ 0ULL ] = X [ 451ULL ] ;
tlu2_linear_linear_prelookup ( & yj_efOut . mField0 [ 0ULL ] , & yj_efOut .
mField1 [ 0ULL ] , & yj_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t70 = yj_efOut ; tlu2_2d_linear_linear_value ( & ak_efOut [ 0ULL ] , & t116 .
mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , &
t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ak_efOut
[ 0 ] ; t1861 = t1091_idx_0 ; t1863 = ( t1860 + t1091_idx_0 ) / 2.0 ; t1100 [
0ULL ] = X [ 450ULL ] ; tlu2_linear_nearest_prelookup ( & bk_efOut . mField0
[ 0ULL ] , & bk_efOut . mField1 [ 0ULL ] , & bk_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [
0ULL ] , & t140 [ 0ULL ] ) ; t86 = bk_efOut ; t1100 [ 0ULL ] = X [ 60ULL ] ;
tlu2_linear_nearest_prelookup ( & ck_efOut . mField0 [ 0ULL ] , & ck_efOut .
mField1 [ 0ULL ] , & ck_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t125 = ck_efOut ; tlu2_2d_linear_nearest_value ( & dk_efOut [ 0ULL ] , & t86
. mField0 [ 0ULL ] , & t86 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , &
t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = dk_efOut
[ 0 ] ; t1864 = t1091_idx_0 ; t1100 [ 0ULL ] = X [ 436ULL ] ;
tlu2_linear_nearest_prelookup ( & ek_efOut . mField0 [ 0ULL ] , & ek_efOut .
mField1 [ 0ULL ] , & ek_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t74 = ek_efOut ; tlu2_2d_linear_nearest_value ( & fk_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , &
t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = fk_efOut
[ 0 ] ; t1866 = t1091_idx_0 ; t1100 [ 0ULL ] = X [ 61ULL ] ;
tlu2_linear_nearest_prelookup ( & gk_efOut . mField0 [ 0ULL ] , & gk_efOut .
mField1 [ 0ULL ] , & gk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = gk_efOut ; tlu2_2d_linear_nearest_value ( & hk_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] ,
& t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hk_efOut
[ 0 ] ; t1867 = t1091_idx_0 ; t1868 = ( t1858 - ( - X [ 442ULL ] ) ) / 2.0 ;
tlu2_2d_linear_nearest_value ( & ik_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , & t125 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t674 [ 0ULL ] ,
& t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = ik_efOut [ 0 ] ; t1869 =
t1091_idx_0 ; t1100 [ 0ULL ] = X [ 61ULL ] ; tlu2_linear_linear_prelookup ( &
jk_efOut . mField0 [ 0ULL ] , & jk_efOut . mField1 [ 0ULL ] , & jk_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t1100 [
0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ; t14 = jk_efOut ; t1100 [ 0ULL
] = X [ 60ULL ] ; tlu2_linear_linear_prelookup ( & kk_efOut . mField0 [ 0ULL
] , & kk_efOut . mField1 [ 0ULL ] , & kk_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t1100 [ 0ULL ] , & t677 [ 0ULL
] , & t140 [ 0ULL ] ) ; t122 = kk_efOut ; tlu2_2d_linear_linear_value ( &
lk_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t122 . mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField35 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ]
) ; t1091_idx_0 = lk_efOut [ 0 ] ; t1870 = t1091_idx_0 ; t1873 = pmf_sqrt (
t1858 * t1858 + 2.4102926357361849E-12 ) ; t1100 [ 0ULL ] = X [ 456ULL ] ;
tlu2_linear_linear_prelookup ( & mk_efOut . mField0 [ 0ULL ] , & mk_efOut .
mField1 [ 0ULL ] , & mk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = mk_efOut ; tlu2_2d_linear_linear_value ( & nk_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , &
t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = nk_efOut
[ 0 ] ; t1874 = t1091_idx_0 ; t1875 = pmf_sqrt ( X [ 442ULL ] * X [ 442ULL ]
+ 2.4102926357361849E-12 ) ; t1100 [ 0ULL ] = X [ 458ULL ] ;
tlu2_linear_linear_prelookup ( & ok_efOut . mField0 [ 0ULL ] , & ok_efOut .
mField1 [ 0ULL ] , & ok_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t1100 [ 0ULL ] , & t674 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = ok_efOut ; tlu2_2d_linear_linear_value ( & pk_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , & t88 . mField0 [ 0ULL ] , &
t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = pk_efOut
[ 0 ] ; t1876 = t1091_idx_0 ; tlu2_2d_linear_linear_value ( & qk_efOut [ 0ULL
] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , & t122 . mField0 [
0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField36 , & t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t1091_idx_0 = qk_efOut [ 0 ] ; t1877 = t1091_idx_0 ;
tlu2_2d_linear_nearest_value ( & rk_efOut [ 0ULL ] , & t86 . mField0 [ 0ULL ]
, & t86 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , & t125 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t674 [ 0ULL ] , &
t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = rk_efOut [ 0 ] ; t1878 =
t1091_idx_0 ; tlu2_2d_linear_nearest_value ( & sk_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t125 . mField0 [ 0ULL ] , &
t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , &
t674 [ 0ULL ] , & t677 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = sk_efOut
[ 0 ] ; t1879 = t1091_idx_0 ; if ( X [ 461ULL ] < 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = X [ 461ULL
] * 17.81 + 0.043 ; } else if ( X [ 461ULL ] <= 1.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = ( ( X [
461ULL ] * 17.81 + 0.043 ) - X [ 461ULL ] * X [ 461ULL ] * 39.85 ) + X [
461ULL ] * X [ 461ULL ] * X [ 461ULL ] * 36.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = ( X [
461ULL ] - 1.0 ) * 1.4 + 14.003 ; } if ( X [ 462ULL ] < 0.0 ) { t1881 = X [
462ULL ] * 17.81 + 0.043 ; } else if ( X [ 462ULL ] <= 1.0 ) { t1881 = ( ( X
[ 462ULL ] * 17.81 + 0.043 ) - X [ 462ULL ] * X [ 462ULL ] * 39.85 ) + X [
462ULL ] * X [ 462ULL ] * X [ 462ULL ] * 36.0 ; } else { t1881 = ( X [ 462ULL
] - 1.0 ) * 1.4 + 14.003 ; } if ( X [ 173ULL ] <= 0.0 ) { t1882 = - X [
173ULL ] / 0.028 ; } else { t1882 = 0.0 ; } t1100 [ 0ULL ] = X [ 32ULL ] ;
tlu2_linear_nearest_prelookup ( & tk_efOut . mField0 [ 0ULL ] , & tk_efOut .
mField1 [ 0ULL ] , & tk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t88 = tk_efOut ; tlu2_1d_linear_nearest_value ( & uk_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = uk_efOut
[ 0 ] ; t1884 = t1091_idx_0 ; t1315 = ( X [ 230ULL ] + X [ 235ULL ] ) / 2.0 ;
t1323 = ( X [ 354ULL ] + X [ 359ULL ] ) / 2.0 ; t1100 [ 0ULL ] = X [ 32ULL ]
; tlu2_linear_linear_prelookup ( & vk_efOut . mField0 [ 0ULL ] , & vk_efOut .
mField1 [ 0ULL ] , & vk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t122 = vk_efOut ; tlu2_1d_linear_linear_value ( & wk_efOut [ 0ULL ] , & t122
. mField0 [ 0ULL ] , & t122 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t915 [ 0 ] =
wk_efOut [ 0 ] ; t1887 = pmf_exp ( pmf_log ( t1315 ) - t915 [ 0ULL ] ) ;
t1889 = pmf_exp ( pmf_log ( t1323 ) - t915 [ 0ULL ] ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 + t1881 ) /
2.0 ; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 >=
1.0 ) { t1881 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 * 0.005139 -
0.00326 ; } else { t1881 = 0.0018790000000000005 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 = pmf_exp ( (
0.003298697014679202 - 1.0 / ( X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) )
* 1268.0 ) * t1881 ; t1890 = t1889 * ( ( X [ 356ULL ] + X [ 361ULL ] ) / 2.0
) ; t1881 = t1890 >= 1.0E-9 ? t1890 : 1.0E-6 ; t1890 = t1315 * ( ( X [ 234ULL
] + X [ 239ULL ] ) / 2.0 ) / 1.01325 ; if ( t1890 * 1.0E-5 >= 1.0E-9 ) {
t1322 = t1890 * 1.0E-5 ; } else { t1322 = 1.0E-6 ; } t1890 = t1323 * ( ( X [
358ULL ] + X [ 363ULL ] ) / 2.0 ) / 1.01325 ; if ( t1890 * 1.0E-5 >= 1.0E-9 )
{ t1330 = t1890 * 1.0E-5 ; } else { t1330 = 1.0E-6 ; } if ( X [ 66ULL ] <=
0.0 ) { t1890 = 0.0 ; } else { t1890 = X [ 66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ]
; } if ( X [ 65ULL ] <= 0.0 ) { t1891 = 0.0 ; } else { t1891 = X [ 65ULL ] >=
1.0 ? 1.0 : X [ 65ULL ] ; } t1892 = ( ( ( 1.0 - t1890 ) - t1891 ) *
296.802103844292 + t1890 * 461.523 ) + t1891 * 4124.48151675695 ; if ( 1.0 -
X [ 66ULL ] >= 0.01 ) { t1890 = 1.0 - X [ 66ULL ] ; } else if ( 1.0 - X [
66ULL ] >= - 0.1 ) { t1890 = pmf_exp ( ( ( 1.0 - X [ 66ULL ] ) - 0.01 ) /
0.01 ) * 0.01 ; } else { t1890 = 1.6701700790245661E-7 ; } t1891 = X [ 65ULL
] / ( t1890 == 0.0 ? 1.0E-16 : t1890 ) * 3827.6794129126583 +
296.802103844292 ; t1100 [ 0ULL ] = X [ 63ULL ] ;
tlu2_linear_linear_prelookup ( & xk_efOut . mField0 [ 0ULL ] , & xk_efOut .
mField1 [ 0ULL ] , & xk_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t88 = xk_efOut ; tlu2_1d_linear_linear_value ( & yk_efOut [ 0ULL ] , & t88 .
mField0 [ 0ULL ] , & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t916 [ 0 ] = yk_efOut [
0 ] ; t1894 = pmf_exp ( pmf_log ( X [ 64ULL ] * 100000.0 ) - t916 [ 0ULL ] )
; if ( t1894 >= 1.0 ) { t2184 = ( t1894 - 1.0 ) * 461.523 + t1891 ; t1896 =
t1891 / ( t2184 == 0.0 ? 1.0E-16 : t2184 ) ; } else { t1896 = 1.0 ; } t1899 =
( X [ 485ULL ] * - 0.62500003906250234 + U_idx_11 * 10.0 ) +
6.2500003783494407E-9 ; if ( X [ 69ULL ] <= 0.0 ) { t1900 = 0.0 ; } else {
t1900 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <= 0.0 )
{ t1901 = 0.0 ; } else { t1901 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; }
t1903 = ( ( ( 1.0 - t1900 ) - t1901 ) * 296.802103844292 + t1900 * 461.523 )
+ t1901 * 4124.48151675695 ; t1905 = - ( ( X [ 67ULL ] / ( X [ 68ULL ] == 0.0
? 1.0E-16 : X [ 68ULL ] ) - X [ 488ULL ] / ( X [ 489ULL ] == 0.0 ? 1.0E-16 :
X [ 489ULL ] ) ) * X [ 478ULL ] * t1903 ) / 7.8539816339744827E-5 ; if ( X [
488ULL ] <= 216.59999999999997 ) { t1091_idx_0 = 216.59999999999997 ; } else
{ t1091_idx_0 = X [ 488ULL ] >= 623.15 ? 623.15 : X [ 488ULL ] ; } t1910 =
t1091_idx_0 * t1091_idx_0 ; t1909 = ( ( ( 1074.1165326382554 + t1091_idx_0 *
- 0.22145652610641059 ) + t1910 * 0.0003721298010901061 ) * ( ( 1.0 - t1900 )
- t1901 ) + ( ( 1479.6504774710402 + t1091_idx_0 * 1.2002114337050787 ) +
t1910 * - 0.00038614513167845434 ) * t1900 ) + ( ( 12825.281119789837 +
t1091_idx_0 * 6.9647057412840034 ) + t1910 * - 0.0070524868246844051 ) *
t1901 ; t2164 = t1909 - t1903 ; t1910 = t1909 / ( t2164 == 0.0 ? 1.0E-16 :
t2164 ) ; t1911 = pmf_sqrt ( t1905 * t1905 * 9.999999999999999E-14 + fabs ( X
[ 488ULL ] * t1910 * t1903 ) * 1.0E-9 ) ; if ( X [ 490ULL ] <= 0.0 ) { t1912
= 0.0 ; } else { t1912 = X [ 490ULL ] >= 1.0 ? 1.0 : X [ 490ULL ] ; } if ( X
[ 491ULL ] <= 0.0 ) { t1913 = 0.0 ; } else { t1913 = X [ 491ULL ] >= 1.0 ?
1.0 : X [ 491ULL ] ; } t1100 [ 0ULL ] = X [ 67ULL ] ;
tlu2_linear_nearest_prelookup ( & al_efOut . mField0 [ 0ULL ] , & al_efOut .
mField1 [ 0ULL ] , & al_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t125 = al_efOut ; tlu2_1d_linear_nearest_value ( & bl_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
bl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & cl_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
cl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & dl_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
dl_efOut [ 0 ] ; t1914 = ( ( ( 1.0 - t1912 ) - t1913 ) * t1091_idx_0 +
t1098_idx_0 * t1912 ) + t1096_idx_0 * t1913 ; t2164 = X [ 489ULL ] * X [
489ULL ] * t1910 ; t1915 = - pmf_sqrt ( fabs ( t2164 / ( t1903 == 0.0 ?
1.0E-16 : t1903 ) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) ) *
7.8539816339744827E-5 ; if ( t1915 >= 0.0 ) { t1919 = t1915 * 100000.0 ; }
else { t1919 = - t1915 * 100000.0 ; } t2027 = t1914 * 7.8539816339744827E-5 ;
t1091_idx_0 = t1919 * 0.01 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) ; t1303 = X [
67ULL ] * t1903 ; t1921 = X [ 68ULL ] / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ;
t2205 = t1921 * 1.5707963267948965E-8 ; t1923 = t1915 * t1914 * 35.2 / (
t2205 == 0.0 ? 1.0E-16 : t2205 ) ; t1925 = t1091_idx_0 >= 1.0 ? t1091_idx_0 :
1.0 ; t1303 = pmf_log10 ( 6.9 / ( t1925 == 0.0 ? 1.0E-16 : t1925 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1925 == 0.0 ? 1.0E-16 : t1925
) + 0.00017169489553429715 ) * 3.24 ; t2211 = t1921 * 1.2337005501361697E-10
; t1919 = t1915 * t1919 * ( 1.0 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ) * 0.55
/ ( t2211 == 0.0 ? 1.0E-16 : t2211 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 = (
t1091_idx_0 - 2000.0 ) / 2000.0 ; t1303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 * 2.0 ; if (
t1091_idx_0 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 = t1923 *
1.0E-5 ; } else if ( t1091_idx_0 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 = t1919 *
1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 = ( ( 1.0 -
t1303 ) * t1923 + t1919 * t1303 ) * 1.0E-5 ; } t1911 = - ( X [ 478ULL ] *
t1911 ) / 7.8539816339744827E-5 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 ; t1919 = ( X
[ 67ULL ] / ( X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) - X [ 493ULL ] / (
X [ 494ULL ] == 0.0 ? 1.0E-16 : X [ 494ULL ] ) ) * X [ 492ULL ] * t1903 /
7.8539816339744827E-5 ; if ( X [ 493ULL ] <= 216.59999999999997 ) {
t1091_idx_0 = 216.59999999999997 ; } else { t1091_idx_0 = X [ 493ULL ] >=
623.15 ? 623.15 : X [ 493ULL ] ; } t1930 = t1091_idx_0 * t1091_idx_0 ; t1923
= ( ( ( 1074.1165326382554 + t1091_idx_0 * - 0.22145652610641059 ) + t1930 *
0.0003721298010901061 ) * ( ( 1.0 - t1900 ) - t1901 ) + ( (
1479.6504774710402 + t1091_idx_0 * 1.2002114337050787 ) + t1930 * -
0.00038614513167845434 ) * t1900 ) + ( ( 12825.281119789837 + t1091_idx_0 *
6.9647057412840034 ) + t1930 * - 0.0070524868246844051 ) * t1901 ; t2184 =
t1923 - t1903 ; t1900 = t1923 / ( t2184 == 0.0 ? 1.0E-16 : t2184 ) ; t1901 =
pmf_sqrt ( t1919 * t1919 * 9.999999999999999E-14 + fabs ( X [ 493ULL ] *
t1900 * t1903 ) * 1.0E-9 ) ; t2184 = X [ 494ULL ] * X [ 494ULL ] * t1900 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 = - pmf_sqrt
( fabs ( t2184 / ( t1903 == 0.0 ? 1.0E-16 : t1903 ) / ( X [ 493ULL ] == 0.0 ?
1.0E-16 : X [ 493ULL ] ) ) ) * 7.8539816339744827E-5 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 >= 0.0 ) {
t1303 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 *
100000.0 ; } else { t1303 = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 * 100000.0 ;
} t1930 = t1303 * 0.01 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 * t1914 *
35.2 / ( t2205 == 0.0 ? 1.0E-16 : t2205 ) ; t1933 = t1930 >= 1.0 ? t1930 :
1.0 ; t2199 = pmf_log10 ( 6.9 / ( t1933 == 0.0 ? 1.0E-16 : t1933 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1933 == 0.0 ? 1.0E-16 : t1933
) + 0.00017169489553429715 ) * 3.24 ; t1303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 * t1303 * (
1.0 / ( t2199 == 0.0 ? 1.0E-16 : t2199 ) ) * 0.55 / ( t2211 == 0.0 ? 1.0E-16
: t2211 ) ; t1934 = ( t1930 - 2000.0 ) / 2000.0 ; t1935 = t1934 * t1934 * 3.0
- t1934 * t1934 * t1934 * 2.0 ; if ( t1930 <= 2000.0 ) { t1934 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 * 1.0E-5 ; }
else if ( t1930 >= 4000.0 ) { t1934 = t1303 * 1.0E-5 ; } else { t1934 = ( (
1.0 - t1935 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 + t1303 *
t1935 ) * 1.0E-5 ; } t1901 = X [ 492ULL ] * t1901 / 7.8539816339744827E-5 *
0.00031622776601683789 + t1934 ; if ( 1.0 - X [ 69ULL ] >= 0.01 ) { t1930 =
1.0 - X [ 69ULL ] ; } else if ( 1.0 - X [ 69ULL ] >= - 0.1 ) { t1930 =
pmf_exp ( ( ( 1.0 - X [ 69ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1930 =
1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 = X [ 70ULL ]
/ ( t1930 == 0.0 ? 1.0E-16 : t1930 ) * 3827.6794129126583 + 296.802103844292
; t1100 [ 0ULL ] = X [ 67ULL ] ; tlu2_linear_linear_prelookup ( & el_efOut .
mField0 [ 0ULL ] , & el_efOut . mField1 [ 0ULL ] , & el_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t88 = el_efOut ;
tlu2_1d_linear_linear_value ( & fl_efOut [ 0ULL ] , & t88 . mField0 [ 0ULL ]
, & t88 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t141 [ 0 ] = fl_efOut [ 0 ] ; t1934 =
pmf_exp ( pmf_log ( X [ 68ULL ] * 100000.0 ) - t141 [ 0ULL ] ) ; if ( t1934
>= 1.0 ) { t2199 = ( t1934 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 ; t1935 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 / ( t2199 ==
0.0 ? 1.0E-16 : t2199 ) ; } else { t1935 = 1.0 ; } if ( X [ 487ULL ] <= 0.0 )
{ t1303 = 0.0 ; } else { t1303 = X [ 487ULL ] >= 1.0 ? 1.0 : X [ 487ULL ] ; }
if ( X [ 486ULL ] <= 0.0 ) { t1937 = 0.0 ; } else { t1937 = X [ 486ULL ] >=
1.0 ? 1.0 : X [ 486ULL ] ; } t1938 = ( ( ( 1.0 - t1303 ) - t1937 ) *
296.802103844292 + t1303 * 461.523 ) + t1937 * 4124.48151675695 ; t1303 = X [
487ULL ] * 461.523 / ( t1938 == 0.0 ? 1.0E-16 : t1938 ) ; if ( t1303 <= 0.0 )
{ t1937 = 0.0 ; } else { t1937 = t1303 >= 1.0 ? 1.0 : t1303 ; } t1303 = X [
486ULL ] * 4124.48151675695 / ( t1938 == 0.0 ? 1.0E-16 : t1938 ) ; if ( t1303
<= 0.0 ) { t1939 = 0.0 ; } else { t1939 = t1303 >= 1.0 ? 1.0 : t1303 ; }
t1100 [ 0ULL ] = X [ 484ULL ] ; tlu2_linear_nearest_prelookup ( & gl_efOut .
mField0 [ 0ULL ] , & gl_efOut . mField1 [ 0ULL ] , & gl_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t1100 [ 0ULL ] , &
t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t116 = gl_efOut ;
tlu2_1d_linear_nearest_value ( & hl_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField23
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 = hl_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & il_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField24
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 = il_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & jl_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL
] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25
, & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 = jl_efOut [ 0 ] ; t1303
= ( ( ( 1.0 - t1937 ) - t1939 ) * t1091_idx_0 + t1098_idx_0 * t1937 ) +
t1096_idx_0 * t1939 ; tlu2_1d_linear_nearest_value ( & kl_efOut [ 0ULL ] , &
t125 . mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
kl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ll_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
ll_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ml_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
ml_efOut [ 0 ] ; t1941 = ( ( ( 1.0 - t1912 ) - t1913 ) * t1091_idx_0 +
t1098_idx_0 * t1912 ) + t1096_idx_0 * t1913 ; t1912 = ( - X [ 478ULL ] - X [
492ULL ] ) / 2.0 ; tlu2_1d_linear_nearest_value ( & nl_efOut [ 0ULL ] , &
t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
nl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ol_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
ol_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & pl_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
pl_efOut [ 0 ] ; t2199 = t1914 + ( ( ( ( 1.0 - t1937 ) - t1939 ) *
t1091_idx_0 + t1098_idx_0 * t1937 ) + t1096_idx_0 * t1939 ) ; t2211 = t2199 /
2.0 * 7.8539816339744827E-5 ; t1913 = ( t1912 >= 0.0 ? t1912 : 0.0 ) * 0.01 /
( t2211 == 0.0 ? 1.0E-16 : t2211 ) ; t1937 = t1913 >= 0.0 ? t1913 : - t1913 ;
t1913 = t1937 > 1000.0 ? t1937 : 1000.0 ; t2205 = t1303 + t1941 ; if ( t2205
/ 2.0 > 0.5 ) { t1939 = ( t1303 + t1941 ) / 2.0 ; } else { t1939 = 0.5 ; }
t2211 = pmf_log10 ( 6.9 / ( t1913 == 0.0 ? 1.0E-16 : t1913 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1913 == 0.0 ? 1.0E-16 : t1913
) + 0.00017169489553429715 ) * 3.24 ; t1942 = 1.0 / ( t2211 == 0.0 ? 1.0E-16
: t2211 ) ; t2223 = ( pmf_pow ( t1939 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1942 / 8.0 ) * 12.7 + 1.0 ; t1944 = ( t1913 - 1000.0 ) * ( t1942
/ 8.0 ) * t1939 / ( t2223 == 0.0 ? 1.0E-16 : t2223 ) ; t1945 = ( t1937 -
2000.0 ) / 2000.0 ; intrm_sf_mf_1464 = t1945 * t1945 * 3.0 - t1945 * t1945 *
t1945 * 2.0 ; if ( t1937 <= 2000.0 ) { t1945 = 3.66 ; } else if ( t1937 >=
4000.0 ) { t1945 = t1944 ; } else { t1945 = ( 1.0 - intrm_sf_mf_1464 ) * 3.66
+ t1944 * intrm_sf_mf_1464 ; } t2211 = t1945 * 0.031415926535897927 ; t2224 =
t2205 / 2.0 ; if ( t1937 > t2211 / 7.8539816339744827E-5 / ( t2224 == 0.0 ?
1.0E-16 : t2224 ) / 30.0 ) { t2024 = ( t1303 + t1941 ) / 2.0 ; t1944 = t1945
* 0.031415926535897927 / ( t1937 == 0.0 ? 1.0E-16 : t1937 ) /
7.8539816339744827E-5 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) ; } else { t1944 =
30.0 ; } if ( X [ 468ULL ] <= 0.0 ) { t1303 = 0.0 ; } else { t1303 = X [
468ULL ] >= 1.0 ? 1.0 : X [ 468ULL ] ; } if ( X [ 467ULL ] <= 0.0 ) { t1945 =
0.0 ; } else { t1945 = X [ 467ULL ] >= 1.0 ? 1.0 : X [ 467ULL ] ; }
intrm_sf_mf_1464 = ( ( ( 1.0 - t1303 ) - t1945 ) * 296.802103844292 + t1303 *
461.523 ) + t1945 * 4124.48151675695 ; t1303 = X [ 468ULL ] * 461.523 / (
intrm_sf_mf_1464 == 0.0 ? 1.0E-16 : intrm_sf_mf_1464 ) ; if ( t1303 <= 0.0 )
{ t1945 = 0.0 ; } else { t1945 = t1303 >= 1.0 ? 1.0 : t1303 ; } t1303 = X [
467ULL ] * 4124.48151675695 / ( intrm_sf_mf_1464 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1464 ) ; if ( t1303 <= 0.0 ) { t1947 = 0.0 ; } else { t1947 =
t1303 >= 1.0 ? 1.0 : t1303 ; } t1100 [ 0ULL ] = X [ 466ULL ] ;
tlu2_linear_nearest_prelookup ( & ql_efOut . mField0 [ 0ULL ] , & ql_efOut .
mField1 [ 0ULL ] , & ql_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = ql_efOut ; tlu2_1d_linear_nearest_value ( & rl_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField23 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1091_idx_0 =
rl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & sl_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField24 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1098_idx_0 =
sl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & tl_efOut [ 0ULL ] , & t116
. mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField25 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1096_idx_0 =
tl_efOut [ 0 ] ; t1303 = ( ( ( 1.0 - t1945 ) - t1947 ) * t1091_idx_0 +
t1098_idx_0 * t1945 ) + t1096_idx_0 * t1947 ; tlu2_1d_linear_nearest_value (
& ul_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 , & t364 [ 0ULL ] , & t140 [
0ULL ] ) ; t1091_idx_0 = ul_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
vl_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField16 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1098_idx_0 = vl_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( &
wl_efOut [ 0ULL ] , & t116 . mField0 [ 0ULL ] , & t116 . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField17 , & t364 [ 0ULL ] , & t140 [ 0ULL
] ) ; t1096_idx_0 = wl_efOut [ 0 ] ; t2223 = t1914 + ( ( ( ( 1.0 - t1945 ) -
t1947 ) * t1091_idx_0 + t1098_idx_0 * t1945 ) + t1096_idx_0 * t1947 ) ; t2232
= t2223 / 2.0 * 7.8539816339744827E-5 ; t1912 = - ( t1912 <= 0.0 ? t1912 :
0.0 ) * 0.01 / ( t2232 == 0.0 ? 1.0E-16 : t2232 ) ; t1945 = t1912 >= 0.0 ?
t1912 : - t1912 ; t1912 = t1945 > 1000.0 ? t1945 : 1000.0 ; t2224 = t1941 +
t1303 ; if ( t2224 / 2.0 > 0.5 ) { t1947 = ( t1941 + t1303 ) / 2.0 ; } else {
t1947 = 0.5 ; } t2232 = pmf_log10 ( 6.9 / ( t1912 == 0.0 ? 1.0E-16 : t1912 )
+ 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1912 == 0.0 ? 1.0E-16 :
t1912 ) + 0.00017169489553429715 ) * 3.24 ; t1948 = 1.0 / ( t2232 == 0.0 ?
1.0E-16 : t2232 ) ; t2255 = ( pmf_pow ( t1947 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( t1948 / 8.0 ) * 12.7 + 1.0 ; t1951 = ( t1912 - 1000.0 ) * (
t1948 / 8.0 ) * t1947 / ( t2255 == 0.0 ? 1.0E-16 : t2255 ) ; t1952 = ( t1945
- 2000.0 ) / 2000.0 ; t1953 = t1952 * t1952 * 3.0 - t1952 * t1952 * t1952 *
2.0 ; if ( t1945 <= 2000.0 ) { t1952 = 3.66 ; } else if ( t1945 >= 4000.0 ) {
t1952 = t1951 ; } else { t1952 = ( 1.0 - t1953 ) * 3.66 + t1951 * t1953 ; }
t2232 = t1952 * 0.031415926535897927 ; U_idx_3 = t2224 / 2.0 ; if ( t1945 >
t2232 / 7.8539816339744827E-5 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) / 30.0
) { t2282 = ( t1941 + t1303 ) / 2.0 ; t1951 = t1952 * 0.031415926535897927 /
( t1945 == 0.0 ? 1.0E-16 : t1945 ) / 7.8539816339744827E-5 / ( t2282 == 0.0 ?
1.0E-16 : t2282 ) ; } else { t1951 = 30.0 ; } if ( X [ 485ULL ] *
7.8539816339744827E-5 <= 7.8539816339744857E-13 ) { t1941 =
7.8539816339744857E-13 ; } else if ( X [ 485ULL ] * 7.8539816339744827E-5 >=
1.2566370614359172E-5 ) { t1941 = 1.2566370614359172E-5 ; } else { t1941 = X
[ 485ULL ] * 7.8539816339744827E-5 ; } t1952 = t1941 / 7.8539816339744827E-5
; if ( X [ 508ULL ] <= 0.0 ) { t1953 = 0.0 ; } else { t1953 = X [ 508ULL ] >=
1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL ] <= 0.0 ) { t1469 = 0.0 ; }
else { t1469 = X [ 509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } t1955 = ( ( ( 1.0
- t1953 ) - t1469 ) * 296.802103844292 + t1953 * 461.523 ) + t1469 *
4124.48151675695 ; U_idx_3 = X [ 506ULL ] * t1955 ; t1956 = X [ 507ULL ] / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; U_idx_3 = X [ 507ULL ] / ( X [ 64ULL ]
== 0.0 ? 1.0E-16 : X [ 64ULL ] ) * ( X [ 510ULL ] / ( X [ 506ULL ] == 0.0 ?
1.0E-16 : X [ 506ULL ] ) ) ; t1958 = X [ 507ULL ] / ( t1899 == 0.0 ? 1.0E-16
: t1899 ) * ( X [ 511ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] )
) ; t1960 = ( X [ 64ULL ] + t1899 ) / 2.0 * 0.0010000000000000009 ; t1959 = (
1.0 - t1952 ) * ( 1.0 - t1952 ) ; intrm_sf_mf_1574 = t1960 * t1959 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = ( t1952 +
1.0 ) * ( 1.0 - t1952 * U_idx_3 ) - ( 1.0 - t1952 * t1958 ) * t1952 * 2.0 ;
t1965 = ( X [ 64ULL ] - t1899 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 >= t1959 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 : t1959 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = ( X [ 64ULL
] - t1899 ) / ( t1960 == 0.0 ? 1.0E-16 : t1960 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 * 2.0 ; if (
X [ 64ULL ] - t1899 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 =
intrm_sf_mf_1574 ; } else if ( X [ 64ULL ] - t1899 >= t1960 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = t1965 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 ) *
intrm_sf_mf_1574 + t1965 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 ; } t1965 = (
t1952 + 1.0 ) * ( 1.0 - t1952 * t1958 ) - ( 1.0 - t1952 * U_idx_3 ) * t1952 *
2.0 ; t1952 = ( t1899 - X [ 64ULL ] ) * ( t1965 >= t1959 ? t1965 : t1959 ) ;
U_idx_3 = ( t1899 - X [ 64ULL ] ) / ( t1960 == 0.0 ? 1.0E-16 : t1960 ) ;
t1958 = U_idx_3 * U_idx_3 * 3.0 - U_idx_3 * U_idx_3 * U_idx_3 * 2.0 ; if (
t1899 - X [ 64ULL ] <= 0.0 ) { U_idx_3 = intrm_sf_mf_1574 ; } else if ( t1899
- X [ 64ULL ] >= t1960 ) { U_idx_3 = t1952 ; } else { U_idx_3 = ( 1.0 - t1958
) * intrm_sf_mf_1574 + t1952 * t1958 ; } if ( X [ 64ULL ] > t1899 ) { t1952 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 ; } else {
t1952 = X [ 64ULL ] < t1899 ? U_idx_3 : intrm_sf_mf_1574 ; } if ( X [ 506ULL
] <= 216.59999999999997 ) { U_idx_3 = 216.59999999999997 ; } else { U_idx_3 =
X [ 506ULL ] >= 623.15 ? 623.15 : X [ 506ULL ] ; } t1303 = U_idx_3 * U_idx_3
; t1958 = ( ( ( 1074.1165326382554 + U_idx_3 * - 0.22145652610641059 ) +
t1303 * 0.0003721298010901061 ) * ( ( 1.0 - t1953 ) - t1469 ) + ( (
1479.6504774710402 + U_idx_3 * 1.2002114337050787 ) + t1303 * -
0.00038614513167845434 ) * t1953 ) + ( ( 12825.281119789837 + U_idx_3 *
6.9647057412840034 ) + t1303 * - 0.0070524868246844051 ) * t1469 ; t2255 =
t1958 - t1955 ; t2255 = X [ 507ULL ] * X [ 507ULL ] * ( t1958 / ( t2255 ==
0.0 ? 1.0E-16 : t2255 ) ) ; t1953 = pmf_sqrt ( fabs ( t2255 / ( t1955 == 0.0
? 1.0E-16 : t1955 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) *
t1941 * 0.64 ; if ( X [ 524ULL ] <= 0.0 ) { t1469 = 0.0 ; } else { t1469 = X
[ 524ULL ] >= 1.0 ? 1.0 : X [ 524ULL ] ; } if ( X [ 525ULL ] <= 0.0 ) { t1959
= 0.0 ; } else { t1959 = X [ 525ULL ] >= 1.0 ? 1.0 : X [ 525ULL ] ; }
intrm_sf_mf_1574 = ( ( ( 1.0 - t1469 ) - t1959 ) * 296.802103844292 + t1469 *
461.523 ) + t1959 * 259.836612622973 ; if ( X [ 73ULL ] <= 0.0 ) { t1959 =
0.0 ; } else { t1959 = X [ 73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ] ; } if ( X [
72ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = X [
72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; } t1965 = ( ( ( 1.0 - t1959 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 ) *
296.802103844292 + t1959 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 *
259.836612622973 ; if ( 1.0 - X [ 73ULL ] >= 0.01 ) { t1959 = 1.0 - X [ 73ULL
] ; } else if ( 1.0 - X [ 73ULL ] >= - 0.1 ) { t1959 = pmf_exp ( ( ( 1.0 - X
[ 73ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1959 = 1.6701700790245661E-7
; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 = X [
72ULL ] / ( t1959 == 0.0 ? 1.0E-16 : t1959 ) * - 36.965491221318985 +
296.802103844292 ; t1100 [ 0ULL ] = X [ 71ULL ] ;
tlu2_linear_linear_prelookup ( & xl_efOut . mField0 [ 0ULL ] , & xl_efOut .
mField1 [ 0ULL ] , & xl_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t125 = xl_efOut ; tlu2_1d_linear_linear_value ( & yl_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t150 [ 0 ] =
yl_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 = pmf_exp (
pmf_log ( X [ 55ULL ] * 100000.0 ) - t150 [ 0ULL ] ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 >= 1.0 ) {
U_idx_3 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 -
1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 ; t1306 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 / ( U_idx_3
== 0.0 ? 1.0E-16 : U_idx_3 ) ; } else { t1306 = 1.0 ; } if ( X [ 76ULL ] <=
0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 = 0.0
; } else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 =
X [ 76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) { t1969
= 0.0 ; } else { t1969 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; } t1972 = (
( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 ) -
t1969 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 * 461.523 ) +
t1969 * 4124.48151675695 ; if ( 1.0 - X [ 76ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 = 1.0 - X [
76ULL ] ; } else if ( 1.0 - X [ 76ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 = pmf_exp ( (
( 1.0 - X [ 76ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 =
1.6701700790245661E-7 ; } t1969 = X [ 75ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 ) *
3827.6794129126583 + 296.802103844292 ; t1100 [ 0ULL ] = X [ 74ULL ] ;
tlu2_linear_linear_prelookup ( & am_efOut . mField0 [ 0ULL ] , & am_efOut .
mField1 [ 0ULL ] , & am_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t1100 [ 0ULL ] , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t125 = am_efOut ; tlu2_1d_linear_linear_value ( & bm_efOut [ 0ULL ] , & t125
. mField0 [ 0ULL ] , & t125 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField14 , & t364 [ 0ULL ] , & t140 [ 0ULL ] ) ; t914 [ 0 ] =
bm_efOut [ 0 ] ; t1973 = pmf_exp ( pmf_log ( X [ 38ULL ] * 100000.0 ) - t914
[ 0ULL ] ) ; if ( t1973 >= 1.0 ) { U_idx_3 = ( t1973 - 1.0 ) * 461.523 +
t1969 ; t1974 = t1969 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; } else {
t1974 = 1.0 ; } t1976 = U_idx_4 * 0.01 ; U_idx_3 = ( U_idx_2 >= 0.0 ? U_idx_2
: - U_idx_2 ) * 0.01 ; t2024 = t1416 * 7.8539816339744827E-5 ;
intrm_sf_mf_1280 = U_idx_3 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) ; t1978 = ( X
[ 371ULL ] >= 0.0 ? X [ 371ULL ] : - X [ 371ULL ] ) * 0.01 / ( t1906 == 0.0 ?
1.0E-16 : t1906 ) ; t1979 = t1978 >= 1.0 ? t1978 : 1.0 ; t1978 =
intrm_sf_mf_1280 >= 2000.0 ? intrm_sf_mf_1280 : 1.0 ; if ( - X [ 371ULL ] >=
0.0 ) { intrm_sf_mf_1280 = - X [ 371ULL ] ; } else { intrm_sf_mf_1280 = X [
371ULL ] ; } intrm_sf_mf_1280 = intrm_sf_mf_1280 * 0.01 / ( t1990 == 0.0 ?
1.0E-16 : t1990 ) ; t1980 = intrm_sf_mf_1280 >= 1.0 ? intrm_sf_mf_1280 : 1.0
; if ( - X [ 325ULL ] >= 0.0 ) { intrm_sf_mf_1280 = - X [ 325ULL ] ; } else {
intrm_sf_mf_1280 = X [ 325ULL ] ; } intrm_sf_mf_1280 = intrm_sf_mf_1280 *
0.01 / ( t1990 == 0.0 ? 1.0E-16 : t1990 ) ; t1981 = intrm_sf_mf_1280 >= 1.0 ?
intrm_sf_mf_1280 : 1.0 ; intrm_sf_mf_1280 = ( X [ 413ULL ] >= 0.0 ? X [
413ULL ] : - X [ 413ULL ] ) * 0.05 / ( t2070 == 0.0 ? 1.0E-16 : t2070 ) ;
t1983 = intrm_sf_mf_1280 >= 1.0 ? intrm_sf_mf_1280 : 1.0 ; if ( - X [ 368ULL
] >= 0.0 ) { intrm_sf_mf_1280 = - X [ 368ULL ] ; } else { intrm_sf_mf_1280 =
X [ 368ULL ] ; } intrm_sf_mf_1280 = intrm_sf_mf_1280 * 0.05 / ( t2070 == 0.0
? 1.0E-16 : t2070 ) ; t1984 = intrm_sf_mf_1280 >= 1.0 ? intrm_sf_mf_1280 :
1.0 ; t2070 = t1856 + t1847 ; t2282 = t2070 / 2.0 * 0.002 ; t1856 = t1846 *
0.01 / ( t2282 == 0.0 ? 1.0E-16 : t2282 ) ; intrm_sf_mf_1280 = t1856 >= 0.0 ?
t1856 : - t1856 ; t1856 = intrm_sf_mf_1280 > 1000.0 ? intrm_sf_mf_1280 :
1000.0 ; t2274 = t1842 + t1845 ; if ( t2274 / 2.0 > 0.5 ) { t1985 = ( t1842 +
t1845 ) / 2.0 ; } else { t1985 = 0.5 ; } t2282 = pmf_log10 ( 6.9 / ( t1856 ==
0.0 ? 1.0E-16 : t1856 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t1856 == 0.0 ? 1.0E-16 : t1856 ) + 0.00017169489553429715 ) * 3.24 ; t1987 =
1.0 / ( t2282 == 0.0 ? 1.0E-16 : t2282 ) ; t2295 = ( pmf_pow ( t1985 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1987 / 8.0 ) * 12.7 + 1.0 ; t1989
= ( t1856 - 1000.0 ) * ( t1987 / 8.0 ) * t1985 / ( t2295 == 0.0 ? 1.0E-16 :
t2295 ) ; t1990 = ( intrm_sf_mf_1280 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1300 =
t1990 * t1990 * 3.0 - t1990 * t1990 * t1990 * 2.0 ; if ( intrm_sf_mf_1280 <=
2000.0 ) { t1990 = 3.66 ; } else if ( intrm_sf_mf_1280 >= 4000.0 ) { t1990 =
t1989 ; } else { t1990 = ( 1.0 - intrm_sf_mf_1300 ) * 3.66 + t1989 *
intrm_sf_mf_1300 ; } t2282 = t1990 * 1.6063872509454251 ; t2298 = t2274 / 2.0
; if ( intrm_sf_mf_1280 > t2282 / 0.002 / ( t2298 == 0.0 ? 1.0E-16 : t2298 )
/ 30.0 ) { t2327 = ( t1842 + t1845 ) / 2.0 ; t1989 = t1990 *
1.6063872509454251 / ( intrm_sf_mf_1280 == 0.0 ? 1.0E-16 : intrm_sf_mf_1280 )
/ 0.002 / ( t2327 == 0.0 ? 1.0E-16 : t2327 ) ; } else { t1989 = 30.0 ; }
t2295 = t1857 + t1847 ; t2303 = t2295 / 2.0 * 0.002 ; t1842 = - t1846 * 0.01
/ ( t2303 == 0.0 ? 1.0E-16 : t2303 ) ; t1846 = t1842 >= 0.0 ? t1842 : - t1842
; t1842 = t1846 > 1000.0 ? t1846 : 1000.0 ; t2298 = t1843 + t1845 ; if (
t2298 / 2.0 > 0.5 ) { t1857 = ( t1843 + t1845 ) / 2.0 ; } else { t1857 = 0.5
; } t2303 = pmf_log10 ( 6.9 / ( t1842 == 0.0 ? 1.0E-16 : t1842 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1842 == 0.0 ? 1.0E-16 : t1842
) + 0.00017169489553429715 ) * 3.24 ; t1990 = 1.0 / ( t2303 == 0.0 ? 1.0E-16
: t2303 ) ; t2316 = ( pmf_pow ( t1857 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1990 / 8.0 ) * 12.7 + 1.0 ; intrm_sf_mf_1300 = ( t1842 - 1000.0 )
* ( t1990 / 8.0 ) * t1857 / ( t2316 == 0.0 ? 1.0E-16 : t2316 ) ; t1993 = (
t1846 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1327 = t1993 * t1993 * 3.0 - t1993 *
t1993 * t1993 * 2.0 ; if ( t1846 <= 2000.0 ) { t1993 = 3.66 ; } else if (
t1846 >= 4000.0 ) { t1993 = intrm_sf_mf_1300 ; } else { t1993 = ( 1.0 -
intrm_sf_mf_1327 ) * 3.66 + intrm_sf_mf_1300 * intrm_sf_mf_1327 ; } t2303 =
t1993 * 1.6063872509454251 ; t2319 = t2298 / 2.0 ; if ( t1846 > t2303 / 0.002
/ ( t2319 == 0.0 ? 1.0E-16 : t2319 ) / 30.0 ) { t2343 = ( t1843 + t1845 ) /
2.0 ; intrm_sf_mf_1300 = t1993 * 1.6063872509454251 / ( t1846 == 0.0 ?
1.0E-16 : t1846 ) / 0.002 / ( t2343 == 0.0 ? 1.0E-16 : t2343 ) ; } else {
intrm_sf_mf_1300 = 30.0 ; } t2319 = t1847 * 0.002 ; t1843 = ( X [ 442ULL ] >=
0.0 ? X [ 442ULL ] : - X [ 442ULL ] ) * 0.01 / ( t2319 == 0.0 ? 1.0E-16 :
t2319 ) ; t1845 = t1843 >= 1.0 ? t1843 : 1.0 ; t1843 = ( X [ 434ULL ] >= 0.0
? X [ 434ULL ] : - X [ 434ULL ] ) * 0.01 / ( t2319 == 0.0 ? 1.0E-16 : t2319 )
; t1993 = t1843 >= 1.0 ? t1843 : 1.0 ; t2316 = t1878 + t1869 ; t2327 = t2316
/ 2.0 * 0.00093750000000000007 ; t1843 = t1868 * 0.0028301886792452828 / (
t2327 == 0.0 ? 1.0E-16 : t2327 ) ; t1878 = t1843 >= 0.0 ? t1843 : - t1843 ;
t1843 = t1878 > 1000.0 ? t1878 : 1000.0 ; t2319 = t1864 + t1867 ; if ( t2319
/ 2.0 > 0.5 ) { intrm_sf_mf_1327 = ( t1864 + t1867 ) / 2.0 ; } else {
intrm_sf_mf_1327 = 0.5 ; } t2327 = pmf_log10 ( 6.9 / ( t1843 == 0.0 ? 1.0E-16
: t1843 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1843 == 0.0 ?
1.0E-16 : t1843 ) + 0.00069701528436089772 ) * 3.24 ; t1995 = 1.0 / ( t2327
== 0.0 ? 1.0E-16 : t2327 ) ; t2337 = ( pmf_pow ( intrm_sf_mf_1327 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1995 / 8.0 ) * 12.7 + 1.0 ; t1996
= ( t1843 - 1000.0 ) * ( t1995 / 8.0 ) * intrm_sf_mf_1327 / ( t2337 == 0.0 ?
1.0E-16 : t2337 ) ; intrm_sf_mf_1340 = ( t1878 - 2000.0 ) / 2000.0 ; t1998 =
intrm_sf_mf_1340 * intrm_sf_mf_1340 * 3.0 - intrm_sf_mf_1340 *
intrm_sf_mf_1340 * intrm_sf_mf_1340 * 2.0 ; if ( t1878 <= 2000.0 ) {
intrm_sf_mf_1340 = 3.66 ; } else if ( t1878 >= 4000.0 ) { intrm_sf_mf_1340 =
t1996 ; } else { intrm_sf_mf_1340 = ( 1.0 - t1998 ) * 3.66 + t1996 * t1998 ;
} t2327 = intrm_sf_mf_1340 * 1.3250000000000002 ; t2340 = t2319 / 2.0 ; if (
t1878 > t2327 / 0.00093750000000000007 / ( t2340 == 0.0 ? 1.0E-16 : t2340 ) /
30.0 ) { t1303 = ( t1864 + t1867 ) / 2.0 ; t1996 = intrm_sf_mf_1340 *
1.3250000000000002 / ( t1878 == 0.0 ? 1.0E-16 : t1878 ) /
0.00093750000000000007 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else { t1996
= 30.0 ; } t2337 = t1879 + t1869 ; t2343 = t2337 / 2.0 *
0.00093750000000000007 ; t1864 = - t1868 * 0.0028301886792452828 / ( t2343 ==
0.0 ? 1.0E-16 : t2343 ) ; t1868 = t1864 >= 0.0 ? t1864 : - t1864 ; t1864 =
t1868 > 1000.0 ? t1868 : 1000.0 ; t2340 = t1866 + t1867 ; if ( t2340 / 2.0 >
0.5 ) { t1879 = ( t1866 + t1867 ) / 2.0 ; } else { t1879 = 0.5 ; } t2343 =
pmf_log10 ( 6.9 / ( t1864 == 0.0 ? 1.0E-16 : t1864 ) + 0.00069701528436089772
) * pmf_log10 ( 6.9 / ( t1864 == 0.0 ? 1.0E-16 : t1864 ) +
0.00069701528436089772 ) * 3.24 ; intrm_sf_mf_1340 = 1.0 / ( t2343 == 0.0 ?
1.0E-16 : t2343 ) ; t1303 = ( pmf_pow ( t1879 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( intrm_sf_mf_1340 / 8.0 ) * 12.7 + 1.0 ; t1998 = ( t1864 - 1000.0
) * ( intrm_sf_mf_1340 / 8.0 ) * t1879 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ;
t1999 = ( t1868 - 2000.0 ) / 2000.0 ; t1098_idx_0 = t1999 * t1999 * 3.0 -
t1999 * t1999 * t1999 * 2.0 ; if ( t1868 <= 2000.0 ) { t1999 = 3.66 ; } else
if ( t1868 >= 4000.0 ) { t1999 = t1998 ; } else { t1999 = ( 1.0 - t1098_idx_0
) * 3.66 + t1998 * t1098_idx_0 ; } t2343 = t1999 * 1.3250000000000002 ; t1303
= t2340 / 2.0 ; if ( t1868 > t2343 / 0.00093750000000000007 / ( t1303 == 0.0
? 1.0E-16 : t1303 ) / 30.0 ) { t1303 = ( t1866 + t1867 ) / 2.0 ; t1998 =
t1999 * 1.3250000000000002 / ( t1868 == 0.0 ? 1.0E-16 : t1868 ) /
0.00093750000000000007 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; } else { t1998
= 30.0 ; } t1303 = t1869 * 0.00093750000000000007 ; t1866 = ( t1858 >= 0.0 ?
t1858 : - t1858 ) * 0.0028301886792452828 / ( t1303 == 0.0 ? 1.0E-16 : t1303
) ; t1867 = t1866 >= 1.0 ? t1866 : 1.0 ; if ( - X [ 442ULL ] >= 0.0 ) { t1866
= - X [ 442ULL ] ; } else { t1866 = X [ 442ULL ] ; } t1866 = t1866 *
0.0028301886792452828 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) ; t1999 = t1866 >=
1.0 ? t1866 : 1.0 ; if ( - X [ 478ULL ] >= 0.0 ) { t1866 = - X [ 478ULL ] ; }
else { t1866 = X [ 478ULL ] ; } t1866 = t1866 * 0.01 / ( t2027 == 0.0 ?
1.0E-16 : t2027 ) ; t1098_idx_0 = t1866 >= 1.0 ? t1866 : 1.0 ; t1866 = ( X [
492ULL ] >= 0.0 ? X [ 492ULL ] : - X [ 492ULL ] ) * 0.01 / ( t2027 == 0.0 ?
1.0E-16 : t2027 ) ; t1096_idx_0 = t1866 >= 1.0 ? t1866 : 1.0 ; if ( X [
529ULL ] <= 0.0 ) { t1866 = 0.0 ; } else { t1866 = X [ 529ULL ] >= 1.0 ? 1.0
: X [ 529ULL ] ; } if ( X [ 528ULL ] <= 0.0 ) { t2005 = 0.0 ; } else { t2005
= X [ 528ULL ] >= 1.0 ? 1.0 : X [ 528ULL ] ; } U_idx_11 = ( ( ( 1.0 - t1866 )
- t2005 ) * 296.802103844292 + t1866 * 461.523 ) + t2005 * 259.836612622973 ;
t1866 = pmf_sqrt ( X [ 148ULL ] * 402.5245441795231 ) ; t2005 = pmf_sqrt ( X
[ 144ULL ] * 402.5245441795231 ) ; U_idx_4 = X [ 162ULL ] * t1866 * 1.0E-6 ;
t1866 = X [ 163ULL ] * t2005 * 1.0E-6 ; t2005 = pmf_sqrt ( X [ 154ULL ] * X [
154ULL ] + U_idx_4 * U_idx_4 ) ; t2011 = pmf_sqrt ( t1866 * t1866 ) ; t1100 [
0ULL ] = X [ 8ULL ] ; tlu2_linear_linear_prelookup ( & cm_efOut . mField0 [
0ULL ] , & cm_efOut . mField1 [ 0ULL ] , & cm_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t1100 [ 0ULL ] , & t139 [ 0ULL ]
, & t140 [ 0ULL ] ) ; t74 = cm_efOut ; t1100 [ 0ULL ] = X [ 15ULL ] ;
tlu2_linear_linear_prelookup ( & dm_efOut . mField0 [ 0ULL ] , & dm_efOut .
mField1 [ 0ULL ] , & dm_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t1100 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ;
t116 = dm_efOut ; tlu2_2d_linear_linear_value ( & em_efOut [ 0ULL ] , & t74 .
mField0 [ 0ULL ] , & t74 . mField2 [ 0ULL ] , & t116 . mField0 [ 0ULL ] , &
t116 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , &
t139 [ 0ULL ] , & t142 [ 0ULL ] , & t140 [ 0ULL ] ) ; t1100 [ 0 ] = em_efOut
[ 0 ] ; t2013 = t1100 [ 0ULL ] ; if ( U_idx_13 >= 1.0 ) { t2014 = 1.0 ; }
else { t2014 = U_idx_13 <= 0.0 ? 0.0 : U_idx_13 ; } if ( - U_idx_2 >= 0.0 ) {
t2016 = - U_idx_2 ; } else { t2016 = U_idx_2 ; } intrm_sf_mf_1801 = ( fabs (
t2014 - U_idx_13 ) > 0.001 ) ; t2027 = t2016 * 0.01 ; t2014 = t2027 / ( t2024
== 0.0 ? 1.0E-16 : t2024 ) ; t2016 = t2014 >= 2000.0 ? t2014 : 1.0 ; t2014 =
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ) * 0.01 / (
t1461 == 0.0 ? 1.0E-16 : t1461 ) ; U_idx_7 = t2014 >= 1.0 ? t2014 : 1.0 ; if
( - X [ 186ULL ] >= 0.0 ) { t2014 = - X [ 186ULL ] ; } else { t2014 = X [
186ULL ] ; } t2014 = t2014 * 0.01 / ( t1461 == 0.0 ? 1.0E-16 : t1461 ) ;
t1461 = t2014 >= 1.0 ? t2014 : 1.0 ; t2024 = t1427 * 7.8539816339744827E-5 ;
t2014 = U_idx_3 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) ; U_idx_10 = t2014 >=
2000.0 ? t2014 : 1.0 ; t2014 = ( X [ 244ULL ] >= 0.0 ? X [ 244ULL ] : - X [
244ULL ] ) * 0.01 / ( t1561 == 0.0 ? 1.0E-16 : t1561 ) ; t1091_idx_0 = t2014
>= 1.0 ? t2014 : 1.0 ; t2014 = ( X [ 247ULL ] >= 0.0 ? X [ 247ULL ] : - X [
247ULL ] ) * 0.01 / ( t1561 == 0.0 ? 1.0E-16 : t1561 ) ; t1561 = t2014 >= 1.0
? t2014 : 1.0 ; t2014 = t2027 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) ; t2020 =
t2014 >= 2000.0 ? t2014 : 1.0 ; t2024 = t1436 * 7.8539816339744827E-5 ; t2014
= U_idx_3 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) ; if ( - X [ 247ULL ] >= 0.0 )
{ U_idx_3 = - X [ 247ULL ] ; } else { U_idx_3 = X [ 247ULL ] ; } U_idx_3 =
U_idx_3 * 0.01 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) ; t1469 = U_idx_3 >= 1.0
? U_idx_3 : 1.0 ; U_idx_3 = t2014 >= 2000.0 ? t2014 : 1.0 ; t2014 = ( X [
198ULL ] >= 0.0 ? X [ 198ULL ] : - X [ 198ULL ] ) * 0.01 / ( t1645 == 0.0 ?
1.0E-16 : t1645 ) ; t1645 = t2014 >= 1.0 ? t2014 : 1.0 ; t2014 = t2027 / (
t2024 == 0.0 ? 1.0E-16 : t2024 ) ; t2024 = t2014 >= 2000.0 ? t2014 : 1.0 ;
t2014 = ( X [ 288ULL ] >= 0.0 ? X [ 288ULL ] : - X [ 288ULL ] ) * 0.05 / (
t1725 == 0.0 ? 1.0E-16 : t1725 ) ; t1303 = t2014 >= 1.0 ? t2014 : 1.0 ; if (
- X [ 244ULL ] >= 0.0 ) { t2014 = - X [ 244ULL ] ; } else { t2014 = X [
244ULL ] ; } t2014 = t2014 * 0.05 / ( t1725 == 0.0 ? 1.0E-16 : t1725 ) ;
t1725 = t2014 >= 1.0 ? t2014 : 1.0 ; t2014 = ( X [ 325ULL ] >= 0.0 ? X [
325ULL ] : - X [ 325ULL ] ) * 0.05 / ( t1807 == 0.0 ? 1.0E-16 : t1807 ) ;
t2027 = t2014 >= 1.0 ? t2014 : 1.0 ; if ( - X [ 313ULL ] >= 0.0 ) { t2014 = -
X [ 313ULL ] ; } else { t2014 = X [ 313ULL ] ; } t2014 = t2014 * 0.05 / (
t1807 == 0.0 ? 1.0E-16 : t1807 ) ; t1807 = t2014 >= 1.0 ? t2014 : 1.0 ; t2014
= ( X [ 368ULL ] >= 0.0 ? X [ 368ULL ] : - X [ 368ULL ] ) * 0.01 / ( t1906 ==
0.0 ? 1.0E-16 : t1906 ) ; t1906 = t2014 >= 1.0 ? t2014 : 1.0 ; if ( X [
277ULL ] >= 0.0 ) { t132 = true ; } else { t132 = ( X [ 30ULL ] > 0.0 ) ; }
if ( X [ 276ULL ] >= 0.0 ) { t133 = true ; } else { t133 = ( X [ 29ULL ] >
0.0 ) ; } if ( U_idx_5 >= 0.0 ) { t134 = true ; } else { t134 = ( X [ 36ULL ]
> 0.0 ) ; } if ( X [ 402ULL ] >= 0.0 ) { t135 = true ; } else { t135 = ( X [
48ULL ] > 0.0 ) ; } if ( X [ 401ULL ] >= 0.0 ) { t136 = true ; } else { t136
= ( X [ 47ULL ] > 0.0 ) ; } if ( U_idx_8 >= 0.0 ) { t137 = true ; } else {
t137 = ( X [ 53ULL ] > 0.0 ) ; } t913 [ 0ULL ] = 1 ; t913 [ 1ULL ] = 1 ; t913
[ 2ULL ] = 1 ; t913 [ 3ULL ] = 1 ; t913 [ 4ULL ] = 1 ; t913 [ 5ULL ] = 1 ;
t913 [ 6ULL ] = ( int32_T ) ( X [ 83ULL ] >= 0.0 ) ; t913 [ 7ULL ] = (
int32_T ) ( X [ 83ULL ] <= 1.0 ) ; t913 [ 8ULL ] = ( int32_T ) ( X [ 81ULL ]
>= 100.8 ) ; t913 [ 9ULL ] = ( int32_T ) ( X [ 81ULL ] <= 607.824 ) ; t913 [
10ULL ] = ( int32_T ) ( M [ 47ULL ] != 0 ) ; t913 [ 11ULL ] = ( int32_T ) ( M
[ 48ULL ] != 0 ) ; t913 [ 12ULL ] = ( int32_T ) ( M [ 49ULL ] != 0 ) ; t913 [
13ULL ] = ( int32_T ) ( M [ 51ULL ] != 0 ) ; t913 [ 14ULL ] = ( int32_T ) ( M
[ 52ULL ] != 0 ) ; t913 [ 15ULL ] = ( int32_T ) ( M [ 53ULL ] != 0 ) ; t913 [
16ULL ] = ( int32_T ) ( M [ 54ULL ] != 0 ) ; t913 [ 17ULL ] = ( int32_T ) ( M
[ 55ULL ] != 0 ) ; t913 [ 18ULL ] = ( int32_T ) ( M [ 56ULL ] != 0 ) ; t913 [
19ULL ] = ( int32_T ) ( M [ 57ULL ] != 0 ) ; t913 [ 20ULL ] = ( int32_T ) ( M
[ 58ULL ] != 0 ) ; t913 [ 21ULL ] = ( int32_T ) ( M [ 59ULL ] != 0 ) ; t913 [
22ULL ] = ( int32_T ) ( M [ 60ULL ] != 0 ) ; t913 [ 23ULL ] = ( int32_T ) ( M
[ 62ULL ] != 0 ) ; t913 [ 24ULL ] = ( int32_T ) ( M [ 63ULL ] != 0 ) ; t913 [
25ULL ] = ( int32_T ) ( M [ 64ULL ] != 0 ) ; t913 [ 26ULL ] = ( int32_T ) ( M
[ 65ULL ] != 0 ) ; t913 [ 27ULL ] = ( int32_T ) ( M [ 66ULL ] != 0 ) ; t913 [
28ULL ] = ( int32_T ) ( M [ 67ULL ] != 0 ) ; t913 [ 29ULL ] = ( int32_T ) ( M
[ 68ULL ] != 0 ) ; t913 [ 30ULL ] = ( int32_T ) ( M [ 69ULL ] != 0 ) ; t913 [
31ULL ] = ( int32_T ) ( M [ 70ULL ] != 0 ) ; t913 [ 32ULL ] = ( int32_T ) ( M
[ 71ULL ] != 0 ) ; t913 [ 33ULL ] = ( int32_T ) ( M [ 73ULL ] != 0 ) ; t913 [
34ULL ] = ( int32_T ) ( M [ 74ULL ] != 0 ) ; t913 [ 35ULL ] = ( int32_T ) ( M
[ 75ULL ] != 0 ) ; t913 [ 36ULL ] = ( int32_T ) ( M [ 76ULL ] != 0 ) ; t913 [
37ULL ] = ( int32_T ) ( M [ 77ULL ] != 0 ) ; t913 [ 38ULL ] = ( int32_T ) ( M
[ 78ULL ] != 0 ) ; t913 [ 39ULL ] = ( int32_T ) ( M [ 79ULL ] != 0 ) ; t913 [
40ULL ] = ( int32_T ) ( M [ 80ULL ] != 0 ) ; t913 [ 41ULL ] = ( int32_T ) ( M
[ 81ULL ] != 0 ) ; t913 [ 42ULL ] = ( int32_T ) ( M [ 82ULL ] != 0 ) ; t913 [
43ULL ] = ( int32_T ) ( M [ 84ULL ] != 0 ) ; t913 [ 44ULL ] = ( int32_T ) ( M
[ 85ULL ] != 0 ) ; t913 [ 45ULL ] = ( int32_T ) ( M [ 86ULL ] != 0 ) ; t913 [
46ULL ] = ( int32_T ) ( M [ 87ULL ] != 0 ) ; t913 [ 47ULL ] = ( int32_T ) ( M
[ 88ULL ] != 0 ) ; t913 [ 48ULL ] = ( int32_T ) ( M [ 89ULL ] != 0 ) ; t913 [
49ULL ] = ( int32_T ) ( M [ 90ULL ] != 0 ) ; t913 [ 50ULL ] = ( int32_T ) ( M
[ 91ULL ] != 0 ) ; t913 [ 51ULL ] = ( int32_T ) ( M [ 92ULL ] != 0 ) ; t913 [
52ULL ] = ( int32_T ) ( M [ 82ULL ] != 0 ) ; t913 [ 53ULL ] = ( int32_T ) ( M
[ 84ULL ] != 0 ) ; t913 [ 54ULL ] = ( int32_T ) ( M [ 85ULL ] != 0 ) ; t913 [
55ULL ] = ( int32_T ) ( M [ 86ULL ] != 0 ) ; t913 [ 56ULL ] = ( int32_T ) ( M
[ 93ULL ] != 0 ) ; t913 [ 57ULL ] = ( int32_T ) ( M [ 95ULL ] != 0 ) ; t913 [
58ULL ] = ( int32_T ) ( M [ 96ULL ] != 0 ) ; t913 [ 59ULL ] = ( int32_T ) ( M
[ 97ULL ] != 0 ) ; t913 [ 60ULL ] = ( int32_T ) ( M [ 98ULL ] != 0 ) ; t913 [
61ULL ] = ( int32_T ) ( M [ 99ULL ] != 0 ) ; t913 [ 62ULL ] = ( int32_T ) ( M
[ 100ULL ] != 0 ) ; t913 [ 63ULL ] = ( int32_T ) ( M [ 101ULL ] != 0 ) ; t913
[ 64ULL ] = ( int32_T ) ( M [ 102ULL ] != 0 ) ; t913 [ 65ULL ] = ( int32_T )
( M [ 103ULL ] != 0 ) ; t913 [ 66ULL ] = ( int32_T ) ( M [ 104ULL ] != 0 ) ;
t913 [ 67ULL ] = ( int32_T ) ( M [ 60ULL ] != 0 ) ; t913 [ 68ULL ] = (
int32_T ) ( M [ 62ULL ] != 0 ) ; t913 [ 69ULL ] = ( int32_T ) ( M [ 63ULL ]
!= 0 ) ; t913 [ 70ULL ] = ( int32_T ) ( M [ 64ULL ] != 0 ) ; t913 [ 71ULL ] =
( int32_T ) ( M [ 106ULL ] != 0 ) ; t913 [ 72ULL ] = ( int32_T ) ( M [ 66ULL
] != 0 ) ; t913 [ 73ULL ] = ( int32_T ) ( M [ 67ULL ] != 0 ) ; t913 [ 74ULL ]
= ( int32_T ) ( M [ 68ULL ] != 0 ) ; t913 [ 75ULL ] = ( int32_T ) ( M [ 69ULL
] != 0 ) ; t913 [ 76ULL ] = ( int32_T ) ( M [ 107ULL ] != 0 ) ; t913 [ 77ULL
] = ( int32_T ) ( M [ 108ULL ] != 0 ) ; t913 [ 78ULL ] = ( int32_T ) ( M [
109ULL ] != 0 ) ; t913 [ 79ULL ] = ( int32_T ) ( M [ 110ULL ] != 0 ) ; t913 [
80ULL ] = ( int32_T ) ( M [ 111ULL ] != 0 ) ; t913 [ 81ULL ] = ( int32_T ) (
M [ 112ULL ] != 0 ) ; t913 [ 82ULL ] = ( int32_T ) ( M [ 71ULL ] != 0 ) ;
t913 [ 83ULL ] = ( int32_T ) ( M [ 73ULL ] != 0 ) ; t913 [ 84ULL ] = (
int32_T ) ( M [ 74ULL ] != 0 ) ; t913 [ 85ULL ] = ( int32_T ) ( M [ 75ULL ]
!= 0 ) ; t913 [ 86ULL ] = ( int32_T ) ( M [ 113ULL ] != 0 ) ; t913 [ 87ULL ]
= ( int32_T ) ( M [ 77ULL ] != 0 ) ; t913 [ 88ULL ] = ( int32_T ) ( M [ 78ULL
] != 0 ) ; t913 [ 89ULL ] = ( int32_T ) ( M [ 79ULL ] != 0 ) ; t913 [ 90ULL ]
= ( int32_T ) ( M [ 80ULL ] != 0 ) ; t913 [ 91ULL ] = ( int32_T ) ( M [
114ULL ] != 0 ) ; t913 [ 92ULL ] = ( int32_T ) ( M [ 115ULL ] != 0 ) ; t913 [
93ULL ] = ( int32_T ) ( M [ 117ULL ] != 0 ) ; t913 [ 94ULL ] = ( int32_T ) (
M [ 118ULL ] != 0 ) ; t913 [ 95ULL ] = ( int32_T ) ( M [ 119ULL ] != 0 ) ;
t913 [ 96ULL ] = ( int32_T ) ( M [ 54ULL ] != 0 ) ; t913 [ 97ULL ] = (
int32_T ) ( M [ 55ULL ] != 0 ) ; t913 [ 98ULL ] = ( int32_T ) ( M [ 56ULL ]
!= 0 ) ; t913 [ 99ULL ] = ( int32_T ) ( M [ 57ULL ] != 0 ) ; t913 [ 100ULL ]
= ( int32_T ) ( M [ 58ULL ] != 0 ) ; t913 [ 101ULL ] = ( int32_T ) ( M [
120ULL ] != 0 ) ; t913 [ 102ULL ] = ( int32_T ) ( M [ 121ULL ] != 0 ) ; t913
[ 103ULL ] = ( int32_T ) ( M [ 122ULL ] != 0 ) ; t913 [ 104ULL ] = ( int32_T
) ( M [ 123ULL ] != 0 ) ; t913 [ 105ULL ] = ( int32_T ) ( M [ 124ULL ] != 0 )
; t913 [ 106ULL ] = ( int32_T ) ( M [ 125ULL ] != 0 ) ; t913 [ 107ULL ] = (
int32_T ) ( M [ 127ULL ] != 0 ) ; t913 [ 108ULL ] = ( int32_T ) ( M [ 128ULL
] != 0 ) ; t913 [ 109ULL ] = ( int32_T ) ( M [ 125ULL ] != 0 ) ; t913 [
110ULL ] = ( int32_T ) ( M [ 124ULL ] != 0 ) ; t913 [ 111ULL ] = ( int32_T )
( M [ 128ULL ] != 0 ) ; t913 [ 112ULL ] = ( int32_T ) ( M [ 127ULL ] != 0 ) ;
t913 [ 113ULL ] = ( int32_T ) ( M [ 129ULL ] != 0 ) ; t913 [ 114ULL ] = (
int32_T ) ( M [ 130ULL ] != 0 ) ; t913 [ 115ULL ] = ( int32_T ) ( M [ 131ULL
] != 0 ) ; t913 [ 116ULL ] = ( int32_T ) ( M [ 132ULL ] != 0 ) ; t913 [
117ULL ] = ( int32_T ) ( M [ 133ULL ] != 0 ) ; t913 [ 118ULL ] = ( int32_T )
( M [ 134ULL ] != 0 ) ; t913 [ 119ULL ] = ( int32_T ) ( M [ 135ULL ] != 0 ) ;
t913 [ 120ULL ] = ( int32_T ) ( M [ 136ULL ] != 0 ) ; t913 [ 121ULL ] = (
int32_T ) ( M [ 138ULL ] != 0 ) ; t913 [ 122ULL ] = ( int32_T ) ( M [ 117ULL
] != 0 ) ; t913 [ 123ULL ] = ( int32_T ) ( M [ 115ULL ] != 0 ) ; t913 [
124ULL ] = ( int32_T ) ( M [ 139ULL ] != 0 ) ; t913 [ 125ULL ] = ( int32_T )
( M [ 140ULL ] != 0 ) ; t913 [ 126ULL ] = ( int32_T ) ( M [ 141ULL ] != 0 ) ;
t913 [ 127ULL ] = ( int32_T ) ( M [ 96ULL ] != 0 ) ; t913 [ 128ULL ] = (
int32_T ) ( M [ 95ULL ] != 0 ) ; t913 [ 129ULL ] = ( int32_T ) ( M [ 142ULL ]
!= 0 ) ; t913 [ 130ULL ] = ( int32_T ) ( M [ 143ULL ] != 0 ) ; t913 [ 131ULL
] = ( int32_T ) ( M [ 144ULL ] != 0 ) ; t913 [ 132ULL ] = ( int32_T ) ( M [
145ULL ] != 0 ) ; t913 [ 133ULL ] = ( int32_T ) ( M [ 146ULL ] != 0 ) ; t913
[ 134ULL ] = ( int32_T ) ( M [ 147ULL ] != 0 ) ; t913 [ 135ULL ] = ( int32_T
) ( M [ 149ULL ] != 0 ) ; t913 [ 136ULL ] = ( int32_T ) ( M [ 150ULL ] != 0 )
; t913 [ 137ULL ] = ( int32_T ) ( M [ 151ULL ] != 0 ) ; t913 [ 138ULL ] = (
int32_T ) ( M [ 151ULL ] != 0 ) ; t913 [ 139ULL ] = ( int32_T ) ( M [ 152ULL
] != 0 ) ; t913 [ 140ULL ] = ( int32_T ) ( M [ 153ULL ] != 0 ) ; t913 [
141ULL ] = ( int32_T ) ( M [ 154ULL ] != 0 ) ; t913 [ 142ULL ] = ( int32_T )
( M [ 155ULL ] != 0 ) ; t913 [ 143ULL ] = ( int32_T ) ! intrm_sf_mf_1801 ;
t913 [ 144ULL ] = ( int32_T ) ( M [ 156ULL ] != 0 ) ; t913 [ 145ULL ] = 1 ;
t913 [ 146ULL ] = 1 ; t913 [ 147ULL ] = ( int32_T ) ( M [ 157ULL ] != 0 ) ;
t913 [ 148ULL ] = ( int32_T ) ( M [ 158ULL ] != 0 ) ; t913 [ 149ULL ] = (
int32_T ) ( M [ 160ULL ] != 0 ) ; t913 [ 150ULL ] = ( int32_T ) ( M [ 161ULL
] != 0 ) ; t913 [ 151ULL ] = ( int32_T ) ( M [ 162ULL ] != 0 ) ; t913 [
152ULL ] = ( int32_T ) ( M [ 163ULL ] != 0 ) ; t913 [ 153ULL ] = ( int32_T )
( M [ 164ULL ] != 0 ) ; t913 [ 154ULL ] = ( int32_T ) ( M [ 165ULL ] != 0 ) ;
t913 [ 155ULL ] = ( int32_T ) ( M [ 166ULL ] != 0 ) ; t913 [ 156ULL ] = (
int32_T ) ( M [ 167ULL ] != 0 ) ; t913 [ 157ULL ] = ( int32_T ) ( M [ 168ULL
] != 0 ) ; t913 [ 158ULL ] = ( int32_T ) ( M [ 169ULL ] != 0 ) ; t913 [
159ULL ] = ( int32_T ) ( M [ 162ULL ] != 0 ) ; t913 [ 160ULL ] = ( int32_T )
( M [ 163ULL ] != 0 ) ; t913 [ 161ULL ] = ( int32_T ) ( M [ 164ULL ] != 0 ) ;
t913 [ 162ULL ] = ( int32_T ) ( M [ 165ULL ] != 0 ) ; t913 [ 163ULL ] = (
int32_T ) ( M [ 171ULL ] != 0 ) ; t913 [ 164ULL ] = ( int32_T ) ( M [ 172ULL
] != 0 ) ; t913 [ 165ULL ] = 1 ; t913 [ 166ULL ] = 1 ; t913 [ 167ULL ] = (
int32_T ) ( M [ 173ULL ] != 0 ) ; t913 [ 168ULL ] = ( int32_T ) ( M [ 174ULL
] != 0 ) ; t913 [ 169ULL ] = ( int32_T ) ( M [ 175ULL ] != 0 ) ; t913 [
170ULL ] = ( int32_T ) ( M [ 176ULL ] != 0 ) ; t913 [ 171ULL ] = ( int32_T )
( M [ 177ULL ] != 0 ) ; t913 [ 172ULL ] = ( int32_T ) ( M [ 178ULL ] != 0 ) ;
t913 [ 173ULL ] = ( int32_T ) ( M [ 179ULL ] != 0 ) ; t913 [ 174ULL ] = (
int32_T ) ( M [ 180ULL ] != 0 ) ; t913 [ 175ULL ] = ( int32_T ) ( M [ 182ULL
] != 0 ) ; t913 [ 176ULL ] = ( int32_T ) ( M [ 183ULL ] != 0 ) ; t913 [
177ULL ] = ( int32_T ) ( M [ 184ULL ] != 0 ) ; t913 [ 178ULL ] = ( int32_T )
( M [ 185ULL ] != 0 ) ; t913 [ 179ULL ] = ( int32_T ) t132 ; t913 [ 180ULL ]
= ( int32_T ) t133 ; t913 [ 181ULL ] = ( int32_T ) ( M [ 177ULL ] != 0 ) ;
t913 [ 182ULL ] = ( int32_T ) ( M [ 178ULL ] != 0 ) ; t913 [ 183ULL ] = (
int32_T ) ( M [ 179ULL ] != 0 ) ; t913 [ 184ULL ] = ( int32_T ) ( M [ 180ULL
] != 0 ) ; t913 [ 185ULL ] = ( int32_T ) ( M [ 157ULL ] != 0 ) ; t913 [
186ULL ] = ( int32_T ) ( M [ 158ULL ] != 0 ) ; t913 [ 187ULL ] = ( int32_T )
( M [ 160ULL ] != 0 ) ; t913 [ 188ULL ] = ( int32_T ) ( M [ 161ULL ] != 0 ) ;
t913 [ 189ULL ] = ( int32_T ) ( M [ 186ULL ] != 0 ) ; t913 [ 190ULL ] = (
int32_T ) ( M [ 187ULL ] != 0 ) ; t913 [ 191ULL ] = ( int32_T ) ( M [ 188ULL
] != 0 ) ; t913 [ 192ULL ] = ( int32_T ) ( M [ 189ULL ] != 0 ) ; t913 [
193ULL ] = ( int32_T ) t134 ; t913 [ 194ULL ] = 1 ; t913 [ 195ULL ] = (
int32_T ) ( M [ 190ULL ] != 0 ) ; t913 [ 196ULL ] = ( int32_T ) ( M [ 191ULL
] != 0 ) ; t913 [ 197ULL ] = ( int32_T ) ( M [ 193ULL ] != 0 ) ; t913 [
198ULL ] = ( int32_T ) ( M [ 194ULL ] != 0 ) ; t913 [ 199ULL ] = ( int32_T )
( M [ 173ULL ] != 0 ) ; t913 [ 200ULL ] = ( int32_T ) ( M [ 174ULL ] != 0 ) ;
t913 [ 201ULL ] = ( int32_T ) ( M [ 175ULL ] != 0 ) ; t913 [ 202ULL ] = (
int32_T ) ( M [ 176ULL ] != 0 ) ; t913 [ 203ULL ] = ( int32_T ) ( M [ 195ULL
] != 0 ) ; t913 [ 204ULL ] = ( int32_T ) ( M [ 196ULL ] != 0 ) ; t913 [
205ULL ] = ( int32_T ) ( M [ 197ULL ] != 0 ) ; t913 [ 206ULL ] = ( int32_T )
( M [ 198ULL ] != 0 ) ; t913 [ 207ULL ] = ( int32_T ) ( M [ 199ULL ] != 0 ) ;
t913 [ 208ULL ] = 1 ; t913 [ 209ULL ] = 1 ; t913 [ 210ULL ] = ( int32_T ) ( M
[ 200ULL ] != 0 ) ; t913 [ 211ULL ] = ( int32_T ) ( M [ 201ULL ] != 0 ) ;
t913 [ 212ULL ] = ( int32_T ) ( M [ 202ULL ] != 0 ) ; t913 [ 213ULL ] = (
int32_T ) ( M [ 204ULL ] != 0 ) ; t913 [ 214ULL ] = ( int32_T ) ( M [ 205ULL
] != 0 ) ; t913 [ 215ULL ] = ( int32_T ) ( M [ 206ULL ] != 0 ) ; t913 [
216ULL ] = ( int32_T ) ( M [ 207ULL ] != 0 ) ; t913 [ 217ULL ] = ( int32_T )
( M [ 208ULL ] != 0 ) ; t913 [ 218ULL ] = ( int32_T ) ( M [ 209ULL ] != 0 ) ;
t913 [ 219ULL ] = ( int32_T ) ( M [ 210ULL ] != 0 ) ; t913 [ 220ULL ] = (
int32_T ) ( M [ 211ULL ] != 0 ) ; t913 [ 221ULL ] = ( int32_T ) ( M [ 212ULL
] != 0 ) ; t913 [ 222ULL ] = ( int32_T ) ( M [ 205ULL ] != 0 ) ; t913 [
223ULL ] = ( int32_T ) ( M [ 206ULL ] != 0 ) ; t913 [ 224ULL ] = ( int32_T )
( M [ 207ULL ] != 0 ) ; t913 [ 225ULL ] = ( int32_T ) ( M [ 208ULL ] != 0 ) ;
t913 [ 226ULL ] = ( int32_T ) ( M [ 213ULL ] != 0 ) ; t913 [ 227ULL ] = (
int32_T ) ( M [ 216ULL ] != 0 ) ; t913 [ 228ULL ] = 1 ; t913 [ 229ULL ] = 1 ;
t913 [ 230ULL ] = ( int32_T ) ( M [ 217ULL ] != 0 ) ; t913 [ 231ULL ] = (
int32_T ) ( M [ 218ULL ] != 0 ) ; t913 [ 232ULL ] = ( int32_T ) ( M [ 219ULL
] != 0 ) ; t913 [ 233ULL ] = ( int32_T ) ( M [ 220ULL ] != 0 ) ; t913 [
234ULL ] = ( int32_T ) ( M [ 221ULL ] != 0 ) ; t913 [ 235ULL ] = ( int32_T )
( M [ 222ULL ] != 0 ) ; t913 [ 236ULL ] = ( int32_T ) ( M [ 223ULL ] != 0 ) ;
t913 [ 237ULL ] = ( int32_T ) ( M [ 224ULL ] != 0 ) ; t913 [ 238ULL ] = (
int32_T ) ( M [ 225ULL ] != 0 ) ; t913 [ 239ULL ] = ( int32_T ) ( M [ 227ULL
] != 0 ) ; t913 [ 240ULL ] = ( int32_T ) ( M [ 228ULL ] != 0 ) ; t913 [
241ULL ] = ( int32_T ) ( M [ 229ULL ] != 0 ) ; t913 [ 242ULL ] = ( int32_T )
t135 ; t913 [ 243ULL ] = ( int32_T ) t136 ; t913 [ 244ULL ] = ( int32_T ) ( M
[ 221ULL ] != 0 ) ; t913 [ 245ULL ] = ( int32_T ) ( M [ 222ULL ] != 0 ) ;
t913 [ 246ULL ] = ( int32_T ) ( M [ 223ULL ] != 0 ) ; t913 [ 247ULL ] = (
int32_T ) ( M [ 224ULL ] != 0 ) ; t913 [ 248ULL ] = ( int32_T ) ( M [ 200ULL
] != 0 ) ; t913 [ 249ULL ] = ( int32_T ) ( M [ 201ULL ] != 0 ) ; t913 [
250ULL ] = ( int32_T ) ( M [ 202ULL ] != 0 ) ; t913 [ 251ULL ] = ( int32_T )
( M [ 204ULL ] != 0 ) ; t913 [ 252ULL ] = ( int32_T ) ( M [ 230ULL ] != 0 ) ;
t913 [ 253ULL ] = ( int32_T ) ( M [ 231ULL ] != 0 ) ; t913 [ 254ULL ] = (
int32_T ) ( M [ 232ULL ] != 0 ) ; t913 [ 255ULL ] = ( int32_T ) ( M [ 233ULL
] != 0 ) ; t913 [ 256ULL ] = ( int32_T ) t137 ; t913 [ 257ULL ] = 1 ; t913 [
258ULL ] = ( int32_T ) ( M [ 234ULL ] != 0 ) ; t913 [ 259ULL ] = ( int32_T )
( M [ 235ULL ] != 0 ) ; t913 [ 260ULL ] = ( int32_T ) ( M [ 236ULL ] != 0 ) ;
t913 [ 261ULL ] = ( int32_T ) ( M [ 238ULL ] != 0 ) ; t913 [ 262ULL ] = (
int32_T ) ( M [ 217ULL ] != 0 ) ; t913 [ 263ULL ] = ( int32_T ) ( M [ 218ULL
] != 0 ) ; t913 [ 264ULL ] = ( int32_T ) ( M [ 219ULL ] != 0 ) ; t913 [
265ULL ] = ( int32_T ) ( M [ 220ULL ] != 0 ) ; t913 [ 266ULL ] = ( int32_T )
( M [ 239ULL ] != 0 ) ; t913 [ 267ULL ] = ( int32_T ) ( M [ 240ULL ] != 0 ) ;
t913 [ 268ULL ] = ( int32_T ) ( M [ 241ULL ] != 0 ) ; t913 [ 269ULL ] = (
int32_T ) ( M [ 242ULL ] != 0 ) ; t913 [ 270ULL ] = ( int32_T ) ( M [ 243ULL
] != 0 ) ; t913 [ 271ULL ] = ( int32_T ) ( M [ 244ULL ] != 0 ) ; t913 [
272ULL ] = ( int32_T ) ( M [ 245ULL ] != 0 ) ; t913 [ 273ULL ] = ( int32_T )
( M [ 246ULL ] != 0 ) ; t913 [ 274ULL ] = ( int32_T ) ( M [ 247ULL ] != 0 ) ;
t913 [ 275ULL ] = ( int32_T ) ( M [ 249ULL ] != 0 ) ; t913 [ 276ULL ] = (
int32_T ) ( M [ 250ULL ] != 0 ) ; t913 [ 277ULL ] = ( int32_T ) ( M [ 251ULL
] != 0 ) ; t913 [ 278ULL ] = ( int32_T ) ( M [ 252ULL ] != 0 ) ; t913 [
279ULL ] = ( int32_T ) ( M [ 253ULL ] != 0 ) ; t913 [ 280ULL ] = ( int32_T )
( M [ 254ULL ] != 0 ) ; t913 [ 281ULL ] = ( int32_T ) ( M [ 251ULL ] != 0 ) ;
t913 [ 282ULL ] = ( int32_T ) ( M [ 252ULL ] != 0 ) ; t913 [ 283ULL ] = (
int32_T ) ( M [ 253ULL ] != 0 ) ; t913 [ 284ULL ] = ( int32_T ) ( M [ 254ULL
] != 0 ) ; t913 [ 285ULL ] = ( int32_T ) ( M [ 255ULL ] != 0 ) ; t913 [
286ULL ] = ( int32_T ) ( M [ 256ULL ] != 0 ) ; t913 [ 287ULL ] = ( int32_T )
( M [ 257ULL ] != 0 ) ; t913 [ 288ULL ] = ( int32_T ) ( M [ 258ULL ] != 0 ) ;
t913 [ 289ULL ] = ( int32_T ) ( M [ 260ULL ] != 0 ) ; t913 [ 290ULL ] = (
int32_T ) ( M [ 261ULL ] != 0 ) ; t913 [ 291ULL ] = ( int32_T ) ( M [ 255ULL
] != 0 ) ; t913 [ 292ULL ] = ( int32_T ) ( M [ 256ULL ] != 0 ) ; t913 [
293ULL ] = ( int32_T ) ( M [ 262ULL ] != 0 ) ; t913 [ 294ULL ] = ( int32_T )
( M [ 263ULL ] != 0 ) ; t913 [ 295ULL ] = ( int32_T ) ( M [ 264ULL ] != 0 ) ;
t913 [ 296ULL ] = ( int32_T ) ( M [ 265ULL ] != 0 ) ; t913 [ 297ULL ] = (
int32_T ) ( M [ 262ULL ] != 0 ) ; t913 [ 298ULL ] = ( int32_T ) ( M [ 263ULL
] != 0 ) ; t913 [ 299ULL ] = ( int32_T ) ( M [ 264ULL ] != 0 ) ; t913 [
300ULL ] = ( int32_T ) ( M [ 265ULL ] != 0 ) ; t913 [ 301ULL ] = ( int32_T )
( M [ 246ULL ] != 0 ) ; t913 [ 302ULL ] = ( int32_T ) ( M [ 247ULL ] != 0 ) ;
t913 [ 303ULL ] = ( int32_T ) ( M [ 249ULL ] != 0 ) ; t913 [ 304ULL ] = (
int32_T ) ( M [ 250ULL ] != 0 ) ; t913 [ 305ULL ] = ( int32_T ) ( M [ 266ULL
] != 0 ) ; t913 [ 306ULL ] = ( int32_T ) ( M [ 267ULL ] != 0 ) ; t913 [
307ULL ] = ( int32_T ) ( M [ 268ULL ] != 0 ) ; t913 [ 308ULL ] = ( int32_T )
( M [ 269ULL ] != 0 ) ; t913 [ 309ULL ] = ( int32_T ) ( M [ 271ULL ] != 0 ) ;
t913 [ 310ULL ] = 1 ; t913 [ 311ULL ] = 1 ; t913 [ 312ULL ] = ( int32_T ) ( M
[ 272ULL ] != 0 ) ; t913 [ 313ULL ] = ( int32_T ) ( M [ 273ULL ] != 0 ) ;
t913 [ 314ULL ] = ( int32_T ) ( M [ 274ULL ] != 0 ) ; t913 [ 315ULL ] = (
int32_T ) ( M [ 275ULL ] != 0 ) ; t913 [ 316ULL ] = 1 ; t913 [ 317ULL ] = 1 ;
t913 [ 318ULL ] = ( int32_T ) ( M [ 276ULL ] != 0 ) ; t913 [ 319ULL ] = (
int32_T ) ( M [ 277ULL ] != 0 ) ; t913 [ 320ULL ] = ( int32_T ) ( M [ 278ULL
] != 0 ) ; t913 [ 321ULL ] = ( int32_T ) ( M [ 279ULL ] != 0 ) ; t913 [
322ULL ] = ( int32_T ) ( M [ 190ULL ] != 0 ) ; t913 [ 323ULL ] = ( int32_T )
( M [ 191ULL ] != 0 ) ; t913 [ 324ULL ] = ( int32_T ) ( M [ 280ULL ] != 0 ) ;
t913 [ 325ULL ] = ( int32_T ) ( M [ 281ULL ] != 0 ) ; t913 [ 326ULL ] = (
int32_T ) ( M [ 282ULL ] != 0 ) ; t913 [ 327ULL ] = ( int32_T ) ( M [ 283ULL
] != 0 ) ; t913 [ 328ULL ] = ( int32_T ) ( M [ 284ULL ] != 0 ) ; t913 [
329ULL ] = ( int32_T ) ( M [ 285ULL ] != 0 ) ; t913 [ 330ULL ] = ( int32_T )
( M [ 272ULL ] != 0 ) ; t913 [ 331ULL ] = ( int32_T ) ( M [ 273ULL ] != 0 ) ;
t913 [ 332ULL ] = ( int32_T ) ( M [ 286ULL ] != 0 ) ; t913 [ 333ULL ] = (
int32_T ) ( M [ 287ULL ] != 0 ) ; t913 [ 334ULL ] = ( int32_T ) ( M [ 276ULL
] != 0 ) ; t913 [ 335ULL ] = ( int32_T ) ( M [ 277ULL ] != 0 ) ; t913 [
336ULL ] = ( int32_T ) ( M [ 278ULL ] != 0 ) ; t913 [ 337ULL ] = ( int32_T )
( M [ 279ULL ] != 0 ) ; t913 [ 338ULL ] = ( int32_T ) ( M [ 288ULL ] != 0 ) ;
t913 [ 339ULL ] = ( int32_T ) ( M [ 289ULL ] != 0 ) ; t913 [ 340ULL ] = (
int32_T ) ( M [ 290ULL ] != 0 ) ; t913 [ 341ULL ] = ( int32_T ) ( M [ 291ULL
] != 0 ) ; t913 [ 342ULL ] = ( int32_T ) ( M [ 234ULL ] != 0 ) ; t913 [
343ULL ] = ( int32_T ) ( M [ 235ULL ] != 0 ) ; t913 [ 344ULL ] = ( int32_T )
( M [ 292ULL ] != 0 ) ; t913 [ 345ULL ] = ( int32_T ) ( M [ 293ULL ] != 0 ) ;
t913 [ 346ULL ] = 1 ; t913 [ 347ULL ] = 1 ; t913 [ 348ULL ] = ( int32_T ) ( M
[ 234ULL ] != 0 ) ; t913 [ 349ULL ] = ( int32_T ) ( M [ 235ULL ] != 0 ) ;
t913 [ 350ULL ] = ( int32_T ) ( M [ 294ULL ] != 0 ) ; t913 [ 351ULL ] = (
int32_T ) ( M [ 295ULL ] != 0 ) ; t913 [ 352ULL ] = 1 ; t913 [ 353ULL ] = 1 ;
t913 [ 354ULL ] = ( int32_T ) ( M [ 190ULL ] != 0 ) ; t913 [ 355ULL ] = (
int32_T ) ( M [ 191ULL ] != 0 ) ; t913 [ 356ULL ] = ( int32_T ) ( M [ 296ULL
] != 0 ) ; t913 [ 357ULL ] = ( int32_T ) ( M [ 297ULL ] != 0 ) ; t913 [
358ULL ] = ( int32_T ) ( M [ 157ULL ] != 0 ) ; t913 [ 359ULL ] = ( int32_T )
( M [ 158ULL ] != 0 ) ; t913 [ 360ULL ] = ( int32_T ) ( M [ 160ULL ] != 0 ) ;
t913 [ 361ULL ] = ( int32_T ) ( M [ 161ULL ] != 0 ) ; t913 [ 362ULL ] = (
int32_T ) ( M [ 190ULL ] != 0 ) ; t913 [ 363ULL ] = ( int32_T ) ( M [ 191ULL
] != 0 ) ; t913 [ 364ULL ] = ( int32_T ) ( M [ 298ULL ] != 0 ) ; t913 [
365ULL ] = ( int32_T ) ( M [ 299ULL ] != 0 ) ; t913 [ 366ULL ] = ( int32_T )
( M [ 300ULL ] != 0 ) ; t913 [ 367ULL ] = ( int32_T ) ( M [ 302ULL ] != 0 ) ;
t913 [ 368ULL ] = 1 ; t913 [ 369ULL ] = 1 ; t913 [ 370ULL ] = 1 ; t913 [
371ULL ] = 1 ; t913 [ 372ULL ] = 1 ; t913 [ 373ULL ] = 1 ; t913 [ 374ULL ] =
1 ; t913 [ 375ULL ] = 1 ; t913 [ 376ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2
+ 4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) && (
fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ;
t913 [ 377ULL ] = ( int32_T ) ( ( ! ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) ) || (
! ( fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) )
) || ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 378ULL
] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 379ULL ] = ( int32_T ) ( ( ! (
t1304 != 0.0 ) ) || ( t2773 != 0.0 ) ) ; t913 [ 380ULL ] = ( int32_T ) (
t1304 != 0.0 ) ; t913 [ 381ULL ] = 1 ; t913 [ 382ULL ] = ( int32_T ) ( t1304
!= 0.0 ) ; t913 [ 383ULL ] = 1 ; t913 [ 384ULL ] = 1 ; t913 [ 385ULL ] = 1 ;
t913 [ 386ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12
== U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2
+ 4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 387ULL ] = (
int32_T ) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 388ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 389ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( t2769 !=
0.0 ) ) ; t913 [ 390ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 391ULL ] =
1 ; t913 [ 392ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 393ULL ] = 1 ;
t913 [ 394ULL ] = 1 ; t913 [ 395ULL ] = 1 ; t913 [ 396ULL ] = 1 ; t913 [
397ULL ] = 1 ; t913 [ 398ULL ] = ( int32_T ) ( ( X [ 100ULL ] * X [ 100ULL ]
+ t2678 * t2678 == X [ 100ULL ] * X [ 100ULL ] + t2678 * t2678 ) && ( fabs (
X [ 100ULL ] * X [ 100ULL ] + t2678 * t2678 ) != pmf_get_inf ( ) ) ) ; t913 [
399ULL ] = ( int32_T ) ( ( ! ( X [ 100ULL ] * X [ 100ULL ] + t2678 * t2678 ==
X [ 100ULL ] * X [ 100ULL ] + t2678 * t2678 ) ) || ( ! ( fabs ( X [ 100ULL ]
* X [ 100ULL ] + t2678 * t2678 ) != pmf_get_inf ( ) ) ) || ( X [ 100ULL ] * X
[ 100ULL ] + t2678 * t2678 >= 0.0 ) ) ; t913 [ 400ULL ] = 1 ; t913 [ 401ULL ]
= 1 ; t913 [ 402ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) && (
fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ;
t913 [ 403ULL ] = ( int32_T ) ( ( ! ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) ) || (
! ( fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) )
) || ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 404ULL
] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 405ULL ] = ( int32_T ) ( ( ! (
t1304 != 0.0 ) ) || (
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co1 != 0.0 ) ) ;
t913 [ 406ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 407ULL ] = 1 ; t913 [
408ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 409ULL ] = 1 ; t913 [ 410ULL
] = 1 ; t913 [ 411ULL ] = 1 ; t913 [ 412ULL ] = ( int32_T ) ( ( U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 413ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 414ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 415ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( t1401 !=
0.0 ) ) ; t913 [ 416ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 417ULL ] =
1 ; t913 [ 418ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 419ULL ] = 1 ;
t913 [ 420ULL ] = 1 ; t913 [ 421ULL ] = 1 ; t913 [ 422ULL ] = 1 ; t913 [
423ULL ] = 1 ; t913 [ 424ULL ] = ( int32_T ) ( ( X [ 109ULL ] * X [ 109ULL ]
+ Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 == X [ 109ULL
] * X [ 109ULL ] +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 ) && ( fabs (
X [ 109ULL ] * X [ 109ULL ] +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 425ULL ] = ( int32_T ) ( ( ! ( X [ 109ULL ] * X
[ 109ULL ] + Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1
* Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 == X [
109ULL ] * X [ 109ULL ] +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 ) ) || ( ! (
fabs ( X [ 109ULL ] * X [ 109ULL ] +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 ) !=
pmf_get_inf ( ) ) ) || ( X [ 109ULL ] * X [ 109ULL ] +
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 *
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_ve1 >= 0.0 ) ) ;
t913 [ 426ULL ] = 1 ; t913 [ 427ULL ] = 1 ; t913 [ 428ULL ] = ( int32_T ) ( (
U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 429ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 430ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 431ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio1 != 0.0 ) ) ;
t913 [ 432ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 433ULL ] = 1 ; t913 [
434ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 435ULL ] = 1 ; t913 [ 436ULL
] = 1 ; t913 [ 437ULL ] = 1 ; t913 [ 438ULL ] = ( int32_T ) ( ( U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 439ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 440ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 441ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( t1403 !=
0.0 ) ) ; t913 [ 442ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 443ULL ] =
1 ; t913 [ 444ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 445ULL ] = 1 ;
t913 [ 446ULL ] = 1 ; t913 [ 447ULL ] = 1 ; t913 [ 448ULL ] = 1 ; t913 [
449ULL ] = 1 ; t913 [ 450ULL ] = ( int32_T ) ( ( X [ 118ULL ] * X [ 118ULL ]
+ Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c == X [ 118ULL
] * X [ 118ULL ] +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c ) && ( fabs (
X [ 118ULL ] * X [ 118ULL ] +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c ) !=
pmf_get_inf ( ) ) ) ; t913 [ 451ULL ] = ( int32_T ) ( ( ! ( X [ 118ULL ] * X
[ 118ULL ] + Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c
* Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c == X [
118ULL ] * X [ 118ULL ] +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c ) ) || ( ! (
fabs ( X [ 118ULL ] * X [ 118ULL ] +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c ) !=
pmf_get_inf ( ) ) ) || ( X [ 118ULL ] * X [ 118ULL ] +
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c *
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_velocity_c >= 0.0 ) ) ;
t913 [ 452ULL ] = ( int32_T ) ( t1407 * 7.8539816339744827E-5 != 0.0 ) ; t913
[ 453ULL ] = ( int32_T ) ( t1409 != 0.0 ) ; t913 [ 454ULL ] = ( int32_T ) ( (
! ( t1409 != 0.0 ) ) || ( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 455ULL ] = 1 ; t913 [ 456ULL ] = 1
; t913 [ 457ULL ] = ( int32_T ) ( ( ! ( t1409 != 0.0 ) ) || ( ( t1409 != 0.0
) && ( ! ( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409 ) + 0.00017169489553429715
> 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1409 == 0.0 ? 1.0E-16 : t1409
) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 458ULL ] = ( int32_T
) ( ( t1411 / 8.0 == t1411 / 8.0 ) && ( fabs ( t1411 / 8.0 ) != pmf_get_inf (
) ) ) ; t913 [ 459ULL ] = ( int32_T ) ( ( ! ( t1411 / 8.0 == t1411 / 8.0 ) )
|| ( ! ( fabs ( t1411 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1411 / 8.0 >= 0.0
) ) ; t913 [ 460ULL ] = 1 ; t913 [ 461ULL ] = ( int32_T ) (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg >= 0.0 ) ; t913 [
462ULL ] = ( int32_T ) ( ( ! ( t1411 / 8.0 == t1411 / 8.0 ) ) || ( ! ( fabs (
t1411 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1411 / 8.0 == t1411 / 8.0 ) && (
fabs ( t1411 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1411 / 8.0 >= 0.0 ) ) )
|| ( ! ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg >= 0.0 )
) || ( ( pmf_pow ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg
, 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1411 / 8.0 ) * 12.7 + 1.0 !=
0.0 ) ) ; t913 [ 463ULL ] = 1 ; t913 [ 464ULL ] = 1 ; t913 [ 465ULL ] = 1 ;
t913 [ 466ULL ] = 1 ; t913 [ 467ULL ] = ( int32_T ) ( t1406 + 1.0 != 0.0 ) ;
t913 [ 468ULL ] = 1 ; t913 [ 469ULL ] = ( int32_T ) ( ( ! ( t1406 + 1.0 !=
0.0 ) ) || ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg !=
0.0 ) ) ; t913 [ 470ULL ] = ( int32_T ) ( - t1408 < 663.67513503334737 ) ;
t913 [ 471ULL ] = 1 ; t913 [ 472ULL ] = 1 ; t913 [ 473ULL ] = ( int32_T ) ( (
U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) && ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 474ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 475ULL ] = ( int32_T ) ( t1412 !=
0.0 ) ; t913 [ 476ULL ] = ( int32_T ) ( ( ! ( t1412 != 0.0 ) ) || ( t1413 !=
0.0 ) ) ; t913 [ 477ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 478ULL ] =
1 ; t913 [ 479ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 480ULL ] = 1 ;
t913 [ 481ULL ] = 1 ; t913 [ 482ULL ] = 1 ; t913 [ 483ULL ] = ( int32_T ) ( (
U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) && ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 484ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 485ULL ] = ( int32_T ) ( t1412 !=
0.0 ) ; t913 [ 486ULL ] = ( int32_T ) ( ( ! ( t1412 != 0.0 ) ) || ( t1414 !=
0.0 ) ) ; t913 [ 487ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 488ULL ] =
1 ; t913 [ 489ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 490ULL ] = 1 ;
t913 [ 491ULL ] = 1 ; t913 [ 492ULL ] = 1 ; t913 [ 493ULL ] = ( int32_T ) (
t1415 != 0.0 ) ; t913 [ 494ULL ] = ( int32_T ) ( t1418 *
7.8539816339744827E-5 != 0.0 ) ; t913 [ 495ULL ] = ( int32_T ) ( t1421 != 0.0
) ; t913 [ 496ULL ] = ( int32_T ) ( ( ! ( t1421 != 0.0 ) ) || ( 6.9 / ( t1421
== 0.0 ? 1.0E-16 : t1421 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 497ULL
] = 1 ; t913 [ 498ULL ] = 1 ; t913 [ 499ULL ] = ( int32_T ) ( ( ! ( t1421 !=
0.0 ) ) || ( ( t1421 != 0.0 ) && ( ! ( 6.9 / ( t1421 == 0.0 ? 1.0E-16 : t1421
) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1421 == 0.0
? 1.0E-16 : t1421 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1421 ==
0.0 ? 1.0E-16 : t1421 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
500ULL ] = ( int32_T ) ( ( t1423 / 8.0 == t1423 / 8.0 ) && ( fabs ( t1423 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 501ULL ] = ( int32_T ) ( ( ! ( t1423 /
8.0 == t1423 / 8.0 ) ) || ( ! ( fabs ( t1423 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1423 / 8.0 >= 0.0 ) ) ; t913 [ 502ULL ] = 1 ; t913 [ 503ULL ] = (
int32_T ) ( Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg >= 0.0
) ; t913 [ 504ULL ] = ( int32_T ) ( ( ! ( t1423 / 8.0 == t1423 / 8.0 ) ) || (
! ( fabs ( t1423 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1423 / 8.0 == t1423 /
8.0 ) && ( fabs ( t1423 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1423 / 8.0 >=
0.0 ) ) ) || ( ! ( Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg
>= 0.0 ) ) || ( ( pmf_pow (
Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1423 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 505ULL ] = 1 ; t913 [ 506ULL ] = 1 ; t913 [ 507ULL ] = 1 ; t913
[ 508ULL ] = 1 ; t913 [ 509ULL ] = ( int32_T ) ( t1419 + 1.0 != 0.0 ) ; t913
[ 510ULL ] = 1 ; t913 [ 511ULL ] = ( int32_T ) ( ( ! ( t1419 + 1.0 != 0.0 ) )
|| ( Electrical_Cooling_System_Pipe_Converter_pipe_model_Pr_avg != 0.0 ) ) ;
t913 [ 512ULL ] = ( int32_T ) ( -
Electrical_Cooling_System_Pipe_Converter_pipe_model_NTU < 663.67513503334737
) ; t913 [ 513ULL ] = 1 ; t913 [ 514ULL ] = 1 ; t913 [ 515ULL ] = ( int32_T )
( ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) && ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 516ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 517ULL ] = ( int32_T ) ( t1412 !=
0.0 ) ; t913 [ 518ULL ] = ( int32_T ) ( ( ! ( t1412 != 0.0 ) ) || (
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection1 != 0.0 ) ) ;
t913 [ 519ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 520ULL ] = 1 ; t913 [
521ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 522ULL ] = 1 ; t913 [ 523ULL
] = 1 ; t913 [ 524ULL ] = 1 ; t913 [ 525ULL ] = ( int32_T ) ( ( U_idx_2 *
U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) && ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 526ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 527ULL ] = ( int32_T ) ( t1412 !=
0.0 ) ; t913 [ 528ULL ] = ( int32_T ) ( ( ! ( t1412 != 0.0 ) ) || ( t1425 !=
0.0 ) ) ; t913 [ 529ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 530ULL ] =
1 ; t913 [ 531ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 532ULL ] = 1 ;
t913 [ 533ULL ] = 1 ; t913 [ 534ULL ] = 1 ; t913 [ 535ULL ] = ( int32_T ) (
t1426 != 0.0 ) ; t913 [ 536ULL ] = ( int32_T ) ( t1428 *
7.8539816339744827E-5 != 0.0 ) ; t913 [ 537ULL ] = ( int32_T ) ( t1430 != 0.0
) ; t913 [ 538ULL ] = ( int32_T ) ( ( ! ( t1430 != 0.0 ) ) || ( 6.9 / ( t1430
== 0.0 ? 1.0E-16 : t1430 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 539ULL
] = 1 ; t913 [ 540ULL ] = 1 ; t913 [ 541ULL ] = ( int32_T ) ( ( ! ( t1430 !=
0.0 ) ) || ( ( t1430 != 0.0 ) && ( ! ( 6.9 / ( t1430 == 0.0 ? 1.0E-16 : t1430
) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1430 == 0.0
? 1.0E-16 : t1430 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1430 ==
0.0 ? 1.0E-16 : t1430 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
542ULL ] = ( int32_T ) ( ( t1431 / 8.0 == t1431 / 8.0 ) && ( fabs ( t1431 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 543ULL ] = ( int32_T ) ( ( ! ( t1431 /
8.0 == t1431 / 8.0 ) ) || ( ! ( fabs ( t1431 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1431 / 8.0 >= 0.0 ) ) ; t913 [ 544ULL ] = 1 ; t913 [ 545ULL ] = (
int32_T ) ( Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0 ) ;
t913 [ 546ULL ] = ( int32_T ) ( ( ! ( t1431 / 8.0 == t1431 / 8.0 ) ) || ( ! (
fabs ( t1431 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1431 / 8.0 == t1431 / 8.0
) && ( fabs ( t1431 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1431 / 8.0 >= 0.0
) ) ) || ( ! ( Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg >= 0.0
) ) || ( ( pmf_pow ( Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1431 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 547ULL ] = 1 ; t913 [ 548ULL ] = 1 ; t913 [ 549ULL ] = 1 ; t913
[ 550ULL ] = 1 ; t913 [ 551ULL ] = ( int32_T ) ( t1429 + 1.0 != 0.0 ) ; t913
[ 552ULL ] = 1 ; t913 [ 553ULL ] = ( int32_T ) ( ( ! ( t1429 + 1.0 != 0.0 ) )
|| ( Electrical_Cooling_System_Pipe_Motor_pipe_model_Pr_avg != 0.0 ) ) ; t913
[ 554ULL ] = ( int32_T ) ( - t1410 < 663.67513503334737 ) ; t913 [ 555ULL ] =
1 ; t913 [ 556ULL ] = 1 ; t913 [ 557ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2
+ 1.8124727852251287E-13 == U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) && (
fabs ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ;
t913 [ 558ULL ] = ( int32_T ) ( ( ! ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 == U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) ) || (
! ( fabs ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) != pmf_get_inf ( ) )
) || ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 559ULL
] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 560ULL ] = ( int32_T ) ( ( ! (
t1412 != 0.0 ) ) || ( t1432 != 0.0 ) ) ; t913 [ 561ULL ] = ( int32_T ) (
t1412 != 0.0 ) ; t913 [ 562ULL ] = 1 ; t913 [ 563ULL ] = ( int32_T ) ( t1412
!= 0.0 ) ; t913 [ 564ULL ] = 1 ; t913 [ 565ULL ] = 1 ; t913 [ 566ULL ] = 1 ;
t913 [ 567ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13
== U_idx_2 * U_idx_2 + 1.8124727852251287E-13 ) && ( fabs ( U_idx_2 * U_idx_2
+ 1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 568ULL ] = (
int32_T ) ( ( ! ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 == U_idx_2 *
U_idx_2 + 1.8124727852251287E-13 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 >= 0.0 ) ) ; t913 [ 569ULL ] = ( int32_T ) ( t1412 !=
0.0 ) ; t913 [ 570ULL ] = ( int32_T ) ( ( ! ( t1412 != 0.0 ) ) || ( t1433 !=
0.0 ) ) ; t913 [ 571ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 572ULL ] =
1 ; t913 [ 573ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 574ULL ] = 1 ;
t913 [ 575ULL ] = 1 ; t913 [ 576ULL ] = 1 ; t913 [ 577ULL ] = ( int32_T ) (
t1435 != 0.0 ) ; t913 [ 578ULL ] = 1 ; t913 [ 579ULL ] = 1 ; t913 [ 580ULL ]
= ( int32_T ) ( ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 581ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 582ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 583ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( t1437 !=
0.0 ) ) ; t913 [ 584ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 585ULL ] =
1 ; t913 [ 586ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 587ULL ] = 1 ;
t913 [ 588ULL ] = 1 ; t913 [ 589ULL ] = 1 ; t913 [ 590ULL ] = ( int32_T ) ( (
U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 591ULL ] = ( int32_T
) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 592ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 593ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( t1438 !=
0.0 ) ) ; t913 [ 594ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 595ULL ] =
1 ; t913 [ 596ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 597ULL ] = 1 ;
t913 [ 598ULL ] = ( int32_T ) ( t1439 != 0.0 ) ; t913 [ 599ULL ] = ( int32_T
) ( ( t1440 * 402.5245441795231 == t1440 * 402.5245441795231 ) && ( fabs (
t1440 * 402.5245441795231 ) != pmf_get_inf ( ) ) ) ; t913 [ 600ULL ] = (
int32_T ) ( ( ! ( t1440 * 402.5245441795231 == t1440 * 402.5245441795231 ) )
|| ( ! ( fabs ( t1440 * 402.5245441795231 ) != pmf_get_inf ( ) ) ) || ( t1440
* 402.5245441795231 >= 0.0 ) ) ; t913 [ 601ULL ] = 1 ; t913 [ 602ULL ] = (
int32_T ) ( ( ! ( X [ 146ULL ] >= 1.0 ) ) || ( X [ 146ULL ] > 0.0 ) ) ; t913
[ 603ULL ] = 1 ; t913 [ 604ULL ] = 1 ; t913 [ 605ULL ] = 1 ; t913 [ 606ULL ]
= 1 ; t913 [ 607ULL ] = ( int32_T ) ( ( ! ( X [ 147ULL ] / 1.0E-5 >= 1.0 ) )
|| ( X [ 147ULL ] / 1.0E-5 > 0.0 ) ) ; t913 [ 608ULL ] = 1 ; t913 [ 609ULL ]
= 1 ; t913 [ 610ULL ] = 1 ; t913 [ 611ULL ] = ( int32_T ) ( ( t1443 -
5.65948221575962 ) - t1442 < 663.67513503334737 ) ; t913 [ 612ULL ] = (
int32_T ) ( t1444 != 0.0 ) ; t913 [ 613ULL ] = 1 ; t913 [ 614ULL ] = 1 ; t913
[ 615ULL ] = 1 ; t913 [ 616ULL ] = 1 ; t913 [ 617ULL ] = 1 ; t913 [ 618ULL ]
= 1 ; t913 [ 619ULL ] = 1 ; t913 [ 620ULL ] = ( int32_T ) ( ( X [ 154ULL ] *
X [ 154ULL ] + t1446 * t1446 == X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 )
&& ( fabs ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 ) != pmf_get_inf ( )
) ) ; t913 [ 621ULL ] = ( int32_T ) ( ( ! ( X [ 154ULL ] * X [ 154ULL ] +
t1446 * t1446 == X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 ) ) || ( ! (
fabs ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 ) != pmf_get_inf ( ) ) )
|| ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 >= 0.0 ) ) ; t913 [ 622ULL ]
= ( int32_T ) ( ( t1447 * 402.5245441795231 == t1447 * 402.5245441795231 ) &&
( fabs ( t1447 * 402.5245441795231 ) != pmf_get_inf ( ) ) ) ; t913 [ 623ULL ]
= ( int32_T ) ( ( ! ( t1447 * 402.5245441795231 == t1447 * 402.5245441795231
) ) || ( ! ( fabs ( t1447 * 402.5245441795231 ) != pmf_get_inf ( ) ) ) || (
t1447 * 402.5245441795231 >= 0.0 ) ) ; t913 [ 624ULL ] = 1 ; t913 [ 625ULL ]
= ( int32_T ) ( ( ! ( X [ 148ULL ] >= 1.0 ) ) || ( X [ 148ULL ] > 0.0 ) ) ;
t913 [ 626ULL ] = 1 ; t913 [ 627ULL ] = 1 ; t913 [ 628ULL ] = 1 ; t913 [
629ULL ] = 1 ; t913 [ 630ULL ] = ( int32_T ) ( ( ! ( X [ 149ULL ] / 1.0E-5 >=
1.0 ) ) || ( X [ 149ULL ] / 1.0E-5 > 0.0 ) ) ; t913 [ 631ULL ] = 1 ; t913 [
632ULL ] = 1 ; t913 [ 633ULL ] = 1 ; t913 [ 634ULL ] = ( int32_T ) ( (
intrm_sf_mf_72 - 5.65948221575962 ) - intrm_sf_mf_71 < 663.67513503334737 ) ;
t913 [ 635ULL ] = ( int32_T ) ( t1449 != 0.0 ) ; t913 [ 636ULL ] = 1 ; t913 [
637ULL ] = 1 ; t913 [ 638ULL ] = 1 ; t913 [ 639ULL ] = 1 ; t913 [ 640ULL ] =
1 ; t913 [ 641ULL ] = 1 ; t913 [ 642ULL ] = 1 ; t913 [ 643ULL ] = ( int32_T )
( ( X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 == X [ 154ULL ] * X [ 154ULL
] + t1450 * t1450 ) && ( fabs ( X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 )
!= pmf_get_inf ( ) ) ) ; t913 [ 644ULL ] = ( int32_T ) ( ( ! ( X [ 154ULL ] *
X [ 154ULL ] + t1450 * t1450 == X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 )
) || ( ! ( fabs ( X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 ) !=
pmf_get_inf ( ) ) ) || ( X [ 154ULL ] * X [ 154ULL ] + t1450 * t1450 >= 0.0 )
) ; t913 [ 645ULL ] = 1 ; t913 [ 646ULL ] = ( int32_T ) ( ( ! ( X [ 151ULL ]
>= 1.0 ) ) || ( X [ 151ULL ] > 0.0 ) ) ; t913 [ 647ULL ] = 1 ; t913 [ 648ULL
] = 1 ; t913 [ 649ULL ] = 1 ; t913 [ 650ULL ] = 1 ; t913 [ 651ULL ] = (
int32_T ) ( ( ! ( X [ 147ULL ] / 1.0E-5 >= 1.0 ) ) || ( X [ 147ULL ] / 1.0E-5
> 0.0 ) ) ; t913 [ 652ULL ] = 1 ; t913 [ 653ULL ] = 1 ; t913 [ 654ULL ] = 1 ;
t913 [ 655ULL ] = ( int32_T ) ( ( t1443 - 5.65948221575962 ) - intrm_sf_mf_73
< 663.67513503334737 ) ; t913 [ 656ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_A != 0.0 ) ; t913 [
657ULL ] = 1 ; t913 [ 658ULL ] = 1 ; t913 [ 659ULL ] = 1 ; t913 [ 660ULL ] =
1 ; t913 [ 661ULL ] = ( int32_T ) ( ( ! ( X [ 152ULL ] >= 1.0 ) ) || ( X [
152ULL ] > 0.0 ) ) ; t913 [ 662ULL ] = 1 ; t913 [ 663ULL ] = 1 ; t913 [
664ULL ] = 1 ; t913 [ 665ULL ] = 1 ; t913 [ 666ULL ] = ( int32_T ) ( ( ! ( X
[ 149ULL ] / 1.0E-5 >= 1.0 ) ) || ( X [ 149ULL ] / 1.0E-5 > 0.0 ) ) ; t913 [
667ULL ] = 1 ; t913 [ 668ULL ] = 1 ; t913 [ 669ULL ] = 1 ; t913 [ 670ULL ] =
( int32_T ) ( ( intrm_sf_mf_72 - 5.65948221575962 ) - intrm_sf_mf_74 <
663.67513503334737 ) ; t913 [ 671ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Flow_Resistance_G_rho_B != 0.0 ) ; t913 [
672ULL ] = 1 ; t913 [ 673ULL ] = 1 ; t913 [ 674ULL ] = 1 ; t913 [ 675ULL ] =
1 ; t913 [ 676ULL ] = 1 ; t913 [ 677ULL ] = ( int32_T ) ( ( X [ 154ULL ] * X
[ 154ULL ] + 1.0E-8 == X [ 154ULL ] * X [ 154ULL ] + 1.0E-8 ) && ( fabs ( X [
154ULL ] * X [ 154ULL ] + 1.0E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 678ULL ] =
( int32_T ) ( ( ! ( X [ 154ULL ] * X [ 154ULL ] + 1.0E-8 == X [ 154ULL ] * X
[ 154ULL ] + 1.0E-8 ) ) || ( ! ( fabs ( X [ 154ULL ] * X [ 154ULL ] + 1.0E-8
) != pmf_get_inf ( ) ) ) || ( X [ 154ULL ] * X [ 154ULL ] + 1.0E-8 >= 0.0 ) )
; t913 [ 679ULL ] = ( int32_T ) ( ( t1440 * 402.5245441795231 == t1440 *
402.5245441795231 ) && ( fabs ( t1440 * 402.5245441795231 ) != pmf_get_inf (
) ) ) ; t913 [ 680ULL ] = ( int32_T ) ( ( ! ( t1440 * 402.5245441795231 ==
t1440 * 402.5245441795231 ) ) || ( ! ( fabs ( t1440 * 402.5245441795231 ) !=
pmf_get_inf ( ) ) ) || ( t1440 * 402.5245441795231 >= 0.0 ) ) ; t913 [ 681ULL
] = 1 ; t913 [ 682ULL ] = ( int32_T ) ( ( ! ( X [ 146ULL ] >= 1.0 ) ) || ( X
[ 146ULL ] > 0.0 ) ) ; t913 [ 683ULL ] = 1 ; t913 [ 684ULL ] = 1 ; t913 [
685ULL ] = 1 ; t913 [ 686ULL ] = 1 ; t913 [ 687ULL ] = ( int32_T ) ( ( ! ( X
[ 147ULL ] / 1.0E-5 >= 1.0 ) ) || ( X [ 147ULL ] / 1.0E-5 > 0.0 ) ) ; t913 [
688ULL ] = 1 ; t913 [ 689ULL ] = 1 ; t913 [ 690ULL ] = 1 ; t913 [ 691ULL ] =
( int32_T ) ( ( t1443 - 5.65948221575962 ) - t1442 < 663.67513503334737 ) ;
t913 [ 692ULL ] = ( int32_T ) ( t1444 != 0.0 ) ; t913 [ 693ULL ] = 1 ; t913 [
694ULL ] = 1 ; t913 [ 695ULL ] = 1 ; t913 [ 696ULL ] = 1 ; t913 [ 697ULL ] =
1 ; t913 [ 698ULL ] = 1 ; t913 [ 699ULL ] = 1 ; t913 [ 700ULL ] = ( int32_T )
( ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 == X [ 154ULL ] * X [ 154ULL
] + t1446 * t1446 ) && ( fabs ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 )
!= pmf_get_inf ( ) ) ) ; t913 [ 701ULL ] = ( int32_T ) ( ( ! ( X [ 154ULL ] *
X [ 154ULL ] + t1446 * t1446 == X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 )
) || ( ! ( fabs ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 ) !=
pmf_get_inf ( ) ) ) || ( X [ 154ULL ] * X [ 154ULL ] + t1446 * t1446 >= 0.0 )
) ; t913 [ 702ULL ] = 1 ; t913 [ 703ULL ] = 1 ; t913 [ 704ULL ] = 1 ; t913 [
705ULL ] = 1 ; t913 [ 706ULL ] = 1 ; t913 [ 707ULL ] = 1 ; t913 [ 708ULL ] =
1 ; t913 [ 709ULL ] = 1 ; t913 [ 710ULL ] = 1 ; t913 [ 711ULL ] = 1 ; t913 [
712ULL ] = 1 ; t913 [ 713ULL ] = 1 ; t913 [ 714ULL ] = 1 ; t913 [ 715ULL ] =
( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 == X [
186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 ) && ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
716ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 == X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( X [ 186ULL ] * X [
186ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 717ULL ] = 1 ; t913 [
718ULL ] = 1 ; t913 [ 719ULL ] = ( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ]
+ 2.0914103314136477E-13 == X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 720ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 == X [ 186ULL
] * X [ 186ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 721ULL ]
= 1 ; t913 [ 722ULL ] = 1 ; t913 [ 723ULL ] = ( int32_T ) ( ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 724ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL
] * X [ 186ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 725ULL ]
= ( int32_T ) ( intrm_sf_mf_83 * 293.15 != 0.0 ) ; t913 [ 726ULL ] = 1 ; t913
[ 727ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 191ULL ] >= - 0.1 ) ) || ( ( ( 1.0
- X [ 191ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || ( 1.0 - X [ 191ULL
] >= 0.01 ) ) ; t913 [ 728ULL ] = 1 ; t913 [ 729ULL ] = ( int32_T ) ( X [
22ULL ] != 0.0 ) ; t913 [ 730ULL ] = ( int32_T ) ( X [ 200ULL ] != 0.0 ) ;
t913 [ 731ULL ] = 1 ; t913 [ 732ULL ] = 1 ; t913 [ 733ULL ] = 1 ; t913 [
734ULL ] = ( int32_T ) ( intrm_sf_mf_99 - intrm_sf_mf_95 != 0.0 ) ; t913 [
735ULL ] = 1 ; t913 [ 736ULL ] = 1 ; t913 [ 737ULL ] = ( int32_T ) ( ( t1454
* t1454 * 9.999999999999999E-14 + fabs ( X [ 199ULL ] * t1308 *
intrm_sf_mf_95 ) * 1.0E-9 == t1454 * t1454 * 9.999999999999999E-14 + fabs ( X
[ 199ULL ] * t1308 * intrm_sf_mf_95 ) * 1.0E-9 ) && ( fabs ( t1454 * t1454 *
9.999999999999999E-14 + fabs ( X [ 199ULL ] * t1308 * intrm_sf_mf_95 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 738ULL ] = ( int32_T ) ( ( ! ( t1454
* t1454 * 9.999999999999999E-14 + fabs ( X [ 199ULL ] * t1308 *
intrm_sf_mf_95 ) * 1.0E-9 == t1454 * t1454 * 9.999999999999999E-14 + fabs ( X
[ 199ULL ] * t1308 * intrm_sf_mf_95 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1454 *
t1454 * 9.999999999999999E-14 + fabs ( X [ 199ULL ] * t1308 * intrm_sf_mf_95
) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1454 * t1454 *
9.999999999999999E-14 + fabs ( X [ 199ULL ] * t1308 * intrm_sf_mf_95 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 739ULL ] = 1 ; t913 [ 740ULL ] = 1 ; t913 [ 741ULL
] = ( int32_T ) ( intrm_sf_mf_95 != 0.0 ) ; t913 [ 742ULL ] = ( int32_T ) ( (
! ( intrm_sf_mf_95 != 0.0 ) ) || ( X [ 199ULL ] != 0.0 ) ) ; t913 [ 743ULL ]
= 1 ; t913 [ 744ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_95 != 0.0 ) ) || ( (
intrm_sf_mf_95 != 0.0 ) && ( ! ( X [ 199ULL ] != 0.0 ) ) ) || ( fabs ( t1457
/ ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [ 199ULL ] ==
0.0 ? 1.0E-16 : X [ 199ULL ] ) ) >= 0.0 ) ) ; t913 [ 745ULL ] = ( int32_T ) (
intrm_sf_mf_102 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 746ULL ] = (
int32_T ) ( X [ 21ULL ] * intrm_sf_mf_95 != 0.0 ) ; t913 [ 747ULL ] = (
int32_T ) ( t1460 * 1.5707963267948965E-8 != 0.0 ) ; t913 [ 748ULL ] = (
int32_T ) ( t1464 != 0.0 ) ; t913 [ 749ULL ] = ( int32_T ) ( ( ! ( t1464 !=
0.0 ) ) || ( 6.9 / ( t1464 == 0.0 ? 1.0E-16 : t1464 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 750ULL ] = 1 ; t913 [ 751ULL ] = 1
; t913 [ 752ULL ] = ( int32_T ) ( ( ! ( t1464 != 0.0 ) ) || ( ( t1464 != 0.0
) && ( ! ( 6.9 / ( t1464 == 0.0 ? 1.0E-16 : t1464 ) + 0.00017169489553429715
> 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1464 == 0.0 ? 1.0E-16 : t1464 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1464 == 0.0 ? 1.0E-16 : t1464
) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 753ULL ] = ( int32_T
) ( t1460 * 1.2337005501361697E-10 != 0.0 ) ; t913 [ 754ULL ] = 1 ; t913 [
755ULL ] = 1 ; t913 [ 756ULL ] = 1 ; t913 [ 757ULL ] = 1 ; t913 [ 758ULL ] =
( int32_T ) ( X [ 22ULL ] != 0.0 ) ; t913 [ 759ULL ] = ( int32_T ) ( X [
204ULL ] != 0.0 ) ; t913 [ 760ULL ] = 1 ; t913 [ 761ULL ] = 1 ; t913 [ 762ULL
] = 1 ; t913 [ 763ULL ] = ( int32_T ) ( t1463 - intrm_sf_mf_95 != 0.0 ) ;
t913 [ 764ULL ] = 1 ; t913 [ 765ULL ] = 1 ; t913 [ 766ULL ] = ( int32_T ) ( (
t1458 * t1458 * 9.999999999999999E-14 + fabs ( X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 == t1458 * t1458 * 9.999999999999999E-14 + fabs ( X
[ 203ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1
* intrm_sf_mf_95 ) * 1.0E-9 ) && ( fabs ( t1458 * t1458 *
9.999999999999999E-14 + fabs ( X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 767ULL ] = (
int32_T ) ( ( ! ( t1458 * t1458 * 9.999999999999999E-14 + fabs ( X [ 203ULL ]
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 == t1458 * t1458 * 9.999999999999999E-14 + fabs ( X
[ 203ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1
* intrm_sf_mf_95 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1458 * t1458 *
9.999999999999999E-14 + fabs ( X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1458 * t1458 *
9.999999999999999E-14 + fabs ( X [ 203ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g1 *
intrm_sf_mf_95 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 768ULL ] = 1 ; t913 [ 769ULL ]
= 1 ; t913 [ 770ULL ] = ( int32_T ) ( intrm_sf_mf_95 != 0.0 ) ; t913 [ 771ULL
] = ( int32_T ) ( ( ! ( intrm_sf_mf_95 != 0.0 ) ) || ( X [ 203ULL ] != 0.0 )
) ; t913 [ 772ULL ] = 1 ; t913 [ 773ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_95 != 0.0 ) ) || ( ( intrm_sf_mf_95 != 0.0 ) && ( ! ( X [ 203ULL
] != 0.0 ) ) ) || ( fabs ( t1477 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 :
intrm_sf_mf_95 ) / ( X [ 203ULL ] == 0.0 ? 1.0E-16 : X [ 203ULL ] ) ) >= 0.0
) ) ; t913 [ 774ULL ] = ( int32_T ) ( intrm_sf_mf_102 * 7.8539816339744827E-5
!= 0.0 ) ; t913 [ 775ULL ] = ( int32_T ) ( t1460 * 1.5707963267948965E-8 !=
0.0 ) ; t913 [ 776ULL ] = ( int32_T ) ( t1465 != 0.0 ) ; t913 [ 777ULL ] = (
int32_T ) ( ( ! ( t1465 != 0.0 ) ) || ( 6.9 / ( t1465 == 0.0 ? 1.0E-16 :
t1465 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 778ULL ] = 1 ; t913 [
779ULL ] = 1 ; t913 [ 780ULL ] = ( int32_T ) ( ( ! ( t1465 != 0.0 ) ) || ( (
t1465 != 0.0 ) && ( ! ( 6.9 / ( t1465 == 0.0 ? 1.0E-16 : t1465 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1465 == 0.0 ?
1.0E-16 : t1465 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1465 ==
0.0 ? 1.0E-16 : t1465 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
781ULL ] = ( int32_T ) ( t1460 * 1.2337005501361697E-10 != 0.0 ) ; t913 [
782ULL ] = 1 ; t913 [ 783ULL ] = 1 ; t913 [ 784ULL ] = 1 ; t913 [ 785ULL ] =
1 ; t913 [ 786ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m0 != 0.0 ) ;
t913 [ 787ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 != 0.0 ) ;
t913 [ 788ULL ] = 1 ; t913 [ 789ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 23ULL ]
>= - 0.1 ) ) || ( ( ( 1.0 - X [ 23ULL ] ) - 0.01 ) / 0.01 <
663.67513503334737 ) || ( 1.0 - X [ 23ULL ] >= 0.01 ) ) ; t913 [ 790ULL ] = 1
; t913 [ 791ULL ] = ( int32_T ) ( t1451 != 0.0 ) ; t913 [ 792ULL ] = (
int32_T ) ( X [ 22ULL ] * 100000.0 > 0.0 ) ; t913 [ 793ULL ] = ( int32_T ) (
( ! ( X [ 22ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 22ULL ] * 100000.0
) - t168 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 794ULL ] = 1 ; t913 [
795ULL ] = ( int32_T ) ( ( ! ( t1467 >= 1.0 ) ) || ( ( t1467 - 1.0 ) *
461.523 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_R_ !=
0.0 ) ) ; t913 [ 796ULL ] = ( int32_T ) ( t1468 * 0.01 != 0.0 ) ; t913 [
797ULL ] = 1 ; t913 [ 798ULL ] = 1 ; t913 [ 799ULL ] = 1 ; t913 [ 800ULL ] =
1 ; t913 [ 801ULL ] = ( int32_T ) ( t1474 != 0.0 ) ; t913 [ 802ULL ] = (
int32_T ) ( t1495 / 2.0 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 803ULL ] =
1 ; t913 [ 804ULL ] = ( int32_T ) ( intrm_sf_mf_148 != 0.0 ) ; t913 [ 805ULL
] = ( int32_T ) ( ( ! ( intrm_sf_mf_148 != 0.0 ) ) || ( 6.9 / (
intrm_sf_mf_148 == 0.0 ? 1.0E-16 : intrm_sf_mf_148 ) + 0.00017169489553429715
> 0.0 ) ) ; t913 [ 806ULL ] = 1 ; t913 [ 807ULL ] = 1 ; t913 [ 808ULL ] = (
int32_T ) ( ( ! ( intrm_sf_mf_148 != 0.0 ) ) || ( ( intrm_sf_mf_148 != 0.0 )
&& ( ! ( 6.9 / ( intrm_sf_mf_148 == 0.0 ? 1.0E-16 : intrm_sf_mf_148 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( intrm_sf_mf_148
== 0.0 ? 1.0E-16 : intrm_sf_mf_148 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( intrm_sf_mf_148 == 0.0 ? 1.0E-16 : intrm_sf_mf_148 ) +
0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 809ULL ] = ( int32_T ) (
( t1480 / 8.0 == t1480 / 8.0 ) && ( fabs ( t1480 / 8.0 ) != pmf_get_inf ( ) )
) ; t913 [ 810ULL ] = ( int32_T ) ( ( ! ( t1480 / 8.0 == t1480 / 8.0 ) ) || (
! ( fabs ( t1480 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1480 / 8.0 >= 0.0 ) ) ;
t913 [ 811ULL ] = 1 ; t913 [ 812ULL ] = ( int32_T ) ( t1475 >= 0.0 ) ; t913 [
813ULL ] = ( int32_T ) ( ( ! ( t1480 / 8.0 == t1480 / 8.0 ) ) || ( ! ( fabs (
t1480 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1480 / 8.0 == t1480 / 8.0 ) && (
fabs ( t1480 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1480 / 8.0 >= 0.0 ) ) )
|| ( ! ( t1475 >= 0.0 ) ) || ( ( pmf_pow ( t1475 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t1480 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 814ULL ] =
1 ; t913 [ 815ULL ] = 1 ; t913 [ 816ULL ] = 1 ; t913 [ 817ULL ] = 1 ; t913 [
818ULL ] = ( int32_T ) ( t1498 / 2.0 != 0.0 ) ; t913 [ 819ULL ] = 1 ; t2769 =
t1498 / 2.0 ; t913 [ 820ULL ] = ( int32_T ) ( ( ! ( t1470 > t1504 /
7.8539816339744827E-5 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || (
t1470 != 0.0 ) ) ; t913 [ 821ULL ] = 1 ; t913 [ 822ULL ] = 1 ; t2769 = t1498
/ 2.0 ; t913 [ 823ULL ] = ( int32_T ) ( ( ! ( t1470 > t1504 /
7.8539816339744827E-5 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( !
( t1470 != 0.0 ) ) || ( t1498 / 2.0 != 0.0 ) ) ; t913 [ 824ULL ] = ( int32_T
) ( - t1482 < 663.67513503334737 ) ; t913 [ 825ULL ] = ( int32_T ) ( t1487 !=
0.0 ) ; t913 [ 826ULL ] = ( int32_T ) ( t1516 / 2.0 * 7.8539816339744827E-5
!= 0.0 ) ; t913 [ 827ULL ] = 1 ; t913 [ 828ULL ] = ( int32_T ) (
intrm_sf_mf_172 != 0.0 ) ; t913 [ 829ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_172 != 0.0 ) ) || ( 6.9 / ( intrm_sf_mf_172 == 0.0 ? 1.0E-16 :
intrm_sf_mf_172 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 830ULL ] = 1 ;
t913 [ 831ULL ] = 1 ; t913 [ 832ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_172
!= 0.0 ) ) || ( ( intrm_sf_mf_172 != 0.0 ) && ( ! ( 6.9 / ( intrm_sf_mf_172
== 0.0 ? 1.0E-16 : intrm_sf_mf_172 ) + 0.00017169489553429715 > 0.0 ) ) ) ||
( pmf_log10 ( 6.9 / ( intrm_sf_mf_172 == 0.0 ? 1.0E-16 : intrm_sf_mf_172 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_172 == 0.0 ?
1.0E-16 : intrm_sf_mf_172 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ;
t913 [ 833ULL ] = ( int32_T ) ( ( t1489 / 8.0 == t1489 / 8.0 ) && ( fabs (
t1489 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 834ULL ] = ( int32_T ) ( ( ! (
t1489 / 8.0 == t1489 / 8.0 ) ) || ( ! ( fabs ( t1489 / 8.0 ) != pmf_get_inf (
) ) ) || ( t1489 / 8.0 >= 0.0 ) ) ; t913 [ 835ULL ] = 1 ; t913 [ 836ULL ] = (
int32_T ) ( t1488 >= 0.0 ) ; t913 [ 837ULL ] = ( int32_T ) ( ( ! ( t1489 /
8.0 == t1489 / 8.0 ) ) || ( ! ( fabs ( t1489 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1489 / 8.0 == t1489 / 8.0 ) && ( fabs ( t1489 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1489 / 8.0 >= 0.0 ) ) ) || ( ! ( t1488 >= 0.0 ) ) || ( (
pmf_pow ( t1488 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1489 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 838ULL ] = 1 ; t913 [ 839ULL ] = 1 ; t913 [
840ULL ] = 1 ; t913 [ 841ULL ] = 1 ; t913 [ 842ULL ] = ( int32_T ) ( t1519 /
2.0 != 0.0 ) ; t913 [ 843ULL ] = 1 ; t2769 = t1519 / 2.0 ; t913 [ 844ULL ] =
( int32_T ) ( ( ! ( intrm_sf_mf_171 > t1525 / 7.8539816339744827E-5 / ( t2769
== 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( intrm_sf_mf_171 != 0.0 ) ) ; t913
[ 845ULL ] = 1 ; t913 [ 846ULL ] = 1 ; t2769 = t1519 / 2.0 ; t913 [ 847ULL ]
= ( int32_T ) ( ( ! ( intrm_sf_mf_171 > t1525 / 7.8539816339744827E-5 / (
t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_171 != 0.0 )
) || ( t1519 / 2.0 != 0.0 ) ) ; t913 [ 848ULL ] = ( int32_T ) ( -
intrm_sf_mf_179 < 663.67513503334737 ) ; t913 [ 849ULL ] = 1 ; t913 [ 850ULL
] = 1 ; t913 [ 851ULL ] = ( int32_T ) ( X [ 176ULL ] != 0.0 ) ; t913 [ 852ULL
] = 1 ; t913 [ 853ULL ] = 1 ; t913 [ 854ULL ] = 1 ; t913 [ 855ULL ] = 1 ;
t913 [ 856ULL ] = 1 ; t913 [ 857ULL ] = ( int32_T ) ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) && ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 858ULL ] = ( int32_T
) ( ( ! ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) ) || ( ! ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) || (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 >= 0.0 ) ) ; t913 [ 859ULL ] = 1 ; t913 [ 860ULL ] = 1
; t913 [ 861ULL ] = ( int32_T ) ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) && ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 862ULL ] = ( int32_T
) ( ( ! ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) ) || ( ! ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) || (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 >= 0.0 ) ) ; t913 [ 863ULL ] = 1 ; t913 [ 864ULL ] = 1
; t913 [ 865ULL ] = ( int32_T ) ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) && ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 866ULL ] = ( int32_T
) ( ( ! ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) ) || ( ! ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) || (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 >= 0.0 ) ) ; t913 [ 867ULL ] = ( int32_T ) ( X [
195ULL ] != 0.0 ) ; t913 [ 868ULL ] = 1 ; t913 [ 869ULL ] = 1 ; t913 [ 870ULL
] = 1 ; t913 [ 871ULL ] = 1 ; t913 [ 872ULL ] = 1 ; t913 [ 873ULL ] = (
int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ] + 2.0360111955237585E-13 == X [
186ULL ] * X [ 186ULL ] + 2.0360111955237585E-13 ) && ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ; t913 [
874ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] +
2.0360111955237585E-13 == X [ 186ULL ] * X [ 186ULL ] +
2.0360111955237585E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) || ( X [ 186ULL ] * X [
186ULL ] + 2.0360111955237585E-13 >= 0.0 ) ) ; t913 [ 875ULL ] = 1 ; t913 [
876ULL ] = 1 ; t913 [ 877ULL ] = ( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ]
+ 2.3237892571262758E-14 == X [ 186ULL ] * X [ 186ULL ] +
2.3237892571262758E-14 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 878ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 2.3237892571262758E-14 == X [ 186ULL
] * X [ 186ULL ] + 2.3237892571262758E-14 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 2.3237892571262758E-14 >= 0.0 ) ) ; t913 [ 879ULL ]
= 1 ; t913 [ 880ULL ] = 1 ; t913 [ 881ULL ] = ( int32_T ) ( ( X [ 186ULL ] *
X [ 186ULL ] + 1.6409606283812424E-14 == X [ 186ULL ] * X [ 186ULL ] +
1.6409606283812424E-14 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 882ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 1.6409606283812424E-14 == X [ 186ULL
] * X [ 186ULL ] + 1.6409606283812424E-14 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 1.6409606283812424E-14 >= 0.0 ) ) ; t913 [ 883ULL ]
= ( int32_T ) ( X [ 219ULL ] * t1494 != 0.0 ) ; t913 [ 884ULL ] = ( int32_T )
( X [ 195ULL ] != 0.0 ) ; t913 [ 885ULL ] = ( int32_T ) ( X [ 219ULL ] != 0.0
) ; t913 [ 886ULL ] = ( int32_T ) ( X [ 219ULL ] != 0.0 ) ; t913 [ 887ULL ] =
1 ; t913 [ 888ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] > 0.0 ) ) || ( t1491
!= 0.0 ) ) ; t913 [ 889ULL ] = 1 ; t913 [ 890ULL ] = 1 ; t913 [ 891ULL ] = 1
; t913 [ 892ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] > 0.0 ) ) || ( ! ( t1491
!= 0.0 ) ) || ( t1496 != 0.0 ) ) ; t913 [ 893ULL ] = 1 ; t913 [ 894ULL ] = (
int32_T ) ( ( ! ( X [ 186ULL ] < 0.0 ) ) || ( X [ 186ULL ] > 0.0 ) || ( t1491
!= 0.0 ) ) ; t913 [ 895ULL ] = 1 ; t913 [ 896ULL ] = 1 ; t913 [ 897ULL ] = 1
; t913 [ 898ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] < 0.0 ) ) || ( ! ( t1491
!= 0.0 ) ) || ( X [ 186ULL ] > 0.0 ) || ( t1496 != 0.0 ) ) ; t913 [ 899ULL ]
= 1 ; t913 [ 900ULL ] = 1 ; t913 [ 901ULL ] = ( int32_T ) ( t1501 != 0.0 ) ;
t913 [ 902ULL ] = 1 ; t913 [ 903ULL ] = 1 ; t913 [ 904ULL ] = 1 ; t913 [
905ULL ] = 1 ; t913 [ 906ULL ] = 1 ; t913 [ 907ULL ] = 1 ; t913 [ 908ULL ] =
1 ; t913 [ 909ULL ] = 1 ; t913 [ 910ULL ] = 1 ; t913 [ 911ULL ] = 1 ; t913 [
912ULL ] = ( int32_T ) ( intrm_sf_mf_249 - t1494 != 0.0 ) ; t913 [ 913ULL ] =
1 ; t913 [ 914ULL ] = 1 ; t913 [ 915ULL ] = ( int32_T ) ( t1494 != 0.0 ) ;
t913 [ 916ULL ] = ( int32_T ) ( ( ! ( t1494 != 0.0 ) ) || ( X [ 219ULL ] !=
0.0 ) ) ; t913 [ 917ULL ] = 1 ; t913 [ 918ULL ] = ( int32_T ) ( ( ! ( t1494
!= 0.0 ) ) || ( ( t1494 != 0.0 ) && ( ! ( X [ 219ULL ] != 0.0 ) ) ) || ( fabs
( t1548 / ( t1494 == 0.0 ? 1.0E-16 : t1494 ) / ( X [ 219ULL ] == 0.0 ?
1.0E-16 : X [ 219ULL ] ) ) >= 0.0 ) ) ; t913 [ 919ULL ] = ( int32_T ) ( ( ! (
X [ 186ULL ] >= 0.0 ) ) || ( t1492 != 0.0 ) ) ; t913 [ 920ULL ] = ( int32_T )
( ( X [ 186ULL ] >= 0.0 ) || ( t1492 != 0.0 ) ) ; t913 [ 921ULL ] = ( int32_T
) ( X [ 195ULL ] != 0.0 ) ; t913 [ 922ULL ] = 1 ; t913 [ 923ULL ] = 1 ; t913
[ 924ULL ] = 1 ; t913 [ 925ULL ] = 1 ; t913 [ 926ULL ] = 1 ; t913 [ 927ULL ]
= ( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 == X [
186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 ) && ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
928ULL ] = ( int32_T ) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 == X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( X [ 186ULL ] * X [
186ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 929ULL ] = 1 ; t913 [
930ULL ] = 1 ; t913 [ 931ULL ] = ( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL ]
+ 2.0914103314136477E-13 == X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 932ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 == X [ 186ULL
] * X [ 186ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 933ULL ]
= 1 ; t913 [ 934ULL ] = 1 ; t913 [ 935ULL ] = ( int32_T ) ( ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 936ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL
] * X [ 186ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 937ULL ]
= 1 ; t913 [ 938ULL ] = 1 ; t913 [ 939ULL ] = 1 ; t913 [ 940ULL ] = 1 ; t913
[ 941ULL ] = 1 ; t913 [ 942ULL ] = ( int32_T ) ( ( X [ 186ULL ] * X [ 186ULL
] + 1.8324100759713822E-12 == X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 943ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 == X [ 186ULL
] * X [ 186ULL ] + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 944ULL ]
= 1 ; t913 [ 945ULL ] = 1 ; t913 [ 946ULL ] = ( int32_T ) ( ( X [ 186ULL ] *
X [ 186ULL ] + 2.0914103314136477E-13 == X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 947ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 == X [ 186ULL
] * X [ 186ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 948ULL ]
= 1 ; t913 [ 949ULL ] = 1 ; t913 [ 950ULL ] = ( int32_T ) ( ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) && ( fabs ( X [ 186ULL ] * X [ 186ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 951ULL ] = ( int32_T
) ( ( ! ( X [ 186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 == X [ 186ULL
] * X [ 186ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [ 186ULL ] *
X [ 186ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( X [
186ULL ] * X [ 186ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 952ULL ]
= ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 != 0.0 ) ;
t913 [ 953ULL ] = 1 ; t913 [ 954ULL ] = ( int32_T ) ( ( ! (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 != 0.0 ) ) ||
( fabs ( t1496 * 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
>= 0.0 ) ) ; t913 [ 955ULL ] = ( int32_T ) ( X [ 31ULL ] != 0.0 ) ; t913 [
956ULL ] = ( int32_T ) ( X [ 246ULL ] != 0.0 ) ; t913 [ 957ULL ] = 1 ; t913 [
958ULL ] = 1 ; t913 [ 959ULL ] = 1 ; t913 [ 960ULL ] = ( int32_T ) ( t1507 -
intrm_sf_mf_270 != 0.0 ) ; t913 [ 961ULL ] = 1 ; t913 [ 962ULL ] = 1 ; t913 [
963ULL ] = ( int32_T ) ( ( t1503 * t1503 * 9.999999999999999E-14 + fabs ( X [
245ULL ] * t1508 * intrm_sf_mf_270 ) * 1.0E-9 == t1503 * t1503 *
9.999999999999999E-14 + fabs ( X [ 245ULL ] * t1508 * intrm_sf_mf_270 ) *
1.0E-9 ) && ( fabs ( t1503 * t1503 * 9.999999999999999E-14 + fabs ( X [
245ULL ] * t1508 * intrm_sf_mf_270 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913
[ 964ULL ] = ( int32_T ) ( ( ! ( t1503 * t1503 * 9.999999999999999E-14 + fabs
( X [ 245ULL ] * t1508 * intrm_sf_mf_270 ) * 1.0E-9 == t1503 * t1503 *
9.999999999999999E-14 + fabs ( X [ 245ULL ] * t1508 * intrm_sf_mf_270 ) *
1.0E-9 ) ) || ( ! ( fabs ( t1503 * t1503 * 9.999999999999999E-14 + fabs ( X [
245ULL ] * t1508 * intrm_sf_mf_270 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || (
t1503 * t1503 * 9.999999999999999E-14 + fabs ( X [ 245ULL ] * t1508 *
intrm_sf_mf_270 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 965ULL ] = 1 ; t913 [ 966ULL ]
= 1 ; t913 [ 967ULL ] = ( int32_T ) ( intrm_sf_mf_270 != 0.0 ) ; t913 [
968ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_270 != 0.0 ) ) || ( X [ 245ULL ]
!= 0.0 ) ) ; t913 [ 969ULL ] = 1 ; t913 [ 970ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_270 != 0.0 ) ) || ( ( intrm_sf_mf_270 != 0.0 ) && ( ! ( X [
245ULL ] != 0.0 ) ) ) || ( fabs ( t1557 / ( intrm_sf_mf_270 == 0.0 ? 1.0E-16
: intrm_sf_mf_270 ) / ( X [ 245ULL ] == 0.0 ? 1.0E-16 : X [ 245ULL ] ) ) >=
0.0 ) ) ; t913 [ 971ULL ] = ( int32_T ) ( t1512 * 0.44 != 0.0 ) ; t913 [
972ULL ] = ( int32_T ) ( X [ 25ULL ] * intrm_sf_mf_270 != 0.0 ) ; t913 [
973ULL ] = ( int32_T ) ( t1517 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
974ULL ] = ( int32_T ) ( t1520 != 0.0 ) ; t913 [ 975ULL ] = ( int32_T ) ( ( !
( t1520 != 0.0 ) ) || ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 976ULL ] = 1 ; t913 [ 977ULL ] = 1
; t913 [ 978ULL ] = ( int32_T ) ( ( ! ( t1520 != 0.0 ) ) || ( ( t1520 != 0.0
) && ( ! ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520 ) + 0.00017169489553429715
> 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1520 == 0.0 ? 1.0E-16 : t1520
) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 979ULL ] = ( int32_T
) ( t1517 * 0.003872 != 0.0 ) ; t913 [ 980ULL ] = 1 ; t913 [ 981ULL ] = 1 ;
t913 [ 982ULL ] = 1 ; t913 [ 983ULL ] = 1 ; t913 [ 984ULL ] = ( int32_T ) ( X
[ 31ULL ] != 0.0 ) ; t913 [ 985ULL ] = ( int32_T ) ( X [ 249ULL ] != 0.0 ) ;
t913 [ 986ULL ] = 1 ; t913 [ 987ULL ] = 1 ; t913 [ 988ULL ] = 1 ; t913 [
989ULL ] = ( int32_T ) ( intrm_sf_mf_290 - intrm_sf_mf_270 != 0.0 ) ; t913 [
990ULL ] = 1 ; t913 [ 991ULL ] = 1 ; t913 [ 992ULL ] = ( int32_T ) ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 == Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 ) && ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 993ULL ] = ( int32_T ) ( ( ! (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 == Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 ) ) || ( ! ( fabs (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) || (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi24 *
9.999999999999999E-14 + fabs ( X [ 248ULL ] * t1493 * intrm_sf_mf_270 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 994ULL ] = 1 ; t913 [ 995ULL ] = 1 ; t913 [ 996ULL
] = ( int32_T ) ( intrm_sf_mf_270 != 0.0 ) ; t913 [ 997ULL ] = ( int32_T ) (
( ! ( intrm_sf_mf_270 != 0.0 ) ) || ( X [ 248ULL ] != 0.0 ) ) ; t913 [ 998ULL
] = 1 ; t913 [ 999ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_270 != 0.0 ) ) || (
( intrm_sf_mf_270 != 0.0 ) && ( ! ( X [ 248ULL ] != 0.0 ) ) ) || ( fabs (
t1577 / ( intrm_sf_mf_270 == 0.0 ? 1.0E-16 : intrm_sf_mf_270 ) / ( X [ 248ULL
] == 0.0 ? 1.0E-16 : X [ 248ULL ] ) ) >= 0.0 ) ) ; t913 [ 1000ULL ] = (
int32_T ) ( t1512 * 0.44 != 0.0 ) ; t913 [ 1001ULL ] = ( int32_T ) ( t1517 *
8.8000000000000011E-5 != 0.0 ) ; t913 [ 1002ULL ] = ( int32_T ) ( t1527 !=
0.0 ) ; t913 [ 1003ULL ] = ( int32_T ) ( ( ! ( t1527 != 0.0 ) ) || ( 6.9 / (
t1527 == 0.0 ? 1.0E-16 : t1527 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [
1004ULL ] = 1 ; t913 [ 1005ULL ] = 1 ; t913 [ 1006ULL ] = ( int32_T ) ( ( ! (
t1527 != 0.0 ) ) || ( ( t1527 != 0.0 ) && ( ! ( 6.9 / ( t1527 == 0.0 ?
1.0E-16 : t1527 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1527 == 0.0 ? 1.0E-16 : t1527 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1527 == 0.0 ? 1.0E-16 : t1527 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 1007ULL ] = ( int32_T ) ( t1517 * 0.003872 != 0.0 ) ; t913 [
1008ULL ] = 1 ; t913 [ 1009ULL ] = 1 ; t913 [ 1010ULL ] = 1 ; t913 [ 1011ULL
] = 1 ; t913 [ 1012ULL ] = ( int32_T ) ( t1513 != 0.0 ) ; t913 [ 1013ULL ] =
( int32_T ) ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi34
!= 0.0 ) ; t913 [ 1014ULL ] = 1 ; t913 [ 1015ULL ] = ( int32_T ) ( ( ! ( 1.0
- X [ 27ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 27ULL ] ) - 0.01 ) / 0.01 <
663.67513503334737 ) || ( 1.0 - X [ 27ULL ] >= 0.01 ) ) ; t913 [ 1016ULL ] =
1 ; t913 [ 1017ULL ] = ( int32_T ) ( t1523 != 0.0 ) ; t913 [ 1018ULL ] = (
int32_T ) ( X [ 31ULL ] * 100000.0 > 0.0 ) ; t913 [ 1019ULL ] = ( int32_T ) (
( ! ( X [ 31ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 31ULL ] * 100000.0
) - t177 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 1020ULL ] = 1 ; t913 [
1021ULL ] = ( int32_T ) ( ( ! ( t1528 >= 1.0 ) ) || ( ( t1528 - 1.0 ) *
461.523 + t1524 != 0.0 ) ) ; t913 [ 1022ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi49 * 0.01 != 0.0
) ; t913 [ 1023ULL ] = 1 ; t913 [ 1024ULL ] = 1 ; t913 [ 1025ULL ] = 1 ; t913
[ 1026ULL ] = 1 ; t913 [ 1027ULL ] = ( int32_T ) ( t1532 != 0.0 ) ; t913 [
1028ULL ] = ( int32_T ) ( t1595 / 2.0 * 0.44 != 0.0 ) ; t913 [ 1029ULL ] = 1
; t913 [ 1030ULL ] = ( int32_T ) ( t1511 != 0.0 ) ; t913 [ 1031ULL ] = (
int32_T ) ( ( ! ( t1511 != 0.0 ) ) || ( 6.9 / ( t1511 == 0.0 ? 1.0E-16 :
t1511 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1032ULL ] = 1 ; t913 [
1033ULL ] = 1 ; t913 [ 1034ULL ] = ( int32_T ) ( ( ! ( t1511 != 0.0 ) ) || (
( t1511 != 0.0 ) && ( ! ( 6.9 / ( t1511 == 0.0 ? 1.0E-16 : t1511 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1511 == 0.0 ?
1.0E-16 : t1511 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1511 ==
0.0 ? 1.0E-16 : t1511 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1035ULL ] = ( int32_T ) ( ( t1536 / 8.0 == t1536 / 8.0 ) && ( fabs ( t1536 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1036ULL ] = ( int32_T ) ( ( ! ( t1536 /
8.0 == t1536 / 8.0 ) ) || ( ! ( fabs ( t1536 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1536 / 8.0 >= 0.0 ) ) ; t913 [ 1037ULL ] = 1 ; t913 [ 1038ULL ] = (
int32_T ) ( t1533 >= 0.0 ) ; t913 [ 1039ULL ] = ( int32_T ) ( ( ! ( t1536 /
8.0 == t1536 / 8.0 ) ) || ( ! ( fabs ( t1536 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1536 / 8.0 == t1536 / 8.0 ) && ( fabs ( t1536 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1536 / 8.0 >= 0.0 ) ) ) || ( ! ( t1533 >= 0.0 ) ) || ( (
pmf_pow ( t1533 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1536 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 1040ULL ] = 1 ; t913 [ 1041ULL ] = 1 ; t913 [
1042ULL ] = 1 ; t913 [ 1043ULL ] = 1 ; t913 [ 1044ULL ] = ( int32_T ) ( t1598
/ 2.0 != 0.0 ) ; t913 [ 1045ULL ] = 1 ; t2769 = t1598 / 2.0 ; t913 [ 1046ULL
] = ( int32_T ) ( ( ! ( intrm_sf_mf_306 > t1604 / 0.44 / ( t2769 == 0.0 ?
1.0E-16 : t2769 ) / 30.0 ) ) || ( intrm_sf_mf_306 != 0.0 ) ) ; t913 [ 1047ULL
] = 1 ; t913 [ 1048ULL ] = 1 ; t2769 = t1598 / 2.0 ; t913 [ 1049ULL ] = (
int32_T ) ( ( ! ( intrm_sf_mf_306 > t1604 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_306 != 0.0 ) ) || ( t1598 / 2.0 !=
0.0 ) ) ; t913 [ 1050ULL ] = ( int32_T ) ( - intrm_sf_mf_330 <
663.67513503334737 ) ; t913 [ 1051ULL ] = ( int32_T ) ( t1544 != 0.0 ) ; t913
[ 1052ULL ] = ( int32_T ) ( t1616 / 2.0 * 0.44 != 0.0 ) ; t913 [ 1053ULL ] =
1 ; t913 [ 1054ULL ] = ( int32_T ) ( t1542 != 0.0 ) ; t913 [ 1055ULL ] = (
int32_T ) ( ( ! ( t1542 != 0.0 ) ) || ( 6.9 / ( t1542 == 0.0 ? 1.0E-16 :
t1542 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1056ULL ] = 1 ; t913 [
1057ULL ] = 1 ; t913 [ 1058ULL ] = ( int32_T ) ( ( ! ( t1542 != 0.0 ) ) || (
( t1542 != 0.0 ) && ( ! ( 6.9 / ( t1542 == 0.0 ? 1.0E-16 : t1542 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1542 == 0.0 ?
1.0E-16 : t1542 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1542 ==
0.0 ? 1.0E-16 : t1542 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1059ULL ] = ( int32_T ) ( ( t1547 / 8.0 == t1547 / 8.0 ) && ( fabs ( t1547 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1060ULL ] = ( int32_T ) ( ( ! ( t1547 /
8.0 == t1547 / 8.0 ) ) || ( ! ( fabs ( t1547 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1547 / 8.0 >= 0.0 ) ) ; t913 [ 1061ULL ] = 1 ; t913 [ 1062ULL ] = (
int32_T ) ( t1546 >= 0.0 ) ; t913 [ 1063ULL ] = ( int32_T ) ( ( ! ( t1547 /
8.0 == t1547 / 8.0 ) ) || ( ! ( fabs ( t1547 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1547 / 8.0 == t1547 / 8.0 ) && ( fabs ( t1547 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1547 / 8.0 >= 0.0 ) ) ) || ( ! ( t1546 >= 0.0 ) ) || ( (
pmf_pow ( t1546 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1547 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 1064ULL ] = 1 ; t913 [ 1065ULL ] = 1 ; t913 [
1066ULL ] = 1 ; t913 [ 1067ULL ] = 1 ; t913 [ 1068ULL ] = ( int32_T ) ( t1619
/ 2.0 != 0.0 ) ; t913 [ 1069ULL ] = 1 ; t2769 = t1619 / 2.0 ; t913 [ 1070ULL
] = ( int32_T ) ( ( ! ( t1545 > t1625 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1545 != 0.0 ) ) ; t913 [ 1071ULL ] = 1 ; t913 [
1072ULL ] = 1 ; t2769 = t1619 / 2.0 ; t913 [ 1073ULL ] = ( int32_T ) ( ( ! (
t1545 > t1625 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( ! (
t1545 != 0.0 ) ) || ( t1619 / 2.0 != 0.0 ) ) ; t913 [ 1074ULL ] = ( int32_T )
( - t1549 < 663.67513503334737 ) ; t913 [ 1075ULL ] = 1 ; t913 [ 1076ULL ] =
1 ; t913 [ 1077ULL ] = ( int32_T ) ( X [ 241ULL ] != 0.0 ) ; t913 [ 1078ULL ]
= 1 ; t913 [ 1079ULL ] = 1 ; t913 [ 1080ULL ] = 1 ; t913 [ 1081ULL ] = 1 ;
t913 [ 1082ULL ] = 1 ; t913 [ 1083ULL ] = ( int32_T ) ( ( X [ 244ULL ] * X [
244ULL ] + 8.2158068647071286E-7 == X [ 244ULL ] * X [ 244ULL ] +
8.2158068647071286E-7 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) ; t913 [ 1084ULL ] = ( int32_T
) ( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 8.2158068647071286E-7 == X [ 244ULL ]
* X [ 244ULL ] + 8.2158068647071286E-7 ) ) || ( ! ( fabs ( X [ 244ULL ] * X [
244ULL ] + 8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) || ( X [ 244ULL ] *
X [ 244ULL ] + 8.2158068647071286E-7 >= 0.0 ) ) ; t913 [ 1085ULL ] = 1 ; t913
[ 1086ULL ] = 1 ; t913 [ 1087ULL ] = ( int32_T ) ( ( X [ 244ULL ] * X [
244ULL ] + 9.37706225427676E-8 == X [ 244ULL ] * X [ 244ULL ] +
9.37706225427676E-8 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1088ULL ] = ( int32_T )
( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 9.37706225427676E-8 == X [ 244ULL ] * X
[ 244ULL ] + 9.37706225427676E-8 ) ) || ( ! ( fabs ( X [ 244ULL ] * X [
244ULL ] + 9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 244ULL ] * X
[ 244ULL ] + 9.37706225427676E-8 >= 0.0 ) ) ; t913 [ 1089ULL ] = 1 ; t913 [
1090ULL ] = 1 ; t913 [ 1091ULL ] = ( int32_T ) ( ( X [ 244ULL ] * X [ 244ULL
] + 6.6216804824104011E-8 == X [ 244ULL ] * X [ 244ULL ] +
6.6216804824104011E-8 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1092ULL ] = ( int32_T
) ( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 6.6216804824104011E-8 == X [ 244ULL ]
* X [ 244ULL ] + 6.6216804824104011E-8 ) ) || ( ! ( fabs ( X [ 244ULL ] * X [
244ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 244ULL ] *
X [ 244ULL ] + 6.6216804824104011E-8 >= 0.0 ) ) ; t913 [ 1093ULL ] = (
int32_T ) ( X [ 227ULL ] != 0.0 ) ; t913 [ 1094ULL ] = 1 ; t913 [ 1095ULL ] =
1 ; t913 [ 1096ULL ] = 1 ; t913 [ 1097ULL ] = 1 ; t913 [ 1098ULL ] = 1 ; t913
[ 1099ULL ] = ( int32_T ) ( ( X [ 247ULL ] * X [ 247ULL ] +
8.2158068647071286E-7 == X [ 247ULL ] * X [ 247ULL ] + 8.2158068647071286E-7
) && ( fabs ( X [ 247ULL ] * X [ 247ULL ] + 8.2158068647071286E-7 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1100ULL ] = ( int32_T ) ( ( ! ( X [ 247ULL ] * X
[ 247ULL ] + 8.2158068647071286E-7 == X [ 247ULL ] * X [ 247ULL ] +
8.2158068647071286E-7 ) ) || ( ! ( fabs ( X [ 247ULL ] * X [ 247ULL ] +
8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) || ( X [ 247ULL ] * X [ 247ULL
] + 8.2158068647071286E-7 >= 0.0 ) ) ; t913 [ 1101ULL ] = 1 ; t913 [ 1102ULL
] = 1 ; t913 [ 1103ULL ] = ( int32_T ) ( ( X [ 247ULL ] * X [ 247ULL ] +
9.37706225427676E-8 == X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 ) &&
( fabs ( X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 ) != pmf_get_inf (
) ) ) ; t913 [ 1104ULL ] = ( int32_T ) ( ( ! ( X [ 247ULL ] * X [ 247ULL ] +
9.37706225427676E-8 == X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 ) )
|| ( ! ( fabs ( X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 >=
0.0 ) ) ; t913 [ 1105ULL ] = 1 ; t913 [ 1106ULL ] = 1 ; t913 [ 1107ULL ] = (
int32_T ) ( ( X [ 247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8 == X [
247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8 ) && ( fabs ( X [ 247ULL ] *
X [ 247ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [
1108ULL ] = ( int32_T ) ( ( ! ( X [ 247ULL ] * X [ 247ULL ] +
6.6216804824104011E-8 == X [ 247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8
) ) || ( ! ( fabs ( X [ 247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8
>= 0.0 ) ) ; t913 [ 1109ULL ] = ( int32_T ) ( X [ 33ULL ] != 0.0 ) ; t913 [
1110ULL ] = ( int32_T ) ( X [ 264ULL ] != 0.0 ) ; t913 [ 1111ULL ] = 1 ; t913
[ 1112ULL ] = 1 ; t913 [ 1113ULL ] = 1 ; t913 [ 1114ULL ] = ( int32_T ) (
t1558 - t1554 != 0.0 ) ; t913 [ 1115ULL ] = 1 ; t913 [ 1116ULL ] = 1 ; t913 [
1117ULL ] = ( int32_T ) ( ( t1555 * t1555 * 9.999999999999999E-14 + fabs ( X
[ 263ULL ] * t1560 * t1554 ) * 1.0E-9 == t1555 * t1555 *
9.999999999999999E-14 + fabs ( X [ 263ULL ] * t1560 * t1554 ) * 1.0E-9 ) && (
fabs ( t1555 * t1555 * 9.999999999999999E-14 + fabs ( X [ 263ULL ] * t1560 *
t1554 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1118ULL ] = ( int32_T ) (
( ! ( t1555 * t1555 * 9.999999999999999E-14 + fabs ( X [ 263ULL ] * t1560 *
t1554 ) * 1.0E-9 == t1555 * t1555 * 9.999999999999999E-14 + fabs ( X [ 263ULL
] * t1560 * t1554 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1555 * t1555 *
9.999999999999999E-14 + fabs ( X [ 263ULL ] * t1560 * t1554 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || ( t1555 * t1555 * 9.999999999999999E-14 + fabs ( X [
263ULL ] * t1560 * t1554 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1119ULL ] = 1 ; t913
[ 1120ULL ] = 1 ; t913 [ 1121ULL ] = ( int32_T ) ( t1554 != 0.0 ) ; t913 [
1122ULL ] = ( int32_T ) ( ( ! ( t1554 != 0.0 ) ) || ( X [ 263ULL ] != 0.0 ) )
; t913 [ 1123ULL ] = 1 ; t913 [ 1124ULL ] = ( int32_T ) ( ( ! ( t1554 != 0.0
) ) || ( ( t1554 != 0.0 ) && ( ! ( X [ 263ULL ] != 0.0 ) ) ) || ( fabs (
t1641 / ( t1554 == 0.0 ? 1.0E-16 : t1554 ) / ( X [ 263ULL ] == 0.0 ? 1.0E-16
: X [ 263ULL ] ) ) >= 0.0 ) ) ; t913 [ 1125ULL ] = ( int32_T ) ( t1566 * 0.44
!= 0.0 ) ; t913 [ 1126ULL ] = ( int32_T ) ( X [ 28ULL ] * t1554 != 0.0 ) ;
t913 [ 1127ULL ] = ( int32_T ) ( t1570 * 8.8000000000000011E-5 != 0.0 ) ;
t913 [ 1128ULL ] = ( int32_T ) ( t1575 != 0.0 ) ; t913 [ 1129ULL ] = (
int32_T ) ( ( ! ( t1575 != 0.0 ) ) || ( 6.9 / ( t1575 == 0.0 ? 1.0E-16 :
t1575 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1130ULL ] = 1 ; t913 [
1131ULL ] = 1 ; t913 [ 1132ULL ] = ( int32_T ) ( ( ! ( t1575 != 0.0 ) ) || (
( t1575 != 0.0 ) && ( ! ( 6.9 / ( t1575 == 0.0 ? 1.0E-16 : t1575 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1575 == 0.0 ?
1.0E-16 : t1575 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1575 ==
0.0 ? 1.0E-16 : t1575 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1133ULL ] = ( int32_T ) ( t1570 * 0.003872 != 0.0 ) ; t913 [ 1134ULL ] = 1 ;
t913 [ 1135ULL ] = 1 ; t913 [ 1136ULL ] = 1 ; t913 [ 1137ULL ] = 1 ; t913 [
1138ULL ] = ( int32_T ) ( X [ 33ULL ] != 0.0 ) ; t913 [ 1139ULL ] = ( int32_T
) ( X [ 266ULL ] != 0.0 ) ; t913 [ 1140ULL ] = 1 ; t913 [ 1141ULL ] = 1 ;
t913 [ 1142ULL ] = 1 ; t913 [ 1143ULL ] = ( int32_T ) ( t1574 - t1554 != 0.0
) ; t913 [ 1144ULL ] = 1 ; t913 [ 1145ULL ] = 1 ; t913 [ 1146ULL ] = (
int32_T ) ( ( t1568 * t1568 * 9.999999999999999E-14 + fabs ( X [ 265ULL ] *
t1551 * t1554 ) * 1.0E-9 == t1568 * t1568 * 9.999999999999999E-14 + fabs ( X
[ 265ULL ] * t1551 * t1554 ) * 1.0E-9 ) && ( fabs ( t1568 * t1568 *
9.999999999999999E-14 + fabs ( X [ 265ULL ] * t1551 * t1554 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1147ULL ] = ( int32_T ) ( ( ! ( t1568 * t1568 *
9.999999999999999E-14 + fabs ( X [ 265ULL ] * t1551 * t1554 ) * 1.0E-9 ==
t1568 * t1568 * 9.999999999999999E-14 + fabs ( X [ 265ULL ] * t1551 * t1554 )
* 1.0E-9 ) ) || ( ! ( fabs ( t1568 * t1568 * 9.999999999999999E-14 + fabs ( X
[ 265ULL ] * t1551 * t1554 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1568 *
t1568 * 9.999999999999999E-14 + fabs ( X [ 265ULL ] * t1551 * t1554 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 1148ULL ] = 1 ; t913 [ 1149ULL ] = 1 ; t913 [
1150ULL ] = ( int32_T ) ( t1554 != 0.0 ) ; t913 [ 1151ULL ] = ( int32_T ) ( (
! ( t1554 != 0.0 ) ) || ( X [ 265ULL ] != 0.0 ) ) ; t913 [ 1152ULL ] = 1 ;
t913 [ 1153ULL ] = ( int32_T ) ( ( ! ( t1554 != 0.0 ) ) || ( ( t1554 != 0.0 )
&& ( ! ( X [ 265ULL ] != 0.0 ) ) ) || ( fabs ( t1661 / ( t1554 == 0.0 ?
1.0E-16 : t1554 ) / ( X [ 265ULL ] == 0.0 ? 1.0E-16 : X [ 265ULL ] ) ) >= 0.0
) ) ; t913 [ 1154ULL ] = ( int32_T ) ( t1566 * 0.44 != 0.0 ) ; t913 [ 1155ULL
] = ( int32_T ) ( t1570 * 8.8000000000000011E-5 != 0.0 ) ; t913 [ 1156ULL ] =
( int32_T ) ( t1584 != 0.0 ) ; t913 [ 1157ULL ] = ( int32_T ) ( ( ! ( t1584
!= 0.0 ) ) || ( 6.9 / ( t1584 == 0.0 ? 1.0E-16 : t1584 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 1158ULL ] = 1 ; t913 [ 1159ULL ] =
1 ; t913 [ 1160ULL ] = ( int32_T ) ( ( ! ( t1584 != 0.0 ) ) || ( ( t1584 !=
0.0 ) && ( ! ( 6.9 / ( t1584 == 0.0 ? 1.0E-16 : t1584 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1584 == 0.0 ?
1.0E-16 : t1584 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1584 ==
0.0 ? 1.0E-16 : t1584 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1161ULL ] = ( int32_T ) ( t1570 * 0.003872 != 0.0 ) ; t913 [ 1162ULL ] = 1 ;
t913 [ 1163ULL ] = 1 ; t913 [ 1164ULL ] = 1 ; t913 [ 1165ULL ] = 1 ; t913 [
1166ULL ] = ( int32_T ) ( t1567 != 0.0 ) ; t913 [ 1167ULL ] = ( int32_T ) (
t1576 != 0.0 ) ; t913 [ 1168ULL ] = 1 ; t913 [ 1169ULL ] = ( int32_T ) ( ( !
( 1.0 - X [ 30ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 30ULL ] ) - 0.01 ) / 0.01
< 663.67513503334737 ) || ( 1.0 - X [ 30ULL ] >= 0.01 ) ) ; t913 [ 1170ULL ]
= 1 ; t913 [ 1171ULL ] = ( int32_T ) ( t1580 != 0.0 ) ; t913 [ 1172ULL ] = (
int32_T ) ( X [ 33ULL ] * 100000.0 > 0.0 ) ; t913 [ 1173ULL ] = ( int32_T ) (
( ! ( X [ 33ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 33ULL ] * 100000.0
) - t192 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 1174ULL ] = 1 ; t913 [
1175ULL ] = ( int32_T ) ( ( ! ( t1585 >= 1.0 ) ) || ( ( t1585 - 1.0 ) *
461.523 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi69 !=
0.0 ) ) ; t913 [ 1176ULL ] = ( int32_T ) ( t1587 * 0.01 != 0.0 ) ; t913 [
1177ULL ] = 1 ; t913 [ 1178ULL ] = 1 ; t913 [ 1179ULL ] = 1 ; t913 [ 1180ULL
] = 1 ; t913 [ 1181ULL ] = ( int32_T ) ( t1544 != 0.0 ) ; t913 [ 1182ULL ] =
( int32_T ) ( t1677 / 2.0 * 0.44 != 0.0 ) ; t913 [ 1183ULL ] = 1 ; t913 [
1184ULL ] = ( int32_T ) ( t1510 != 0.0 ) ; t913 [ 1185ULL ] = ( int32_T ) ( (
! ( t1510 != 0.0 ) ) || ( 6.9 / ( t1510 == 0.0 ? 1.0E-16 : t1510 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 1186ULL ] = 1 ; t913 [ 1187ULL ] =
1 ; t913 [ 1188ULL ] = ( int32_T ) ( ( ! ( t1510 != 0.0 ) ) || ( ( t1510 !=
0.0 ) && ( ! ( 6.9 / ( t1510 == 0.0 ? 1.0E-16 : t1510 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1510 == 0.0 ?
1.0E-16 : t1510 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1510 ==
0.0 ? 1.0E-16 : t1510 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1189ULL ] = ( int32_T ) ( ( t1590 / 8.0 == t1590 / 8.0 ) && ( fabs ( t1590 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1190ULL ] = ( int32_T ) ( ( ! ( t1590 /
8.0 == t1590 / 8.0 ) ) || ( ! ( fabs ( t1590 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1590 / 8.0 >= 0.0 ) ) ; t913 [ 1191ULL ] = 1 ; t913 [ 1192ULL ] = (
int32_T ) ( t1589 >= 0.0 ) ; t913 [ 1193ULL ] = ( int32_T ) ( ( ! ( t1590 /
8.0 == t1590 / 8.0 ) ) || ( ! ( fabs ( t1590 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1590 / 8.0 == t1590 / 8.0 ) && ( fabs ( t1590 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1590 / 8.0 >= 0.0 ) ) ) || ( ! ( t1589 >= 0.0 ) ) || ( (
pmf_pow ( t1589 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1590 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 1194ULL ] = 1 ; t913 [ 1195ULL ] = 1 ; t913 [
1196ULL ] = 1 ; t913 [ 1197ULL ] = 1 ; t913 [ 1198ULL ] = ( int32_T ) ( t1680
/ 2.0 != 0.0 ) ; t913 [ 1199ULL ] = 1 ; t2769 = t1680 / 2.0 ; t913 [ 1200ULL
] = ( int32_T ) ( ( ! ( t1565 > t1686 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1565 != 0.0 ) ) ; t913 [ 1201ULL ] = 1 ; t913 [
1202ULL ] = 1 ; t2769 = t1680 / 2.0 ; t913 [ 1203ULL ] = ( int32_T ) ( ( ! (
t1565 > t1686 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( ! (
t1565 != 0.0 ) ) || ( t1680 / 2.0 != 0.0 ) ) ; t913 [ 1204ULL ] = ( int32_T )
( - t1591 < 663.67513503334737 ) ; t913 [ 1205ULL ] = ( int32_T ) ( t1474 !=
0.0 ) ; t913 [ 1206ULL ] = ( int32_T ) ( t1696 / 2.0 * 0.44 != 0.0 ) ; t913 [
1207ULL ] = 1 ; t913 [ 1208ULL ] = ( int32_T ) ( t1478 != 0.0 ) ; t913 [
1209ULL ] = ( int32_T ) ( ( ! ( t1478 != 0.0 ) ) || ( 6.9 / ( t1478 == 0.0 ?
1.0E-16 : t1478 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1210ULL ] = 1 ;
t913 [ 1211ULL ] = 1 ; t913 [ 1212ULL ] = ( int32_T ) ( ( ! ( t1478 != 0.0 )
) || ( ( t1478 != 0.0 ) && ( ! ( 6.9 / ( t1478 == 0.0 ? 1.0E-16 : t1478 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1478 == 0.0 ?
1.0E-16 : t1478 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1478 ==
0.0 ? 1.0E-16 : t1478 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1213ULL ] = ( int32_T ) ( ( t1592 / 8.0 == t1592 / 8.0 ) && ( fabs ( t1592 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1214ULL ] = ( int32_T ) ( ( ! ( t1592 /
8.0 == t1592 / 8.0 ) ) || ( ! ( fabs ( t1592 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1592 / 8.0 >= 0.0 ) ) ; t913 [ 1215ULL ] = 1 ; t913 [ 1216ULL ] = (
int32_T ) ( t1564 >= 0.0 ) ; t913 [ 1217ULL ] = ( int32_T ) ( ( ! ( t1592 /
8.0 == t1592 / 8.0 ) ) || ( ! ( fabs ( t1592 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1592 / 8.0 == t1592 / 8.0 ) && ( fabs ( t1592 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1592 / 8.0 >= 0.0 ) ) ) || ( ! ( t1564 >= 0.0 ) ) || ( (
pmf_pow ( t1564 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1592 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 1218ULL ] = 1 ; t913 [ 1219ULL ] = 1 ; t913 [
1220ULL ] = 1 ; t913 [ 1221ULL ] = 1 ; t913 [ 1222ULL ] = ( int32_T ) ( t1699
/ 2.0 != 0.0 ) ; t913 [ 1223ULL ] = 1 ; t2769 = t1699 / 2.0 ; t913 [ 1224ULL
] = ( int32_T ) ( ( ! ( intrm_sf_mf_483 > t1705 / 0.44 / ( t2769 == 0.0 ?
1.0E-16 : t2769 ) / 30.0 ) ) || ( intrm_sf_mf_483 != 0.0 ) ) ; t913 [ 1225ULL
] = 1 ; t913 [ 1226ULL ] = 1 ; t2769 = t1699 / 2.0 ; t913 [ 1227ULL ] = (
int32_T ) ( ( ! ( intrm_sf_mf_483 > t1705 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_483 != 0.0 ) ) || ( t1699 / 2.0 !=
0.0 ) ) ; t913 [ 1228ULL ] = ( int32_T ) ( - intrm_sf_mf_491 <
663.67513503334737 ) ; t913 [ 1229ULL ] = 1 ; t913 [ 1230ULL ] = 1 ; t913 [
1231ULL ] = ( int32_T ) ( X [ 227ULL ] != 0.0 ) ; t913 [ 1232ULL ] = 1 ; t913
[ 1233ULL ] = 1 ; t913 [ 1234ULL ] = 1 ; t913 [ 1235ULL ] = 1 ; t913 [
1236ULL ] = 1 ; t913 [ 1237ULL ] = ( int32_T ) ( ( X [ 247ULL ] * X [ 247ULL
] + 8.2158068647071286E-7 == X [ 247ULL ] * X [ 247ULL ] +
8.2158068647071286E-7 ) && ( fabs ( X [ 247ULL ] * X [ 247ULL ] +
8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) ; t913 [ 1238ULL ] = ( int32_T
) ( ( ! ( X [ 247ULL ] * X [ 247ULL ] + 8.2158068647071286E-7 == X [ 247ULL ]
* X [ 247ULL ] + 8.2158068647071286E-7 ) ) || ( ! ( fabs ( X [ 247ULL ] * X [
247ULL ] + 8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) || ( X [ 247ULL ] *
X [ 247ULL ] + 8.2158068647071286E-7 >= 0.0 ) ) ; t913 [ 1239ULL ] = 1 ; t913
[ 1240ULL ] = 1 ; t913 [ 1241ULL ] = ( int32_T ) ( ( X [ 247ULL ] * X [
247ULL ] + 9.37706225427676E-8 == X [ 247ULL ] * X [ 247ULL ] +
9.37706225427676E-8 ) && ( fabs ( X [ 247ULL ] * X [ 247ULL ] +
9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1242ULL ] = ( int32_T )
( ( ! ( X [ 247ULL ] * X [ 247ULL ] + 9.37706225427676E-8 == X [ 247ULL ] * X
[ 247ULL ] + 9.37706225427676E-8 ) ) || ( ! ( fabs ( X [ 247ULL ] * X [
247ULL ] + 9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 247ULL ] * X
[ 247ULL ] + 9.37706225427676E-8 >= 0.0 ) ) ; t913 [ 1243ULL ] = 1 ; t913 [
1244ULL ] = 1 ; t913 [ 1245ULL ] = ( int32_T ) ( ( X [ 247ULL ] * X [ 247ULL
] + 6.6216804824104011E-8 == X [ 247ULL ] * X [ 247ULL ] +
6.6216804824104011E-8 ) && ( fabs ( X [ 247ULL ] * X [ 247ULL ] +
6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1246ULL ] = ( int32_T
) ( ( ! ( X [ 247ULL ] * X [ 247ULL ] + 6.6216804824104011E-8 == X [ 247ULL ]
* X [ 247ULL ] + 6.6216804824104011E-8 ) ) || ( ! ( fabs ( X [ 247ULL ] * X [
247ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 247ULL ] *
X [ 247ULL ] + 6.6216804824104011E-8 >= 0.0 ) ) ; t913 [ 1247ULL ] = (
int32_T ) ( X [ 176ULL ] != 0.0 ) ; t913 [ 1248ULL ] = 1 ; t913 [ 1249ULL ] =
1 ; t913 [ 1250ULL ] = 1 ; t913 [ 1251ULL ] = 1 ; t913 [ 1252ULL ] = 1 ; t913
[ 1253ULL ] = ( int32_T ) ( ( X [ 198ULL ] * X [ 198ULL ] +
8.2158068647071286E-7 == X [ 198ULL ] * X [ 198ULL ] + 8.2158068647071286E-7
) && ( fabs ( X [ 198ULL ] * X [ 198ULL ] + 8.2158068647071286E-7 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1254ULL ] = ( int32_T ) ( ( ! ( X [ 198ULL ] * X
[ 198ULL ] + 8.2158068647071286E-7 == X [ 198ULL ] * X [ 198ULL ] +
8.2158068647071286E-7 ) ) || ( ! ( fabs ( X [ 198ULL ] * X [ 198ULL ] +
8.2158068647071286E-7 ) != pmf_get_inf ( ) ) ) || ( X [ 198ULL ] * X [ 198ULL
] + 8.2158068647071286E-7 >= 0.0 ) ) ; t913 [ 1255ULL ] = 1 ; t913 [ 1256ULL
] = 1 ; t913 [ 1257ULL ] = ( int32_T ) ( ( X [ 198ULL ] * X [ 198ULL ] +
9.37706225427676E-8 == X [ 198ULL ] * X [ 198ULL ] + 9.37706225427676E-8 ) &&
( fabs ( X [ 198ULL ] * X [ 198ULL ] + 9.37706225427676E-8 ) != pmf_get_inf (
) ) ) ; t913 [ 1258ULL ] = ( int32_T ) ( ( ! ( X [ 198ULL ] * X [ 198ULL ] +
9.37706225427676E-8 == X [ 198ULL ] * X [ 198ULL ] + 9.37706225427676E-8 ) )
|| ( ! ( fabs ( X [ 198ULL ] * X [ 198ULL ] + 9.37706225427676E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 198ULL ] * X [ 198ULL ] + 9.37706225427676E-8 >=
0.0 ) ) ; t913 [ 1259ULL ] = 1 ; t913 [ 1260ULL ] = 1 ; t913 [ 1261ULL ] = (
int32_T ) ( ( X [ 198ULL ] * X [ 198ULL ] + 6.6216804824104011E-8 == X [
198ULL ] * X [ 198ULL ] + 6.6216804824104011E-8 ) && ( fabs ( X [ 198ULL ] *
X [ 198ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [
1262ULL ] = ( int32_T ) ( ( ! ( X [ 198ULL ] * X [ 198ULL ] +
6.6216804824104011E-8 == X [ 198ULL ] * X [ 198ULL ] + 6.6216804824104011E-8
) ) || ( ! ( fabs ( X [ 198ULL ] * X [ 198ULL ] + 6.6216804824104011E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 198ULL ] * X [ 198ULL ] + 6.6216804824104011E-8
>= 0.0 ) ) ; t913 [ 1263ULL ] = ( int32_T ) ( X [ 37ULL ] != 0.0 ) ; t913 [
1264ULL ] = ( int32_T ) ( X [ 290ULL ] != 0.0 ) ; t913 [ 1265ULL ] = 1 ; t913
[ 1266ULL ] = 1 ; t913 [ 1267ULL ] = 1 ; t913 [ 1268ULL ] = ( int32_T ) (
t1600 - t1596 != 0.0 ) ; t913 [ 1269ULL ] = 1 ; t913 [ 1270ULL ] = 1 ; t913 [
1271ULL ] = ( int32_T ) ( ( t1597 * t1597 * 9.999999999999999E-14 + fabs ( X
[ 289ULL ] * t1601 * t1596 ) * 1.0E-9 == t1597 * t1597 *
9.999999999999999E-14 + fabs ( X [ 289ULL ] * t1601 * t1596 ) * 1.0E-9 ) && (
fabs ( t1597 * t1597 * 9.999999999999999E-14 + fabs ( X [ 289ULL ] * t1601 *
t1596 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1272ULL ] = ( int32_T ) (
( ! ( t1597 * t1597 * 9.999999999999999E-14 + fabs ( X [ 289ULL ] * t1601 *
t1596 ) * 1.0E-9 == t1597 * t1597 * 9.999999999999999E-14 + fabs ( X [ 289ULL
] * t1601 * t1596 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1597 * t1597 *
9.999999999999999E-14 + fabs ( X [ 289ULL ] * t1601 * t1596 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || ( t1597 * t1597 * 9.999999999999999E-14 + fabs ( X [
289ULL ] * t1601 * t1596 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1273ULL ] = 1 ; t913
[ 1274ULL ] = 1 ; t913 [ 1275ULL ] = ( int32_T ) ( t1596 != 0.0 ) ; t913 [
1276ULL ] = ( int32_T ) ( ( ! ( t1596 != 0.0 ) ) || ( X [ 289ULL ] != 0.0 ) )
; t913 [ 1277ULL ] = 1 ; t913 [ 1278ULL ] = ( int32_T ) ( ( ! ( t1596 != 0.0
) ) || ( ( t1596 != 0.0 ) && ( ! ( X [ 289ULL ] != 0.0 ) ) ) || ( fabs (
t1721 / ( t1596 == 0.0 ? 1.0E-16 : t1596 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16
: X [ 289ULL ] ) ) >= 0.0 ) ) ; t913 [ 1279ULL ] = ( int32_T ) ( t1607 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1280ULL ] = ( int32_T ) ( X [ 34ULL ]
* t1596 != 0.0 ) ; t913 [ 1281ULL ] = ( int32_T ) ( t1611 *
9.8174770424681068E-6 != 0.0 ) ; t913 [ 1282ULL ] = ( int32_T ) ( t1613 !=
0.0 ) ; t913 [ 1283ULL ] = ( int32_T ) ( ( ! ( t1613 != 0.0 ) ) || ( 6.9 / (
t1613 == 0.0 ? 1.0E-16 : t1613 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [
1284ULL ] = 1 ; t913 [ 1285ULL ] = 1 ; t913 [ 1286ULL ] = ( int32_T ) ( ( ! (
t1613 != 0.0 ) ) || ( ( t1613 != 0.0 ) && ( ! ( 6.9 / ( t1613 == 0.0 ?
1.0E-16 : t1613 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1613 == 0.0 ? 1.0E-16 : t1613 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1613 == 0.0 ? 1.0E-16 : t1613 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 1287ULL ] = ( int32_T ) ( t1611 * 3.855314219175531E-7 !=
0.0 ) ; t913 [ 1288ULL ] = 1 ; t913 [ 1289ULL ] = 1 ; t913 [ 1290ULL ] = 1 ;
t913 [ 1291ULL ] = 1 ; t913 [ 1292ULL ] = ( int32_T ) ( X [ 37ULL ] != 0.0 )
; t913 [ 1293ULL ] = ( int32_T ) ( X [ 292ULL ] != 0.0 ) ; t913 [ 1294ULL ] =
1 ; t913 [ 1295ULL ] = 1 ; t913 [ 1296ULL ] = 1 ; t913 [ 1297ULL ] = (
int32_T ) ( intrm_sf_mf_565 - t1596 != 0.0 ) ; t913 [ 1298ULL ] = 1 ; t913 [
1299ULL ] = 1 ; t913 [ 1300ULL ] = ( int32_T ) ( ( t1609 * t1609 *
9.999999999999999E-14 + fabs ( X [ 291ULL ] * t1588 * t1596 ) * 1.0E-9 ==
t1609 * t1609 * 9.999999999999999E-14 + fabs ( X [ 291ULL ] * t1588 * t1596 )
* 1.0E-9 ) && ( fabs ( t1609 * t1609 * 9.999999999999999E-14 + fabs ( X [
291ULL ] * t1588 * t1596 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1301ULL
] = ( int32_T ) ( ( ! ( t1609 * t1609 * 9.999999999999999E-14 + fabs ( X [
291ULL ] * t1588 * t1596 ) * 1.0E-9 == t1609 * t1609 * 9.999999999999999E-14
+ fabs ( X [ 291ULL ] * t1588 * t1596 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1609 *
t1609 * 9.999999999999999E-14 + fabs ( X [ 291ULL ] * t1588 * t1596 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1609 * t1609 * 9.999999999999999E-14 +
fabs ( X [ 291ULL ] * t1588 * t1596 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1302ULL ]
= 1 ; t913 [ 1303ULL ] = 1 ; t913 [ 1304ULL ] = ( int32_T ) ( t1596 != 0.0 )
; t913 [ 1305ULL ] = ( int32_T ) ( ( ! ( t1596 != 0.0 ) ) || ( X [ 291ULL ]
!= 0.0 ) ) ; t913 [ 1306ULL ] = 1 ; t913 [ 1307ULL ] = ( int32_T ) ( ( ! (
t1596 != 0.0 ) ) || ( ( t1596 != 0.0 ) && ( ! ( X [ 291ULL ] != 0.0 ) ) ) ||
( fabs ( t1741 / ( t1596 == 0.0 ? 1.0E-16 : t1596 ) / ( X [ 291ULL ] == 0.0 ?
1.0E-16 : X [ 291ULL ] ) ) >= 0.0 ) ) ; t913 [ 1308ULL ] = ( int32_T ) (
t1607 * 0.0019634954084936209 != 0.0 ) ; t913 [ 1309ULL ] = ( int32_T ) (
t1611 * 9.8174770424681068E-6 != 0.0 ) ; t913 [ 1310ULL ] = ( int32_T ) (
t1620 != 0.0 ) ; t913 [ 1311ULL ] = ( int32_T ) ( ( ! ( t1620 != 0.0 ) ) || (
6.9 / ( t1620 == 0.0 ? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 > 0.0 ) ) ;
t913 [ 1312ULL ] = 1 ; t913 [ 1313ULL ] = 1 ; t913 [ 1314ULL ] = ( int32_T )
( ( ! ( t1620 != 0.0 ) ) || ( ( t1620 != 0.0 ) && ( ! ( 6.9 / ( t1620 == 0.0
? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9
/ ( t1620 == 0.0 ? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1620 == 0.0 ? 1.0E-16 : t1620 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 1315ULL ] = ( int32_T ) ( t1611 * 3.855314219175531E-7 !=
0.0 ) ; t913 [ 1316ULL ] = 1 ; t913 [ 1317ULL ] = 1 ; t913 [ 1318ULL ] = 1 ;
t913 [ 1319ULL ] = 1 ; t913 [ 1320ULL ] = ( int32_T ) ( t1608 != 0.0 ) ; t913
[ 1321ULL ] = ( int32_T ) ( t1614 != 0.0 ) ; t913 [ 1322ULL ] = 1 ; t913 [
1323ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 36ULL ] >= - 0.1 ) ) || ( ( ( 1.0 -
X [ 36ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || ( 1.0 - X [ 36ULL ]
>= 0.01 ) ) ; t913 [ 1324ULL ] = 1 ; t913 [ 1325ULL ] = ( int32_T ) ( t1348
!= 0.0 ) ; t913 [ 1326ULL ] = ( int32_T ) ( X [ 37ULL ] * 100000.0 > 0.0 ) ;
t913 [ 1327ULL ] = ( int32_T ) ( ( ! ( X [ 37ULL ] * 100000.0 > 0.0 ) ) || (
pmf_log ( X [ 37ULL ] * 100000.0 ) - t917 [ 0ULL ] < 663.67513503334737 ) ) ;
t913 [ 1328ULL ] = 1 ; t913 [ 1329ULL ] = ( int32_T ) ( ( ! ( t1621 >= 1.0 )
) || ( ( t1621 - 1.0 ) * 461.523 + t1618 != 0.0 ) ) ; t913 [ 1330ULL ] = (
int32_T ) ( t1622 * 0.01 != 0.0 ) ; t913 [ 1331ULL ] = 1 ; t913 [ 1332ULL ] =
1 ; t913 [ 1333ULL ] = 1 ; t913 [ 1334ULL ] = 1 ; t913 [ 1335ULL ] = (
int32_T ) ( t1627 != 0.0 ) ; t913 [ 1336ULL ] = ( int32_T ) ( t1759 / 2.0 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1337ULL ] = 1 ; t913 [ 1338ULL ] = (
int32_T ) ( t1606 != 0.0 ) ; t913 [ 1339ULL ] = ( int32_T ) ( ( ! ( t1606 !=
0.0 ) ) || ( 6.9 / ( t1606 == 0.0 ? 1.0E-16 : t1606 ) + 2.8767404433520813E-5
> 0.0 ) ) ; t913 [ 1340ULL ] = 1 ; t913 [ 1341ULL ] = 1 ; t913 [ 1342ULL ] =
( int32_T ) ( ( ! ( t1606 != 0.0 ) ) || ( ( t1606 != 0.0 ) && ( ! ( 6.9 / (
t1606 == 0.0 ? 1.0E-16 : t1606 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( t1606 == 0.0 ? 1.0E-16 : t1606 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1606 == 0.0 ? 1.0E-16 : t1606 ) +
2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 1343ULL ] = ( int32_T ) (
( t1630 / 8.0 == t1630 / 8.0 ) && ( fabs ( t1630 / 8.0 ) != pmf_get_inf ( ) )
) ; t913 [ 1344ULL ] = ( int32_T ) ( ( ! ( t1630 / 8.0 == t1630 / 8.0 ) ) ||
( ! ( fabs ( t1630 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1630 / 8.0 >= 0.0 ) )
; t913 [ 1345ULL ] = 1 ; t913 [ 1346ULL ] = ( int32_T ) ( t1628 >= 0.0 ) ;
t913 [ 1347ULL ] = ( int32_T ) ( ( ! ( t1630 / 8.0 == t1630 / 8.0 ) ) || ( !
( fabs ( t1630 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1630 / 8.0 == t1630 /
8.0 ) && ( fabs ( t1630 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1630 / 8.0 >=
0.0 ) ) ) || ( ! ( t1628 >= 0.0 ) ) || ( ( pmf_pow ( t1628 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1630 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 1348ULL ] = 1 ; t913 [ 1349ULL ] = 1 ; t913 [ 1350ULL ] = 1 ;
t913 [ 1351ULL ] = 1 ; t913 [ 1352ULL ] = ( int32_T ) ( t1762 / 2.0 != 0.0 )
; t913 [ 1353ULL ] = 1 ; t2769 = t1762 / 2.0 ; t913 [ 1354ULL ] = ( int32_T )
( ( ! ( t1624 > t1768 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1624 != 0.0 ) ) ; t913 [ 1355ULL ] = 1 ; t913 [
1356ULL ] = 1 ; t2769 = t1762 / 2.0 ; t913 [ 1357ULL ] = ( int32_T ) ( ( ! (
t1624 > t1768 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) /
30.0 ) ) || ( ! ( t1624 != 0.0 ) ) || ( t1762 / 2.0 != 0.0 ) ) ; t913 [
1358ULL ] = ( int32_T ) ( - t1631 < 663.67513503334737 ) ; t913 [ 1359ULL ] =
( int32_T ) ( t1532 != 0.0 ) ; t913 [ 1360ULL ] = ( int32_T ) ( t1778 / 2.0 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1361ULL ] = 1 ; t913 [ 1362ULL ] = (
int32_T ) ( intrm_sf_mf_622 != 0.0 ) ; t913 [ 1363ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_622 != 0.0 ) ) || ( 6.9 / ( intrm_sf_mf_622 == 0.0 ? 1.0E-16 :
intrm_sf_mf_622 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [ 1364ULL ] = 1 ;
t913 [ 1365ULL ] = 1 ; t913 [ 1366ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_622
!= 0.0 ) ) || ( ( intrm_sf_mf_622 != 0.0 ) && ( ! ( 6.9 / ( intrm_sf_mf_622
== 0.0 ? 1.0E-16 : intrm_sf_mf_622 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( intrm_sf_mf_622 == 0.0 ? 1.0E-16 : intrm_sf_mf_622 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_622 == 0.0 ?
1.0E-16 : intrm_sf_mf_622 ) + 2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ;
t913 [ 1367ULL ] = ( int32_T ) ( ( t1632 / 8.0 == t1632 / 8.0 ) && ( fabs (
t1632 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1368ULL ] = ( int32_T ) ( ( ! (
t1632 / 8.0 == t1632 / 8.0 ) ) || ( ! ( fabs ( t1632 / 8.0 ) != pmf_get_inf (
) ) ) || ( t1632 / 8.0 >= 0.0 ) ) ; t913 [ 1369ULL ] = 1 ; t913 [ 1370ULL ] =
( int32_T ) ( intrm_sf_mf_623 >= 0.0 ) ; t913 [ 1371ULL ] = ( int32_T ) ( ( !
( t1632 / 8.0 == t1632 / 8.0 ) ) || ( ! ( fabs ( t1632 / 8.0 ) != pmf_get_inf
( ) ) ) || ( ( t1632 / 8.0 == t1632 / 8.0 ) && ( fabs ( t1632 / 8.0 ) !=
pmf_get_inf ( ) ) && ( ! ( t1632 / 8.0 >= 0.0 ) ) ) || ( ! ( intrm_sf_mf_623
>= 0.0 ) ) || ( ( pmf_pow ( intrm_sf_mf_623 , 0.66666666666666663 ) - 1.0 ) *
pmf_sqrt ( t1632 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 1372ULL ] = 1 ;
t913 [ 1373ULL ] = 1 ; t913 [ 1374ULL ] = 1 ; t913 [ 1375ULL ] = 1 ; t913 [
1376ULL ] = ( int32_T ) ( t1781 / 2.0 != 0.0 ) ; t913 [ 1377ULL ] = 1 ; t2769
= t1781 / 2.0 ; t913 [ 1378ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_621 >
t1787 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) )
|| ( intrm_sf_mf_621 != 0.0 ) ) ; t913 [ 1379ULL ] = 1 ; t913 [ 1380ULL ] = 1
; t2769 = t1781 / 2.0 ; t913 [ 1381ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_621 > t1787 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_621 != 0.0 ) ) || ( t1781 / 2.0 !=
0.0 ) ) ; t913 [ 1382ULL ] = ( int32_T ) ( - t1633 < 663.67513503334737 ) ;
t913 [ 1383ULL ] = 1 ; t913 [ 1384ULL ] = 1 ; t913 [ 1385ULL ] = ( int32_T )
( X [ 38ULL ] != 0.0 ) ; t913 [ 1386ULL ] = 1 ; t913 [ 1387ULL ] = 1 ; t913 [
1388ULL ] = 1 ; t913 [ 1389ULL ] = 1 ; t913 [ 1390ULL ] = 1 ; t913 [ 1391ULL
] = ( int32_T ) ( ( X [ 288ULL ] * X [ 288ULL ] + 5.0900279888093953E-12 == X
[ 288ULL ] * X [ 288ULL ] + 5.0900279888093953E-12 ) && ( fabs ( X [ 288ULL ]
* X [ 288ULL ] + 5.0900279888093953E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
1392ULL ] = ( int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] +
5.0900279888093953E-12 == X [ 288ULL ] * X [ 288ULL ] +
5.0900279888093953E-12 ) ) || ( ! ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
5.0900279888093953E-12 ) != pmf_get_inf ( ) ) ) || ( X [ 288ULL ] * X [
288ULL ] + 5.0900279888093953E-12 >= 0.0 ) ) ; t913 [ 1393ULL ] = 1 ; t913 [
1394ULL ] = 1 ; t913 [ 1395ULL ] = ( int32_T ) ( ( X [ 288ULL ] * X [ 288ULL
] + 5.8094731428156895E-13 == X [ 288ULL ] * X [ 288ULL ] +
5.8094731428156895E-13 ) && ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1396ULL ] = (
int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] + 5.8094731428156895E-13 == X [
288ULL ] * X [ 288ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
288ULL ] * X [ 288ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 288ULL ] * X [ 288ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
1397ULL ] = 1 ; t913 [ 1398ULL ] = 1 ; t913 [ 1399ULL ] = ( int32_T ) ( ( X [
288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 == X [ 288ULL ] * X [ 288ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1400ULL ] = (
int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 == X [
288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 288ULL ] * X [ 288ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
1401ULL ] = ( int32_T ) ( X [ 241ULL ] != 0.0 ) ; t913 [ 1402ULL ] = 1 ; t913
[ 1403ULL ] = 1 ; t913 [ 1404ULL ] = 1 ; t913 [ 1405ULL ] = 1 ; t913 [
1406ULL ] = 1 ; t913 [ 1407ULL ] = ( int32_T ) ( ( X [ 244ULL ] * X [ 244ULL
] + 5.0900279888093953E-12 == X [ 244ULL ] * X [ 244ULL ] +
5.0900279888093953E-12 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
5.0900279888093953E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1408ULL ] = (
int32_T ) ( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 5.0900279888093953E-12 == X [
244ULL ] * X [ 244ULL ] + 5.0900279888093953E-12 ) ) || ( ! ( fabs ( X [
244ULL ] * X [ 244ULL ] + 5.0900279888093953E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 244ULL ] * X [ 244ULL ] + 5.0900279888093953E-12 >= 0.0 ) ) ; t913 [
1409ULL ] = 1 ; t913 [ 1410ULL ] = 1 ; t913 [ 1411ULL ] = ( int32_T ) ( ( X [
244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 == X [ 244ULL ] * X [ 244ULL
] + 5.8094731428156895E-13 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1412ULL ] = (
int32_T ) ( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 == X [
244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 244ULL ] * X [ 244ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
1413ULL ] = 1 ; t913 [ 1414ULL ] = 1 ; t913 [ 1415ULL ] = ( int32_T ) ( ( X [
244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 == X [ 244ULL ] * X [ 244ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 244ULL ] * X [ 244ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1416ULL ] = (
int32_T ) ( ( ! ( X [ 244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 == X [
244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 244ULL ] * X [ 244ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
1417ULL ] = 1 ; t913 [ 1418ULL ] = 1 ; t913 [ 1419ULL ] = 1 ; t913 [ 1420ULL
] = 1 ; t913 [ 1421ULL ] = 1 ; t913 [ 1422ULL ] = ( int32_T ) ( ( X [ 313ULL
] * X [ 313ULL ] + 2.7104677895120892E-12 == X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1423ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 == X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
1424ULL ] = 1 ; t913 [ 1425ULL ] = 1 ; t913 [ 1426ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [ 313ULL ] * X [ 313ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1427ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
1428ULL ] = 1 ; t913 [ 1429ULL ] = 1 ; t913 [ 1430ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [ 313ULL ] * X [ 313ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1431ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
1432ULL ] = ( int32_T ) ( t1635 * 293.15 != 0.0 ) ; t913 [ 1433ULL ] = 1 ;
t913 [ 1434ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 318ULL ] >= - 0.1 ) ) || ( (
( 1.0 - X [ 318ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || ( 1.0 - X [
318ULL ] >= 0.01 ) ) ; t913 [ 1435ULL ] = 1 ; t913 [ 1436ULL ] = ( int32_T )
( X [ 40ULL ] != 0.0 ) ; t913 [ 1437ULL ] = ( int32_T ) ( X [ 327ULL ] != 0.0
) ; t913 [ 1438ULL ] = 1 ; t913 [ 1439ULL ] = 1 ; t913 [ 1440ULL ] = 1 ; t913
[ 1441ULL ] = ( int32_T ) ( t1642 - t1638 != 0.0 ) ; t913 [ 1442ULL ] = 1 ;
t913 [ 1443ULL ] = 1 ; t913 [ 1444ULL ] = ( int32_T ) ( ( t1639 * t1639 *
9.999999999999999E-14 + fabs ( X [ 326ULL ] * t1644 * t1638 ) * 1.0E-9 ==
t1639 * t1639 * 9.999999999999999E-14 + fabs ( X [ 326ULL ] * t1644 * t1638 )
* 1.0E-9 ) && ( fabs ( t1639 * t1639 * 9.999999999999999E-14 + fabs ( X [
326ULL ] * t1644 * t1638 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1445ULL
] = ( int32_T ) ( ( ! ( t1639 * t1639 * 9.999999999999999E-14 + fabs ( X [
326ULL ] * t1644 * t1638 ) * 1.0E-9 == t1639 * t1639 * 9.999999999999999E-14
+ fabs ( X [ 326ULL ] * t1644 * t1638 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1639 *
t1639 * 9.999999999999999E-14 + fabs ( X [ 326ULL ] * t1644 * t1638 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1639 * t1639 * 9.999999999999999E-14 +
fabs ( X [ 326ULL ] * t1644 * t1638 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1446ULL ]
= 1 ; t913 [ 1447ULL ] = 1 ; t913 [ 1448ULL ] = ( int32_T ) ( t1638 != 0.0 )
; t913 [ 1449ULL ] = ( int32_T ) ( ( ! ( t1638 != 0.0 ) ) || ( X [ 326ULL ]
!= 0.0 ) ) ; t913 [ 1450ULL ] = 1 ; t913 [ 1451ULL ] = ( int32_T ) ( ( ! (
t1638 != 0.0 ) ) || ( ( t1638 != 0.0 ) && ( ! ( X [ 326ULL ] != 0.0 ) ) ) ||
( fabs ( t1803 / ( t1638 == 0.0 ? 1.0E-16 : t1638 ) / ( X [ 326ULL ] == 0.0 ?
1.0E-16 : X [ 326ULL ] ) ) >= 0.0 ) ) ; t913 [ 1452ULL ] = ( int32_T ) (
t1650 * 0.0019634954084936209 != 0.0 ) ; t913 [ 1453ULL ] = ( int32_T ) ( X [
39ULL ] * t1638 != 0.0 ) ; t913 [ 1454ULL ] = ( int32_T ) ( t1654 *
9.8174770424681068E-6 != 0.0 ) ; t913 [ 1455ULL ] = ( int32_T ) ( t1659 !=
0.0 ) ; t913 [ 1456ULL ] = ( int32_T ) ( ( ! ( t1659 != 0.0 ) ) || ( 6.9 / (
t1659 == 0.0 ? 1.0E-16 : t1659 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [
1457ULL ] = 1 ; t913 [ 1458ULL ] = 1 ; t913 [ 1459ULL ] = ( int32_T ) ( ( ! (
t1659 != 0.0 ) ) || ( ( t1659 != 0.0 ) && ( ! ( 6.9 / ( t1659 == 0.0 ?
1.0E-16 : t1659 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1659 == 0.0 ? 1.0E-16 : t1659 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1659 == 0.0 ? 1.0E-16 : t1659 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 1460ULL ] = ( int32_T ) ( t1654 * 3.855314219175531E-7 !=
0.0 ) ; t913 [ 1461ULL ] = 1 ; t913 [ 1462ULL ] = 1 ; t913 [ 1463ULL ] = 1 ;
t913 [ 1464ULL ] = 1 ; t913 [ 1465ULL ] = ( int32_T ) ( X [ 40ULL ] != 0.0 )
; t913 [ 1466ULL ] = ( int32_T ) ( X [ 331ULL ] != 0.0 ) ; t913 [ 1467ULL ] =
1 ; t913 [ 1468ULL ] = 1 ; t913 [ 1469ULL ] = 1 ; t913 [ 1470ULL ] = (
int32_T ) ( intrm_sf_mf_714 - t1638 != 0.0 ) ; t913 [ 1471ULL ] = 1 ; t913 [
1472ULL ] = 1 ; t913 [ 1473ULL ] = ( int32_T ) ( ( t1652 * t1652 *
9.999999999999999E-14 + fabs ( X [ 330ULL ] * t1634 * t1638 ) * 1.0E-9 ==
t1652 * t1652 * 9.999999999999999E-14 + fabs ( X [ 330ULL ] * t1634 * t1638 )
* 1.0E-9 ) && ( fabs ( t1652 * t1652 * 9.999999999999999E-14 + fabs ( X [
330ULL ] * t1634 * t1638 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1474ULL
] = ( int32_T ) ( ( ! ( t1652 * t1652 * 9.999999999999999E-14 + fabs ( X [
330ULL ] * t1634 * t1638 ) * 1.0E-9 == t1652 * t1652 * 9.999999999999999E-14
+ fabs ( X [ 330ULL ] * t1634 * t1638 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1652 *
t1652 * 9.999999999999999E-14 + fabs ( X [ 330ULL ] * t1634 * t1638 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1652 * t1652 * 9.999999999999999E-14 +
fabs ( X [ 330ULL ] * t1634 * t1638 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1475ULL ]
= 1 ; t913 [ 1476ULL ] = 1 ; t913 [ 1477ULL ] = ( int32_T ) ( t1638 != 0.0 )
; t913 [ 1478ULL ] = ( int32_T ) ( ( ! ( t1638 != 0.0 ) ) || ( X [ 330ULL ]
!= 0.0 ) ) ; t913 [ 1479ULL ] = 1 ; t913 [ 1480ULL ] = ( int32_T ) ( ( ! (
t1638 != 0.0 ) ) || ( ( t1638 != 0.0 ) && ( ! ( X [ 330ULL ] != 0.0 ) ) ) ||
( fabs ( t1823 / ( t1638 == 0.0 ? 1.0E-16 : t1638 ) / ( X [ 330ULL ] == 0.0 ?
1.0E-16 : X [ 330ULL ] ) ) >= 0.0 ) ) ; t913 [ 1481ULL ] = ( int32_T ) (
t1650 * 0.0019634954084936209 != 0.0 ) ; t913 [ 1482ULL ] = ( int32_T ) (
t1654 * 9.8174770424681068E-6 != 0.0 ) ; t913 [ 1483ULL ] = ( int32_T ) (
t1668 != 0.0 ) ; t913 [ 1484ULL ] = ( int32_T ) ( ( ! ( t1668 != 0.0 ) ) || (
6.9 / ( t1668 == 0.0 ? 1.0E-16 : t1668 ) + 2.8767404433520813E-5 > 0.0 ) ) ;
t913 [ 1485ULL ] = 1 ; t913 [ 1486ULL ] = 1 ; t913 [ 1487ULL ] = ( int32_T )
( ( ! ( t1668 != 0.0 ) ) || ( ( t1668 != 0.0 ) && ( ! ( 6.9 / ( t1668 == 0.0
? 1.0E-16 : t1668 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9
/ ( t1668 == 0.0 ? 1.0E-16 : t1668 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1668 == 0.0 ? 1.0E-16 : t1668 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 1488ULL ] = ( int32_T ) ( t1654 * 3.855314219175531E-7 !=
0.0 ) ; t913 [ 1489ULL ] = 1 ; t913 [ 1490ULL ] = 1 ; t913 [ 1491ULL ] = 1 ;
t913 [ 1492ULL ] = 1 ; t913 [ 1493ULL ] = ( int32_T ) ( t1651 != 0.0 ) ; t913
[ 1494ULL ] = ( int32_T ) ( t1660 != 0.0 ) ; t913 [ 1495ULL ] = 1 ; t913 [
1496ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 41ULL ] >= - 0.1 ) ) || ( ( ( 1.0 -
X [ 41ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || ( 1.0 - X [ 41ULL ]
>= 0.01 ) ) ; t913 [ 1497ULL ] = 1 ; t913 [ 1498ULL ] = ( int32_T ) ( t1664
!= 0.0 ) ; t913 [ 1499ULL ] = ( int32_T ) ( X [ 40ULL ] * 100000.0 > 0.0 ) ;
t913 [ 1500ULL ] = ( int32_T ) ( ( ! ( X [ 40ULL ] * 100000.0 > 0.0 ) ) || (
pmf_log ( X [ 40ULL ] * 100000.0 ) - t919 [ 0ULL ] < 663.67513503334737 ) ) ;
t913 [ 1501ULL ] = 1 ; t913 [ 1502ULL ] = ( int32_T ) ( ( ! ( t1669 >= 1.0 )
) || ( ( t1669 - 1.0 ) * 461.523 + t1666 != 0.0 ) ) ; t913 [ 1503ULL ] = (
int32_T ) ( t1671 * 0.01 != 0.0 ) ; t913 [ 1504ULL ] = 1 ; t913 [ 1505ULL ] =
1 ; t913 [ 1506ULL ] = 1 ; t913 [ 1507ULL ] = 1 ; t913 [ 1508ULL ] = (
int32_T ) ( t1674 != 0.0 ) ; t913 [ 1509ULL ] = ( int32_T ) ( t1841 / 2.0 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1510ULL ] = 1 ; t913 [ 1511ULL ] = (
int32_T ) ( t1649 != 0.0 ) ; t913 [ 1512ULL ] = ( int32_T ) ( ( ! ( t1649 !=
0.0 ) ) || ( 6.9 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) + 2.8767404433520813E-5
> 0.0 ) ) ; t913 [ 1513ULL ] = 1 ; t913 [ 1514ULL ] = 1 ; t913 [ 1515ULL ] =
( int32_T ) ( ( ! ( t1649 != 0.0 ) ) || ( ( t1649 != 0.0 ) && ( ! ( 6.9 / (
t1649 == 0.0 ? 1.0E-16 : t1649 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1649 == 0.0 ? 1.0E-16 : t1649 ) +
2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 1516ULL ] = ( int32_T ) (
( t1679 / 8.0 == t1679 / 8.0 ) && ( fabs ( t1679 / 8.0 ) != pmf_get_inf ( ) )
) ; t913 [ 1517ULL ] = ( int32_T ) ( ( ! ( t1679 / 8.0 == t1679 / 8.0 ) ) ||
( ! ( fabs ( t1679 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1679 / 8.0 >= 0.0 ) )
; t913 [ 1518ULL ] = 1 ; t913 [ 1519ULL ] = ( int32_T ) ( t1675 >= 0.0 ) ;
t913 [ 1520ULL ] = ( int32_T ) ( ( ! ( t1679 / 8.0 == t1679 / 8.0 ) ) || ( !
( fabs ( t1679 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1679 / 8.0 == t1679 /
8.0 ) && ( fabs ( t1679 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1679 / 8.0 >=
0.0 ) ) ) || ( ! ( t1675 >= 0.0 ) ) || ( ( pmf_pow ( t1675 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1679 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 1521ULL ] = 1 ; t913 [ 1522ULL ] = 1 ; t913 [ 1523ULL ] = 1 ;
t913 [ 1524ULL ] = 1 ; t913 [ 1525ULL ] = ( int32_T ) ( t1844 / 2.0 != 0.0 )
; t913 [ 1526ULL ] = 1 ; t2769 = t1844 / 2.0 ; t913 [ 1527ULL ] = ( int32_T )
( ( ! ( t1673 > t1850 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1673 != 0.0 ) ) ; t913 [ 1528ULL ] = 1 ; t913 [
1529ULL ] = 1 ; t2769 = t1844 / 2.0 ; t913 [ 1530ULL ] = ( int32_T ) ( ( ! (
t1673 > t1850 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) /
30.0 ) ) || ( ! ( t1673 != 0.0 ) ) || ( t1844 / 2.0 != 0.0 ) ) ; t913 [
1531ULL ] = ( int32_T ) ( - t1681 < 663.67513503334737 ) ; t913 [ 1532ULL ] =
( int32_T ) ( t1684 != 0.0 ) ; t913 [ 1533ULL ] = ( int32_T ) ( t1862 / 2.0 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1534ULL ] = 1 ; t913 [ 1535ULL ] = (
int32_T ) ( t1648 != 0.0 ) ; t913 [ 1536ULL ] = ( int32_T ) ( ( ! ( t1648 !=
0.0 ) ) || ( 6.9 / ( t1648 == 0.0 ? 1.0E-16 : t1648 ) + 2.8767404433520813E-5
> 0.0 ) ) ; t913 [ 1537ULL ] = 1 ; t913 [ 1538ULL ] = 1 ; t913 [ 1539ULL ] =
( int32_T ) ( ( ! ( t1648 != 0.0 ) ) || ( ( t1648 != 0.0 ) && ( ! ( 6.9 / (
t1648 == 0.0 ? 1.0E-16 : t1648 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( t1648 == 0.0 ? 1.0E-16 : t1648 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1648 == 0.0 ? 1.0E-16 : t1648 ) +
2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 1540ULL ] = ( int32_T ) (
( t1688 / 8.0 == t1688 / 8.0 ) && ( fabs ( t1688 / 8.0 ) != pmf_get_inf ( ) )
) ; t913 [ 1541ULL ] = ( int32_T ) ( ( ! ( t1688 / 8.0 == t1688 / 8.0 ) ) ||
( ! ( fabs ( t1688 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1688 / 8.0 >= 0.0 ) )
; t913 [ 1542ULL ] = 1 ; t913 [ 1543ULL ] = ( int32_T ) ( t1685 >= 0.0 ) ;
t913 [ 1544ULL ] = ( int32_T ) ( ( ! ( t1688 / 8.0 == t1688 / 8.0 ) ) || ( !
( fabs ( t1688 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1688 / 8.0 == t1688 /
8.0 ) && ( fabs ( t1688 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1688 / 8.0 >=
0.0 ) ) ) || ( ! ( t1685 >= 0.0 ) ) || ( ( pmf_pow ( t1685 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1688 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 1545ULL ] = 1 ; t913 [ 1546ULL ] = 1 ; t913 [ 1547ULL ] = 1 ;
t913 [ 1548ULL ] = 1 ; t913 [ 1549ULL ] = ( int32_T ) ( t1865 / 2.0 != 0.0 )
; t913 [ 1550ULL ] = 1 ; t2769 = t1865 / 2.0 ; t913 [ 1551ULL ] = ( int32_T )
( ( ! ( t1683 > t1871 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1683 != 0.0 ) ) ; t913 [ 1552ULL ] = 1 ; t913 [
1553ULL ] = 1 ; t2769 = t1865 / 2.0 ; t913 [ 1554ULL ] = ( int32_T ) ( ( ! (
t1683 > t1871 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) /
30.0 ) ) || ( ! ( t1683 != 0.0 ) ) || ( t1865 / 2.0 != 0.0 ) ) ; t913 [
1555ULL ] = ( int32_T ) ( - t1689 < 663.67513503334737 ) ; t913 [ 1556ULL ] =
1 ; t913 [ 1557ULL ] = 1 ; t913 [ 1558ULL ] = ( int32_T ) ( X [ 303ULL ] !=
0.0 ) ; t913 [ 1559ULL ] = 1 ; t913 [ 1560ULL ] = 1 ; t913 [ 1561ULL ] = 1 ;
t913 [ 1562ULL ] = 1 ; t913 [ 1563ULL ] = 1 ; t913 [ 1564ULL ] = ( int32_T )
( ( X [ 325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 == X [ 325ULL ] * X
[ 325ULL ] + 3.0116308772356542E-13 ) && ( fabs ( X [ 325ULL ] * X [ 325ULL ]
+ 3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1565ULL ] = (
int32_T ) ( ( ! ( X [ 325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 == X [
325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 ) ) || ( ! ( fabs ( X [
325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 325ULL ] * X [ 325ULL ] + 3.0116308772356542E-13 >= 0.0 ) ) ; t913 [
1566ULL ] = 1 ; t913 [ 1567ULL ] = 1 ; t913 [ 1568ULL ] = ( int32_T ) ( ( X [
325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 == X [ 325ULL ] * X [ 325ULL
] + 5.8094731428156895E-13 ) && ( fabs ( X [ 325ULL ] * X [ 325ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1569ULL ] = (
int32_T ) ( ( ! ( X [ 325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 == X [
325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 325ULL ] * X [ 325ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
1570ULL ] = 1 ; t913 [ 1571ULL ] = 1 ; t913 [ 1572ULL ] = ( int32_T ) ( ( X [
325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 == X [ 325ULL ] * X [ 325ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 325ULL ] * X [ 325ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1573ULL ] = (
int32_T ) ( ( ! ( X [ 325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 == X [
325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 325ULL ] * X [ 325ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
1574ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 != 0.0 ) ;
t913 [ 1575ULL ] = 1 ; t913 [ 1576ULL ] = 1 ; t913 [ 1577ULL ] = 1 ; t913 [
1578ULL ] = 1 ; t913 [ 1579ULL ] = 1 ; t913 [ 1580ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 == X [ 313ULL ] * X [ 313ULL
] + 3.0116308772356542E-13 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1581ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 == X [
313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 3.0116308772356542E-13 >= 0.0 ) ) ; t913 [
1582ULL ] = 1 ; t913 [ 1583ULL ] = 1 ; t913 [ 1584ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 == X [ 313ULL ] * X [ 313ULL
] + 5.8094731428156895E-13 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1585ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 == X [
313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
1586ULL ] = 1 ; t913 [ 1587ULL ] = 1 ; t913 [ 1588ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 == X [ 313ULL ] * X [ 313ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 1589ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 == X [
313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
1590ULL ] = ( int32_T ) ( X [ 343ULL ] * t1693 != 0.0 ) ; t913 [ 1591ULL ] =
( int32_T ) ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0
!= 0.0 ) ; t913 [ 1592ULL ] = ( int32_T ) ( X [ 343ULL ] != 0.0 ) ; t913 [
1593ULL ] = ( int32_T ) ( X [ 343ULL ] != 0.0 ) ; t913 [ 1594ULL ] = 1 ; t913
[ 1595ULL ] = ( int32_T ) ( ( ! ( X [ 313ULL ] > 0.0 ) ) || ( intrm_sf_mf_829
!= 0.0 ) ) ; t913 [ 1596ULL ] = 1 ; t913 [ 1597ULL ] = 1 ; t913 [ 1598ULL ] =
1 ; t913 [ 1599ULL ] = ( int32_T ) ( ( ! ( X [ 313ULL ] > 0.0 ) ) || ( ! (
intrm_sf_mf_829 != 0.0 ) ) || ( t1694 != 0.0 ) ) ; t913 [ 1600ULL ] = 1 ;
t913 [ 1601ULL ] = ( int32_T ) ( ( ! ( X [ 313ULL ] < 0.0 ) ) || ( X [ 313ULL
] > 0.0 ) || ( intrm_sf_mf_829 != 0.0 ) ) ; t913 [ 1602ULL ] = 1 ; t913 [
1603ULL ] = 1 ; t913 [ 1604ULL ] = 1 ; t913 [ 1605ULL ] = ( int32_T ) ( ( ! (
X [ 313ULL ] < 0.0 ) ) || ( ! ( intrm_sf_mf_829 != 0.0 ) ) || ( X [ 313ULL ]
> 0.0 ) || ( t1694 != 0.0 ) ) ; t913 [ 1606ULL ] = 1 ; t913 [ 1607ULL ] = 1 ;
t913 [ 1608ULL ] = ( int32_T ) ( t1700 != 0.0 ) ; t913 [ 1609ULL ] = 1 ; t913
[ 1610ULL ] = 1 ; t913 [ 1611ULL ] = 1 ; t913 [ 1612ULL ] = 1 ; t913 [
1613ULL ] = 1 ; t913 [ 1614ULL ] = 1 ; t913 [ 1615ULL ] = 1 ; t913 [ 1616ULL
] = 1 ; t913 [ 1617ULL ] = 1 ; t913 [ 1618ULL ] = 1 ; t913 [ 1619ULL ] = (
int32_T ) ( intrm_sf_mf_848 - t1693 != 0.0 ) ; t913 [ 1620ULL ] = 1 ; t913 [
1621ULL ] = 1 ; t913 [ 1622ULL ] = ( int32_T ) ( t1693 != 0.0 ) ; t913 [
1623ULL ] = ( int32_T ) ( ( ! ( t1693 != 0.0 ) ) || ( X [ 343ULL ] != 0.0 ) )
; t913 [ 1624ULL ] = 1 ; t913 [ 1625ULL ] = ( int32_T ) ( ( ! ( t1693 != 0.0
) ) || ( ( t1693 != 0.0 ) && ( ! ( X [ 343ULL ] != 0.0 ) ) ) || ( fabs (
t1893 / ( t1693 == 0.0 ? 1.0E-16 : t1693 ) / ( X [ 343ULL ] == 0.0 ? 1.0E-16
: X [ 343ULL ] ) ) >= 0.0 ) ) ; t913 [ 1626ULL ] = ( int32_T ) ( ( ! ( X [
313ULL ] >= 0.0 ) ) || ( t1691 != 0.0 ) ) ; t913 [ 1627ULL ] = ( int32_T ) (
( X [ 313ULL ] >= 0.0 ) || ( t1691 != 0.0 ) ) ; t913 [ 1628ULL ] = ( int32_T
) ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 != 0.0 ) ;
t913 [ 1629ULL ] = 1 ; t913 [ 1630ULL ] = 1 ; t913 [ 1631ULL ] = 1 ; t913 [
1632ULL ] = 1 ; t913 [ 1633ULL ] = 1 ; t913 [ 1634ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 == X [ 313ULL ] * X [ 313ULL
] + 2.7104677895120892E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1635ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 == X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
1636ULL ] = 1 ; t913 [ 1637ULL ] = 1 ; t913 [ 1638ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [ 313ULL ] * X [ 313ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1639ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
1640ULL ] = 1 ; t913 [ 1641ULL ] = 1 ; t913 [ 1642ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [ 313ULL ] * X [ 313ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1643ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
1644ULL ] = 1 ; t913 [ 1645ULL ] = 1 ; t913 [ 1646ULL ] = 1 ; t913 [ 1647ULL
] = 1 ; t913 [ 1648ULL ] = 1 ; t913 [ 1649ULL ] = ( int32_T ) ( ( X [ 313ULL
] * X [ 313ULL ] + 2.7104677895120892E-12 == X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1650ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 == X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
1651ULL ] = 1 ; t913 [ 1652ULL ] = 1 ; t913 [ 1653ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [ 313ULL ] * X [ 313ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1654ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 == X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
1655ULL ] = 1 ; t913 [ 1656ULL ] = 1 ; t913 [ 1657ULL ] = ( int32_T ) ( ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [ 313ULL ] * X [ 313ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 313ULL ] * X [ 313ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 1658ULL ] = (
int32_T ) ( ( ! ( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 == X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
1659ULL ] = ( int32_T ) ( t1690 != 0.0 ) ; t913 [ 1660ULL ] = 1 ; t913 [
1661ULL ] = ( int32_T ) ( ( ! ( t1690 != 0.0 ) ) || ( fabs ( t1694 * 2.0 / (
t1690 == 0.0 ? 1.0E-16 : t1690 ) ) >= 0.0 ) ) ; t913 [ 1662ULL ] = ( int32_T
) ( X [ 49ULL ] != 0.0 ) ; t913 [ 1663ULL ] = ( int32_T ) ( X [ 370ULL ] !=
0.0 ) ; t913 [ 1664ULL ] = 1 ; t913 [ 1665ULL ] = 1 ; t913 [ 1666ULL ] = 1 ;
t913 [ 1667ULL ] = ( int32_T ) ( t1704 - t1701 != 0.0 ) ; t913 [ 1668ULL ] =
1 ; t913 [ 1669ULL ] = 1 ; t913 [ 1670ULL ] = ( int32_T ) ( ( t1702 * t1702 *
9.999999999999999E-14 + fabs ( X [ 369ULL ] * t1707 * t1701 ) * 1.0E-9 ==
t1702 * t1702 * 9.999999999999999E-14 + fabs ( X [ 369ULL ] * t1707 * t1701 )
* 1.0E-9 ) && ( fabs ( t1702 * t1702 * 9.999999999999999E-14 + fabs ( X [
369ULL ] * t1707 * t1701 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1671ULL
] = ( int32_T ) ( ( ! ( t1702 * t1702 * 9.999999999999999E-14 + fabs ( X [
369ULL ] * t1707 * t1701 ) * 1.0E-9 == t1702 * t1702 * 9.999999999999999E-14
+ fabs ( X [ 369ULL ] * t1707 * t1701 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1702 *
t1702 * 9.999999999999999E-14 + fabs ( X [ 369ULL ] * t1707 * t1701 ) *
1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1702 * t1702 * 9.999999999999999E-14 +
fabs ( X [ 369ULL ] * t1707 * t1701 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1672ULL ]
= 1 ; t913 [ 1673ULL ] = 1 ; t913 [ 1674ULL ] = ( int32_T ) ( t1701 != 0.0 )
; t913 [ 1675ULL ] = ( int32_T ) ( ( ! ( t1701 != 0.0 ) ) || ( X [ 369ULL ]
!= 0.0 ) ) ; t913 [ 1676ULL ] = 1 ; t913 [ 1677ULL ] = ( int32_T ) ( ( ! (
t1701 != 0.0 ) ) || ( ( t1701 != 0.0 ) && ( ! ( X [ 369ULL ] != 0.0 ) ) ) ||
( fabs ( t1902 / ( t1701 == 0.0 ? 1.0E-16 : t1701 ) / ( X [ 369ULL ] == 0.0 ?
1.0E-16 : X [ 369ULL ] ) ) >= 0.0 ) ) ; t913 [ 1678ULL ] = ( int32_T ) (
t1711 * 0.44 != 0.0 ) ; t913 [ 1679ULL ] = ( int32_T ) ( X [ 43ULL ] * t1701
!= 0.0 ) ; t913 [ 1680ULL ] = ( int32_T ) ( t1715 * 8.8000000000000011E-5 !=
0.0 ) ; t913 [ 1681ULL ] = ( int32_T ) ( t1718 != 0.0 ) ; t913 [ 1682ULL ] =
( int32_T ) ( ( ! ( t1718 != 0.0 ) ) || ( 6.9 / ( t1718 == 0.0 ? 1.0E-16 :
t1718 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1683ULL ] = 1 ; t913 [
1684ULL ] = 1 ; t913 [ 1685ULL ] = ( int32_T ) ( ( ! ( t1718 != 0.0 ) ) || (
( t1718 != 0.0 ) && ( ! ( 6.9 / ( t1718 == 0.0 ? 1.0E-16 : t1718 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1718 == 0.0 ?
1.0E-16 : t1718 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1718 ==
0.0 ? 1.0E-16 : t1718 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1686ULL ] = ( int32_T ) ( t1715 * 0.003872 != 0.0 ) ; t913 [ 1687ULL ] = 1 ;
t913 [ 1688ULL ] = 1 ; t913 [ 1689ULL ] = 1 ; t913 [ 1690ULL ] = 1 ; t913 [
1691ULL ] = ( int32_T ) ( X [ 49ULL ] != 0.0 ) ; t913 [ 1692ULL ] = ( int32_T
) ( X [ 373ULL ] != 0.0 ) ; t913 [ 1693ULL ] = 1 ; t913 [ 1694ULL ] = 1 ;
t913 [ 1695ULL ] = 1 ; t913 [ 1696ULL ] = ( int32_T ) ( t1716 - t1701 != 0.0
) ; t913 [ 1697ULL ] = 1 ; t913 [ 1698ULL ] = 1 ; t913 [ 1699ULL ] = (
int32_T ) ( ( t1713 * t1713 * 9.999999999999999E-14 + fabs ( X [ 372ULL ] *
t1692 * t1701 ) * 1.0E-9 == t1713 * t1713 * 9.999999999999999E-14 + fabs ( X
[ 372ULL ] * t1692 * t1701 ) * 1.0E-9 ) && ( fabs ( t1713 * t1713 *
9.999999999999999E-14 + fabs ( X [ 372ULL ] * t1692 * t1701 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1700ULL ] = ( int32_T ) ( ( ! ( t1713 * t1713 *
9.999999999999999E-14 + fabs ( X [ 372ULL ] * t1692 * t1701 ) * 1.0E-9 ==
t1713 * t1713 * 9.999999999999999E-14 + fabs ( X [ 372ULL ] * t1692 * t1701 )
* 1.0E-9 ) ) || ( ! ( fabs ( t1713 * t1713 * 9.999999999999999E-14 + fabs ( X
[ 372ULL ] * t1692 * t1701 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1713 *
t1713 * 9.999999999999999E-14 + fabs ( X [ 372ULL ] * t1692 * t1701 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 1701ULL ] = 1 ; t913 [ 1702ULL ] = 1 ; t913 [
1703ULL ] = ( int32_T ) ( t1701 != 0.0 ) ; t913 [ 1704ULL ] = ( int32_T ) ( (
! ( t1701 != 0.0 ) ) || ( X [ 372ULL ] != 0.0 ) ) ; t913 [ 1705ULL ] = 1 ;
t913 [ 1706ULL ] = ( int32_T ) ( ( ! ( t1701 != 0.0 ) ) || ( ( t1701 != 0.0 )
&& ( ! ( X [ 372ULL ] != 0.0 ) ) ) || ( fabs ( t1922 / ( t1701 == 0.0 ?
1.0E-16 : t1701 ) / ( X [ 372ULL ] == 0.0 ? 1.0E-16 : X [ 372ULL ] ) ) >= 0.0
) ) ; t913 [ 1707ULL ] = ( int32_T ) ( t1711 * 0.44 != 0.0 ) ; t913 [ 1708ULL
] = ( int32_T ) ( t1715 * 8.8000000000000011E-5 != 0.0 ) ; t913 [ 1709ULL ] =
( int32_T ) ( t1727 != 0.0 ) ; t913 [ 1710ULL ] = ( int32_T ) ( ( ! ( t1727
!= 0.0 ) ) || ( 6.9 / ( t1727 == 0.0 ? 1.0E-16 : t1727 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 1711ULL ] = 1 ; t913 [ 1712ULL ] =
1 ; t913 [ 1713ULL ] = ( int32_T ) ( ( ! ( t1727 != 0.0 ) ) || ( ( t1727 !=
0.0 ) && ( ! ( 6.9 / ( t1727 == 0.0 ? 1.0E-16 : t1727 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1727 == 0.0 ?
1.0E-16 : t1727 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1727 ==
0.0 ? 1.0E-16 : t1727 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1714ULL ] = ( int32_T ) ( t1715 * 0.003872 != 0.0 ) ; t913 [ 1715ULL ] = 1 ;
t913 [ 1716ULL ] = 1 ; t913 [ 1717ULL ] = 1 ; t913 [ 1718ULL ] = 1 ; t913 [
1719ULL ] = ( int32_T ) ( t1712 != 0.0 ) ; t913 [ 1720ULL ] = ( int32_T ) (
t1719 != 0.0 ) ; t913 [ 1721ULL ] = 1 ; t913 [ 1722ULL ] = ( int32_T ) ( ( !
( 1.0 - X [ 45ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 45ULL ] ) - 0.01 ) / 0.01
< 663.67513503334737 ) || ( 1.0 - X [ 45ULL ] >= 0.01 ) ) ; t913 [ 1723ULL ]
= 1 ; t913 [ 1724ULL ] = ( int32_T ) ( t1722 != 0.0 ) ; t913 [ 1725ULL ] = (
int32_T ) ( X [ 49ULL ] * 100000.0 > 0.0 ) ; t913 [ 1726ULL ] = ( int32_T ) (
( ! ( X [ 49ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 49ULL ] * 100000.0
) - t918 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 1727ULL ] = 1 ; t913 [
1728ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_898 >= 1.0 ) ) || ( (
intrm_sf_mf_898 - 1.0 ) * 461.523 + t1724 != 0.0 ) ) ; t913 [ 1729ULL ] = (
int32_T ) ( t1729 * 0.01 != 0.0 ) ; t913 [ 1730ULL ] = 1 ; t913 [ 1731ULL ] =
1 ; t913 [ 1732ULL ] = 1 ; t913 [ 1733ULL ] = 1 ; t913 [ 1734ULL ] = (
int32_T ) ( t1732 != 0.0 ) ; t913 [ 1735ULL ] = ( int32_T ) ( t1940 / 2.0 *
0.44 != 0.0 ) ; t913 [ 1736ULL ] = 1 ; t913 [ 1737ULL ] = ( int32_T ) ( t1710
!= 0.0 ) ; t913 [ 1738ULL ] = ( int32_T ) ( ( ! ( t1710 != 0.0 ) ) || ( 6.9 /
( t1710 == 0.0 ? 1.0E-16 : t1710 ) + 0.00017169489553429715 > 0.0 ) ) ; t913
[ 1739ULL ] = 1 ; t913 [ 1740ULL ] = 1 ; t913 [ 1741ULL ] = ( int32_T ) ( ( !
( t1710 != 0.0 ) ) || ( ( t1710 != 0.0 ) && ( ! ( 6.9 / ( t1710 == 0.0 ?
1.0E-16 : t1710 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1710 == 0.0 ? 1.0E-16 : t1710 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1710 == 0.0 ? 1.0E-16 : t1710 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 1742ULL ] = ( int32_T ) ( ( t1739 / 8.0 == t1739 / 8.0 ) &&
( fabs ( t1739 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1743ULL ] = ( int32_T
) ( ( ! ( t1739 / 8.0 == t1739 / 8.0 ) ) || ( ! ( fabs ( t1739 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( t1739 / 8.0 >= 0.0 ) ) ; t913 [ 1744ULL ] = 1 ; t913
[ 1745ULL ] = ( int32_T ) ( t1733 >= 0.0 ) ; t913 [ 1746ULL ] = ( int32_T ) (
( ! ( t1739 / 8.0 == t1739 / 8.0 ) ) || ( ! ( fabs ( t1739 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( ( t1739 / 8.0 == t1739 / 8.0 ) && ( fabs ( t1739 /
8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1739 / 8.0 >= 0.0 ) ) ) || ( ! ( t1733
>= 0.0 ) ) || ( ( pmf_pow ( t1733 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt
( t1739 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 1747ULL ] = 1 ; t913 [
1748ULL ] = 1 ; t913 [ 1749ULL ] = 1 ; t913 [ 1750ULL ] = 1 ; t913 [ 1751ULL
] = ( int32_T ) ( t1943 / 2.0 != 0.0 ) ; t913 [ 1752ULL ] = 1 ; t2769 = t1943
/ 2.0 ; t913 [ 1753ULL ] = ( int32_T ) ( ( ! ( t1731 > t1949 / 0.44 / ( t2769
== 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( t1731 != 0.0 ) ) ; t913 [ 1754ULL
] = 1 ; t913 [ 1755ULL ] = 1 ; t2769 = t1943 / 2.0 ; t913 [ 1756ULL ] = (
int32_T ) ( ( ! ( t1731 > t1949 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) /
30.0 ) ) || ( ! ( t1731 != 0.0 ) ) || ( t1943 / 2.0 != 0.0 ) ) ; t913 [
1757ULL ] = ( int32_T ) ( - t1740 < 663.67513503334737 ) ; t913 [ 1758ULL ] =
( int32_T ) ( t1746 != 0.0 ) ; t913 [ 1759ULL ] = ( int32_T ) ( t1961 / 2.0 *
0.44 != 0.0 ) ; t913 [ 1760ULL ] = 1 ; t913 [ 1761ULL ] = ( int32_T ) ( t1744
!= 0.0 ) ; t913 [ 1762ULL ] = ( int32_T ) ( ( ! ( t1744 != 0.0 ) ) || ( 6.9 /
( t1744 == 0.0 ? 1.0E-16 : t1744 ) + 0.00017169489553429715 > 0.0 ) ) ; t913
[ 1763ULL ] = 1 ; t913 [ 1764ULL ] = 1 ; t913 [ 1765ULL ] = ( int32_T ) ( ( !
( t1744 != 0.0 ) ) || ( ( t1744 != 0.0 ) && ( ! ( 6.9 / ( t1744 == 0.0 ?
1.0E-16 : t1744 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1744 == 0.0 ? 1.0E-16 : t1744 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1744 == 0.0 ? 1.0E-16 : t1744 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 1766ULL ] = ( int32_T ) ( ( t1751 / 8.0 == t1751 / 8.0 ) &&
( fabs ( t1751 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1767ULL ] = ( int32_T
) ( ( ! ( t1751 / 8.0 == t1751 / 8.0 ) ) || ( ! ( fabs ( t1751 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( t1751 / 8.0 >= 0.0 ) ) ; t913 [ 1768ULL ] = 1 ; t913
[ 1769ULL ] = ( int32_T ) ( t1749 >= 0.0 ) ; t913 [ 1770ULL ] = ( int32_T ) (
( ! ( t1751 / 8.0 == t1751 / 8.0 ) ) || ( ! ( fabs ( t1751 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( ( t1751 / 8.0 == t1751 / 8.0 ) && ( fabs ( t1751 /
8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1751 / 8.0 >= 0.0 ) ) ) || ( ! ( t1749
>= 0.0 ) ) || ( ( pmf_pow ( t1749 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt
( t1751 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 1771ULL ] = 1 ; t913 [
1772ULL ] = 1 ; t913 [ 1773ULL ] = 1 ; t913 [ 1774ULL ] = 1 ; t913 [ 1775ULL
] = ( int32_T ) ( t1964 / 2.0 != 0.0 ) ; t913 [ 1776ULL ] = 1 ; t2769 = t1964
/ 2.0 ; t913 [ 1777ULL ] = ( int32_T ) ( ( ! ( t1748 > t1970 / 0.44 / ( t2769
== 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( t1748 != 0.0 ) ) ; t913 [ 1778ULL
] = 1 ; t913 [ 1779ULL ] = 1 ; t2769 = t1964 / 2.0 ; t913 [ 1780ULL ] = (
int32_T ) ( ( ! ( t1748 > t1970 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) /
30.0 ) ) || ( ! ( t1748 != 0.0 ) ) || ( t1964 / 2.0 != 0.0 ) ) ; t913 [
1781ULL ] = ( int32_T ) ( - t1752 < 663.67513503334737 ) ; t913 [ 1782ULL ] =
1 ; t913 [ 1783ULL ] = 1 ; t913 [ 1784ULL ] = ( int32_T ) ( X [ 365ULL ] !=
0.0 ) ; t913 [ 1785ULL ] = 1 ; t913 [ 1786ULL ] = 1 ; t913 [ 1787ULL ] = 1 ;
t913 [ 1788ULL ] = 1 ; t913 [ 1789ULL ] = 1 ; t913 [ 1790ULL ] = ( int32_T )
( ( X [ 368ULL ] * X [ 368ULL ] + 4.8610690726170741E-8 == X [ 368ULL ] * X [
368ULL ] + 4.8610690726170741E-8 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1791ULL ] = ( int32_T
) ( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 4.8610690726170741E-8 == X [ 368ULL ]
* X [ 368ULL ] + 4.8610690726170741E-8 ) ) || ( ! ( fabs ( X [ 368ULL ] * X [
368ULL ] + 4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 368ULL ] *
X [ 368ULL ] + 4.8610690726170741E-8 >= 0.0 ) ) ; t913 [ 1792ULL ] = 1 ; t913
[ 1793ULL ] = 1 ; t913 [ 1794ULL ] = ( int32_T ) ( ( X [ 368ULL ] * X [
368ULL ] + 9.37706225427676E-8 == X [ 368ULL ] * X [ 368ULL ] +
9.37706225427676E-8 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1795ULL ] = ( int32_T )
( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 9.37706225427676E-8 == X [ 368ULL ] * X
[ 368ULL ] + 9.37706225427676E-8 ) ) || ( ! ( fabs ( X [ 368ULL ] * X [
368ULL ] + 9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 368ULL ] * X
[ 368ULL ] + 9.37706225427676E-8 >= 0.0 ) ) ; t913 [ 1796ULL ] = 1 ; t913 [
1797ULL ] = 1 ; t913 [ 1798ULL ] = ( int32_T ) ( ( X [ 368ULL ] * X [ 368ULL
] + 6.6216804824104011E-8 == X [ 368ULL ] * X [ 368ULL ] +
6.6216804824104011E-8 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1799ULL ] = ( int32_T
) ( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 6.6216804824104011E-8 == X [ 368ULL ]
* X [ 368ULL ] + 6.6216804824104011E-8 ) ) || ( ! ( fabs ( X [ 368ULL ] * X [
368ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 368ULL ] *
X [ 368ULL ] + 6.6216804824104011E-8 >= 0.0 ) ) ; t913 [ 1800ULL ] = (
int32_T ) ( X [ 351ULL ] != 0.0 ) ; t913 [ 1801ULL ] = 1 ; t913 [ 1802ULL ] =
1 ; t913 [ 1803ULL ] = 1 ; t913 [ 1804ULL ] = 1 ; t913 [ 1805ULL ] = 1 ; t913
[ 1806ULL ] = ( int32_T ) ( ( X [ 371ULL ] * X [ 371ULL ] +
4.8610690726170741E-8 == X [ 371ULL ] * X [ 371ULL ] + 4.8610690726170741E-8
) && ( fabs ( X [ 371ULL ] * X [ 371ULL ] + 4.8610690726170741E-8 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1807ULL ] = ( int32_T ) ( ( ! ( X [ 371ULL ] * X
[ 371ULL ] + 4.8610690726170741E-8 == X [ 371ULL ] * X [ 371ULL ] +
4.8610690726170741E-8 ) ) || ( ! ( fabs ( X [ 371ULL ] * X [ 371ULL ] +
4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 371ULL ] * X [ 371ULL
] + 4.8610690726170741E-8 >= 0.0 ) ) ; t913 [ 1808ULL ] = 1 ; t913 [ 1809ULL
] = 1 ; t913 [ 1810ULL ] = ( int32_T ) ( ( X [ 371ULL ] * X [ 371ULL ] +
9.37706225427676E-8 == X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 ) &&
( fabs ( X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 ) != pmf_get_inf (
) ) ) ; t913 [ 1811ULL ] = ( int32_T ) ( ( ! ( X [ 371ULL ] * X [ 371ULL ] +
9.37706225427676E-8 == X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 ) )
|| ( ! ( fabs ( X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 >=
0.0 ) ) ; t913 [ 1812ULL ] = 1 ; t913 [ 1813ULL ] = 1 ; t913 [ 1814ULL ] = (
int32_T ) ( ( X [ 371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8 == X [
371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8 ) && ( fabs ( X [ 371ULL ] *
X [ 371ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [
1815ULL ] = ( int32_T ) ( ( ! ( X [ 371ULL ] * X [ 371ULL ] +
6.6216804824104011E-8 == X [ 371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8
) ) || ( ! ( fabs ( X [ 371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8
>= 0.0 ) ) ; t913 [ 1816ULL ] = ( int32_T ) ( X [ 50ULL ] != 0.0 ) ; t913 [
1817ULL ] = ( int32_T ) ( X [ 388ULL ] != 0.0 ) ; t913 [ 1818ULL ] = 1 ; t913
[ 1819ULL ] = 1 ; t913 [ 1820ULL ] = 1 ; t913 [ 1821ULL ] = ( int32_T ) (
t1758 - t1755 != 0.0 ) ; t913 [ 1822ULL ] = 1 ; t913 [ 1823ULL ] = 1 ; t913 [
1824ULL ] = ( int32_T ) ( ( t1756 * t1756 * 9.999999999999999E-14 + fabs ( X
[ 387ULL ] * t1760 * t1755 ) * 1.0E-9 == t1756 * t1756 *
9.999999999999999E-14 + fabs ( X [ 387ULL ] * t1760 * t1755 ) * 1.0E-9 ) && (
fabs ( t1756 * t1756 * 9.999999999999999E-14 + fabs ( X [ 387ULL ] * t1760 *
t1755 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1825ULL ] = ( int32_T ) (
( ! ( t1756 * t1756 * 9.999999999999999E-14 + fabs ( X [ 387ULL ] * t1760 *
t1755 ) * 1.0E-9 == t1756 * t1756 * 9.999999999999999E-14 + fabs ( X [ 387ULL
] * t1760 * t1755 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1756 * t1756 *
9.999999999999999E-14 + fabs ( X [ 387ULL ] * t1760 * t1755 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || ( t1756 * t1756 * 9.999999999999999E-14 + fabs ( X [
387ULL ] * t1760 * t1755 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1826ULL ] = 1 ; t913
[ 1827ULL ] = 1 ; t913 [ 1828ULL ] = ( int32_T ) ( t1755 != 0.0 ) ; t913 [
1829ULL ] = ( int32_T ) ( ( ! ( t1755 != 0.0 ) ) || ( X [ 387ULL ] != 0.0 ) )
; t913 [ 1830ULL ] = 1 ; t913 [ 1831ULL ] = ( int32_T ) ( ( ! ( t1755 != 0.0
) ) || ( ( t1755 != 0.0 ) && ( ! ( X [ 387ULL ] != 0.0 ) ) ) || ( fabs (
t1986 / ( t1755 == 0.0 ? 1.0E-16 : t1755 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16
: X [ 387ULL ] ) ) >= 0.0 ) ) ; t913 [ 1832ULL ] = ( int32_T ) ( t1765 * 0.44
!= 0.0 ) ; t913 [ 1833ULL ] = ( int32_T ) ( X [ 46ULL ] * t1755 != 0.0 ) ;
t913 [ 1834ULL ] = ( int32_T ) ( t1771 * 8.8000000000000011E-5 != 0.0 ) ;
t913 [ 1835ULL ] = ( int32_T ) ( t1773 != 0.0 ) ; t913 [ 1836ULL ] = (
int32_T ) ( ( ! ( t1773 != 0.0 ) ) || ( 6.9 / ( t1773 == 0.0 ? 1.0E-16 :
t1773 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1837ULL ] = 1 ; t913 [
1838ULL ] = 1 ; t913 [ 1839ULL ] = ( int32_T ) ( ( ! ( t1773 != 0.0 ) ) || (
( t1773 != 0.0 ) && ( ! ( 6.9 / ( t1773 == 0.0 ? 1.0E-16 : t1773 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1773 == 0.0 ?
1.0E-16 : t1773 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1773 ==
0.0 ? 1.0E-16 : t1773 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1840ULL ] = ( int32_T ) ( t1771 * 0.003872 != 0.0 ) ; t913 [ 1841ULL ] = 1 ;
t913 [ 1842ULL ] = 1 ; t913 [ 1843ULL ] = 1 ; t913 [ 1844ULL ] = 1 ; t913 [
1845ULL ] = ( int32_T ) ( X [ 50ULL ] != 0.0 ) ; t913 [ 1846ULL ] = ( int32_T
) ( X [ 390ULL ] != 0.0 ) ; t913 [ 1847ULL ] = 1 ; t913 [ 1848ULL ] = 1 ;
t913 [ 1849ULL ] = 1 ; t913 [ 1850ULL ] = ( int32_T ) ( t1772 - t1755 != 0.0
) ; t913 [ 1851ULL ] = 1 ; t913 [ 1852ULL ] = 1 ; t913 [ 1853ULL ] = (
int32_T ) ( ( t1767 * t1767 * 9.999999999999999E-14 + fabs ( X [ 389ULL ] *
t1753 * t1755 ) * 1.0E-9 == t1767 * t1767 * 9.999999999999999E-14 + fabs ( X
[ 389ULL ] * t1753 * t1755 ) * 1.0E-9 ) && ( fabs ( t1767 * t1767 *
9.999999999999999E-14 + fabs ( X [ 389ULL ] * t1753 * t1755 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1854ULL ] = ( int32_T ) ( ( ! ( t1767 * t1767 *
9.999999999999999E-14 + fabs ( X [ 389ULL ] * t1753 * t1755 ) * 1.0E-9 ==
t1767 * t1767 * 9.999999999999999E-14 + fabs ( X [ 389ULL ] * t1753 * t1755 )
* 1.0E-9 ) ) || ( ! ( fabs ( t1767 * t1767 * 9.999999999999999E-14 + fabs ( X
[ 389ULL ] * t1753 * t1755 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1767 *
t1767 * 9.999999999999999E-14 + fabs ( X [ 389ULL ] * t1753 * t1755 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 1855ULL ] = 1 ; t913 [ 1856ULL ] = 1 ; t913 [
1857ULL ] = ( int32_T ) ( t1755 != 0.0 ) ; t913 [ 1858ULL ] = ( int32_T ) ( (
! ( t1755 != 0.0 ) ) || ( X [ 389ULL ] != 0.0 ) ) ; t913 [ 1859ULL ] = 1 ;
t913 [ 1860ULL ] = ( int32_T ) ( ( ! ( t1755 != 0.0 ) ) || ( ( t1755 != 0.0 )
&& ( ! ( X [ 389ULL ] != 0.0 ) ) ) || ( fabs ( t2006 / ( t1755 == 0.0 ?
1.0E-16 : t1755 ) / ( X [ 389ULL ] == 0.0 ? 1.0E-16 : X [ 389ULL ] ) ) >= 0.0
) ) ; t913 [ 1861ULL ] = ( int32_T ) ( t1765 * 0.44 != 0.0 ) ; t913 [ 1862ULL
] = ( int32_T ) ( t1771 * 8.8000000000000011E-5 != 0.0 ) ; t913 [ 1863ULL ] =
( int32_T ) ( t1779 != 0.0 ) ; t913 [ 1864ULL ] = ( int32_T ) ( ( ! ( t1779
!= 0.0 ) ) || ( 6.9 / ( t1779 == 0.0 ? 1.0E-16 : t1779 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 1865ULL ] = 1 ; t913 [ 1866ULL ] =
1 ; t913 [ 1867ULL ] = ( int32_T ) ( ( ! ( t1779 != 0.0 ) ) || ( ( t1779 !=
0.0 ) && ( ! ( 6.9 / ( t1779 == 0.0 ? 1.0E-16 : t1779 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1779 == 0.0 ?
1.0E-16 : t1779 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1779 ==
0.0 ? 1.0E-16 : t1779 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1868ULL ] = ( int32_T ) ( t1771 * 0.003872 != 0.0 ) ; t913 [ 1869ULL ] = 1 ;
t913 [ 1870ULL ] = 1 ; t913 [ 1871ULL ] = 1 ; t913 [ 1872ULL ] = 1 ; t913 [
1873ULL ] = ( int32_T ) ( t1766 != 0.0 ) ; t913 [ 1874ULL ] = ( int32_T ) (
t1774 != 0.0 ) ; t913 [ 1875ULL ] = 1 ; t913 [ 1876ULL ] = ( int32_T ) ( ( !
( 1.0 - X [ 48ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 48ULL ] ) - 0.01 ) / 0.01
< 663.67513503334737 ) || ( 1.0 - X [ 48ULL ] >= 0.01 ) ) ; t913 [ 1877ULL ]
= 1 ; t913 [ 1878ULL ] = ( int32_T ) ( t1776 != 0.0 ) ; t913 [ 1879ULL ] = (
int32_T ) ( X [ 50ULL ] * 100000.0 > 0.0 ) ; t913 [ 1880ULL ] = ( int32_T ) (
( ! ( X [ 50ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 50ULL ] * 100000.0
) - t186 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 1881ULL ] = 1 ; t913 [
1882ULL ] = ( int32_T ) ( ( ! ( t1780 >= 1.0 ) ) || ( ( t1780 - 1.0 ) *
461.523 + t1777 != 0.0 ) ) ; t913 [ 1883ULL ] = ( int32_T ) ( t1782 * 0.01 !=
0.0 ) ; t913 [ 1884ULL ] = 1 ; t913 [ 1885ULL ] = 1 ; t913 [ 1886ULL ] = 1 ;
t913 [ 1887ULL ] = 1 ; t913 [ 1888ULL ] = ( int32_T ) ( t1746 != 0.0 ) ; t913
[ 1889ULL ] = ( int32_T ) ( t2022 / 2.0 * 0.44 != 0.0 ) ; t913 [ 1890ULL ] =
1 ; t913 [ 1891ULL ] = ( int32_T ) ( t1709 != 0.0 ) ; t913 [ 1892ULL ] = (
int32_T ) ( ( ! ( t1709 != 0.0 ) ) || ( 6.9 / ( t1709 == 0.0 ? 1.0E-16 :
t1709 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 1893ULL ] = 1 ; t913 [
1894ULL ] = 1 ; t913 [ 1895ULL ] = ( int32_T ) ( ( ! ( t1709 != 0.0 ) ) || (
( t1709 != 0.0 ) && ( ! ( 6.9 / ( t1709 == 0.0 ? 1.0E-16 : t1709 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1709 == 0.0 ?
1.0E-16 : t1709 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1709 ==
0.0 ? 1.0E-16 : t1709 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
1896ULL ] = ( int32_T ) ( ( t1785 / 8.0 == t1785 / 8.0 ) && ( fabs ( t1785 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 1897ULL ] = ( int32_T ) ( ( ! ( t1785 /
8.0 == t1785 / 8.0 ) ) || ( ! ( fabs ( t1785 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1785 / 8.0 >= 0.0 ) ) ; t913 [ 1898ULL ] = 1 ; t913 [ 1899ULL ] = (
int32_T ) ( t1784 >= 0.0 ) ; t913 [ 1900ULL ] = ( int32_T ) ( ( ! ( t1785 /
8.0 == t1785 / 8.0 ) ) || ( ! ( fabs ( t1785 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1785 / 8.0 == t1785 / 8.0 ) && ( fabs ( t1785 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1785 / 8.0 >= 0.0 ) ) ) || ( ! ( t1784 >= 0.0 ) ) || ( (
pmf_pow ( t1784 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1785 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 1901ULL ] = 1 ; t913 [ 1902ULL ] = 1 ; t913 [
1903ULL ] = 1 ; t913 [ 1904ULL ] = 1 ; t913 [ 1905ULL ] = ( int32_T ) ( t2025
/ 2.0 != 0.0 ) ; t913 [ 1906ULL ] = 1 ; t2769 = t2025 / 2.0 ; t913 [ 1907ULL
] = ( int32_T ) ( ( ! ( t1764 > t2031 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( t1764 != 0.0 ) ) ; t913 [ 1908ULL ] = 1 ; t913 [
1909ULL ] = 1 ; t2769 = t2025 / 2.0 ; t913 [ 1910ULL ] = ( int32_T ) ( ( ! (
t1764 > t2031 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( ! (
t1764 != 0.0 ) ) || ( t2025 / 2.0 != 0.0 ) ) ; t913 [ 1911ULL ] = ( int32_T )
( - intrm_sf_mf_1066 < 663.67513503334737 ) ; t913 [ 1912ULL ] = ( int32_T )
( t1674 != 0.0 ) ; t913 [ 1913ULL ] = ( int32_T ) ( t2036 / 2.0 * 0.44 != 0.0
) ; t913 [ 1914ULL ] = 1 ; t913 [ 1915ULL ] = ( int32_T ) ( intrm_sf_mf_1083
!= 0.0 ) ; t913 [ 1916ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_1083 != 0.0 ) )
|| ( 6.9 / ( intrm_sf_mf_1083 == 0.0 ? 1.0E-16 : intrm_sf_mf_1083 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 1917ULL ] = 1 ; t913 [ 1918ULL ] =
1 ; t913 [ 1919ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_1083 != 0.0 ) ) || ( (
intrm_sf_mf_1083 != 0.0 ) && ( ! ( 6.9 / ( intrm_sf_mf_1083 == 0.0 ? 1.0E-16
: intrm_sf_mf_1083 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 (
6.9 / ( intrm_sf_mf_1083 == 0.0 ? 1.0E-16 : intrm_sf_mf_1083 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1083 == 0.0 ?
1.0E-16 : intrm_sf_mf_1083 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ;
t913 [ 1920ULL ] = ( int32_T ) ( ( intrm_sf_mf_1085 / 8.0 == intrm_sf_mf_1085
/ 8.0 ) && ( fabs ( intrm_sf_mf_1085 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [
1921ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_1085 / 8.0 == intrm_sf_mf_1085 /
8.0 ) ) || ( ! ( fabs ( intrm_sf_mf_1085 / 8.0 ) != pmf_get_inf ( ) ) ) || (
intrm_sf_mf_1085 / 8.0 >= 0.0 ) ) ; t913 [ 1922ULL ] = 1 ; t913 [ 1923ULL ] =
( int32_T ) ( t1763 >= 0.0 ) ; t913 [ 1924ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_1085 / 8.0 == intrm_sf_mf_1085 / 8.0 ) ) || ( ! ( fabs (
intrm_sf_mf_1085 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( intrm_sf_mf_1085 / 8.0
== intrm_sf_mf_1085 / 8.0 ) && ( fabs ( intrm_sf_mf_1085 / 8.0 ) !=
pmf_get_inf ( ) ) && ( ! ( intrm_sf_mf_1085 / 8.0 >= 0.0 ) ) ) || ( ! ( t1763
>= 0.0 ) ) || ( ( pmf_pow ( t1763 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt
( intrm_sf_mf_1085 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 1925ULL ] = 1 ;
t913 [ 1926ULL ] = 1 ; t913 [ 1927ULL ] = 1 ; t913 [ 1928ULL ] = 1 ; t913 [
1929ULL ] = ( int32_T ) ( t2044 / 2.0 != 0.0 ) ; t913 [ 1930ULL ] = 1 ; t2769
= t2044 / 2.0 ; t913 [ 1931ULL ] = ( int32_T ) ( ( ! ( t1742 > t2050 / 0.44 /
( t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( t1742 != 0.0 ) ) ; t913 [
1932ULL ] = 1 ; t913 [ 1933ULL ] = 1 ; t2769 = t2044 / 2.0 ; t913 [ 1934ULL ]
= ( int32_T ) ( ( ! ( t1742 > t2050 / 0.44 / ( t2769 == 0.0 ? 1.0E-16 : t2769
) / 30.0 ) ) || ( ! ( t1742 != 0.0 ) ) || ( t2044 / 2.0 != 0.0 ) ) ; t913 [
1935ULL ] = ( int32_T ) ( - t1790 < 663.67513503334737 ) ; t913 [ 1936ULL ] =
1 ; t913 [ 1937ULL ] = 1 ; t913 [ 1938ULL ] = ( int32_T ) ( X [ 351ULL ] !=
0.0 ) ; t913 [ 1939ULL ] = 1 ; t913 [ 1940ULL ] = 1 ; t913 [ 1941ULL ] = 1 ;
t913 [ 1942ULL ] = 1 ; t913 [ 1943ULL ] = 1 ; t913 [ 1944ULL ] = ( int32_T )
( ( X [ 371ULL ] * X [ 371ULL ] + 4.8610690726170741E-8 == X [ 371ULL ] * X [
371ULL ] + 4.8610690726170741E-8 ) && ( fabs ( X [ 371ULL ] * X [ 371ULL ] +
4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1945ULL ] = ( int32_T
) ( ( ! ( X [ 371ULL ] * X [ 371ULL ] + 4.8610690726170741E-8 == X [ 371ULL ]
* X [ 371ULL ] + 4.8610690726170741E-8 ) ) || ( ! ( fabs ( X [ 371ULL ] * X [
371ULL ] + 4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 371ULL ] *
X [ 371ULL ] + 4.8610690726170741E-8 >= 0.0 ) ) ; t913 [ 1946ULL ] = 1 ; t913
[ 1947ULL ] = 1 ; t913 [ 1948ULL ] = ( int32_T ) ( ( X [ 371ULL ] * X [
371ULL ] + 9.37706225427676E-8 == X [ 371ULL ] * X [ 371ULL ] +
9.37706225427676E-8 ) && ( fabs ( X [ 371ULL ] * X [ 371ULL ] +
9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1949ULL ] = ( int32_T )
( ( ! ( X [ 371ULL ] * X [ 371ULL ] + 9.37706225427676E-8 == X [ 371ULL ] * X
[ 371ULL ] + 9.37706225427676E-8 ) ) || ( ! ( fabs ( X [ 371ULL ] * X [
371ULL ] + 9.37706225427676E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 371ULL ] * X
[ 371ULL ] + 9.37706225427676E-8 >= 0.0 ) ) ; t913 [ 1950ULL ] = 1 ; t913 [
1951ULL ] = 1 ; t913 [ 1952ULL ] = ( int32_T ) ( ( X [ 371ULL ] * X [ 371ULL
] + 6.6216804824104011E-8 == X [ 371ULL ] * X [ 371ULL ] +
6.6216804824104011E-8 ) && ( fabs ( X [ 371ULL ] * X [ 371ULL ] +
6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 1953ULL ] = ( int32_T
) ( ( ! ( X [ 371ULL ] * X [ 371ULL ] + 6.6216804824104011E-8 == X [ 371ULL ]
* X [ 371ULL ] + 6.6216804824104011E-8 ) ) || ( ! ( fabs ( X [ 371ULL ] * X [
371ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 371ULL ] *
X [ 371ULL ] + 6.6216804824104011E-8 >= 0.0 ) ) ; t913 [ 1954ULL ] = (
int32_T ) ( X [ 303ULL ] != 0.0 ) ; t913 [ 1955ULL ] = 1 ; t913 [ 1956ULL ] =
1 ; t913 [ 1957ULL ] = 1 ; t913 [ 1958ULL ] = 1 ; t913 [ 1959ULL ] = 1 ; t913
[ 1960ULL ] = ( int32_T ) ( ( X [ 325ULL ] * X [ 325ULL ] +
4.8610690726170741E-8 == X [ 325ULL ] * X [ 325ULL ] + 4.8610690726170741E-8
) && ( fabs ( X [ 325ULL ] * X [ 325ULL ] + 4.8610690726170741E-8 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 1961ULL ] = ( int32_T ) ( ( ! ( X [ 325ULL ] * X
[ 325ULL ] + 4.8610690726170741E-8 == X [ 325ULL ] * X [ 325ULL ] +
4.8610690726170741E-8 ) ) || ( ! ( fabs ( X [ 325ULL ] * X [ 325ULL ] +
4.8610690726170741E-8 ) != pmf_get_inf ( ) ) ) || ( X [ 325ULL ] * X [ 325ULL
] + 4.8610690726170741E-8 >= 0.0 ) ) ; t913 [ 1962ULL ] = 1 ; t913 [ 1963ULL
] = 1 ; t913 [ 1964ULL ] = ( int32_T ) ( ( X [ 325ULL ] * X [ 325ULL ] +
9.37706225427676E-8 == X [ 325ULL ] * X [ 325ULL ] + 9.37706225427676E-8 ) &&
( fabs ( X [ 325ULL ] * X [ 325ULL ] + 9.37706225427676E-8 ) != pmf_get_inf (
) ) ) ; t913 [ 1965ULL ] = ( int32_T ) ( ( ! ( X [ 325ULL ] * X [ 325ULL ] +
9.37706225427676E-8 == X [ 325ULL ] * X [ 325ULL ] + 9.37706225427676E-8 ) )
|| ( ! ( fabs ( X [ 325ULL ] * X [ 325ULL ] + 9.37706225427676E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 325ULL ] * X [ 325ULL ] + 9.37706225427676E-8 >=
0.0 ) ) ; t913 [ 1966ULL ] = 1 ; t913 [ 1967ULL ] = 1 ; t913 [ 1968ULL ] = (
int32_T ) ( ( X [ 325ULL ] * X [ 325ULL ] + 6.6216804824104011E-8 == X [
325ULL ] * X [ 325ULL ] + 6.6216804824104011E-8 ) && ( fabs ( X [ 325ULL ] *
X [ 325ULL ] + 6.6216804824104011E-8 ) != pmf_get_inf ( ) ) ) ; t913 [
1969ULL ] = ( int32_T ) ( ( ! ( X [ 325ULL ] * X [ 325ULL ] +
6.6216804824104011E-8 == X [ 325ULL ] * X [ 325ULL ] + 6.6216804824104011E-8
) ) || ( ! ( fabs ( X [ 325ULL ] * X [ 325ULL ] + 6.6216804824104011E-8 ) !=
pmf_get_inf ( ) ) ) || ( X [ 325ULL ] * X [ 325ULL ] + 6.6216804824104011E-8
>= 0.0 ) ) ; t913 [ 1970ULL ] = ( int32_T ) ( X [ 54ULL ] != 0.0 ) ; t913 [
1971ULL ] = ( int32_T ) ( X [ 415ULL ] != 0.0 ) ; t913 [ 1972ULL ] = 1 ; t913
[ 1973ULL ] = 1 ; t913 [ 1974ULL ] = 1 ; t913 [ 1975ULL ] = ( int32_T ) (
t1795 - t1792 != 0.0 ) ; t913 [ 1976ULL ] = 1 ; t913 [ 1977ULL ] = 1 ; t913 [
1978ULL ] = ( int32_T ) ( ( t1793 * t1793 * 9.999999999999999E-14 + fabs ( X
[ 414ULL ] * t1388 * t1792 ) * 1.0E-9 == t1793 * t1793 *
9.999999999999999E-14 + fabs ( X [ 414ULL ] * t1388 * t1792 ) * 1.0E-9 ) && (
fabs ( t1793 * t1793 * 9.999999999999999E-14 + fabs ( X [ 414ULL ] * t1388 *
t1792 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 1979ULL ] = ( int32_T ) (
( ! ( t1793 * t1793 * 9.999999999999999E-14 + fabs ( X [ 414ULL ] * t1388 *
t1792 ) * 1.0E-9 == t1793 * t1793 * 9.999999999999999E-14 + fabs ( X [ 414ULL
] * t1388 * t1792 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1793 * t1793 *
9.999999999999999E-14 + fabs ( X [ 414ULL ] * t1388 * t1792 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || ( t1793 * t1793 * 9.999999999999999E-14 + fabs ( X [
414ULL ] * t1388 * t1792 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 1980ULL ] = 1 ; t913
[ 1981ULL ] = 1 ; t913 [ 1982ULL ] = ( int32_T ) ( t1792 != 0.0 ) ; t913 [
1983ULL ] = ( int32_T ) ( ( ! ( t1792 != 0.0 ) ) || ( X [ 414ULL ] != 0.0 ) )
; t913 [ 1984ULL ] = 1 ; t913 [ 1985ULL ] = ( int32_T ) ( ( ! ( t1792 != 0.0
) ) || ( ( t1792 != 0.0 ) && ( ! ( X [ 414ULL ] != 0.0 ) ) ) || ( fabs (
t2066 / ( t1792 == 0.0 ? 1.0E-16 : t1792 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16
: X [ 414ULL ] ) ) >= 0.0 ) ) ; t913 [ 1986ULL ] = ( int32_T ) ( t1801 *
0.0019634954084936209 != 0.0 ) ; t913 [ 1987ULL ] = ( int32_T ) ( X [ 51ULL ]
* t1792 != 0.0 ) ; t913 [ 1988ULL ] = ( int32_T ) ( t1809 *
9.8174770424681068E-6 != 0.0 ) ; t913 [ 1989ULL ] = ( int32_T ) ( t1811 !=
0.0 ) ; t913 [ 1990ULL ] = ( int32_T ) ( ( ! ( t1811 != 0.0 ) ) || ( 6.9 / (
t1811 == 0.0 ? 1.0E-16 : t1811 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [
1991ULL ] = 1 ; t913 [ 1992ULL ] = 1 ; t913 [ 1993ULL ] = ( int32_T ) ( ( ! (
t1811 != 0.0 ) ) || ( ( t1811 != 0.0 ) && ( ! ( 6.9 / ( t1811 == 0.0 ?
1.0E-16 : t1811 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1811 == 0.0 ? 1.0E-16 : t1811 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1811 == 0.0 ? 1.0E-16 : t1811 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 1994ULL ] = ( int32_T ) ( t1809 * 3.855314219175531E-7 !=
0.0 ) ; t913 [ 1995ULL ] = 1 ; t913 [ 1996ULL ] = 1 ; t913 [ 1997ULL ] = 1 ;
t913 [ 1998ULL ] = 1 ; t913 [ 1999ULL ] = ( int32_T ) ( X [ 54ULL ] != 0.0 )
; t913 [ 2000ULL ] = ( int32_T ) ( X [ 417ULL ] != 0.0 ) ; t913 [ 2001ULL ] =
1 ; t913 [ 2002ULL ] = 1 ; t913 [ 2003ULL ] = 1 ; t913 [ 2004ULL ] = (
int32_T ) ( t1810 - t1792 != 0.0 ) ; t913 [ 2005ULL ] = 1 ; t913 [ 2006ULL ]
= 1 ; t913 [ 2007ULL ] = ( int32_T ) ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ) && (
fabs ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 2008ULL ] = ( int32_T ) ( ( ! (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ==
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ) ) ||
( ! ( fabs ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip22 *
9.999999999999999E-14 + fabs ( X [ 416ULL ] * t1783 * t1792 ) * 1.0E-9 >= 0.0
) ) ; t913 [ 2009ULL ] = 1 ; t913 [ 2010ULL ] = 1 ; t913 [ 2011ULL ] = (
int32_T ) ( t1792 != 0.0 ) ; t913 [ 2012ULL ] = ( int32_T ) ( ( ! ( t1792 !=
0.0 ) ) || ( X [ 416ULL ] != 0.0 ) ) ; t913 [ 2013ULL ] = 1 ; t913 [ 2014ULL
] = ( int32_T ) ( ( ! ( t1792 != 0.0 ) ) || ( ( t1792 != 0.0 ) && ( ! ( X [
416ULL ] != 0.0 ) ) ) || ( fabs ( t2085 / ( t1792 == 0.0 ? 1.0E-16 : t1792 )
/ ( X [ 416ULL ] == 0.0 ? 1.0E-16 : X [ 416ULL ] ) ) >= 0.0 ) ) ; t913 [
2015ULL ] = ( int32_T ) ( t1801 * 0.0019634954084936209 != 0.0 ) ; t913 [
2016ULL ] = ( int32_T ) ( t1809 * 9.8174770424681068E-6 != 0.0 ) ; t913 [
2017ULL ] = ( int32_T ) ( t1816 != 0.0 ) ; t913 [ 2018ULL ] = ( int32_T ) ( (
! ( t1816 != 0.0 ) ) || ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816 ) +
2.8767404433520813E-5 > 0.0 ) ) ; t913 [ 2019ULL ] = 1 ; t913 [ 2020ULL ] = 1
; t913 [ 2021ULL ] = ( int32_T ) ( ( ! ( t1816 != 0.0 ) ) || ( ( t1816 != 0.0
) && ( ! ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816 ) + 2.8767404433520813E-5 >
0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1816 == 0.0 ? 1.0E-16 : t1816
) + 2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 2022ULL ] = ( int32_T
) ( t1809 * 3.855314219175531E-7 != 0.0 ) ; t913 [ 2023ULL ] = 1 ; t913 [
2024ULL ] = 1 ; t913 [ 2025ULL ] = 1 ; t913 [ 2026ULL ] = 1 ; t913 [ 2027ULL
] = ( int32_T ) ( t1802 != 0.0 ) ; t913 [ 2028ULL ] = ( int32_T ) ( t1812 !=
0.0 ) ; t913 [ 2029ULL ] = 1 ; t913 [ 2030ULL ] = ( int32_T ) ( ( ! ( 1.0 - X
[ 53ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 53ULL ] ) - 0.01 ) / 0.01 <
663.67513503334737 ) || ( 1.0 - X [ 53ULL ] >= 0.01 ) ) ; t913 [ 2031ULL ] =
1 ; t913 [ 2032ULL ] = ( int32_T ) ( t1814 != 0.0 ) ; t913 [ 2033ULL ] = (
int32_T ) ( X [ 54ULL ] * 100000.0 > 0.0 ) ; t913 [ 2034ULL ] = ( int32_T ) (
( ! ( X [ 54ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 54ULL ] * 100000.0
) - t159 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 2035ULL ] = 1 ; t913 [
2036ULL ] = ( int32_T ) ( ( ! ( t1820 >= 1.0 ) ) || ( ( t1820 - 1.0 ) *
461.523 + t1815 != 0.0 ) ) ; t913 [ 2037ULL ] = ( int32_T ) ( t1821 * 0.01 !=
0.0 ) ; t913 [ 2038ULL ] = 1 ; t913 [ 2039ULL ] = 1 ; t913 [ 2040ULL ] = 1 ;
t913 [ 2041ULL ] = 1 ; t913 [ 2042ULL ] = ( int32_T ) ( t1826 != 0.0 ) ; t913
[ 2043ULL ] = ( int32_T ) ( t2100 / 2.0 * 0.0019634954084936209 != 0.0 ) ;
t913 [ 2044ULL ] = 1 ; t913 [ 2045ULL ] = ( int32_T ) ( t1800 != 0.0 ) ; t913
[ 2046ULL ] = ( int32_T ) ( ( ! ( t1800 != 0.0 ) ) || ( 6.9 / ( t1800 == 0.0
? 1.0E-16 : t1800 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [ 2047ULL ] = 1
; t913 [ 2048ULL ] = 1 ; t913 [ 2049ULL ] = ( int32_T ) ( ( ! ( t1800 != 0.0
) ) || ( ( t1800 != 0.0 ) && ( ! ( 6.9 / ( t1800 == 0.0 ? 1.0E-16 : t1800 ) +
2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1800 == 0.0 ?
1.0E-16 : t1800 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1800 ==
0.0 ? 1.0E-16 : t1800 ) + 2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [
2050ULL ] = ( int32_T ) ( ( t1831 / 8.0 == t1831 / 8.0 ) && ( fabs ( t1831 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2051ULL ] = ( int32_T ) ( ( ! ( t1831 /
8.0 == t1831 / 8.0 ) ) || ( ! ( fabs ( t1831 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1831 / 8.0 >= 0.0 ) ) ; t913 [ 2052ULL ] = 1 ; t913 [ 2053ULL ] = (
int32_T ) ( t1828 >= 0.0 ) ; t913 [ 2054ULL ] = ( int32_T ) ( ( ! ( t1831 /
8.0 == t1831 / 8.0 ) ) || ( ! ( fabs ( t1831 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1831 / 8.0 == t1831 / 8.0 ) && ( fabs ( t1831 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1831 / 8.0 >= 0.0 ) ) ) || ( ! ( t1828 >= 0.0 ) ) || ( (
pmf_pow ( t1828 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1831 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 2055ULL ] = 1 ; t913 [ 2056ULL ] = 1 ; t913 [
2057ULL ] = 1 ; t913 [ 2058ULL ] = 1 ; t913 [ 2059ULL ] = ( int32_T ) ( t2107
/ 2.0 != 0.0 ) ; t913 [ 2060ULL ] = 1 ; t2769 = t2107 / 2.0 ; t913 [ 2061ULL
] = ( int32_T ) ( ( ! ( t1824 > t2110 / 0.0019634954084936209 / ( t2769 ==
0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( t1824 != 0.0 ) ) ; t913 [ 2062ULL ] =
1 ; t913 [ 2063ULL ] = 1 ; t2769 = t2107 / 2.0 ; t913 [ 2064ULL ] = ( int32_T
) ( ( ! ( t1824 > t2110 / 0.0019634954084936209 / ( t2769 == 0.0 ? 1.0E-16 :
t2769 ) / 30.0 ) ) || ( ! ( t1824 != 0.0 ) ) || ( t2107 / 2.0 != 0.0 ) ) ;
t913 [ 2065ULL ] = ( int32_T ) ( - t1833 < 663.67513503334737 ) ; t913 [
2066ULL ] = ( int32_T ) ( t1732 != 0.0 ) ; t913 [ 2067ULL ] = ( int32_T ) (
t2118 / 2.0 * 0.0019634954084936209 != 0.0 ) ; t913 [ 2068ULL ] = 1 ; t913 [
2069ULL ] = ( int32_T ) ( t1738 != 0.0 ) ; t913 [ 2070ULL ] = ( int32_T ) ( (
! ( t1738 != 0.0 ) ) || ( 6.9 / ( t1738 == 0.0 ? 1.0E-16 : t1738 ) +
2.8767404433520813E-5 > 0.0 ) ) ; t913 [ 2071ULL ] = 1 ; t913 [ 2072ULL ] = 1
; t913 [ 2073ULL ] = ( int32_T ) ( ( ! ( t1738 != 0.0 ) ) || ( ( t1738 != 0.0
) && ( ! ( 6.9 / ( t1738 == 0.0 ? 1.0E-16 : t1738 ) + 2.8767404433520813E-5 >
0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1738 == 0.0 ? 1.0E-16 : t1738 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t1738 == 0.0 ? 1.0E-16 : t1738
) + 2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 2074ULL ] = ( int32_T
) ( ( t1834 / 8.0 == t1834 / 8.0 ) && ( fabs ( t1834 / 8.0 ) != pmf_get_inf (
) ) ) ; t913 [ 2075ULL ] = ( int32_T ) ( ( ! ( t1834 / 8.0 == t1834 / 8.0 ) )
|| ( ! ( fabs ( t1834 / 8.0 ) != pmf_get_inf ( ) ) ) || ( t1834 / 8.0 >= 0.0
) ) ; t913 [ 2076ULL ] = 1 ; t913 [ 2077ULL ] = ( int32_T ) ( t1822 >= 0.0 )
; t913 [ 2078ULL ] = ( int32_T ) ( ( ! ( t1834 / 8.0 == t1834 / 8.0 ) ) || (
! ( fabs ( t1834 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( t1834 / 8.0 == t1834 /
8.0 ) && ( fabs ( t1834 / 8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1834 / 8.0 >=
0.0 ) ) ) || ( ! ( t1822 >= 0.0 ) ) || ( ( pmf_pow ( t1822 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1834 / 8.0 ) * 12.7 + 1.0 != 0.0
) ) ; t913 [ 2079ULL ] = 1 ; t913 [ 2080ULL ] = 1 ; t913 [ 2081ULL ] = 1 ;
t913 [ 2082ULL ] = 1 ; t913 [ 2083ULL ] = ( int32_T ) ( t2126 / 2.0 != 0.0 )
; t913 [ 2084ULL ] = 1 ; t2769 = t2126 / 2.0 ; t913 [ 2085ULL ] = ( int32_T )
( ( ! ( intrm_sf_mf_1220 > t2132 / 0.0019634954084936209 / ( t2769 == 0.0 ?
1.0E-16 : t2769 ) / 30.0 ) ) || ( intrm_sf_mf_1220 != 0.0 ) ) ; t913 [
2086ULL ] = 1 ; t913 [ 2087ULL ] = 1 ; t2769 = t2126 / 2.0 ; t913 [ 2088ULL ]
= ( int32_T ) ( ( ! ( intrm_sf_mf_1220 > t2132 / 0.0019634954084936209 / (
t2769 == 0.0 ? 1.0E-16 : t2769 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_1220 != 0.0
) ) || ( t2126 / 2.0 != 0.0 ) ) ; t913 [ 2089ULL ] = ( int32_T ) ( -
intrm_sf_mf_1228 < 663.67513503334737 ) ; t913 [ 2090ULL ] = 1 ; t913 [
2091ULL ] = 1 ; t913 [ 2092ULL ] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913
[ 2093ULL ] = 1 ; t913 [ 2094ULL ] = 1 ; t913 [ 2095ULL ] = 1 ; t913 [
2096ULL ] = 1 ; t913 [ 2097ULL ] = 1 ; t913 [ 2098ULL ] = ( int32_T ) ( ( X [
413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 == X [ 413ULL ] * X [ 413ULL
] + 3.0116308772356542E-13 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2099ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 == X [
413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 3.0116308772356542E-13 >= 0.0 ) ) ; t913 [
2100ULL ] = 1 ; t913 [ 2101ULL ] = 1 ; t913 [ 2102ULL ] = ( int32_T ) ( ( X [
413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 == X [ 413ULL ] * X [ 413ULL
] + 5.8094731428156895E-13 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2103ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 == X [
413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
2104ULL ] = 1 ; t913 [ 2105ULL ] = 1 ; t913 [ 2106ULL ] = ( int32_T ) ( ( X [
413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 == X [ 413ULL ] * X [ 413ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2107ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 == X [
413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
2108ULL ] = ( int32_T ) ( X [ 365ULL ] != 0.0 ) ; t913 [ 2109ULL ] = 1 ; t913
[ 2110ULL ] = 1 ; t913 [ 2111ULL ] = 1 ; t913 [ 2112ULL ] = 1 ; t913 [
2113ULL ] = 1 ; t913 [ 2114ULL ] = ( int32_T ) ( ( X [ 368ULL ] * X [ 368ULL
] + 3.0116308772356542E-13 == X [ 368ULL ] * X [ 368ULL ] +
3.0116308772356542E-13 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2115ULL ] = (
int32_T ) ( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 3.0116308772356542E-13 == X [
368ULL ] * X [ 368ULL ] + 3.0116308772356542E-13 ) ) || ( ! ( fabs ( X [
368ULL ] * X [ 368ULL ] + 3.0116308772356542E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 368ULL ] * X [ 368ULL ] + 3.0116308772356542E-13 >= 0.0 ) ) ; t913 [
2116ULL ] = 1 ; t913 [ 2117ULL ] = 1 ; t913 [ 2118ULL ] = ( int32_T ) ( ( X [
368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 == X [ 368ULL ] * X [ 368ULL
] + 5.8094731428156895E-13 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2119ULL ] = (
int32_T ) ( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 == X [
368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 ) ) || ( ! ( fabs ( X [
368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 368ULL ] * X [ 368ULL ] + 5.8094731428156895E-13 >= 0.0 ) ) ; t913 [
2120ULL ] = 1 ; t913 [ 2121ULL ] = 1 ; t913 [ 2122ULL ] = ( int32_T ) ( ( X [
368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 == X [ 368ULL ] * X [ 368ULL
] + 4.1024015709531055E-13 ) && ( fabs ( X [ 368ULL ] * X [ 368ULL ] +
4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2123ULL ] = (
int32_T ) ( ( ! ( X [ 368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 == X [
368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 ) ) || ( ! ( fabs ( X [
368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 368ULL ] * X [ 368ULL ] + 4.1024015709531055E-13 >= 0.0 ) ) ; t913 [
2124ULL ] = 1 ; t913 [ 2125ULL ] = 1 ; t913 [ 2126ULL ] = ( int32_T ) ( (
t1830 * t1830 + 6.4274470286298274E-9 == t1830 * t1830 +
6.4274470286298274E-9 ) && ( fabs ( t1830 * t1830 + 6.4274470286298274E-9 )
!= pmf_get_inf ( ) ) ) ; t913 [ 2127ULL ] = ( int32_T ) ( ( ! ( t1830 * t1830
+ 6.4274470286298274E-9 == t1830 * t1830 + 6.4274470286298274E-9 ) ) || ( ! (
fabs ( t1830 * t1830 + 6.4274470286298274E-9 ) != pmf_get_inf ( ) ) ) || (
t1830 * t1830 + 6.4274470286298274E-9 >= 0.0 ) ) ; t913 [ 2128ULL ] = (
int32_T ) ( intrm_sf_mf_1227 != 0.0 ) ; t913 [ 2129ULL ] = ( int32_T ) ( ( !
( intrm_sf_mf_1227 != 0.0 ) ) || ( t2779 != 0.0 ) ) ; t913 [ 2130ULL ] = (
int32_T ) ( intrm_sf_mf_1227 != 0.0 ) ; t913 [ 2131ULL ] = 1 ; t913 [ 2132ULL
] = ( int32_T ) ( intrm_sf_mf_1227 != 0.0 ) ; t913 [ 2133ULL ] = 1 ; t913 [
2134ULL ] = 1 ; t913 [ 2135ULL ] = 1 ; t913 [ 2136ULL ] = ( int32_T ) ( t1837
!= 0.0 ) ; t913 [ 2137ULL ] = ( int32_T ) ( t1837 != 0.0 ) ; t913 [ 2138ULL ]
= 1 ; t913 [ 2139ULL ] = 1 ; t913 [ 2140ULL ] = ( int32_T ) ( ( X [ 442ULL ]
* X [ 442ULL ] + 1.2620262729050631E-10 == X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 ) && ( fabs ( X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) ; t913 [ 2141ULL ] = (
int32_T ) ( ( ! ( X [ 442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 == X [
442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 ) ) || ( ! ( fabs ( X [
442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) ||
( X [ 442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 >= 0.0 ) ) ; t913 [
2142ULL ] = ( int32_T ) ( t1838 != 0.0 ) ; t913 [ 2143ULL ] = ( int32_T ) ( (
! ( t1838 != 0.0 ) ) || ( t1839 != 0.0 ) ) ; t913 [ 2144ULL ] = ( int32_T ) (
t1838 != 0.0 ) ; t913 [ 2145ULL ] = 1 ; t913 [ 2146ULL ] = ( int32_T ) (
t1838 != 0.0 ) ; t913 [ 2147ULL ] = 1 ; t913 [ 2148ULL ] = 1 ; t913 [ 2149ULL
] = 1 ; t913 [ 2150ULL ] = ( int32_T ) ( ( X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 == X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 ) && ( fabs ( X [ 442ULL ] * X [ 442ULL ] +
1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) ; t913 [ 2151ULL ] = (
int32_T ) ( ( ! ( X [ 442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 == X [
442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 ) ) || ( ! ( fabs ( X [
442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) ||
( X [ 442ULL ] * X [ 442ULL ] + 1.2620262729050631E-10 >= 0.0 ) ) ; t913 [
2152ULL ] = ( int32_T ) ( t1838 != 0.0 ) ; t913 [ 2153ULL ] = ( int32_T ) ( (
! ( t1838 != 0.0 ) ) || ( t1840 != 0.0 ) ) ; t913 [ 2154ULL ] = ( int32_T ) (
t1838 != 0.0 ) ; t913 [ 2155ULL ] = 1 ; t913 [ 2156ULL ] = ( int32_T ) (
t1838 != 0.0 ) ; t913 [ 2157ULL ] = 1 ; t913 [ 2158ULL ] = ( int32_T ) (
t1847 * 0.002 != 0.0 ) ; t913 [ 2159ULL ] = 1 ; t913 [ 2160ULL ] = 1 ; t913 [
2161ULL ] = ( int32_T ) ( ( X [ 442ULL ] * X [ 442ULL ] +
5.1419576229038592E-12 == X [ 442ULL ] * X [ 442ULL ] +
5.1419576229038592E-12 ) && ( fabs ( X [ 442ULL ] * X [ 442ULL ] +
5.1419576229038592E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2162ULL ] = (
int32_T ) ( ( ! ( X [ 442ULL ] * X [ 442ULL ] + 5.1419576229038592E-12 == X [
442ULL ] * X [ 442ULL ] + 5.1419576229038592E-12 ) ) || ( ! ( fabs ( X [
442ULL ] * X [ 442ULL ] + 5.1419576229038592E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 442ULL ] * X [ 442ULL ] + 5.1419576229038592E-12 >= 0.0 ) ) ; t913 [
2163ULL ] = ( int32_T ) ( t1849 != 0.0 ) ; t913 [ 2164ULL ] = ( int32_T ) ( (
! ( t1849 != 0.0 ) ) || ( t1852 != 0.0 ) ) ; t913 [ 2165ULL ] = ( int32_T ) (
t1849 != 0.0 ) ; t913 [ 2166ULL ] = 1 ; t913 [ 2167ULL ] = ( int32_T ) (
t1849 != 0.0 ) ; t913 [ 2168ULL ] = 1 ; t913 [ 2169ULL ] = 1 ; t913 [ 2170ULL
] = 1 ; t913 [ 2171ULL ] = ( int32_T ) ( ( X [ 434ULL ] * X [ 434ULL ] +
5.1419576229038592E-12 == X [ 434ULL ] * X [ 434ULL ] +
5.1419576229038592E-12 ) && ( fabs ( X [ 434ULL ] * X [ 434ULL ] +
5.1419576229038592E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2172ULL ] = (
int32_T ) ( ( ! ( X [ 434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 == X [
434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 ) ) || ( ! ( fabs ( X [
434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 434ULL ] * X [ 434ULL ] + 5.1419576229038592E-12 >= 0.0 ) ) ; t913 [
2173ULL ] = ( int32_T ) ( t1853 != 0.0 ) ; t913 [ 2174ULL ] = ( int32_T ) ( (
! ( t1853 != 0.0 ) ) || ( t1854 != 0.0 ) ) ; t913 [ 2175ULL ] = ( int32_T ) (
t1853 != 0.0 ) ; t913 [ 2176ULL ] = 1 ; t913 [ 2177ULL ] = ( int32_T ) (
t1853 != 0.0 ) ; t913 [ 2178ULL ] = 1 ; t913 [ 2179ULL ] = ( int32_T ) (
t1855 != 0.0 ) ; t913 [ 2180ULL ] = ( int32_T ) ( t1848 != 0.0 ) ; t913 [
2181ULL ] = 1 ; t913 [ 2182ULL ] = 1 ; t913 [ 2183ULL ] = ( int32_T ) ( (
t1858 * t1858 + 1.2620262729050631E-10 == t1858 * t1858 +
1.2620262729050631E-10 ) && ( fabs ( t1858 * t1858 + 1.2620262729050631E-10 )
!= pmf_get_inf ( ) ) ) ; t913 [ 2184ULL ] = ( int32_T ) ( ( ! ( t1858 * t1858
+ 1.2620262729050631E-10 == t1858 * t1858 + 1.2620262729050631E-10 ) ) || ( !
( fabs ( t1858 * t1858 + 1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) || (
t1858 * t1858 + 1.2620262729050631E-10 >= 0.0 ) ) ; t913 [ 2185ULL ] = (
int32_T ) ( t1859 != 0.0 ) ; t913 [ 2186ULL ] = ( int32_T ) ( ( ! ( t1859 !=
0.0 ) ) || ( t1860 != 0.0 ) ) ; t913 [ 2187ULL ] = ( int32_T ) ( t1859 != 0.0
) ; t913 [ 2188ULL ] = 1 ; t913 [ 2189ULL ] = ( int32_T ) ( t1859 != 0.0 ) ;
t913 [ 2190ULL ] = 1 ; t913 [ 2191ULL ] = 1 ; t913 [ 2192ULL ] = 1 ; t913 [
2193ULL ] = ( int32_T ) ( ( t1858 * t1858 + 1.2620262729050631E-10 == t1858 *
t1858 + 1.2620262729050631E-10 ) && ( fabs ( t1858 * t1858 +
1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) ; t913 [ 2194ULL ] = (
int32_T ) ( ( ! ( t1858 * t1858 + 1.2620262729050631E-10 == t1858 * t1858 +
1.2620262729050631E-10 ) ) || ( ! ( fabs ( t1858 * t1858 +
1.2620262729050631E-10 ) != pmf_get_inf ( ) ) ) || ( t1858 * t1858 +
1.2620262729050631E-10 >= 0.0 ) ) ; t913 [ 2195ULL ] = ( int32_T ) ( t1859 !=
0.0 ) ; t913 [ 2196ULL ] = ( int32_T ) ( ( ! ( t1859 != 0.0 ) ) || ( t1861 !=
0.0 ) ) ; t913 [ 2197ULL ] = ( int32_T ) ( t1859 != 0.0 ) ; t913 [ 2198ULL ]
= 1 ; t913 [ 2199ULL ] = ( int32_T ) ( t1859 != 0.0 ) ; t913 [ 2200ULL ] = 1
; t913 [ 2201ULL ] = ( int32_T ) ( t1863 != 0.0 ) ; t913 [ 2202ULL ] = (
int32_T ) ( t1869 * 0.00093750000000000007 != 0.0 ) ; t913 [ 2203ULL ] = 1 ;
t913 [ 2204ULL ] = 1 ; t913 [ 2205ULL ] = ( int32_T ) ( ( t1858 * t1858 +
2.4102926357361849E-12 == t1858 * t1858 + 2.4102926357361849E-12 ) && ( fabs
( t1858 * t1858 + 2.4102926357361849E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
2206ULL ] = ( int32_T ) ( ( ! ( t1858 * t1858 + 2.4102926357361849E-12 ==
t1858 * t1858 + 2.4102926357361849E-12 ) ) || ( ! ( fabs ( t1858 * t1858 +
2.4102926357361849E-12 ) != pmf_get_inf ( ) ) ) || ( t1858 * t1858 +
2.4102926357361849E-12 >= 0.0 ) ) ; t913 [ 2207ULL ] = ( int32_T ) ( t1873 !=
0.0 ) ; t913 [ 2208ULL ] = ( int32_T ) ( ( ! ( t1873 != 0.0 ) ) || ( t1874 !=
0.0 ) ) ; t913 [ 2209ULL ] = ( int32_T ) ( t1873 != 0.0 ) ; t913 [ 2210ULL ]
= 1 ; t913 [ 2211ULL ] = ( int32_T ) ( t1873 != 0.0 ) ; t913 [ 2212ULL ] = 1
; t913 [ 2213ULL ] = 1 ; t913 [ 2214ULL ] = 1 ; t913 [ 2215ULL ] = ( int32_T
) ( ( X [ 442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 == X [ 442ULL ] *
X [ 442ULL ] + 2.4102926357361849E-12 ) && ( fabs ( X [ 442ULL ] * X [ 442ULL
] + 2.4102926357361849E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2216ULL ] = (
int32_T ) ( ( ! ( X [ 442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 == X [
442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 ) ) || ( ! ( fabs ( X [
442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 442ULL ] * X [ 442ULL ] + 2.4102926357361849E-12 >= 0.0 ) ) ; t913 [
2217ULL ] = ( int32_T ) ( t1875 != 0.0 ) ; t913 [ 2218ULL ] = ( int32_T ) ( (
! ( t1875 != 0.0 ) ) || ( t1876 != 0.0 ) ) ; t913 [ 2219ULL ] = ( int32_T ) (
t1875 != 0.0 ) ; t913 [ 2220ULL ] = 1 ; t913 [ 2221ULL ] = ( int32_T ) (
t1875 != 0.0 ) ; t913 [ 2222ULL ] = 1 ; t913 [ 2223ULL ] = ( int32_T ) (
t1877 != 0.0 ) ; t913 [ 2224ULL ] = ( int32_T ) ( t1870 != 0.0 ) ; t913 [
2225ULL ] = 1 ; t913 [ 2226ULL ] = 1 ; t913 [ 2227ULL ] = 1 ; t913 [ 2228ULL
] = 1 ; t913 [ 2229ULL ] = 1 ; t913 [ 2230ULL ] = 1 ; t913 [ 2231ULL ] = 1 ;
t913 [ 2232ULL ] = 1 ; t913 [ 2233ULL ] = ( int32_T ) ( X [ 32ULL ] != 0.0 )
; t913 [ 2234ULL ] = ( int32_T ) ( ( ! ( X [ 32ULL ] != 0.0 ) ) || ( (
0.003298697014679202 - 1.0 / ( X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) )
* 2416.0 < 663.67513503334737 ) ) ; t913 [ 2235ULL ] = 1 ; t913 [ 2236ULL ] =
1 ; t913 [ 2237ULL ] = 1 ; t913 [ 2238ULL ] = ( int32_T ) ( t1315 > 0.0 ) ;
t913 [ 2239ULL ] = ( int32_T ) ( ( ! ( t1315 > 0.0 ) ) || ( pmf_log ( t1315 )
- t915 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 2240ULL ] = ( int32_T ) (
t1887 != 0.0 ) ; t913 [ 2241ULL ] = ( int32_T ) ( t1323 > 0.0 ) ; t913 [
2242ULL ] = ( int32_T ) ( ( ! ( t1323 > 0.0 ) ) || ( pmf_log ( t1323 ) - t915
[ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 2243ULL ] = ( int32_T ) ( t1889 !=
0.0 ) ; t913 [ 2244ULL ] = ( int32_T ) ( ( ! ( t1315 > t1323 ) ) || ( t1884 *
X [ 32ULL ] * 0.001039307827269155 != 0.0 ) ) ; t913 [ 2245ULL ] = ( int32_T
) ( ( t1315 > t1323 ) || ( t1884 * X [ 32ULL ] * 0.001039307827269155 != 0.0
) ) ; t913 [ 2246ULL ] = ( int32_T ) ( ( ! ( X [ 32ULL ] != 0.0 ) ) || ( (
0.003298697014679202 - 1.0 / ( X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) )
* 1268.0 < 663.67513503334737 ) ) ; t913 [ 2247ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra40 != 0.0 ) ;
t913 [ 2248ULL ] = ( int32_T ) ( X [ 32ULL ] * 8.31446261815324 != 0.0 ) ;
t913 [ 2249ULL ] = 1 ; t913 [ 2250ULL ] = ( int32_T ) ( X [ 32ULL ] *
8.31446261815324 != 0.0 ) ; t913 [ 2251ULL ] = 1 ; t913 [ 2252ULL ] = 1 ;
t913 [ 2253ULL ] = ( int32_T ) ( ( ! ( t1882 >= 1.0 ) ) || ( t1882 > 0.0 ) )
; t913 [ 2254ULL ] = 1 ; t913 [ 2255ULL ] = ( int32_T ) ( ( ! ( t1882 <=
13986.0 ) ) || ( 1.0 - t1882 / 14000.0 > 0.0 ) ) ; t913 [ 2256ULL ] = 1 ;
t913 [ 2257ULL ] = 1 ; t913 [ 2258ULL ] = 1 ; t913 [ 2259ULL ] = 1 ; t913 [
2260ULL ] = ( int32_T ) ( t1330 >= 0.0 ) ; t913 [ 2261ULL ] = ( int32_T ) ( (
! ( t1330 >= 0.0 ) ) || ( t1881 != 0.0 ) ) ; t2779 = pmf_sqrt ( t1330 ) *
t1322 ; t913 [ 2262ULL ] = ( int32_T ) ( ( ! ( t1330 >= 0.0 ) ) || ( ( t1330
>= 0.0 ) && ( ! ( t1881 != 0.0 ) ) ) || ( t2779 / ( t1881 == 0.0 ? 1.0E-16 :
t1881 ) > 0.0 ) ) ; t913 [ 2263ULL ] = ( int32_T ) ( X [ 63ULL ] * t1892 !=
0.0 ) ; t913 [ 2264ULL ] = 1 ; t913 [ 2265ULL ] = ( int32_T ) ( ( ! ( 1.0 - X
[ 66ULL ] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 66ULL ] ) - 0.01 ) / 0.01 <
663.67513503334737 ) || ( 1.0 - X [ 66ULL ] >= 0.01 ) ) ; t913 [ 2266ULL ] =
1 ; t913 [ 2267ULL ] = ( int32_T ) ( t1890 != 0.0 ) ; t913 [ 2268ULL ] = (
int32_T ) ( X [ 64ULL ] * 100000.0 > 0.0 ) ; t913 [ 2269ULL ] = ( int32_T ) (
( ! ( X [ 64ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 64ULL ] * 100000.0
) - t916 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 2270ULL ] = 1 ; t913 [
2271ULL ] = ( int32_T ) ( ( ! ( t1894 >= 1.0 ) ) || ( ( t1894 - 1.0 ) *
461.523 + t1891 != 0.0 ) ) ; t913 [ 2272ULL ] = ( int32_T ) ( t1896 * 0.01 !=
0.0 ) ; t913 [ 2273ULL ] = 1 ; t913 [ 2274ULL ] = 1 ; t913 [ 2275ULL ] = 1 ;
t913 [ 2276ULL ] = 1 ; t913 [ 2277ULL ] = 1 ; t913 [ 2278ULL ] = 1 ; t913 [
2279ULL ] = ( int32_T ) ( X [ 64ULL ] != 0.0 ) ; t913 [ 2280ULL ] = 1 ; t913
[ 2281ULL ] = 1 ; t913 [ 2282ULL ] = 1 ; t913 [ 2283ULL ] = 1 ; t913 [
2284ULL ] = 1 ; t913 [ 2285ULL ] = ( int32_T ) ( ( X [ 478ULL ] * X [ 478ULL
] + 1.8324100759713822E-12 == X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2286ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 == X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [
2287ULL ] = 1 ; t913 [ 2288ULL ] = 1 ; t913 [ 2289ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [ 478ULL ] * X [ 478ULL
] + 2.0914103314136477E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2290ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [
2291ULL ] = 1 ; t913 [ 2292ULL ] = 1 ; t913 [ 2293ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [ 478ULL ] * X [ 478ULL
] + 1.4768645655431184E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2294ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [
2295ULL ] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ; t913 [ 2296ULL ] = ( int32_T
) ( X [ 489ULL ] != 0.0 ) ; t913 [ 2297ULL ] = 1 ; t913 [ 2298ULL ] = 1 ;
t913 [ 2299ULL ] = 1 ; t913 [ 2300ULL ] = ( int32_T ) ( t1909 - t1903 != 0.0
) ; t913 [ 2301ULL ] = 1 ; t913 [ 2302ULL ] = 1 ; t913 [ 2303ULL ] = (
int32_T ) ( ( t1905 * t1905 * 9.999999999999999E-14 + fabs ( X [ 488ULL ] *
t1910 * t1903 ) * 1.0E-9 == t1905 * t1905 * 9.999999999999999E-14 + fabs ( X
[ 488ULL ] * t1910 * t1903 ) * 1.0E-9 ) && ( fabs ( t1905 * t1905 *
9.999999999999999E-14 + fabs ( X [ 488ULL ] * t1910 * t1903 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 2304ULL ] = ( int32_T ) ( ( ! ( t1905 * t1905 *
9.999999999999999E-14 + fabs ( X [ 488ULL ] * t1910 * t1903 ) * 1.0E-9 ==
t1905 * t1905 * 9.999999999999999E-14 + fabs ( X [ 488ULL ] * t1910 * t1903 )
* 1.0E-9 ) ) || ( ! ( fabs ( t1905 * t1905 * 9.999999999999999E-14 + fabs ( X
[ 488ULL ] * t1910 * t1903 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) || ( t1905 *
t1905 * 9.999999999999999E-14 + fabs ( X [ 488ULL ] * t1910 * t1903 ) *
1.0E-9 >= 0.0 ) ) ; t913 [ 2305ULL ] = 1 ; t913 [ 2306ULL ] = 1 ; t913 [
2307ULL ] = ( int32_T ) ( t1903 != 0.0 ) ; t913 [ 2308ULL ] = ( int32_T ) ( (
! ( t1903 != 0.0 ) ) || ( X [ 488ULL ] != 0.0 ) ) ; t913 [ 2309ULL ] = 1 ;
t913 [ 2310ULL ] = ( int32_T ) ( ( ! ( t1903 != 0.0 ) ) || ( ( t1903 != 0.0 )
&& ( ! ( X [ 488ULL ] != 0.0 ) ) ) || ( fabs ( t2164 / ( t1903 == 0.0 ?
1.0E-16 : t1903 ) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) >= 0.0
) ) ; t913 [ 2311ULL ] = ( int32_T ) ( t1914 * 7.8539816339744827E-5 != 0.0 )
; t913 [ 2312ULL ] = ( int32_T ) ( X [ 67ULL ] * t1903 != 0.0 ) ; t913 [
2313ULL ] = ( int32_T ) ( t1921 * 1.5707963267948965E-8 != 0.0 ) ; t913 [
2314ULL ] = ( int32_T ) ( t1925 != 0.0 ) ; t913 [ 2315ULL ] = ( int32_T ) ( (
! ( t1925 != 0.0 ) ) || ( 6.9 / ( t1925 == 0.0 ? 1.0E-16 : t1925 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 2316ULL ] = 1 ; t913 [ 2317ULL ] =
1 ; t913 [ 2318ULL ] = ( int32_T ) ( ( ! ( t1925 != 0.0 ) ) || ( ( t1925 !=
0.0 ) && ( ! ( 6.9 / ( t1925 == 0.0 ? 1.0E-16 : t1925 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1925 == 0.0 ?
1.0E-16 : t1925 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1925 ==
0.0 ? 1.0E-16 : t1925 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2319ULL ] = ( int32_T ) ( t1921 * 1.2337005501361697E-10 != 0.0 ) ; t913 [
2320ULL ] = 1 ; t913 [ 2321ULL ] = 1 ; t913 [ 2322ULL ] = 1 ; t913 [ 2323ULL
] = 1 ; t913 [ 2324ULL ] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ; t913 [
2325ULL ] = ( int32_T ) ( X [ 494ULL ] != 0.0 ) ; t913 [ 2326ULL ] = 1 ; t913
[ 2327ULL ] = 1 ; t913 [ 2328ULL ] = 1 ; t913 [ 2329ULL ] = ( int32_T ) (
t1923 - t1903 != 0.0 ) ; t913 [ 2330ULL ] = 1 ; t913 [ 2331ULL ] = 1 ; t913 [
2332ULL ] = ( int32_T ) ( ( t1919 * t1919 * 9.999999999999999E-14 + fabs ( X
[ 493ULL ] * t1900 * t1903 ) * 1.0E-9 == t1919 * t1919 *
9.999999999999999E-14 + fabs ( X [ 493ULL ] * t1900 * t1903 ) * 1.0E-9 ) && (
fabs ( t1919 * t1919 * 9.999999999999999E-14 + fabs ( X [ 493ULL ] * t1900 *
t1903 ) * 1.0E-9 ) != pmf_get_inf ( ) ) ) ; t913 [ 2333ULL ] = ( int32_T ) (
( ! ( t1919 * t1919 * 9.999999999999999E-14 + fabs ( X [ 493ULL ] * t1900 *
t1903 ) * 1.0E-9 == t1919 * t1919 * 9.999999999999999E-14 + fabs ( X [ 493ULL
] * t1900 * t1903 ) * 1.0E-9 ) ) || ( ! ( fabs ( t1919 * t1919 *
9.999999999999999E-14 + fabs ( X [ 493ULL ] * t1900 * t1903 ) * 1.0E-9 ) !=
pmf_get_inf ( ) ) ) || ( t1919 * t1919 * 9.999999999999999E-14 + fabs ( X [
493ULL ] * t1900 * t1903 ) * 1.0E-9 >= 0.0 ) ) ; t913 [ 2334ULL ] = 1 ; t913
[ 2335ULL ] = 1 ; t913 [ 2336ULL ] = ( int32_T ) ( t1903 != 0.0 ) ; t913 [
2337ULL ] = ( int32_T ) ( ( ! ( t1903 != 0.0 ) ) || ( X [ 493ULL ] != 0.0 ) )
; t913 [ 2338ULL ] = 1 ; t913 [ 2339ULL ] = ( int32_T ) ( ( ! ( t1903 != 0.0
) ) || ( ( t1903 != 0.0 ) && ( ! ( X [ 493ULL ] != 0.0 ) ) ) || ( fabs (
t2184 / ( t1903 == 0.0 ? 1.0E-16 : t1903 ) / ( X [ 493ULL ] == 0.0 ? 1.0E-16
: X [ 493ULL ] ) ) >= 0.0 ) ) ; t913 [ 2340ULL ] = ( int32_T ) ( t1914 *
7.8539816339744827E-5 != 0.0 ) ; t913 [ 2341ULL ] = ( int32_T ) ( t1921 *
1.5707963267948965E-8 != 0.0 ) ; t913 [ 2342ULL ] = ( int32_T ) ( t1933 !=
0.0 ) ; t913 [ 2343ULL ] = ( int32_T ) ( ( ! ( t1933 != 0.0 ) ) || ( 6.9 / (
t1933 == 0.0 ? 1.0E-16 : t1933 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [
2344ULL ] = 1 ; t913 [ 2345ULL ] = 1 ; t913 [ 2346ULL ] = ( int32_T ) ( ( ! (
t1933 != 0.0 ) ) || ( ( t1933 != 0.0 ) && ( ! ( 6.9 / ( t1933 == 0.0 ?
1.0E-16 : t1933 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1933 == 0.0 ? 1.0E-16 : t1933 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1933 == 0.0 ? 1.0E-16 : t1933 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 2347ULL ] = ( int32_T ) ( t1921 * 1.2337005501361697E-10 !=
0.0 ) ; t913 [ 2348ULL ] = 1 ; t913 [ 2349ULL ] = 1 ; t913 [ 2350ULL ] = 1 ;
t913 [ 2351ULL ] = 1 ; t913 [ 2352ULL ] = ( int32_T ) ( t1915 != 0.0 ) ; t913
[ 2353ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M34 != 0.0 ) ;
t913 [ 2354ULL ] = 1 ; t913 [ 2355ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 69ULL
] >= - 0.1 ) ) || ( ( ( 1.0 - X [ 69ULL ] ) - 0.01 ) / 0.01 <
663.67513503334737 ) || ( 1.0 - X [ 69ULL ] >= 0.01 ) ) ; t913 [ 2356ULL ] =
1 ; t913 [ 2357ULL ] = ( int32_T ) ( t1930 != 0.0 ) ; t913 [ 2358ULL ] = (
int32_T ) ( X [ 68ULL ] * 100000.0 > 0.0 ) ; t913 [ 2359ULL ] = ( int32_T ) (
( ! ( X [ 68ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log ( X [ 68ULL ] * 100000.0
) - t141 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [ 2360ULL ] = 1 ; t913 [
2361ULL ] = ( int32_T ) ( ( ! ( t1934 >= 1.0 ) ) || ( ( t1934 - 1.0 ) *
461.523 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M12 !=
0.0 ) ) ; t913 [ 2362ULL ] = ( int32_T ) ( t1935 * 0.01 != 0.0 ) ; t913 [
2363ULL ] = 1 ; t913 [ 2364ULL ] = 1 ; t913 [ 2365ULL ] = 1 ; t913 [ 2366ULL
] = 1 ; t913 [ 2367ULL ] = ( int32_T ) ( t1938 != 0.0 ) ; t913 [ 2368ULL ] =
( int32_T ) ( t2199 / 2.0 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 2369ULL ]
= 1 ; t913 [ 2370ULL ] = ( int32_T ) ( t1913 != 0.0 ) ; t913 [ 2371ULL ] = (
int32_T ) ( ( ! ( t1913 != 0.0 ) ) || ( 6.9 / ( t1913 == 0.0 ? 1.0E-16 :
t1913 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 2372ULL ] = 1 ; t913 [
2373ULL ] = 1 ; t913 [ 2374ULL ] = ( int32_T ) ( ( ! ( t1913 != 0.0 ) ) || (
( t1913 != 0.0 ) && ( ! ( 6.9 / ( t1913 == 0.0 ? 1.0E-16 : t1913 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1913 == 0.0 ?
1.0E-16 : t1913 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1913 ==
0.0 ? 1.0E-16 : t1913 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2375ULL ] = ( int32_T ) ( ( t1942 / 8.0 == t1942 / 8.0 ) && ( fabs ( t1942 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2376ULL ] = ( int32_T ) ( ( ! ( t1942 /
8.0 == t1942 / 8.0 ) ) || ( ! ( fabs ( t1942 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1942 / 8.0 >= 0.0 ) ) ; t913 [ 2377ULL ] = 1 ; t913 [ 2378ULL ] = (
int32_T ) ( t1939 >= 0.0 ) ; t913 [ 2379ULL ] = ( int32_T ) ( ( ! ( t1942 /
8.0 == t1942 / 8.0 ) ) || ( ! ( fabs ( t1942 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1942 / 8.0 == t1942 / 8.0 ) && ( fabs ( t1942 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1942 / 8.0 >= 0.0 ) ) ) || ( ! ( t1939 >= 0.0 ) ) || ( (
pmf_pow ( t1939 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1942 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 2380ULL ] = 1 ; t913 [ 2381ULL ] = 1 ; t913 [
2382ULL ] = 1 ; t913 [ 2383ULL ] = 1 ; t913 [ 2384ULL ] = ( int32_T ) ( t2205
/ 2.0 != 0.0 ) ; t913 [ 2385ULL ] = 1 ; t2773 = t2205 / 2.0 ; t913 [ 2386ULL
] = ( int32_T ) ( ( ! ( t1937 > t2211 / 7.8539816339744827E-5 / ( t2773 ==
0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || ( t1937 != 0.0 ) ) ; t913 [ 2387ULL ] =
1 ; t913 [ 2388ULL ] = 1 ; t2773 = t2205 / 2.0 ; t913 [ 2389ULL ] = ( int32_T
) ( ( ! ( t1937 > t2211 / 7.8539816339744827E-5 / ( t2773 == 0.0 ? 1.0E-16 :
t2773 ) / 30.0 ) ) || ( ! ( t1937 != 0.0 ) ) || ( t2205 / 2.0 != 0.0 ) ) ;
t913 [ 2390ULL ] = ( int32_T ) ( - t1944 < 663.67513503334737 ) ; t913 [
2391ULL ] = ( int32_T ) ( intrm_sf_mf_1464 != 0.0 ) ; t913 [ 2392ULL ] = (
int32_T ) ( t2223 / 2.0 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 2393ULL ] =
1 ; t913 [ 2394ULL ] = ( int32_T ) ( t1912 != 0.0 ) ; t913 [ 2395ULL ] = (
int32_T ) ( ( ! ( t1912 != 0.0 ) ) || ( 6.9 / ( t1912 == 0.0 ? 1.0E-16 :
t1912 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 2396ULL ] = 1 ; t913 [
2397ULL ] = 1 ; t913 [ 2398ULL ] = ( int32_T ) ( ( ! ( t1912 != 0.0 ) ) || (
( t1912 != 0.0 ) && ( ! ( 6.9 / ( t1912 == 0.0 ? 1.0E-16 : t1912 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1912 == 0.0 ?
1.0E-16 : t1912 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1912 ==
0.0 ? 1.0E-16 : t1912 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2399ULL ] = ( int32_T ) ( ( t1948 / 8.0 == t1948 / 8.0 ) && ( fabs ( t1948 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2400ULL ] = ( int32_T ) ( ( ! ( t1948 /
8.0 == t1948 / 8.0 ) ) || ( ! ( fabs ( t1948 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1948 / 8.0 >= 0.0 ) ) ; t913 [ 2401ULL ] = 1 ; t913 [ 2402ULL ] = (
int32_T ) ( t1947 >= 0.0 ) ; t913 [ 2403ULL ] = ( int32_T ) ( ( ! ( t1948 /
8.0 == t1948 / 8.0 ) ) || ( ! ( fabs ( t1948 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1948 / 8.0 == t1948 / 8.0 ) && ( fabs ( t1948 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1948 / 8.0 >= 0.0 ) ) ) || ( ! ( t1947 >= 0.0 ) ) || ( (
pmf_pow ( t1947 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1948 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 2404ULL ] = 1 ; t913 [ 2405ULL ] = 1 ; t913 [
2406ULL ] = 1 ; t913 [ 2407ULL ] = 1 ; t913 [ 2408ULL ] = ( int32_T ) ( t2224
/ 2.0 != 0.0 ) ; t913 [ 2409ULL ] = 1 ; t2773 = t2224 / 2.0 ; t913 [ 2410ULL
] = ( int32_T ) ( ( ! ( t1945 > t2232 / 7.8539816339744827E-5 / ( t2773 ==
0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || ( t1945 != 0.0 ) ) ; t913 [ 2411ULL ] =
1 ; t913 [ 2412ULL ] = 1 ; t2773 = t2224 / 2.0 ; t913 [ 2413ULL ] = ( int32_T
) ( ( ! ( t1945 > t2232 / 7.8539816339744827E-5 / ( t2773 == 0.0 ? 1.0E-16 :
t2773 ) / 30.0 ) ) || ( ! ( t1945 != 0.0 ) ) || ( t2224 / 2.0 != 0.0 ) ) ;
t913 [ 2414ULL ] = ( int32_T ) ( - t1951 < 663.67513503334737 ) ; t913 [
2415ULL ] = 1 ; t913 [ 2416ULL ] = 1 ; t913 [ 2417ULL ] = ( int32_T ) ( t1899
!= 0.0 ) ; t913 [ 2418ULL ] = 1 ; t913 [ 2419ULL ] = 1 ; t913 [ 2420ULL ] = 1
; t913 [ 2421ULL ] = 1 ; t913 [ 2422ULL ] = 1 ; t913 [ 2423ULL ] = ( int32_T
) ( ( X [ 478ULL ] * X [ 478ULL ] + 2.0360111955237585E-13 == X [ 478ULL ] *
X [ 478ULL ] + 2.0360111955237585E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL
] + 2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2424ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 2.0360111955237585E-13 == X [
478ULL ] * X [ 478ULL ] + 2.0360111955237585E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 2.0360111955237585E-13 >= 0.0 ) ) ; t913 [
2425ULL ] = 1 ; t913 [ 2426ULL ] = 1 ; t913 [ 2427ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 == X [ 478ULL ] * X [ 478ULL
] + 2.3237892571262758E-14 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 2428ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 == X [
478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 2.3237892571262758E-14 >= 0.0 ) ) ; t913 [
2429ULL ] = 1 ; t913 [ 2430ULL ] = 1 ; t913 [ 2431ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 == X [ 478ULL ] * X [ 478ULL
] + 1.6409606283812424E-14 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 2432ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 == X [
478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 >= 0.0 ) ) ; t913 [
2433ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913 [ 2434ULL ] = 1 ; t913
[ 2435ULL ] = 1 ; t913 [ 2436ULL ] = 1 ; t913 [ 2437ULL ] = 1 ; t913 [
2438ULL ] = 1 ; t913 [ 2439ULL ] = ( int32_T ) ( ( X [ 492ULL ] * X [ 492ULL
] + 2.0360111955237585E-13 == X [ 492ULL ] * X [ 492ULL ] +
2.0360111955237585E-13 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2440ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 2.0360111955237585E-13 == X [
492ULL ] * X [ 492ULL ] + 2.0360111955237585E-13 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 2.0360111955237585E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 2.0360111955237585E-13 >= 0.0 ) ) ; t913 [
2441ULL ] = 1 ; t913 [ 2442ULL ] = 1 ; t913 [ 2443ULL ] = ( int32_T ) ( ( X [
492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 == X [ 492ULL ] * X [ 492ULL
] + 2.3237892571262758E-14 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 2444ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 == X [
492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 2.3237892571262758E-14 >= 0.0 ) ) ; t913 [
2445ULL ] = 1 ; t913 [ 2446ULL ] = 1 ; t913 [ 2447ULL ] = ( int32_T ) ( ( X [
492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 == X [ 492ULL ] * X [ 492ULL
] + 1.6409606283812424E-14 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ; t913 [ 2448ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 == X [
492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 1.6409606283812424E-14 >= 0.0 ) ) ; t913 [
2449ULL ] = ( int32_T ) ( X [ 506ULL ] * t1955 != 0.0 ) ; t913 [ 2450ULL ] =
( int32_T ) ( X [ 64ULL ] != 0.0 ) ; t913 [ 2451ULL ] = ( int32_T ) ( X [
506ULL ] != 0.0 ) ; t913 [ 2452ULL ] = ( int32_T ) ( t1899 != 0.0 ) ; t913 [
2453ULL ] = ( int32_T ) ( X [ 506ULL ] != 0.0 ) ; t913 [ 2454ULL ] = 1 ; t913
[ 2455ULL ] = ( int32_T ) ( ( ! ( - X [ 478ULL ] > 0.0 ) ) || ( t1941 != 0.0
) ) ; t913 [ 2456ULL ] = 1 ; t913 [ 2457ULL ] = 1 ; t913 [ 2458ULL ] = 1 ;
t913 [ 2459ULL ] = ( int32_T ) ( ( ! ( - X [ 478ULL ] > 0.0 ) ) || ( ! (
t1941 != 0.0 ) ) || ( t1956 != 0.0 ) ) ; t913 [ 2460ULL ] = 1 ; t913 [
2461ULL ] = ( int32_T ) ( ( ! ( - X [ 478ULL ] < 0.0 ) ) || ( - X [ 478ULL ]
> 0.0 ) || ( t1941 != 0.0 ) ) ; t913 [ 2462ULL ] = 1 ; t913 [ 2463ULL ] = 1 ;
t913 [ 2464ULL ] = 1 ; t913 [ 2465ULL ] = ( int32_T ) ( ( ! ( - X [ 478ULL ]
< 0.0 ) ) || ( ! ( t1941 != 0.0 ) ) || ( - X [ 478ULL ] > 0.0 ) || ( t1956 !=
0.0 ) ) ; t913 [ 2466ULL ] = 1 ; t913 [ 2467ULL ] = 1 ; t913 [ 2468ULL ] = (
int32_T ) ( t1960 != 0.0 ) ; t913 [ 2469ULL ] = 1 ; t913 [ 2470ULL ] = 1 ;
t913 [ 2471ULL ] = 1 ; t913 [ 2472ULL ] = 1 ; t913 [ 2473ULL ] = 1 ; t913 [
2474ULL ] = 1 ; t913 [ 2475ULL ] = 1 ; t913 [ 2476ULL ] = 1 ; t913 [ 2477ULL
] = 1 ; t913 [ 2478ULL ] = 1 ; t913 [ 2479ULL ] = ( int32_T ) ( t1958 - t1955
!= 0.0 ) ; t913 [ 2480ULL ] = 1 ; t913 [ 2481ULL ] = 1 ; t913 [ 2482ULL ] = (
int32_T ) ( t1955 != 0.0 ) ; t913 [ 2483ULL ] = ( int32_T ) ( ( ! ( t1955 !=
0.0 ) ) || ( X [ 506ULL ] != 0.0 ) ) ; t913 [ 2484ULL ] = 1 ; t913 [ 2485ULL
] = ( int32_T ) ( ( ! ( t1955 != 0.0 ) ) || ( ( t1955 != 0.0 ) && ( ! ( X [
506ULL ] != 0.0 ) ) ) || ( fabs ( t2255 / ( t1955 == 0.0 ? 1.0E-16 : t1955 )
/ ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) >= 0.0 ) ) ; t913 [
2486ULL ] = ( int32_T ) ( ( ! ( - X [ 478ULL ] >= 0.0 ) ) || ( t1953 != 0.0 )
) ; t913 [ 2487ULL ] = ( int32_T ) ( ( - X [ 478ULL ] >= 0.0 ) || ( t1953 !=
0.0 ) ) ; t913 [ 2488ULL ] = ( int32_T ) ( X [ 64ULL ] != 0.0 ) ; t913 [
2489ULL ] = 1 ; t913 [ 2490ULL ] = 1 ; t913 [ 2491ULL ] = 1 ; t913 [ 2492ULL
] = 1 ; t913 [ 2493ULL ] = 1 ; t913 [ 2494ULL ] = ( int32_T ) ( ( X [ 478ULL
] * X [ 478ULL ] + 1.8324100759713822E-12 == X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2495ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 == X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [
2496ULL ] = 1 ; t913 [ 2497ULL ] = 1 ; t913 [ 2498ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [ 478ULL ] * X [ 478ULL
] + 2.0914103314136477E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2499ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [
2500ULL ] = 1 ; t913 [ 2501ULL ] = 1 ; t913 [ 2502ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [ 478ULL ] * X [ 478ULL
] + 1.4768645655431184E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2503ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [
2504ULL ] = ( int32_T ) ( t1899 != 0.0 ) ; t913 [ 2505ULL ] = 1 ; t913 [
2506ULL ] = 1 ; t913 [ 2507ULL ] = 1 ; t913 [ 2508ULL ] = 1 ; t913 [ 2509ULL
] = 1 ; t913 [ 2510ULL ] = ( int32_T ) ( ( X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 == X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2511ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 == X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [
2512ULL ] = 1 ; t913 [ 2513ULL ] = 1 ; t913 [ 2514ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [ 478ULL ] * X [ 478ULL
] + 2.0914103314136477E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2515ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 == X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [
2516ULL ] = 1 ; t913 [ 2517ULL ] = 1 ; t913 [ 2518ULL ] = ( int32_T ) ( ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [ 478ULL ] * X [ 478ULL
] + 1.4768645655431184E-13 ) && ( fabs ( X [ 478ULL ] * X [ 478ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2519ULL ] = (
int32_T ) ( ( ! ( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 == X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [
478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [
2520ULL ] = ( int32_T ) ( t1952 != 0.0 ) ; t913 [ 2521ULL ] = 1 ; t913 [
2522ULL ] = ( int32_T ) ( ( ! ( t1952 != 0.0 ) ) || ( fabs ( t1956 * 2.0 / (
t1952 == 0.0 ? 1.0E-16 : t1952 ) ) >= 0.0 ) ) ; t913 [ 2523ULL ] = 1 ; t913 [
2524ULL ] = 1 ; t913 [ 2525ULL ] = 1 ; t913 [ 2526ULL ] = 1 ; t913 [ 2527ULL
] = 1 ; t913 [ 2528ULL ] = ( int32_T ) ( ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 == X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2529ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 == X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
2530ULL ] = 1 ; t913 [ 2531ULL ] = 1 ; t913 [ 2532ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [ 519ULL ] * X [ 519ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2533ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
2534ULL ] = 1 ; t913 [ 2535ULL ] = 1 ; t913 [ 2536ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [ 519ULL ] * X [ 519ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2537ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
2538ULL ] = ( int32_T ) ( intrm_sf_mf_1574 * 293.15 != 0.0 ) ; t913 [ 2539ULL
] = 1 ; t913 [ 2540ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 524ULL ] >= - 0.1 )
) || ( ( ( 1.0 - X [ 524ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || (
1.0 - X [ 524ULL ] >= 0.01 ) ) ; t913 [ 2541ULL ] = 1 ; t913 [ 2542ULL ] = 1
; t913 [ 2543ULL ] = 1 ; t913 [ 2544ULL ] = 1 ; t913 [ 2545ULL ] = 1 ; t913 [
2546ULL ] = 1 ; t913 [ 2547ULL ] = ( int32_T ) ( ( X [ 519ULL ] * X [ 519ULL
] + 2.7104677895120892E-12 == X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2548ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 == X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
2549ULL ] = 1 ; t913 [ 2550ULL ] = 1 ; t913 [ 2551ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [ 519ULL ] * X [ 519ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2552ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
2553ULL ] = 1 ; t913 [ 2554ULL ] = 1 ; t913 [ 2555ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [ 519ULL ] * X [ 519ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2556ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
2557ULL ] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 2558ULL ] = 1 ; t913
[ 2559ULL ] = 1 ; t913 [ 2560ULL ] = 1 ; t913 [ 2561ULL ] = 1 ; t913 [
2562ULL ] = 1 ; t913 [ 2563ULL ] = ( int32_T ) ( ( X [ 519ULL ] * X [ 519ULL
] + 2.7104677895120892E-12 == X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2564ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 == X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
2565ULL ] = 1 ; t913 [ 2566ULL ] = 1 ; t913 [ 2567ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [ 519ULL ] * X [ 519ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2568ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
2569ULL ] = 1 ; t913 [ 2570ULL ] = 1 ; t913 [ 2571ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [ 519ULL ] * X [ 519ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2572ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
2573ULL ] = 1 ; t913 [ 2574ULL ] = 1 ; t913 [ 2575ULL ] = 1 ; t913 [ 2576ULL
] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 2577ULL ] = 1 ; t913 [
2578ULL ] = 1 ; t913 [ 2579ULL ] = 1 ; t913 [ 2580ULL ] = ( int32_T ) ( X [
55ULL ] != 0.0 ) ; t913 [ 2581ULL ] = 1 ; t913 [ 2582ULL ] = 1 ; t913 [
2583ULL ] = 1 ; t913 [ 2584ULL ] = 1 ; t913 [ 2585ULL ] = 1 ; t913 [ 2586ULL
] = 1 ; t913 [ 2587ULL ] = ( int32_T ) ( X [ 71ULL ] * t1965 != 0.0 ) ; t913
[ 2588ULL ] = 1 ; t913 [ 2589ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 73ULL ] >=
- 0.1 ) ) || ( ( ( 1.0 - X [ 73ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 )
|| ( 1.0 - X [ 73ULL ] >= 0.01 ) ) ; t913 [ 2590ULL ] = 1 ; t913 [ 2591ULL ]
= ( int32_T ) ( t1959 != 0.0 ) ; t913 [ 2592ULL ] = ( int32_T ) ( X [ 55ULL ]
* 100000.0 > 0.0 ) ; t913 [ 2593ULL ] = ( int32_T ) ( ( ! ( X [ 55ULL ] *
100000.0 > 0.0 ) ) || ( pmf_log ( X [ 55ULL ] * 100000.0 ) - t150 [ 0ULL ] <
663.67513503334737 ) ) ; t913 [ 2594ULL ] = 1 ; t913 [ 2595ULL ] = ( int32_T
) ( ( ! ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 >=
1.0 ) ) || ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress26 - 1.0 ) *
461.523 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress12 !=
0.0 ) ) ; t913 [ 2596ULL ] = ( int32_T ) ( t1306 * 0.01 != 0.0 ) ; t913 [
2597ULL ] = 1 ; t913 [ 2598ULL ] = 1 ; t913 [ 2599ULL ] = 1 ; t913 [ 2600ULL
] = 1 ; t913 [ 2601ULL ] = 1 ; t913 [ 2602ULL ] = 1 ; t913 [ 2603ULL ] = (
int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 2604ULL ] = 1 ; t913 [ 2605ULL ] =
1 ; t913 [ 2606ULL ] = 1 ; t913 [ 2607ULL ] = 1 ; t913 [ 2608ULL ] = 1 ; t913
[ 2609ULL ] = ( int32_T ) ( ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 == X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2610ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 == X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
2611ULL ] = 1 ; t913 [ 2612ULL ] = 1 ; t913 [ 2613ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [ 519ULL ] * X [ 519ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2614ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 == X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
2615ULL ] = 1 ; t913 [ 2616ULL ] = 1 ; t913 [ 2617ULL ] = ( int32_T ) ( ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [ 519ULL ] * X [ 519ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 519ULL ] * X [ 519ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2618ULL ] = (
int32_T ) ( ( ! ( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 == X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 519ULL ] * X [ 519ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
2619ULL ] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 2620ULL ] = 1 ; t913
[ 2621ULL ] = 1 ; t913 [ 2622ULL ] = 1 ; t913 [ 2623ULL ] = 1 ; t913 [
2624ULL ] = 1 ; t913 [ 2625ULL ] = ( int32_T ) ( ( X [ 413ULL ] * X [ 413ULL
] + 2.7104677895120892E-12 == X [ 413ULL ] * X [ 413ULL ] +
2.7104677895120892E-12 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2626ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 2.7104677895120892E-12 == X [
413ULL ] * X [ 413ULL ] + 2.7104677895120892E-12 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 2.7104677895120892E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 2.7104677895120892E-12 >= 0.0 ) ) ; t913 [
2627ULL ] = 1 ; t913 [ 2628ULL ] = 1 ; t913 [ 2629ULL ] = ( int32_T ) ( ( X [
413ULL ] * X [ 413ULL ] + 5.2285258285341208E-12 == X [ 413ULL ] * X [ 413ULL
] + 5.2285258285341208E-12 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2630ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 5.2285258285341208E-12 == X [
413ULL ] * X [ 413ULL ] + 5.2285258285341208E-12 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 5.2285258285341208E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 5.2285258285341208E-12 >= 0.0 ) ) ; t913 [
2631ULL ] = 1 ; t913 [ 2632ULL ] = 1 ; t913 [ 2633ULL ] = ( int32_T ) ( ( X [
413ULL ] * X [ 413ULL ] + 3.6921614138577959E-12 == X [ 413ULL ] * X [ 413ULL
] + 3.6921614138577959E-12 ) && ( fabs ( X [ 413ULL ] * X [ 413ULL ] +
3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2634ULL ] = (
int32_T ) ( ( ! ( X [ 413ULL ] * X [ 413ULL ] + 3.6921614138577959E-12 == X [
413ULL ] * X [ 413ULL ] + 3.6921614138577959E-12 ) ) || ( ! ( fabs ( X [
413ULL ] * X [ 413ULL ] + 3.6921614138577959E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 413ULL ] * X [ 413ULL ] + 3.6921614138577959E-12 >= 0.0 ) ) ; t913 [
2635ULL ] = ( int32_T ) ( X [ 74ULL ] * t1972 != 0.0 ) ; t913 [ 2636ULL ] = 1
; t913 [ 2637ULL ] = ( int32_T ) ( ( ! ( 1.0 - X [ 76ULL ] >= - 0.1 ) ) || (
( ( 1.0 - X [ 76ULL ] ) - 0.01 ) / 0.01 < 663.67513503334737 ) || ( 1.0 - X [
76ULL ] >= 0.01 ) ) ; t913 [ 2638ULL ] = 1 ; t913 [ 2639ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant31 != 0.0 ) ;
t913 [ 2640ULL ] = ( int32_T ) ( X [ 38ULL ] * 100000.0 > 0.0 ) ; t913 [
2641ULL ] = ( int32_T ) ( ( ! ( X [ 38ULL ] * 100000.0 > 0.0 ) ) || ( pmf_log
( X [ 38ULL ] * 100000.0 ) - t914 [ 0ULL ] < 663.67513503334737 ) ) ; t913 [
2642ULL ] = 1 ; t913 [ 2643ULL ] = ( int32_T ) ( ( ! ( t1973 >= 1.0 ) ) || (
( t1973 - 1.0 ) * 461.523 + t1969 != 0.0 ) ) ; t913 [ 2644ULL ] = ( int32_T )
( t1974 * 0.01 != 0.0 ) ; t913 [ 2645ULL ] = 1 ; t913 [ 2646ULL ] = 1 ; t913
[ 2647ULL ] = 1 ; t913 [ 2648ULL ] = 1 ; t913 [ 2649ULL ] = 1 ; t913 [
2650ULL ] = 1 ; t913 [ 2651ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913
[ 2652ULL ] = 1 ; t913 [ 2653ULL ] = 1 ; t913 [ 2654ULL ] = 1 ; t913 [
2655ULL ] = 1 ; t913 [ 2656ULL ] = 1 ; t913 [ 2657ULL ] = ( int32_T ) ( ( X [
492ULL ] * X [ 492ULL ] + 1.8324100759713822E-12 == X [ 492ULL ] * X [ 492ULL
] + 1.8324100759713822E-12 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 2658ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 1.8324100759713822E-12 == X [
492ULL ] * X [ 492ULL ] + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [
2659ULL ] = 1 ; t913 [ 2660ULL ] = 1 ; t913 [ 2661ULL ] = ( int32_T ) ( ( X [
492ULL ] * X [ 492ULL ] + 2.0914103314136477E-13 == X [ 492ULL ] * X [ 492ULL
] + 2.0914103314136477E-13 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2662ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 2.0914103314136477E-13 == X [
492ULL ] * X [ 492ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [
2663ULL ] = 1 ; t913 [ 2664ULL ] = 1 ; t913 [ 2665ULL ] = ( int32_T ) ( ( X [
492ULL ] * X [ 492ULL ] + 1.4768645655431184E-13 == X [ 492ULL ] * X [ 492ULL
] + 1.4768645655431184E-13 ) && ( fabs ( X [ 492ULL ] * X [ 492ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2666ULL ] = (
int32_T ) ( ( ! ( X [ 492ULL ] * X [ 492ULL ] + 1.4768645655431184E-13 == X [
492ULL ] * X [ 492ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [
492ULL ] * X [ 492ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 492ULL ] * X [ 492ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [
2667ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913 [ 2668ULL ] = 1 ; t913
[ 2669ULL ] = 1 ; t913 [ 2670ULL ] = 1 ; t913 [ 2671ULL ] = 1 ; t913 [
2672ULL ] = 1 ; t913 [ 2673ULL ] = ( int32_T ) ( ( t1976 * t1976 +
1.8324100759713822E-12 == t1976 * t1976 + 1.8324100759713822E-12 ) && ( fabs
( t1976 * t1976 + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
2674ULL ] = ( int32_T ) ( ( ! ( t1976 * t1976 + 1.8324100759713822E-12 ==
t1976 * t1976 + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( t1976 * t1976 +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 2675ULL ] = 1 ; t913 [ 2676ULL ] =
1 ; t913 [ 2677ULL ] = ( int32_T ) ( ( t1976 * t1976 + 2.0914103314136477E-13
== t1976 * t1976 + 2.0914103314136477E-13 ) && ( fabs ( t1976 * t1976 +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2678ULL ] = (
int32_T ) ( ( ! ( t1976 * t1976 + 2.0914103314136477E-13 == t1976 * t1976 +
2.0914103314136477E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 2679ULL ] = 1 ; t913 [ 2680ULL ] =
1 ; t913 [ 2681ULL ] = ( int32_T ) ( ( t1976 * t1976 + 1.4768645655431184E-13
== t1976 * t1976 + 1.4768645655431184E-13 ) && ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2682ULL ] = (
int32_T ) ( ( ! ( t1976 * t1976 + 1.4768645655431184E-13 == t1976 * t1976 +
1.4768645655431184E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 2683ULL ] = ( int32_T ) ( X [
38ULL ] != 0.0 ) ; t913 [ 2684ULL ] = 1 ; t913 [ 2685ULL ] = 1 ; t913 [
2686ULL ] = 1 ; t913 [ 2687ULL ] = 1 ; t913 [ 2688ULL ] = 1 ; t913 [ 2689ULL
] = ( int32_T ) ( ( X [ 288ULL ] * X [ 288ULL ] + 1.8324100759713822E-12 == X
[ 288ULL ] * X [ 288ULL ] + 1.8324100759713822E-12 ) && ( fabs ( X [ 288ULL ]
* X [ 288ULL ] + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
2690ULL ] = ( int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] +
1.8324100759713822E-12 == X [ 288ULL ] * X [ 288ULL ] +
1.8324100759713822E-12 ) ) || ( ! ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( X [ 288ULL ] * X [
288ULL ] + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 2691ULL ] = 1 ; t913 [
2692ULL ] = 1 ; t913 [ 2693ULL ] = ( int32_T ) ( ( X [ 288ULL ] * X [ 288ULL
] + 2.0914103314136477E-13 == X [ 288ULL ] * X [ 288ULL ] +
2.0914103314136477E-13 ) && ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2694ULL ] = (
int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] + 2.0914103314136477E-13 == X [
288ULL ] * X [ 288ULL ] + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( X [
288ULL ] * X [ 288ULL ] + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 288ULL ] * X [ 288ULL ] + 2.0914103314136477E-13 >= 0.0 ) ) ; t913 [
2695ULL ] = 1 ; t913 [ 2696ULL ] = 1 ; t913 [ 2697ULL ] = ( int32_T ) ( ( X [
288ULL ] * X [ 288ULL ] + 1.4768645655431184E-13 == X [ 288ULL ] * X [ 288ULL
] + 1.4768645655431184E-13 ) && ( fabs ( X [ 288ULL ] * X [ 288ULL ] +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2698ULL ] = (
int32_T ) ( ( ! ( X [ 288ULL ] * X [ 288ULL ] + 1.4768645655431184E-13 == X [
288ULL ] * X [ 288ULL ] + 1.4768645655431184E-13 ) ) || ( ! ( fabs ( X [
288ULL ] * X [ 288ULL ] + 1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ||
( X [ 288ULL ] * X [ 288ULL ] + 1.4768645655431184E-13 >= 0.0 ) ) ; t913 [
2699ULL ] = ( int32_T ) ( X [ 176ULL ] != 0.0 ) ; t913 [ 2700ULL ] = 1 ; t913
[ 2701ULL ] = 1 ; t913 [ 2702ULL ] = 1 ; t913 [ 2703ULL ] = 1 ; t913 [
2704ULL ] = 1 ; t913 [ 2705ULL ] = ( int32_T ) ( ( t1976 * t1976 +
1.8324100759713822E-12 == t1976 * t1976 + 1.8324100759713822E-12 ) && ( fabs
( t1976 * t1976 + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) ; t913 [
2706ULL ] = ( int32_T ) ( ( ! ( t1976 * t1976 + 1.8324100759713822E-12 ==
t1976 * t1976 + 1.8324100759713822E-12 ) ) || ( ! ( fabs ( t1976 * t1976 +
1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 2707ULL ] = 1 ; t913 [ 2708ULL ] =
1 ; t913 [ 2709ULL ] = ( int32_T ) ( ( t1976 * t1976 + 2.0914103314136477E-13
== t1976 * t1976 + 2.0914103314136477E-13 ) && ( fabs ( t1976 * t1976 +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2710ULL ] = (
int32_T ) ( ( ! ( t1976 * t1976 + 2.0914103314136477E-13 == t1976 * t1976 +
2.0914103314136477E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 2711ULL ] = 1 ; t913 [ 2712ULL ] =
1 ; t913 [ 2713ULL ] = ( int32_T ) ( ( t1976 * t1976 + 1.4768645655431184E-13
== t1976 * t1976 + 1.4768645655431184E-13 ) && ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2714ULL ] = (
int32_T ) ( ( ! ( t1976 * t1976 + 1.4768645655431184E-13 == t1976 * t1976 +
1.4768645655431184E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 2715ULL ] = ( int32_T ) ( X [
38ULL ] != 0.0 ) ; t913 [ 2716ULL ] = 1 ; t913 [ 2717ULL ] = 1 ; t913 [
2718ULL ] = 1 ; t913 [ 2719ULL ] = 1 ; t913 [ 2720ULL ] = 1 ; t913 [ 2721ULL
] = ( int32_T ) ( ( t1976 * t1976 + 1.8324100759713822E-12 == t1976 * t1976 +
1.8324100759713822E-12 ) && ( fabs ( t1976 * t1976 + 1.8324100759713822E-12 )
!= pmf_get_inf ( ) ) ) ; t913 [ 2722ULL ] = ( int32_T ) ( ( ! ( t1976 * t1976
+ 1.8324100759713822E-12 == t1976 * t1976 + 1.8324100759713822E-12 ) ) || ( !
( fabs ( t1976 * t1976 + 1.8324100759713822E-12 ) != pmf_get_inf ( ) ) ) || (
t1976 * t1976 + 1.8324100759713822E-12 >= 0.0 ) ) ; t913 [ 2723ULL ] = 1 ;
t913 [ 2724ULL ] = 1 ; t913 [ 2725ULL ] = ( int32_T ) ( ( t1976 * t1976 +
2.0914103314136477E-13 == t1976 * t1976 + 2.0914103314136477E-13 ) && ( fabs
( t1976 * t1976 + 2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) ; t913 [
2726ULL ] = ( int32_T ) ( ( ! ( t1976 * t1976 + 2.0914103314136477E-13 ==
t1976 * t1976 + 2.0914103314136477E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
2.0914103314136477E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
2.0914103314136477E-13 >= 0.0 ) ) ; t913 [ 2727ULL ] = 1 ; t913 [ 2728ULL ] =
1 ; t913 [ 2729ULL ] = ( int32_T ) ( ( t1976 * t1976 + 1.4768645655431184E-13
== t1976 * t1976 + 1.4768645655431184E-13 ) && ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) ; t913 [ 2730ULL ] = (
int32_T ) ( ( ! ( t1976 * t1976 + 1.4768645655431184E-13 == t1976 * t1976 +
1.4768645655431184E-13 ) ) || ( ! ( fabs ( t1976 * t1976 +
1.4768645655431184E-13 ) != pmf_get_inf ( ) ) ) || ( t1976 * t1976 +
1.4768645655431184E-13 >= 0.0 ) ) ; t913 [ 2731ULL ] = ( int32_T ) ( X [
176ULL ] != 0.0 ) ; t913 [ 2732ULL ] = 1 ; t913 [ 2733ULL ] = 1 ; t913 [
2734ULL ] = 1 ; t913 [ 2735ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913
[ 2736ULL ] = 1 ; t913 [ 2737ULL ] = 1 ; t913 [ 2738ULL ] = 1 ; t913 [
2739ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913 [ 2740ULL ] = 1 ; t913
[ 2741ULL ] = 1 ; t913 [ 2742ULL ] = 1 ; t913 [ 2743ULL ] = ( int32_T ) ( X [
176ULL ] != 0.0 ) ; t913 [ 2744ULL ] = 1 ; t913 [ 2745ULL ] = 1 ; t913 [
2746ULL ] = 1 ; t913 [ 2747ULL ] = 1 ; t913 [ 2748ULL ] = 1 ; t913 [ 2749ULL
] = 1 ; t913 [ 2750ULL ] = 1 ; t913 [ 2751ULL ] = 1 ; t913 [ 2752ULL ] = 1 ;
t913 [ 2753ULL ] = ( int32_T ) ( t1416 * 7.8539816339744827E-5 != 0.0 ) ;
t913 [ 2754ULL ] = ( int32_T ) ( t1711 * 0.44 != 0.0 ) ; t913 [ 2755ULL ] = (
int32_T ) ( t1979 != 0.0 ) ; t913 [ 2756ULL ] = ( int32_T ) ( ( ! ( t1979 !=
0.0 ) ) || ( 6.9 / ( t1979 == 0.0 ? 1.0E-16 : t1979 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 2757ULL ] = 1 ; t913 [ 2758ULL ] =
1 ; t913 [ 2759ULL ] = ( int32_T ) ( ( ! ( t1979 != 0.0 ) ) || ( ( t1979 !=
0.0 ) && ( ! ( 6.9 / ( t1979 == 0.0 ? 1.0E-16 : t1979 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1979 == 0.0 ?
1.0E-16 : t1979 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1979 ==
0.0 ? 1.0E-16 : t1979 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2760ULL ] = ( int32_T ) ( t1715 * 0.003872 != 0.0 ) ; t913 [ 2761ULL ] = 1 ;
t913 [ 2762ULL ] = 1 ; t913 [ 2763ULL ] = 1 ; t913 [ 2764ULL ] = 1 ; t913 [
2765ULL ] = ( int32_T ) ( t1715 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
2766ULL ] = 1 ; t913 [ 2767ULL ] = 1 ; t913 [ 2768ULL ] = 1 ; t913 [ 2769ULL
] = 1 ; t913 [ 2770ULL ] = 1 ; t913 [ 2771ULL ] = ( int32_T ) ( t1765 * 0.44
!= 0.0 ) ; t913 [ 2772ULL ] = ( int32_T ) ( t1980 != 0.0 ) ; t913 [ 2773ULL ]
= ( int32_T ) ( ( ! ( t1980 != 0.0 ) ) || ( 6.9 / ( t1980 == 0.0 ? 1.0E-16 :
t1980 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 2774ULL ] = 1 ; t913 [
2775ULL ] = 1 ; t913 [ 2776ULL ] = ( int32_T ) ( ( ! ( t1980 != 0.0 ) ) || (
( t1980 != 0.0 ) && ( ! ( 6.9 / ( t1980 == 0.0 ? 1.0E-16 : t1980 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1980 == 0.0 ?
1.0E-16 : t1980 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1980 ==
0.0 ? 1.0E-16 : t1980 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2777ULL ] = ( int32_T ) ( t1771 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
2778ULL ] = ( int32_T ) ( t1771 * 0.003872 != 0.0 ) ; t913 [ 2779ULL ] = 1 ;
t913 [ 2780ULL ] = 1 ; t913 [ 2781ULL ] = 1 ; t913 [ 2782ULL ] = 1 ; t913 [
2783ULL ] = ( int32_T ) ( t1765 * 0.44 != 0.0 ) ; t913 [ 2784ULL ] = (
int32_T ) ( t1981 != 0.0 ) ; t913 [ 2785ULL ] = ( int32_T ) ( ( ! ( t1981 !=
0.0 ) ) || ( 6.9 / ( t1981 == 0.0 ? 1.0E-16 : t1981 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 2786ULL ] = 1 ; t913 [ 2787ULL ] =
1 ; t913 [ 2788ULL ] = ( int32_T ) ( ( ! ( t1981 != 0.0 ) ) || ( ( t1981 !=
0.0 ) && ( ! ( 6.9 / ( t1981 == 0.0 ? 1.0E-16 : t1981 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1981 == 0.0 ?
1.0E-16 : t1981 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1981 ==
0.0 ? 1.0E-16 : t1981 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2789ULL ] = ( int32_T ) ( t1771 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
2790ULL ] = ( int32_T ) ( t1771 * 0.003872 != 0.0 ) ; t913 [ 2791ULL ] = 1 ;
t913 [ 2792ULL ] = 1 ; t913 [ 2793ULL ] = 1 ; t913 [ 2794ULL ] = 1 ; t913 [
2795ULL ] = 1 ; t913 [ 2796ULL ] = 1 ; t913 [ 2797ULL ] = 1 ; t913 [ 2798ULL
] = 1 ; t913 [ 2799ULL ] = 1 ; t913 [ 2800ULL ] = ( int32_T ) ( t1978 != 0.0
) ; t913 [ 2801ULL ] = ( int32_T ) ( ( ! ( t1978 != 0.0 ) ) || ( 6.9 / (
t1978 == 0.0 ? 1.0E-16 : t1978 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [
2802ULL ] = 1 ; t913 [ 2803ULL ] = 1 ; t913 [ 2804ULL ] = ( int32_T ) ( ( ! (
t1978 != 0.0 ) ) || ( ( t1978 != 0.0 ) && ( ! ( 6.9 / ( t1978 == 0.0 ?
1.0E-16 : t1978 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1978 == 0.0 ? 1.0E-16 : t1978 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1978 == 0.0 ? 1.0E-16 : t1978 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 2805ULL ] = 1 ; t913 [ 2806ULL ] = 1 ; t913 [ 2807ULL ] = 1
; t913 [ 2808ULL ] = 1 ; t913 [ 2809ULL ] = 1 ; t913 [ 2810ULL ] = ( int32_T
) ( t1801 * 0.0019634954084936209 != 0.0 ) ; t913 [ 2811ULL ] = ( int32_T ) (
t1983 != 0.0 ) ; t913 [ 2812ULL ] = ( int32_T ) ( ( ! ( t1983 != 0.0 ) ) || (
6.9 / ( t1983 == 0.0 ? 1.0E-16 : t1983 ) + 2.8767404433520813E-5 > 0.0 ) ) ;
t913 [ 2813ULL ] = 1 ; t913 [ 2814ULL ] = 1 ; t913 [ 2815ULL ] = ( int32_T )
( ( ! ( t1983 != 0.0 ) ) || ( ( t1983 != 0.0 ) && ( ! ( 6.9 / ( t1983 == 0.0
? 1.0E-16 : t1983 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9
/ ( t1983 == 0.0 ? 1.0E-16 : t1983 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1983 == 0.0 ? 1.0E-16 : t1983 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 2816ULL ] = ( int32_T ) ( t1809 * 9.8174770424681068E-6 !=
0.0 ) ; t913 [ 2817ULL ] = ( int32_T ) ( t1809 * 3.855314219175531E-7 != 0.0
) ; t913 [ 2818ULL ] = 1 ; t913 [ 2819ULL ] = 1 ; t913 [ 2820ULL ] = 1 ; t913
[ 2821ULL ] = 1 ; t913 [ 2822ULL ] = 1 ; t913 [ 2823ULL ] = ( int32_T ) (
t1801 * 0.0019634954084936209 != 0.0 ) ; t913 [ 2824ULL ] = ( int32_T ) (
t1984 != 0.0 ) ; t913 [ 2825ULL ] = ( int32_T ) ( ( ! ( t1984 != 0.0 ) ) || (
6.9 / ( t1984 == 0.0 ? 1.0E-16 : t1984 ) + 2.8767404433520813E-5 > 0.0 ) ) ;
t913 [ 2826ULL ] = 1 ; t913 [ 2827ULL ] = 1 ; t913 [ 2828ULL ] = ( int32_T )
( ( ! ( t1984 != 0.0 ) ) || ( ( t1984 != 0.0 ) && ( ! ( 6.9 / ( t1984 == 0.0
? 1.0E-16 : t1984 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9
/ ( t1984 == 0.0 ? 1.0E-16 : t1984 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1984 == 0.0 ? 1.0E-16 : t1984 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 2829ULL ] = ( int32_T ) ( t1809 * 9.8174770424681068E-6 !=
0.0 ) ; t913 [ 2830ULL ] = ( int32_T ) ( t1809 * 3.855314219175531E-7 != 0.0
) ; t913 [ 2831ULL ] = 1 ; t913 [ 2832ULL ] = 1 ; t913 [ 2833ULL ] = 1 ; t913
[ 2834ULL ] = 1 ; t913 [ 2835ULL ] = ( int32_T ) ( t2070 / 2.0 * 0.002 != 0.0
) ; t913 [ 2836ULL ] = 1 ; t913 [ 2837ULL ] = ( int32_T ) ( t1856 != 0.0 ) ;
t913 [ 2838ULL ] = ( int32_T ) ( ( ! ( t1856 != 0.0 ) ) || ( 6.9 / ( t1856 ==
0.0 ? 1.0E-16 : t1856 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 2839ULL ]
= 1 ; t913 [ 2840ULL ] = 1 ; t913 [ 2841ULL ] = ( int32_T ) ( ( ! ( t1856 !=
0.0 ) ) || ( ( t1856 != 0.0 ) && ( ! ( 6.9 / ( t1856 == 0.0 ? 1.0E-16 : t1856
) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1856 == 0.0
? 1.0E-16 : t1856 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1856 ==
0.0 ? 1.0E-16 : t1856 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2842ULL ] = ( int32_T ) ( ( t1987 / 8.0 == t1987 / 8.0 ) && ( fabs ( t1987 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2843ULL ] = ( int32_T ) ( ( ! ( t1987 /
8.0 == t1987 / 8.0 ) ) || ( ! ( fabs ( t1987 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1987 / 8.0 >= 0.0 ) ) ; t913 [ 2844ULL ] = 1 ; t913 [ 2845ULL ] = (
int32_T ) ( t1985 >= 0.0 ) ; t913 [ 2846ULL ] = ( int32_T ) ( ( ! ( t1987 /
8.0 == t1987 / 8.0 ) ) || ( ! ( fabs ( t1987 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( ( t1987 / 8.0 == t1987 / 8.0 ) && ( fabs ( t1987 / 8.0 ) != pmf_get_inf
( ) ) && ( ! ( t1987 / 8.0 >= 0.0 ) ) ) || ( ! ( t1985 >= 0.0 ) ) || ( (
pmf_pow ( t1985 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1987 / 8.0 ) *
12.7 + 1.0 != 0.0 ) ) ; t913 [ 2847ULL ] = 1 ; t913 [ 2848ULL ] = 1 ; t913 [
2849ULL ] = 1 ; t913 [ 2850ULL ] = 1 ; t913 [ 2851ULL ] = ( int32_T ) ( t2274
/ 2.0 != 0.0 ) ; t913 [ 2852ULL ] = 1 ; t2773 = t2274 / 2.0 ; t913 [ 2853ULL
] = ( int32_T ) ( ( ! ( intrm_sf_mf_1280 > t2282 / 0.002 / ( t2773 == 0.0 ?
1.0E-16 : t2773 ) / 30.0 ) ) || ( intrm_sf_mf_1280 != 0.0 ) ) ; t913 [
2854ULL ] = 1 ; t913 [ 2855ULL ] = 1 ; t2773 = t2274 / 2.0 ; t913 [ 2856ULL ]
= ( int32_T ) ( ( ! ( intrm_sf_mf_1280 > t2282 / 0.002 / ( t2773 == 0.0 ?
1.0E-16 : t2773 ) / 30.0 ) ) || ( ! ( intrm_sf_mf_1280 != 0.0 ) ) || ( t2274
/ 2.0 != 0.0 ) ) ; t913 [ 2857ULL ] = ( int32_T ) ( - t1989 <
663.67513503334737 ) ; t913 [ 2858ULL ] = ( int32_T ) ( t2295 / 2.0 * 0.002
!= 0.0 ) ; t913 [ 2859ULL ] = 1 ; t913 [ 2860ULL ] = ( int32_T ) ( t1842 !=
0.0 ) ; t913 [ 2861ULL ] = ( int32_T ) ( ( ! ( t1842 != 0.0 ) ) || ( 6.9 / (
t1842 == 0.0 ? 1.0E-16 : t1842 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [
2862ULL ] = 1 ; t913 [ 2863ULL ] = 1 ; t913 [ 2864ULL ] = ( int32_T ) ( ( ! (
t1842 != 0.0 ) ) || ( ( t1842 != 0.0 ) && ( ! ( 6.9 / ( t1842 == 0.0 ?
1.0E-16 : t1842 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1842 == 0.0 ? 1.0E-16 : t1842 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1842 == 0.0 ? 1.0E-16 : t1842 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 2865ULL ] = ( int32_T ) ( ( t1990 / 8.0 == t1990 / 8.0 ) &&
( fabs ( t1990 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2866ULL ] = ( int32_T
) ( ( ! ( t1990 / 8.0 == t1990 / 8.0 ) ) || ( ! ( fabs ( t1990 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( t1990 / 8.0 >= 0.0 ) ) ; t913 [ 2867ULL ] = 1 ; t913
[ 2868ULL ] = ( int32_T ) ( t1857 >= 0.0 ) ; t913 [ 2869ULL ] = ( int32_T ) (
( ! ( t1990 / 8.0 == t1990 / 8.0 ) ) || ( ! ( fabs ( t1990 / 8.0 ) !=
pmf_get_inf ( ) ) ) || ( ( t1990 / 8.0 == t1990 / 8.0 ) && ( fabs ( t1990 /
8.0 ) != pmf_get_inf ( ) ) && ( ! ( t1990 / 8.0 >= 0.0 ) ) ) || ( ! ( t1857
>= 0.0 ) ) || ( ( pmf_pow ( t1857 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt
( t1990 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 2870ULL ] = 1 ; t913 [
2871ULL ] = 1 ; t913 [ 2872ULL ] = 1 ; t913 [ 2873ULL ] = 1 ; t913 [ 2874ULL
] = ( int32_T ) ( t1415 * 1.5707963267948965E-8 != 0.0 ) ; t913 [ 2875ULL ] =
( int32_T ) ( t2298 / 2.0 != 0.0 ) ; t913 [ 2876ULL ] = 1 ; t2773 = t2298 /
2.0 ; t913 [ 2877ULL ] = ( int32_T ) ( ( ! ( t1846 > t2303 / 0.002 / ( t2773
== 0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || ( t1846 != 0.0 ) ) ; t913 [ 2878ULL
] = 1 ; t913 [ 2879ULL ] = 1 ; t2773 = t2298 / 2.0 ; t913 [ 2880ULL ] = (
int32_T ) ( ( ! ( t1846 > t2303 / 0.002 / ( t2773 == 0.0 ? 1.0E-16 : t2773 )
/ 30.0 ) ) || ( ! ( t1846 != 0.0 ) ) || ( t2298 / 2.0 != 0.0 ) ) ; t913 [
2881ULL ] = ( int32_T ) ( - intrm_sf_mf_1300 < 663.67513503334737 ) ; t913 [
2882ULL ] = 1 ; t913 [ 2883ULL ] = 1 ; t913 [ 2884ULL ] = 1 ; t913 [ 2885ULL
] = 1 ; t913 [ 2886ULL ] = 1 ; t913 [ 2887ULL ] = ( int32_T ) ( t1847 * 0.002
!= 0.0 ) ; t913 [ 2888ULL ] = ( int32_T ) ( t1845 != 0.0 ) ; t913 [ 2889ULL ]
= ( int32_T ) ( ( ! ( t1845 != 0.0 ) ) || ( 6.9 / ( t1845 == 0.0 ? 1.0E-16 :
t1845 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 2890ULL ] = 1 ; t913 [
2891ULL ] = 1 ; t913 [ 2892ULL ] = ( int32_T ) ( ( ! ( t1845 != 0.0 ) ) || (
( t1845 != 0.0 ) && ( ! ( 6.9 / ( t1845 == 0.0 ? 1.0E-16 : t1845 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1845 == 0.0 ?
1.0E-16 : t1845 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1845 ==
0.0 ? 1.0E-16 : t1845 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2893ULL ] = ( int32_T ) ( t1855 * 4.0000000000000003E-7 != 0.0 ) ; t913 [
2894ULL ] = ( int32_T ) ( t1855 * 8.0E-8 != 0.0 ) ; t913 [ 2895ULL ] = 1 ;
t913 [ 2896ULL ] = 1 ; t913 [ 2897ULL ] = 1 ; t913 [ 2898ULL ] = 1 ; t913 [
2899ULL ] = ( int32_T ) ( t1847 * 0.002 != 0.0 ) ; t913 [ 2900ULL ] = (
int32_T ) ( t1993 != 0.0 ) ; t913 [ 2901ULL ] = ( int32_T ) ( ( ! ( t1993 !=
0.0 ) ) || ( 6.9 / ( t1993 == 0.0 ? 1.0E-16 : t1993 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 2902ULL ] = 1 ; t913 [ 2903ULL ] =
1 ; t913 [ 2904ULL ] = ( int32_T ) ( ( ! ( t1993 != 0.0 ) ) || ( ( t1993 !=
0.0 ) && ( ! ( 6.9 / ( t1993 == 0.0 ? 1.0E-16 : t1993 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1993 == 0.0 ?
1.0E-16 : t1993 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1993 ==
0.0 ? 1.0E-16 : t1993 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
2905ULL ] = ( int32_T ) ( t1855 * 4.0000000000000003E-7 != 0.0 ) ; t913 [
2906ULL ] = ( int32_T ) ( t1855 * 8.0E-8 != 0.0 ) ; t913 [ 2907ULL ] = 1 ;
t913 [ 2908ULL ] = 1 ; t913 [ 2909ULL ] = 1 ; t913 [ 2910ULL ] = 1 ; t913 [
2911ULL ] = ( int32_T ) ( t2316 / 2.0 * 0.00093750000000000007 != 0.0 ) ;
t913 [ 2912ULL ] = 1 ; t913 [ 2913ULL ] = ( int32_T ) ( t1843 != 0.0 ) ; t913
[ 2914ULL ] = ( int32_T ) ( ( ! ( t1843 != 0.0 ) ) || ( 6.9 / ( t1843 == 0.0
? 1.0E-16 : t1843 ) + 0.00069701528436089772 > 0.0 ) ) ; t913 [ 2915ULL ] = 1
; t913 [ 2916ULL ] = 1 ; t913 [ 2917ULL ] = ( int32_T ) ( ( ! ( t1843 != 0.0
) ) || ( ( t1843 != 0.0 ) && ( ! ( 6.9 / ( t1843 == 0.0 ? 1.0E-16 : t1843 ) +
0.00069701528436089772 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1843 == 0.0 ?
1.0E-16 : t1843 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1843 ==
0.0 ? 1.0E-16 : t1843 ) + 0.00069701528436089772 ) * 3.24 != 0.0 ) ) ; t913 [
2918ULL ] = ( int32_T ) ( ( t1995 / 8.0 == t1995 / 8.0 ) && ( fabs ( t1995 /
8.0 ) != pmf_get_inf ( ) ) ) ; t913 [ 2919ULL ] = ( int32_T ) ( ( ! ( t1995 /
8.0 == t1995 / 8.0 ) ) || ( ! ( fabs ( t1995 / 8.0 ) != pmf_get_inf ( ) ) )
|| ( t1995 / 8.0 >= 0.0 ) ) ; t913 [ 2920ULL ] = 1 ; t913 [ 2921ULL ] = (
int32_T ) ( intrm_sf_mf_1327 >= 0.0 ) ; t913 [ 2922ULL ] = ( int32_T ) ( ( !
( t1995 / 8.0 == t1995 / 8.0 ) ) || ( ! ( fabs ( t1995 / 8.0 ) != pmf_get_inf
( ) ) ) || ( ( t1995 / 8.0 == t1995 / 8.0 ) && ( fabs ( t1995 / 8.0 ) !=
pmf_get_inf ( ) ) && ( ! ( t1995 / 8.0 >= 0.0 ) ) ) || ( ! ( intrm_sf_mf_1327
>= 0.0 ) ) || ( ( pmf_pow ( intrm_sf_mf_1327 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( t1995 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 2923ULL ] = 1 ;
t913 [ 2924ULL ] = 1 ; t913 [ 2925ULL ] = 1 ; t913 [ 2926ULL ] = 1 ; t913 [
2927ULL ] = ( int32_T ) ( t2319 / 2.0 != 0.0 ) ; t913 [ 2928ULL ] = 1 ; t2773
= t2319 / 2.0 ; t913 [ 2929ULL ] = ( int32_T ) ( ( ! ( t1878 > t2327 /
0.00093750000000000007 / ( t2773 == 0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || (
t1878 != 0.0 ) ) ; t913 [ 2930ULL ] = 1 ; t913 [ 2931ULL ] = 1 ; t2773 =
t2319 / 2.0 ; t913 [ 2932ULL ] = ( int32_T ) ( ( ! ( t1878 > t2327 /
0.00093750000000000007 / ( t2773 == 0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || ( !
( t1878 != 0.0 ) ) || ( t2319 / 2.0 != 0.0 ) ) ; t913 [ 2933ULL ] = ( int32_T
) ( - t1996 < 663.67513503334737 ) ; t913 [ 2934ULL ] = ( int32_T ) ( t2337 /
2.0 * 0.00093750000000000007 != 0.0 ) ; t913 [ 2935ULL ] = 1 ; t913 [ 2936ULL
] = ( int32_T ) ( t1864 != 0.0 ) ; t913 [ 2937ULL ] = ( int32_T ) ( ( ! (
t1864 != 0.0 ) ) || ( 6.9 / ( t1864 == 0.0 ? 1.0E-16 : t1864 ) +
0.00069701528436089772 > 0.0 ) ) ; t913 [ 2938ULL ] = 1 ; t913 [ 2939ULL ] =
1 ; t913 [ 2940ULL ] = ( int32_T ) ( ( ! ( t1864 != 0.0 ) ) || ( ( t1864 !=
0.0 ) && ( ! ( 6.9 / ( t1864 == 0.0 ? 1.0E-16 : t1864 ) +
0.00069701528436089772 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1864 == 0.0 ?
1.0E-16 : t1864 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1864 ==
0.0 ? 1.0E-16 : t1864 ) + 0.00069701528436089772 ) * 3.24 != 0.0 ) ) ; t913 [
2941ULL ] = ( int32_T ) ( ( intrm_sf_mf_1340 / 8.0 == intrm_sf_mf_1340 / 8.0
) && ( fabs ( intrm_sf_mf_1340 / 8.0 ) != pmf_get_inf ( ) ) ) ; t913 [
2942ULL ] = ( int32_T ) ( ( ! ( intrm_sf_mf_1340 / 8.0 == intrm_sf_mf_1340 /
8.0 ) ) || ( ! ( fabs ( intrm_sf_mf_1340 / 8.0 ) != pmf_get_inf ( ) ) ) || (
intrm_sf_mf_1340 / 8.0 >= 0.0 ) ) ; t913 [ 2943ULL ] = 1 ; t913 [ 2944ULL ] =
( int32_T ) ( t1879 >= 0.0 ) ; t913 [ 2945ULL ] = ( int32_T ) ( ( ! (
intrm_sf_mf_1340 / 8.0 == intrm_sf_mf_1340 / 8.0 ) ) || ( ! ( fabs (
intrm_sf_mf_1340 / 8.0 ) != pmf_get_inf ( ) ) ) || ( ( intrm_sf_mf_1340 / 8.0
== intrm_sf_mf_1340 / 8.0 ) && ( fabs ( intrm_sf_mf_1340 / 8.0 ) !=
pmf_get_inf ( ) ) && ( ! ( intrm_sf_mf_1340 / 8.0 >= 0.0 ) ) ) || ( ! ( t1879
>= 0.0 ) ) || ( ( pmf_pow ( t1879 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt
( intrm_sf_mf_1340 / 8.0 ) * 12.7 + 1.0 != 0.0 ) ) ; t913 [ 2946ULL ] = 1 ;
t913 [ 2947ULL ] = 1 ; t913 [ 2948ULL ] = 1 ; t913 [ 2949ULL ] = 1 ; t913 [
2950ULL ] = ( int32_T ) ( t2340 / 2.0 != 0.0 ) ; t913 [ 2951ULL ] = 1 ; t2773
= t2340 / 2.0 ; t913 [ 2952ULL ] = ( int32_T ) ( ( ! ( t1868 > t2343 /
0.00093750000000000007 / ( t2773 == 0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || (
t1868 != 0.0 ) ) ; t913 [ 2953ULL ] = 1 ; t913 [ 2954ULL ] = 1 ; t2773 =
t2340 / 2.0 ; t913 [ 2955ULL ] = ( int32_T ) ( ( ! ( t1868 > t2343 /
0.00093750000000000007 / ( t2773 == 0.0 ? 1.0E-16 : t2773 ) / 30.0 ) ) || ( !
( t1868 != 0.0 ) ) || ( t2340 / 2.0 != 0.0 ) ) ; t913 [ 2956ULL ] = ( int32_T
) ( - t1998 < 663.67513503334737 ) ; t913 [ 2957ULL ] = 1 ; t913 [ 2958ULL ]
= 1 ; t913 [ 2959ULL ] = 1 ; t913 [ 2960ULL ] = 1 ; t913 [ 2961ULL ] = 1 ;
t913 [ 2962ULL ] = ( int32_T ) ( t1869 * 0.00093750000000000007 != 0.0 ) ;
t913 [ 2963ULL ] = ( int32_T ) ( t1867 != 0.0 ) ; t913 [ 2964ULL ] = (
int32_T ) ( ( ! ( t1867 != 0.0 ) ) || ( 6.9 / ( t1867 == 0.0 ? 1.0E-16 :
t1867 ) + 0.00069701528436089772 > 0.0 ) ) ; t913 [ 2965ULL ] = 1 ; t913 [
2966ULL ] = 1 ; t913 [ 2967ULL ] = ( int32_T ) ( ( ! ( t1867 != 0.0 ) ) || (
( t1867 != 0.0 ) && ( ! ( 6.9 / ( t1867 == 0.0 ? 1.0E-16 : t1867 ) +
0.00069701528436089772 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1867 == 0.0 ?
1.0E-16 : t1867 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1867 ==
0.0 ? 1.0E-16 : t1867 ) + 0.00069701528436089772 ) * 3.24 != 0.0 ) ) ; t913 [
2968ULL ] = ( int32_T ) ( t1877 * 1.50186899252403E-8 != 0.0 ) ; t913 [
2969ULL ] = ( int32_T ) ( t1877 * 4.97494103773585E-9 != 0.0 ) ; t913 [
2970ULL ] = 1 ; t913 [ 2971ULL ] = 1 ; t913 [ 2972ULL ] = 1 ; t913 [ 2973ULL
] = 1 ; t913 [ 2974ULL ] = ( int32_T ) ( t1869 * 0.00093750000000000007 !=
0.0 ) ; t913 [ 2975ULL ] = ( int32_T ) ( t1999 != 0.0 ) ; t913 [ 2976ULL ] =
( int32_T ) ( ( ! ( t1999 != 0.0 ) ) || ( 6.9 / ( t1999 == 0.0 ? 1.0E-16 :
t1999 ) + 0.00069701528436089772 > 0.0 ) ) ; t913 [ 2977ULL ] = 1 ; t913 [
2978ULL ] = 1 ; t913 [ 2979ULL ] = ( int32_T ) ( ( ! ( t1999 != 0.0 ) ) || (
( t1999 != 0.0 ) && ( ! ( 6.9 / ( t1999 == 0.0 ? 1.0E-16 : t1999 ) +
0.00069701528436089772 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1999 == 0.0 ?
1.0E-16 : t1999 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1999 ==
0.0 ? 1.0E-16 : t1999 ) + 0.00069701528436089772 ) * 3.24 != 0.0 ) ) ; t913 [
2980ULL ] = ( int32_T ) ( t1877 * 1.50186899252403E-8 != 0.0 ) ; t913 [
2981ULL ] = ( int32_T ) ( t1877 * 4.97494103773585E-9 != 0.0 ) ; t913 [
2982ULL ] = 1 ; t913 [ 2983ULL ] = 1 ; t913 [ 2984ULL ] = 1 ; t913 [ 2985ULL
] = 1 ; t913 [ 2986ULL ] = 1 ; t913 [ 2987ULL ] = 1 ; t913 [ 2988ULL ] = 1 ;
t913 [ 2989ULL ] = 1 ; t913 [ 2990ULL ] = 1 ; t913 [ 2991ULL ] = 1 ; t913 [
2992ULL ] = 1 ; t913 [ 2993ULL ] = 1 ; t913 [ 2994ULL ] = ( int32_T ) ( t1415
* 1.2337005501361696E-8 != 0.0 ) ; t913 [ 2995ULL ] = 1 ; t913 [ 2996ULL ] =
1 ; t913 [ 2997ULL ] = 1 ; t913 [ 2998ULL ] = 1 ; t913 [ 2999ULL ] = 1 ; t913
[ 3000ULL ] = ( int32_T ) ( t1914 * 7.8539816339744827E-5 != 0.0 ) ; t913 [
3001ULL ] = ( int32_T ) ( t1098_idx_0 != 0.0 ) ; t913 [ 3002ULL ] = ( int32_T
) ( ( ! ( t1098_idx_0 != 0.0 ) ) || ( 6.9 / ( t1098_idx_0 == 0.0 ? 1.0E-16 :
t1098_idx_0 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3003ULL ] = 1 ;
t913 [ 3004ULL ] = 1 ; t913 [ 3005ULL ] = ( int32_T ) ( ( ! ( t1098_idx_0 !=
0.0 ) ) || ( ( t1098_idx_0 != 0.0 ) && ( ! ( 6.9 / ( t1098_idx_0 == 0.0 ?
1.0E-16 : t1098_idx_0 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 (
6.9 / ( t1098_idx_0 == 0.0 ? 1.0E-16 : t1098_idx_0 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1098_idx_0 == 0.0 ? 1.0E-16 : t1098_idx_0 ) +
0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 3006ULL ] = ( int32_T ) (
t1921 * 1.5707963267948965E-8 != 0.0 ) ; t913 [ 3007ULL ] = ( int32_T ) (
t1921 * 1.2337005501361697E-10 != 0.0 ) ; t913 [ 3008ULL ] = 1 ; t913 [
3009ULL ] = 1 ; t913 [ 3010ULL ] = 1 ; t913 [ 3011ULL ] = 1 ; t913 [ 3012ULL
] = ( int32_T ) ( t1914 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 3013ULL ] =
( int32_T ) ( t1096_idx_0 != 0.0 ) ; t913 [ 3014ULL ] = ( int32_T ) ( ( ! (
t1096_idx_0 != 0.0 ) ) || ( 6.9 / ( t1096_idx_0 == 0.0 ? 1.0E-16 :
t1096_idx_0 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3015ULL ] = 1 ;
t913 [ 3016ULL ] = 1 ; t913 [ 3017ULL ] = ( int32_T ) ( ( ! ( t1096_idx_0 !=
0.0 ) ) || ( ( t1096_idx_0 != 0.0 ) && ( ! ( 6.9 / ( t1096_idx_0 == 0.0 ?
1.0E-16 : t1096_idx_0 ) + 0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 (
6.9 / ( t1096_idx_0 == 0.0 ? 1.0E-16 : t1096_idx_0 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1096_idx_0 == 0.0 ? 1.0E-16 : t1096_idx_0 ) +
0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 3018ULL ] = ( int32_T ) (
t1921 * 1.5707963267948965E-8 != 0.0 ) ; t913 [ 3019ULL ] = ( int32_T ) (
t1921 * 1.2337005501361697E-10 != 0.0 ) ; t913 [ 3020ULL ] = 1 ; t913 [
3021ULL ] = 1 ; t913 [ 3022ULL ] = 1 ; t913 [ 3023ULL ] = 1 ; t913 [ 3024ULL
] = ( int32_T ) ( t1960 - ( - t1960 ) != 0.0 ) ; t913 [ 3025ULL ] = 1 ; t913
[ 3026ULL ] = 1 ; t913 [ 3027ULL ] = 1 ; t913 [ 3028ULL ] = 1 ; t913 [
3029ULL ] = ( int32_T ) ( X [ 55ULL ] * 100000.0 > 0.0 ) ; t913 [ 3030ULL ] =
1 ; t913 [ 3031ULL ] = 1 ; t913 [ 3032ULL ] = 1 ; t913 [ 3033ULL ] = 1 ; t913
[ 3034ULL ] = ( int32_T ) ( X [ 55ULL ] * 100000.0 > 0.0 ) ; t913 [ 3035ULL ]
= ( int32_T ) ( X [ 38ULL ] * 100000.0 > 0.0 ) ; t913 [ 3036ULL ] = ( int32_T
) ( X [ 176ULL ] * 100000.0 > 0.0 ) ; t913 [ 3037ULL ] = ( int32_T ) ( X [
176ULL ] * 100000.0 > 0.0 ) ; t913 [ 3038ULL ] = ( int32_T ) ( X [ 38ULL ] *
100000.0 > 0.0 ) ; t913 [ 3039ULL ] = ( int32_T ) ( X [ 7ULL ] > 0.0 ) ; t913
[ 3040ULL ] = ( int32_T ) ( X [ 148ULL ] > 0.0 ) ; t913 [ 3041ULL ] = (
int32_T ) ( X [ 144ULL ] > 0.0 ) ; t913 [ 3042ULL ] = ( int32_T ) ( X [ 15ULL
] / 1.0E-5 > 0.0 ) ; t913 [ 3043ULL ] = ( int32_T ) ( X [ 149ULL ] / 1.0E-5 >
0.0 ) ; t913 [ 3044ULL ] = ( int32_T ) ( X [ 145ULL ] / 1.0E-5 > 0.0 ) ; t913
[ 3045ULL ] = ( int32_T ) ( X [ 161ULL ] > 0.0 ) ; t913 [ 3046ULL ] = (
int32_T ) ( X [ 162ULL ] > 0.0 ) ; t913 [ 3047ULL ] = ( int32_T ) ( X [
163ULL ] > 0.0 ) ; t913 [ 3048ULL ] = 1 ; t913 [ 3049ULL ] = 1 ; t913 [
3050ULL ] = ( int32_T ) ( X [ 162ULL ] != 0.0 ) ; t913 [ 3051ULL ] = (
int32_T ) ( ( ! ( X [ 162ULL ] != 0.0 ) ) || ( fabs ( X [ 162ULL ] ) != 0.0 )
) ; t913 [ 3052ULL ] = 1 ; t913 [ 3053ULL ] = ( int32_T ) ( X [ 163ULL ] !=
0.0 ) ; t913 [ 3054ULL ] = ( int32_T ) ( ( ! ( X [ 163ULL ] != 0.0 ) ) || (
fabs ( X [ 163ULL ] ) != 0.0 ) ) ; t913 [ 3055ULL ] = 1 ; t913 [ 3056ULL ] =
1 ; t913 [ 3057ULL ] = 1 ; t913 [ 3058ULL ] = ( int32_T ) ( X [ 161ULL ] !=
0.0 ) ; t913 [ 3059ULL ] = ( int32_T ) ( ( ! ( X [ 161ULL ] != 0.0 ) ) || (
fabs ( X [ 161ULL ] ) != 0.0 ) ) ; t913 [ 3060ULL ] = 1 ; t913 [ 3061ULL ] =
( int32_T ) ( X [ 161ULL ] != 0.0 ) ; t913 [ 3062ULL ] = ( int32_T ) ( ( ! (
X [ 161ULL ] != 0.0 ) ) || ( fabs ( X [ 161ULL ] ) != 0.0 ) ) ; t913 [
3063ULL ] = 1 ; t913 [ 3064ULL ] = ( int32_T ) ( ( X [ 148ULL ] *
402.5245441795231 == X [ 148ULL ] * 402.5245441795231 ) && ( fabs ( X [
148ULL ] * 402.5245441795231 ) != pmf_get_inf ( ) ) ) ; t913 [ 3065ULL ] = (
int32_T ) ( ( ! ( X [ 148ULL ] * 402.5245441795231 == X [ 148ULL ] *
402.5245441795231 ) ) || ( ! ( fabs ( X [ 148ULL ] * 402.5245441795231 ) !=
pmf_get_inf ( ) ) ) || ( X [ 148ULL ] * 402.5245441795231 >= 0.0 ) ) ; t913 [
3066ULL ] = ( int32_T ) ( ( X [ 144ULL ] * 402.5245441795231 == X [ 144ULL ]
* 402.5245441795231 ) && ( fabs ( X [ 144ULL ] * 402.5245441795231 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 3067ULL ] = ( int32_T ) ( ( ! ( X [ 144ULL ] *
402.5245441795231 == X [ 144ULL ] * 402.5245441795231 ) ) || ( ! ( fabs ( X [
144ULL ] * 402.5245441795231 ) != pmf_get_inf ( ) ) ) || ( X [ 144ULL ] *
402.5245441795231 >= 0.0 ) ) ; t913 [ 3068ULL ] = 1 ; t913 [ 3069ULL ] = 1 ;
t913 [ 3070ULL ] = 1 ; t913 [ 3071ULL ] = 1 ; t913 [ 3072ULL ] = ( int32_T )
( ( X [ 154ULL ] * X [ 154ULL ] + U_idx_4 * U_idx_4 == X [ 154ULL ] * X [
154ULL ] + U_idx_4 * U_idx_4 ) && ( fabs ( X [ 154ULL ] * X [ 154ULL ] +
U_idx_4 * U_idx_4 ) != pmf_get_inf ( ) ) ) ; t913 [ 3073ULL ] = ( int32_T ) (
( ! ( X [ 154ULL ] * X [ 154ULL ] + U_idx_4 * U_idx_4 == X [ 154ULL ] * X [
154ULL ] + U_idx_4 * U_idx_4 ) ) || ( ! ( fabs ( X [ 154ULL ] * X [ 154ULL ]
+ U_idx_4 * U_idx_4 ) != pmf_get_inf ( ) ) ) || ( X [ 154ULL ] * X [ 154ULL ]
+ U_idx_4 * U_idx_4 >= 0.0 ) ) ; t913 [ 3074ULL ] = 1 ; t913 [ 3075ULL ] = 1
; t913 [ 3076ULL ] = ( int32_T ) ( ( t1866 * t1866 == t1866 * t1866 ) && (
fabs ( t1866 * t1866 ) != pmf_get_inf ( ) ) ) ; t913 [ 3077ULL ] = ( int32_T
) ( ( ! ( t1866 * t1866 == t1866 * t1866 ) ) || ( ! ( fabs ( t1866 * t1866 )
!= pmf_get_inf ( ) ) ) || ( t1866 * t1866 >= 0.0 ) ) ; t913 [ 3078ULL ] = (
int32_T ) ( t2005 != 0.0 ) ; t913 [ 3079ULL ] = 1 ; t913 [ 3080ULL ] = (
int32_T ) ( t2011 != 0.0 ) ; t913 [ 3081ULL ] = 1 ; t913 [ 3082ULL ] = (
int32_T ) ( t2005 != 0.0 ) ; t913 [ 3083ULL ] = 1 ; t913 [ 3084ULL ] = (
int32_T ) ( t2011 != 0.0 ) ; t913 [ 3085ULL ] = 1 ; t913 [ 3086ULL ] = 1 ;
t913 [ 3087ULL ] = 1 ; t913 [ 3088ULL ] = ( int32_T ) ( ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) && (
fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ;
t913 [ 3089ULL ] = ( int32_T ) ( ( ! ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 == U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) ) || (
! ( fabs ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 ) != pmf_get_inf ( ) )
) || ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 3090ULL
] = 1 ; t913 [ 3091ULL ] = 1 ; t913 [ 3092ULL ] = ( int32_T ) ( ( U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 == U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) && ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) ; t913 [ 3093ULL ] = (
int32_T ) ( ( ! ( U_idx_2 * U_idx_2 + 4.5311819630628225E-12 == U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 ) ) || ( ! ( fabs ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) != pmf_get_inf ( ) ) ) || ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 >= 0.0 ) ) ; t913 [ 3094ULL ] = ( int32_T ) ( t1304 !=
0.0 ) ; t913 [ 3095ULL ] = 1 ; t913 [ 3096ULL ] = ( int32_T ) ( t1304 != 0.0
) ; t913 [ 3097ULL ] = 1 ; t913 [ 3098ULL ] = ( int32_T ) ( t1304 != 0.0 ) ;
t913 [ 3099ULL ] = 1 ; t913 [ 3100ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913
[ 3101ULL ] = 1 ; t913 [ 3102ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [
3103ULL ] = ( int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( X [ 159ULL ] != 0.0 ) )
; t913 [ 3104ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 3105ULL ] = (
int32_T ) ( ( ! ( t1304 != 0.0 ) ) || ( X [ 160ULL ] != 0.0 ) ) ; t913 [
3106ULL ] = ( int32_T ) ( X [ 15ULL ] != 0.0 ) ; t913 [ 3107ULL ] = ( int32_T
) ( X [ 7ULL ] != 0.0 ) ; t913 [ 3108ULL ] = ( int32_T ) ( X [ 7ULL ] * 287.0
!= 0.0 ) ; t913 [ 3109ULL ] = ( int32_T ) ( X [ 7ULL ] != 0.0 ) ; t913 [
3110ULL ] = ( int32_T ) ( X [ 164ULL ] != 0.0 ) ; t913 [ 3111ULL ] = 1 ; t913
[ 3112ULL ] = 1 ; t913 [ 3113ULL ] = 1 ; t913 [ 3114ULL ] = 1 ; t913 [
3115ULL ] = ( int32_T ) ( ( - U_idx_2 >= 0.0 ) || ( X [ 159ULL ] *
1.2337005501361696E-8 != 0.0 ) ) ; t913 [ 3116ULL ] = 1 ; t913 [ 3117ULL ] =
1 ; t913 [ 3118ULL ] = 1 ; t913 [ 3119ULL ] = 1 ; t913 [ 3120ULL ] = (
int32_T ) ( ( U_idx_2 >= 0.0 ) || ( X [ 160ULL ] * 1.2337005501361696E-8 !=
0.0 ) ) ; t913 [ 3121ULL ] = ( int32_T ) ( - t1456 - t1456 * - 0.95 != 0.0 )
; t913 [ 3122ULL ] = 1 ; t913 [ 3123ULL ] = 1 ; t913 [ 3124ULL ] = 1 ; t913 [
3125ULL ] = 1 ; t913 [ 3126ULL ] = ( int32_T ) ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_D2 * - 0.95 !=
0.0 ) ; t913 [ 3127ULL ] = 1 ; t913 [ 3128ULL ] = 1 ; t913 [ 3129ULL ] = 1 ;
t913 [ 3130ULL ] = 1 ; t913 [ 3131ULL ] = ( int32_T ) ( t1492 - t1492 * 0.95
!= 0.0 ) ; t913 [ 3132ULL ] = 1 ; t913 [ 3133ULL ] = 1 ; t913 [ 3134ULL ] = 1
; t913 [ 3135ULL ] = 1 ; t913 [ 3136ULL ] = 1 ; t913 [ 3137ULL ] = 1 ; t913 [
3138ULL ] = 1 ; t913 [ 3139ULL ] = 1 ; t913 [ 3140ULL ] = ( int32_T ) ( -
t1333 - t1333 * - 0.95 != 0.0 ) ; t913 [ 3141ULL ] = 1 ; t913 [ 3142ULL ] = 1
; t913 [ 3143ULL ] = 1 ; t913 [ 3144ULL ] = 1 ; t913 [ 3145ULL ] = ( int32_T
) ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi2 * - 0.95 != 0.0
) ; t913 [ 3146ULL ] = 1 ; t913 [ 3147ULL ] = 1 ; t913 [ 3148ULL ] = 1 ; t913
[ 3149ULL ] = 1 ; t913 [ 3150ULL ] = ( int32_T ) ( - t1563 - t1563 * - 0.95
!= 0.0 ) ; t913 [ 3151ULL ] = 1 ; t913 [ 3152ULL ] = 1 ; t913 [ 3153ULL ] = 1
; t913 [ 3154ULL ] = 1 ; t913 [ 3155ULL ] = ( int32_T ) ( - t1552 - t1552 * -
0.95 != 0.0 ) ; t913 [ 3156ULL ] = 1 ; t913 [ 3157ULL ] = 1 ; t913 [ 3158ULL
] = 1 ; t913 [ 3159ULL ] = 1 ; t913 [ 3160ULL ] = ( int32_T ) ( - t1602 -
t1602 * - 0.95 != 0.0 ) ; t913 [ 3161ULL ] = 1 ; t913 [ 3162ULL ] = 1 ; t913
[ 3163ULL ] = 1 ; t913 [ 3164ULL ] = 1 ; t913 [ 3165ULL ] = ( int32_T ) ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_2 * - 0.95 !=
0.0 ) ; t913 [ 3166ULL ] = 1 ; t913 [ 3167ULL ] = 1 ; t913 [ 3168ULL ] = 1 ;
t913 [ 3169ULL ] = 1 ; t913 [ 3170ULL ] = ( int32_T ) ( - t1647 - t1647 * -
0.95 != 0.0 ) ; t913 [ 3171ULL ] = 1 ; t913 [ 3172ULL ] = 1 ; t913 [ 3173ULL
] = 1 ; t913 [ 3174ULL ] = 1 ; t913 [ 3175ULL ] = ( int32_T ) ( - t1636 -
t1636 * - 0.95 != 0.0 ) ; t913 [ 3176ULL ] = 1 ; t913 [ 3177ULL ] = 1 ; t913
[ 3178ULL ] = 1 ; t913 [ 3179ULL ] = 1 ; t913 [ 3180ULL ] = ( int32_T ) (
t1691 - t1691 * 0.95 != 0.0 ) ; t913 [ 3181ULL ] = 1 ; t913 [ 3182ULL ] = 1 ;
t913 [ 3183ULL ] = 1 ; t913 [ 3184ULL ] = 1 ; t913 [ 3185ULL ] = 1 ; t913 [
3186ULL ] = 1 ; t913 [ 3187ULL ] = 1 ; t913 [ 3188ULL ] = 1 ; t913 [ 3189ULL
] = ( int32_T ) ( - t1376 - t1376 * - 0.95 != 0.0 ) ; t913 [ 3190ULL ] = 1 ;
t913 [ 3191ULL ] = 1 ; t913 [ 3192ULL ] = 1 ; t913 [ 3193ULL ] = 1 ; t913 [
3194ULL ] = ( int32_T ) ( - t1698 - t1698 * - 0.95 != 0.0 ) ; t913 [ 3195ULL
] = 1 ; t913 [ 3196ULL ] = 1 ; t913 [ 3197ULL ] = 1 ; t913 [ 3198ULL ] = 1 ;
t913 [ 3199ULL ] = ( int32_T ) ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_56 * - 0.95 !=
0.0 ) ; t913 [ 3200ULL ] = 1 ; t913 [ 3201ULL ] = 1 ; t913 [ 3202ULL ] = 1 ;
t913 [ 3203ULL ] = 1 ; t913 [ 3204ULL ] = ( int32_T ) ( - t1754 - t1754 * -
0.95 != 0.0 ) ; t913 [ 3205ULL ] = 1 ; t913 [ 3206ULL ] = 1 ; t913 [ 3207ULL
] = 1 ; t913 [ 3208ULL ] = 1 ; t913 [ 3209ULL ] = ( int32_T ) ( - t1797 -
t1797 * - 0.95 != 0.0 ) ; t913 [ 3210ULL ] = 1 ; t913 [ 3211ULL ] = 1 ; t913
[ 3212ULL ] = 1 ; t913 [ 3213ULL ] = 1 ; t913 [ 3214ULL ] = ( int32_T ) ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip2 * - 0.95 !=
0.0 ) ; t913 [ 3215ULL ] = 1 ; t913 [ 3216ULL ] = 1 ; t913 [ 3217ULL ] = 1 ;
t913 [ 3218ULL ] = 1 ; t913 [ 3219ULL ] = ( int32_T ) ( t1416 *
7.8539816339744827E-5 != 0.0 ) ; t913 [ 3220ULL ] = ( int32_T ) ( - t1911 -
t1911 * - 0.95 != 0.0 ) ; t913 [ 3221ULL ] = 1 ; t913 [ 3222ULL ] = 1 ; t913
[ 3223ULL ] = 1 ; t913 [ 3224ULL ] = 1 ; t913 [ 3225ULL ] = ( int32_T ) ( -
t1901 - t1901 * - 0.95 != 0.0 ) ; t913 [ 3226ULL ] = 1 ; t913 [ 3227ULL ] = 1
; t913 [ 3228ULL ] = 1 ; t913 [ 3229ULL ] = 1 ; t913 [ 3230ULL ] = ( int32_T
) ( t1953 - t1953 * 0.95 != 0.0 ) ; t913 [ 3231ULL ] = 1 ; t913 [ 3232ULL ] =
1 ; t913 [ 3233ULL ] = 1 ; t913 [ 3234ULL ] = 1 ; t913 [ 3235ULL ] = 1 ; t913
[ 3236ULL ] = 1 ; t913 [ 3237ULL ] = 1 ; t913 [ 3238ULL ] = 1 ; t913 [
3239ULL ] = ( int32_T ) ( U_idx_11 != 0.0 ) ; t913 [ 3240ULL ] = ( int32_T )
( ( ! ( U_idx_11 != 0.0 ) ) || ( X [ 527ULL ] != 0.0 ) ) ; t913 [ 3241ULL ] =
( int32_T ) ( t2016 != 0.0 ) ; t913 [ 3242ULL ] = ( int32_T ) ( ( ! ( t2016
!= 0.0 ) ) || ( 6.9 / ( t2016 == 0.0 ? 1.0E-16 : t2016 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 3243ULL ] = 1 ; t913 [ 3244ULL ] =
1 ; t913 [ 3245ULL ] = ( int32_T ) ( ( ! ( t2016 != 0.0 ) ) || ( ( t2016 !=
0.0 ) && ( ! ( 6.9 / ( t2016 == 0.0 ? 1.0E-16 : t2016 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t2016 == 0.0 ?
1.0E-16 : t2016 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2016 ==
0.0 ? 1.0E-16 : t2016 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3246ULL ] = 1 ; t913 [ 3247ULL ] = ( int32_T ) ( intrm_sf_mf_102 *
7.8539816339744827E-5 != 0.0 ) ; t913 [ 3248ULL ] = ( int32_T ) ( U_idx_7 !=
0.0 ) ; t913 [ 3249ULL ] = ( int32_T ) ( ( ! ( U_idx_7 != 0.0 ) ) || ( 6.9 /
( U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) + 0.00017169489553429715 > 0.0 ) ) ;
t913 [ 3250ULL ] = 1 ; t913 [ 3251ULL ] = 1 ; t913 [ 3252ULL ] = ( int32_T )
( ( ! ( U_idx_7 != 0.0 ) ) || ( ( U_idx_7 != 0.0 ) && ( ! ( 6.9 / ( U_idx_7
== 0.0 ? 1.0E-16 : U_idx_7 ) + 0.00017169489553429715 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( U_idx_7 == 0.0 ? 1.0E-16 : U_idx_7 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( U_idx_7 == 0.0 ? 1.0E-16 :
U_idx_7 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [ 3253ULL ] = (
int32_T ) ( t1460 * 1.5707963267948965E-8 != 0.0 ) ; t913 [ 3254ULL ] = (
int32_T ) ( t1460 * 1.2337005501361697E-10 != 0.0 ) ; t913 [ 3255ULL ] = 1 ;
t913 [ 3256ULL ] = 1 ; t913 [ 3257ULL ] = 1 ; t913 [ 3258ULL ] = 1 ; t913 [
3259ULL ] = ( int32_T ) ( t1415 * 1.5707963267948965E-8 != 0.0 ) ; t913 [
3260ULL ] = ( int32_T ) ( intrm_sf_mf_102 * 7.8539816339744827E-5 != 0.0 ) ;
t913 [ 3261ULL ] = ( int32_T ) ( t1461 != 0.0 ) ; t913 [ 3262ULL ] = (
int32_T ) ( ( ! ( t1461 != 0.0 ) ) || ( 6.9 / ( t1461 == 0.0 ? 1.0E-16 :
t1461 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3263ULL ] = 1 ; t913 [
3264ULL ] = 1 ; t913 [ 3265ULL ] = ( int32_T ) ( ( ! ( t1461 != 0.0 ) ) || (
( t1461 != 0.0 ) && ( ! ( 6.9 / ( t1461 == 0.0 ? 1.0E-16 : t1461 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1461 == 0.0 ?
1.0E-16 : t1461 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1461 ==
0.0 ? 1.0E-16 : t1461 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3266ULL ] = ( int32_T ) ( t1460 * 1.5707963267948965E-8 != 0.0 ) ; t913 [
3267ULL ] = ( int32_T ) ( t1460 * 1.2337005501361697E-10 != 0.0 ) ; t913 [
3268ULL ] = 1 ; t913 [ 3269ULL ] = 1 ; t913 [ 3270ULL ] = 1 ; t913 [ 3271ULL
] = 1 ; t913 [ 3272ULL ] = ( int32_T ) ( t1415 * 1.2337005501361696E-8 != 0.0
) ; t913 [ 3273ULL ] = 1 ; t913 [ 3274ULL ] = 1 ; t913 [ 3275ULL ] = 1 ; t913
[ 3276ULL ] = 1 ; t913 [ 3277ULL ] = ( int32_T ) ( t1501 - ( - t1501 ) != 0.0
) ; t913 [ 3278ULL ] = 1 ; t913 [ 3279ULL ] = 1 ; t913 [ 3280ULL ] = 1 ; t913
[ 3281ULL ] = 1 ; t913 [ 3282ULL ] = 1 ; t913 [ 3283ULL ] = 1 ; t913 [
3284ULL ] = 1 ; t913 [ 3285ULL ] = 1 ; t913 [ 3286ULL ] = 1 ; t913 [ 3287ULL
] = ( int32_T ) ( t1427 * 7.8539816339744827E-5 != 0.0 ) ; t913 [ 3288ULL ] =
( int32_T ) ( U_idx_10 != 0.0 ) ; t913 [ 3289ULL ] = ( int32_T ) ( ( ! (
U_idx_10 != 0.0 ) ) || ( 6.9 / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 3290ULL ] = 1 ; t913 [ 3291ULL ] =
1 ; t913 [ 3292ULL ] = ( int32_T ) ( ( ! ( U_idx_10 != 0.0 ) ) || ( (
U_idx_10 != 0.0 ) && ( ! ( 6.9 / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( U_idx_10 == 0.0 ?
1.0E-16 : U_idx_10 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) + 0.00017169489553429715 ) * 3.24 !=
0.0 ) ) ; t913 [ 3293ULL ] = 1 ; t913 [ 3294ULL ] = ( int32_T ) ( t1426 *
1.5707963267948965E-8 != 0.0 ) ; t913 [ 3295ULL ] = ( int32_T ) ( t1426 *
1.2337005501361696E-8 != 0.0 ) ; t913 [ 3296ULL ] = 1 ; t913 [ 3297ULL ] = 1
; t913 [ 3298ULL ] = 1 ; t913 [ 3299ULL ] = 1 ; t913 [ 3300ULL ] = ( int32_T
) ( t1512 * 0.44 != 0.0 ) ; t913 [ 3301ULL ] = ( int32_T ) ( t1091_idx_0 !=
0.0 ) ; t913 [ 3302ULL ] = ( int32_T ) ( ( ! ( t1091_idx_0 != 0.0 ) ) || (
6.9 / ( t1091_idx_0 == 0.0 ? 1.0E-16 : t1091_idx_0 ) + 0.00017169489553429715
> 0.0 ) ) ; t913 [ 3303ULL ] = 1 ; t913 [ 3304ULL ] = 1 ; t913 [ 3305ULL ] =
( int32_T ) ( ( ! ( t1091_idx_0 != 0.0 ) ) || ( ( t1091_idx_0 != 0.0 ) && ( !
( 6.9 / ( t1091_idx_0 == 0.0 ? 1.0E-16 : t1091_idx_0 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1091_idx_0 ==
0.0 ? 1.0E-16 : t1091_idx_0 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 /
( t1091_idx_0 == 0.0 ? 1.0E-16 : t1091_idx_0 ) + 0.00017169489553429715 ) *
3.24 != 0.0 ) ) ; t913 [ 3306ULL ] = ( int32_T ) ( t1517 *
8.8000000000000011E-5 != 0.0 ) ; t913 [ 3307ULL ] = ( int32_T ) ( t1517 *
0.003872 != 0.0 ) ; t913 [ 3308ULL ] = 1 ; t913 [ 3309ULL ] = 1 ; t913 [
3310ULL ] = 1 ; t913 [ 3311ULL ] = 1 ; t913 [ 3312ULL ] = ( int32_T ) ( t1512
* 0.44 != 0.0 ) ; t913 [ 3313ULL ] = ( int32_T ) ( t1561 != 0.0 ) ; t913 [
3314ULL ] = ( int32_T ) ( ( ! ( t1561 != 0.0 ) ) || ( 6.9 / ( t1561 == 0.0 ?
1.0E-16 : t1561 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3315ULL ] = 1 ;
t913 [ 3316ULL ] = 1 ; t913 [ 3317ULL ] = ( int32_T ) ( ( ! ( t1561 != 0.0 )
) || ( ( t1561 != 0.0 ) && ( ! ( 6.9 / ( t1561 == 0.0 ? 1.0E-16 : t1561 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1561 == 0.0 ?
1.0E-16 : t1561 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1561 ==
0.0 ? 1.0E-16 : t1561 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3318ULL ] = 1 ; t913 [ 3319ULL ] = 1 ; t913 [ 3320ULL ] = 1 ; t913 [ 3321ULL
] = 1 ; t913 [ 3322ULL ] = ( int32_T ) ( t1427 * 7.8539816339744827E-5 != 0.0
) ; t913 [ 3323ULL ] = ( int32_T ) ( t1517 * 8.8000000000000011E-5 != 0.0 ) ;
t913 [ 3324ULL ] = ( int32_T ) ( t1517 * 0.003872 != 0.0 ) ; t913 [ 3325ULL ]
= 1 ; t913 [ 3326ULL ] = 1 ; t913 [ 3327ULL ] = 1 ; t913 [ 3328ULL ] = 1 ;
t913 [ 3329ULL ] = ( int32_T ) ( t2020 != 0.0 ) ; t913 [ 3330ULL ] = (
int32_T ) ( ( ! ( t2020 != 0.0 ) ) || ( 6.9 / ( t2020 == 0.0 ? 1.0E-16 :
t2020 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3331ULL ] = 1 ; t913 [
3332ULL ] = 1 ; t913 [ 3333ULL ] = ( int32_T ) ( ( ! ( t2020 != 0.0 ) ) || (
( t2020 != 0.0 ) && ( ! ( 6.9 / ( t2020 == 0.0 ? 1.0E-16 : t2020 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t2020 == 0.0 ?
1.0E-16 : t2020 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2020 ==
0.0 ? 1.0E-16 : t2020 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3334ULL ] = 1 ; t913 [ 3335ULL ] = ( int32_T ) ( t1426 *
1.5707963267948965E-8 != 0.0 ) ; t913 [ 3336ULL ] = 1 ; t913 [ 3337ULL ] = 1
; t913 [ 3338ULL ] = 1 ; t913 [ 3339ULL ] = 1 ; t913 [ 3340ULL ] = 1 ; t913 [
3341ULL ] = ( int32_T ) ( t1426 * 1.2337005501361696E-8 != 0.0 ) ; t913 [
3342ULL ] = 1 ; t913 [ 3343ULL ] = 1 ; t913 [ 3344ULL ] = 1 ; t913 [ 3345ULL
] = 1 ; t913 [ 3346ULL ] = ( int32_T ) ( t1436 * 7.8539816339744827E-5 != 0.0
) ; t913 [ 3347ULL ] = ( int32_T ) ( t1566 * 0.44 != 0.0 ) ; t913 [ 3348ULL ]
= ( int32_T ) ( t1469 != 0.0 ) ; t913 [ 3349ULL ] = ( int32_T ) ( ( ! ( t1469
!= 0.0 ) ) || ( 6.9 / ( t1469 == 0.0 ? 1.0E-16 : t1469 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 3350ULL ] = 1 ; t913 [ 3351ULL ] =
1 ; t913 [ 3352ULL ] = ( int32_T ) ( ( ! ( t1469 != 0.0 ) ) || ( ( t1469 !=
0.0 ) && ( ! ( 6.9 / ( t1469 == 0.0 ? 1.0E-16 : t1469 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1469 == 0.0 ?
1.0E-16 : t1469 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1469 ==
0.0 ? 1.0E-16 : t1469 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3353ULL ] = ( int32_T ) ( t1570 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
3354ULL ] = ( int32_T ) ( t1570 * 0.003872 != 0.0 ) ; t913 [ 3355ULL ] = 1 ;
t913 [ 3356ULL ] = 1 ; t913 [ 3357ULL ] = 1 ; t913 [ 3358ULL ] = 1 ; t913 [
3359ULL ] = ( int32_T ) ( t1566 * 0.44 != 0.0 ) ; t913 [ 3360ULL ] = (
int32_T ) ( t1645 != 0.0 ) ; t913 [ 3361ULL ] = ( int32_T ) ( ( ! ( t1645 !=
0.0 ) ) || ( 6.9 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 3362ULL ] = 1 ; t913 [ 3363ULL ] =
1 ; t913 [ 3364ULL ] = ( int32_T ) ( ( ! ( t1645 != 0.0 ) ) || ( ( t1645 !=
0.0 ) && ( ! ( 6.9 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1645 == 0.0 ?
1.0E-16 : t1645 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1645 ==
0.0 ? 1.0E-16 : t1645 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3365ULL ] = ( int32_T ) ( t1570 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
3366ULL ] = ( int32_T ) ( t1570 * 0.003872 != 0.0 ) ; t913 [ 3367ULL ] = (
int32_T ) ( U_idx_3 != 0.0 ) ; t913 [ 3368ULL ] = ( int32_T ) ( ( ! ( U_idx_3
!= 0.0 ) ) || ( 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) +
0.00017169489553429715 > 0.0 ) ) ; t913 [ 3369ULL ] = 1 ; t913 [ 3370ULL ] =
1 ; t913 [ 3371ULL ] = ( int32_T ) ( ( ! ( U_idx_3 != 0.0 ) ) || ( ( U_idx_3
!= 0.0 ) && ( ! ( 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( U_idx_3 == 0.0 ?
1.0E-16 : U_idx_3 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( U_idx_3
== 0.0 ? 1.0E-16 : U_idx_3 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ;
t913 [ 3372ULL ] = 1 ; t913 [ 3373ULL ] = 1 ; t913 [ 3374ULL ] = 1 ; t913 [
3375ULL ] = 1 ; t913 [ 3376ULL ] = 1 ; t913 [ 3377ULL ] = ( int32_T ) ( t1435
* 1.5707963267948965E-8 != 0.0 ) ; t913 [ 3378ULL ] = ( int32_T ) ( t1435 *
1.2337005501361696E-8 != 0.0 ) ; t913 [ 3379ULL ] = 1 ; t913 [ 3380ULL ] = 1
; t913 [ 3381ULL ] = 1 ; t913 [ 3382ULL ] = 1 ; t913 [ 3383ULL ] = 1 ; t913 [
3384ULL ] = 1 ; t913 [ 3385ULL ] = 1 ; t913 [ 3386ULL ] = 1 ; t913 [ 3387ULL
] = 1 ; t913 [ 3388ULL ] = ( int32_T ) ( t1436 * 7.8539816339744827E-5 != 0.0
) ; t913 [ 3389ULL ] = ( int32_T ) ( t2024 != 0.0 ) ; t913 [ 3390ULL ] = (
int32_T ) ( ( ! ( t2024 != 0.0 ) ) || ( 6.9 / ( t2024 == 0.0 ? 1.0E-16 :
t2024 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3391ULL ] = 1 ; t913 [
3392ULL ] = 1 ; t913 [ 3393ULL ] = ( int32_T ) ( ( ! ( t2024 != 0.0 ) ) || (
( t2024 != 0.0 ) && ( ! ( 6.9 / ( t2024 == 0.0 ? 1.0E-16 : t2024 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t2024 == 0.0 ?
1.0E-16 : t2024 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t2024 ==
0.0 ? 1.0E-16 : t2024 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3394ULL ] = 1 ; t913 [ 3395ULL ] = ( int32_T ) ( t1435 *
1.5707963267948965E-8 != 0.0 ) ; t913 [ 3396ULL ] = ( int32_T ) ( t1435 *
1.2337005501361696E-8 != 0.0 ) ; t913 [ 3397ULL ] = ( int32_T ) ( t1607 *
0.0019634954084936209 != 0.0 ) ; t913 [ 3398ULL ] = ( int32_T ) ( t1303 !=
0.0 ) ; t913 [ 3399ULL ] = ( int32_T ) ( ( ! ( t1303 != 0.0 ) ) || ( 6.9 / (
t1303 == 0.0 ? 1.0E-16 : t1303 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [
3400ULL ] = 1 ; t913 [ 3401ULL ] = 1 ; t913 [ 3402ULL ] = ( int32_T ) ( ( ! (
t1303 != 0.0 ) ) || ( ( t1303 != 0.0 ) && ( ! ( 6.9 / ( t1303 == 0.0 ?
1.0E-16 : t1303 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1303 == 0.0 ? 1.0E-16 : t1303 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1303 == 0.0 ? 1.0E-16 : t1303 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 3403ULL ] = ( int32_T ) ( t1611 * 9.8174770424681068E-6 !=
0.0 ) ; t913 [ 3404ULL ] = ( int32_T ) ( t1611 * 3.855314219175531E-7 != 0.0
) ; t913 [ 3405ULL ] = 1 ; t913 [ 3406ULL ] = 1 ; t913 [ 3407ULL ] = 1 ; t913
[ 3408ULL ] = 1 ; t913 [ 3409ULL ] = 1 ; t913 [ 3410ULL ] = 1 ; t913 [
3411ULL ] = 1 ; t913 [ 3412ULL ] = 1 ; t913 [ 3413ULL ] = ( int32_T ) ( t1607
* 0.0019634954084936209 != 0.0 ) ; t913 [ 3414ULL ] = ( int32_T ) ( t1725 !=
0.0 ) ; t913 [ 3415ULL ] = ( int32_T ) ( ( ! ( t1725 != 0.0 ) ) || ( 6.9 / (
t1725 == 0.0 ? 1.0E-16 : t1725 ) + 2.8767404433520813E-5 > 0.0 ) ) ; t913 [
3416ULL ] = 1 ; t913 [ 3417ULL ] = 1 ; t913 [ 3418ULL ] = ( int32_T ) ( ( ! (
t1725 != 0.0 ) ) || ( ( t1725 != 0.0 ) && ( ! ( 6.9 / ( t1725 == 0.0 ?
1.0E-16 : t1725 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 /
( t1725 == 0.0 ? 1.0E-16 : t1725 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( t1725 == 0.0 ? 1.0E-16 : t1725 ) + 2.8767404433520813E-5 ) * 3.24 !=
0.0 ) ) ; t913 [ 3419ULL ] = ( int32_T ) ( t1611 * 9.8174770424681068E-6 !=
0.0 ) ; t913 [ 3420ULL ] = ( int32_T ) ( t1611 * 3.855314219175531E-7 != 0.0
) ; t913 [ 3421ULL ] = 1 ; t913 [ 3422ULL ] = 1 ; t913 [ 3423ULL ] = 1 ; t913
[ 3424ULL ] = 1 ; t913 [ 3425ULL ] = 1 ; t913 [ 3426ULL ] = 1 ; t913 [
3427ULL ] = 1 ; t913 [ 3428ULL ] = 1 ; t913 [ 3429ULL ] = 1 ; t913 [ 3430ULL
] = ( int32_T ) ( t1650 * 0.0019634954084936209 != 0.0 ) ; t913 [ 3431ULL ] =
( int32_T ) ( t2027 != 0.0 ) ; t913 [ 3432ULL ] = ( int32_T ) ( ( ! ( t2027
!= 0.0 ) ) || ( 6.9 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) +
2.8767404433520813E-5 > 0.0 ) ) ; t913 [ 3433ULL ] = 1 ; t913 [ 3434ULL ] = 1
; t913 [ 3435ULL ] = ( int32_T ) ( ( ! ( t2027 != 0.0 ) ) || ( ( t2027 != 0.0
) && ( ! ( 6.9 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) + 2.8767404433520813E-5 >
0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t2027 == 0.0 ? 1.0E-16 : t2027 ) +
2.8767404433520813E-5 ) * pmf_log10 ( 6.9 / ( t2027 == 0.0 ? 1.0E-16 : t2027
) + 2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 3436ULL ] = ( int32_T
) ( t1654 * 9.8174770424681068E-6 != 0.0 ) ; t913 [ 3437ULL ] = ( int32_T ) (
t1654 * 3.855314219175531E-7 != 0.0 ) ; t913 [ 3438ULL ] = 1 ; t913 [ 3439ULL
] = 1 ; t913 [ 3440ULL ] = 1 ; t913 [ 3441ULL ] = 1 ; t913 [ 3442ULL ] = (
int32_T ) ( t1650 * 0.0019634954084936209 != 0.0 ) ; t913 [ 3443ULL ] = (
int32_T ) ( t1807 != 0.0 ) ; t913 [ 3444ULL ] = ( int32_T ) ( ( ! ( t1807 !=
0.0 ) ) || ( 6.9 / ( t1807 == 0.0 ? 1.0E-16 : t1807 ) + 2.8767404433520813E-5
> 0.0 ) ) ; t913 [ 3445ULL ] = 1 ; t913 [ 3446ULL ] = 1 ; t913 [ 3447ULL ] =
( int32_T ) ( ( ! ( t1807 != 0.0 ) ) || ( ( t1807 != 0.0 ) && ( ! ( 6.9 / (
t1807 == 0.0 ? 1.0E-16 : t1807 ) + 2.8767404433520813E-5 > 0.0 ) ) ) || (
pmf_log10 ( 6.9 / ( t1807 == 0.0 ? 1.0E-16 : t1807 ) + 2.8767404433520813E-5
) * pmf_log10 ( 6.9 / ( t1807 == 0.0 ? 1.0E-16 : t1807 ) +
2.8767404433520813E-5 ) * 3.24 != 0.0 ) ) ; t913 [ 3448ULL ] = ( int32_T ) (
t1654 * 9.8174770424681068E-6 != 0.0 ) ; t913 [ 3449ULL ] = ( int32_T ) (
t1654 * 3.855314219175531E-7 != 0.0 ) ; t913 [ 3450ULL ] = 1 ; t913 [ 3451ULL
] = 1 ; t913 [ 3452ULL ] = 1 ; t913 [ 3453ULL ] = 1 ; t913 [ 3454ULL ] = (
int32_T ) ( t1700 - ( - t1700 ) != 0.0 ) ; t913 [ 3455ULL ] = 1 ; t913 [
3456ULL ] = 1 ; t913 [ 3457ULL ] = 1 ; t913 [ 3458ULL ] = 1 ; t913 [ 3459ULL
] = 1 ; t913 [ 3460ULL ] = 1 ; t913 [ 3461ULL ] = 1 ; t913 [ 3462ULL ] = 1 ;
t913 [ 3463ULL ] = 1 ; t913 [ 3464ULL ] = ( int32_T ) ( t1711 * 0.44 != 0.0 )
; t913 [ 3465ULL ] = ( int32_T ) ( t1906 != 0.0 ) ; t913 [ 3466ULL ] = (
int32_T ) ( ( ! ( t1906 != 0.0 ) ) || ( 6.9 / ( t1906 == 0.0 ? 1.0E-16 :
t1906 ) + 0.00017169489553429715 > 0.0 ) ) ; t913 [ 3467ULL ] = 1 ; t913 [
3468ULL ] = 1 ; t913 [ 3469ULL ] = ( int32_T ) ( ( ! ( t1906 != 0.0 ) ) || (
( t1906 != 0.0 ) && ( ! ( 6.9 / ( t1906 == 0.0 ? 1.0E-16 : t1906 ) +
0.00017169489553429715 > 0.0 ) ) ) || ( pmf_log10 ( 6.9 / ( t1906 == 0.0 ?
1.0E-16 : t1906 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1906 ==
0.0 ? 1.0E-16 : t1906 ) + 0.00017169489553429715 ) * 3.24 != 0.0 ) ) ; t913 [
3470ULL ] = ( int32_T ) ( t1715 * 8.8000000000000011E-5 != 0.0 ) ; t913 [
3471ULL ] = ( int32_T ) ( t1715 * 0.003872 != 0.0 ) ; t913 [ 3472ULL ] = 1 ;
t913 [ 3473ULL ] = 1 ; t913 [ 3474ULL ] = 1 ; t913 [ 3475ULL ] = 1 ; t913 [
3476ULL ] = ( int32_T ) ( t1301 != 0.0 ) ; t913 [ 3477ULL ] = ( int32_T ) (
t2013 != 0.0 ) ; t913 [ 3478ULL ] = ( int32_T ) ( X [ 164ULL ] != 0.0 ) ;
t913 [ 3479ULL ] = ( int32_T ) ( t2013 != 0.0 ) ; t913 [ 3480ULL ] = (
int32_T ) ( X [ 164ULL ] != 0.0 ) ; t913 [ 3481ULL ] = ( int32_T ) ( X [
22ULL ] != 0.0 ) ; t913 [ 3482ULL ] = ( int32_T ) ( X [ 21ULL ] != 0.0 ) ;
t913 [ 3483ULL ] = ( int32_T ) ( intrm_sf_mf_95 != 0.0 ) ; t913 [ 3484ULL ] =
( int32_T ) ( X [ 31ULL ] != 0.0 ) ; t913 [ 3485ULL ] = ( int32_T ) ( X [
25ULL ] != 0.0 ) ; t913 [ 3486ULL ] = ( int32_T ) ( intrm_sf_mf_270 != 0.0 )
; t913 [ 3487ULL ] = ( int32_T ) ( X [ 33ULL ] != 0.0 ) ; t913 [ 3488ULL ] =
( int32_T ) ( X [ 28ULL ] != 0.0 ) ; t913 [ 3489ULL ] = ( int32_T ) ( t1554
!= 0.0 ) ; t913 [ 3490ULL ] = ( int32_T ) ( X [ 37ULL ] != 0.0 ) ; t913 [
3491ULL ] = ( int32_T ) ( X [ 34ULL ] != 0.0 ) ; t913 [ 3492ULL ] = ( int32_T
) ( t1596 != 0.0 ) ; t913 [ 3493ULL ] = ( int32_T ) ( X [ 40ULL ] != 0.0 ) ;
t913 [ 3494ULL ] = ( int32_T ) ( X [ 39ULL ] != 0.0 ) ; t913 [ 3495ULL ] = (
int32_T ) ( t1638 != 0.0 ) ; t913 [ 3496ULL ] = ( int32_T ) ( X [ 49ULL ] !=
0.0 ) ; t913 [ 3497ULL ] = ( int32_T ) ( X [ 43ULL ] != 0.0 ) ; t913 [
3498ULL ] = ( int32_T ) ( t1701 != 0.0 ) ; t913 [ 3499ULL ] = ( int32_T ) ( X
[ 50ULL ] != 0.0 ) ; t913 [ 3500ULL ] = ( int32_T ) ( X [ 46ULL ] != 0.0 ) ;
t913 [ 3501ULL ] = ( int32_T ) ( t1755 != 0.0 ) ; t913 [ 3502ULL ] = (
int32_T ) ( X [ 54ULL ] != 0.0 ) ; t913 [ 3503ULL ] = ( int32_T ) ( X [ 51ULL
] != 0.0 ) ; t913 [ 3504ULL ] = ( int32_T ) ( t1792 != 0.0 ) ; t913 [ 3505ULL
] = ( int32_T ) ( t1848 != 0.0 ) ; t913 [ 3506ULL ] = ( int32_T ) ( t1870 !=
0.0 ) ; t913 [ 3507ULL ] = ( int32_T ) ( X [ 64ULL ] != 0.0 ) ; t913 [
3508ULL ] = ( int32_T ) ( X [ 63ULL ] != 0.0 ) ; t913 [ 3509ULL ] = ( int32_T
) ( t1892 != 0.0 ) ; t913 [ 3510ULL ] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ;
t913 [ 3511ULL ] = ( int32_T ) ( X [ 67ULL ] != 0.0 ) ; t913 [ 3512ULL ] = (
int32_T ) ( t1903 != 0.0 ) ; t913 [ 3513ULL ] = ( int32_T ) ( X [ 55ULL ] !=
0.0 ) ; t913 [ 3514ULL ] = ( int32_T ) ( X [ 71ULL ] != 0.0 ) ; t913 [
3515ULL ] = ( int32_T ) ( t1965 != 0.0 ) ; t913 [ 3516ULL ] = ( int32_T ) ( X
[ 38ULL ] != 0.0 ) ; t913 [ 3517ULL ] = ( int32_T ) ( X [ 74ULL ] != 0.0 ) ;
t913 [ 3518ULL ] = ( int32_T ) ( t1972 != 0.0 ) ; t913 [ 3519ULL ] = 1 ; t913
[ 3520ULL ] = 1 ; t913 [ 3521ULL ] = 1 ; t913 [ 3522ULL ] = 1 ; t913 [
3523ULL ] = ( int32_T ) ( t1301 != 0.0 ) ; t913 [ 3524ULL ] = ( int32_T ) ( (
( X [ 2ULL ] + 1.0E-6 ) / 100.0 == ( X [ 2ULL ] + 1.0E-6 ) / 100.0 ) && (
fabs ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 ) != pmf_get_inf ( ) ) ) ; t913 [
3525ULL ] = ( int32_T ) ( ( ! ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 == ( X [ 2ULL
] + 1.0E-6 ) / 100.0 ) ) || ( ! ( fabs ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 ) !=
pmf_get_inf ( ) ) ) || ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 >= 0.0 ) ) ; t913 [
3526ULL ] = ( int32_T ) ( ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 == ( X [ 2ULL ] +
1.0E-6 ) / 100.0 ) && ( fabs ( ( X [ 2ULL ] + 1.0E-6 ) / 100.0 ) !=
pmf_get_inf ( ) ) ) ; t913 [ 3527ULL ] = ( int32_T ) ( ( ! ( ( X [ 2ULL ] +
1.0E-6 ) / 100.0 == ( X [ 2ULL ] + 1.0E-6 ) / 100.0 ) ) || ( ! ( fabs ( ( X [
2ULL ] + 1.0E-6 ) / 100.0 ) != pmf_get_inf ( ) ) ) || ( ( X [ 2ULL ] + 1.0E-6
) / 100.0 >= 0.0 ) ) ; t913 [ 3528ULL ] = ( int32_T ) ( ( X [ 81ULL ] > 0.9 ?
X [ 81ULL ] : 0.9 ) != 0.0 ) ; t913 [ 3529ULL ] = 1 ; t913 [ 3530ULL ] = 1 ;
t913 [ 3531ULL ] = 1 ; t913 [ 3532ULL ] = 1 ; t913 [ 3533ULL ] = ( int32_T )
( t1304 != 0.0 ) ; t913 [ 3534ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [
3535ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 3536ULL ] = ( int32_T ) (
t1304 != 0.0 ) ; t913 [ 3537ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [
3538ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 3539ULL ] = ( int32_T ) (
t1412 != 0.0 ) ; t913 [ 3540ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [
3541ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 3542ULL ] = ( int32_T ) (
t1412 != 0.0 ) ; t913 [ 3543ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [
3544ULL ] = ( int32_T ) ( t1412 != 0.0 ) ; t913 [ 3545ULL ] = ( int32_T ) (
t1304 != 0.0 ) ; t913 [ 3546ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [
3547ULL ] = ( int32_T ) ( t1441 != 0.0 ) ; t913 [ 3548ULL ] = ( int32_T ) (
t1441 != 0.0 ) ; t913 [ 3549ULL ] = 1 ; t913 [ 3550ULL ] = ( int32_T ) (
t1441 != 0.0 ) ; t913 [ 3551ULL ] = 1 ; t913 [ 3552ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 != 0.0 ) ;
t913 [ 3553ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 != 0.0 ) ;
t913 [ 3554ULL ] = 1 ; t913 [ 3555ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Flow_Resistance_G_convection_B_2 != 0.0 ) ;
t913 [ 3556ULL ] = 1 ; t913 [ 3557ULL ] = ( int32_T ) ( t1441 != 0.0 ) ; t913
[ 3558ULL ] = ( int32_T ) ( t1441 != 0.0 ) ; t913 [ 3559ULL ] = 1 ; t913 [
3560ULL ] = ( int32_T ) ( t1441 != 0.0 ) ; t913 [ 3561ULL ] = 1 ; t913 [
3562ULL ] = 1 ; t913 [ 3563ULL ] = 1 ; t913 [ 3564ULL ] = 1 ; t913 [ 3565ULL
] = ( int32_T ) ( t2005 != 0.0 ) ; t913 [ 3566ULL ] = ( int32_T ) ( t2011 !=
0.0 ) ; t913 [ 3567ULL ] = ( int32_T ) ( t1304 != 0.0 ) ; t913 [ 3568ULL ] =
( int32_T ) ( t1304 != 0.0 ) ; t913 [ 3569ULL ] = 1 ; t913 [ 3570ULL ] = 1 ;
t913 [ 3571ULL ] = 1 ; t913 [ 3572ULL ] = ( int32_T ) ( X [ 200ULL ] != 0.0 )
; t913 [ 3573ULL ] = ( int32_T ) ( X [ 200ULL ] != 0.0 ) ; t913 [ 3574ULL ] =
1 ; t913 [ 3575ULL ] = 1 ; t913 [ 3576ULL ] = 1 ; t913 [ 3577ULL ] = (
int32_T ) ( X [ 204ULL ] != 0.0 ) ; t913 [ 3578ULL ] = ( int32_T ) ( X [
204ULL ] != 0.0 ) ; t913 [ 3579ULL ] = 1 ; t913 [ 3580ULL ] = 1 ; t913 [
3581ULL ] = 1 ; t913 [ 3582ULL ] = ( int32_T ) ( X [ 22ULL ] != 0.0 ) ; t913
[ 3583ULL ] = ( int32_T ) ( X [ 22ULL ] != 0.0 ) ; t913 [ 3584ULL ] = 1 ;
t913 [ 3585ULL ] = 1 ; t913 [ 3586ULL ] = 1 ; t913 [ 3587ULL ] = ( int32_T )
( X [ 22ULL ] != 0.0 ) ; t913 [ 3588ULL ] = ( int32_T ) ( X [ 22ULL ] != 0.0
) ; t913 [ 3589ULL ] = 1 ; t913 [ 3590ULL ] = 1 ; t913 [ 3591ULL ] = 1 ; t913
[ 3592ULL ] = 1 ; t913 [ 3593ULL ] = 1 ; t913 [ 3594ULL ] = 1 ; t913 [
3595ULL ] = 1 ; t913 [ 3596ULL ] = 1 ; t913 [ 3597ULL ] = 1 ; t913 [ 3598ULL
] = ( int32_T ) ( X [ 220ULL ] != 0.0 ) ; t913 [ 3599ULL ] = ( int32_T ) ( X
[ 220ULL ] != 0.0 ) ; t913 [ 3600ULL ] = ( int32_T ) ( t1491 != 0.0 ) ; t913
[ 3601ULL ] = 1 ; t913 [ 3602ULL ] = 1 ; t913 [ 3603ULL ] = 1 ; t913 [
3604ULL ] = ( int32_T ) ( X [ 246ULL ] != 0.0 ) ; t913 [ 3605ULL ] = (
int32_T ) ( X [ 246ULL ] != 0.0 ) ; t913 [ 3606ULL ] = 1 ; t913 [ 3607ULL ] =
1 ; t913 [ 3608ULL ] = 1 ; t913 [ 3609ULL ] = ( int32_T ) ( X [ 249ULL ] !=
0.0 ) ; t913 [ 3610ULL ] = ( int32_T ) ( X [ 249ULL ] != 0.0 ) ; t913 [
3611ULL ] = 1 ; t913 [ 3612ULL ] = 1 ; t913 [ 3613ULL ] = 1 ; t913 [ 3614ULL
] = ( int32_T ) ( X [ 31ULL ] != 0.0 ) ; t913 [ 3615ULL ] = ( int32_T ) ( X [
31ULL ] != 0.0 ) ; t913 [ 3616ULL ] = 1 ; t913 [ 3617ULL ] = 1 ; t913 [
3618ULL ] = 1 ; t913 [ 3619ULL ] = ( int32_T ) ( X [ 31ULL ] != 0.0 ) ; t913
[ 3620ULL ] = ( int32_T ) ( X [ 31ULL ] != 0.0 ) ; t913 [ 3621ULL ] = 1 ;
t913 [ 3622ULL ] = 1 ; t913 [ 3623ULL ] = 1 ; t913 [ 3624ULL ] = ( int32_T )
( X [ 264ULL ] != 0.0 ) ; t913 [ 3625ULL ] = ( int32_T ) ( X [ 264ULL ] !=
0.0 ) ; t913 [ 3626ULL ] = 1 ; t913 [ 3627ULL ] = 1 ; t913 [ 3628ULL ] = 1 ;
t913 [ 3629ULL ] = ( int32_T ) ( X [ 266ULL ] != 0.0 ) ; t913 [ 3630ULL ] = (
int32_T ) ( X [ 266ULL ] != 0.0 ) ; t913 [ 3631ULL ] = 1 ; t913 [ 3632ULL ] =
1 ; t913 [ 3633ULL ] = 1 ; t913 [ 3634ULL ] = ( int32_T ) ( X [ 33ULL ] !=
0.0 ) ; t913 [ 3635ULL ] = ( int32_T ) ( X [ 33ULL ] != 0.0 ) ; t913 [
3636ULL ] = 1 ; t913 [ 3637ULL ] = 1 ; t913 [ 3638ULL ] = 1 ; t913 [ 3639ULL
] = ( int32_T ) ( X [ 33ULL ] != 0.0 ) ; t913 [ 3640ULL ] = ( int32_T ) ( X [
33ULL ] != 0.0 ) ; t913 [ 3641ULL ] = 1 ; t913 [ 3642ULL ] = 1 ; t913 [
3643ULL ] = 1 ; t913 [ 3644ULL ] = ( int32_T ) ( X [ 290ULL ] != 0.0 ) ; t913
[ 3645ULL ] = ( int32_T ) ( X [ 290ULL ] != 0.0 ) ; t913 [ 3646ULL ] = 1 ;
t913 [ 3647ULL ] = 1 ; t913 [ 3648ULL ] = 1 ; t913 [ 3649ULL ] = ( int32_T )
( X [ 292ULL ] != 0.0 ) ; t913 [ 3650ULL ] = ( int32_T ) ( X [ 292ULL ] !=
0.0 ) ; t913 [ 3651ULL ] = 1 ; t913 [ 3652ULL ] = 1 ; t913 [ 3653ULL ] = 1 ;
t913 [ 3654ULL ] = ( int32_T ) ( X [ 37ULL ] != 0.0 ) ; t913 [ 3655ULL ] = (
int32_T ) ( X [ 37ULL ] != 0.0 ) ; t913 [ 3656ULL ] = 1 ; t913 [ 3657ULL ] =
1 ; t913 [ 3658ULL ] = 1 ; t913 [ 3659ULL ] = ( int32_T ) ( X [ 37ULL ] !=
0.0 ) ; t913 [ 3660ULL ] = ( int32_T ) ( X [ 37ULL ] != 0.0 ) ; t913 [
3661ULL ] = 1 ; t913 [ 3662ULL ] = 1 ; t913 [ 3663ULL ] = 1 ; t913 [ 3664ULL
] = 1 ; t913 [ 3665ULL ] = 1 ; t913 [ 3666ULL ] = 1 ; t913 [ 3667ULL ] = (
int32_T ) ( X [ 327ULL ] != 0.0 ) ; t913 [ 3668ULL ] = ( int32_T ) ( X [
327ULL ] != 0.0 ) ; t913 [ 3669ULL ] = 1 ; t913 [ 3670ULL ] = 1 ; t913 [
3671ULL ] = 1 ; t913 [ 3672ULL ] = ( int32_T ) ( X [ 331ULL ] != 0.0 ) ; t913
[ 3673ULL ] = ( int32_T ) ( X [ 331ULL ] != 0.0 ) ; t913 [ 3674ULL ] = 1 ;
t913 [ 3675ULL ] = 1 ; t913 [ 3676ULL ] = 1 ; t913 [ 3677ULL ] = ( int32_T )
( X [ 40ULL ] != 0.0 ) ; t913 [ 3678ULL ] = ( int32_T ) ( X [ 40ULL ] != 0.0
) ; t913 [ 3679ULL ] = 1 ; t913 [ 3680ULL ] = 1 ; t913 [ 3681ULL ] = 1 ; t913
[ 3682ULL ] = ( int32_T ) ( X [ 40ULL ] != 0.0 ) ; t913 [ 3683ULL ] = (
int32_T ) ( X [ 40ULL ] != 0.0 ) ; t913 [ 3684ULL ] = 1 ; t913 [ 3685ULL ] =
1 ; t913 [ 3686ULL ] = 1 ; t913 [ 3687ULL ] = 1 ; t913 [ 3688ULL ] = 1 ; t913
[ 3689ULL ] = 1 ; t913 [ 3690ULL ] = 1 ; t913 [ 3691ULL ] = 1 ; t913 [
3692ULL ] = 1 ; t913 [ 3693ULL ] = ( int32_T ) ( X [ 344ULL ] != 0.0 ) ; t913
[ 3694ULL ] = ( int32_T ) ( X [ 344ULL ] != 0.0 ) ; t913 [ 3695ULL ] = (
int32_T ) ( intrm_sf_mf_829 != 0.0 ) ; t913 [ 3696ULL ] = 1 ; t913 [ 3697ULL
] = 1 ; t913 [ 3698ULL ] = 1 ; t913 [ 3699ULL ] = ( int32_T ) ( X [ 370ULL ]
!= 0.0 ) ; t913 [ 3700ULL ] = ( int32_T ) ( X [ 370ULL ] != 0.0 ) ; t913 [
3701ULL ] = 1 ; t913 [ 3702ULL ] = 1 ; t913 [ 3703ULL ] = 1 ; t913 [ 3704ULL
] = ( int32_T ) ( X [ 373ULL ] != 0.0 ) ; t913 [ 3705ULL ] = ( int32_T ) ( X
[ 373ULL ] != 0.0 ) ; t913 [ 3706ULL ] = 1 ; t913 [ 3707ULL ] = 1 ; t913 [
3708ULL ] = 1 ; t913 [ 3709ULL ] = ( int32_T ) ( X [ 49ULL ] != 0.0 ) ; t913
[ 3710ULL ] = ( int32_T ) ( X [ 49ULL ] != 0.0 ) ; t913 [ 3711ULL ] = 1 ;
t913 [ 3712ULL ] = 1 ; t913 [ 3713ULL ] = 1 ; t913 [ 3714ULL ] = ( int32_T )
( X [ 49ULL ] != 0.0 ) ; t913 [ 3715ULL ] = ( int32_T ) ( X [ 49ULL ] != 0.0
) ; t913 [ 3716ULL ] = 1 ; t913 [ 3717ULL ] = 1 ; t913 [ 3718ULL ] = 1 ; t913
[ 3719ULL ] = ( int32_T ) ( X [ 388ULL ] != 0.0 ) ; t913 [ 3720ULL ] = (
int32_T ) ( X [ 388ULL ] != 0.0 ) ; t913 [ 3721ULL ] = 1 ; t913 [ 3722ULL ] =
1 ; t913 [ 3723ULL ] = 1 ; t913 [ 3724ULL ] = ( int32_T ) ( X [ 390ULL ] !=
0.0 ) ; t913 [ 3725ULL ] = ( int32_T ) ( X [ 390ULL ] != 0.0 ) ; t913 [
3726ULL ] = 1 ; t913 [ 3727ULL ] = 1 ; t913 [ 3728ULL ] = 1 ; t913 [ 3729ULL
] = ( int32_T ) ( X [ 50ULL ] != 0.0 ) ; t913 [ 3730ULL ] = ( int32_T ) ( X [
50ULL ] != 0.0 ) ; t913 [ 3731ULL ] = 1 ; t913 [ 3732ULL ] = 1 ; t913 [
3733ULL ] = 1 ; t913 [ 3734ULL ] = ( int32_T ) ( X [ 50ULL ] != 0.0 ) ; t913
[ 3735ULL ] = ( int32_T ) ( X [ 50ULL ] != 0.0 ) ; t913 [ 3736ULL ] = 1 ;
t913 [ 3737ULL ] = 1 ; t913 [ 3738ULL ] = 1 ; t913 [ 3739ULL ] = ( int32_T )
( X [ 415ULL ] != 0.0 ) ; t913 [ 3740ULL ] = ( int32_T ) ( X [ 415ULL ] !=
0.0 ) ; t913 [ 3741ULL ] = 1 ; t913 [ 3742ULL ] = 1 ; t913 [ 3743ULL ] = 1 ;
t913 [ 3744ULL ] = ( int32_T ) ( X [ 417ULL ] != 0.0 ) ; t913 [ 3745ULL ] = (
int32_T ) ( X [ 417ULL ] != 0.0 ) ; t913 [ 3746ULL ] = 1 ; t913 [ 3747ULL ] =
1 ; t913 [ 3748ULL ] = 1 ; t913 [ 3749ULL ] = ( int32_T ) ( X [ 54ULL ] !=
0.0 ) ; t913 [ 3750ULL ] = ( int32_T ) ( X [ 54ULL ] != 0.0 ) ; t913 [
3751ULL ] = 1 ; t913 [ 3752ULL ] = 1 ; t913 [ 3753ULL ] = 1 ; t913 [ 3754ULL
] = ( int32_T ) ( X [ 54ULL ] != 0.0 ) ; t913 [ 3755ULL ] = ( int32_T ) ( X [
54ULL ] != 0.0 ) ; t913 [ 3756ULL ] = 1 ; t913 [ 3757ULL ] = 1 ; t913 [
3758ULL ] = 1 ; t913 [ 3759ULL ] = ( int32_T ) ( intrm_sf_mf_1227 != 0.0 ) ;
t913 [ 3760ULL ] = ( int32_T ) ( t1838 != 0.0 ) ; t913 [ 3761ULL ] = (
int32_T ) ( t1838 != 0.0 ) ; t913 [ 3762ULL ] = 1 ; t913 [ 3763ULL ] = 1 ;
t913 [ 3764ULL ] = ( int32_T ) ( ( X [ 442ULL ] * X [ 442ULL ] + 1.0E-8 == X
[ 442ULL ] * X [ 442ULL ] + 1.0E-8 ) && ( fabs ( X [ 442ULL ] * X [ 442ULL ]
+ 1.0E-8 ) != pmf_get_inf ( ) ) ) ; t913 [ 3765ULL ] = ( int32_T ) ( ( ! ( X
[ 442ULL ] * X [ 442ULL ] + 1.0E-8 == X [ 442ULL ] * X [ 442ULL ] + 1.0E-8 )
) || ( ! ( fabs ( X [ 442ULL ] * X [ 442ULL ] + 1.0E-8 ) != pmf_get_inf ( ) )
) || ( X [ 442ULL ] * X [ 442ULL ] + 1.0E-8 >= 0.0 ) ) ; t913 [ 3766ULL ] = (
int32_T ) ( t1849 != 0.0 ) ; t913 [ 3767ULL ] = ( int32_T ) ( t1853 != 0.0 )
; t913 [ 3768ULL ] = ( int32_T ) ( t1859 != 0.0 ) ; t913 [ 3769ULL ] = (
int32_T ) ( t1859 != 0.0 ) ; t913 [ 3770ULL ] = ( int32_T ) ( t1873 != 0.0 )
; t913 [ 3771ULL ] = ( int32_T ) ( t1875 != 0.0 ) ; t913 [ 3772ULL ] = (
int32_T ) ( X [ 64ULL ] != 0.0 ) ; t913 [ 3773ULL ] = ( int32_T ) ( X [ 64ULL
] != 0.0 ) ; t913 [ 3774ULL ] = 1 ; t913 [ 3775ULL ] = 1 ; t913 [ 3776ULL ] =
1 ; t913 [ 3777ULL ] = ( int32_T ) ( X [ 489ULL ] != 0.0 ) ; t913 [ 3778ULL ]
= ( int32_T ) ( X [ 489ULL ] != 0.0 ) ; t913 [ 3779ULL ] = 1 ; t913 [ 3780ULL
] = 1 ; t913 [ 3781ULL ] = 1 ; t913 [ 3782ULL ] = ( int32_T ) ( X [ 494ULL ]
!= 0.0 ) ; t913 [ 3783ULL ] = ( int32_T ) ( X [ 494ULL ] != 0.0 ) ; t913 [
3784ULL ] = 1 ; t913 [ 3785ULL ] = 1 ; t913 [ 3786ULL ] = 1 ; t913 [ 3787ULL
] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ; t913 [ 3788ULL ] = ( int32_T ) ( X [
68ULL ] != 0.0 ) ; t913 [ 3789ULL ] = 1 ; t913 [ 3790ULL ] = 1 ; t913 [
3791ULL ] = 1 ; t913 [ 3792ULL ] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ; t913
[ 3793ULL ] = ( int32_T ) ( X [ 68ULL ] != 0.0 ) ; t913 [ 3794ULL ] = 1 ;
t913 [ 3795ULL ] = 1 ; t913 [ 3796ULL ] = 1 ; t913 [ 3797ULL ] = 1 ; t913 [
3798ULL ] = 1 ; t913 [ 3799ULL ] = 1 ; t913 [ 3800ULL ] = 1 ; t913 [ 3801ULL
] = 1 ; t913 [ 3802ULL ] = 1 ; t913 [ 3803ULL ] = ( int32_T ) ( X [ 507ULL ]
!= 0.0 ) ; t913 [ 3804ULL ] = ( int32_T ) ( X [ 507ULL ] != 0.0 ) ; t913 [
3805ULL ] = ( int32_T ) ( t1941 != 0.0 ) ; t913 [ 3806ULL ] = 1 ; t913 [
3807ULL ] = 1 ; t913 [ 3808ULL ] = 1 ; t913 [ 3809ULL ] = 1 ; t913 [ 3810ULL
] = 1 ; t913 [ 3811ULL ] = 1 ; t913 [ 3812ULL ] = ( int32_T ) ( X [ 541ULL ]
!= 0.0 ) ; t913 [ 3813ULL ] = ( int32_T ) ( ( X [ 513ULL ] *
0.00347041471455839 == X [ 513ULL ] * 0.00347041471455839 ) && ( fabs ( X [
513ULL ] * 0.00347041471455839 ) != pmf_get_inf ( ) ) ) ; t913 [ 3814ULL ] =
( int32_T ) ( ( ! ( X [ 513ULL ] * 0.00347041471455839 == X [ 513ULL ] *
0.00347041471455839 ) ) || ( ! ( fabs ( X [ 513ULL ] * 0.00347041471455839 )
!= pmf_get_inf ( ) ) ) || ( X [ 513ULL ] * 0.00347041471455839 >= 0.0 ) ) ;
t913 [ 3815ULL ] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 3816ULL ] = (
int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [ 3817ULL ] = 1 ; t913 [ 3818ULL ] =
1 ; t913 [ 3819ULL ] = 1 ; t913 [ 3820ULL ] = ( int32_T ) ( X [ 55ULL ] !=
0.0 ) ; t913 [ 3821ULL ] = ( int32_T ) ( X [ 55ULL ] != 0.0 ) ; t913 [
3822ULL ] = 1 ; t913 [ 3823ULL ] = 1 ; t913 [ 3824ULL ] = 1 ; t913 [ 3825ULL
] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913 [ 3826ULL ] = ( int32_T ) ( X [
38ULL ] != 0.0 ) ; t913 [ 3827ULL ] = 1 ; t913 [ 3828ULL ] = 1 ; t913 [
3829ULL ] = 1 ; t913 [ 3830ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913
[ 3831ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0 ) ; t913 [ 3832ULL ] = 1 ;
t913 [ 3833ULL ] = 1 ; t913 [ 3834ULL ] = 1 ; t913 [ 3835ULL ] = ( int32_T )
( X [ 38ULL ] != 0.0 ) ; t913 [ 3836ULL ] = ( int32_T ) ( X [ 38ULL ] != 0.0
) ; t913 [ 3837ULL ] = 1 ; t913 [ 3838ULL ] = 1 ; t913 [ 3839ULL ] = 1 ; t913
[ 3840ULL ] = 1 ; t913 [ 3841ULL ] = 1 ; t913 [ 3842ULL ] = 1 ; t913 [
3843ULL ] = ( int32_T ) ( X [ 89ULL ] != 0.0 ) ; t913 [ 3844ULL ] = 1 ; t913
[ 3845ULL ] = 1 ; for ( b = 0 ; b < 3846 ; b ++ ) { out . mX [ b ] = t913 [ b
] ; } ( void ) LC ; ( void ) t2781 ; return 0 ; }
