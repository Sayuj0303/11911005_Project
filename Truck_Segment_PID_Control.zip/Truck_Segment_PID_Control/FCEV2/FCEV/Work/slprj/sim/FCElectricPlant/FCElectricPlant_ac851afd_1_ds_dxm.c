#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_dxm.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_dxm ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t1132 , NeDsMethodOutput * t1133 ) { ETTS0
ab_efOut ; ETTS0 b_efOut ; ETTS0 efOut ; ETTS0 g_efOut ; ETTS0 gb_efOut ;
ETTS0 h_efOut ; ETTS0 hb_efOut ; ETTS0 m_efOut ; ETTS0 n_efOut ; ETTS0
nb_efOut ; ETTS0 ob_efOut ; ETTS0 s_efOut ; ETTS0 t10 ; ETTS0 t11 ; ETTS0 t13
; ETTS0 t14 ; ETTS0 t16 ; ETTS0 t18 ; ETTS0 t26 ; ETTS0 t27 ; ETTS0 t28 ;
ETTS0 t29 ; ETTS0 t30 ; ETTS0 t31 ; ETTS0 t7 ; ETTS0 t9 ; ETTS0 t_efOut ;
ETTS0 y_efOut ; PmRealVector out ; real_T X [ 582 ] ; real_T t323 [ 298 ] ;
real_T t462 [ 8 ] ; real_T t408 [ 6 ] ; real_T t409 [ 6 ] ; real_T t463 [ 6 ]
; real_T t410 [ 5 ] ; real_T t411 [ 5 ] ; real_T t412 [ 5 ] ; real_T t413 [ 5
] ; real_T t414 [ 5 ] ; real_T t415 [ 5 ] ; real_T t416 [ 5 ] ; real_T t417 [
5 ] ; real_T t418 [ 5 ] ; real_T t419 [ 5 ] ; real_T t420 [ 5 ] ; real_T t421
[ 5 ] ; real_T t422 [ 5 ] ; real_T t423 [ 5 ] ; real_T t424 [ 5 ] ; real_T
t425 [ 5 ] ; real_T t426 [ 5 ] ; real_T t427 [ 5 ] ; real_T t428 [ 5 ] ;
real_T t429 [ 5 ] ; real_T t430 [ 5 ] ; real_T t431 [ 5 ] ; real_T t432 [ 5 ]
; real_T t433 [ 5 ] ; real_T t434 [ 5 ] ; real_T t435 [ 5 ] ; real_T t436 [ 5
] ; real_T t437 [ 5 ] ; real_T t438 [ 5 ] ; real_T t439 [ 5 ] ; real_T t440 [
5 ] ; real_T t441 [ 5 ] ; real_T t442 [ 5 ] ; real_T t443 [ 5 ] ; real_T t448
[ 5 ] ; real_T t449 [ 5 ] ; real_T t450 [ 5 ] ; real_T t451 [ 5 ] ; real_T
t452 [ 5 ] ; real_T t453 [ 5 ] ; real_T t454 [ 5 ] ; real_T t455 [ 5 ] ;
real_T t456 [ 5 ] ; real_T t457 [ 5 ] ; real_T t458 [ 5 ] ; real_T t459 [ 5 ]
; real_T t460 [ 5 ] ; real_T t461 [ 5 ] ; real_T t407 [ 4 ] ; real_T t444 [ 4
] ; real_T t445 [ 4 ] ; real_T t446 [ 4 ] ; real_T t447 [ 4 ] ; real_T t548 [
2 ] ; real_T t549 [ 2 ] ; real_T t551 [ 2 ] ; real_T t555 [ 2 ] ; real_T t557
[ 2 ] ; real_T t560 [ 2 ] ; real_T t561 [ 2 ] ; real_T ac_efOut [ 1 ] ;
real_T ad_efOut [ 1 ] ; real_T bb_efOut [ 1 ] ; real_T bc_efOut [ 1 ] ;
real_T bd_efOut [ 1 ] ; real_T c_efOut [ 1 ] ; real_T cb_efOut [ 1 ] ; real_T
cc_efOut [ 1 ] ; real_T cd_efOut [ 1 ] ; real_T d_efOut [ 1 ] ; real_T
db_efOut [ 1 ] ; real_T dc_efOut [ 1 ] ; real_T dd_efOut [ 1 ] ; real_T
e_efOut [ 1 ] ; real_T eb_efOut [ 1 ] ; real_T ec_efOut [ 1 ] ; real_T
ed_efOut [ 1 ] ; real_T f_efOut [ 1 ] ; real_T fb_efOut [ 1 ] ; real_T
fc_efOut [ 1 ] ; real_T fd_efOut [ 1 ] ; real_T gc_efOut [ 1 ] ; real_T
gd_efOut [ 1 ] ; real_T hc_efOut [ 1 ] ; real_T hd_efOut [ 1 ] ; real_T
i_efOut [ 1 ] ; real_T ib_efOut [ 1 ] ; real_T ic_efOut [ 1 ] ; real_T
id_efOut [ 1 ] ; real_T j_efOut [ 1 ] ; real_T jb_efOut [ 1 ] ; real_T
jc_efOut [ 1 ] ; real_T jd_efOut [ 1 ] ; real_T k_efOut [ 1 ] ; real_T
kb_efOut [ 1 ] ; real_T kc_efOut [ 1 ] ; real_T kd_efOut [ 1 ] ; real_T
l_efOut [ 1 ] ; real_T lb_efOut [ 1 ] ; real_T lc_efOut [ 1 ] ; real_T
ld_efOut [ 1 ] ; real_T mb_efOut [ 1 ] ; real_T mc_efOut [ 1 ] ; real_T
md_efOut [ 1 ] ; real_T nc_efOut [ 1 ] ; real_T nd_efOut [ 1 ] ; real_T
o_efOut [ 1 ] ; real_T oc_efOut [ 1 ] ; real_T od_efOut [ 1 ] ; real_T
p_efOut [ 1 ] ; real_T pb_efOut [ 1 ] ; real_T pc_efOut [ 1 ] ; real_T
pd_efOut [ 1 ] ; real_T q_efOut [ 1 ] ; real_T qb_efOut [ 1 ] ; real_T
qc_efOut [ 1 ] ; real_T qd_efOut [ 1 ] ; real_T r_efOut [ 1 ] ; real_T
rb_efOut [ 1 ] ; real_T rc_efOut [ 1 ] ; real_T rd_efOut [ 1 ] ; real_T
sb_efOut [ 1 ] ; real_T sc_efOut [ 1 ] ; real_T sd_efOut [ 1 ] ; real_T t360
[ 1 ] ; real_T t361 [ 1 ] ; real_T t362 [ 1 ] ; real_T t406 [ 1 ] ; real_T
tb_efOut [ 1 ] ; real_T tc_efOut [ 1 ] ; real_T td_efOut [ 1 ] ; real_T
u_efOut [ 1 ] ; real_T ub_efOut [ 1 ] ; real_T uc_efOut [ 1 ] ; real_T
ud_efOut [ 1 ] ; real_T v_efOut [ 1 ] ; real_T vb_efOut [ 1 ] ; real_T
vc_efOut [ 1 ] ; real_T vd_efOut [ 1 ] ; real_T w_efOut [ 1 ] ; real_T
wb_efOut [ 1 ] ; real_T wc_efOut [ 1 ] ; real_T x_efOut [ 1 ] ; real_T
xb_efOut [ 1 ] ; real_T xc_efOut [ 1 ] ; real_T yb_efOut [ 1 ] ; real_T
yc_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_cv_I ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_cv_I ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_cv_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant11 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 ; real_T
intermediate_der1975 ; real_T intermediate_der2018 ; real_T
intermediate_der2020 ; real_T intermediate_der2021 ; real_T
intermediate_der249 ; real_T intermediate_der250 ; real_T intermediate_der251
; real_T intermediate_der252 ; real_T intermediate_der253 ; real_T
intermediate_der2531 ; real_T intermediate_der2532 ; real_T
intermediate_der2533 ; real_T intermediate_der2576 ; real_T
intermediate_der2578 ; real_T intermediate_der2579 ; real_T
intermediate_der3090 ; real_T intermediate_der3091 ; real_T
intermediate_der3092 ; real_T intermediate_der3135 ; real_T
intermediate_der3137 ; real_T intermediate_der3138 ; real_T
intermediate_der366 ; real_T intermediate_der3779 ; real_T
intermediate_der3780 ; real_T intermediate_der3781 ; real_T
intermediate_der3824 ; real_T intermediate_der3826 ; real_T
intermediate_der3827 ; real_T intermediate_der387 ; real_T
intermediate_der389 ; real_T intermediate_der4343 ; real_T
intermediate_der4344 ; real_T intermediate_der4387 ; real_T
intermediate_der4389 ; real_T intermediate_der4390 ; real_T
intermediate_der4901 ; real_T intermediate_der4902 ; real_T
intermediate_der4945 ; real_T intermediate_der4947 ; real_T
intermediate_der4948 ; real_T intermediate_der496 ; real_T
intermediate_der499 ; real_T intermediate_der501 ; real_T intermediate_der518
; real_T intermediate_der5458 ; real_T intermediate_der5464 ; real_T
intermediate_der5505 ; real_T intermediate_der5506 ; real_T
intermediate_der5530 ; real_T intermediate_der5532 ; real_T
intermediate_der5533 ; real_T intermediate_der5588 ; real_T
intermediate_der5589 ; real_T intermediate_der5615 ; real_T
intermediate_der5616 ; real_T intermediate_der5617 ; real_T
intermediate_der5618 ; real_T intermediate_der6295 ; real_T
intermediate_der6371 ; real_T intermediate_der6372 ; real_T
intermediate_der6415 ; real_T intermediate_der6417 ; real_T
intermediate_der6418 ; real_T intermediate_der691 ; real_T
intermediate_der7150 ; real_T intermediate_der7151 ; real_T
intermediate_der7152 ; real_T intermediate_der7154 ; real_T
intermediate_der7155 ; real_T intermediate_der7244 ; real_T
intermediate_der7245 ; real_T intermediate_der7246 ; real_T
intermediate_der7248 ; real_T intermediate_der7249 ; real_T
intermediate_der737 ; real_T intermediate_der7477 ; real_T
intermediate_der7478 ; real_T intermediate_der7612 ; real_T
intermediate_der7613 ; real_T intermediate_der7614 ; real_T
intermediate_der8176 ; real_T intermediate_der8177 ; real_T
intermediate_der8178 ; real_T intermediate_der8217 ; real_T
intermediate_der8219 ; real_T intermediate_der8370 ; real_T
intermediate_der8371 ; real_T intermediate_der8372 ; real_T
intermediate_der8383 ; real_T intermediate_der8384 ; real_T
intermediate_der8385 ; real_T intermediate_der8476 ; real_T
intermediate_der8477 ; real_T intermediate_der8479 ; real_T
intermediate_der8481 ; real_T intermediate_der8484 ; real_T
intermediate_der8485 ; real_T intermediate_der8490 ; real_T
intermediate_der8492 ; real_T intermediate_der8496 ; real_T
intermediate_der8769 ; real_T intermediate_der8770 ; real_T
intermediate_der8975 ; real_T intermediate_der9128 ; real_T
intermediate_der9129 ; real_T intermediate_der9130 ; real_T
intermediate_der9297 ; real_T intermediate_der9298 ; real_T
intermediate_der9299 ; real_T intermediate_der9438 ; real_T
intermediate_der9439 ; real_T intermediate_der9440 ; real_T
intermediate_der9572 ; real_T intermediate_der9573 ; real_T
intermediate_der9574 ; real_T intrm_sf_mf_1006 ; real_T intrm_sf_mf_1113 ;
real_T intrm_sf_mf_1144 ; real_T intrm_sf_mf_1251 ; real_T intrm_sf_mf_1380 ;
real_T intrm_sf_mf_1393 ; real_T intrm_sf_mf_1399 ; real_T intrm_sf_mf_1506 ;
real_T intrm_sf_mf_1634 ; real_T intrm_sf_mf_1653 ; real_T intrm_sf_mf_1659 ;
real_T intrm_sf_mf_1684 ; real_T intrm_sf_mf_1792 ; real_T intrm_sf_mf_1793 ;
real_T intrm_sf_mf_202 ; real_T intrm_sf_mf_270 ; real_T intrm_sf_mf_377 ;
real_T intrm_sf_mf_407 ; real_T intrm_sf_mf_514 ; real_T intrm_sf_mf_545 ;
real_T intrm_sf_mf_652 ; real_T intrm_sf_mf_694 ; real_T intrm_sf_mf_801 ;
real_T intrm_sf_mf_869 ; real_T intrm_sf_mf_976 ; real_T t1085 ; real_T t1090
; real_T t1110 ; real_T t1118 ; real_T t1128 ; real_T t1130 ; real_T t1131 ;
real_T t348_idx_0 ; real_T t565 ; real_T t568 ; real_T t571 ; real_T t574 ;
real_T t577 ; real_T t580 ; real_T t583 ; real_T t586 ; real_T t589 ; real_T
t643 ; real_T t646 ; real_T t649 ; real_T t652 ; real_T t655 ; real_T t658 ;
real_T t667 ; real_T t670 ; real_T t673 ; real_T t676 ; real_T t678 ; real_T
t679 ; real_T t681 ; real_T t682 ; real_T t686 ; real_T t688 ; real_T t690 ;
real_T t692 ; real_T t694 ; real_T t696 ; real_T t698 ; real_T t699 ; real_T
t700 ; real_T t701 ; real_T t703 ; real_T t705 ; real_T t707 ; real_T t709 ;
real_T t710 ; real_T t711 ; real_T t712 ; real_T t715 ; real_T t718 ; real_T
t719 ; real_T t720 ; real_T t721 ; real_T t724 ; real_T t727 ; real_T t728 ;
real_T t729 ; real_T t730 ; real_T t733 ; real_T t736 ; real_T t738 ; real_T
t739 ; real_T t745 ; real_T t746 ; real_T t752 ; real_T t753 ; real_T t759 ;
real_T t760 ; real_T t766 ; real_T t767 ; real_T t773 ; real_T t774 ; real_T
t781 ; real_T t787 ; real_T t788 ; real_T t794 ; real_T t796 ; real_T t797 ;
real_T t801 ; real_T t802 ; real_T t805 ; real_T t806 ; real_T t807 ; real_T
t810 ; real_T t811 ; real_T t812 ; real_T t817 ; real_T t818 ; real_T t824 ;
real_T t825 ; real_T t831 ; real_T t838 ; real_T t839 ; real_T t845 ; real_T
t847 ; real_T t850 ; real_T t857 ; real_T t858 ; real_T t875 ; real_T t878 ;
real_T t889 ; real_T t892 ; size_t t33 [ 1 ] ; size_t t34 [ 1 ] ; size_t t36
[ 1 ] ; size_t t547 [ 1 ] ; size_t t550 [ 1 ] ; size_t t553 [ 1 ] ; size_t
t556 [ 1 ] ; size_t t559 [ 1 ] ; size_t t562 [ 1 ] ; size_t t87 [ 1 ] ;
size_t t90 [ 1 ] ; size_t t519 ; int32_T b ; for ( b = 0 ; b < 582 ; b ++ ) {
X [ b ] = t1132 -> mX . mX [ b ] ; } out = t1133 -> mDXM ; t406 [ 0ULL ] = X
[ 6ULL ] ; t33 [ 0 ] = 20ULL ; t34 [ 0 ] = 1ULL ;
tlu2_linear_linear_prelookup ( & efOut . mField0 [ 0ULL ] , & efOut . mField1
[ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField2 , & t406 [ 0ULL ] , & t33 [ 0ULL ] , & t34 [ 0ULL ] ) ; t31 = efOut ;
t560 [ 0ULL ] = t31 . mField0 [ 0ULL ] ; t560 [ 1ULL ] = t31 . mField0 [ 1ULL
] ; t561 [ 0ULL ] = t31 . mField1 [ 0ULL ] ; t561 [ 1ULL ] = t31 . mField1 [
1ULL ] ; t562 [ 0ULL ] = t31 . mField2 [ 0ULL ] ; t362 [ 0ULL ] = ( X [
113ULL ] + X [ 120ULL ] ) / 2.0 ; t36 [ 0 ] = 19ULL ;
tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t362 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t30
= b_efOut ; t557 [ 0ULL ] = t30 . mField0 [ 0ULL ] ; t557 [ 1ULL ] = t30 .
mField0 [ 1ULL ] ; t559 [ 0ULL ] = t30 . mField2 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & c_efOut [ 0ULL ] , & t560 [ 0ULL ] , & t562 [
0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t361 [ 0
] = c_efOut [ 0 ] ; t1130 = t361 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
d_efOut [ 0ULL ] , & t560 [ 0ULL ] , & t562 [ 0ULL ] , & t557 [ 0ULL ] , &
t559 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL
] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t360 [ 0 ] = d_efOut [ 0 ] ;
intermediate_der389 = t360 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & e_efOut
[ 0ULL ] , & t560 [ 0ULL ] , & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = e_efOut [ 0 ] ;
intermediate_der496 = t348_idx_0 ; tlu2_2d_linear_linear_value ( & f_efOut [
0ULL ] , & t560 [ 0ULL ] , & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33 [ 0ULL ] , & t36 [
0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = f_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I = t348_idx_0 ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_cv_I =
intermediate_der496 - t1130 * t1130 * X [ 6ULL ] * intermediate_der389 / (
t348_idx_0 == 0.0 ? 1.0E-16 : t348_idx_0 ) * 100000.0 ; t361 [ 0ULL ] = X [
9ULL ] ; tlu2_linear_linear_prelookup ( & g_efOut . mField0 [ 0ULL ] , &
g_efOut . mField1 [ 0ULL ] , & g_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t361 [ 0ULL ] , & t33 [ 0ULL ] ,
& t34 [ 0ULL ] ) ; t29 = g_efOut ; t560 [ 0ULL ] = t29 . mField0 [ 0ULL ] ;
t560 [ 1ULL ] = t29 . mField0 [ 1ULL ] ; t555 [ 0ULL ] = t29 . mField1 [ 0ULL
] ; t555 [ 1ULL ] = t29 . mField1 [ 1ULL ] ; t556 [ 0ULL ] = t29 . mField2 [
0ULL ] ; t360 [ 0ULL ] = ( X [ 95ULL ] + X [ 102ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & h_efOut . mField0 [ 0ULL ] , & h_efOut .
mField1 [ 0ULL ] , & h_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t360 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t28
= h_efOut ; t551 [ 0ULL ] = t28 . mField0 [ 0ULL ] ; t551 [ 1ULL ] = t28 .
mField0 [ 1ULL ] ; t553 [ 0ULL ] = t28 . mField2 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & i_efOut [ 0ULL ] , & t560 [ 0ULL ] , & t556 [
0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = i_efOut [ 0 ] ; intermediate_der496 = t348_idx_0 ;
tlu2_2d_linear_linear_value ( & j_efOut [ 0ULL ] , & t560 [ 0ULL ] , & t556 [
0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField10 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = j_efOut [ 0 ] ; t678 = t348_idx_0 ; tlu2_2d_linear_linear_value
( & k_efOut [ 0ULL ] , & t560 [ 0ULL ] , & t556 [ 0ULL ] , & t551 [ 0ULL ] ,
& t553 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [
0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = k_efOut [ 0 ] ;
t679 = t348_idx_0 ; tlu2_2d_linear_linear_value ( & l_efOut [ 0ULL ] , & t560
[ 0ULL ] , & t556 [ 0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33 [ 0ULL ] , & t36 [ 0ULL ] ,
& t34 [ 0ULL ] ) ; t348_idx_0 = l_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I = t348_idx_0 ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_cv_I = t679 -
intermediate_der496 * intermediate_der496 * X [ 9ULL ] * t678 / ( t348_idx_0
== 0.0 ? 1.0E-16 : t348_idx_0 ) * 100000.0 ; t360 [ 0ULL ] = X [ 11ULL ] ;
tlu2_linear_linear_prelookup ( & m_efOut . mField0 [ 0ULL ] , & m_efOut .
mField1 [ 0ULL ] , & m_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t360 [ 0ULL ] , & t33 [ 0ULL ] , & t34 [ 0ULL ] ) ; t27
= m_efOut ; t548 [ 0ULL ] = t27 . mField0 [ 0ULL ] ; t548 [ 1ULL ] = t27 .
mField0 [ 1ULL ] ; t549 [ 0ULL ] = t27 . mField1 [ 0ULL ] ; t549 [ 1ULL ] =
t27 . mField1 [ 1ULL ] ; t550 [ 0ULL ] = t27 . mField2 [ 0ULL ] ; t360 [ 0ULL
] = ( X [ 104ULL ] + X [ 111ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( &
n_efOut . mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t360 [
0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t26 = n_efOut ; t560 [ 0ULL ] =
t26 . mField0 [ 0ULL ] ; t560 [ 1ULL ] = t26 . mField0 [ 1ULL ] ; t547 [ 0ULL
] = t26 . mField2 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & o_efOut [ 0ULL ]
, & t548 [ 0ULL ] , & t550 [ 0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] ,
& t34 [ 0ULL ] ) ; t348_idx_0 = o_efOut [ 0 ] ; t679 = t348_idx_0 ;
tlu2_2d_linear_linear_value ( & p_efOut [ 0ULL ] , & t548 [ 0ULL ] , & t550 [
0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField10 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = p_efOut [ 0 ] ; t1128 = t348_idx_0 ; tlu2_2d_linear_linear_value
( & q_efOut [ 0ULL ] , & t548 [ 0ULL ] , & t550 [ 0ULL ] , & t560 [ 0ULL ] ,
& t547 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [
0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = q_efOut [ 0 ] ;
t681 = t348_idx_0 ; tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t548
[ 0ULL ] , & t550 [ 0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33 [ 0ULL ] , & t36 [ 0ULL ] ,
& t34 [ 0ULL ] ) ; t348_idx_0 = r_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I = t348_idx_0 ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_cv_I = t681 - t679 * t679 * X
[ 11ULL ] * t1128 / ( t348_idx_0 == 0.0 ? 1.0E-16 : t348_idx_0 ) * 100000.0 ;
t682 = X [ 158ULL ] * - 0.2 + 0.2 ; if ( X [ 23ULL ] <= 0.0 ) { t1118 = 0.0 ;
} else { t1118 = X [ 23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ]
<= 0.0 ) { t1110 = 0.0 ; } else { t1110 = X [ 24ULL ] >= 1.0 ? 1.0 : X [
24ULL ] ; } t1090 = ( ( ( 1.0 - t1118 ) - t1110 ) * 296.802103844292 + t1118
* 461.523 ) + t1110 * 4124.48151675695 ; t875 = X [ 21ULL ] * t1090 ; t1085 =
X [ 22ULL ] / ( t875 == 0.0 ? 1.0E-16 : t875 ) ; if ( X [ 21ULL ] <=
216.59999999999997 ) { intermediate_der8975 = 216.59999999999997 ; } else {
intermediate_der8975 = X [ 21ULL ] >= 623.15 ? 623.15 : X [ 21ULL ] ; } t565
= intermediate_der8975 * intermediate_der8975 ; if ( X [ 27ULL ] <= 0.0 ) {
intermediate_der9128 = 0.0 ; } else { intermediate_der9128 = X [ 27ULL ] >=
1.0 ? 1.0 : X [ 27ULL ] ; } if ( X [ 26ULL ] <= 0.0 ) { intermediate_der9129
= 0.0 ; } else { intermediate_der9129 = X [ 26ULL ] >= 1.0 ? 1.0 : X [ 26ULL
] ; } intrm_sf_mf_270 = ( ( ( 1.0 - intermediate_der9128 ) -
intermediate_der9129 ) * 296.802103844292 + intermediate_der9128 * 461.523 )
+ intermediate_der9129 * 4124.48151675695 ; t686 = X [ 25ULL ] *
intrm_sf_mf_270 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 = X [ 31ULL ]
/ ( t686 == 0.0 ? 1.0E-16 : t686 ) ; if ( X [ 25ULL ] <= 216.59999999999997 )
{ intermediate_der9130 = 216.59999999999997 ; } else { intermediate_der9130 =
X [ 25ULL ] >= 623.15 ? 623.15 : X [ 25ULL ] ; } t568 = intermediate_der9130
* intermediate_der9130 ; if ( X [ 30ULL ] <= 0.0 ) { intermediate_der9297 =
0.0 ; } else { intermediate_der9297 = X [ 30ULL ] >= 1.0 ? 1.0 : X [ 30ULL ]
; } if ( X [ 29ULL ] <= 0.0 ) { intermediate_der9298 = 0.0 ; } else {
intermediate_der9298 = X [ 29ULL ] >= 1.0 ? 1.0 : X [ 29ULL ] ; }
intrm_sf_mf_407 = ( ( ( 1.0 - intermediate_der9297 ) - intermediate_der9298 )
* 296.802103844292 + intermediate_der9297 * 461.523 ) + intermediate_der9298
* 4124.48151675695 ; t688 = X [ 28ULL ] * intrm_sf_mf_407 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 = X [ 33ULL ]
/ ( t688 == 0.0 ? 1.0E-16 : t688 ) ; if ( X [ 28ULL ] <= 216.59999999999997 )
{ intermediate_der9299 = 216.59999999999997 ; } else { intermediate_der9299 =
X [ 28ULL ] >= 623.15 ? 623.15 : X [ 28ULL ] ; } t571 = intermediate_der9299
* intermediate_der9299 ; if ( X [ 36ULL ] <= 0.0 ) { intermediate_der9438 =
0.0 ; } else { intermediate_der9438 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ]
; } if ( X [ 35ULL ] <= 0.0 ) { intermediate_der9439 = 0.0 ; } else {
intermediate_der9439 = X [ 35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; }
intrm_sf_mf_545 = ( ( ( 1.0 - intermediate_der9438 ) - intermediate_der9439 )
* 296.802103844292 + intermediate_der9438 * 461.523 ) + intermediate_der9439
* 4124.48151675695 ; t690 = X [ 34ULL ] * intrm_sf_mf_545 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 = X [ 37ULL ]
/ ( t690 == 0.0 ? 1.0E-16 : t690 ) ; if ( X [ 34ULL ] <= 216.59999999999997 )
{ intermediate_der9440 = 216.59999999999997 ; } else { intermediate_der9440 =
X [ 34ULL ] >= 623.15 ? 623.15 : X [ 34ULL ] ; } t574 = intermediate_der9440
* intermediate_der9440 ; if ( X [ 41ULL ] <= 0.0 ) { intermediate_der9572 =
0.0 ; } else { intermediate_der9572 = X [ 41ULL ] >= 1.0 ? 1.0 : X [ 41ULL ]
; } if ( X [ 42ULL ] <= 0.0 ) { intermediate_der9573 = 0.0 ; } else {
intermediate_der9573 = X [ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; }
intrm_sf_mf_694 = ( ( ( 1.0 - intermediate_der9572 ) - intermediate_der9573 )
* 296.802103844292 + intermediate_der9572 * 461.523 ) + intermediate_der9573
* 259.836612622973 ; t692 = X [ 39ULL ] * intrm_sf_mf_694 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = X [ 40ULL ]
/ ( t692 == 0.0 ? 1.0E-16 : t692 ) ; if ( X [ 39ULL ] <= 216.59999999999997 )
{ intermediate_der9574 = 216.59999999999997 ; } else { intermediate_der9574 =
X [ 39ULL ] >= 623.15 ? 623.15 : X [ 39ULL ] ; } t577 = intermediate_der9574
* intermediate_der9574 ; if ( X [ 45ULL ] <= 0.0 ) { t878 = 0.0 ; } else {
t878 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; } if ( X [ 44ULL ] <= 0.0 ) {
t892 = 0.0 ; } else { t892 = X [ 44ULL ] >= 1.0 ? 1.0 : X [ 44ULL ] ; }
intrm_sf_mf_869 = ( ( ( 1.0 - t878 ) - t892 ) * 296.802103844292 + t878 *
461.523 ) + t892 * 259.836612622973 ; t694 = X [ 43ULL ] * intrm_sf_mf_869 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 = X [ 49ULL ]
/ ( t694 == 0.0 ? 1.0E-16 : t694 ) ; if ( X [ 43ULL ] <= 216.59999999999997 )
{ t889 = 216.59999999999997 ; } else { t889 = X [ 43ULL ] >= 623.15 ? 623.15
: X [ 43ULL ] ; } t580 = t889 * t889 ; if ( X [ 48ULL ] <= 0.0 ) {
intermediate_der7612 = 0.0 ; } else { intermediate_der7612 = X [ 48ULL ] >=
1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { intermediate_der7613
= 0.0 ; } else { intermediate_der7613 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL
] ; } intrm_sf_mf_1006 = ( ( ( 1.0 - intermediate_der7612 ) -
intermediate_der7613 ) * 296.802103844292 + intermediate_der7612 * 461.523 )
+ intermediate_der7613 * 259.836612622973 ; t696 = X [ 46ULL ] *
intrm_sf_mf_1006 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 = X [ 50ULL ]
/ ( t696 == 0.0 ? 1.0E-16 : t696 ) ; if ( X [ 46ULL ] <= 216.59999999999997 )
{ intermediate_der7478 = 216.59999999999997 ; } else { intermediate_der7478 =
X [ 46ULL ] >= 623.15 ? 623.15 : X [ 46ULL ] ; } t583 = intermediate_der7478
* intermediate_der7478 ; if ( X [ 53ULL ] <= 0.0 ) { intermediate_der8176 =
0.0 ; } else { intermediate_der8176 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ]
; } if ( X [ 52ULL ] <= 0.0 ) { intermediate_der8177 = 0.0 ; } else {
intermediate_der8177 = X [ 52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; }
intrm_sf_mf_1144 = ( ( ( 1.0 - intermediate_der8176 ) - intermediate_der8177
) * 296.802103844292 + intermediate_der8176 * 461.523 ) +
intermediate_der8177 * 259.836612622973 ; t698 = X [ 51ULL ] *
intrm_sf_mf_1144 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 = X [ 54ULL ]
/ ( t698 == 0.0 ? 1.0E-16 : t698 ) ; if ( X [ 51ULL ] <= 216.59999999999997 )
{ intermediate_der7614 = 216.59999999999997 ; } else { intermediate_der7614 =
X [ 51ULL ] >= 623.15 ? 623.15 : X [ 51ULL ] ; } t586 = intermediate_der7614
* intermediate_der7614 ; t360 [ 0ULL ] = X [ 56ULL ] ; t87 [ 0 ] = 11ULL ;
tlu2_linear_linear_prelookup ( & s_efOut . mField0 [ 0ULL ] , & s_efOut .
mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t360 [ 0ULL ] , & t87 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t14 = s_efOut ; t360 [ 0ULL ] = 1.01325 ; t90 [ 0 ] = 12ULL ;
tlu2_linear_linear_prelookup ( & t_efOut . mField0 [ 0ULL ] , & t_efOut .
mField1 [ 0ULL ] , & t_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t360 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t13 = t_efOut ; tlu2_2d_linear_linear_value ( & u_efOut [ 0ULL ] , & t14 .
mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , & t13 . mField0 [ 0ULL ] , &
t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , &
t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = u_efOut [ 0 ]
; t1131 = t348_idx_0 ; tlu2_2d_linear_linear_value ( & v_efOut [ 0ULL ] , &
t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , & t13 . mField0 [ 0ULL ]
, & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField35 ,
& t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = v_efOut [ 0
] ; intermediate_der5464 = t348_idx_0 ; tlu2_2d_linear_linear_value ( &
w_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t13 . mField0 [ 0ULL ] , & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField38 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = w_efOut [ 0 ] ; t681 = t348_idx_0 ; tlu2_2d_linear_linear_value
( & x_efOut [ 0ULL ] , & t14 . mField0 [ 0ULL ] , & t14 . mField2 [ 0ULL ] ,
& t13 . mField0 [ 0ULL ] , & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = x_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 = t348_idx_0
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant11 = t681 -
t1131 * t1131 * X [ 56ULL ] * intermediate_der5464 / ( t348_idx_0 == 0.0 ?
1.0E-16 : t348_idx_0 ) * 100000.0 ; t360 [ 0ULL ] = X [ 59ULL ] ;
tlu2_linear_linear_prelookup ( & y_efOut . mField0 [ 0ULL ] , & y_efOut .
mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t360 [ 0ULL ] , & t87 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t11 = y_efOut ; t360 [ 0ULL ] = X [ 58ULL ] ; tlu2_linear_linear_prelookup (
& ab_efOut . mField0 [ 0ULL ] , & ab_efOut . mField1 [ 0ULL ] , & ab_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t360 [
0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t10 = ab_efOut ;
tlu2_2d_linear_linear_value ( & bb_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL ]
, & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , & t10 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = bb_efOut [ 0 ] ; t699 =
t348_idx_0 ; tlu2_2d_linear_linear_value ( & cb_efOut [ 0ULL ] , & t11 .
mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , &
t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField35 , &
t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = cb_efOut [ 0
] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 =
t348_idx_0 ; tlu2_2d_linear_linear_value ( & db_efOut [ 0ULL ] , & t11 .
mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , &
t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , &
t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = db_efOut [ 0
] ; intermediate_der5532 = t348_idx_0 ; tlu2_2d_linear_linear_value ( &
eb_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , &
t10 . mField0 [ 0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = eb_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 = t348_idx_0
; tlu2_2d_linear_linear_value ( & fb_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL
] , & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , & t10 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = fb_efOut [ 0 ] ;
intermediate_der5533 = X [ 58ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ) *
100.0 + t348_idx_0 ; t360 [ 0ULL ] = X [ 61ULL ] ;
tlu2_linear_linear_prelookup ( & gb_efOut . mField0 [ 0ULL ] , & gb_efOut .
mField1 [ 0ULL ] , & gb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t360 [ 0ULL ] , & t87 [ 0ULL ] , & t34 [ 0ULL ] ) ; t9
= gb_efOut ; t360 [ 0ULL ] = X [ 60ULL ] ; tlu2_linear_linear_prelookup ( &
hb_efOut . mField0 [ 0ULL ] , & hb_efOut . mField1 [ 0ULL ] , & hb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t360 [
0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t16 = hb_efOut ;
tlu2_2d_linear_linear_value ( & ib_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = ib_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 = t348_idx_0 ;
tlu2_2d_linear_linear_value ( & jb_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField35 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = jb_efOut [ 0 ] ; t700 = t348_idx_0 ;
tlu2_2d_linear_linear_value ( & kb_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = kb_efOut [ 0 ] ;
intermediate_der5617 = t348_idx_0 ; tlu2_2d_linear_linear_value ( & lb_efOut
[ 0ULL ] , & t9 . mField0 [ 0ULL ] , & t9 . mField2 [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t348_idx_0 = lb_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 = t348_idx_0
; tlu2_2d_linear_linear_value ( & mb_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ]
, & t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t348_idx_0 = mb_efOut [ 0 ] ;
intermediate_der5618 = X [ 60ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ) *
100.0 + t348_idx_0 ; if ( X [ 66ULL ] <= 0.0 ) { intermediate_der8217 = 0.0 ;
} else { intermediate_der8217 = X [ 66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ] ; } if
( X [ 65ULL ] <= 0.0 ) { t701 = 0.0 ; } else { t701 = X [ 65ULL ] >= 1.0 ?
1.0 : X [ 65ULL ] ; } intrm_sf_mf_1380 = ( ( ( 1.0 - intermediate_der8217 ) -
t701 ) * 296.802103844292 + intermediate_der8217 * 461.523 ) + t701 *
4124.48151675695 ; t703 = X [ 63ULL ] * intrm_sf_mf_1380 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 = X [ 64ULL ]
/ ( t703 == 0.0 ? 1.0E-16 : t703 ) ; if ( X [ 63ULL ] <= 216.59999999999997 )
{ intermediate_der8178 = 216.59999999999997 ; } else { intermediate_der8178 =
X [ 63ULL ] >= 623.15 ? 623.15 : X [ 63ULL ] ; } t589 = intermediate_der8178
* intermediate_der8178 ; if ( X [ 69ULL ] <= 0.0 ) { intermediate_der8370 =
0.0 ; } else { intermediate_der8370 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ]
; } if ( X [ 70ULL ] <= 0.0 ) { intermediate_der8371 = 0.0 ; } else {
intermediate_der8371 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; }
intrm_sf_mf_1399 = ( ( ( 1.0 - intermediate_der8370 ) - intermediate_der8371
) * 296.802103844292 + intermediate_der8370 * 461.523 ) +
intermediate_der8371 * 4124.48151675695 ; t705 = X [ 67ULL ] *
intrm_sf_mf_1399 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 = X [ 68ULL ]
/ ( t705 == 0.0 ? 1.0E-16 : t705 ) ; if ( X [ 67ULL ] <= 216.59999999999997 )
{ intermediate_der8219 = 216.59999999999997 ; } else { intermediate_der8219 =
X [ 67ULL ] >= 623.15 ? 623.15 : X [ 67ULL ] ; } t850 = intermediate_der8219
* intermediate_der8219 ; if ( X [ 73ULL ] <= 0.0 ) { intermediate_der8383 =
0.0 ; } else { intermediate_der8383 = X [ 73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ]
; } if ( X [ 72ULL ] <= 0.0 ) { intermediate_der8384 = 0.0 ; } else {
intermediate_der8384 = X [ 72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; }
intrm_sf_mf_1634 = ( ( ( 1.0 - intermediate_der8383 ) - intermediate_der8384
) * 296.802103844292 + intermediate_der8383 * 461.523 ) +
intermediate_der8384 * 259.836612622973 ; t707 = X [ 71ULL ] *
intrm_sf_mf_1634 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 = X [ 55ULL ]
/ ( t707 == 0.0 ? 1.0E-16 : t707 ) ; if ( X [ 71ULL ] <= 216.59999999999997 )
{ intermediate_der8372 = 216.59999999999997 ; } else { intermediate_der8372 =
X [ 71ULL ] >= 623.15 ? 623.15 : X [ 71ULL ] ; } t845 = intermediate_der8372
* intermediate_der8372 ; if ( X [ 76ULL ] <= 0.0 ) { intermediate_der8476 =
0.0 ; } else { intermediate_der8476 = X [ 76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ]
; } if ( X [ 75ULL ] <= 0.0 ) { intermediate_der8477 = 0.0 ; } else {
intermediate_der8477 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; }
intrm_sf_mf_1659 = ( ( ( 1.0 - intermediate_der8476 ) - intermediate_der8477
) * 296.802103844292 + intermediate_der8476 * 461.523 ) +
intermediate_der8477 * 4124.48151675695 ; t709 = X [ 74ULL ] *
intrm_sf_mf_1659 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 = X [ 38ULL ]
/ ( t709 == 0.0 ? 1.0E-16 : t709 ) ; if ( X [ 74ULL ] <= 216.59999999999997 )
{ intermediate_der8385 = 216.59999999999997 ; } else { intermediate_der8385 =
X [ 74ULL ] >= 623.15 ? 623.15 : X [ 74ULL ] ; } t847 = intermediate_der8385
* intermediate_der8385 ; intrm_sf_mf_1113 = ( ( ( 1074.1165326382554 +
intermediate_der7478 * - 0.22145652610641059 ) + t583 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der7612 ) - intermediate_der7613 ) + ( (
1479.6504774710402 + intermediate_der7478 * 1.2002114337050787 ) + t583 * -
0.00038614513167845434 ) * intermediate_der7612 ) + ( ( 900.639412248396 +
intermediate_der7478 * - 0.044484923911441127 ) + t583 *
0.00036936011832051582 ) * intermediate_der7613 ; intrm_sf_mf_1251 = ( ( (
1074.1165326382554 + intermediate_der7614 * - 0.22145652610641059 ) + t586 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der8176 ) -
intermediate_der8177 ) + ( ( 1479.6504774710402 + intermediate_der7614 *
1.2002114337050787 ) + t586 * - 0.00038614513167845434 ) *
intermediate_der8176 ) + ( ( 900.639412248396 + intermediate_der7614 * -
0.044484923911441127 ) + t586 * 0.00036936011832051582 ) *
intermediate_der8177 ; intrm_sf_mf_1393 = ( ( ( 1074.1165326382554 +
intermediate_der8178 * - 0.22145652610641059 ) + t589 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der8217 ) - t701 ) + ( ( 1479.6504774710402 +
intermediate_der8178 * 1.2002114337050787 ) + t589 * - 0.00038614513167845434
) * intermediate_der8217 ) + ( ( 12825.281119789837 + intermediate_der8178 *
6.9647057412840034 ) + t589 * - 0.0070524868246844051 ) * t701 ;
intrm_sf_mf_1506 = ( ( ( 1074.1165326382554 + intermediate_der8219 * -
0.22145652610641059 ) + t850 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der8370 ) - intermediate_der8371 ) + ( ( 1479.6504774710402 +
intermediate_der8219 * 1.2002114337050787 ) + t850 * - 0.00038614513167845434
) * intermediate_der8370 ) + ( ( 12825.281119789837 + intermediate_der8219 *
6.9647057412840034 ) + t850 * - 0.0070524868246844051 ) *
intermediate_der8371 ; intrm_sf_mf_1653 = ( ( ( 1074.1165326382554 +
intermediate_der8372 * - 0.22145652610641059 ) + t845 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der8383 ) - intermediate_der8384 ) + ( (
1479.6504774710402 + intermediate_der8372 * 1.2002114337050787 ) + t845 * -
0.00038614513167845434 ) * intermediate_der8383 ) + ( ( 900.639412248396 +
intermediate_der8372 * - 0.044484923911441127 ) + t845 *
0.00036936011832051582 ) * intermediate_der8384 ; intrm_sf_mf_1684 = ( ( (
1074.1165326382554 + intermediate_der8385 * - 0.22145652610641059 ) + t847 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der8476 ) -
intermediate_der8477 ) + ( ( 1479.6504774710402 + intermediate_der8385 *
1.2002114337050787 ) + t847 * - 0.00038614513167845434 ) *
intermediate_der8476 ) + ( ( 12825.281119789837 + intermediate_der8385 *
6.9647057412840034 ) + t847 * - 0.0070524868246844051 ) *
intermediate_der8477 ; t360 [ 0ULL ] = X [ 8ULL ] ;
tlu2_linear_linear_prelookup ( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut .
mField1 [ 0ULL ] , & nb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t360 [ 0ULL ] , & t33 [ 0ULL ] , & t34 [ 0ULL ] ) ; t18
= nb_efOut ; t360 [ 0ULL ] = X [ 15ULL ] ; tlu2_linear_linear_prelookup ( &
ob_efOut . mField0 [ 0ULL ] , & ob_efOut . mField1 [ 0ULL ] , & ob_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t360 [
0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t7 = ob_efOut ;
tlu2_2d_linear_linear_value ( & pb_efOut [ 0ULL ] , & t18 . mField0 [ 0ULL ]
, & t18 . mField2 [ 0ULL ] , & t7 . mField0 [ 0ULL ] , & t7 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , & t36 [
0ULL ] , & t34 [ 0ULL ] ) ; t360 [ 0 ] = pb_efOut [ 0 ] ;
intermediate_der8769 = t360 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
qb_efOut [ 0ULL ] , & t18 . mField0 [ 0ULL ] , & t18 . mField2 [ 0ULL ] , &
t7 . mField0 [ 0ULL ] , & t7 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t360
[ 0 ] = qb_efOut [ 0 ] ; intrm_sf_mf_1792 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & rb_efOut [ 0ULL ] , & t18 . mField0 [ 0ULL ]
, & t18 . mField2 [ 0ULL ] , & t7 . mField0 [ 0ULL ] , & t7 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , & t36 [
0ULL ] , & t34 [ 0ULL ] ) ; t360 [ 0 ] = rb_efOut [ 0 ] ; intrm_sf_mf_1793 =
t360 [ 0ULL ] ; intrm_sf_mf_202 = ( ( ( 1074.1165326382554 +
intermediate_der8975 * - 0.22145652610641059 ) + t565 * 0.0003721298010901061
) * ( ( 1.0 - t1118 ) - t1110 ) + ( ( 1479.6504774710402 +
intermediate_der8975 * 1.2002114337050787 ) + t565 * - 0.00038614513167845434
) * t1118 ) + ( ( 12825.281119789837 + intermediate_der8975 *
6.9647057412840034 ) + t565 * - 0.0070524868246844051 ) * t1110 ;
intrm_sf_mf_377 = ( ( ( 1074.1165326382554 + intermediate_der9130 * -
0.22145652610641059 ) + t568 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der9128 ) - intermediate_der9129 ) + ( ( 1479.6504774710402 +
intermediate_der9130 * 1.2002114337050787 ) + t568 * - 0.00038614513167845434
) * intermediate_der9128 ) + ( ( 12825.281119789837 + intermediate_der9130 *
6.9647057412840034 ) + t568 * - 0.0070524868246844051 ) *
intermediate_der9129 ; intrm_sf_mf_514 = ( ( ( 1074.1165326382554 +
intermediate_der9299 * - 0.22145652610641059 ) + t571 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der9297 ) - intermediate_der9298 ) + ( (
1479.6504774710402 + intermediate_der9299 * 1.2002114337050787 ) + t571 * -
0.00038614513167845434 ) * intermediate_der9297 ) + ( ( 12825.281119789837 +
intermediate_der9299 * 6.9647057412840034 ) + t571 * - 0.0070524868246844051
) * intermediate_der9298 ; intrm_sf_mf_652 = ( ( ( 1074.1165326382554 +
intermediate_der9440 * - 0.22145652610641059 ) + t574 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der9438 ) - intermediate_der9439 ) + ( (
1479.6504774710402 + intermediate_der9440 * 1.2002114337050787 ) + t574 * -
0.00038614513167845434 ) * intermediate_der9438 ) + ( ( 12825.281119789837 +
intermediate_der9440 * 6.9647057412840034 ) + t574 * - 0.0070524868246844051
) * intermediate_der9439 ; intrm_sf_mf_801 = ( ( ( 1074.1165326382554 +
intermediate_der9574 * - 0.22145652610641059 ) + t577 * 0.0003721298010901061
) * ( ( 1.0 - intermediate_der9572 ) - intermediate_der9573 ) + ( (
1479.6504774710402 + intermediate_der9574 * 1.2002114337050787 ) + t577 * -
0.00038614513167845434 ) * intermediate_der9572 ) + ( ( 900.639412248396 +
intermediate_der9574 * - 0.044484923911441127 ) + t577 *
0.00036936011832051582 ) * intermediate_der9573 ; intrm_sf_mf_976 = ( ( (
1074.1165326382554 + t889 * - 0.22145652610641059 ) + t580 *
0.0003721298010901061 ) * ( ( 1.0 - t878 ) - t892 ) + ( ( 1479.6504774710402
+ t889 * 1.2002114337050787 ) + t580 * - 0.00038614513167845434 ) * t878 ) +
( ( 900.639412248396 + t889 * - 0.044484923911441127 ) + t580 *
0.00036936011832051582 ) * t892 ; tlu2_2d_linear_linear_value ( & sb_efOut [
0ULL ] , & t561 [ 0ULL ] , & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField9 , & t33 [ 0ULL ] , & t36 [
0ULL ] , & t34 [ 0ULL ] ) ; t360 [ 0 ] = sb_efOut [ 0 ] ; intermediate_der366
= t360 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & tb_efOut [ 0ULL ] , & t31 .
mField0 [ 0ULL ] , & t31 . mField2 [ 0ULL ] , & t30 . mField1 [ 0ULL ] , &
t30 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField9 , & t33
[ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = tb_efOut [ 0 ] ;
intermediate_der253 = t406 [ 0ULL ] * 0.5 ; intermediate_der252 = t406 [ 0ULL
] * 0.5 ; tlu2_2d_linear_linear_value ( & ub_efOut [ 0ULL ] , & t561 [ 0ULL ]
, & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] )
; t360 [ 0 ] = ub_efOut [ 0 ] ; intermediate_der387 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & vb_efOut [ 0ULL ] , & t31 . mField0 [ 0ULL ]
, & t31 . mField2 [ 0ULL ] , & t30 . mField1 [ 0ULL ] , & t30 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t362 [ 0 ] = vb_efOut [ 0 ] ;
intermediate_der8770 = t362 [ 0ULL ] * 0.5 ; intermediate_der499 = t362 [
0ULL ] * 0.5 ; tlu2_2d_linear_linear_value ( & wb_efOut [ 0ULL ] , & t561 [
0ULL ] , & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , & t36 [ 0ULL ] ,
& t34 [ 0ULL ] ) ; t360 [ 0 ] = wb_efOut [ 0 ] ; intermediate_der691 = t360 [
0ULL ] ; tlu2_2d_linear_linear_value ( & xb_efOut [ 0ULL ] , & t31 . mField0
[ 0ULL ] , & t31 . mField2 [ 0ULL ] , & t30 . mField1 [ 0ULL ] , & t30 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [
0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t361 [ 0 ] = xb_efOut [ 0 ] ;
intermediate_der501 = t361 [ 0ULL ] * 0.5 ; intermediate_der737 = t361 [ 0ULL
] * 0.5 ; tlu2_2d_linear_linear_value ( & yb_efOut [ 0ULL ] , & t561 [ 0ULL ]
, & t562 [ 0ULL ] , & t557 [ 0ULL ] , & t559 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField1 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] )
; t360 [ 0 ] = yb_efOut [ 0 ] ; intermediate_der249 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & ac_efOut [ 0ULL ] , & t31 . mField0 [ 0ULL ]
, & t31 . mField2 [ 0ULL ] , & t30 . mField1 [ 0ULL ] , & t30 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ac_efOut [ 0 ] ;
intermediate_der250 = t406 [ 0ULL ] * 0.5 ; intermediate_der251 = t406 [ 0ULL
] * 0.5 ; t710 = - ( t1130 * t1130 * X [ 6ULL ] * intermediate_der389 ) ;
t711 = Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ;
intermediate_der252 = intermediate_der737 - ( t710 / ( t711 == 0.0 ? 1.0E-16
: t711 ) * intermediate_der251 + ( t1130 * t1130 * intermediate_der499 +
t1130 * intermediate_der389 * intermediate_der252 * 2.0 ) * X [ 6ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ) ) * 100000.0 ;
intermediate_der253 = intermediate_der501 - ( t710 / ( t711 == 0.0 ? 1.0E-16
: t711 ) * intermediate_der250 + ( t1130 * t1130 * intermediate_der8770 +
t1130 * intermediate_der389 * intermediate_der253 * 2.0 ) * X [ 6ULL ] / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ) ) * 100000.0 ;
t1130 = intermediate_der691 - ( t710 / ( t711 == 0.0 ? 1.0E-16 : t711 ) *
intermediate_der249 + ( ( t1130 * t1130 * intermediate_der387 + t1130 *
intermediate_der389 * intermediate_der366 * 2.0 ) * X [ 6ULL ] + t1130 *
t1130 * intermediate_der389 ) / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ) ) * 100000.0 ;
tlu2_2d_linear_linear_value ( & bc_efOut [ 0ULL ] , & t555 [ 0ULL ] , & t556
[ 0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t360 [
0 ] = bc_efOut [ 0 ] ; intermediate_der389 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & cc_efOut [ 0ULL ] , & t29 . mField0 [ 0ULL ]
, & t29 . mField2 [ 0ULL ] , & t28 . mField1 [ 0ULL ] , & t28 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField9 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = cc_efOut [ 0 ] ;
intermediate_der366 = t406 [ 0ULL ] * 0.5 ; intermediate_der387 = t406 [ 0ULL
] * 0.5 ; tlu2_2d_linear_linear_value ( & dc_efOut [ 0ULL ] , & t555 [ 0ULL ]
, & t556 [ 0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] )
; t360 [ 0 ] = dc_efOut [ 0 ] ; intermediate_der8770 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & ec_efOut [ 0ULL ] , & t29 . mField0 [ 0ULL ]
, & t29 . mField2 [ 0ULL ] , & t28 . mField1 [ 0ULL ] , & t28 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ec_efOut [ 0 ] ;
intermediate_der499 = t406 [ 0ULL ] * 0.5 ; intermediate_der691 = t406 [ 0ULL
] * 0.5 ; tlu2_2d_linear_linear_value ( & fc_efOut [ 0ULL ] , & t555 [ 0ULL ]
, & t556 [ 0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] )
; t360 [ 0 ] = fc_efOut [ 0 ] ; intermediate_der501 = t360 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & gc_efOut [ 0ULL ] , & t29 . mField0 [ 0ULL ]
, & t29 . mField2 [ 0ULL ] , & t28 . mField1 [ 0ULL ] , & t28 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = gc_efOut [ 0 ] ;
intermediate_der737 = t406 [ 0ULL ] * 0.5 ; t710 = t406 [ 0ULL ] * 0.5 ;
tlu2_2d_linear_linear_value ( & hc_efOut [ 0ULL ] , & t555 [ 0ULL ] , & t556
[ 0ULL ] , & t551 [ 0ULL ] , & t553 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField1 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t360 [
0 ] = hc_efOut [ 0 ] ; t711 = t360 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
ic_efOut [ 0ULL ] , & t29 . mField0 [ 0ULL ] , & t29 . mField2 [ 0ULL ] , &
t28 . mField1 [ 0ULL ] , & t28 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t361 [ 0 ] = ic_efOut [ 0 ] ; t712 = t361 [ 0ULL ] * 0.5 ; t715 = t361 [ 0ULL
] * 0.5 ; t719 = - ( intermediate_der496 * intermediate_der496 * X [ 9ULL ] *
t678 ) ; t720 = Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ;
intermediate_der387 = t710 - ( t719 / ( t720 == 0.0 ? 1.0E-16 : t720 ) * t715
+ ( intermediate_der496 * intermediate_der496 * intermediate_der691 +
intermediate_der496 * t678 * intermediate_der387 * 2.0 ) * X [ 9ULL ] / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ) ) * 100000.0 ;
intermediate_der366 = intermediate_der737 - ( t719 / ( t720 == 0.0 ? 1.0E-16
: t720 ) * t712 + ( intermediate_der496 * intermediate_der496 *
intermediate_der499 + intermediate_der496 * t678 * intermediate_der366 * 2.0
) * X [ 9ULL ] / ( Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I
== 0.0 ? 1.0E-16 : Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I
) ) * 100000.0 ; intermediate_der389 = intermediate_der501 - ( t719 / ( t720
== 0.0 ? 1.0E-16 : t720 ) * t711 + ( ( intermediate_der496 *
intermediate_der496 * intermediate_der8770 + intermediate_der496 * t678 *
intermediate_der389 * 2.0 ) * X [ 9ULL ] + intermediate_der496 *
intermediate_der496 * t678 ) / (
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ) ) * 100000.0 ;
tlu2_2d_linear_linear_value ( & jc_efOut [ 0ULL ] , & t549 [ 0ULL ] , & t550
[ 0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t361 [
0 ] = jc_efOut [ 0 ] ; intermediate_der496 = t361 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & kc_efOut [ 0ULL ] , & t27 . mField0 [ 0ULL ]
, & t27 . mField2 [ 0ULL ] , & t26 . mField1 [ 0ULL ] , & t26 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField9 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t362 [ 0 ] = kc_efOut [ 0 ] ; t678 = t362 [
0ULL ] * 0.5 ; intermediate_der8770 = t362 [ 0ULL ] * 0.5 ;
tlu2_2d_linear_linear_value ( & lc_efOut [ 0ULL ] , & t549 [ 0ULL ] , & t550
[ 0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField10 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t362 [
0 ] = lc_efOut [ 0 ] ; intermediate_der499 = t362 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & mc_efOut [ 0ULL ] , & t27 . mField0 [ 0ULL ]
, & t27 . mField2 [ 0ULL ] , & t26 . mField1 [ 0ULL ] , & t26 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = mc_efOut [ 0 ] ;
intermediate_der691 = t406 [ 0ULL ] * 0.5 ; intermediate_der501 = t406 [ 0ULL
] * 0.5 ; tlu2_2d_linear_linear_value ( & nc_efOut [ 0ULL ] , & t549 [ 0ULL ]
, & t550 [ 0ULL ] , & t560 [ 0ULL ] , & t547 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] )
; t362 [ 0 ] = nc_efOut [ 0 ] ; intermediate_der737 = t362 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & oc_efOut [ 0ULL ] , & t27 . mField0 [ 0ULL ]
, & t27 . mField2 [ 0ULL ] , & t26 . mField1 [ 0ULL ] , & t26 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = oc_efOut [ 0 ] ; t710 = t406 [
0ULL ] * 0.5 ; t718 = t406 [ 0ULL ] * 0.5 ; tlu2_2d_linear_linear_value ( &
pc_efOut [ 0ULL ] , & t549 [ 0ULL ] , & t550 [ 0ULL ] , & t560 [ 0ULL ] , &
t547 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33 [ 0ULL ]
, & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t362 [ 0 ] = pc_efOut [ 0 ] ; t719 =
t362 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & qc_efOut [ 0ULL ] , & t27 .
mField0 [ 0ULL ] , & t27 . mField2 [ 0ULL ] , & t26 . mField1 [ 0ULL ] , &
t26 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t33
[ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = qc_efOut [ 0 ] ;
t720 = t406 [ 0ULL ] * 0.5 ; t721 = t406 [ 0ULL ] * 0.5 ; t728 = - ( t679 *
t679 * X [ 11ULL ] * t1128 ) ; t729 =
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I *
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ; intermediate_der518 =
t718 - ( t728 / ( t729 == 0.0 ? 1.0E-16 : t729 ) * t721 + ( t679 * t679 *
intermediate_der501 + t679 * t1128 * intermediate_der8770 * 2.0 ) * X [ 11ULL
] / ( Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I == 0.0 ? 1.0E-16
: Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ) ) * 100000.0 ; t678
= t710 - ( t728 / ( t729 == 0.0 ? 1.0E-16 : t729 ) * t720 + ( t679 * t679 *
intermediate_der691 + t679 * t1128 * t678 * 2.0 ) * X [ 11ULL ] / (
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ) ) * 100000.0 ;
intermediate_der496 = intermediate_der737 - ( t728 / ( t729 == 0.0 ? 1.0E-16
: t729 ) * t719 + ( ( t679 * t679 * intermediate_der499 + t679 * t1128 *
intermediate_der496 * 2.0 ) * X [ 11ULL ] + t679 * t679 * t1128 ) / (
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ) ) * 100000.0 ; if ( X
[ 23ULL ] <= 0.0 ) { t1128 = 0.0 ; } else { t1128 = ( real_T ) ! ( X [ 23ULL
] >= 1.0 ) ; } if ( X [ 24ULL ] <= 0.0 ) { intermediate_der8770 = 0.0 ; }
else { intermediate_der8770 = ( real_T ) ! ( X [ 24ULL ] >= 1.0 ) ; }
intermediate_der499 = - intermediate_der8770 * 296.802103844292 +
intermediate_der8770 * 4124.48151675695 ; intermediate_der691 = - t1128 *
296.802103844292 + t1128 * 461.523 ; intermediate_der501 = 1.0 / ( t875 ==
0.0 ? 1.0E-16 : t875 ) ; t739 = X [ 21ULL ] * X [ 21ULL ] * t1090 * t1090 ;
intermediate_der737 = - X [ 22ULL ] / ( t739 == 0.0 ? 1.0E-16 : t739 ) * X [
21ULL ] * intermediate_der691 ; t710 = - X [ 22ULL ] / ( t739 == 0.0 ?
1.0E-16 : t739 ) * X [ 21ULL ] * intermediate_der499 ; t718 = - X [ 22ULL ] /
( t739 == 0.0 ? 1.0E-16 : t739 ) * t1090 ; if ( X [ 21ULL ] <=
216.59999999999997 ) { t875 = 0.0 ; } else { t875 = ( real_T ) ! ( X [ 21ULL
] >= 623.15 ) ; } t643 = intermediate_der8975 * t875 * 2.0 ; if ( X [ 27ULL ]
<= 0.0 ) { t724 = 0.0 ; } else { t724 = ( real_T ) ! ( X [ 27ULL ] >= 1.0 ) ;
} if ( X [ 26ULL ] <= 0.0 ) { t727 = 0.0 ; } else { t727 = ( real_T ) ! ( X [
26ULL ] >= 1.0 ) ; } t728 = - t727 * 296.802103844292 + t727 *
4124.48151675695 ; t729 = - t724 * 296.802103844292 + t724 * 461.523 ; t730 =
1.0 / ( t686 == 0.0 ? 1.0E-16 : t686 ) ; t746 = X [ 25ULL ] * X [ 25ULL ] *
intrm_sf_mf_270 * intrm_sf_mf_270 ; t686 = - X [ 31ULL ] / ( t746 == 0.0 ?
1.0E-16 : t746 ) * X [ 25ULL ] * t729 ; t733 = - X [ 31ULL ] / ( t746 == 0.0
? 1.0E-16 : t746 ) * intrm_sf_mf_270 ; t736 = - X [ 31ULL ] / ( t746 == 0.0 ?
1.0E-16 : t746 ) * X [ 25ULL ] * t728 ; if ( X [ 25ULL ] <=
216.59999999999997 ) { t738 = 0.0 ; } else { t738 = ( real_T ) ! ( X [ 25ULL
] >= 623.15 ) ; } t646 = intermediate_der9130 * t738 * 2.0 ; if ( X [ 30ULL ]
<= 0.0 ) { t739 = 0.0 ; } else { t739 = ( real_T ) ! ( X [ 30ULL ] >= 1.0 ) ;
} if ( X [ 29ULL ] <= 0.0 ) { t745 = 0.0 ; } else { t745 = ( real_T ) ! ( X [
29ULL ] >= 1.0 ) ; } t746 = - t745 * 296.802103844292 + t745 *
4124.48151675695 ; intermediate_der1975 = - t739 * 296.802103844292 + t739 *
461.523 ; intermediate_der2018 = 1.0 / ( t688 == 0.0 ? 1.0E-16 : t688 ) ;
t753 = X [ 28ULL ] * X [ 28ULL ] * intrm_sf_mf_407 * intrm_sf_mf_407 ; t688 =
- X [ 33ULL ] / ( t753 == 0.0 ? 1.0E-16 : t753 ) * X [ 28ULL ] *
intermediate_der1975 ; intermediate_der2020 = - X [ 33ULL ] / ( t753 == 0.0 ?
1.0E-16 : t753 ) * X [ 28ULL ] * t746 ; intermediate_der2021 = - X [ 33ULL ]
/ ( t753 == 0.0 ? 1.0E-16 : t753 ) * intrm_sf_mf_407 ; if ( X [ 28ULL ] <=
216.59999999999997 ) { t752 = 0.0 ; } else { t752 = ( real_T ) ! ( X [ 28ULL
] >= 623.15 ) ; } t649 = intermediate_der9299 * t752 * 2.0 ; if ( X [ 36ULL ]
<= 0.0 ) { t753 = 0.0 ; } else { t753 = ( real_T ) ! ( X [ 36ULL ] >= 1.0 ) ;
} if ( X [ 35ULL ] <= 0.0 ) { intermediate_der2531 = 0.0 ; } else {
intermediate_der2531 = ( real_T ) ! ( X [ 35ULL ] >= 1.0 ) ; }
intermediate_der2532 = - intermediate_der2531 * 296.802103844292 +
intermediate_der2531 * 4124.48151675695 ; intermediate_der2533 = - t753 *
296.802103844292 + t753 * 461.523 ; intermediate_der2576 = 1.0 / ( t690 ==
0.0 ? 1.0E-16 : t690 ) ; t760 = X [ 34ULL ] * X [ 34ULL ] * intrm_sf_mf_545 *
intrm_sf_mf_545 ; t690 = - X [ 37ULL ] / ( t760 == 0.0 ? 1.0E-16 : t760 ) * X
[ 34ULL ] * intermediate_der2533 ; intermediate_der2578 = - X [ 37ULL ] / (
t760 == 0.0 ? 1.0E-16 : t760 ) * X [ 34ULL ] * intermediate_der2532 ;
intermediate_der2579 = - X [ 37ULL ] / ( t760 == 0.0 ? 1.0E-16 : t760 ) *
intrm_sf_mf_545 ; if ( X [ 34ULL ] <= 216.59999999999997 ) { t759 = 0.0 ; }
else { t759 = ( real_T ) ! ( X [ 34ULL ] >= 623.15 ) ; } t652 =
intermediate_der9440 * t759 * 2.0 ; if ( X [ 41ULL ] <= 0.0 ) { t760 = 0.0 ;
} else { t760 = ( real_T ) ! ( X [ 41ULL ] >= 1.0 ) ; } if ( X [ 42ULL ] <=
0.0 ) { intermediate_der3090 = 0.0 ; } else { intermediate_der3090 = ( real_T
) ! ( X [ 42ULL ] >= 1.0 ) ; } intermediate_der3091 = - intermediate_der3090
* 296.802103844292 + intermediate_der3090 * 259.836612622973 ;
intermediate_der3092 = - t760 * 296.802103844292 + t760 * 461.523 ;
intermediate_der3135 = 1.0 / ( t692 == 0.0 ? 1.0E-16 : t692 ) ; t767 = X [
39ULL ] * X [ 39ULL ] * intrm_sf_mf_694 * intrm_sf_mf_694 ; t692 = - X [
40ULL ] / ( t767 == 0.0 ? 1.0E-16 : t767 ) * X [ 39ULL ] *
intermediate_der3092 ; intermediate_der3137 = - X [ 40ULL ] / ( t767 == 0.0 ?
1.0E-16 : t767 ) * X [ 39ULL ] * intermediate_der3091 ; intermediate_der3138
= - X [ 40ULL ] / ( t767 == 0.0 ? 1.0E-16 : t767 ) * intrm_sf_mf_694 ; if ( X
[ 39ULL ] <= 216.59999999999997 ) { t766 = 0.0 ; } else { t766 = ( real_T ) !
( X [ 39ULL ] >= 623.15 ) ; } t655 = intermediate_der9574 * t766 * 2.0 ; if (
X [ 45ULL ] <= 0.0 ) { t767 = 0.0 ; } else { t767 = ( real_T ) ! ( X [ 45ULL
] >= 1.0 ) ; } if ( X [ 44ULL ] <= 0.0 ) { intermediate_der3779 = 0.0 ; }
else { intermediate_der3779 = ( real_T ) ! ( X [ 44ULL ] >= 1.0 ) ; }
intermediate_der3780 = - intermediate_der3779 * 296.802103844292 +
intermediate_der3779 * 259.836612622973 ; intermediate_der3781 = - t767 *
296.802103844292 + t767 * 461.523 ; intermediate_der3824 = 1.0 / ( t694 ==
0.0 ? 1.0E-16 : t694 ) ; t774 = X [ 43ULL ] * X [ 43ULL ] * intrm_sf_mf_869 *
intrm_sf_mf_869 ; t694 = - X [ 49ULL ] / ( t774 == 0.0 ? 1.0E-16 : t774 ) * X
[ 43ULL ] * intermediate_der3781 ; intermediate_der3826 = - X [ 49ULL ] / (
t774 == 0.0 ? 1.0E-16 : t774 ) * X [ 43ULL ] * intermediate_der3780 ;
intermediate_der3827 = - X [ 49ULL ] / ( t774 == 0.0 ? 1.0E-16 : t774 ) *
intrm_sf_mf_869 ; if ( X [ 43ULL ] <= 216.59999999999997 ) { t773 = 0.0 ; }
else { t773 = ( real_T ) ! ( X [ 43ULL ] >= 623.15 ) ; } t658 = t889 * t773 *
2.0 ; if ( X [ 48ULL ] <= 0.0 ) { t774 = 0.0 ; } else { t774 = ( real_T ) ! (
X [ 48ULL ] >= 1.0 ) ; } if ( X [ 47ULL ] <= 0.0 ) { intermediate_der7477 =
0.0 ; } else { intermediate_der7477 = ( real_T ) ! ( X [ 47ULL ] >= 1.0 ) ; }
intermediate_der4343 = - intermediate_der7477 * 296.802103844292 +
intermediate_der7477 * 259.836612622973 ; intermediate_der4344 = - t774 *
296.802103844292 + t774 * 461.523 ; intermediate_der4387 = 1.0 / ( t696 ==
0.0 ? 1.0E-16 : t696 ) ; t781 = X [ 46ULL ] * X [ 46ULL ] * intrm_sf_mf_1006
* intrm_sf_mf_1006 ; t696 = - X [ 50ULL ] / ( t781 == 0.0 ? 1.0E-16 : t781 )
* X [ 46ULL ] * intermediate_der4344 ; intermediate_der4389 = - X [ 50ULL ] /
( t781 == 0.0 ? 1.0E-16 : t781 ) * intrm_sf_mf_1006 ; intermediate_der4390 =
- X [ 50ULL ] / ( t781 == 0.0 ? 1.0E-16 : t781 ) * X [ 46ULL ] *
intermediate_der4343 ; if ( X [ 46ULL ] <= 216.59999999999997 ) {
intermediate_der8479 = 0.0 ; } else { intermediate_der8479 = ( real_T ) ! ( X
[ 46ULL ] >= 623.15 ) ; } t857 = intermediate_der7478 * intermediate_der8479
* 2.0 ; if ( X [ 53ULL ] <= 0.0 ) { t781 = 0.0 ; } else { t781 = ( real_T ) !
( X [ 53ULL ] >= 1.0 ) ; } if ( X [ 52ULL ] <= 0.0 ) { intermediate_der8481 =
0.0 ; } else { intermediate_der8481 = ( real_T ) ! ( X [ 52ULL ] >= 1.0 ) ; }
intermediate_der4901 = - intermediate_der8481 * 296.802103844292 +
intermediate_der8481 * 259.836612622973 ; intermediate_der4902 = - t781 *
296.802103844292 + t781 * 461.523 ; intermediate_der4945 = 1.0 / ( t698 ==
0.0 ? 1.0E-16 : t698 ) ; t788 = X [ 51ULL ] * X [ 51ULL ] * intrm_sf_mf_1144
* intrm_sf_mf_1144 ; t698 = - X [ 54ULL ] / ( t788 == 0.0 ? 1.0E-16 : t788 )
* X [ 51ULL ] * intermediate_der4902 ; intermediate_der4947 = - X [ 54ULL ] /
( t788 == 0.0 ? 1.0E-16 : t788 ) * X [ 51ULL ] * intermediate_der4901 ;
intermediate_der4948 = - X [ 54ULL ] / ( t788 == 0.0 ? 1.0E-16 : t788 ) *
intrm_sf_mf_1144 ; if ( X [ 51ULL ] <= 216.59999999999997 ) { t787 = 0.0 ; }
else { t787 = ( real_T ) ! ( X [ 51ULL ] >= 623.15 ) ; } t858 =
intermediate_der7614 * t787 * 2.0 ; tlu2_2d_linear_linear_value ( & rc_efOut
[ 0ULL ] , & t14 . mField1 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , & t13 .
mField0 [ 0ULL ] , & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField32 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0
] = rc_efOut [ 0 ] ; t788 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
sc_efOut [ 0ULL ] , & t14 . mField1 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t13 . mField0 [ 0ULL ] , & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField35 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t406 [ 0 ] = sc_efOut [ 0 ] ; intermediate_der5505 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & tc_efOut [ 0ULL ] , & t14 . mField1 [ 0ULL ]
, & t14 . mField2 [ 0ULL ] , & t13 . mField0 [ 0ULL ] , & t13 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = tc_efOut [ 0 ] ;
intermediate_der5506 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
uc_efOut [ 0ULL ] , & t14 . mField1 [ 0ULL ] , & t14 . mField2 [ 0ULL ] , &
t13 . mField0 [ 0ULL ] , & t13 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t406 [ 0 ] = uc_efOut [ 0 ] ; intermediate_der5458 = t406 [ 0ULL ] ; t794 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 ; t1131 =
intermediate_der5506 - ( - ( t1131 * t1131 * X [ 56ULL ] *
intermediate_der5464 ) / ( t794 == 0.0 ? 1.0E-16 : t794 ) *
intermediate_der5458 + ( ( t1131 * t1131 * intermediate_der5505 + t1131 *
intermediate_der5464 * t788 * 2.0 ) * X [ 56ULL ] + t1131 * t1131 *
intermediate_der5464 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 ) )
* 100000.0 ; tlu2_2d_linear_linear_value ( & vc_efOut [ 0ULL ] , & t11 .
mField1 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , &
t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , &
t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = vc_efOut [ 0
] ; t788 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & wc_efOut [ 0ULL ]
, & t11 . mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField1 [
0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField32 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] =
wc_efOut [ 0 ] ; intermediate_der5505 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & xc_efOut [ 0ULL ] , & t11 . mField1 [ 0ULL ]
, & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , & t10 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField35 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = xc_efOut [ 0 ] ;
intermediate_der5506 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
yc_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , &
t10 . mField1 [ 0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField35 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t406 [ 0 ] = yc_efOut [ 0 ] ; t681 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & ad_efOut [ 0ULL ] , & t11 . mField1 [ 0ULL ]
, & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , & t10 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ad_efOut [ 0 ] ; t794 = t406 [
0ULL ] ; tlu2_2d_linear_linear_value ( & bd_efOut [ 0ULL ] , & t11 . mField0
[ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField1 [ 0ULL ] , & t10 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [
0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = bd_efOut [ 0 ] ;
t348_idx_0 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & cd_efOut [ 0ULL
] , & t11 . mField1 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , & t10 . mField0 [
0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] =
cd_efOut [ 0 ] ; t679 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
dd_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , &
t10 . mField1 [ 0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t406 [ 0 ] = dd_efOut [ 0 ] ; intermediate_der5464 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & ed_efOut [ 0ULL ] , & t11 . mField1 [ 0ULL ]
, & t11 . mField2 [ 0ULL ] , & t10 . mField0 [ 0ULL ] , & t10 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ed_efOut [ 0 ] ;
intermediate_der5588 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
fd_efOut [ 0ULL ] , & t11 . mField0 [ 0ULL ] , & t11 . mField2 [ 0ULL ] , &
t10 . mField1 [ 0ULL ] , & t10 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField37 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ;
t406 [ 0 ] = fd_efOut [ 0 ] ; intermediate_der5530 = t406 [ 0ULL ] ; t797 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ;
intermediate_der5589 = - X [ 58ULL ] / ( t797 == 0.0 ? 1.0E-16 : t797 ) *
t679 * 100.0 + intermediate_der5588 ; intermediate_der5588 = ( - X [ 58ULL ]
/ ( t797 == 0.0 ? 1.0E-16 : t797 ) * intermediate_der5464 + 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ) )
* 100.0 + intermediate_der5530 ; intermediate_der5530 = ( ( t348_idx_0 - (
t699 * intermediate_der5588 + intermediate_der5533 * intermediate_der5505 ) *
1000.0 ) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 +
( intermediate_der5532 - t699 * intermediate_der5533 * 1000.0 ) *
intermediate_der5464 ) * 0.0040159681273635624 ; t348_idx_0 = ( ( t794 - (
t699 * intermediate_der5589 + intermediate_der5533 * t788 ) * 1000.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 + (
intermediate_der5532 - t699 * intermediate_der5533 * 1000.0 ) * t679 ) *
0.0040159681273635624 ; intermediate_der5616 = - ( intermediate_der5533 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ) ; t801 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ;
intermediate_der5532 = ( ( intermediate_der5616 / ( t801 == 0.0 ? 1.0E-16 :
t801 ) * t681 + ( intermediate_der5533 * intermediate_der5464 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 *
intermediate_der5588 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ) )
* 0.01 - X [ 59ULL ] * intermediate_der5505 ) * 0.0040159681273635624 ;
intermediate_der5533 = ( ( intermediate_der5616 / ( t801 == 0.0 ? 1.0E-16 :
t801 ) * intermediate_der5506 + ( intermediate_der5533 * t679 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 *
intermediate_der5589 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ) )
* 0.01 - ( X [ 59ULL ] * t788 + t699 ) ) * 0.0040159681273635624 ;
tlu2_2d_linear_linear_value ( & gd_efOut [ 0ULL ] , & t9 . mField1 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = gd_efOut [ 0 ] ; t794 = t406 [ 0ULL
] ; tlu2_2d_linear_linear_value ( & hd_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL
] , & t9 . mField2 [ 0ULL ] , & t16 . mField1 [ 0ULL ] , & t16 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField32 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = hd_efOut [ 0 ] ;
intermediate_der5588 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
id_efOut [ 0ULL ] , & t9 . mField1 [ 0ULL ] , & t9 . mField2 [ 0ULL ] , & t16
. mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField35 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [
0 ] = id_efOut [ 0 ] ; intermediate_der5589 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & jd_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField1 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField35 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = jd_efOut [ 0 ] ; t796 = t406 [ 0ULL
] ; tlu2_2d_linear_linear_value ( & kd_efOut [ 0ULL ] , & t9 . mField1 [ 0ULL
] , & t9 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = kd_efOut [ 0 ] ; t797 = t406 [
0ULL ] ; tlu2_2d_linear_linear_value ( & ld_efOut [ 0ULL ] , & t9 . mField0 [
0ULL ] , & t9 . mField2 [ 0ULL ] , & t16 . mField1 [ 0ULL ] , & t16 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField38 , & t87 [ 0ULL ] , &
t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ld_efOut [ 0 ] ;
intermediate_der5616 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
md_efOut [ 0ULL ] , & t9 . mField1 [ 0ULL ] , & t9 . mField2 [ 0ULL ] , & t16
. mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [
0 ] = md_efOut [ 0 ] ; t802 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
nd_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] , & t9 . mField2 [ 0ULL ] , & t16
. mField1 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField36 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [
0 ] = nd_efOut [ 0 ] ; t805 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( &
od_efOut [ 0ULL ] , & t9 . mField1 [ 0ULL ] , & t9 . mField2 [ 0ULL ] , & t16
. mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField37 , & t87 [ 0ULL ] , & t90 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [
0 ] = od_efOut [ 0 ] ; intermediate_der8484 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & pd_efOut [ 0ULL ] , & t9 . mField0 [ 0ULL ] ,
& t9 . mField2 [ 0ULL ] , & t16 . mField1 [ 0ULL ] , & t16 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t87 [ 0ULL ] , & t90 [
0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = pd_efOut [ 0 ] ;
intermediate_der5615 = t406 [ 0ULL ] ; t807 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ;
intermediate_der6295 = - X [ 60ULL ] / ( t807 == 0.0 ? 1.0E-16 : t807 ) *
t802 * 100.0 + intermediate_der8484 ; intermediate_der8484 = ( - X [ 60ULL ]
/ ( t807 == 0.0 ? 1.0E-16 : t807 ) * t805 + 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ) )
* 100.0 + intermediate_der5615 ; intermediate_der5615 = ( (
intermediate_der5616 - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 *
intermediate_der8484 + intermediate_der5618 * intermediate_der5588 ) * 1000.0
) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 + (
intermediate_der5617 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 *
intermediate_der5618 * 1000.0 ) * t805 ) * 0.00093750000000000007 ;
intermediate_der5616 = ( ( t797 - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 *
intermediate_der6295 + intermediate_der5618 * t794 ) * 1000.0 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 + (
intermediate_der5617 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 *
intermediate_der5618 * 1000.0 ) * t802 ) * 0.00093750000000000007 ; t810 = -
( intermediate_der5618 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ) ; t811 =
t700 * t700 ; intermediate_der5617 = ( ( t810 / ( t811 == 0.0 ? 1.0E-16 :
t811 ) * t796 + ( intermediate_der5618 * t805 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 *
intermediate_der8484 ) / ( t700 == 0.0 ? 1.0E-16 : t700 ) ) * 0.01 - X [
61ULL ] * intermediate_der5588 ) * 0.00093750000000000007 ;
intermediate_der5618 = ( ( t810 / ( t811 == 0.0 ? 1.0E-16 : t811 ) *
intermediate_der5589 + ( intermediate_der5618 * t802 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 *
intermediate_der6295 ) / ( t700 == 0.0 ? 1.0E-16 : t700 ) ) * 0.01 - ( X [
61ULL ] * t794 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 ) ) *
0.00093750000000000007 ; if ( X [ 66ULL ] <= 0.0 ) { t797 = 0.0 ; } else {
t797 = ( real_T ) ! ( X [ 66ULL ] >= 1.0 ) ; } if ( X [ 65ULL ] <= 0.0 ) {
intermediate_der8484 = 0.0 ; } else { intermediate_der8484 = ( real_T ) ! ( X
[ 65ULL ] >= 1.0 ) ; } intermediate_der6295 = - intermediate_der8484 *
296.802103844292 + intermediate_der8484 * 4124.48151675695 ; t806 = - t797 *
296.802103844292 + t797 * 461.523 ; t807 = 1.0 / ( t703 == 0.0 ? 1.0E-16 :
t703 ) ; t818 = X [ 63ULL ] * X [ 63ULL ] * intrm_sf_mf_1380 *
intrm_sf_mf_1380 ; t703 = - X [ 64ULL ] / ( t818 == 0.0 ? 1.0E-16 : t818 ) *
X [ 63ULL ] * t806 ; t810 = - X [ 64ULL ] / ( t818 == 0.0 ? 1.0E-16 : t818 )
* X [ 63ULL ] * intermediate_der6295 ; t812 = - X [ 64ULL ] / ( t818 == 0.0 ?
1.0E-16 : t818 ) * intrm_sf_mf_1380 ; if ( X [ 63ULL ] <= 216.59999999999997
) { intermediate_der8485 = 0.0 ; } else { intermediate_der8485 = ( real_T ) !
( X [ 63ULL ] >= 623.15 ) ; } t667 = intermediate_der8178 *
intermediate_der8485 * 2.0 ; if ( X [ 69ULL ] <= 0.0 ) { t817 = 0.0 ; } else
{ t817 = ( real_T ) ! ( X [ 69ULL ] >= 1.0 ) ; } if ( X [ 70ULL ] <= 0.0 ) {
t818 = 0.0 ; } else { t818 = ( real_T ) ! ( X [ 70ULL ] >= 1.0 ) ; }
intermediate_der6371 = - t818 * 296.802103844292 + t818 * 4124.48151675695 ;
intermediate_der6372 = - t817 * 296.802103844292 + t817 * 461.523 ;
intermediate_der6415 = 1.0 / ( t705 == 0.0 ? 1.0E-16 : t705 ) ; t825 = X [
67ULL ] * X [ 67ULL ] * intrm_sf_mf_1399 * intrm_sf_mf_1399 ; t705 = - X [
68ULL ] / ( t825 == 0.0 ? 1.0E-16 : t825 ) * X [ 67ULL ] *
intermediate_der6372 ; intermediate_der6417 = - X [ 68ULL ] / ( t825 == 0.0 ?
1.0E-16 : t825 ) * X [ 67ULL ] * intermediate_der6371 ; intermediate_der6418
= - X [ 68ULL ] / ( t825 == 0.0 ? 1.0E-16 : t825 ) * intrm_sf_mf_1399 ; if (
X [ 67ULL ] <= 216.59999999999997 ) { t824 = 0.0 ; } else { t824 = ( real_T )
! ( X [ 67ULL ] >= 623.15 ) ; } t670 = intermediate_der8219 * t824 * 2.0 ; if
( X [ 73ULL ] <= 0.0 ) { t825 = 0.0 ; } else { t825 = ( real_T ) ! ( X [
73ULL ] >= 1.0 ) ; } if ( X [ 72ULL ] <= 0.0 ) { intermediate_der8490 = 0.0 ;
} else { intermediate_der8490 = ( real_T ) ! ( X [ 72ULL ] >= 1.0 ) ; }
intermediate_der7150 = - intermediate_der8490 * 296.802103844292 +
intermediate_der8490 * 259.836612622973 ; intermediate_der7151 = - t825 *
296.802103844292 + t825 * 461.523 ; intermediate_der7152 = 1.0 / ( t707 ==
0.0 ? 1.0E-16 : t707 ) ; intermediate_der8492 = X [ 71ULL ] * X [ 71ULL ] *
intrm_sf_mf_1634 * intrm_sf_mf_1634 ; t707 = - X [ 55ULL ] / (
intermediate_der8492 == 0.0 ? 1.0E-16 : intermediate_der8492 ) * X [ 71ULL ]
* intermediate_der7150 ; intermediate_der7154 = - X [ 55ULL ] / (
intermediate_der8492 == 0.0 ? 1.0E-16 : intermediate_der8492 ) * X [ 71ULL ]
* intermediate_der7151 ; intermediate_der7155 = - X [ 55ULL ] / (
intermediate_der8492 == 0.0 ? 1.0E-16 : intermediate_der8492 ) *
intrm_sf_mf_1634 ; if ( X [ 71ULL ] <= 216.59999999999997 ) { t831 = 0.0 ; }
else { t831 = ( real_T ) ! ( X [ 71ULL ] >= 623.15 ) ; } t673 =
intermediate_der8372 * t831 * 2.0 ; if ( X [ 76ULL ] <= 0.0 ) {
intermediate_der8492 = 0.0 ; } else { intermediate_der8492 = ( real_T ) ! ( X
[ 76ULL ] >= 1.0 ) ; } if ( X [ 75ULL ] <= 0.0 ) { intermediate_der8496 = 0.0
; } else { intermediate_der8496 = ( real_T ) ! ( X [ 75ULL ] >= 1.0 ) ; }
intermediate_der7244 = - intermediate_der8496 * 296.802103844292 +
intermediate_der8496 * 4124.48151675695 ; intermediate_der7245 = -
intermediate_der8492 * 296.802103844292 + intermediate_der8492 * 461.523 ;
intermediate_der7246 = 1.0 / ( t709 == 0.0 ? 1.0E-16 : t709 ) ; t839 = X [
74ULL ] * X [ 74ULL ] * intrm_sf_mf_1659 * intrm_sf_mf_1659 ; t709 = - X [
38ULL ] / ( t839 == 0.0 ? 1.0E-16 : t839 ) * X [ 74ULL ] *
intermediate_der7245 ; intermediate_der7248 = - X [ 38ULL ] / ( t839 == 0.0 ?
1.0E-16 : t839 ) * X [ 74ULL ] * intermediate_der7244 ; intermediate_der7249
= - X [ 38ULL ] / ( t839 == 0.0 ? 1.0E-16 : t839 ) * intrm_sf_mf_1659 ; if (
X [ 74ULL ] <= 216.59999999999997 ) { t838 = 0.0 ; } else { t838 = ( real_T )
! ( X [ 74ULL ] >= 623.15 ) ; } t676 = intermediate_der8385 * t838 * 2.0 ;
t839 = - intermediate_der7477 * ( ( 1074.1165326382554 + intermediate_der7478
* - 0.22145652610641059 ) + t583 * 0.0003721298010901061 ) + ( (
900.639412248396 + intermediate_der7478 * - 0.044484923911441127 ) + t583 *
0.00036936011832051582 ) * intermediate_der7477 ; intermediate_der7477 = -
t774 * ( ( 1074.1165326382554 + intermediate_der7478 * - 0.22145652610641059
) + t583 * 0.0003721298010901061 ) + ( ( 1479.6504774710402 +
intermediate_der7478 * 1.2002114337050787 ) + t583 * - 0.00038614513167845434
) * t774 ; intermediate_der7478 = ( ( intermediate_der8479 * -
0.22145652610641059 + t857 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der7612 ) - intermediate_der7613 ) + ( intermediate_der8479 *
1.2002114337050787 + t857 * - 0.00038614513167845434 ) * intermediate_der7612
) + ( intermediate_der8479 * - 0.044484923911441127 + t857 *
0.00036936011832051582 ) * intermediate_der7613 ; intermediate_der7612 = -
intermediate_der8481 * ( ( 1074.1165326382554 + intermediate_der7614 * -
0.22145652610641059 ) + t586 * 0.0003721298010901061 ) + ( ( 900.639412248396
+ intermediate_der7614 * - 0.044484923911441127 ) + t586 *
0.00036936011832051582 ) * intermediate_der8481 ; intermediate_der7613 = -
t781 * ( ( 1074.1165326382554 + intermediate_der7614 * - 0.22145652610641059
) + t586 * 0.0003721298010901061 ) + ( ( 1479.6504774710402 +
intermediate_der7614 * 1.2002114337050787 ) + t586 * - 0.00038614513167845434
) * t781 ; intermediate_der7614 = ( ( t787 * - 0.22145652610641059 + t858 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der8176 ) -
intermediate_der8177 ) + ( t787 * 1.2002114337050787 + t858 * -
0.00038614513167845434 ) * intermediate_der8176 ) + ( t787 * -
0.044484923911441127 + t858 * 0.00036936011832051582 ) * intermediate_der8177
; intermediate_der8176 = - intermediate_der8484 * ( ( 1074.1165326382554 +
intermediate_der8178 * - 0.22145652610641059 ) + t589 * 0.0003721298010901061
) + ( ( 12825.281119789837 + intermediate_der8178 * 6.9647057412840034 ) +
t589 * - 0.0070524868246844051 ) * intermediate_der8484 ;
intermediate_der8177 = - t797 * ( ( 1074.1165326382554 + intermediate_der8178
* - 0.22145652610641059 ) + t589 * 0.0003721298010901061 ) + ( (
1479.6504774710402 + intermediate_der8178 * 1.2002114337050787 ) + t589 * -
0.00038614513167845434 ) * t797 ; intermediate_der8178 = ( (
intermediate_der8485 * - 0.22145652610641059 + t667 * 0.0003721298010901061 )
* ( ( 1.0 - intermediate_der8217 ) - t701 ) + ( intermediate_der8485 *
1.2002114337050787 + t667 * - 0.00038614513167845434 ) * intermediate_der8217
) + ( intermediate_der8485 * 6.9647057412840034 + t667 * -
0.0070524868246844051 ) * t701 ; intermediate_der8217 = - t818 * ( (
1074.1165326382554 + intermediate_der8219 * - 0.22145652610641059 ) + t850 *
0.0003721298010901061 ) + ( ( 12825.281119789837 + intermediate_der8219 *
6.9647057412840034 ) + t850 * - 0.0070524868246844051 ) * t818 ; t701 = -
t817 * ( ( 1074.1165326382554 + intermediate_der8219 * - 0.22145652610641059
) + t850 * 0.0003721298010901061 ) + ( ( 1479.6504774710402 +
intermediate_der8219 * 1.2002114337050787 ) + t850 * - 0.00038614513167845434
) * t817 ; intermediate_der8219 = ( ( t824 * - 0.22145652610641059 + t670 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der8370 ) -
intermediate_der8371 ) + ( t824 * 1.2002114337050787 + t670 * -
0.00038614513167845434 ) * intermediate_der8370 ) + ( t824 *
6.9647057412840034 + t670 * - 0.0070524868246844051 ) * intermediate_der8371
; intermediate_der8370 = - intermediate_der8490 * ( ( 1074.1165326382554 +
intermediate_der8372 * - 0.22145652610641059 ) + t845 * 0.0003721298010901061
) + ( ( 900.639412248396 + intermediate_der8372 * - 0.044484923911441127 ) +
t845 * 0.00036936011832051582 ) * intermediate_der8490 ; intermediate_der8371
= - t825 * ( ( 1074.1165326382554 + intermediate_der8372 * -
0.22145652610641059 ) + t845 * 0.0003721298010901061 ) + ( (
1479.6504774710402 + intermediate_der8372 * 1.2002114337050787 ) + t845 * -
0.00038614513167845434 ) * t825 ; intermediate_der8372 = ( ( t831 * -
0.22145652610641059 + t673 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der8383 ) - intermediate_der8384 ) + ( t831 * 1.2002114337050787
+ t673 * - 0.00038614513167845434 ) * intermediate_der8383 ) + ( t831 * -
0.044484923911441127 + t673 * 0.00036936011832051582 ) * intermediate_der8384
; intermediate_der8383 = - intermediate_der8496 * ( ( 1074.1165326382554 +
intermediate_der8385 * - 0.22145652610641059 ) + t847 * 0.0003721298010901061
) + ( ( 12825.281119789837 + intermediate_der8385 * 6.9647057412840034 ) +
t847 * - 0.0070524868246844051 ) * intermediate_der8496 ;
intermediate_der8384 = - intermediate_der8492 * ( ( 1074.1165326382554 +
intermediate_der8385 * - 0.22145652610641059 ) + t847 * 0.0003721298010901061
) + ( ( 1479.6504774710402 + intermediate_der8385 * 1.2002114337050787 ) +
t847 * - 0.00038614513167845434 ) * intermediate_der8492 ;
intermediate_der8385 = ( ( t838 * - 0.22145652610641059 + t676 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der8476 ) -
intermediate_der8477 ) + ( t838 * 1.2002114337050787 + t676 * -
0.00038614513167845434 ) * intermediate_der8476 ) + ( t838 *
6.9647057412840034 + t676 * - 0.0070524868246844051 ) * intermediate_der8477
; t847 = X [ 15ULL ] * X [ 15ULL ] ; intermediate_der8477 = - ( X [ 158ULL ]
* X [ 161ULL ] * 0.001 ) / ( t847 == 0.0 ? 1.0E-16 : t847 ) * 1.0E-5 ; t847 =
X [ 7ULL ] * X [ 7ULL ] ; t850 = X [ 7ULL ] * 287.0 ; t858 = X [ 7ULL ] * X [
7ULL ] * 82369.0 ; tlu2_2d_linear_linear_value ( & qd_efOut [ 0ULL ] , & t18
. mField1 [ 0ULL ] , & t18 . mField2 [ 0ULL ] , & t7 . mField0 [ 0ULL ] , &
t7 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t33
[ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = qd_efOut [ 0 ] ;
t818 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & rd_efOut [ 0ULL ] , &
t18 . mField0 [ 0ULL ] , & t18 . mField2 [ 0ULL ] , & t7 . mField1 [ 0ULL ] ,
& t7 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , &
t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = rd_efOut [ 0
] ; t824 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & sd_efOut [ 0ULL ]
, & t18 . mField1 [ 0ULL ] , & t18 . mField2 [ 0ULL ] , & t7 . mField0 [ 0ULL
] , & t7 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField9 ,
& t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = sd_efOut [
0 ] ; t825 = t406 [ 0ULL ] ; tlu2_2d_linear_linear_value ( & td_efOut [ 0ULL
] , & t18 . mField0 [ 0ULL ] , & t18 . mField2 [ 0ULL ] , & t7 . mField1 [
0ULL ] , & t7 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField9 , & t33 [ 0ULL ] , & t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] =
td_efOut [ 0 ] ; intermediate_der8490 = t406 [ 0ULL ] ;
tlu2_2d_linear_linear_value ( & ud_efOut [ 0ULL ] , & t18 . mField1 [ 0ULL ]
, & t18 . mField2 [ 0ULL ] , & t7 . mField0 [ 0ULL ] , & t7 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , & t36 [
0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = ud_efOut [ 0 ] ; t831 = t406 [ 0ULL
] ; tlu2_2d_linear_linear_value ( & vd_efOut [ 0ULL ] , & t18 . mField0 [
0ULL ] , & t18 . mField2 [ 0ULL ] , & t7 . mField1 [ 0ULL ] , & t7 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField10 , & t33 [ 0ULL ] , &
t36 [ 0ULL ] , & t34 [ 0ULL ] ) ; t406 [ 0 ] = vd_efOut [ 0 ] ;
intermediate_der8492 = t406 [ 0ULL ] ; t586 = t682 * intermediate_der8769 *
0.005 ; t589 = t682 * X [ 164ULL ] * t818 * 0.005 ; t818 = t682 * X [ 164ULL
] * t824 * 0.005 ; t824 = X [ 164ULL ] * - 0.2 * intermediate_der8769 * 0.005
; intermediate_der8769 = - intermediate_der8770 * ( ( 1074.1165326382554 +
intermediate_der8975 * - 0.22145652610641059 ) + t565 * 0.0003721298010901061
) + ( ( 12825.281119789837 + intermediate_der8975 * 6.9647057412840034 ) +
t565 * - 0.0070524868246844051 ) * intermediate_der8770 ;
intermediate_der8770 = ( ( t875 * - 0.22145652610641059 + t643 *
0.0003721298010901061 ) * ( ( 1.0 - t1118 ) - t1110 ) + ( t875 *
1.2002114337050787 + t643 * - 0.00038614513167845434 ) * t1118 ) + ( t875 *
6.9647057412840034 + t643 * - 0.0070524868246844051 ) * t1110 ; t1118 = -
t1128 * ( ( 1074.1165326382554 + intermediate_der8975 * - 0.22145652610641059
) + t565 * 0.0003721298010901061 ) + ( ( 1479.6504774710402 +
intermediate_der8975 * 1.2002114337050787 ) + t565 * - 0.00038614513167845434
) * t1128 ; t1128 = - t727 * ( ( 1074.1165326382554 + intermediate_der9130 *
- 0.22145652610641059 ) + t568 * 0.0003721298010901061 ) + ( (
12825.281119789837 + intermediate_der9130 * 6.9647057412840034 ) + t568 * -
0.0070524868246844051 ) * t727 ; t1110 = - t724 * ( ( 1074.1165326382554 +
intermediate_der9130 * - 0.22145652610641059 ) + t568 * 0.0003721298010901061
) + ( ( 1479.6504774710402 + intermediate_der9130 * 1.2002114337050787 ) +
t568 * - 0.00038614513167845434 ) * t724 ; intermediate_der8975 = ( ( t738 *
- 0.22145652610641059 + t646 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der9128 ) - intermediate_der9129 ) + ( t738 * 1.2002114337050787
+ t646 * - 0.00038614513167845434 ) * intermediate_der9128 ) + ( t738 *
6.9647057412840034 + t646 * - 0.0070524868246844051 ) * intermediate_der9129
; intermediate_der9128 = - t745 * ( ( 1074.1165326382554 +
intermediate_der9299 * - 0.22145652610641059 ) + t571 * 0.0003721298010901061
) + ( ( 12825.281119789837 + intermediate_der9299 * 6.9647057412840034 ) +
t571 * - 0.0070524868246844051 ) * t745 ; intermediate_der9129 = - t739 * ( (
1074.1165326382554 + intermediate_der9299 * - 0.22145652610641059 ) + t571 *
0.0003721298010901061 ) + ( ( 1479.6504774710402 + intermediate_der9299 *
1.2002114337050787 ) + t571 * - 0.00038614513167845434 ) * t739 ;
intermediate_der9130 = ( ( t752 * - 0.22145652610641059 + t649 *
0.0003721298010901061 ) * ( ( 1.0 - intermediate_der9297 ) -
intermediate_der9298 ) + ( t752 * 1.2002114337050787 + t649 * -
0.00038614513167845434 ) * intermediate_der9297 ) + ( t752 *
6.9647057412840034 + t649 * - 0.0070524868246844051 ) * intermediate_der9298
; intermediate_der9297 = - intermediate_der2531 * ( ( 1074.1165326382554 +
intermediate_der9440 * - 0.22145652610641059 ) + t574 * 0.0003721298010901061
) + ( ( 12825.281119789837 + intermediate_der9440 * 6.9647057412840034 ) +
t574 * - 0.0070524868246844051 ) * intermediate_der2531 ;
intermediate_der9298 = - t753 * ( ( 1074.1165326382554 + intermediate_der9440
* - 0.22145652610641059 ) + t574 * 0.0003721298010901061 ) + ( (
1479.6504774710402 + intermediate_der9440 * 1.2002114337050787 ) + t574 * -
0.00038614513167845434 ) * t753 ; intermediate_der9299 = ( ( t759 * -
0.22145652610641059 + t652 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der9438 ) - intermediate_der9439 ) + ( t759 * 1.2002114337050787
+ t652 * - 0.00038614513167845434 ) * intermediate_der9438 ) + ( t759 *
6.9647057412840034 + t652 * - 0.0070524868246844051 ) * intermediate_der9439
; intermediate_der9438 = - intermediate_der3090 * ( ( 1074.1165326382554 +
intermediate_der9574 * - 0.22145652610641059 ) + t577 * 0.0003721298010901061
) + ( ( 900.639412248396 + intermediate_der9574 * - 0.044484923911441127 ) +
t577 * 0.00036936011832051582 ) * intermediate_der3090 ; intermediate_der9439
= - t760 * ( ( 1074.1165326382554 + intermediate_der9574 * -
0.22145652610641059 ) + t577 * 0.0003721298010901061 ) + ( (
1479.6504774710402 + intermediate_der9574 * 1.2002114337050787 ) + t577 * -
0.00038614513167845434 ) * t760 ; intermediate_der9440 = ( ( t766 * -
0.22145652610641059 + t655 * 0.0003721298010901061 ) * ( ( 1.0 -
intermediate_der9572 ) - intermediate_der9573 ) + ( t766 * 1.2002114337050787
+ t655 * - 0.00038614513167845434 ) * intermediate_der9572 ) + ( t766 * -
0.044484923911441127 + t655 * 0.00036936011832051582 ) * intermediate_der9573
; intermediate_der9572 = - intermediate_der3779 * ( ( 1074.1165326382554 +
t889 * - 0.22145652610641059 ) + t580 * 0.0003721298010901061 ) + ( (
900.639412248396 + t889 * - 0.044484923911441127 ) + t580 *
0.00036936011832051582 ) * intermediate_der3779 ; intermediate_der9573 = -
t767 * ( ( 1074.1165326382554 + t889 * - 0.22145652610641059 ) + t580 *
0.0003721298010901061 ) + ( ( 1479.6504774710402 + t889 * 1.2002114337050787
) + t580 * - 0.00038614513167845434 ) * t767 ; intermediate_der9574 = ( (
t773 * - 0.22145652610641059 + t658 * 0.0003721298010901061 ) * ( ( 1.0 -
t878 ) - t892 ) + ( t773 * 1.2002114337050787 + t658 * -
0.00038614513167845434 ) * t878 ) + ( t773 * - 0.044484923911441127 + t658 *
0.00036936011832051582 ) * t892 ; t407 [ 0ULL ] = - ( - ( X [ 158ULL ] *
0.001 ) * X [ 161ULL ] ) / ( t847 == 0.0 ? 1.0E-16 : t847 ) /
1.1843079200592157 ; t407 [ 1ULL ] = - ( ( 1.0 / ( X [ 7ULL ] == 0.0 ?
1.0E-16 : X [ 7ULL ] ) + - ( X [ 7ULL ] + 126.84999999999997 ) / ( t847 ==
0.0 ? 1.0E-16 : t847 ) ) * 1000.0 ) * X [ 161ULL ] * X [ 158ULL ] * 0.001 *
0.001 ; t407 [ 2ULL ] = - ( t682 * X [ 161ULL ] * intrm_sf_mf_1792 * 0.005 )
; t407 [ 3ULL ] = ( t682 * X [ 161ULL ] * 0.005 / ( intrm_sf_mf_1793 == 0.0 ?
1.0E-16 : intrm_sf_mf_1793 ) * 0.01 + ( - ( X [ 7ULL ] + 126.84999999999997 )
/ ( t858 == 0.0 ? 1.0E-16 : t858 ) * 287.0 + 1.0 / ( t850 == 0.0 ? 1.0E-16 :
t850 ) ) * X [ 158ULL ] ) * 100.0 ; t408 [ 0ULL ] = - ( t682 * X [ 161ULL ] *
t825 * 0.005 ) / 1.1843079200592157 ; t408 [ 1ULL ] = - ( ( X [ 7ULL ] +
126.84999999999997 ) * t682 * X [ 161ULL ] * t825 * 0.005 ) ; t408 [ 2ULL ] =
t589 * 0.001 ; t878 = - ( t682 * X [ 161ULL ] * 0.005 ) ; t892 =
intrm_sf_mf_1793 * intrm_sf_mf_1793 ; t408 [ 3ULL ] = t878 / ( t892 == 0.0 ?
1.0E-16 : t892 ) * t831 / 1.1843079200592157 ; t889 = - ( ( X [ 7ULL ] +
126.84999999999997 ) * t682 * X [ 161ULL ] * 0.005 ) ; t408 [ 4ULL ] = t889 /
( t892 == 0.0 ? 1.0E-16 : t892 ) * t831 ; t408 [ 5ULL ] = ( -
intrm_sf_mf_1792 + - t825 * X [ 8ULL ] ) * t682 * 0.005 * 100.0 ; t409 [ 0ULL
] = - ( t682 * X [ 161ULL ] * intermediate_der8490 * 0.005 ) /
1.1843079200592157 ; t409 [ 1ULL ] = - ( ( X [ 7ULL ] + 126.84999999999997 )
* t682 * X [ 161ULL ] * intermediate_der8490 * 0.005 ) ; t409 [ 2ULL ] = t818
* 0.001 ; t409 [ 3ULL ] = ( t878 / ( t892 == 0.0 ? 1.0E-16 : t892 ) *
intermediate_der8492 * 1.0E-5 + intermediate_der8477 ) * 100000.0 /
1.1843079200592157 ; t409 [ 4ULL ] = t889 / ( t892 == 0.0 ? 1.0E-16 : t892 )
* intermediate_der8492 ; t409 [ 5ULL ] = - intermediate_der8490 * X [ 8ULL ]
* t682 * 0.005 * 100.0 ; t892 = X [ 21ULL ] * X [ 21ULL ] ; t410 [ 0ULL ] = (
- ( 1.0 / ( X [ 21ULL ] == 0.0 ? 1.0E-16 : X [ 21ULL ] ) ) * t718 + - ( - 1.0
/ ( t892 == 0.0 ? 1.0E-16 : t892 ) ) * t1085 ) * 7.8539816339744828 /
12.896402563644669 ; t410 [ 1ULL ] = ( ( intrm_sf_mf_202 - t1090 ) * t718 +
t1085 * intermediate_der8770 ) * 0.0078539816339744835 / 2246.65922904024 ;
t410 [ 2ULL ] = 1.0 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) * t718 *
7.8539816339744828 / 12.896402563644669 ; t410 [ 3ULL ] = t718 *
7.8539816339744828 ; t410 [ 4ULL ] = t718 * 7.8539816339744828 ; t411 [ 0ULL
] = - ( 1.0 / ( X [ 21ULL ] == 0.0 ? 1.0E-16 : X [ 21ULL ] ) ) *
intermediate_der501 * 7.8539816339744828 / 12.896402563644669 ; t411 [ 1ULL ]
= ( intrm_sf_mf_202 - t1090 ) * intermediate_der501 * 0.0078539816339744835 /
2246.65922904024 ; t892 = X [ 22ULL ] * X [ 22ULL ] ; t411 [ 2ULL ] = ( 1.0 /
( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) * intermediate_der501 + - 1.0
/ ( t892 == 0.0 ? 1.0E-16 : t892 ) * t1085 ) * 7.8539816339744828 /
12.896402563644669 ; t411 [ 3ULL ] = intermediate_der501 * 7.8539816339744828
; t411 [ 4ULL ] = intermediate_der501 * 7.8539816339744828 ; t412 [ 0ULL ] =
- ( 1.0 / ( X [ 21ULL ] == 0.0 ? 1.0E-16 : X [ 21ULL ] ) ) *
intermediate_der737 * 7.8539816339744828 / 12.896402563644669 ; t412 [ 1ULL ]
= ( ( intrm_sf_mf_202 - t1090 ) * intermediate_der737 + ( t1118 -
intermediate_der691 ) * t1085 ) * 0.0078539816339744835 / 2246.65922904024 ;
t412 [ 2ULL ] = 1.0 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) *
intermediate_der737 * 7.8539816339744828 / 12.896402563644669 ; t412 [ 3ULL ]
= intermediate_der737 * 7.8539816339744828 ; t412 [ 4ULL ] =
intermediate_der737 * 7.8539816339744828 ; t413 [ 0ULL ] = - ( 1.0 / ( X [
21ULL ] == 0.0 ? 1.0E-16 : X [ 21ULL ] ) ) * t710 * 7.8539816339744828 /
12.896402563644669 ; t413 [ 1ULL ] = ( ( intrm_sf_mf_202 - t1090 ) * t710 + (
intermediate_der8769 - intermediate_der499 ) * t1085 ) *
0.0078539816339744835 / 2246.65922904024 ; t413 [ 2ULL ] = 1.0 / ( X [ 22ULL
] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) * t710 * 7.8539816339744828 /
12.896402563644669 ; t413 [ 3ULL ] = t710 * 7.8539816339744828 ; t413 [ 4ULL
] = t710 * 7.8539816339744828 ; t1090 = X [ 25ULL ] * X [ 25ULL ] ; t414 [
0ULL ] = ( - ( 1.0 / ( X [ 25ULL ] == 0.0 ? 1.0E-16 : X [ 25ULL ] ) ) * t733
+ - ( - 1.0 / ( t1090 == 0.0 ? 1.0E-16 : t1090 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 ) *
3681.3041167499323 / 12.896402563644669 ; t414 [ 1ULL ] = ( ( intrm_sf_mf_377
- intrm_sf_mf_270 ) * t733 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 *
intermediate_der8975 ) * 3.6813041167499323 / 2246.65922904024 ; t414 [ 2ULL
] = t733 * 3681.3041167499323 ; t414 [ 3ULL ] = t733 * 3681.3041167499323 ;
t414 [ 4ULL ] = 1.0 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) * t733 *
3681.3041167499323 / 12.896402563644669 ; t415 [ 0ULL ] = - ( 1.0 / ( X [
25ULL ] == 0.0 ? 1.0E-16 : X [ 25ULL ] ) ) * t736 * 3681.3041167499323 /
12.896402563644669 ; t415 [ 1ULL ] = ( ( intrm_sf_mf_377 - intrm_sf_mf_270 )
* t736 + ( t1128 - t728 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 ) *
3.6813041167499323 / 2246.65922904024 ; t415 [ 2ULL ] = t736 *
3681.3041167499323 ; t415 [ 3ULL ] = t736 * 3681.3041167499323 ; t415 [ 4ULL
] = 1.0 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) * t736 *
3681.3041167499323 / 12.896402563644669 ; t416 [ 0ULL ] = - ( 1.0 / ( X [
25ULL ] == 0.0 ? 1.0E-16 : X [ 25ULL ] ) ) * t686 * 3681.3041167499323 /
12.896402563644669 ; t416 [ 1ULL ] = ( ( intrm_sf_mf_377 - intrm_sf_mf_270 )
* t686 + ( t1110 - t729 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 ) *
3.6813041167499323 / 2246.65922904024 ; t416 [ 2ULL ] = t686 *
3681.3041167499323 ; t416 [ 3ULL ] = t686 * 3681.3041167499323 ; t416 [ 4ULL
] = 1.0 / ( X [ 31ULL ] == 0.0 ? 1.0E-16 : X [ 31ULL ] ) * t686 *
3681.3041167499323 / 12.896402563644669 ; t1110 = X [ 28ULL ] * X [ 28ULL ] ;
t417 [ 0ULL ] = ( - ( 1.0 / ( X [ 28ULL ] == 0.0 ? 1.0E-16 : X [ 28ULL ] ) )
* intermediate_der2021 + - ( - 1.0 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 ) *
3681.3041167499323 / 13.896402563644669 ; t417 [ 1ULL ] = ( ( intrm_sf_mf_514
- intrm_sf_mf_407 ) * intermediate_der2021 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 *
intermediate_der9130 ) * 3.6813041167499323 / 2448.8207083326588 ; t417 [
2ULL ] = intermediate_der2021 * 3681.3041167499323 ; t417 [ 3ULL ] =
intermediate_der2021 * 3681.3041167499323 ; t417 [ 4ULL ] = 1.0 / ( X [ 33ULL
] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) * intermediate_der2021 *
3681.3041167499323 / 13.896402563644669 ; t418 [ 0ULL ] = - ( 1.0 / ( X [
28ULL ] == 0.0 ? 1.0E-16 : X [ 28ULL ] ) ) * intermediate_der2020 *
3681.3041167499323 / 13.896402563644669 ; t418 [ 1ULL ] = ( ( intrm_sf_mf_514
- intrm_sf_mf_407 ) * intermediate_der2020 + ( intermediate_der9128 - t746 )
* Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 ) *
3.6813041167499323 / 2448.8207083326588 ; t418 [ 2ULL ] =
intermediate_der2020 * 3681.3041167499323 ; t418 [ 3ULL ] =
intermediate_der2020 * 3681.3041167499323 ; t418 [ 4ULL ] = 1.0 / ( X [ 33ULL
] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) * intermediate_der2020 *
3681.3041167499323 / 13.896402563644669 ; t419 [ 0ULL ] = - ( 1.0 / ( X [
28ULL ] == 0.0 ? 1.0E-16 : X [ 28ULL ] ) ) * t688 * 3681.3041167499323 /
13.896402563644669 ; t419 [ 1ULL ] = ( ( intrm_sf_mf_514 - intrm_sf_mf_407 )
* t688 + ( intermediate_der9129 - intermediate_der1975 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 ) *
3.6813041167499323 / 2448.8207083326588 ; t419 [ 2ULL ] = t688 *
3681.3041167499323 ; t419 [ 3ULL ] = t688 * 3681.3041167499323 ; t419 [ 4ULL
] = 1.0 / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) * t688 *
3681.3041167499323 / 13.896402563644669 ; t420 [ 0ULL ] = - ( 1.0 / ( X [
25ULL ] == 0.0 ? 1.0E-16 : X [ 25ULL ] ) ) * t730 * 3681.3041167499323 /
12.896402563644669 ; t420 [ 1ULL ] = ( intrm_sf_mf_377 - intrm_sf_mf_270 ) *
t730 * 3.6813041167499323 / 2246.65922904024 ; t420 [ 2ULL ] = t730 *
3681.3041167499323 ; t420 [ 3ULL ] = t730 * 3681.3041167499323 ; t1118 = X [
31ULL ] * X [ 31ULL ] ; t420 [ 4ULL ] = ( 1.0 / ( X [ 31ULL ] == 0.0 ?
1.0E-16 : X [ 31ULL ] ) * t730 + - 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi43 ) *
3681.3041167499323 / 12.896402563644669 ; t421 [ 0ULL ] = - ( 1.0 / ( X [
28ULL ] == 0.0 ? 1.0E-16 : X [ 28ULL ] ) ) * intermediate_der2018 *
3681.3041167499323 / 13.896402563644669 ; t421 [ 1ULL ] = ( intrm_sf_mf_514 -
intrm_sf_mf_407 ) * intermediate_der2018 * 3.6813041167499323 /
2448.8207083326588 ; t421 [ 2ULL ] = intermediate_der2018 *
3681.3041167499323 ; t421 [ 3ULL ] = intermediate_der2018 *
3681.3041167499323 ; t1128 = X [ 33ULL ] * X [ 33ULL ] ; t421 [ 4ULL ] = (
1.0 / ( X [ 33ULL ] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) * intermediate_der2018 +
- 1.0 / ( t1128 == 0.0 ? 1.0E-16 : t1128 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi100 ) *
3681.3041167499323 / 13.896402563644669 ; t1118 = X [ 34ULL ] * X [ 34ULL ] ;
t422 [ 0ULL ] = ( - ( 1.0 / ( X [ 34ULL ] == 0.0 ? 1.0E-16 : X [ 34ULL ] ) )
* intermediate_der2579 + - ( - 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 ) *
49.087385212340521 / 12.896402563644669 ; t422 [ 1ULL ] = ( ( intrm_sf_mf_652
- intrm_sf_mf_545 ) * intermediate_der2579 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 *
intermediate_der9299 ) * 0.049087385212340524 / 2246.65922904024 ; t422 [
2ULL ] = intermediate_der2579 * 49.087385212340521 ; t422 [ 3ULL ] =
intermediate_der2579 * 49.087385212340521 ; t422 [ 4ULL ] = 1.0 / ( X [ 37ULL
] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) * intermediate_der2579 *
49.087385212340521 / 12.896402563644669 ; t423 [ 0ULL ] = - ( 1.0 / ( X [
34ULL ] == 0.0 ? 1.0E-16 : X [ 34ULL ] ) ) * intermediate_der2578 *
49.087385212340521 / 12.896402563644669 ; t423 [ 1ULL ] = ( ( intrm_sf_mf_652
- intrm_sf_mf_545 ) * intermediate_der2578 + ( intermediate_der9297 -
intermediate_der2532 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 ) *
0.049087385212340524 / 2246.65922904024 ; t423 [ 2ULL ] =
intermediate_der2578 * 49.087385212340521 ; t423 [ 3ULL ] =
intermediate_der2578 * 49.087385212340521 ; t423 [ 4ULL ] = 1.0 / ( X [ 37ULL
] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) * intermediate_der2578 *
49.087385212340521 / 12.896402563644669 ; t424 [ 0ULL ] = - ( 1.0 / ( X [
34ULL ] == 0.0 ? 1.0E-16 : X [ 34ULL ] ) ) * t690 * 49.087385212340521 /
12.896402563644669 ; t424 [ 1ULL ] = ( ( intrm_sf_mf_652 - intrm_sf_mf_545 )
* t690 + ( intermediate_der9298 - intermediate_der2533 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 ) *
0.049087385212340524 / 2246.65922904024 ; t424 [ 2ULL ] = t690 *
49.087385212340521 ; t424 [ 3ULL ] = t690 * 49.087385212340521 ; t424 [ 4ULL
] = 1.0 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) * t690 *
49.087385212340521 / 12.896402563644669 ; t425 [ 0ULL ] = - ( 1.0 / ( X [
34ULL ] == 0.0 ? 1.0E-16 : X [ 34ULL ] ) ) * intermediate_der2576 *
49.087385212340521 / 12.896402563644669 ; t425 [ 1ULL ] = ( intrm_sf_mf_652 -
intrm_sf_mf_545 ) * intermediate_der2576 * 0.049087385212340524 /
2246.65922904024 ; t425 [ 2ULL ] = intermediate_der2576 * 49.087385212340521
; t425 [ 3ULL ] = intermediate_der2576 * 49.087385212340521 ; t1128 = X [
37ULL ] * X [ 37ULL ] ; t425 [ 4ULL ] = ( 1.0 / ( X [ 37ULL ] == 0.0 ?
1.0E-16 : X [ 37ULL ] ) * intermediate_der2576 + - 1.0 / ( t1128 == 0.0 ?
1.0E-16 : t1128 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_41 ) *
49.087385212340521 / 12.896402563644669 ; t1128 = X [ 38ULL ] * X [ 38ULL ] ;
t426 [ 0ULL ] = ( 1.0 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) *
intermediate_der7246 + - 1.0 / ( t1128 == 0.0 ? 1.0E-16 : t1128 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 ) *
12.500000000000004 / 12.896402563644669 ; t426 [ 1ULL ] = - ( 1.0 / ( X [
74ULL ] == 0.0 ? 1.0E-16 : X [ 74ULL ] ) ) * intermediate_der7246 *
12.500000000000004 / 12.896402563644669 ; t426 [ 2ULL ] = ( intrm_sf_mf_1684
- intrm_sf_mf_1659 ) * intermediate_der7246 * 0.012500000000000002 /
2246.65922904024 ; t426 [ 3ULL ] = intermediate_der7246 * 12.500000000000004
; t426 [ 4ULL ] = intermediate_der7246 * 12.500000000000004 ; t1110 = X [
39ULL ] * X [ 39ULL ] ; t427 [ 0ULL ] = ( - ( 1.0 / ( X [ 39ULL ] == 0.0 ?
1.0E-16 : X [ 39ULL ] ) ) * intermediate_der3138 + - ( - 1.0 / ( t1110 == 0.0
? 1.0E-16 : t1110 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) *
196.34954084936209 ; t427 [ 1ULL ] = ( ( intrm_sf_mf_801 - intrm_sf_mf_694 )
* intermediate_der3138 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
intermediate_der9440 ) * 0.1963495408493621 / 2172.7681408465714 ; t427 [
2ULL ] = 1.0 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) *
intermediate_der3138 * 196.34954084936209 ; t427 [ 3ULL ] =
intermediate_der3138 * 196.34954084936209 ; t427 [ 4ULL ] =
intermediate_der3138 * 196.34954084936209 ; t428 [ 0ULL ] = - ( 1.0 / ( X [
39ULL ] == 0.0 ? 1.0E-16 : X [ 39ULL ] ) ) * intermediate_der3135 *
196.34954084936209 ; t428 [ 1ULL ] = ( intrm_sf_mf_801 - intrm_sf_mf_694 ) *
intermediate_der3135 * 0.1963495408493621 / 2172.7681408465714 ; t1110 = X [
40ULL ] * X [ 40ULL ] ; t428 [ 2ULL ] = ( 1.0 / ( X [ 40ULL ] == 0.0 ?
1.0E-16 : X [ 40ULL ] ) * intermediate_der3135 + - 1.0 / ( t1110 == 0.0 ?
1.0E-16 : t1110 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) *
196.34954084936209 ; t428 [ 3ULL ] = intermediate_der3135 *
196.34954084936209 ; t428 [ 4ULL ] = intermediate_der3135 *
196.34954084936209 ; t429 [ 0ULL ] = - ( 1.0 / ( X [ 39ULL ] == 0.0 ? 1.0E-16
: X [ 39ULL ] ) ) * t692 * 196.34954084936209 ; t429 [ 1ULL ] = ( (
intrm_sf_mf_801 - intrm_sf_mf_694 ) * t692 + ( intermediate_der9439 -
intermediate_der3092 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) *
0.1963495408493621 / 2172.7681408465714 ; t429 [ 2ULL ] = 1.0 / ( X [ 40ULL ]
== 0.0 ? 1.0E-16 : X [ 40ULL ] ) * t692 * 196.34954084936209 ; t429 [ 3ULL ]
= t692 * 196.34954084936209 ; t429 [ 4ULL ] = t692 * 196.34954084936209 ;
t430 [ 0ULL ] = - ( 1.0 / ( X [ 39ULL ] == 0.0 ? 1.0E-16 : X [ 39ULL ] ) ) *
intermediate_der3137 * 196.34954084936209 ; t430 [ 1ULL ] = ( (
intrm_sf_mf_801 - intrm_sf_mf_694 ) * intermediate_der3137 + (
intermediate_der9438 - intermediate_der3091 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) *
0.1963495408493621 / 2172.7681408465714 ; t430 [ 2ULL ] = 1.0 / ( X [ 40ULL ]
== 0.0 ? 1.0E-16 : X [ 40ULL ] ) * intermediate_der3137 * 196.34954084936209
; t430 [ 3ULL ] = intermediate_der3137 * 196.34954084936209 ; t430 [ 4ULL ] =
intermediate_der3137 * 196.34954084936209 ; t1110 = X [ 43ULL ] * X [ 43ULL ]
; t431 [ 0ULL ] = ( - ( 1.0 / ( X [ 43ULL ] == 0.0 ? 1.0E-16 : X [ 43ULL ] )
) * intermediate_der3827 + - ( - 1.0 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 ) *
3681.3041167499323 ; t431 [ 1ULL ] = ( ( intrm_sf_mf_976 - intrm_sf_mf_869 )
* intermediate_der3827 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 *
intermediate_der9574 ) * 3.6813041167499323 / 2172.7681408465714 ; t431 [
2ULL ] = intermediate_der3827 * 3681.3041167499323 ; t431 [ 3ULL ] =
intermediate_der3827 * 3681.3041167499323 ; t431 [ 4ULL ] = 1.0 / ( X [ 49ULL
] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) * intermediate_der3827 *
3681.3041167499323 ; t432 [ 0ULL ] = - ( 1.0 / ( X [ 43ULL ] == 0.0 ? 1.0E-16
: X [ 43ULL ] ) ) * intermediate_der3826 * 3681.3041167499323 ; t432 [ 1ULL ]
= ( ( intrm_sf_mf_976 - intrm_sf_mf_869 ) * intermediate_der3826 + (
intermediate_der9572 - intermediate_der3780 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 ) *
3.6813041167499323 / 2172.7681408465714 ; t432 [ 2ULL ] =
intermediate_der3826 * 3681.3041167499323 ; t432 [ 3ULL ] =
intermediate_der3826 * 3681.3041167499323 ; t432 [ 4ULL ] = 1.0 / ( X [ 49ULL
] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) * intermediate_der3826 *
3681.3041167499323 ; t433 [ 0ULL ] = - ( 1.0 / ( X [ 43ULL ] == 0.0 ? 1.0E-16
: X [ 43ULL ] ) ) * t694 * 3681.3041167499323 ; t433 [ 1ULL ] = ( (
intrm_sf_mf_976 - intrm_sf_mf_869 ) * t694 + ( intermediate_der9573 -
intermediate_der3781 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 ) *
3.6813041167499323 / 2172.7681408465714 ; t433 [ 2ULL ] = t694 *
3681.3041167499323 ; t433 [ 3ULL ] = t694 * 3681.3041167499323 ; t433 [ 4ULL
] = 1.0 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) * t694 *
3681.3041167499323 ; t1090 = X [ 46ULL ] * X [ 46ULL ] ; t434 [ 0ULL ] = ( -
( 1.0 / ( X [ 46ULL ] == 0.0 ? 1.0E-16 : X [ 46ULL ] ) ) *
intermediate_der4389 + - ( - 1.0 / ( t1090 == 0.0 ? 1.0E-16 : t1090 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 ) *
3681.3041167499323 / 1.5549856083302016 ; t434 [ 1ULL ] = ( (
intrm_sf_mf_1113 - intrm_sf_mf_1006 ) * intermediate_der4389 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 *
intermediate_der7478 ) * 3.6813041167499323 / 2374.9296201389902 ; t434 [
2ULL ] = intermediate_der4389 * 3681.3041167499323 ; t434 [ 3ULL ] =
intermediate_der4389 * 3681.3041167499323 ; t434 [ 4ULL ] = 1.0 / ( X [ 50ULL
] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) * intermediate_der4389 *
3681.3041167499323 / 1.5549856083302016 ; t435 [ 0ULL ] = - ( 1.0 / ( X [
46ULL ] == 0.0 ? 1.0E-16 : X [ 46ULL ] ) ) * intermediate_der4390 *
3681.3041167499323 / 1.5549856083302016 ; t435 [ 1ULL ] = ( (
intrm_sf_mf_1113 - intrm_sf_mf_1006 ) * intermediate_der4390 + ( t839 -
intermediate_der4343 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 ) *
3.6813041167499323 / 2374.9296201389902 ; t435 [ 2ULL ] =
intermediate_der4390 * 3681.3041167499323 ; t435 [ 3ULL ] =
intermediate_der4390 * 3681.3041167499323 ; t435 [ 4ULL ] = 1.0 / ( X [ 50ULL
] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) * intermediate_der4390 *
3681.3041167499323 / 1.5549856083302016 ; t436 [ 0ULL ] = - ( 1.0 / ( X [
46ULL ] == 0.0 ? 1.0E-16 : X [ 46ULL ] ) ) * t696 * 3681.3041167499323 /
1.5549856083302016 ; t436 [ 1ULL ] = ( ( intrm_sf_mf_1113 - intrm_sf_mf_1006
) * t696 + ( intermediate_der7477 - intermediate_der4344 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 ) *
3.6813041167499323 / 2374.9296201389902 ; t436 [ 2ULL ] = t696 *
3681.3041167499323 ; t436 [ 3ULL ] = t696 * 3681.3041167499323 ; t436 [ 4ULL
] = 1.0 / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) * t696 *
3681.3041167499323 / 1.5549856083302016 ; t437 [ 0ULL ] = - ( 1.0 / ( X [
43ULL ] == 0.0 ? 1.0E-16 : X [ 43ULL ] ) ) * intermediate_der3824 *
3681.3041167499323 ; t437 [ 1ULL ] = ( intrm_sf_mf_976 - intrm_sf_mf_869 ) *
intermediate_der3824 * 3.6813041167499323 / 2172.7681408465714 ; t437 [ 2ULL
] = intermediate_der3824 * 3681.3041167499323 ; t437 [ 3ULL ] =
intermediate_der3824 * 3681.3041167499323 ; t1118 = X [ 49ULL ] * X [ 49ULL ]
; t437 [ 4ULL ] = ( 1.0 / ( X [ 49ULL ] == 0.0 ? 1.0E-16 : X [ 49ULL ] ) *
intermediate_der3824 + - 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_43 ) *
3681.3041167499323 ; t438 [ 0ULL ] = - ( 1.0 / ( X [ 46ULL ] == 0.0 ? 1.0E-16
: X [ 46ULL ] ) ) * intermediate_der4387 * 3681.3041167499323 /
1.5549856083302016 ; t438 [ 1ULL ] = ( intrm_sf_mf_1113 - intrm_sf_mf_1006 )
* intermediate_der4387 * 3.6813041167499323 / 2374.9296201389902 ; t438 [
2ULL ] = intermediate_der4387 * 3681.3041167499323 ; t438 [ 3ULL ] =
intermediate_der4387 * 3681.3041167499323 ; t1118 = X [ 50ULL ] * X [ 50ULL ]
; t438 [ 4ULL ] = ( 1.0 / ( X [ 50ULL ] == 0.0 ? 1.0E-16 : X [ 50ULL ] ) *
intermediate_der4387 + - 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_100 ) *
3681.3041167499323 / 1.5549856083302016 ; t1110 = X [ 51ULL ] * X [ 51ULL ] ;
t439 [ 0ULL ] = ( - ( 1.0 / ( X [ 51ULL ] == 0.0 ? 1.0E-16 : X [ 51ULL ] ) )
* intermediate_der4948 + - ( - 1.0 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 ) *
49.087385212340521 ; t439 [ 1ULL ] = ( ( intrm_sf_mf_1251 - intrm_sf_mf_1144
) * intermediate_der4948 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 *
intermediate_der7614 ) * 0.049087385212340524 / 2172.7681408465714 ; t439 [
2ULL ] = intermediate_der4948 * 49.087385212340521 ; t439 [ 3ULL ] =
intermediate_der4948 * 49.087385212340521 ; t439 [ 4ULL ] = 1.0 / ( X [ 54ULL
] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) * intermediate_der4948 *
49.087385212340521 ; t440 [ 0ULL ] = - ( 1.0 / ( X [ 51ULL ] == 0.0 ? 1.0E-16
: X [ 51ULL ] ) ) * intermediate_der4947 * 49.087385212340521 ; t440 [ 1ULL ]
= ( ( intrm_sf_mf_1251 - intrm_sf_mf_1144 ) * intermediate_der4947 + (
intermediate_der7612 - intermediate_der4901 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 ) *
0.049087385212340524 / 2172.7681408465714 ; t440 [ 2ULL ] =
intermediate_der4947 * 49.087385212340521 ; t440 [ 3ULL ] =
intermediate_der4947 * 49.087385212340521 ; t440 [ 4ULL ] = 1.0 / ( X [ 54ULL
] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) * intermediate_der4947 *
49.087385212340521 ; t441 [ 0ULL ] = - ( 1.0 / ( X [ 51ULL ] == 0.0 ? 1.0E-16
: X [ 51ULL ] ) ) * t698 * 49.087385212340521 ; t441 [ 1ULL ] = ( (
intrm_sf_mf_1251 - intrm_sf_mf_1144 ) * t698 + ( intermediate_der7613 -
intermediate_der4902 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 ) *
0.049087385212340524 / 2172.7681408465714 ; t441 [ 2ULL ] = t698 *
49.087385212340521 ; t441 [ 3ULL ] = t698 * 49.087385212340521 ; t441 [ 4ULL
] = 1.0 / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) * t698 *
49.087385212340521 ; t442 [ 0ULL ] = - ( 1.0 / ( X [ 51ULL ] == 0.0 ? 1.0E-16
: X [ 51ULL ] ) ) * intermediate_der4945 * 49.087385212340521 ; t442 [ 1ULL ]
= ( intrm_sf_mf_1251 - intrm_sf_mf_1144 ) * intermediate_der4945 *
0.049087385212340524 / 2172.7681408465714 ; t442 [ 2ULL ] =
intermediate_der4945 * 49.087385212340521 ; t442 [ 3ULL ] =
intermediate_der4945 * 49.087385212340521 ; t1118 = X [ 54ULL ] * X [ 54ULL ]
; t442 [ 4ULL ] = ( 1.0 / ( X [ 54ULL ] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) *
intermediate_der4945 + - 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip41 ) *
49.087385212340521 ; t1118 = X [ 55ULL ] * X [ 55ULL ] ; t443 [ 0ULL ] = (
1.0 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) * intermediate_der7152 +
- 1.0 / ( t1118 == 0.0 ? 1.0E-16 : t1118 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 ) *
29.999999999999996 ; t443 [ 1ULL ] = - ( 1.0 / ( X [ 71ULL ] == 0.0 ? 1.0E-16
: X [ 71ULL ] ) ) * intermediate_der7152 * 29.999999999999996 ; t443 [ 2ULL ]
= ( intrm_sf_mf_1653 - intrm_sf_mf_1634 ) * intermediate_der7152 * 0.03 /
2172.7681408465714 ; t443 [ 3ULL ] = intermediate_der7152 *
29.999999999999996 ; t443 [ 4ULL ] = intermediate_der7152 *
29.999999999999996 ; t444 [ 0ULL ] = ( 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ) *
intermediate_der5464 + - 1.0 / ( t801 == 0.0 ? 1.0E-16 : t801 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 * t681 ) *
0.0040159681273635624 ; t444 [ 1ULL ] = intermediate_der5532 * 100.0 /
16.703067073570942 ; t444 [ 2ULL ] = ( - t699 * intermediate_der5464 + -
intermediate_der5505 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ) *
0.0040159681273635624 ; t444 [ 3ULL ] = intermediate_der5530 * 0.001 /
16.703067073570942 ; t445 [ 0ULL ] = ( 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce6 ) *
t679 + - 1.0 / ( t801 == 0.0 ? 1.0E-16 : t801 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 *
intermediate_der5506 ) * 0.0040159681273635624 ; t445 [ 1ULL ] =
intermediate_der5533 * 100.0 / 16.703067073570942 ; t445 [ 2ULL ] = ( - t699
* t679 + - t788 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Fuel_Ce28 ) *
0.0040159681273635624 ; t445 [ 3ULL ] = t348_idx_0 * 0.001 /
16.703067073570942 ; t446 [ 0ULL ] = ( 1.0 / ( t700 == 0.0 ? 1.0E-16 : t700 )
* t805 + - 1.0 / ( t811 == 0.0 ? 1.0E-16 : t811 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 * t796 ) *
0.00093750000000000007 ; t446 [ 1ULL ] = intermediate_der5617 * 100.0 /
3.8992155527272074 ; t446 [ 2ULL ] = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 * t805 + -
intermediate_der5588 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ) *
0.00093750000000000007 ; t446 [ 3ULL ] = intermediate_der5615 * 0.001 /
3.8992155527272074 ; t447 [ 0ULL ] = ( 1.0 / ( t700 == 0.0 ? 1.0E-16 : t700 )
* t802 + - 1.0 / ( t811 == 0.0 ? 1.0E-16 : t811 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 *
intermediate_der5589 ) * 0.00093750000000000007 ; t447 [ 1ULL ] =
intermediate_der5618 * 100.0 / 3.8992155527272074 ; t447 [ 2ULL ] = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato5 * t802 + -
t794 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato28 ) *
0.00093750000000000007 ; t447 [ 3ULL ] = intermediate_der5616 * 0.001 /
3.8992155527272074 ; t1090 = X [ 63ULL ] * X [ 63ULL ] ; t448 [ 0ULL ] = ( -
( 1.0 / ( X [ 63ULL ] == 0.0 ? 1.0E-16 : X [ 63ULL ] ) ) * t812 + - ( - 1.0 /
( t1090 == 0.0 ? 1.0E-16 : t1090 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 ) * 18000.0 /
12.896402563644669 ; t448 [ 1ULL ] = ( ( intrm_sf_mf_1393 - intrm_sf_mf_1380
) * t812 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 *
intermediate_der8178 ) * 18.0 / 2246.65922904024 ; t448 [ 2ULL ] = 1.0 / ( X
[ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) * t812 * 18000.0 /
12.896402563644669 ; t448 [ 3ULL ] = t812 * 18000.0 ; t448 [ 4ULL ] = t812 *
18000.0 ; t449 [ 0ULL ] = - ( 1.0 / ( X [ 63ULL ] == 0.0 ? 1.0E-16 : X [
63ULL ] ) ) * t807 * 18000.0 / 12.896402563644669 ; t449 [ 1ULL ] = (
intrm_sf_mf_1393 - intrm_sf_mf_1380 ) * t807 * 18.0 / 2246.65922904024 ;
t1090 = X [ 64ULL ] * X [ 64ULL ] ; t449 [ 2ULL ] = ( 1.0 / ( X [ 64ULL ] ==
0.0 ? 1.0E-16 : X [ 64ULL ] ) * t807 + - 1.0 / ( t1090 == 0.0 ? 1.0E-16 :
t1090 ) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 ) *
18000.0 / 12.896402563644669 ; t449 [ 3ULL ] = t807 * 18000.0 ; t449 [ 4ULL ]
= t807 * 18000.0 ; t450 [ 0ULL ] = - ( 1.0 / ( X [ 63ULL ] == 0.0 ? 1.0E-16 :
X [ 63ULL ] ) ) * t810 * 18000.0 / 12.896402563644669 ; t450 [ 1ULL ] = ( (
intrm_sf_mf_1393 - intrm_sf_mf_1380 ) * t810 + ( intermediate_der8176 -
intermediate_der6295 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 ) * 18.0 /
2246.65922904024 ; t450 [ 2ULL ] = 1.0 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [
64ULL ] ) * t810 * 18000.0 / 12.896402563644669 ; t450 [ 3ULL ] = t810 *
18000.0 ; t450 [ 4ULL ] = t810 * 18000.0 ; t451 [ 0ULL ] = - ( 1.0 / ( X [
63ULL ] == 0.0 ? 1.0E-16 : X [ 63ULL ] ) ) * t703 * 18000.0 /
12.896402563644669 ; t451 [ 1ULL ] = ( ( intrm_sf_mf_1393 - intrm_sf_mf_1380
) * t703 + ( intermediate_der8177 - t806 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T18 ) * 18.0 /
2246.65922904024 ; t451 [ 2ULL ] = 1.0 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [
64ULL ] ) * t703 * 18000.0 / 12.896402563644669 ; t451 [ 3ULL ] = t703 *
18000.0 ; t451 [ 4ULL ] = t703 * 18000.0 ; t1090 = X [ 67ULL ] * X [ 67ULL ]
; t452 [ 0ULL ] = ( - ( 1.0 / ( X [ 67ULL ] == 0.0 ? 1.0E-16 : X [ 67ULL ] )
) * intermediate_der6418 + - ( - 1.0 / ( t1090 == 0.0 ? 1.0E-16 : t1090 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 ) *
7.8539816339744828 / 12.896402563644669 ; t452 [ 1ULL ] = ( (
intrm_sf_mf_1506 - intrm_sf_mf_1399 ) * intermediate_der6418 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 *
intermediate_der8219 ) * 0.0078539816339744835 / 2246.65922904024 ; t452 [
2ULL ] = 1.0 / ( X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) *
intermediate_der6418 * 7.8539816339744828 / 12.896402563644669 ; t452 [ 3ULL
] = intermediate_der6418 * 7.8539816339744828 ; t452 [ 4ULL ] =
intermediate_der6418 * 7.8539816339744828 ; t453 [ 0ULL ] = - ( 1.0 / ( X [
67ULL ] == 0.0 ? 1.0E-16 : X [ 67ULL ] ) ) * intermediate_der6415 *
7.8539816339744828 / 12.896402563644669 ; t453 [ 1ULL ] = ( intrm_sf_mf_1506
- intrm_sf_mf_1399 ) * intermediate_der6415 * 0.0078539816339744835 /
2246.65922904024 ; t1090 = X [ 68ULL ] * X [ 68ULL ] ; t453 [ 2ULL ] = ( 1.0
/ ( X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) * intermediate_der6415 + -
1.0 / ( t1090 == 0.0 ? 1.0E-16 : t1090 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 ) *
7.8539816339744828 / 12.896402563644669 ; t453 [ 3ULL ] =
intermediate_der6415 * 7.8539816339744828 ; t453 [ 4ULL ] =
intermediate_der6415 * 7.8539816339744828 ; t454 [ 0ULL ] = - ( 1.0 / ( X [
67ULL ] == 0.0 ? 1.0E-16 : X [ 67ULL ] ) ) * t705 * 7.8539816339744828 /
12.896402563644669 ; t454 [ 1ULL ] = ( ( intrm_sf_mf_1506 - intrm_sf_mf_1399
) * t705 + ( t701 - intermediate_der6372 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 ) *
0.0078539816339744835 / 2246.65922904024 ; t454 [ 2ULL ] = 1.0 / ( X [ 68ULL
] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) * t705 * 7.8539816339744828 /
12.896402563644669 ; t454 [ 3ULL ] = t705 * 7.8539816339744828 ; t454 [ 4ULL
] = t705 * 7.8539816339744828 ; t455 [ 0ULL ] = - ( 1.0 / ( X [ 67ULL ] ==
0.0 ? 1.0E-16 : X [ 67ULL ] ) ) * intermediate_der6417 * 7.8539816339744828 /
12.896402563644669 ; t455 [ 1ULL ] = ( ( intrm_sf_mf_1506 - intrm_sf_mf_1399
) * intermediate_der6417 + ( intermediate_der8217 - intermediate_der6371 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M43 ) *
0.0078539816339744835 / 2246.65922904024 ; t455 [ 2ULL ] = 1.0 / ( X [ 68ULL
] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) * intermediate_der6417 *
7.8539816339744828 / 12.896402563644669 ; t455 [ 3ULL ] =
intermediate_der6417 * 7.8539816339744828 ; t455 [ 4ULL ] =
intermediate_der6417 * 7.8539816339744828 ; t456 [ 0ULL ] = 1.0 / ( X [ 55ULL
] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) * intermediate_der7155 *
29.999999999999996 ; t1110 = X [ 71ULL ] * X [ 71ULL ] ; t456 [ 1ULL ] = ( -
( 1.0 / ( X [ 71ULL ] == 0.0 ? 1.0E-16 : X [ 71ULL ] ) ) *
intermediate_der7155 + - ( - 1.0 / ( t1110 == 0.0 ? 1.0E-16 : t1110 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 ) *
29.999999999999996 ; t456 [ 2ULL ] = ( ( intrm_sf_mf_1653 - intrm_sf_mf_1634
) * intermediate_der7155 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 *
intermediate_der8372 ) * 0.03 / 2172.7681408465714 ; t456 [ 3ULL ] =
intermediate_der7155 * 29.999999999999996 ; t456 [ 4ULL ] =
intermediate_der7155 * 29.999999999999996 ; t457 [ 0ULL ] = 1.0 / ( X [ 55ULL
] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) * t707 * 29.999999999999996 ; t457 [ 1ULL
] = - ( 1.0 / ( X [ 71ULL ] == 0.0 ? 1.0E-16 : X [ 71ULL ] ) ) * t707 *
29.999999999999996 ; t457 [ 2ULL ] = ( ( intrm_sf_mf_1653 - intrm_sf_mf_1634
) * t707 + ( intermediate_der8370 - intermediate_der7150 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 ) * 0.03 /
2172.7681408465714 ; t457 [ 3ULL ] = t707 * 29.999999999999996 ; t457 [ 4ULL
] = t707 * 29.999999999999996 ; t458 [ 0ULL ] = 1.0 / ( X [ 55ULL ] == 0.0 ?
1.0E-16 : X [ 55ULL ] ) * intermediate_der7154 * 29.999999999999996 ; t458 [
1ULL ] = - ( 1.0 / ( X [ 71ULL ] == 0.0 ? 1.0E-16 : X [ 71ULL ] ) ) *
intermediate_der7154 * 29.999999999999996 ; t458 [ 2ULL ] = ( (
intrm_sf_mf_1653 - intrm_sf_mf_1634 ) * intermediate_der7154 + (
intermediate_der8371 - intermediate_der7151 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Oxygen_Source_Compress27 ) * 0.03 /
2172.7681408465714 ; t458 [ 3ULL ] = intermediate_der7154 *
29.999999999999996 ; t458 [ 4ULL ] = intermediate_der7154 *
29.999999999999996 ; t459 [ 0ULL ] = 1.0 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X
[ 38ULL ] ) * intermediate_der7249 * 12.500000000000004 / 12.896402563644669
; t1118 = X [ 74ULL ] * X [ 74ULL ] ; t459 [ 1ULL ] = ( - ( 1.0 / ( X [ 74ULL
] == 0.0 ? 1.0E-16 : X [ 74ULL ] ) ) * intermediate_der7249 + - ( - 1.0 / (
t1118 == 0.0 ? 1.0E-16 : t1118 ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 ) *
12.500000000000004 / 12.896402563644669 ; t459 [ 2ULL ] = ( (
intrm_sf_mf_1684 - intrm_sf_mf_1659 ) * intermediate_der7249 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 *
intermediate_der8385 ) * 0.012500000000000002 / 2246.65922904024 ; t459 [
3ULL ] = intermediate_der7249 * 12.500000000000004 ; t459 [ 4ULL ] =
intermediate_der7249 * 12.500000000000004 ; t460 [ 0ULL ] = 1.0 / ( X [ 38ULL
] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) * intermediate_der7248 *
12.500000000000004 / 12.896402563644669 ; t460 [ 1ULL ] = - ( 1.0 / ( X [
74ULL ] == 0.0 ? 1.0E-16 : X [ 74ULL ] ) ) * intermediate_der7248 *
12.500000000000004 / 12.896402563644669 ; t460 [ 2ULL ] = ( (
intrm_sf_mf_1684 - intrm_sf_mf_1659 ) * intermediate_der7248 + (
intermediate_der8383 - intermediate_der7244 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 ) *
0.012500000000000002 / 2246.65922904024 ; t460 [ 3ULL ] =
intermediate_der7248 * 12.500000000000004 ; t460 [ 4ULL ] =
intermediate_der7248 * 12.500000000000004 ; t461 [ 0ULL ] = 1.0 / ( X [ 38ULL
] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) * t709 * 12.500000000000004 /
12.896402563644669 ; t461 [ 1ULL ] = - ( 1.0 / ( X [ 74ULL ] == 0.0 ? 1.0E-16
: X [ 74ULL ] ) ) * t709 * 12.500000000000004 / 12.896402563644669 ; t461 [
2ULL ] = ( ( intrm_sf_mf_1684 - intrm_sf_mf_1659 ) * t709 + (
intermediate_der8384 - intermediate_der7245 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant25 ) *
0.012500000000000002 / 2246.65922904024 ; t461 [ 3ULL ] = t709 *
12.500000000000004 ; t461 [ 4ULL ] = t709 * 12.500000000000004 ; t462 [ 0ULL
] = X [ 161ULL ] * - 0.001 / ( X [ 7ULL ] == 0.0 ? 1.0E-16 : X [ 7ULL ] ) /
1.1843079200592157 ; t462 [ 1ULL ] = ( 1000.0 - ( X [ 7ULL ] +
126.84999999999997 ) / ( X [ 7ULL ] == 0.0 ? 1.0E-16 : X [ 7ULL ] ) * 1000.0
) * X [ 161ULL ] * 0.001 * 0.001 ; t462 [ 2ULL ] = - ( X [ 161ULL ] * - 0.2 *
intrm_sf_mf_1792 * 0.005 ) / 1.1843079200592157 ; t462 [ 3ULL ] = - ( ( X [
7ULL ] + 126.84999999999997 ) * X [ 161ULL ] * - 0.2 * intrm_sf_mf_1792 *
0.005 ) ; t462 [ 4ULL ] = t824 * 0.001 ; t462 [ 5ULL ] = ( X [ 161ULL ] * -
0.2 * 0.005 / ( intrm_sf_mf_1793 == 0.0 ? 1.0E-16 : intrm_sf_mf_1793 ) *
1.0E-5 + X [ 161ULL ] * 0.001 / ( X [ 15ULL ] == 0.0 ? 1.0E-16 : X [ 15ULL ]
) * 1.0E-5 ) * 100000.0 / 1.1843079200592157 ; t462 [ 6ULL ] = ( ( X [ 7ULL ]
+ 126.84999999999997 ) * X [ 161ULL ] * - 0.2 * 0.005 / ( intrm_sf_mf_1793 ==
0.0 ? 1.0E-16 : intrm_sf_mf_1793 ) * 0.01 + ( ( X [ 7ULL ] +
126.84999999999997 ) / ( t850 == 0.0 ? 1.0E-16 : t850 ) * 1000.0 - 1.0 ) *
0.001 ) * 100.0 ; t462 [ 7ULL ] = - intrm_sf_mf_1792 * X [ 8ULL ] * - 0.2 *
0.005 * 100.0 ; t463 [ 0ULL ] = - ( X [ 158ULL ] * 0.001 ) / ( X [ 7ULL ] ==
0.0 ? 1.0E-16 : X [ 7ULL ] ) / 1.1843079200592157 ; t463 [ 1ULL ] = ( 1000.0
- ( X [ 7ULL ] + 126.84999999999997 ) / ( X [ 7ULL ] == 0.0 ? 1.0E-16 : X [
7ULL ] ) * 1000.0 ) * X [ 158ULL ] * 0.001 * 0.001 ; t463 [ 2ULL ] = - ( t682
* intrm_sf_mf_1792 * 0.005 ) / 1.1843079200592157 ; t463 [ 3ULL ] = - ( ( X [
7ULL ] + 126.84999999999997 ) * t682 * intrm_sf_mf_1792 * 0.005 ) ; t463 [
4ULL ] = ( t682 * 0.005 / ( intrm_sf_mf_1793 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1793 ) * 1.0E-5 + X [ 158ULL ] * 0.001 / ( X [ 15ULL ] == 0.0 ?
1.0E-16 : X [ 15ULL ] ) * 1.0E-5 ) * 100000.0 / 1.1843079200592157 ; t463 [
5ULL ] = ( X [ 7ULL ] + 126.84999999999997 ) * t682 * 0.005 / (
intrm_sf_mf_1793 == 0.0 ? 1.0E-16 : intrm_sf_mf_1793 ) ; t323 [ 0ULL ] = (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_cv_I *
intermediate_der249 +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I * t1130 ) *
7.8539816339744831E-8 ; for ( t519 = 0ULL ; t519 < 4ULL ; t519 ++ ) { t323 [
t519 + 1ULL ] = t407 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 6ULL ; t519 ++ )
{ t323 [ t519 + 5ULL ] = t408 [ t519 ] ; } t323 [ 11ULL ] = (
Electrical_Cooling_System_Pipe_Converter_pipe_model_cv_I * t711 +
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
intermediate_der389 ) * 7.8539816339744831E-8 ; t323 [ 12ULL ] = (
Electrical_Cooling_System_Pipe_Motor_pipe_model_cv_I * t719 +
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I * intermediate_der496 )
* 7.8539816339744831E-8 ; for ( t519 = 0ULL ; t519 < 6ULL ; t519 ++ ) { t323
[ t519 + 13ULL ] = t409 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519
++ ) { t323 [ t519 + 19ULL ] = t410 [ t519 ] ; } for ( t519 = 0ULL ; t519 <
5ULL ; t519 ++ ) { t323 [ t519 + 24ULL ] = t411 [ t519 ] ; } for ( t519 =
0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 29ULL ] = t412 [ t519 ] ; }
for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 34ULL ] = t413 [
t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 39ULL
] = t414 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [
t519 + 44ULL ] = t415 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++
) { t323 [ t519 + 49ULL ] = t416 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL
; t519 ++ ) { t323 [ t519 + 54ULL ] = t417 [ t519 ] ; } for ( t519 = 0ULL ;
t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 59ULL ] = t418 [ t519 ] ; } for (
t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 64ULL ] = t419 [ t519 ]
; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 69ULL ] =
t420 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 +
74ULL ] = t421 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) {
t323 [ t519 + 79ULL ] = t422 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ;
t519 ++ ) { t323 [ t519 + 84ULL ] = t423 [ t519 ] ; } for ( t519 = 0ULL ;
t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 89ULL ] = t424 [ t519 ] ; } for (
t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 94ULL ] = t425 [ t519 ]
; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 99ULL ] =
t426 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 +
104ULL ] = t427 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) {
t323 [ t519 + 109ULL ] = t428 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ;
t519 ++ ) { t323 [ t519 + 114ULL ] = t429 [ t519 ] ; } for ( t519 = 0ULL ;
t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 119ULL ] = t430 [ t519 ] ; } for (
t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 124ULL ] = t431 [ t519
] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 129ULL ] =
t432 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 +
134ULL ] = t433 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) {
t323 [ t519 + 139ULL ] = t434 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ;
t519 ++ ) { t323 [ t519 + 144ULL ] = t435 [ t519 ] ; } for ( t519 = 0ULL ;
t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 149ULL ] = t436 [ t519 ] ; } for (
t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 154ULL ] = t437 [ t519
] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 159ULL ] =
t438 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 +
164ULL ] = t439 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) {
t323 [ t519 + 169ULL ] = t440 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ;
t519 ++ ) { t323 [ t519 + 174ULL ] = t441 [ t519 ] ; } for ( t519 = 0ULL ;
t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 179ULL ] = t442 [ t519 ] ; } for (
t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 184ULL ] = t443 [ t519
] ; } t323 [ 189ULL ] = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant11 *
intermediate_der5458 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 * t1131 ) * (
X [ 57ULL ] * 0.1 + 0.0001 ) * 0.001 / 8385.55841330098 ; t323 [ 190ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant11 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant15 * 0.1 * 0.001
/ 8385.55841330098 ; for ( t519 = 0ULL ; t519 < 4ULL ; t519 ++ ) { t323 [
t519 + 191ULL ] = t444 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 4ULL ; t519 ++
) { t323 [ t519 + 195ULL ] = t445 [ t519 ] ; } for ( t519 = 0ULL ; t519 <
4ULL ; t519 ++ ) { t323 [ t519 + 199ULL ] = t446 [ t519 ] ; } for ( t519 =
0ULL ; t519 < 4ULL ; t519 ++ ) { t323 [ t519 + 203ULL ] = t447 [ t519 ] ; }
for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 207ULL ] = t448 [
t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 212ULL
] = t449 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [
t519 + 217ULL ] = t450 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++
) { t323 [ t519 + 222ULL ] = t451 [ t519 ] ; } for ( t519 = 0ULL ; t519 <
5ULL ; t519 ++ ) { t323 [ t519 + 227ULL ] = t452 [ t519 ] ; } for ( t519 =
0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 232ULL ] = t453 [ t519 ] ; }
for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 237ULL ] = t454 [
t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 242ULL
] = t455 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [
t519 + 247ULL ] = t456 [ t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++
) { t323 [ t519 + 252ULL ] = t457 [ t519 ] ; } for ( t519 = 0ULL ; t519 <
5ULL ; t519 ++ ) { t323 [ t519 + 257ULL ] = t458 [ t519 ] ; } for ( t519 =
0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 262ULL ] = t459 [ t519 ] ; }
for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 267ULL ] = t460 [
t519 ] ; } for ( t519 = 0ULL ; t519 < 5ULL ; t519 ++ ) { t323 [ t519 + 272ULL
] = t461 [ t519 ] ; } t323 [ 277ULL ] = (
Electrical_Cooling_System_Pipe_Converter_pipe_model_cv_I * t712 +
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
intermediate_der366 ) * 7.8539816339744831E-8 ; t323 [ 278ULL ] = (
Electrical_Cooling_System_Pipe_Converter_pipe_model_cv_I * t715 +
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
intermediate_der387 ) * 7.8539816339744831E-8 ; t323 [ 279ULL ] = (
Electrical_Cooling_System_Pipe_Motor_pipe_model_cv_I * t720 +
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I * t678 ) *
7.8539816339744831E-8 ; t323 [ 280ULL ] = (
Electrical_Cooling_System_Pipe_Motor_pipe_model_cv_I * t721 +
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I * intermediate_der518 )
* 7.8539816339744831E-8 ; t323 [ 281ULL ] = (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_cv_I *
intermediate_der250 +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I *
intermediate_der253 ) * 7.8539816339744831E-8 ; t323 [ 282ULL ] = (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_cv_I *
intermediate_der251 +
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I *
intermediate_der252 ) * 7.8539816339744831E-8 ; for ( t519 = 0ULL ; t519 <
8ULL ; t519 ++ ) { t323 [ t519 + 283ULL ] = t462 [ t519 ] ; } for ( t519 =
0ULL ; t519 < 6ULL ; t519 ++ ) { t323 [ t519 + 291ULL ] = t463 [ t519 ] ; }
t323 [ 297ULL ] = t586 * 0.001 ; for ( b = 0 ; b < 298 ; b ++ ) { out . mX [
b ] = t323 [ b ] ; } ( void ) LC ; ( void ) t1133 ; return 0 ; }
