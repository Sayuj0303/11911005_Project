#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_mode.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_mode ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t519 , NeDsMethodOutput * t520 ) { ETTS0
ab_efOut ; ETTS0 b_efOut ; ETTS0 cb_efOut ; ETTS0 d_efOut ; ETTS0 db_efOut ;
ETTS0 e_efOut ; ETTS0 efOut ; ETTS0 fb_efOut ; ETTS0 g_efOut ; ETTS0 h_efOut
; ETTS0 hb_efOut ; ETTS0 j_efOut ; ETTS0 jb_efOut ; ETTS0 k_efOut ; ETTS0
lb_efOut ; ETTS0 m_efOut ; ETTS0 n_efOut ; ETTS0 nb_efOut ; ETTS0 p_efOut ;
ETTS0 pb_efOut ; ETTS0 q_efOut ; ETTS0 qb_efOut ; ETTS0 s_efOut ; ETTS0
sb_efOut ; ETTS0 t1 ; ETTS0 t21 ; ETTS0 t22 ; ETTS0 t24 ; ETTS0 t25 ; ETTS0
t27 ; ETTS0 t28 ; ETTS0 t8 ; ETTS0 t_efOut ; ETTS0 ub_efOut ; ETTS0 v_efOut ;
ETTS0 w_efOut ; ETTS0 wb_efOut ; ETTS0 xb_efOut ; ETTS0 y_efOut ; PmIntVector
out ; real_T X [ 582 ] ; real_T nonscalar1 [ 7 ] ; real_T bb_efOut [ 1 ] ;
real_T c_efOut [ 1 ] ; real_T eb_efOut [ 1 ] ; real_T f_efOut [ 1 ] ; real_T
gb_efOut [ 1 ] ; real_T i_efOut [ 1 ] ; real_T ib_efOut [ 1 ] ; real_T
kb_efOut [ 1 ] ; real_T l_efOut [ 1 ] ; real_T mb_efOut [ 1 ] ; real_T
o_efOut [ 1 ] ; real_T ob_efOut [ 1 ] ; real_T r_efOut [ 1 ] ; real_T
rb_efOut [ 1 ] ; real_T t201 [ 1 ] ; real_T t202 [ 1 ] ; real_T tb_efOut [ 1
] ; real_T u_efOut [ 1 ] ; real_T vb_efOut [ 1 ] ; real_T x_efOut [ 1 ] ;
real_T yb_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_1 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_2 ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_1 ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_2 ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I ; real_T
Electrical_Cooling_System_Tank_Tank_level ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ; real_T
U_idx_11 ; real_T U_idx_13 ; real_T U_idx_3 ; real_T U_idx_6 ; real_T U_idx_7
; real_T U_idx_9 ; real_T intrm_sf_mf_1006 ; real_T intrm_sf_mf_1142 ; real_T
intrm_sf_mf_1399 ; real_T intrm_sf_mf_1434 ; real_T intrm_sf_mf_1543 ; real_T
intrm_sf_mf_1574 ; real_T intrm_sf_mf_1592 ; real_T intrm_sf_mf_1634 ; real_T
intrm_sf_mf_1659 ; real_T intrm_sf_mf_1670 ; real_T intrm_sf_mf_1672 ; real_T
intrm_sf_mf_1696 ; real_T intrm_sf_mf_1739 ; real_T intrm_sf_mf_1740 ; real_T
intrm_sf_mf_1741 ; real_T intrm_sf_mf_1742 ; real_T intrm_sf_mf_1743 ; real_T
intrm_sf_mf_1744 ; real_T intrm_sf_mf_1772 ; real_T intrm_sf_mf_1773 ; real_T
intrm_sf_mf_1774 ; real_T intrm_sf_mf_237 ; real_T intrm_sf_mf_239 ; real_T
intrm_sf_mf_290 ; real_T intrm_sf_mf_335 ; real_T intrm_sf_mf_543 ; real_T
intrm_sf_mf_694 ; real_T intrm_sf_mf_838 ; real_T intrm_sf_mf_904 ; real_T
intrm_sf_mf_934 ; real_T intrm_sf_mf_95 ; real_T t222 ; real_T t225 ; real_T
t228 ; real_T t237 ; real_T t240 ; real_T t252 ; real_T t255 ; real_T t264 ;
real_T t274 ; real_T t275 ; real_T t276 ; real_T t277 ; real_T t278 ; real_T
t280 ; real_T t283 ; real_T t286 ; real_T t289 ; real_T t294 ; real_T t295 ;
real_T t297 ; real_T t298 ; real_T t299 ; real_T t301 ; real_T t303 ; real_T
t309 ; real_T t311 ; real_T t314 ; real_T t317 ; real_T t318 ; real_T t321 ;
real_T t330 ; real_T t331 ; real_T t332 ; real_T t348 ; real_T t363 ; real_T
t401 ; real_T t409 ; real_T t437 ; size_t t32 [ 1 ] ; size_t t33 [ 1 ] ;
size_t t35 [ 1 ] ; size_t t205 ; size_t t206 ; int32_T t181 [ 361 ] ; int32_T
b ; U_idx_3 = t519 -> mU . mX [ 3 ] ; U_idx_6 = t519 -> mU . mX [ 6 ] ;
U_idx_7 = t519 -> mU . mX [ 7 ] ; U_idx_9 = t519 -> mU . mX [ 9 ] ; U_idx_11
= t519 -> mU . mX [ 11 ] ; U_idx_13 = t519 -> mU . mX [ 13 ] ; for ( b = 0 ;
b < 582 ; b ++ ) { X [ b ] = t519 -> mX . mX [ b ] ; } out = t520 -> mMODE ;
nonscalar1 [ 0 ] = 190800.0 ; nonscalar1 [ 1 ] = 190800.0 ; nonscalar1 [ 2 ]
= 190800.0 ; nonscalar1 [ 3 ] = 190800.0 ; nonscalar1 [ 4 ] = 190800.0 ;
nonscalar1 [ 5 ] = 190800.0 ; nonscalar1 [ 6 ] = 190800.0 ; t437 = ( X [
113ULL ] + X [ 120ULL ] ) / 2.0 ; t201 [ 0ULL ] = X [ 6ULL ] ; t32 [ 0 ] =
20ULL ; t33 [ 0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut . mField0 [
0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] ,
& t33 [ 0ULL ] ) ; t1 = efOut ; t201 [ 0ULL ] = t437 ; t35 [ 0 ] = 19ULL ;
tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = c_efOut [ 0 ] ;
t274 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 123ULL ] ;
tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= d_efOut ; t201 [ 0ULL ] = X [ 113ULL ] ; tlu2_linear_linear_prelookup ( &
e_efOut . mField0 [ 0ULL ] , & e_efOut . mField1 [ 0ULL ] , & e_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t21 = e_efOut ;
tlu2_2d_linear_linear_value ( & f_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ] ,
& t25 . mField2 [ 0ULL ] , & t21 . mField0 [ 0ULL ] , & t21 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = f_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_1 = t202 [ 0ULL
] ; t201 [ 0ULL ] = X [ 125ULL ] ; tlu2_linear_linear_prelookup ( & g_efOut .
mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [
0ULL ] , & t33 [ 0ULL ] ) ; t25 = g_efOut ; t201 [ 0ULL ] = X [ 120ULL ] ;
tlu2_linear_linear_prelookup ( & h_efOut . mField0 [ 0ULL ] , & h_efOut .
mField1 [ 0ULL ] , & h_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t28
= h_efOut ; tlu2_2d_linear_linear_value ( & i_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t28 . mField0 [ 0ULL ] , &
t28 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t32 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = i_efOut [ 0 ]
; Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_2 = t202 [
0ULL ] ; Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I = ( X [
95ULL ] + X [ 102ULL ] ) / 2.0 ; t201 [ 0ULL ] = X [ 9ULL ] ;
tlu2_linear_linear_prelookup ( & j_efOut . mField0 [ 0ULL ] , & j_efOut .
mField1 [ 0ULL ] , & j_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1
= j_efOut ; t201 [ 0ULL ] =
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I ;
tlu2_linear_linear_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= k_efOut ; tlu2_2d_linear_linear_value ( & l_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = l_efOut [ 0 ] ;
t275 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 128ULL ] ;
tlu2_linear_linear_prelookup ( & m_efOut . mField0 [ 0ULL ] , & m_efOut .
mField1 [ 0ULL ] , & m_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= m_efOut ; t201 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup ( &
n_efOut . mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t24 = n_efOut ;
tlu2_2d_linear_linear_value ( & o_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ] ,
& t25 . mField2 [ 0ULL ] , & t24 . mField0 [ 0ULL ] , & t24 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = o_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_1 = t202 [ 0ULL
] ; t201 [ 0ULL ] = X [ 130ULL ] ; tlu2_linear_linear_prelookup ( & p_efOut .
mField0 [ 0ULL ] , & p_efOut . mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [
0ULL ] , & t33 [ 0ULL ] ) ; t22 = p_efOut ; t201 [ 0ULL ] = X [ 102ULL ] ;
tlu2_linear_linear_prelookup ( & q_efOut . mField0 [ 0ULL ] , & q_efOut .
mField1 [ 0ULL ] , & q_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t27
= q_efOut ; tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t22 .
mField0 [ 0ULL ] , & t22 . mField2 [ 0ULL ] , & t27 . mField0 [ 0ULL ] , &
t27 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t32 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = r_efOut [ 0 ]
; Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_2 = t202 [
0ULL ] ; Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I = ( X [ 104ULL ]
+ X [ 111ULL ] ) / 2.0 ; t201 [ 0ULL ] = X [ 11ULL ] ;
tlu2_linear_linear_prelookup ( & s_efOut . mField0 [ 0ULL ] , & s_efOut .
mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1
= s_efOut ; t201 [ 0ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I ;
tlu2_linear_linear_prelookup ( & t_efOut . mField0 [ 0ULL ] , & t_efOut .
mField1 [ 0ULL ] , & t_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= t_efOut ; tlu2_2d_linear_linear_value ( & u_efOut [ 0ULL ] , & t1 . mField0
[ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = u_efOut [ 0 ] ;
t276 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 133ULL ] ;
tlu2_linear_linear_prelookup ( & v_efOut . mField0 [ 0ULL ] , & v_efOut .
mField1 [ 0ULL ] , & v_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t22
= v_efOut ; t201 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup ( &
w_efOut . mField0 [ 0ULL ] , & w_efOut . mField1 [ 0ULL ] , & w_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t8 = w_efOut ;
tlu2_2d_linear_linear_value ( & x_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ] ,
& t22 . mField2 [ 0ULL ] , & t8 . mField0 [ 0ULL ] , & t8 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = x_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A = t202 [ 0ULL
] ; t201 [ 0ULL ] = X [ 135ULL ] ; tlu2_linear_linear_prelookup ( & y_efOut .
mField0 [ 0ULL ] , & y_efOut . mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [
0ULL ] , & t33 [ 0ULL ] ) ; t25 = y_efOut ; t201 [ 0ULL ] = X [ 111ULL ] ;
tlu2_linear_linear_prelookup ( & ab_efOut . mField0 [ 0ULL ] , & ab_efOut .
mField1 [ 0ULL ] , & ab_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t201 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t22
= ab_efOut ; tlu2_2d_linear_linear_value ( & bb_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t22 . mField0 [ 0ULL ] , &
t22 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t32 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = bb_efOut [ 0
] ; Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B = t202 [
0ULL ] ; Electrical_Cooling_System_Tank_Tank_level = X [ 158ULL ] * - 0.2 +
0.2 ; if ( X [ 191ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
191ULL ] >= 1.0 ? 1.0 : X [ 191ULL ] ; } if ( X [ 192ULL ] <= 0.0 ) { t409 =
0.0 ; } else { t409 = X [ 192ULL ] >= 1.0 ? 1.0 : X [ 192ULL ] ; } t401 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
t409 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
t409 * 4124.48151675695 ; if ( X [ 23ULL ] <= 0.0 ) { t409 = 0.0 ; } else {
t409 = X [ 23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 24ULL
] >= 1.0 ? 1.0 : X [ 24ULL ] ; } intrm_sf_mf_95 = ( ( ( 1.0 - t409 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) *
296.802103844292 + t409 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
4124.48151675695 ; if ( X [ 199ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 = X [ 199ULL
] >= 623.15 ? 623.15 : X [ 199ULL ] ; } t348 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 ;
intrm_sf_mf_237 = ( ( ( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 * -
0.22145652610641059 ) + t348 * 0.0003721298010901061 ) * ( ( 1.0 - t409 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
1.2002114337050787 ) + t348 * - 0.00038614513167845434 ) * t409 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
6.9647057412840034 ) + t348 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t277 =
intrm_sf_mf_237 - intrm_sf_mf_95 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 =
intrm_sf_mf_237 / ( t277 == 0.0 ? 1.0E-16 : t277 ) ; if ( X [ 203ULL ] <=
216.59999999999997 ) { intrm_sf_mf_237 = 216.59999999999997 ; } else {
intrm_sf_mf_237 = X [ 203ULL ] >= 623.15 ? 623.15 : X [ 203ULL ] ; } t277 =
intrm_sf_mf_237 * intrm_sf_mf_237 ; t348 = ( ( ( 1074.1165326382554 +
intrm_sf_mf_237 * - 0.22145652610641059 ) + t277 * 0.0003721298010901061 ) *
( ( 1.0 - t409 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) + ( (
1479.6504774710402 + intrm_sf_mf_237 * 1.2002114337050787 ) + t277 * -
0.00038614513167845434 ) * t409 ) + ( ( 12825.281119789837 + intrm_sf_mf_237
* 6.9647057412840034 ) + t277 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t278 = t348
- intrm_sf_mf_95 ; t409 = t348 / ( t278 == 0.0 ? 1.0E-16 : t278 ) ; if ( X [
178ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 178ULL
] >= 1.0 ? 1.0 : X [ 178ULL ] ; } if ( X [ 177ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 177ULL ] >= 1.0 ? 1.0
: X [ 177ULL ] ; } t348 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) -
intrm_sf_mf_237 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 461.523 ) +
intrm_sf_mf_237 * 4124.48151675695 ; if ( X [ 197ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 197ULL
] >= 1.0 ? 1.0 : X [ 197ULL ] ; } if ( X [ 196ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 196ULL ] >= 1.0 ? 1.0
: X [ 196ULL ] ; } t277 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) -
intrm_sf_mf_237 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 461.523 ) +
intrm_sf_mf_237 * 4124.48151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = U_idx_3 *
0.031415926535897927 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 <=
7.8539816339744857E-13 ) { intrm_sf_mf_237 = 7.8539816339744857E-13 ; } else
if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001
>= 3.1415926535897929E-6 ) { intrm_sf_mf_237 = 3.1415926535897929E-6 ; } else
{ intrm_sf_mf_237 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 0.0001 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
intrm_sf_mf_237 / 7.8539816339744827E-5 ; if ( X [ 221ULL ] <= 0.0 ) {
intrm_sf_mf_237 = 0.0 ; } else { intrm_sf_mf_237 = X [ 221ULL ] >= 1.0 ? 1.0
: X [ 221ULL ] ; } if ( X [ 222ULL ] <= 0.0 ) { t278 = 0.0 ; } else { t278 =
X [ 222ULL ] >= 1.0 ? 1.0 : X [ 222ULL ] ; } intrm_sf_mf_239 = ( ( ( 1.0 -
intrm_sf_mf_237 ) - t278 ) * 296.802103844292 + intrm_sf_mf_237 * 461.523 ) +
t278 * 4124.48151675695 ; t280 = X [ 219ULL ] * intrm_sf_mf_239 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 220ULL ]
/ ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [
219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t283 = X [ 220ULL ] / 1.01325
* ( X [ 224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ;
intrm_sf_mf_543 = ( X [ 195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ;
t286 = ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3
) * ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 )
; intrm_sf_mf_290 = intrm_sf_mf_543 * t286 ; intrm_sf_mf_335 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t283 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( X [ 195ULL
] - 1.01325 ) * ( intrm_sf_mf_335 >= t286 ? intrm_sf_mf_335 : t286 ) ;
intrm_sf_mf_335 = ( X [ 195ULL ] - 1.01325 ) / ( intrm_sf_mf_543 == 0.0 ?
1.0E-16 : intrm_sf_mf_543 ) ; t289 = intrm_sf_mf_335 * intrm_sf_mf_335 * 3.0
- intrm_sf_mf_335 * intrm_sf_mf_335 * intrm_sf_mf_335 * 2.0 ; if ( X [ 195ULL
] - 1.01325 <= 0.0 ) { intrm_sf_mf_335 = intrm_sf_mf_290 ; } else if ( X [
195ULL ] - 1.01325 >= intrm_sf_mf_543 ) { intrm_sf_mf_335 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; } else {
intrm_sf_mf_335 = ( 1.0 - t289 ) * intrm_sf_mf_290 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 * t289 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t283 )
- ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.01325 -
X [ 195ULL ] ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >= t286 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 : t286 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = ( 1.01325 -
X [ 195ULL ] ) / ( intrm_sf_mf_543 == 0.0 ? 1.0E-16 : intrm_sf_mf_543 ) ;
t283 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 2.0 ; if (
1.01325 - X [ 195ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
intrm_sf_mf_290 ; } else if ( 1.01325 - X [ 195ULL ] >= intrm_sf_mf_543 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = ( 1.0 - t283
) * intrm_sf_mf_290 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t283 ; } if
( X [ 195ULL ] > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
intrm_sf_mf_335 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 195ULL ]
< 1.01325 ? Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 :
intrm_sf_mf_290 ; } if ( X [ 219ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 219ULL ]
>= 623.15 ? 623.15 : X [ 219ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; t283 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_237 ) - t278 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.00038614513167845434 ) * intrm_sf_mf_237 ) + ( ( 12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.0070524868246844051 ) * t278 ; t222 = t283 - intrm_sf_mf_239 ;
intrm_sf_mf_237 = t283 / ( t222 == 0.0 ? 1.0E-16 : t222 ) ; if ( X [ 27ULL ]
<= 0.0 ) { t278 = 0.0 ; } else { t278 = X [ 27ULL ] >= 1.0 ? 1.0 : X [ 27ULL
] ; } if ( X [ 26ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 26ULL
] >= 1.0 ? 1.0 : X [ 26ULL ] ; } t283 = ( ( ( 1.0 - t278 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) *
296.802103844292 + t278 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
4124.48151675695 ; if ( X [ 245ULL ] <= 216.59999999999997 ) { t286 =
216.59999999999997 ; } else { t286 = X [ 245ULL ] >= 623.15 ? 623.15 : X [
245ULL ] ; } t222 = t286 * t286 ; intrm_sf_mf_543 = ( ( ( 1074.1165326382554
+ t286 * - 0.22145652610641059 ) + t222 * 0.0003721298010901061 ) * ( ( 1.0 -
t278 ) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + (
( 1479.6504774710402 + t286 * 1.2002114337050787 ) + t222 * -
0.00038614513167845434 ) * t278 ) + ( ( 12825.281119789837 + t286 *
6.9647057412840034 ) + t222 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; t225 =
intrm_sf_mf_543 - t283 ; t286 = intrm_sf_mf_543 / ( t225 == 0.0 ? 1.0E-16 :
t225 ) ; if ( X [ 248ULL ] <= 216.59999999999997 ) { intrm_sf_mf_543 =
216.59999999999997 ; } else { intrm_sf_mf_543 = X [ 248ULL ] >= 623.15 ?
623.15 : X [ 248ULL ] ; } t225 = intrm_sf_mf_543 * intrm_sf_mf_543 ;
intrm_sf_mf_290 = ( ( ( 1074.1165326382554 + intrm_sf_mf_543 * -
0.22145652610641059 ) + t225 * 0.0003721298010901061 ) * ( ( 1.0 - t278 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
1479.6504774710402 + intrm_sf_mf_543 * 1.2002114337050787 ) + t225 * -
0.00038614513167845434 ) * t278 ) + ( ( 12825.281119789837 + intrm_sf_mf_543
* 6.9647057412840034 ) + t225 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ; t228 =
intrm_sf_mf_290 - t283 ; t278 = intrm_sf_mf_290 / ( t228 == 0.0 ? 1.0E-16 :
t228 ) ; if ( X [ 243ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 243ULL
] >= 1.0 ? 1.0 : X [ 243ULL ] ; } if ( X [ 242ULL ] <= 0.0 ) {
intrm_sf_mf_543 = 0.0 ; } else { intrm_sf_mf_543 = X [ 242ULL ] >= 1.0 ? 1.0
: X [ 242ULL ] ; } intrm_sf_mf_290 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 229ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 229ULL
] >= 1.0 ? 1.0 : X [ 229ULL ] ; } if ( X [ 228ULL ] <= 0.0 ) {
intrm_sf_mf_543 = 0.0 ; } else { intrm_sf_mf_543 = X [ 228ULL ] >= 1.0 ? 1.0
: X [ 228ULL ] ; } intrm_sf_mf_335 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 30ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = X [ 30ULL
] >= 1.0 ? 1.0 : X [ 30ULL ] ; } if ( X [ 29ULL ] <= 0.0 ) { intrm_sf_mf_543
= 0.0 ; } else { intrm_sf_mf_543 = X [ 29ULL ] >= 1.0 ? 1.0 : X [ 29ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 * 461.523 ) +
intrm_sf_mf_543 * 4124.48151675695 ; if ( X [ 263ULL ] <= 216.59999999999997
) { t289 = 216.59999999999997 ; } else { t289 = X [ 263ULL ] >= 623.15 ?
623.15 : X [ 263ULL ] ; } t228 = t289 * t289 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = ( ( (
1074.1165326382554 + t289 * - 0.22145652610641059 ) + t228 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) + ( ( 1479.6504774710402 + t289 * 1.2002114337050787 ) +
t228 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
12825.281119789837 + t289 * 6.9647057412840034 ) + t228 * -
0.0070524868246844051 ) * intrm_sf_mf_543 ; t294 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ; t289 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( t294 ==
0.0 ? 1.0E-16 : t294 ) ; if ( X [ 265ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [ 265ULL
] >= 623.15 ? 623.15 : X [ 265ULL ] ; } t294 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t222 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.22145652610641059 ) + t294 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) -
intrm_sf_mf_543 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
1.2002114337050787 ) + t294 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
6.9647057412840034 ) + t294 * - 0.0070524868246844051 ) * intrm_sf_mf_543 ;
t295 = t222 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 = t222 / (
t295 == 0.0 ? 1.0E-16 : t295 ) ; if ( X [ 36ULL ] <= 0.0 ) { intrm_sf_mf_543
= 0.0 ; } else { intrm_sf_mf_543 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; }
if ( X [ 35ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t222 = ( ( ( 1.0 - intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + intrm_sf_mf_543 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
4124.48151675695 ; if ( X [ 289ULL ] <= 216.59999999999997 ) { t225 =
216.59999999999997 ; } else { t225 = X [ 289ULL ] >= 623.15 ? 623.15 : X [
289ULL ] ; } t295 = t225 * t225 ; t228 = ( ( ( 1074.1165326382554 + t225 * -
0.22145652610641059 ) + t295 * 0.0003721298010901061 ) * ( ( 1.0 -
intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t225 * 1.2002114337050787 ) + t295 * -
0.00038614513167845434 ) * intrm_sf_mf_543 ) + ( ( 12825.281119789837 + t225
* 6.9647057412840034 ) + t295 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t237 = t228
- t222 ; t225 = t228 / ( t237 == 0.0 ? 1.0E-16 : t237 ) ; if ( X [ 291ULL ]
<= 216.59999999999997 ) { t228 = 216.59999999999997 ; } else { t228 = X [
291ULL ] >= 623.15 ? 623.15 : X [ 291ULL ] ; } t237 = t228 * t228 ; t294 = (
( ( 1074.1165326382554 + t228 * - 0.22145652610641059 ) + t237 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_543 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t228 * 1.2002114337050787 ) + t237 * -
0.00038614513167845434 ) * intrm_sf_mf_543 ) + ( ( 12825.281119789837 + t228
* 6.9647057412840034 ) + t237 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t297 = t294
- t222 ; intrm_sf_mf_543 = t294 / ( t297 == 0.0 ? 1.0E-16 : t297 ) ; if ( X [
280ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
280ULL ] >= 1.0 ? 1.0 : X [ 280ULL ] ; } if ( X [ 279ULL ] <= 0.0 ) { t228 =
0.0 ; } else { t228 = X [ 279ULL ] >= 1.0 ? 1.0 : X [ 279ULL ] ; } t294 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
t228 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
t228 * 4124.48151675695 ; if ( X [ 318ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
318ULL ] >= 1.0 ? 1.0 : X [ 318ULL ] ; } if ( X [ 319ULL ] <= 0.0 ) { t228 =
0.0 ; } else { t228 = X [ 319ULL ] >= 1.0 ? 1.0 : X [ 319ULL ] ; } t295 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
t228 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
t228 * 259.836612622973 ; t228 = ( X [ 322ULL ] * 0.07812500122070315 +
U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X [ 41ULL ] <= 0.0 ) { t237
= 0.0 ; } else { t237 = X [ 41ULL ] >= 1.0 ? 1.0 : X [ 41ULL ] ; } if ( X [
42ULL ] <= 0.0 ) { t297 = 0.0 ; } else { t297 = X [ 42ULL ] >= 1.0 ? 1.0 : X
[ 42ULL ] ; } intrm_sf_mf_694 = ( ( ( 1.0 - t237 ) - t297 ) *
296.802103844292 + t237 * 461.523 ) + t297 * 259.836612622973 ; if ( X [
326ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 = X [ 326ULL
] >= 623.15 ? 623.15 : X [ 326ULL ] ; } t240 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 * -
0.22145652610641059 ) + t240 * 0.0003721298010901061 ) * ( ( 1.0 - t237 ) -
t297 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
1.2002114337050787 ) + t240 * - 0.00038614513167845434 ) * t237 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 * -
0.044484923911441127 ) + t240 * 0.00036936011832051582 ) * t297 ; t298 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 -
intrm_sf_mf_694 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 / ( t298 ==
0.0 ? 1.0E-16 : t298 ) ; if ( X [ 330ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 330ULL ]
>= 623.15 ? 623.15 : X [ 330ULL ] ; } t298 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; t240 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * -
0.22145652610641059 ) + t298 * 0.0003721298010901061 ) * ( ( 1.0 - t237 ) -
t297 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
1.2002114337050787 ) + t298 * - 0.00038614513167845434 ) * t237 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * -
0.044484923911441127 ) + t298 * 0.00036936011832051582 ) * t297 ; t299 = t240
- intrm_sf_mf_694 ; t237 = t240 / ( t299 == 0.0 ? 1.0E-16 : t299 ) ; if ( X [
305ULL ] <= 0.0 ) { t297 = 0.0 ; } else { t297 = X [ 305ULL ] >= 1.0 ? 1.0 :
X [ 305ULL ] ; } if ( X [ 304ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 304ULL
] >= 1.0 ? 1.0 : X [ 304ULL ] ; } t240 = ( ( ( 1.0 - t297 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) *
296.802103844292 + t297 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
259.836612622973 ; if ( X [ 324ULL ] <= 0.0 ) { t297 = 0.0 ; } else { t297 =
X [ 324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X [ 323ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = X [ 323ULL
] >= 1.0 ? 1.0 : X [ 323ULL ] ; } t298 = ( ( ( 1.0 - t297 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) *
296.802103844292 + t297 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
259.836612622973 ; if ( X [ 322ULL ] * 0.0019634954084936209 <=
1.9634954084936209E-11 ) { t297 = 1.9634954084936209E-11 ; } else if ( X [
322ULL ] * 0.0019634954084936209 >= 0.0012566370614359179 ) { t297 =
0.0012566370614359179 ; } else { t297 = X [ 322ULL ] * 0.0019634954084936209
; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = t297 /
0.0019634954084936209 ; if ( X [ 345ULL ] <= 0.0 ) { t297 = 0.0 ; } else {
t297 = X [ 345ULL ] >= 1.0 ? 1.0 : X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0
) { t299 = 0.0 ; } else { t299 = X [ 346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ; }
intrm_sf_mf_838 = ( ( ( 1.0 - t297 ) - t299 ) * 296.802103844292 + t297 *
461.523 ) + t299 * 259.836612622973 ; t301 = X [ 343ULL ] * intrm_sf_mf_838 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 344ULL ]
/ ( t228 == 0.0 ? 1.0E-16 : t228 ) * ( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ; t303 = X [ 344ULL ] / 1.01325 * ( X [ 348ULL ] /
( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; intrm_sf_mf_1142 = (
t228 + 1.01325 ) / 2.0 * 0.0010000000000000009 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) ;
intrm_sf_mf_904 = intrm_sf_mf_1142 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ;
intrm_sf_mf_934 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t303 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * 2.0 ;
intrm_sf_mf_1006 = ( t228 - 1.01325 ) * ( intrm_sf_mf_934 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ?
intrm_sf_mf_934 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ) ;
intrm_sf_mf_934 = ( t228 - 1.01325 ) / ( intrm_sf_mf_1142 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1142 ) ; t309 = intrm_sf_mf_934 * intrm_sf_mf_934 * 3.0 -
intrm_sf_mf_934 * intrm_sf_mf_934 * intrm_sf_mf_934 * 2.0 ; if ( t228 -
1.01325 <= 0.0 ) { intrm_sf_mf_934 = intrm_sf_mf_904 ; } else if ( t228 -
1.01325 >= intrm_sf_mf_1142 ) { intrm_sf_mf_934 = intrm_sf_mf_1006 ; } else {
intrm_sf_mf_934 = ( 1.0 - t309 ) * intrm_sf_mf_904 + intrm_sf_mf_1006 * t309
; } intrm_sf_mf_1006 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t303 )
- ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = ( 1.01325 -
t228 ) * ( intrm_sf_mf_1006 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ?
intrm_sf_mf_1006 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = ( 1.01325 -
t228 ) / ( intrm_sf_mf_1142 == 0.0 ? 1.0E-16 : intrm_sf_mf_1142 ) ; t303 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 2.0 ; if (
1.01325 - t228 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
intrm_sf_mf_904 ; } else if ( 1.01325 - t228 >= intrm_sf_mf_1142 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = ( 1.0 - t303
) * intrm_sf_mf_904 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 * t303 ; } if
( t228 > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 =
intrm_sf_mf_934 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 = t228 <
1.01325 ? Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 :
intrm_sf_mf_904 ; } if ( X [ 343ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 343ULL ]
>= 623.15 ? 623.15 : X [ 343ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t303 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.0003721298010901061 ) * ( ( 1.0 - t297 ) - t299 ) + ( ( 1479.6504774710402
+ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.00038614513167845434 ) * t297 ) + ( ( 900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * -
0.044484923911441127 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
0.00036936011832051582 ) * t299 ; t311 = t303 - intrm_sf_mf_838 ; t297 = t303
/ ( t311 == 0.0 ? 1.0E-16 : t311 ) ; if ( X [ 45ULL ] <= 0.0 ) { t299 = 0.0 ;
} else { t299 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; } if ( X [ 44ULL ]
<= 0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 =
0.0 ; } else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85
= X [ 44ULL ] >= 1.0 ? 1.0 : X [ 44ULL ] ; } t303 = ( ( ( 1.0 - t299 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) *
296.802103844292 + t299 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
259.836612622973 ; if ( X [ 369ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 = X [ 369ULL ]
>= 623.15 ? 623.15 : X [ 369ULL ] ; } t311 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 ;
intrm_sf_mf_1142 = ( ( ( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 * -
0.22145652610641059 ) + t311 * 0.0003721298010901061 ) * ( ( 1.0 - t299 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 *
1.2002114337050787 ) + t311 * - 0.00038614513167845434 ) * t299 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 * -
0.044484923911441127 ) + t311 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t252 =
intrm_sf_mf_1142 - t303 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 =
intrm_sf_mf_1142 / ( t252 == 0.0 ? 1.0E-16 : t252 ) ; if ( X [ 372ULL ] <=
216.59999999999997 ) { intrm_sf_mf_1142 = 216.59999999999997 ; } else {
intrm_sf_mf_1142 = X [ 372ULL ] >= 623.15 ? 623.15 : X [ 372ULL ] ; } t252 =
intrm_sf_mf_1142 * intrm_sf_mf_1142 ; intrm_sf_mf_904 = ( ( (
1074.1165326382554 + intrm_sf_mf_1142 * - 0.22145652610641059 ) + t252 *
0.0003721298010901061 ) * ( ( 1.0 - t299 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
1479.6504774710402 + intrm_sf_mf_1142 * 1.2002114337050787 ) + t252 * -
0.00038614513167845434 ) * t299 ) + ( ( 900.639412248396 + intrm_sf_mf_1142 *
- 0.044484923911441127 ) + t252 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ; t255 =
intrm_sf_mf_904 - t303 ; t299 = intrm_sf_mf_904 / ( t255 == 0.0 ? 1.0E-16 :
t255 ) ; if ( X [ 367ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 367ULL
] >= 1.0 ? 1.0 : X [ 367ULL ] ; } if ( X [ 366ULL ] <= 0.0 ) {
intrm_sf_mf_1142 = 0.0 ; } else { intrm_sf_mf_1142 = X [ 366ULL ] >= 1.0 ?
1.0 : X [ 366ULL ] ; } intrm_sf_mf_904 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
intrm_sf_mf_1142 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
intrm_sf_mf_1142 * 259.836612622973 ; if ( X [ 353ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 353ULL
] >= 1.0 ? 1.0 : X [ 353ULL ] ; } if ( X [ 352ULL ] <= 0.0 ) {
intrm_sf_mf_1142 = 0.0 ; } else { intrm_sf_mf_1142 = X [ 352ULL ] >= 1.0 ?
1.0 : X [ 352ULL ] ; } intrm_sf_mf_934 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
intrm_sf_mf_1142 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
intrm_sf_mf_1142 * 259.836612622973 ; if ( X [ 48ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = X [ 48ULL
] >= 1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { intrm_sf_mf_1142
= 0.0 ; } else { intrm_sf_mf_1142 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ;
} intrm_sf_mf_1006 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
intrm_sf_mf_1142 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 * 461.523 ) +
intrm_sf_mf_1142 * 259.836612622973 ; if ( X [ 387ULL ] <= 216.59999999999997
) { t309 = 216.59999999999997 ; } else { t309 = X [ 387ULL ] >= 623.15 ?
623.15 : X [ 387ULL ] ; } t255 = t309 * t309 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = ( ( (
1074.1165326382554 + t309 * - 0.22145652610641059 ) + t255 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
intrm_sf_mf_1142 ) + ( ( 1479.6504774710402 + t309 * 1.2002114337050787 ) +
t255 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
900.639412248396 + t309 * - 0.044484923911441127 ) + t255 *
0.00036936011832051582 ) * intrm_sf_mf_1142 ; t314 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 -
intrm_sf_mf_1006 ; t309 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 / ( t314 ==
0.0 ? 1.0E-16 : t314 ) ; if ( X [ 389ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [ 389ULL
] >= 623.15 ? 623.15 : X [ 389ULL ] ; } t314 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t311 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.22145652610641059 ) + t314 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) -
intrm_sf_mf_1142 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
1.2002114337050787 ) + t314 * - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * -
0.044484923911441127 ) + t314 * 0.00036936011832051582 ) * intrm_sf_mf_1142 ;
t363 = t311 - intrm_sf_mf_1006 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 = t311 / (
t363 == 0.0 ? 1.0E-16 : t363 ) ; if ( X [ 53ULL ] <= 0.0 ) { intrm_sf_mf_1142
= 0.0 ; } else { intrm_sf_mf_1142 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ;
} if ( X [ 52ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t311 = ( ( ( 1.0 - intrm_sf_mf_1142 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + intrm_sf_mf_1142 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
259.836612622973 ; if ( X [ 414ULL ] <= 216.59999999999997 ) { t252 =
216.59999999999997 ; } else { t252 = X [ 414ULL ] >= 623.15 ? 623.15 : X [
414ULL ] ; } t363 = t252 * t252 ; t255 = ( ( ( 1074.1165326382554 + t252 * -
0.22145652610641059 ) + t363 * 0.0003721298010901061 ) * ( ( 1.0 -
intrm_sf_mf_1142 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t252 * 1.2002114337050787 ) + t363 * -
0.00038614513167845434 ) * intrm_sf_mf_1142 ) + ( ( 900.639412248396 + t252 *
- 0.044484923911441127 ) + t363 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t264 = t255
- t311 ; t252 = t255 / ( t264 == 0.0 ? 1.0E-16 : t264 ) ; if ( X [ 416ULL ]
<= 216.59999999999997 ) { t255 = 216.59999999999997 ; } else { t255 = X [
416ULL ] >= 623.15 ? 623.15 : X [ 416ULL ] ; } t264 = t255 * t255 ; t314 = (
( ( 1074.1165326382554 + t255 * - 0.22145652610641059 ) + t264 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_1142 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + t255 * 1.2002114337050787 ) + t264 * -
0.00038614513167845434 ) * intrm_sf_mf_1142 ) + ( ( 900.639412248396 + t255 *
- 0.044484923911441127 ) + t264 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t317 = t314
- t311 ; intrm_sf_mf_1142 = t314 / ( t317 == 0.0 ? 1.0E-16 : t317 ) ; if ( X
[ 405ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
405ULL ] >= 1.0 ? 1.0 : X [ 405ULL ] ; } if ( X [ 404ULL ] <= 0.0 ) { t255 =
0.0 ; } else { t255 = X [ 404ULL ] >= 1.0 ? 1.0 : X [ 404ULL ] ; } t314 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
t255 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
t255 * 259.836612622973 ; if ( X [ 66ULL ] <= 0.0 ) { t255 = 0.0 ; } else {
t255 = X [ 66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ] ; } if ( X [ 65ULL ] <= 0.0 ) {
t363 = 0.0 ; } else { t363 = X [ 65ULL ] >= 1.0 ? 1.0 : X [ 65ULL ] ; } t264
= ( ( ( 1.0 - t255 ) - t363 ) * 296.802103844292 + t255 * 461.523 ) + t363 *
4124.48151675695 ; t255 = ( X [ 485ULL ] * - 0.62500003906250234 + U_idx_11 *
10.0 ) + 6.2500003783494407E-9 ; if ( X [ 69ULL ] <= 0.0 ) { t363 = 0.0 ; }
else { t363 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <=
0.0 ) { t317 = 0.0 ; } else { t317 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ;
} intrm_sf_mf_1399 = ( ( ( 1.0 - t363 ) - t317 ) * 296.802103844292 + t363 *
461.523 ) + t317 * 4124.48151675695 ; if ( X [ 488ULL ] <= 216.59999999999997
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 = X [ 488ULL
] >= 623.15 ? 623.15 : X [ 488ULL ] ; } intrm_sf_mf_1434 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 * -
0.22145652610641059 ) + intrm_sf_mf_1434 * 0.0003721298010901061 ) * ( ( 1.0
- t363 ) - t317 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
1.2002114337050787 ) + intrm_sf_mf_1434 * - 0.00038614513167845434 ) * t363 )
+ ( ( 12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
6.9647057412840034 ) + intrm_sf_mf_1434 * - 0.0070524868246844051 ) * t317 ;
t318 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 -
intrm_sf_mf_1399 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 / ( t318 ==
0.0 ? 1.0E-16 : t318 ) ; if ( X [ 493ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [ 493ULL
] >= 623.15 ? 623.15 : X [ 493ULL ] ; } t318 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ;
intrm_sf_mf_1434 = ( ( ( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * -
0.22145652610641059 ) + t318 * 0.0003721298010901061 ) * ( ( 1.0 - t363 ) -
t317 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
1.2002114337050787 ) + t318 * - 0.00038614513167845434 ) * t363 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
6.9647057412840034 ) + t318 * - 0.0070524868246844051 ) * t317 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
intrm_sf_mf_1434 - intrm_sf_mf_1399 ; t363 = intrm_sf_mf_1434 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) ;
if ( X [ 487ULL ] <= 0.0 ) { t317 = 0.0 ; } else { t317 = X [ 487ULL ] >= 1.0
? 1.0 : X [ 487ULL ] ; } if ( X [ 486ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [
486ULL ] >= 1.0 ? 1.0 : X [ 486ULL ] ; } intrm_sf_mf_1434 = ( ( ( 1.0 - t317
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) *
296.802103844292 + t317 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
4124.48151675695 ; if ( X [ 468ULL ] <= 0.0 ) { t317 = 0.0 ; } else { t317 =
X [ 468ULL ] >= 1.0 ? 1.0 : X [ 468ULL ] ; } if ( X [ 467ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [
467ULL ] >= 1.0 ? 1.0 : X [ 467ULL ] ; } t318 = ( ( ( 1.0 - t317 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) *
296.802103844292 + t317 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
4124.48151675695 ; if ( X [ 485ULL ] * 7.8539816339744827E-5 <=
7.8539816339744857E-13 ) { t317 = 7.8539816339744857E-13 ; } else if ( X [
485ULL ] * 7.8539816339744827E-5 >= 1.2566370614359172E-5 ) { t317 =
1.2566370614359172E-5 ; } else { t317 = X [ 485ULL ] * 7.8539816339744827E-5
; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = t317 /
7.8539816339744827E-5 ; if ( X [ 508ULL ] <= 0.0 ) { t317 = 0.0 ; } else {
t317 = X [ 508ULL ] >= 1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL ] <= 0.0
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } intrm_sf_mf_1543 = ( ( ( 1.0 - t317
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) *
296.802103844292 + t317 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 *
4124.48151675695 ; t321 = X [ 506ULL ] * intrm_sf_mf_1543 ; intrm_sf_mf_1670
= X [ 507ULL ] / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) * ( X [
510ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ;
intrm_sf_mf_1574 = X [ 507ULL ] / ( t255 == 0.0 ? 1.0E-16 : t255 ) * ( X [
511ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ;
intrm_sf_mf_1592 = ( X [ 64ULL ] + t255 ) / 2.0 * 0.0010000000000000009 ;
intrm_sf_mf_1739 = ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) * ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ) ;
intrm_sf_mf_1634 = intrm_sf_mf_1592 * intrm_sf_mf_1739 ; intrm_sf_mf_1659 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1670 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1574 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * 2.0 ;
intrm_sf_mf_1696 = ( X [ 64ULL ] - t255 ) * ( intrm_sf_mf_1659 >=
intrm_sf_mf_1739 ? intrm_sf_mf_1659 : intrm_sf_mf_1739 ) ; intrm_sf_mf_1659 =
( X [ 64ULL ] - t255 ) / ( intrm_sf_mf_1592 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1592 ) ; t330 = intrm_sf_mf_1659 * intrm_sf_mf_1659 * 3.0 -
intrm_sf_mf_1659 * intrm_sf_mf_1659 * intrm_sf_mf_1659 * 2.0 ; if ( X [ 64ULL
] - t255 <= 0.0 ) { intrm_sf_mf_1659 = intrm_sf_mf_1634 ; } else if ( X [
64ULL ] - t255 >= intrm_sf_mf_1592 ) { intrm_sf_mf_1659 = intrm_sf_mf_1696 ;
} else { intrm_sf_mf_1659 = ( 1.0 - t330 ) * intrm_sf_mf_1634 +
intrm_sf_mf_1696 * t330 ; } intrm_sf_mf_1696 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 + 1.0 ) * (
1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1574 ) - ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1670 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = ( t255 - X
[ 64ULL ] ) * ( intrm_sf_mf_1696 >= intrm_sf_mf_1739 ? intrm_sf_mf_1696 :
intrm_sf_mf_1739 ) ; intrm_sf_mf_1670 = ( t255 - X [ 64ULL ] ) / (
intrm_sf_mf_1592 == 0.0 ? 1.0E-16 : intrm_sf_mf_1592 ) ; intrm_sf_mf_1574 =
intrm_sf_mf_1670 * intrm_sf_mf_1670 * 3.0 - intrm_sf_mf_1670 *
intrm_sf_mf_1670 * intrm_sf_mf_1670 * 2.0 ; if ( t255 - X [ 64ULL ] <= 0.0 )
{ intrm_sf_mf_1670 = intrm_sf_mf_1634 ; } else if ( t255 - X [ 64ULL ] >=
intrm_sf_mf_1592 ) { intrm_sf_mf_1670 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 ; } else {
intrm_sf_mf_1670 = ( 1.0 - intrm_sf_mf_1574 ) * intrm_sf_mf_1634 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 *
intrm_sf_mf_1574 ; } if ( X [ 64ULL ] > t255 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 =
intrm_sf_mf_1659 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 = X [ 64ULL ]
< t255 ? intrm_sf_mf_1670 : intrm_sf_mf_1634 ; } if ( X [ 506ULL ] <=
216.59999999999997 ) { intrm_sf_mf_1670 = 216.59999999999997 ; } else {
intrm_sf_mf_1670 = X [ 506ULL ] >= 623.15 ? 623.15 : X [ 506ULL ] ; } t331 =
intrm_sf_mf_1670 * intrm_sf_mf_1670 ; intrm_sf_mf_1574 = ( ( (
1074.1165326382554 + intrm_sf_mf_1670 * - 0.22145652610641059 ) + t331 *
0.0003721298010901061 ) * ( ( 1.0 - t317 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) + ( (
1479.6504774710402 + intrm_sf_mf_1670 * 1.2002114337050787 ) + t331 * -
0.00038614513167845434 ) * t317 ) + ( ( 12825.281119789837 + intrm_sf_mf_1670
* 6.9647057412840034 ) + t331 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ; t332 =
intrm_sf_mf_1574 - intrm_sf_mf_1543 ; t317 = intrm_sf_mf_1574 / ( t332 == 0.0
? 1.0E-16 : t332 ) ; if ( X [ 524ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = X [
524ULL ] >= 1.0 ? 1.0 : X [ 524ULL ] ; } if ( X [ 525ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 525ULL ] >= 1.0 ?
1.0 : X [ 525ULL ] ; } intrm_sf_mf_1574 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 ) -
intrm_sf_mf_1670 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 * 461.523 ) +
intrm_sf_mf_1670 * 259.836612622973 ; if ( X [ 537ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 537ULL ] >= 1.0 ?
1.0 : X [ 537ULL ] ; } if ( X [ 536ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ;
} else { intrm_sf_mf_1739 = X [ 536ULL ] >= 1.0 ? 1.0 : X [ 536ULL ] ; }
intrm_sf_mf_1592 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) *
296.802103844292 + intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 *
259.836612622973 ; if ( X [ 73ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; }
else { intrm_sf_mf_1670 = X [ 73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ] ; } if ( X [
72ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X [
72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; } intrm_sf_mf_1634 = ( ( ( 1.0 -
intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670
* 461.523 ) + intrm_sf_mf_1739 * 259.836612622973 ; if ( X [ 76ULL ] <= 0.0 )
{ intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 76ULL ] >= 1.0 ?
1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; }
else { intrm_sf_mf_1739 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; }
intrm_sf_mf_1659 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) *
296.802103844292 + intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 *
4124.48151675695 ; if ( X [ 576ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; }
else { intrm_sf_mf_1670 = X [ 576ULL ] >= 1.0 ? 1.0 : X [ 576ULL ] ; } if ( X
[ 575ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X
[ 575ULL ] >= 1.0 ? 1.0 : X [ 575ULL ] ; } intrm_sf_mf_1696 = ( ( ( 1.0 -
intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670
* 461.523 ) + intrm_sf_mf_1739 * 4124.48151675695 ; if ( X [ 471ULL ] <= 0.0
) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 471ULL ] >= 1.0
? 1.0 : X [ 471ULL ] ; } if ( X [ 470ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0
; } else { intrm_sf_mf_1739 = X [ 470ULL ] >= 1.0 ? 1.0 : X [ 470ULL ] ; }
t330 = ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292
+ intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 * 4124.48151675695 ; if ( X
[ 515ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X
[ 515ULL ] >= 1.0 ? 1.0 : X [ 515ULL ] ; } if ( X [ 514ULL ] <= 0.0 ) {
intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X [ 514ULL ] >= 1.0 ?
1.0 : X [ 514ULL ] ; } t331 = ( ( ( 1.0 - intrm_sf_mf_1670 ) -
intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670 * 461.523 ) +
intrm_sf_mf_1739 * 259.836612622973 ; if ( X [ 529ULL ] <= 0.0 ) {
intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [ 529ULL ] >= 1.0 ?
1.0 : X [ 529ULL ] ; } if ( X [ 528ULL ] <= 0.0 ) { intrm_sf_mf_1739 = 0.0 ;
} else { intrm_sf_mf_1739 = X [ 528ULL ] >= 1.0 ? 1.0 : X [ 528ULL ] ; } t332
= ( ( ( 1.0 - intrm_sf_mf_1670 ) - intrm_sf_mf_1739 ) * 296.802103844292 +
intrm_sf_mf_1670 * 461.523 ) + intrm_sf_mf_1739 * 259.836612622973 ; if ( X [
555ULL ] <= 0.0 ) { intrm_sf_mf_1670 = 0.0 ; } else { intrm_sf_mf_1670 = X [
555ULL ] >= 1.0 ? 1.0 : X [ 555ULL ] ; } if ( X [ 554ULL ] <= 0.0 ) {
intrm_sf_mf_1739 = 0.0 ; } else { intrm_sf_mf_1739 = X [ 554ULL ] >= 1.0 ?
1.0 : X [ 554ULL ] ; } intrm_sf_mf_1672 = ( ( ( 1.0 - intrm_sf_mf_1670 ) -
intrm_sf_mf_1739 ) * 296.802103844292 + intrm_sf_mf_1670 * 461.523 ) +
intrm_sf_mf_1739 * 4124.48151675695 ; t201 [ 0ULL ] = X [ 92ULL ] ;
tlu2_linear_linear_prelookup ( & cb_efOut . mField0 [ 0ULL ] , & cb_efOut .
mField1 [ 0ULL ] , & cb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1
= cb_efOut ; t201 [ 0ULL ] = X [ 93ULL ] ; tlu2_linear_linear_prelookup ( &
db_efOut . mField0 [ 0ULL ] , & db_efOut . mField1 [ 0ULL ] , & db_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25 = db_efOut ;
tlu2_2d_linear_linear_value ( & eb_efOut [ 0ULL ] , & t1 . mField0 [ 0ULL ] ,
& t1 . mField2 [ 0ULL ] , & t25 . mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ]
, ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = eb_efOut [ 0 ] ; intrm_sf_mf_1670 =
t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 94ULL ] ; tlu2_linear_linear_prelookup (
& fb_efOut . mField0 [ 0ULL ] , & fb_efOut . mField1 [ 0ULL ] , & fb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [
0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25 = fb_efOut ;
tlu2_2d_linear_linear_value ( & gb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t24 . mField0 [ 0ULL ] , & t24 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , &
t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = gb_efOut [ 0 ] ;
intrm_sf_mf_1739 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 101ULL ] ;
tlu2_linear_linear_prelookup ( & hb_efOut . mField0 [ 0ULL ] , & hb_efOut .
mField1 [ 0ULL ] , & hb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1
= hb_efOut ; tlu2_2d_linear_linear_value ( & ib_efOut [ 0ULL ] , & t1 .
mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL ] , & t27 . mField0 [ 0ULL ] , & t27
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = ib_efOut [ 0 ] ;
intrm_sf_mf_1740 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 103ULL ] ;
tlu2_linear_linear_prelookup ( & jb_efOut . mField0 [ 0ULL ] , & jb_efOut .
mField1 [ 0ULL ] , & jb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t27
= jb_efOut ; tlu2_2d_linear_linear_value ( & kb_efOut [ 0ULL ] , & t27 .
mField0 [ 0ULL ] , & t27 . mField2 [ 0ULL ] , & t8 . mField0 [ 0ULL ] , & t8
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = kb_efOut [ 0 ] ;
intrm_sf_mf_1741 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_linear_prelookup ( & lb_efOut . mField0 [ 0ULL ] , & lb_efOut .
mField1 [ 0ULL ] , & lb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t27
= lb_efOut ; tlu2_2d_linear_linear_value ( & mb_efOut [ 0ULL ] , & t27 .
mField0 [ 0ULL ] , & t27 . mField2 [ 0ULL ] , & t22 . mField0 [ 0ULL ] , &
t22 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t32 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = mb_efOut [ 0
] ; intrm_sf_mf_1742 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 112ULL ] ;
tlu2_linear_linear_prelookup ( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut .
mField1 [ 0ULL ] , & nb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= nb_efOut ; tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t25 .
mField0 [ 0ULL ] , & t25 . mField2 [ 0ULL ] , & t21 . mField0 [ 0ULL ] , &
t21 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , &
t32 [ 0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = ob_efOut [ 0
] ; intrm_sf_mf_1743 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 137ULL ] ;
tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t22
= pb_efOut ; t201 [ 0ULL ] = X [ 138ULL ] ; tlu2_linear_linear_prelookup ( &
qb_efOut . mField0 [ 0ULL ] , & qb_efOut . mField1 [ 0ULL ] , & qb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1 = qb_efOut ;
tlu2_2d_linear_linear_value ( & rb_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ]
, & t22 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = rb_efOut [ 0 ] ; intrm_sf_mf_1744 =
t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 156ULL ] ; tlu2_linear_linear_prelookup (
& sb_efOut . mField0 [ 0ULL ] , & sb_efOut . mField1 [ 0ULL ] , & sb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [
0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t22 = sb_efOut ;
tlu2_2d_linear_linear_value ( & tb_efOut [ 0ULL ] , & t22 . mField0 [ 0ULL ]
, & t22 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = tb_efOut [ 0 ] ; intrm_sf_mf_1772 =
t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 157ULL ] ; tlu2_linear_linear_prelookup (
& ub_efOut . mField0 [ 0ULL ] , & ub_efOut . mField1 [ 0ULL ] , & ub_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t201 [
0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25 = ub_efOut ;
tlu2_2d_linear_linear_value ( & vb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t28 . mField0 [ 0ULL ] , & t28 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , &
t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t202 [ 0 ] = vb_efOut [ 0 ] ;
intrm_sf_mf_1773 = t202 [ 0ULL ] ; t201 [ 0ULL ] = X [ 8ULL ] ;
tlu2_linear_linear_prelookup ( & wb_efOut . mField0 [ 0ULL ] , & wb_efOut .
mField1 [ 0ULL ] , & wb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t201 [ 0ULL ] , & t32 [ 0ULL ] , & t33 [ 0ULL ] ) ; t25
= wb_efOut ; t201 [ 0ULL ] = X [ 15ULL ] ; tlu2_linear_linear_prelookup ( &
xb_efOut . mField0 [ 0ULL ] , & xb_efOut . mField1 [ 0ULL ] , & xb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t201 [
0ULL ] , & t35 [ 0ULL ] , & t33 [ 0ULL ] ) ; t1 = xb_efOut ;
tlu2_2d_linear_linear_value ( & yb_efOut [ 0ULL ] , & t25 . mField0 [ 0ULL ]
, & t25 . mField2 [ 0ULL ] , & t1 . mField0 [ 0ULL ] , & t1 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField12 , & t32 [ 0ULL ] , & t35 [
0ULL ] , & t33 [ 0ULL ] ) ; t201 [ 0 ] = yb_efOut [ 0 ] ; intrm_sf_mf_1774 =
t201 [ 0ULL ] ; if ( U_idx_13 >= 1.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 = 1.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 =
U_idx_13 <= 0.0 ? 0.0 : U_idx_13 ; } if ( X [ 182ULL ] <= 0.0 ) { U_idx_3 =
0.0 ; } else { U_idx_3 = X [ 182ULL ] >= 1.0 ? 1.0 : X [ 182ULL ] ; } if ( X
[ 181ULL ] <= 0.0 ) { U_idx_7 = 0.0 ; } else { U_idx_7 = X [ 181ULL ] >= 1.0
? 1.0 : X [ 181ULL ] ; } U_idx_11 = ( ( ( 1.0 - U_idx_3 ) - U_idx_7 ) *
296.802103844292 + U_idx_3 * 461.523 ) + U_idx_7 * 4124.48151675695 ; if ( X
[ 309ULL ] <= 0.0 ) { U_idx_3 = 0.0 ; } else { U_idx_3 = X [ 309ULL ] >= 1.0
? 1.0 : X [ 309ULL ] ; } if ( X [ 308ULL ] <= 0.0 ) { U_idx_7 = 0.0 ; } else
{ U_idx_7 = X [ 308ULL ] >= 1.0 ? 1.0 : X [ 308ULL ] ; } U_idx_13 = ( ( ( 1.0
- U_idx_3 ) - U_idx_7 ) * 296.802103844292 + U_idx_3 * 461.523 ) + U_idx_7 *
259.836612622973 ; t201 [ 0ULL ] = pmf_get_inf ( ) ; for ( t205 = 0ULL ; t205
< 42ULL ; t205 ++ ) { t206 = t205 / 42ULL ; U_idx_3 = t201 [ t206 > 0ULL ?
0ULL : t206 ] ; U_idx_7 = ( ( _NeDynamicSystem * ) ( LC ) ) -> mField0 [ t205
] * 1.0E-5 ; t201 [ t206 > 0ULL ? 0ULL : t206 ] = U_idx_3 > U_idx_7 ? U_idx_7
: U_idx_3 ; } t202 [ 0ULL ] = pmf_get_inf ( ) ; for ( t205 = 0ULL ; t205 <
7ULL ; t205 ++ ) { t206 = t205 / 7ULL ; U_idx_3 = t202 [ t206 > 0ULL ? 0ULL :
t206 ] ; U_idx_7 = nonscalar1 [ t205 ] * 1.0E-5 ; t202 [ t206 > 0ULL ? 0ULL :
t206 ] = U_idx_3 > U_idx_7 ? U_idx_7 : U_idx_3 ; } t181 [ 0ULL ] = ( int32_T
) ( t201 [ 0ULL ] >= X [ 80ULL ] ) ; t181 [ 1ULL ] = ( int32_T ) ( t202 [
0ULL ] >= X [ 85ULL ] * X [ 87ULL ] ) ; t181 [ 2ULL ] = ( int32_T ) ( t401 *
293.15 / 1.01325 >= 0.0 ) ; t181 [ 3ULL ] = ( int32_T ) ( X [ 414ULL ] * t311
/ ( X [ 415ULL ] == 0.0 ? 1.0E-16 : X [ 415ULL ] ) >= 0.0 ) ; t181 [ 4ULL ] =
( int32_T ) ( X [ 416ULL ] * t311 / ( X [ 417ULL ] == 0.0 ? 1.0E-16 : X [
417ULL ] ) >= 0.0 ) ; t181 [ 5ULL ] = ( int32_T ) ( X [ 51ULL ] * t311 / ( X
[ 54ULL ] == 0.0 ? 1.0E-16 : X [ 54ULL ] ) >= 0.0 ) ; t181 [ 6ULL ] = (
int32_T ) ( X [ 32ULL ] <= 216.59999999999997 ) ; t181 [ 7ULL ] = ( int32_T )
( X [ 32ULL ] >= 623.15 ) ; t181 [ 8ULL ] = ( int32_T ) ( X [ 469ULL ] * t330
/ ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) >= 0.0 ) ; t181 [ 9ULL ] = (
int32_T ) ( X [ 63ULL ] * t264 / ( X [ 64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ]
) >= 0.0 ) ; t181 [ 10ULL ] = ( int32_T ) ( X [ 484ULL ] * intrm_sf_mf_1434 /
( t255 == 0.0 ? 1.0E-16 : t255 ) >= 0.0 ) ; t181 [ 11ULL ] = ( int32_T ) ( X
[ 466ULL ] * t318 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) >= 0.0 ) ;
t181 [ 12ULL ] = ( int32_T ) ( X [ 488ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 *
intrm_sf_mf_1399 >= 0.0 ) ; t181 [ 13ULL ] = ( int32_T ) ( X [ 175ULL ] *
t348 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) >= 0.0 ) ; t181 [
14ULL ] = ( int32_T ) ( X [ 493ULL ] * t363 * intrm_sf_mf_1399 >= 0.0 ) ;
t181 [ 15ULL ] = ( int32_T ) ( X [ 489ULL ] * X [ 489ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M27 / (
intrm_sf_mf_1399 == 0.0 ? 1.0E-16 : intrm_sf_mf_1399 ) / ( X [ 488ULL ] ==
0.0 ? 1.0E-16 : X [ 488ULL ] ) >= 0.0 ) ; t363 = X [ 494ULL ] * X [ 494ULL ]
* t363 / ( intrm_sf_mf_1399 == 0.0 ? 1.0E-16 : intrm_sf_mf_1399 ) ; t181 [
16ULL ] = ( int32_T ) ( t363 / ( X [ 493ULL ] == 0.0 ? 1.0E-16 : X [ 493ULL ]
) >= 0.0 ) ; t181 [ 17ULL ] = ( int32_T ) ( X [ 488ULL ] * intrm_sf_mf_1399 /
( X [ 489ULL ] == 0.0 ? 1.0E-16 : X [ 489ULL ] ) >= 0.0 ) ; t181 [ 18ULL ] =
( int32_T ) ( X [ 493ULL ] * intrm_sf_mf_1399 / ( X [ 494ULL ] == 0.0 ?
1.0E-16 : X [ 494ULL ] ) >= 0.0 ) ; t181 [ 19ULL ] = ( int32_T ) ( X [ 67ULL
] * intrm_sf_mf_1399 / ( X [ 68ULL ] == 0.0 ? 1.0E-16 : X [ 68ULL ] ) >= 0.0
) ; t181 [ 20ULL ] = ( int32_T ) ( X [ 507ULL ] / ( t321 == 0.0 ? 1.0E-16 :
t321 ) * 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu19 )
>= 0.0 ) ; t181 [ 21ULL ] = ( int32_T ) ( X [ 507ULL ] * X [ 507ULL ] * t317
/ ( intrm_sf_mf_1543 == 0.0 ? 1.0E-16 : intrm_sf_mf_1543 ) / ( X [ 506ULL ]
== 0.0 ? 1.0E-16 : X [ 506ULL ] ) >= 0.0 ) ; t181 [ 22ULL ] = ( int32_T ) ( X
[ 194ULL ] * t277 / ( X [ 195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) >= 0.0 )
; t181 [ 23ULL ] = ( int32_T ) ( X [ 510ULL ] * intrm_sf_mf_1543 / ( X [
64ULL ] == 0.0 ? 1.0E-16 : X [ 64ULL ] ) >= 0.0 ) ; t181 [ 24ULL ] = (
int32_T ) ( X [ 511ULL ] * intrm_sf_mf_1543 / ( t255 == 0.0 ? 1.0E-16 : t255
) >= 0.0 ) ; t181 [ 25ULL ] = ( int32_T ) ( t321 / ( X [ 507ULL ] == 0.0 ?
1.0E-16 : X [ 507ULL ] ) >= 0.0 ) ; t181 [ 26ULL ] = ( int32_T ) ( X [ 513ULL
] * t331 / 1.01325 >= 0.0 ) ; t181 [ 27ULL ] = ( int32_T ) ( intrm_sf_mf_1574
* 293.15 / 1.01325 >= 0.0 ) ; t181 [ 28ULL ] = ( int32_T ) ( X [ 527ULL ] *
t332 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) >= 0.0 ) ; t181 [ 29ULL
] = ( int32_T ) ( X [ 534ULL ] * intrm_sf_mf_1592 / ( X [ 55ULL ] == 0.0 ?
1.0E-16 : X [ 55ULL ] ) >= 0.0 ) ; t181 [ 30ULL ] = ( int32_T ) ( X [ 531ULL
] * intrm_sf_mf_1592 / 1.01325 >= 0.0 ) ; t181 [ 31ULL ] = ( int32_T ) ( X [
533ULL ] * intrm_sf_mf_1592 / 1.01325 >= 0.0 ) ; t181 [ 32ULL ] = ( int32_T )
( X [ 199ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 *
intrm_sf_mf_95 >= 0.0 ) ; t181 [ 33ULL ] = ( int32_T ) ( X [ 532ULL ] *
intrm_sf_mf_1592 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) >= 0.0 ) ;
t181 [ 34ULL ] = ( int32_T ) ( X [ 403ULL ] * t314 / ( X [ 55ULL ] == 0.0 ?
1.0E-16 : X [ 55ULL ] ) >= 0.0 ) ; t181 [ 35ULL ] = ( int32_T ) ( X [ 71ULL ]
* intrm_sf_mf_1634 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL ] ) >= 0.0 )
; t181 [ 36ULL ] = ( int32_T ) ( X [ 553ULL ] * intrm_sf_mf_1672 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) >= 0.0 ) ; t181 [ 37ULL ] = (
int32_T ) ( X [ 278ULL ] * t294 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL
] ) >= 0.0 ) ; t181 [ 38ULL ] = ( int32_T ) ( X [ 74ULL ] * intrm_sf_mf_1659
/ ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) >= 0.0 ) ; t181 [ 39ULL ] =
( int32_T ) ( X [ 203ULL ] * t409 * intrm_sf_mf_95 >= 0.0 ) ; t181 [ 40ULL ]
= ( int32_T ) ( X [ 573ULL ] * intrm_sf_mf_1696 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) >= 0.0 ) ; t181 [ 41ULL ] = ( int32_T ) ( X [ 570ULL
] * intrm_sf_mf_1696 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) >=
0.0 ) ; t181 [ 42ULL ] = ( int32_T ) ( X [ 572ULL ] * intrm_sf_mf_1696 / ( X
[ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) >= 0.0 ) ; t181 [ 43ULL ] = (
int32_T ) ( X [ 571ULL ] * intrm_sf_mf_1696 / ( X [ 38ULL ] == 0.0 ? 1.0E-16
: X [ 38ULL ] ) >= 0.0 ) ; t181 [ 44ULL ] = ( int32_T ) ( X [ 464ULL ] > 0.6
) ; t181 [ 45ULL ] = ( int32_T ) ( X [ 78ULL ] > X [ 580ULL ] ) ; t181 [
46ULL ] = ( int32_T ) ( X [ 78ULL ] < - X [ 580ULL ] ) ; t181 [ 47ULL ] = (
int32_T ) ( X [ 86ULL ] > 0.0 ) ; t181 [ 48ULL ] = ( int32_T ) ( X [ 85ULL ]
> 0.0 ) ; t181 [ 49ULL ] = ( int32_T ) ( X [ 84ULL ] > 0.0 ) ; t181 [ 50ULL ]
= ( int32_T ) ( X [ 200ULL ] * X [ 200ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_g0 / (
intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [ 199ULL ] == 0.0 ?
1.0E-16 : X [ 199ULL ] ) >= 0.0 ) ; t181 [ 51ULL ] = ( int32_T ) ( X [ 80ULL
] >= 0.0 ) ; t181 [ 52ULL ] = ( int32_T ) ( X [ 87ULL ] > 0.0 ) ; t181 [
53ULL ] = ( int32_T ) ( X [ 4ULL ] > 0.0 ) ; t181 [ 54ULL ] = ( int32_T ) (
intrm_sf_mf_1670 > 0.0 ) ; t181 [ 55ULL ] = ( int32_T ) ( X [ 93ULL ] >= 0.1
) ; t181 [ 56ULL ] = ( int32_T ) ( X [ 93ULL ] <= 500.0 ) ; t181 [ 57ULL ] =
( int32_T ) ( X [ 92ULL ] >= 268.4357 ) ; t181 [ 58ULL ] = ( int32_T ) ( X [
92ULL ] <= 393.15 ) ; t181 [ 59ULL ] = ( int32_T ) ( intrm_sf_mf_1739 > 0.0 )
; t181 [ 60ULL ] = ( int32_T ) ( X [ 95ULL ] >= 0.1 ) ; t409 = X [ 204ULL ] *
X [ 204ULL ] * t409 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) ;
t181 [ 61ULL ] = ( int32_T ) ( t409 / ( X [ 203ULL ] == 0.0 ? 1.0E-16 : X [
203ULL ] ) >= 0.0 ) ; t181 [ 62ULL ] = ( int32_T ) ( X [ 95ULL ] <= 500.0 ) ;
t181 [ 63ULL ] = ( int32_T ) ( X [ 94ULL ] >= 268.4357 ) ; t181 [ 64ULL ] = (
int32_T ) ( X [ 94ULL ] <= 393.15 ) ; t181 [ 65ULL ] = ( int32_T ) (
intrm_sf_mf_1740 > 0.0 ) ; t181 [ 66ULL ] = ( int32_T ) ( X [ 102ULL ] >= 0.1
) ; t181 [ 67ULL ] = ( int32_T ) ( X [ 102ULL ] <= 500.0 ) ; t181 [ 68ULL ] =
( int32_T ) ( X [ 101ULL ] >= 268.4357 ) ; t181 [ 69ULL ] = ( int32_T ) ( X [
101ULL ] <= 393.15 ) ; t181 [ 70ULL ] = ( int32_T ) ( intrm_sf_mf_1741 > 0.0
) ; t181 [ 71ULL ] = ( int32_T ) ( X [ 104ULL ] >= 0.1 ) ; t181 [ 72ULL ] = (
int32_T ) ( X [ 199ULL ] * intrm_sf_mf_95 / ( X [ 200ULL ] == 0.0 ? 1.0E-16 :
X [ 200ULL ] ) >= 0.0 ) ; t181 [ 73ULL ] = ( int32_T ) ( X [ 104ULL ] <=
500.0 ) ; t181 [ 74ULL ] = ( int32_T ) ( X [ 103ULL ] >= 268.4357 ) ; t181 [
75ULL ] = ( int32_T ) ( X [ 103ULL ] <= 393.15 ) ; t181 [ 76ULL ] = ( int32_T
) ( intrm_sf_mf_1742 > 0.0 ) ; t181 [ 77ULL ] = ( int32_T ) ( X [ 111ULL ] >=
0.1 ) ; t181 [ 78ULL ] = ( int32_T ) ( X [ 111ULL ] <= 500.0 ) ; t181 [ 79ULL
] = ( int32_T ) ( X [ 110ULL ] >= 268.4357 ) ; t181 [ 80ULL ] = ( int32_T ) (
X [ 110ULL ] <= 393.15 ) ; t181 [ 81ULL ] = ( int32_T ) ( intrm_sf_mf_1743 >
0.0 ) ; t181 [ 82ULL ] = ( int32_T ) ( X [ 113ULL ] >= 0.1 ) ; t181 [ 83ULL ]
= ( int32_T ) ( X [ 203ULL ] * intrm_sf_mf_95 / ( X [ 204ULL ] == 0.0 ?
1.0E-16 : X [ 204ULL ] ) >= 0.0 ) ; t181 [ 84ULL ] = ( int32_T ) ( X [ 113ULL
] <= 500.0 ) ; t181 [ 85ULL ] = ( int32_T ) ( X [ 112ULL ] >= 268.4357 ) ;
t181 [ 86ULL ] = ( int32_T ) ( X [ 112ULL ] <= 393.15 ) ; t181 [ 87ULL ] = (
int32_T ) ( t274 > 0.0 ) ; t181 [ 88ULL ] = ( int32_T ) ( t437 >= 0.1 ) ;
t181 [ 89ULL ] = ( int32_T ) ( t437 <= 500.0 ) ; t181 [ 90ULL ] = ( int32_T )
( X [ 6ULL ] >= 268.4357 ) ; t181 [ 91ULL ] = ( int32_T ) ( X [ 6ULL ] <=
393.15 ) ; t181 [ 92ULL ] = ( int32_T ) (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_1 > 0.0 ) ;
t181 [ 93ULL ] = ( int32_T ) (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_indicator_2 > 0.0 ) ;
t181 [ 94ULL ] = ( int32_T ) ( X [ 21ULL ] * intrm_sf_mf_95 / ( X [ 22ULL ]
== 0.0 ? 1.0E-16 : X [ 22ULL ] ) >= 0.0 ) ; t181 [ 95ULL ] = ( int32_T ) ( X
[ 120ULL ] >= 0.1 ) ; t181 [ 96ULL ] = ( int32_T ) ( X [ 120ULL ] <= 500.0 )
; t181 [ 97ULL ] = ( int32_T ) ( X [ 119ULL ] >= 268.4357 ) ; t181 [ 98ULL ]
= ( int32_T ) ( X [ 119ULL ] <= 393.15 ) ; t181 [ 99ULL ] = ( int32_T ) (
t275 > 0.0 ) ; t181 [ 100ULL ] = ( int32_T ) (
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I >= 0.1 ) ; t181 [
101ULL ] = ( int32_T ) (
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I <= 500.0 ) ; t181 [
102ULL ] = ( int32_T ) ( X [ 9ULL ] >= 268.4357 ) ; t181 [ 103ULL ] = (
int32_T ) ( X [ 9ULL ] <= 393.15 ) ; t181 [ 104ULL ] = ( int32_T ) (
Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_1 > 0.0 ) ;
t181 [ 105ULL ] = ( int32_T ) ( X [ 84ULL ] * X [ 86ULL ] <= 4.03416E-7 ) ;
t181 [ 106ULL ] = ( int32_T ) (
Electrical_Cooling_System_Pipe_Converter_pipe_model_indicator_2 > 0.0 ) ;
t181 [ 107ULL ] = ( int32_T ) ( t276 > 0.0 ) ; t181 [ 108ULL ] = ( int32_T )
( Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I >= 0.1 ) ; t181 [
109ULL ] = ( int32_T ) ( Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I
<= 500.0 ) ; t181 [ 110ULL ] = ( int32_T ) ( X [ 11ULL ] >= 268.4357 ) ; t181
[ 111ULL ] = ( int32_T ) ( X [ 11ULL ] <= 393.15 ) ; t181 [ 112ULL ] = (
int32_T ) ( Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_A >
0.0 ) ; t181 [ 113ULL ] = ( int32_T ) (
Electrical_Cooling_System_Pipe_Motor_pipe_model_indicator_pT_B > 0.0 ) ; t181
[ 114ULL ] = ( int32_T ) ( intrm_sf_mf_1744 > 0.0 ) ; t181 [ 115ULL ] = (
int32_T ) ( X [ 138ULL ] >= 0.1 ) ; t181 [ 116ULL ] = ( int32_T ) ( X [
180ULL ] * U_idx_11 / 1.01325 >= 0.0 ) ; t181 [ 117ULL ] = ( int32_T ) ( X [
138ULL ] <= 500.0 ) ; t181 [ 118ULL ] = ( int32_T ) ( X [ 137ULL ] >=
268.4357 ) ; t181 [ 119ULL ] = ( int32_T ) ( X [ 137ULL ] <= 393.15 ) ; t181
[ 120ULL ] = ( int32_T ) ( X [ 147ULL ] >= 1.0E-5 ) ; t181 [ 121ULL ] = (
int32_T ) ( X [ 147ULL ] <= pmf_get_inf ( ) ) ; t181 [ 122ULL ] = ( int32_T )
( X [ 146ULL ] >= 1.0 ) ; t181 [ 123ULL ] = ( int32_T ) ( X [ 146ULL ] <=
pmf_get_inf ( ) ) ; t181 [ 124ULL ] = ( int32_T ) ( X [ 149ULL ] >= 1.0E-5 )
; t181 [ 125ULL ] = ( int32_T ) ( X [ 149ULL ] <= pmf_get_inf ( ) ) ; t181 [
126ULL ] = ( int32_T ) ( X [ 220ULL ] / ( t280 == 0.0 ? 1.0E-16 : t280 ) *
2.0 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0
? 1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 )
>= 0.0 ) ; t181 [ 127ULL ] = ( int32_T ) ( X [ 148ULL ] >= 1.0 ) ; t181 [
128ULL ] = ( int32_T ) ( X [ 148ULL ] <= pmf_get_inf ( ) ) ; t181 [ 129ULL ]
= ( int32_T ) ( X [ 145ULL ] <= pmf_get_inf ( ) ) ; t181 [ 130ULL ] = (
int32_T ) ( X [ 145ULL ] >= 1.0E-5 ) ; t181 [ 131ULL ] = ( int32_T ) ( X [
144ULL ] <= pmf_get_inf ( ) ) ; t181 [ 132ULL ] = ( int32_T ) ( X [ 144ULL ]
>= 1.0 ) ; t181 [ 133ULL ] = ( int32_T ) ( X [ 15ULL ] <= pmf_get_inf ( ) ) ;
t181 [ 134ULL ] = ( int32_T ) ( X [ 15ULL ] >= 1.0E-5 ) ; t181 [ 135ULL ] = (
int32_T ) ( X [ 7ULL ] <= pmf_get_inf ( ) ) ; t181 [ 136ULL ] = ( int32_T ) (
X [ 7ULL ] >= 1.0 ) ; t181 [ 137ULL ] = ( int32_T ) ( X [ 220ULL ] * X [
220ULL ] * intrm_sf_mf_237 / ( intrm_sf_mf_239 == 0.0 ? 1.0E-16 :
intrm_sf_mf_239 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) >= 0.0 )
; t181 [ 138ULL ] = ( int32_T ) ( intrm_sf_mf_1772 > 0.0 ) ; t181 [ 139ULL ]
= ( int32_T ) ( X [ 156ULL ] <= 393.15 ) ; t181 [ 140ULL ] = ( int32_T ) ( X
[ 156ULL ] >= 268.4357 ) ; t181 [ 141ULL ] = ( int32_T ) ( intrm_sf_mf_1773 >
0.0 ) ; t181 [ 142ULL ] = ( int32_T ) ( X [ 157ULL ] <= 393.15 ) ; t181 [
143ULL ] = ( int32_T ) ( X [ 157ULL ] >= 268.4357 ) ; t181 [ 144ULL ] = (
int32_T ) ( intrm_sf_mf_1774 > 0.0 ) ; t181 [ 145ULL ] = ( int32_T ) ( X [
15ULL ] <= 500.0 ) ; t181 [ 146ULL ] = ( int32_T ) ( X [ 15ULL ] >= 0.1 ) ;
t181 [ 147ULL ] = ( int32_T ) ( X [ 8ULL ] <= 393.15 ) ; t181 [ 148ULL ] = (
int32_T ) ( X [ 223ULL ] * intrm_sf_mf_239 / ( X [ 195ULL ] == 0.0 ? 1.0E-16
: X [ 195ULL ] ) >= 0.0 ) ; t181 [ 149ULL ] = ( int32_T ) ( X [ 8ULL ] >=
268.4357 ) ; t181 [ 150ULL ] = ( int32_T ) (
Electrical_Cooling_System_Tank_Tank_level * 0.005 < 0.001 ) ; t181 [ 151ULL ]
= ( int32_T ) ( Electrical_Cooling_System_Tank_Tank_level > 0.01 ) ; t181 [
152ULL ] = ( int32_T ) ( X [ 10ULL ] > 0.0 ) ; t181 [ 153ULL ] = ( int32_T )
( X [ 16ULL ] > 0.0 ) ; t181 [ 154ULL ] = ( int32_T ) ( X [ 12ULL ] > 0.0 ) ;
t181 [ 155ULL ] = ( int32_T ) ( X [ 17ULL ] > 0.0 ) ; t181 [ 156ULL ] = (
int32_T ) ( ( 1.0 - X [ 191ULL ] ) - X [ 192ULL ] >= 0.0 ) ; t181 [ 157ULL ]
= ( int32_T ) ( X [ 176ULL ] >= 0.01 ) ; t181 [ 158ULL ] = ( int32_T ) ( X [
176ULL ] <= pmf_get_inf ( ) ) ; t181 [ 159ULL ] = ( int32_T ) ( X [ 224ULL ]
* intrm_sf_mf_239 / 1.01325 >= 0.0 ) ; t181 [ 160ULL ] = ( int32_T ) ( X [
175ULL ] >= 216.59999999999997 ) ; t181 [ 161ULL ] = ( int32_T ) ( X [ 175ULL
] <= 623.15 ) ; t181 [ 162ULL ] = ( int32_T ) ( X [ 195ULL ] >= 0.01 ) ; t181
[ 163ULL ] = ( int32_T ) ( X [ 195ULL ] <= pmf_get_inf ( ) ) ; t181 [ 164ULL
] = ( int32_T ) ( X [ 194ULL ] >= 216.59999999999997 ) ; t181 [ 165ULL ] = (
int32_T ) ( X [ 194ULL ] <= 623.15 ) ; t181 [ 166ULL ] = ( int32_T ) ( X [
22ULL ] >= 0.01 ) ; t181 [ 167ULL ] = ( int32_T ) ( X [ 22ULL ] <=
pmf_get_inf ( ) ) ; t181 [ 168ULL ] = ( int32_T ) ( X [ 21ULL ] >=
216.59999999999997 ) ; t181 [ 169ULL ] = ( int32_T ) ( X [ 21ULL ] <= 623.15
) ; t181 [ 170ULL ] = ( int32_T ) ( t280 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 :
X [ 220ULL ] ) >= 0.0 ) ; t181 [ 171ULL ] = ( int32_T ) ( X [ 180ULL ] >=
216.59999999999997 ) ; t181 [ 172ULL ] = ( int32_T ) ( X [ 180ULL ] <= 623.15
) ; t181 [ 173ULL ] = ( int32_T ) ( X [ 241ULL ] >= 0.01 ) ; t181 [ 174ULL ]
= ( int32_T ) ( X [ 241ULL ] <= pmf_get_inf ( ) ) ; t181 [ 175ULL ] = (
int32_T ) ( X [ 240ULL ] >= 216.59999999999997 ) ; t181 [ 176ULL ] = (
int32_T ) ( X [ 240ULL ] <= 623.15 ) ; t181 [ 177ULL ] = ( int32_T ) ( X [
227ULL ] >= 0.01 ) ; t181 [ 178ULL ] = ( int32_T ) ( X [ 227ULL ] <=
pmf_get_inf ( ) ) ; t181 [ 179ULL ] = ( int32_T ) ( X [ 226ULL ] >=
216.59999999999997 ) ; t181 [ 180ULL ] = ( int32_T ) ( X [ 226ULL ] <= 623.15
) ; t181 [ 181ULL ] = ( int32_T ) ( X [ 240ULL ] * intrm_sf_mf_290 / ( X [
241ULL ] == 0.0 ? 1.0E-16 : X [ 241ULL ] ) >= 0.0 ) ; t181 [ 182ULL ] = (
int32_T ) ( X [ 31ULL ] >= 0.01 ) ; t181 [ 183ULL ] = ( int32_T ) ( X [ 31ULL
] <= pmf_get_inf ( ) ) ; t181 [ 184ULL ] = ( int32_T ) ( X [ 25ULL ] >=
216.59999999999997 ) ; t181 [ 185ULL ] = ( int32_T ) ( X [ 25ULL ] <= 623.15
) ; t181 [ 186ULL ] = ( int32_T ) ( X [ 33ULL ] >= 0.01 ) ; t181 [ 187ULL ] =
( int32_T ) ( X [ 33ULL ] <= pmf_get_inf ( ) ) ; t181 [ 188ULL ] = ( int32_T
) ( X [ 28ULL ] >= 216.59999999999997 ) ; t181 [ 189ULL ] = ( int32_T ) ( X [
28ULL ] <= 623.15 ) ; t181 [ 190ULL ] = ( int32_T ) ( X [ 38ULL ] >= 0.01 ) ;
t181 [ 191ULL ] = ( int32_T ) ( X [ 38ULL ] <= pmf_get_inf ( ) ) ; t181 [
192ULL ] = ( int32_T ) ( X [ 226ULL ] * intrm_sf_mf_335 / ( X [ 227ULL ] ==
0.0 ? 1.0E-16 : X [ 227ULL ] ) >= 0.0 ) ; t181 [ 193ULL ] = ( int32_T ) ( X [
278ULL ] >= 216.59999999999997 ) ; t181 [ 194ULL ] = ( int32_T ) ( X [ 278ULL
] <= 623.15 ) ; t181 [ 195ULL ] = ( int32_T ) ( X [ 37ULL ] >= 0.01 ) ; t181
[ 196ULL ] = ( int32_T ) ( X [ 37ULL ] <= pmf_get_inf ( ) ) ; t181 [ 197ULL ]
= ( int32_T ) ( X [ 34ULL ] >= 216.59999999999997 ) ; t181 [ 198ULL ] = (
int32_T ) ( X [ 34ULL ] <= 623.15 ) ; t181 [ 199ULL ] = ( int32_T ) ( ( 1.0 -
X [ 318ULL ] ) - X [ 319ULL ] >= 0.0 ) ; t181 [ 200ULL ] = ( int32_T ) ( X [
303ULL ] >= 0.01 ) ; t181 [ 201ULL ] = ( int32_T ) ( X [ 303ULL ] <=
pmf_get_inf ( ) ) ; t181 [ 202ULL ] = ( int32_T ) ( X [ 302ULL ] >=
216.59999999999997 ) ; t181 [ 203ULL ] = ( int32_T ) ( X [ 245ULL ] * t286 *
t283 >= 0.0 ) ; t181 [ 204ULL ] = ( int32_T ) ( X [ 302ULL ] <= 623.15 ) ;
t181 [ 205ULL ] = ( int32_T ) ( t228 >= 0.01 ) ; t181 [ 206ULL ] = ( int32_T
) ( t228 <= pmf_get_inf ( ) ) ; t181 [ 207ULL ] = ( int32_T ) ( X [ 321ULL ]
>= 216.59999999999997 ) ; t181 [ 208ULL ] = ( int32_T ) ( X [ 321ULL ] <=
623.15 ) ; t181 [ 209ULL ] = ( int32_T ) ( X [ 40ULL ] >= 0.01 ) ; t181 [
210ULL ] = ( int32_T ) ( X [ 40ULL ] <= pmf_get_inf ( ) ) ; t181 [ 211ULL ] =
( int32_T ) ( X [ 39ULL ] >= 216.59999999999997 ) ; t181 [ 212ULL ] = (
int32_T ) ( X [ 39ULL ] <= 623.15 ) ; t181 [ 213ULL ] = ( int32_T ) ( X [
307ULL ] >= 216.59999999999997 ) ; t181 [ 214ULL ] = ( int32_T ) ( X [ 81ULL
] >= 0.9 ) ; t181 [ 215ULL ] = ( int32_T ) ( X [ 248ULL ] * t278 * t283 >=
0.0 ) ; t181 [ 216ULL ] = ( int32_T ) ( X [ 307ULL ] <= 623.15 ) ; t181 [
217ULL ] = ( int32_T ) ( X [ 365ULL ] >= 0.01 ) ; t181 [ 218ULL ] = ( int32_T
) ( X [ 365ULL ] <= pmf_get_inf ( ) ) ; t181 [ 219ULL ] = ( int32_T ) ( X [
364ULL ] >= 216.59999999999997 ) ; t181 [ 220ULL ] = ( int32_T ) ( X [ 364ULL
] <= 623.15 ) ; t181 [ 221ULL ] = ( int32_T ) ( X [ 351ULL ] >= 0.01 ) ; t181
[ 222ULL ] = ( int32_T ) ( X [ 351ULL ] <= pmf_get_inf ( ) ) ; t181 [ 223ULL
] = ( int32_T ) ( X [ 350ULL ] >= 216.59999999999997 ) ; t181 [ 224ULL ] = (
int32_T ) ( X [ 350ULL ] <= 623.15 ) ; t181 [ 225ULL ] = ( int32_T ) ( X [
49ULL ] >= 0.01 ) ; t181 [ 226ULL ] = ( int32_T ) ( X [ 246ULL ] * X [ 246ULL
] * t286 / ( t283 == 0.0 ? 1.0E-16 : t283 ) / ( X [ 245ULL ] == 0.0 ? 1.0E-16
: X [ 245ULL ] ) >= 0.0 ) ; t181 [ 227ULL ] = ( int32_T ) ( X [ 49ULL ] <=
pmf_get_inf ( ) ) ; t181 [ 228ULL ] = ( int32_T ) ( X [ 43ULL ] >=
216.59999999999997 ) ; t181 [ 229ULL ] = ( int32_T ) ( X [ 43ULL ] <= 623.15
) ; t181 [ 230ULL ] = ( int32_T ) ( X [ 50ULL ] >= 0.01 ) ; t181 [ 231ULL ] =
( int32_T ) ( X [ 50ULL ] <= pmf_get_inf ( ) ) ; t181 [ 232ULL ] = ( int32_T
) ( X [ 46ULL ] >= 216.59999999999997 ) ; t181 [ 233ULL ] = ( int32_T ) ( X [
46ULL ] <= 623.15 ) ; t181 [ 234ULL ] = ( int32_T ) ( X [ 55ULL ] >= 0.01 ) ;
t181 [ 235ULL ] = ( int32_T ) ( X [ 55ULL ] <= pmf_get_inf ( ) ) ; t181 [
236ULL ] = ( int32_T ) ( X [ 403ULL ] >= 216.59999999999997 ) ; t181 [ 237ULL
] = ( int32_T ) ( X [ 249ULL ] * X [ 249ULL ] * t278 / ( t283 == 0.0 ?
1.0E-16 : t283 ) / ( X [ 248ULL ] == 0.0 ? 1.0E-16 : X [ 248ULL ] ) >= 0.0 )
; t181 [ 238ULL ] = ( int32_T ) ( X [ 403ULL ] <= 623.15 ) ; t181 [ 239ULL ]
= ( int32_T ) ( X [ 54ULL ] >= 0.01 ) ; t181 [ 240ULL ] = ( int32_T ) ( X [
54ULL ] <= pmf_get_inf ( ) ) ; t181 [ 241ULL ] = ( int32_T ) ( X [ 51ULL ] >=
216.59999999999997 ) ; t181 [ 242ULL ] = ( int32_T ) ( X [ 51ULL ] <= 623.15
) ; t181 [ 243ULL ] = ( int32_T ) ( X [ 56ULL ] >= 273.16 ) ; t181 [ 244ULL ]
= ( int32_T ) ( X [ 56ULL ] <= 363.16 ) ; t181 [ 245ULL ] = ( int32_T ) ( X [
57ULL ] * 0.1 + 0.0001 > 1.0E-8 ) ; t181 [ 246ULL ] = ( int32_T ) ( X [
437ULL ] >= 0.5 ) ; t181 [ 247ULL ] = ( int32_T ) ( X [ 437ULL ] <= 500.0 ) ;
t181 [ 248ULL ] = ( int32_T ) ( X [ 245ULL ] * t283 / ( X [ 246ULL ] == 0.0 ?
1.0E-16 : X [ 246ULL ] ) >= 0.0 ) ; t181 [ 249ULL ] = ( int32_T ) ( X [
436ULL ] >= 273.16 ) ; t181 [ 250ULL ] = ( int32_T ) ( X [ 436ULL ] <= 363.16
) ; t181 [ 251ULL ] = ( int32_T ) ( X [ 439ULL ] >= 0.5 ) ; t181 [ 252ULL ] =
( int32_T ) ( X [ 439ULL ] <= 500.0 ) ; t181 [ 253ULL ] = ( int32_T ) ( X [
438ULL ] >= 273.16 ) ; t181 [ 254ULL ] = ( int32_T ) ( X [ 438ULL ] <= 363.16
) ; t181 [ 255ULL ] = ( int32_T ) ( X [ 429ULL ] >= 273.16 ) ; t181 [ 256ULL
] = ( int32_T ) ( X [ 429ULL ] <= 363.16 ) ; t181 [ 257ULL ] = ( int32_T ) (
X [ 58ULL ] >= 0.5 ) ; t181 [ 258ULL ] = ( int32_T ) ( X [ 58ULL ] <= 500.0 )
; t181 [ 259ULL ] = ( int32_T ) ( X [ 248ULL ] * t283 / ( X [ 249ULL ] == 0.0
? 1.0E-16 : X [ 249ULL ] ) >= 0.0 ) ; t181 [ 260ULL ] = ( int32_T ) ( X [
59ULL ] >= 273.16 ) ; t181 [ 261ULL ] = ( int32_T ) ( X [ 59ULL ] <= 363.16 )
; t181 [ 262ULL ] = ( int32_T ) ( X [ 451ULL ] >= 0.5 ) ; t181 [ 263ULL ] = (
int32_T ) ( X [ 451ULL ] <= 500.0 ) ; t181 [ 264ULL ] = ( int32_T ) ( X [
450ULL ] >= 273.16 ) ; t181 [ 265ULL ] = ( int32_T ) ( X [ 450ULL ] <= 363.16
) ; t181 [ 266ULL ] = ( int32_T ) ( X [ 60ULL ] >= 0.5 ) ; t181 [ 267ULL ] =
( int32_T ) ( X [ 60ULL ] <= 500.0 ) ; t181 [ 268ULL ] = ( int32_T ) ( X [
61ULL ] >= 273.16 ) ; t181 [ 269ULL ] = ( int32_T ) ( X [ 61ULL ] <= 363.16 )
; t181 [ 270ULL ] = ( int32_T ) ( X [ 25ULL ] * t283 / ( X [ 31ULL ] == 0.0 ?
1.0E-16 : X [ 31ULL ] ) >= 0.0 ) ; t181 [ 271ULL ] = ( int32_T ) ( X [ 62ULL
] > 0.0 ) ; t181 [ 272ULL ] = ( int32_T ) ( X [ 64ULL ] >= 0.01 ) ; t181 [
273ULL ] = ( int32_T ) ( X [ 64ULL ] <= pmf_get_inf ( ) ) ; t181 [ 274ULL ] =
( int32_T ) ( X [ 63ULL ] >= 216.59999999999997 ) ; t181 [ 275ULL ] = (
int32_T ) ( X [ 63ULL ] <= 623.15 ) ; t181 [ 276ULL ] = ( int32_T ) ( t255 >=
0.01 ) ; t181 [ 277ULL ] = ( int32_T ) ( t255 <= pmf_get_inf ( ) ) ; t181 [
278ULL ] = ( int32_T ) ( X [ 484ULL ] >= 216.59999999999997 ) ; t181 [ 279ULL
] = ( int32_T ) ( X [ 484ULL ] <= 623.15 ) ; t181 [ 280ULL ] = ( int32_T ) (
X [ 466ULL ] >= 216.59999999999997 ) ; t181 [ 281ULL ] = ( int32_T ) ( X [
466ULL ] <= 623.15 ) ; t181 [ 282ULL ] = ( int32_T ) ( X [ 68ULL ] >= 0.01 )
; t181 [ 283ULL ] = ( int32_T ) ( X [ 68ULL ] <= pmf_get_inf ( ) ) ; t181 [
284ULL ] = ( int32_T ) ( X [ 67ULL ] >= 216.59999999999997 ) ; t181 [ 285ULL
] = ( int32_T ) ( X [ 67ULL ] <= 623.15 ) ; t181 [ 286ULL ] = ( int32_T ) ( X
[ 469ULL ] >= 216.59999999999997 ) ; t181 [ 287ULL ] = ( int32_T ) ( X [
469ULL ] <= 623.15 ) ; t181 [ 288ULL ] = ( int32_T ) ( X [ 32ULL ] > 0.0 ) ;
t181 [ 289ULL ] = ( int32_T ) ( ( 1.0 - X [ 524ULL ] ) - X [ 525ULL ] >= 0.0
) ; t181 [ 290ULL ] = ( int32_T ) ( X [ 513ULL ] >= 216.59999999999997 ) ;
t181 [ 291ULL ] = ( int32_T ) ( X [ 513ULL ] <= 623.15 ) ; t181 [ 292ULL ] =
( int32_T ) ( X [ 527ULL ] >= 216.59999999999997 ) ; t181 [ 293ULL ] = (
int32_T ) ( X [ 527ULL ] <= 623.15 ) ; t181 [ 294ULL ] = ( int32_T ) ( X [
71ULL ] >= 216.59999999999997 ) ; t181 [ 295ULL ] = ( int32_T ) ( X [ 71ULL ]
<= 623.15 ) ; t181 [ 296ULL ] = ( int32_T ) ( X [ 74ULL ] >=
216.59999999999997 ) ; t181 [ 297ULL ] = ( int32_T ) ( X [ 74ULL ] <= 623.15
) ; t181 [ 298ULL ] = ( int32_T ) ( X [ 553ULL ] >= 216.59999999999997 ) ;
t181 [ 299ULL ] = ( int32_T ) ( X [ 553ULL ] <= 623.15 ) ; t181 [ 300ULL ] =
( int32_T ) ( X [ 5ULL ] > 0.0 ) ; t181 [ 301ULL ] = ( int32_T ) ( X [ 263ULL
] * t289 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >=
0.0 ) ; t181 [ 302ULL ] = ( int32_T ) ( X [ 89ULL ] > 0.0 ) ; t181 [ 303ULL ]
= ( int32_T ) ( X [ 265ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 >= 0.0 ) ;
t181 [ 304ULL ] = ( int32_T ) ( X [ 162ULL ] >= 0.0 ) ; t181 [ 305ULL ] = (
int32_T ) ( X [ 264ULL ] * X [ 264ULL ] * t289 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ) /
( X [ 263ULL ] == 0.0 ? 1.0E-16 : X [ 263ULL ] ) >= 0.0 ) ; t181 [ 306ULL ] =
( int32_T ) ( X [ 266ULL ] * X [ 266ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_Pi85 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 ) /
( X [ 265ULL ] == 0.0 ? 1.0E-16 : X [ 265ULL ] ) >= 0.0 ) ; t181 [ 307ULL ] =
( int32_T ) ( X [ 263ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / ( X [ 264ULL
] == 0.0 ? 1.0E-16 : X [ 264ULL ] ) >= 0.0 ) ; t181 [ 308ULL ] = ( int32_T )
( X [ 265ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / ( X [ 266ULL
] == 0.0 ? 1.0E-16 : X [ 266ULL ] ) >= 0.0 ) ; t181 [ 309ULL ] = ( int32_T )
( X [ 28ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va9 / ( X [ 33ULL
] == 0.0 ? 1.0E-16 : X [ 33ULL ] ) >= 0.0 ) ; t181 [ 310ULL ] = ( int32_T ) (
U_idx_6 <= 216.59999999999997 ) ; t181 [ 311ULL ] = ( int32_T ) ( U_idx_6 >=
623.15 ) ; t181 [ 312ULL ] = ( int32_T ) ( X [ 289ULL ] * t225 * t222 >= 0.0
) ; t181 [ 313ULL ] = ( int32_T ) ( X [ 161ULL ] >= 0.0 ) ; t181 [ 314ULL ] =
( int32_T ) ( X [ 291ULL ] * intrm_sf_mf_543 * t222 >= 0.0 ) ; t181 [ 315ULL
] = ( int32_T ) ( X [ 290ULL ] * X [ 290ULL ] * t225 / ( t222 == 0.0 ?
1.0E-16 : t222 ) / ( X [ 289ULL ] == 0.0 ? 1.0E-16 : X [ 289ULL ] ) >= 0.0 )
; t181 [ 316ULL ] = ( int32_T ) ( X [ 292ULL ] * X [ 292ULL ] *
intrm_sf_mf_543 / ( t222 == 0.0 ? 1.0E-16 : t222 ) / ( X [ 291ULL ] == 0.0 ?
1.0E-16 : X [ 291ULL ] ) >= 0.0 ) ; t181 [ 317ULL ] = ( int32_T ) ( X [
289ULL ] * t222 / ( X [ 290ULL ] == 0.0 ? 1.0E-16 : X [ 290ULL ] ) >= 0.0 ) ;
t181 [ 318ULL ] = ( int32_T ) ( X [ 291ULL ] * t222 / ( X [ 292ULL ] == 0.0 ?
1.0E-16 : X [ 292ULL ] ) >= 0.0 ) ; t181 [ 319ULL ] = ( int32_T ) ( X [ 34ULL
] * t222 / ( X [ 37ULL ] == 0.0 ? 1.0E-16 : X [ 37ULL ] ) >= 0.0 ) ; t181 [
320ULL ] = ( int32_T ) ( X [ 307ULL ] * U_idx_13 / 1.01325 >= 0.0 ) ; t181 [
321ULL ] = ( int32_T ) ( t295 * 293.15 / 1.01325 >= 0.0 ) ; t181 [ 322ULL ] =
( int32_T ) ( X [ 302ULL ] * t240 / ( X [ 303ULL ] == 0.0 ? 1.0E-16 : X [
303ULL ] ) >= 0.0 ) ; t181 [ 323ULL ] = ( int32_T ) ( X [ 321ULL ] * t298 / (
t228 == 0.0 ? 1.0E-16 : t228 ) >= 0.0 ) ; t181 [ 324ULL ] = ( int32_T ) ( X [
163ULL ] >= 0.0 ) ; t181 [ 325ULL ] = ( int32_T ) ( X [ 326ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 *
intrm_sf_mf_694 >= 0.0 ) ; t181 [ 326ULL ] = ( int32_T ) ( X [ 330ULL ] *
t237 * intrm_sf_mf_694 >= 0.0 ) ; t181 [ 327ULL ] = ( int32_T ) ( X [ 327ULL
] * X [ 327ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M27 / (
intrm_sf_mf_694 == 0.0 ? 1.0E-16 : intrm_sf_mf_694 ) / ( X [ 326ULL ] == 0.0
? 1.0E-16 : X [ 326ULL ] ) >= 0.0 ) ; t181 [ 328ULL ] = ( int32_T ) ( X [
331ULL ] * X [ 331ULL ] * t237 / ( intrm_sf_mf_694 == 0.0 ? 1.0E-16 :
intrm_sf_mf_694 ) / ( X [ 330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) >= 0.0 )
; t181 [ 329ULL ] = ( int32_T ) ( X [ 326ULL ] * intrm_sf_mf_694 / ( X [
327ULL ] == 0.0 ? 1.0E-16 : X [ 327ULL ] ) >= 0.0 ) ; t181 [ 330ULL ] = (
int32_T ) ( X [ 330ULL ] * intrm_sf_mf_694 / ( X [ 331ULL ] == 0.0 ? 1.0E-16
: X [ 331ULL ] ) >= 0.0 ) ; t181 [ 331ULL ] = ( int32_T ) ( X [ 39ULL ] *
intrm_sf_mf_694 / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ] ) >= 0.0 ) ;
t181 [ 332ULL ] = ( int32_T ) ( X [ 344ULL ] / ( t301 == 0.0 ? 1.0E-16 : t301
) * 2.0 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu9 ) >= 0.0 ) ;
t181 [ 333ULL ] = ( int32_T ) ( ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] * -
1.0000000000000011 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ] > X [ 171ULL ]
+ 0.8 ) ; t181 [ 334ULL ] = ( int32_T ) ( X [ 344ULL ] * X [ 344ULL ] * t297
/ ( intrm_sf_mf_838 == 0.0 ? 1.0E-16 : intrm_sf_mf_838 ) / ( X [ 343ULL ] ==
0.0 ? 1.0E-16 : X [ 343ULL ] ) >= 0.0 ) ; t181 [ 335ULL ] = ( int32_T ) ( X [
347ULL ] * intrm_sf_mf_838 / ( t228 == 0.0 ? 1.0E-16 : t228 ) >= 0.0 ) ; t181
[ 336ULL ] = ( int32_T ) ( X [ 348ULL ] * intrm_sf_mf_838 / 1.01325 >= 0.0 )
; t181 [ 337ULL ] = ( int32_T ) ( t301 / ( X [ 344ULL ] == 0.0 ? 1.0E-16 : X
[ 344ULL ] ) >= 0.0 ) ; t181 [ 338ULL ] = ( int32_T ) ( X [ 364ULL ] *
intrm_sf_mf_904 / ( X [ 365ULL ] == 0.0 ? 1.0E-16 : X [ 365ULL ] ) >= 0.0 ) ;
t181 [ 339ULL ] = ( int32_T ) ( X [ 350ULL ] * intrm_sf_mf_934 / ( X [ 351ULL
] == 0.0 ? 1.0E-16 : X [ 351ULL ] ) >= 0.0 ) ; t181 [ 340ULL ] = ( int32_T )
( X [ 369ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 * t303 >= 0.0
) ; t181 [ 341ULL ] = ( int32_T ) ( X [ 372ULL ] * t299 * t303 >= 0.0 ) ;
t181 [ 342ULL ] = ( int32_T ) ( X [ 370ULL ] * X [ 370ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_27 / ( t303 ==
0.0 ? 1.0E-16 : t303 ) / ( X [ 369ULL ] == 0.0 ? 1.0E-16 : X [ 369ULL ] ) >=
0.0 ) ; t181 [ 343ULL ] = ( int32_T ) ( X [ 373ULL ] * X [ 373ULL ] * t299 /
( t303 == 0.0 ? 1.0E-16 : t303 ) / ( X [ 372ULL ] == 0.0 ? 1.0E-16 : X [
372ULL ] ) >= 0.0 ) ; t181 [ 344ULL ] = ( int32_T ) (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Environme5 == 1.0 ) ;
t181 [ 345ULL ] = ( int32_T ) ( X [ 369ULL ] * t303 / ( X [ 370ULL ] == 0.0 ?
1.0E-16 : X [ 370ULL ] ) >= 0.0 ) ; t181 [ 346ULL ] = ( int32_T ) ( X [
372ULL ] * t303 / ( X [ 373ULL ] == 0.0 ? 1.0E-16 : X [ 373ULL ] ) >= 0.0 ) ;
t181 [ 347ULL ] = ( int32_T ) ( X [ 43ULL ] * t303 / ( X [ 49ULL ] == 0.0 ?
1.0E-16 : X [ 49ULL ] ) >= 0.0 ) ; t181 [ 348ULL ] = ( int32_T ) ( X [ 387ULL
] * t309 * intrm_sf_mf_1006 >= 0.0 ) ; t181 [ 349ULL ] = ( int32_T ) ( X [
389ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 *
intrm_sf_mf_1006 >= 0.0 ) ; t181 [ 350ULL ] = ( int32_T ) ( X [ 388ULL ] * X
[ 388ULL ] * t309 / ( intrm_sf_mf_1006 == 0.0 ? 1.0E-16 : intrm_sf_mf_1006 )
/ ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X [ 387ULL ] ) >= 0.0 ) ; t181 [ 351ULL ]
= ( int32_T ) ( X [ 390ULL ] * X [ 390ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_85 / (
intrm_sf_mf_1006 == 0.0 ? 1.0E-16 : intrm_sf_mf_1006 ) / ( X [ 389ULL ] ==
0.0 ? 1.0E-16 : X [ 389ULL ] ) >= 0.0 ) ; t181 [ 352ULL ] = ( int32_T ) ( X [
387ULL ] * intrm_sf_mf_1006 / ( X [ 388ULL ] == 0.0 ? 1.0E-16 : X [ 388ULL ]
) >= 0.0 ) ; t181 [ 353ULL ] = ( int32_T ) ( X [ 389ULL ] * intrm_sf_mf_1006
/ ( X [ 390ULL ] == 0.0 ? 1.0E-16 : X [ 390ULL ] ) >= 0.0 ) ; t181 [ 354ULL ]
= ( int32_T ) ( X [ 46ULL ] * intrm_sf_mf_1006 / ( X [ 50ULL ] == 0.0 ?
1.0E-16 : X [ 50ULL ] ) >= 0.0 ) ; t181 [ 355ULL ] = ( int32_T ) ( U_idx_9 <=
216.59999999999997 ) ; t181 [ 356ULL ] = ( int32_T ) ( U_idx_9 >= 623.15 ) ;
t181 [ 357ULL ] = ( int32_T ) ( X [ 414ULL ] * t252 * t311 >= 0.0 ) ; t181 [
358ULL ] = ( int32_T ) ( X [ 416ULL ] * intrm_sf_mf_1142 * t311 >= 0.0 ) ;
t181 [ 359ULL ] = ( int32_T ) ( X [ 415ULL ] * X [ 415ULL ] * t252 / ( t311
== 0.0 ? 1.0E-16 : t311 ) / ( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [ 414ULL ] )
>= 0.0 ) ; t181 [ 360ULL ] = ( int32_T ) ( X [ 417ULL ] * X [ 417ULL ] *
intrm_sf_mf_1142 / ( t311 == 0.0 ? 1.0E-16 : t311 ) / ( X [ 416ULL ] == 0.0 ?
1.0E-16 : X [ 416ULL ] ) >= 0.0 ) ; for ( b = 0 ; b < 361 ; b ++ ) { out . mX
[ b ] = t181 [ b ] ; } ( void ) LC ; ( void ) t520 ; return 0 ; }
