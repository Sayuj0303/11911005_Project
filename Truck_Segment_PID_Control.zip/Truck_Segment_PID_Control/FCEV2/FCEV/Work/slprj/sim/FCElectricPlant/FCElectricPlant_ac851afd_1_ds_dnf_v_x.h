#ifdef __cplusplus
extern "C" {
#endif
#ifndef FCELECTRICPLANT_AC851AFD_1_DS_DNF_V_X_H
#define FCELECTRICPLANT_AC851AFD_1_DS_DNF_V_X_H 1
int32_T FCElectricPlant_ac851afd_1_ds_dnf_v_x ( const NeDynamicSystem * sys ,
const NeDynamicSystemInput * Q , NeDsMethodOutput * M ) ;
#endif
#ifdef __cplusplus
}
#endif
