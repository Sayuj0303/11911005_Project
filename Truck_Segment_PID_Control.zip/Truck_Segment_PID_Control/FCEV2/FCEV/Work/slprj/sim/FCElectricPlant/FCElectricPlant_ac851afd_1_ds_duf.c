#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_duf.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_duf ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t1970 , NeDsMethodOutput * t1971 ) { ETTS0
ab_efOut ; ETTS0 ad_efOut ; ETTS0 b_efOut ; ETTS0 bb_efOut ; ETTS0 bc_efOut ;
ETTS0 bf_efOut ; ETTS0 cd_efOut ; ETTS0 ch_efOut ; ETTS0 d_efOut ; ETTS0
db_efOut ; ETTS0 dc_efOut ; ETTS0 df_efOut ; ETTS0 dg_efOut ; ETTS0 efOut ;
ETTS0 f_efOut ; ETTS0 fb_efOut ; ETTS0 fc_efOut ; ETTS0 ff_efOut ; ETTS0
g_efOut ; ETTS0 gb_efOut ; ETTS0 gd_efOut ; ETTS0 gf_efOut ; ETTS0 gh_efOut ;
ETTS0 hg_efOut ; ETTS0 i_efOut ; ETTS0 ic_efOut ; ETTS0 if_efOut ; ETTS0
jc_efOut ; ETTS0 k_efOut ; ETTS0 kb_efOut ; ETTS0 kf_efOut ; ETTS0 kh_efOut ;
ETTS0 l_efOut ; ETTS0 ld_efOut ; ETTS0 le_efOut ; ETTS0 lf_efOut ; ETTS0
lg_efOut ; ETTS0 mb_efOut ; ETTS0 mh_efOut ; ETTS0 n_efOut ; ETTS0 nb_efOut ;
ETTS0 nc_efOut ; ETTS0 nf_efOut ; ETTS0 p_efOut ; ETTS0 pb_efOut ; ETTS0
pc_efOut ; ETTS0 pe_efOut ; ETTS0 pf_efOut ; ETTS0 pg_efOut ; ETTS0 q_efOut ;
ETTS0 qh_efOut ; ETTS0 rb_efOut ; ETTS0 rc_efOut ; ETTS0 rh_efOut ; ETTS0
s_efOut ; ETTS0 t32 ; ETTS0 t49 ; ETTS0 t50 ; ETTS0 t52 ; ETTS0 t55 ; ETTS0
t58 ; ETTS0 t60 ; ETTS0 t61 ; ETTS0 t64 ; ETTS0 t68 ; ETTS0 te_efOut ; ETTS0
tf_efOut ; ETTS0 tg_efOut ; ETTS0 u_efOut ; ETTS0 uc_efOut ; ETTS0 v_efOut ;
ETTS0 vb_efOut ; ETTS0 vc_efOut ; ETTS0 vf_efOut ; ETTS0 wb_efOut ; ETTS0
wf_efOut ; ETTS0 x_efOut ; ETTS0 xc_efOut ; ETTS0 xe_efOut ; ETTS0 xg_efOut ;
ETTS0 yd_efOut ; ETTS0 ye_efOut ; PmRealVector out ; real_T X [ 582 ] ;
real_T t589 [ 116 ] ; real_T t711 [ 44 ] ; real_T t713 [ 29 ] ; real_T t717 [
11 ] ; real_T t715 [ 6 ] ; real_T t718 [ 6 ] ; real_T t714 [ 5 ] ; real_T
t716 [ 5 ] ; real_T nonscalar64 [ 3 ] ; real_T ac_efOut [ 1 ] ; real_T
ae_efOut [ 1 ] ; real_T af_efOut [ 1 ] ; real_T ag_efOut [ 1 ] ; real_T
ah_efOut [ 1 ] ; real_T bd_efOut [ 1 ] ; real_T be_efOut [ 1 ] ; real_T
bg_efOut [ 1 ] ; real_T bh_efOut [ 1 ] ; real_T c_efOut [ 1 ] ; real_T
cb_efOut [ 1 ] ; real_T cc_efOut [ 1 ] ; real_T ce_efOut [ 1 ] ; real_T
cf_efOut [ 1 ] ; real_T cg_efOut [ 1 ] ; real_T dd_efOut [ 1 ] ; real_T
de_efOut [ 1 ] ; real_T dh_efOut [ 1 ] ; real_T e_efOut [ 1 ] ; real_T
eb_efOut [ 1 ] ; real_T ec_efOut [ 1 ] ; real_T ed_efOut [ 1 ] ; real_T
ee_efOut [ 1 ] ; real_T ef_efOut [ 1 ] ; real_T eg_efOut [ 1 ] ; real_T
eh_efOut [ 1 ] ; real_T fd_efOut [ 1 ] ; real_T fe_efOut [ 1 ] ; real_T
fg_efOut [ 1 ] ; real_T fh_efOut [ 1 ] ; real_T gc_efOut [ 1 ] ; real_T
ge_efOut [ 1 ] ; real_T gg_efOut [ 1 ] ; real_T h_efOut [ 1 ] ; real_T
hb_efOut [ 1 ] ; real_T hc_efOut [ 1 ] ; real_T hd_efOut [ 1 ] ; real_T
he_efOut [ 1 ] ; real_T hf_efOut [ 1 ] ; real_T hh_efOut [ 1 ] ; real_T
ib_efOut [ 1 ] ; real_T id_efOut [ 1 ] ; real_T ie_efOut [ 1 ] ; real_T
ig_efOut [ 1 ] ; real_T ih_efOut [ 1 ] ; real_T j_efOut [ 1 ] ; real_T
jb_efOut [ 1 ] ; real_T jd_efOut [ 1 ] ; real_T je_efOut [ 1 ] ; real_T
jf_efOut [ 1 ] ; real_T jg_efOut [ 1 ] ; real_T jh_efOut [ 1 ] ; real_T
kc_efOut [ 1 ] ; real_T kd_efOut [ 1 ] ; real_T ke_efOut [ 1 ] ; real_T
kg_efOut [ 1 ] ; real_T lb_efOut [ 1 ] ; real_T lc_efOut [ 1 ] ; real_T
lh_efOut [ 1 ] ; real_T m_efOut [ 1 ] ; real_T mc_efOut [ 1 ] ; real_T
md_efOut [ 1 ] ; real_T me_efOut [ 1 ] ; real_T mf_efOut [ 1 ] ; real_T
mg_efOut [ 1 ] ; real_T nd_efOut [ 1 ] ; real_T ne_efOut [ 1 ] ; real_T
ng_efOut [ 1 ] ; real_T nh_efOut [ 1 ] ; real_T o_efOut [ 1 ] ; real_T
ob_efOut [ 1 ] ; real_T oc_efOut [ 1 ] ; real_T od_efOut [ 1 ] ; real_T
oe_efOut [ 1 ] ; real_T of_efOut [ 1 ] ; real_T og_efOut [ 1 ] ; real_T
oh_efOut [ 1 ] ; real_T pd_efOut [ 1 ] ; real_T ph_efOut [ 1 ] ; real_T
qb_efOut [ 1 ] ; real_T qc_efOut [ 1 ] ; real_T qd_efOut [ 1 ] ; real_T
qe_efOut [ 1 ] ; real_T qf_efOut [ 1 ] ; real_T qg_efOut [ 1 ] ; real_T
r_efOut [ 1 ] ; real_T rd_efOut [ 1 ] ; real_T re_efOut [ 1 ] ; real_T
rf_efOut [ 1 ] ; real_T rg_efOut [ 1 ] ; real_T sb_efOut [ 1 ] ; real_T
sc_efOut [ 1 ] ; real_T sd_efOut [ 1 ] ; real_T se_efOut [ 1 ] ; real_T
sf_efOut [ 1 ] ; real_T sg_efOut [ 1 ] ; real_T sh_efOut [ 1 ] ; real_T t719
[ 1 ] ; real_T t_efOut [ 1 ] ; real_T tb_efOut [ 1 ] ; real_T tc_efOut [ 1 ]
; real_T td_efOut [ 1 ] ; real_T ub_efOut [ 1 ] ; real_T ud_efOut [ 1 ] ;
real_T ue_efOut [ 1 ] ; real_T uf_efOut [ 1 ] ; real_T ug_efOut [ 1 ] ;
real_T vd_efOut [ 1 ] ; real_T ve_efOut [ 1 ] ; real_T vg_efOut [ 1 ] ;
real_T w_efOut [ 1 ] ; real_T wc_efOut [ 1 ] ; real_T wd_efOut [ 1 ] ; real_T
we_efOut [ 1 ] ; real_T wg_efOut [ 1 ] ; real_T xb_efOut [ 1 ] ; real_T
xd_efOut [ 1 ] ; real_T xf_efOut [ 1 ] ; real_T y_efOut [ 1 ] ; real_T
yb_efOut [ 1 ] ; real_T yc_efOut [ 1 ] ; real_T yf_efOut [ 1 ] ; real_T
yg_efOut [ 1 ] ; real_T
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 ; real_T
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I ; real_T
Electrical_Cooling_System_Pump_convection_A_u_in ; real_T
Fuel_Cell_Boost_Converter_L_i ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant6 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co3 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co8 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_rho_ ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato9 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T8 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 ; real_T
U_idx_0 ; real_T U_idx_1 ; real_T U_idx_10 ; real_T U_idx_11 ; real_T
U_idx_12 ; real_T U_idx_13 ; real_T U_idx_2 ; real_T U_idx_3 ; real_T U_idx_4
; real_T U_idx_5 ; real_T U_idx_6 ; real_T U_idx_7 ; real_T U_idx_8 ; real_T
U_idx_9 ; real_T intermediate_der0 ; real_T intermediate_der10249 ; real_T
intermediate_der10338 ; real_T intermediate_der10838 ; real_T
intermediate_der11334 ; real_T intermediate_der11472 ; real_T
intermediate_der1148 ; real_T intermediate_der11512 ; real_T
intermediate_der11539 ; real_T intermediate_der11637 ; real_T
intermediate_der11712 ; real_T intermediate_der1227 ; real_T
intermediate_der1258 ; real_T intermediate_der149 ; real_T
intermediate_der197 ; real_T intermediate_der239 ; real_T intermediate_der242
; real_T intermediate_der349 ; real_T intermediate_der358 ; real_T
intermediate_der3714 ; real_T intermediate_der3747 ; real_T
intermediate_der509 ; real_T intermediate_der539 ; real_T
intermediate_der5449 ; real_T intermediate_der5453 ; real_T
intermediate_der5455 ; real_T intermediate_der546 ; real_T
intermediate_der553 ; real_T intermediate_der5547 ; real_T
intermediate_der5551 ; real_T intermediate_der5554 ; real_T
intermediate_der5591 ; real_T intermediate_der5594 ; real_T
intermediate_der5597 ; real_T intermediate_der5598 ; real_T
intermediate_der7296 ; real_T intermediate_der7331 ; real_T
intermediate_der8034 ; real_T intermediate_der8213 ; real_T
intermediate_der8325 ; real_T intermediate_der8351 ; real_T
intermediate_der8470 ; real_T intermediate_der8507 ; real_T
intermediate_der8886 ; real_T intermediate_der8955 ; real_T
intermediate_der9401 ; real_T intermediate_der9543 ; real_T
intermediate_der9757 ; real_T intrm_sf_mf_10 ; real_T intrm_sf_mf_11 ; real_T
intrm_sf_mf_1142 ; real_T intrm_sf_mf_1324 ; real_T intrm_sf_mf_1332 ; real_T
intrm_sf_mf_1336 ; real_T intrm_sf_mf_1337 ; real_T intrm_sf_mf_1348 ; real_T
intrm_sf_mf_1433 ; real_T intrm_sf_mf_1544 ; real_T intrm_sf_mf_32 ; real_T
intrm_sf_mf_41 ; real_T intrm_sf_mf_52 ; real_T intrm_sf_mf_545 ; real_T
intrm_sf_mf_56 ; real_T intrm_sf_mf_839 ; real_T intrm_sf_mf_864 ; real_T
intrm_sf_mf_9 ; real_T intrm_sf_mf_95 ; real_T t1000 ; real_T t1002 ; real_T
t1003 ; real_T t1004 ; real_T t1005 ; real_T t1006 ; real_T t1007 ; real_T
t1008 ; real_T t1009 ; real_T t1011 ; real_T t1012 ; real_T t1013 ; real_T
t1014 ; real_T t1015 ; real_T t1016 ; real_T t1017 ; real_T t1018 ; real_T
t1019 ; real_T t1021 ; real_T t1022 ; real_T t1023 ; real_T t1024 ; real_T
t1025 ; real_T t1026 ; real_T t1027 ; real_T t1028 ; real_T t1029 ; real_T
t1030 ; real_T t1031 ; real_T t1033 ; real_T t1034 ; real_T t1036 ; real_T
t1037 ; real_T t1039 ; real_T t1041 ; real_T t1043 ; real_T t1044 ; real_T
t1047 ; real_T t1049 ; real_T t1051 ; real_T t1052 ; real_T t1053 ; real_T
t1054 ; real_T t1055 ; real_T t1056 ; real_T t1057 ; real_T t1058 ; real_T
t1060 ; real_T t1062 ; real_T t1063 ; real_T t1066 ; real_T t1067 ; real_T
t1069 ; real_T t1072 ; real_T t1074 ; real_T t1076 ; real_T t1078 ; real_T
t1079 ; real_T t1082 ; real_T t1083 ; real_T t1084 ; real_T t1085 ; real_T
t1088 ; real_T t1089 ; real_T t1092 ; real_T t1094 ; real_T t1096 ; real_T
t1097 ; real_T t1099 ; real_T t1100 ; real_T t1101 ; real_T t1102 ; real_T
t1103 ; real_T t1106 ; real_T t1110 ; real_T t1112 ; real_T t1114 ; real_T
t1118 ; real_T t1127 ; real_T t1144 ; real_T t1150 ; real_T t1164 ; real_T
t1170 ; real_T t1173 ; real_T t1178 ; real_T t1282 ; real_T t1382 ; real_T
t1395 ; real_T t1423 ; real_T t1425 ; real_T t1426 ; real_T t1430 ; real_T
t1431 ; real_T t1432 ; real_T t1433 ; real_T t1434 ; real_T t1435 ; real_T
t1436 ; real_T t1437 ; real_T t1456 ; real_T t1464 ; real_T t1473 ; real_T
t1487 ; real_T t1502 ; real_T t1513 ; real_T t1519 ; real_T t1553 ; real_T
t1581 ; real_T t1645 ; real_T t1681 ; real_T t1694 ; real_T t1713 ; real_T
t1723 ; real_T t1757 ; real_T t1793 ; real_T t1794 ; real_T t1804 ; real_T
t1822 ; real_T t1830 ; real_T t1862 ; real_T t1901 ; real_T t1902 ; real_T
t1903 ; real_T t1904 ; real_T t1908 ; real_T t1922 ; real_T t1936 ; real_T
t706_idx_0 ; real_T t710_idx_0 ; real_T t73 ; real_T t775 ; real_T t778 ;
real_T t784 ; real_T t787 ; real_T t790 ; real_T t791 ; real_T t797 ; real_T
t798 ; real_T t799 ; real_T t800 ; real_T t802 ; real_T t805 ; real_T t806 ;
real_T t808 ; real_T t811 ; real_T t814 ; real_T t815 ; real_T t817 ; real_T
t818 ; real_T t820 ; real_T t821 ; real_T t822 ; real_T t823 ; real_T t826 ;
real_T t827 ; real_T t830 ; real_T t832 ; real_T t839 ; real_T t841 ; real_T
t842 ; real_T t844 ; real_T t845 ; real_T t847 ; real_T t848 ; real_T t849 ;
real_T t850 ; real_T t851 ; real_T t852 ; real_T t853 ; real_T t855 ; real_T
t856 ; real_T t857 ; real_T t860 ; real_T t866 ; real_T t869 ; real_T t870 ;
real_T t871 ; real_T t872 ; real_T t873 ; real_T t874 ; real_T t885 ; real_T
t887 ; real_T t890 ; real_T t891 ; real_T t893 ; real_T t894 ; real_T t895 ;
real_T t896 ; real_T t899 ; real_T t907 ; real_T t910 ; real_T t911 ; real_T
t912 ; real_T t914 ; real_T t917 ; real_T t920 ; real_T t921 ; real_T t923 ;
real_T t924 ; real_T t926 ; real_T t927 ; real_T t928 ; real_T t929 ; real_T
t930 ; real_T t931 ; real_T t932 ; real_T t933 ; real_T t935 ; real_T t936 ;
real_T t941 ; real_T t943 ; real_T t944 ; real_T t945 ; real_T t946 ; real_T
t947 ; real_T t948 ; real_T t950 ; real_T t951 ; real_T t952 ; real_T t953 ;
real_T t954 ; real_T t955 ; real_T t959 ; real_T t960 ; real_T t961 ; real_T
t962 ; real_T t964 ; real_T t965 ; real_T t967 ; real_T t968 ; real_T t971 ;
real_T t972 ; real_T t973 ; real_T t974 ; real_T t975 ; real_T t976 ; real_T
t978 ; real_T t979 ; real_T t984 ; real_T t985 ; real_T t986 ; real_T t987 ;
real_T t988 ; real_T t989 ; real_T t991 ; real_T t992 ; real_T t993 ; real_T
t994 ; real_T t995 ; real_T t996 ; real_T t998 ; real_T t999 ; real_T
zc_int10 ; real_T zc_int116 ; real_T zc_int17 ; real_T zc_int174 ; real_T
zc_int179 ; real_T zc_int180 ; real_T zc_int184 ; real_T zc_int186 ; real_T
zc_int321 ; real_T zc_int322 ; real_T zc_int341 ; real_T zc_int360 ; real_T
zc_int364 ; real_T zc_int365 ; real_T zc_int366 ; real_T zc_int367 ; real_T
zc_int42 ; real_T zc_int43 ; size_t t408 [ 1 ] ; size_t t581 [ 1 ] ; size_t
t584 [ 1 ] ; size_t t76 [ 1 ] ; size_t t727 ; int32_T M [ 361 ] ; int32_T b ;
for ( b = 0 ; b < 361 ; b ++ ) { M [ b ] = t1970 -> mM . mX [ b ] ; } U_idx_0
= t1970 -> mU . mX [ 0 ] ; U_idx_1 = t1970 -> mU . mX [ 1 ] ; U_idx_2 = t1970
-> mU . mX [ 2 ] ; U_idx_3 = t1970 -> mU . mX [ 3 ] ; U_idx_4 = t1970 -> mU .
mX [ 4 ] ; U_idx_5 = t1970 -> mU . mX [ 5 ] ; U_idx_6 = t1970 -> mU . mX [ 6
] ; U_idx_7 = t1970 -> mU . mX [ 7 ] ; U_idx_8 = t1970 -> mU . mX [ 8 ] ;
U_idx_9 = t1970 -> mU . mX [ 9 ] ; U_idx_10 = t1970 -> mU . mX [ 10 ] ;
U_idx_11 = t1970 -> mU . mX [ 11 ] ; U_idx_12 = t1970 -> mU . mX [ 12 ] ;
U_idx_13 = t1970 -> mU . mX [ 13 ] ; for ( b = 0 ; b < 582 ; b ++ ) { X [ b ]
= t1970 -> mX . mX [ b ] ; } out = t1971 -> mDUF ; t714 [ 0 ] = 1.0 ; t714 [
1 ] = 1.25 ; t714 [ 2 ] = 1.5 ; t714 [ 3 ] = 1.75 ; t714 [ 4 ] = 2.0 ;
nonscalar64 [ 0 ] = 0.0 ; nonscalar64 [ 1 ] = 188.49555921538757 ;
nonscalar64 [ 2 ] = 376.99111843077515 ; t791 = - X [ 79ULL ] - U_idx_1 ; t73
= ( ( ( real_T ) ( t791 >= 0.0 ) * t791 * 1000.0 + ( real_T ) ( t791 < 0.0 )
* X [ 81ULL ] ) - 0.9 ) / 0.099999999999999978 ; t1922 = pmf_sqrt ( U_idx_2 *
U_idx_2 + 4.5311819630628225E-12 ) ; t719 [ 0ULL ] = X [ 97ULL ] ; t581 [ 0 ]
= 20ULL ; t76 [ 0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut . mField0
[ 0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t68 = efOut ; t719 [ 0ULL ] = X [ 93ULL ] ; t584 [ 0 ] =
19ULL ; tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , &
b_efOut . mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [ 0ULL ] , & t584 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t64 = b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut
[ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField1 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = c_efOut [ 0 ] ; t1936 = t710_idx_0 ; t719 [ 0ULL ] = X [ 92ULL ]
; tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = d_efOut ; tlu2_2d_linear_linear_value ( & e_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t64 . mField0 [ 0ULL ] , &
t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = e_efOut [ 0
] ; t1862 = t710_idx_0 ; t719 [ 0ULL ] = X [ 99ULL ] ;
tlu2_linear_linear_prelookup ( & f_efOut . mField0 [ 0ULL ] , & f_efOut .
mField1 [ 0ULL ] , & f_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = f_efOut ; t719 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup (
& g_efOut . mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t61 = g_efOut ;
tlu2_2d_linear_linear_value ( & h_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] ,
& t68 . mField2 [ 0ULL ] , & t61 . mField0 [ 0ULL ] , & t61 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , & t584 [
0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = h_efOut [ 0 ] ; t1901 = t710_idx_0 ;
t719 [ 0ULL ] = X [ 94ULL ] ; tlu2_linear_linear_prelookup ( & i_efOut .
mField0 [ 0ULL ] , & i_efOut . mField1 [ 0ULL ] , & i_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [
0ULL ] , & t76 [ 0ULL ] ) ; t68 = i_efOut ; tlu2_2d_linear_linear_value ( &
j_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t61 . mField0 [ 0ULL ] , & t61 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = j_efOut [ 0 ] ; t1902 = t710_idx_0 ; t719 [ 0ULL ] = X [ 106ULL
] ; tlu2_linear_linear_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = k_efOut ; t719 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_linear_prelookup (
& l_efOut . mField0 [ 0ULL ] , & l_efOut . mField1 [ 0ULL ] , & l_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t52 = l_efOut ;
tlu2_2d_linear_linear_value ( & m_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] ,
& t68 . mField2 [ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , & t584 [
0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = m_efOut [ 0 ] ; t1903 = t710_idx_0 ;
t719 [ 0ULL ] = X [ 101ULL ] ; tlu2_linear_linear_prelookup ( & n_efOut .
mField0 [ 0ULL ] , & n_efOut . mField1 [ 0ULL ] , & n_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [
0ULL ] , & t76 [ 0ULL ] ) ; t60 = n_efOut ; tlu2_2d_linear_linear_value ( &
o_efOut [ 0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , &
t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = o_efOut [ 0 ] ; t1904 = t710_idx_0 ; t719 [ 0ULL ] = X [ 108ULL
] ; tlu2_linear_linear_prelookup ( & p_efOut . mField0 [ 0ULL ] , & p_efOut .
mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = p_efOut ; t719 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup (
& q_efOut . mField0 [ 0ULL ] , & q_efOut . mField1 [ 0ULL ] , & q_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t49 = q_efOut ;
tlu2_2d_linear_linear_value ( & r_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] ,
& t68 . mField2 [ 0ULL ] , & t49 . mField0 [ 0ULL ] , & t49 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , & t584 [
0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = r_efOut [ 0 ] ; t1908 = t710_idx_0 ;
t719 [ 0ULL ] = X [ 103ULL ] ; tlu2_linear_linear_prelookup ( & s_efOut .
mField0 [ 0ULL ] , & s_efOut . mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [
0ULL ] , & t76 [ 0ULL ] ) ; t68 = s_efOut ; tlu2_2d_linear_linear_value ( &
t_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t49 . mField0 [ 0ULL ] , & t49 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = t_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 = t710_idx_0
; t719 [ 0ULL ] = X [ 115ULL ] ; tlu2_linear_linear_prelookup ( & u_efOut .
mField0 [ 0ULL ] , & u_efOut . mField1 [ 0ULL ] , & u_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [
0ULL ] , & t76 [ 0ULL ] ) ; t60 = u_efOut ; t719 [ 0ULL ] = X [ 111ULL ] ;
tlu2_linear_linear_prelookup ( & v_efOut . mField0 [ 0ULL ] , & v_efOut .
mField1 [ 0ULL ] , & v_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = v_efOut ; tlu2_2d_linear_linear_value ( & w_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , & t55 . mField0 [ 0ULL ] , &
t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = w_efOut [ 0
] ; t1830 = t710_idx_0 ; t719 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_linear_prelookup ( & x_efOut . mField0 [ 0ULL ] , & x_efOut .
mField1 [ 0ULL ] , & x_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = x_efOut ; tlu2_2d_linear_linear_value ( & y_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , & t55 . mField0 [ 0ULL ] , &
t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = y_efOut [ 0
] ; Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 =
t710_idx_0 ; t719 [ 0ULL ] = X [ 117ULL ] ; tlu2_linear_linear_prelookup ( &
ab_efOut . mField0 [ 0ULL ] , & ab_efOut . mField1 [ 0ULL ] , & ab_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = ab_efOut ; t719 [ 0ULL ]
= X [ 113ULL ] ; tlu2_linear_linear_prelookup ( & bb_efOut . mField0 [ 0ULL ]
, & bb_efOut . mField1 [ 0ULL ] , & bb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [ 0ULL ] , & t584 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t60 = bb_efOut ; tlu2_2d_linear_linear_value ( &
cb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = cb_efOut [ 0 ] ; intermediate_der149 = t710_idx_0 ; t719 [ 0ULL
] = X [ 112ULL ] ; tlu2_linear_linear_prelookup ( & db_efOut . mField0 [ 0ULL
] , & db_efOut . mField1 [ 0ULL ] , & db_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t68 = db_efOut ; tlu2_2d_linear_linear_value ( &
eb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField4 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = eb_efOut [ 0 ] ;
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 = t710_idx_0
; intermediate_der197 = ( U_idx_2 - ( - U_idx_2 ) ) / 2.0 ; t797 =
intermediate_der197 >= 0.0 ? X [ 112ULL ] : X [ 119ULL ] ; t719 [ 0ULL ] = (
X [ 6ULL ] + t797 ) / 2.0 ; tlu2_linear_linear_prelookup ( & fb_efOut .
mField0 [ 0ULL ] , & fb_efOut . mField1 [ 0ULL ] , & fb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , &
t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = fb_efOut ; t719 [ 0ULL ] = ( X [
113ULL ] + X [ 120ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( & gb_efOut .
mField0 [ 0ULL ] , & gb_efOut . mField1 [ 0ULL ] , & gb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t58 = gb_efOut ;
tlu2_2d_linear_linear_value ( & hb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = hb_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg = t710_idx_0 ;
tlu2_2d_linear_linear_value ( & ib_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ib_efOut [ 0 ] ; t800 = (
intermediate_der197 >= 0.0 ? intermediate_der197 : - intermediate_der197 ) *
0.01 ; t1282 = t710_idx_0 * 7.8539816339744827E-5 ; t798 = t800 / ( t1282 ==
0.0 ? 1.0E-16 : t1282 ) ; t799 = t798 > 1000.0 ? t798 : 1000.0 ;
intermediate_der239 = t798 >= 2000.0 ? t798 : 1.0 ; t802 = pmf_log10 ( 6.9 /
( intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ?
1.0E-16 : intermediate_der239 ) + 0.00017169489553429715 ) * 3.24 ;
intermediate_der242 = 1.0 / ( t802 == 0.0 ? 1.0E-16 : t802 ) ; t1382 = (
pmf_pow ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ; t802 = ( t799 - 1000.0 ) * ( intermediate_der242 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg / ( t1382 == 0.0 ?
1.0E-16 : t1382 ) ; intermediate_der358 = ( t798 - 2000.0 ) / 2000.0 ; t805 =
intermediate_der358 * intermediate_der358 * 3.0 - intermediate_der358 *
intermediate_der358 * intermediate_der358 * 2.0 ; if ( t798 <= 2000.0 ) {
intermediate_der349 = 3.66 ; } else if ( t798 >= 4000.0 ) {
intermediate_der349 = t802 ; } else { intermediate_der349 = ( 1.0 - t805 ) *
3.66 + t802 * t805 ; } t806 = intermediate_der349 * 0.031415926535897927 / (
t798 + 1.0 == 0.0 ? 1.0E-16 : t798 + 1.0 ) / 7.8539816339744827E-5 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) ; t808 = (
U_idx_0 - t797 ) * ( 1.0 - pmf_exp ( - t806 ) ) ; tlu2_2d_linear_linear_value
( & jb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] ,
& t58 . mField0 [ 0ULL ] , & t58 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField8 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] )
; t710_idx_0 = jb_efOut [ 0 ] ; intermediate_der509 = t710_idx_0 ;
intermediate_der539 = pmf_sqrt ( U_idx_2 * U_idx_2 + 1.8124727852251287E-13 )
; t719 [ 0ULL ] = X [ 123ULL ] ; tlu2_linear_linear_prelookup ( & kb_efOut .
mField0 [ 0ULL ] , & kb_efOut . mField1 [ 0ULL ] , & kb_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , &
t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = kb_efOut ;
tlu2_2d_linear_linear_value ( & lb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = lb_efOut [ 0 ] ;
intermediate_der546 = t710_idx_0 ; t719 [ 0ULL ] = X [ 125ULL ] ;
tlu2_linear_linear_prelookup ( & mb_efOut . mField0 [ 0ULL ] , & mb_efOut .
mField1 [ 0ULL ] , & mb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = mb_efOut ; t719 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_linear_prelookup
( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut . mField1 [ 0ULL ] , & nb_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t50 = nb_efOut ;
tlu2_2d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ob_efOut [ 0 ] ;
intermediate_der553 = t710_idx_0 ; t719 [ 0ULL ] = X [ 119ULL ] ;
tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t32 = pb_efOut ; tlu2_2d_linear_linear_value ( & qb_efOut [ 0ULL ] , & t32 .
mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , & t50 . mField0 [ 0ULL ] , &
t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = qb_efOut [
0 ] ; Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 =
t710_idx_0 ; t719 [ 0ULL ] = X [ 6ULL ] ; tlu2_linear_linear_prelookup ( &
rb_efOut . mField0 [ 0ULL ] , & rb_efOut . mField1 [ 0ULL ] , & rb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t50 = rb_efOut ;
tlu2_2d_linear_linear_value ( & sb_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = sb_efOut [ 0 ] ;
intermediate_der8470 = t710_idx_0 ; tlu2_2d_linear_linear_value ( & tb_efOut
[ 0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , & t58 .
mField0 [ 0ULL ] , & t58 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField8 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = tb_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I = t710_idx_0 ;
tlu2_2d_linear_linear_value ( & ub_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , & t58 . mField0 [ 0ULL ] , & t58 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ub_efOut [ 0 ] ;
intermediate_der9543 = t710_idx_0 ; intermediate_der9757 =
intermediate_der197 >= 0.0 ? X [ 94ULL ] : X [ 101ULL ] ; t719 [ 0ULL ] = ( X
[ 9ULL ] + intermediate_der9757 ) / 2.0 ; tlu2_linear_linear_prelookup ( &
vb_efOut . mField0 [ 0ULL ] , & vb_efOut . mField1 [ 0ULL ] , & vb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = vb_efOut ; t719 [ 0ULL ]
= ( X [ 95ULL ] + X [ 102ULL ] ) / 2.0 ; tlu2_linear_linear_prelookup ( &
wb_efOut . mField0 [ 0ULL ] , & wb_efOut . mField1 [ 0ULL ] , & wb_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t60 = wb_efOut ;
tlu2_2d_linear_linear_value ( & xb_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = xb_efOut [ 0 ] ;
intermediate_der1227 = t710_idx_0 ; tlu2_2d_linear_linear_value ( & yb_efOut
[ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField7 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = yb_efOut [ 0 ] ; t1395 = t710_idx_0 * 7.8539816339744827E-5 ;
intermediate_der1258 = t800 / ( t1395 == 0.0 ? 1.0E-16 : t1395 ) ; t811 =
intermediate_der1258 > 1000.0 ? intermediate_der1258 : 1000.0 ;
intermediate_der1148 = intermediate_der1258 >= 2000.0 ? intermediate_der1258
: 1.0 ; t814 = pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ? 1.0E-16 :
intermediate_der1148 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * 3.24 ; intermediate_der11712 = 1.0 / ( t814 == 0.0
? 1.0E-16 : t814 ) ; t1423 = ( pmf_pow ( intermediate_der1227 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der11712 / 8.0 ) *
12.7 + 1.0 ; t814 = ( t811 - 1000.0 ) * ( intermediate_der11712 / 8.0 ) *
intermediate_der1227 / ( t1423 == 0.0 ? 1.0E-16 : t1423 ) ; t815 = (
intermediate_der1258 - 2000.0 ) / 2000.0 ; t817 = t815 * t815 * 3.0 - t815 *
t815 * t815 * 2.0 ; if ( intermediate_der1258 <= 2000.0 ) {
intermediate_der3747 = 3.66 ; } else if ( intermediate_der1258 >= 4000.0 ) {
intermediate_der3747 = t814 ; } else { intermediate_der3747 = ( 1.0 - t817 )
* 3.66 + t814 * t817 ; } t818 = intermediate_der3747 * 0.031415926535897927 /
( intermediate_der1258 + 1.0 == 0.0 ? 1.0E-16 : intermediate_der1258 + 1.0 )
/ 7.8539816339744827E-5 / ( intermediate_der1227 == 0.0 ? 1.0E-16 :
intermediate_der1227 ) ; t820 = ( X [ 10ULL ] - intermediate_der9757 ) * (
1.0 - pmf_exp ( - t818 ) ) ; tlu2_2d_linear_linear_value ( & ac_efOut [ 0ULL
] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t60 . mField0 [
0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField8 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
ac_efOut [ 0 ] ; t821 = t710_idx_0 ; t719 [ 0ULL ] = X [ 128ULL ] ;
tlu2_linear_linear_prelookup ( & bc_efOut . mField0 [ 0ULL ] , & bc_efOut .
mField1 [ 0ULL ] , & bc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = bc_efOut ; tlu2_2d_linear_linear_value ( & cc_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t61 . mField0 [ 0ULL ] , &
t61 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = cc_efOut [
0 ] ; intermediate_der5455 = t710_idx_0 ; t719 [ 0ULL ] = X [ 130ULL ] ;
tlu2_linear_linear_prelookup ( & dc_efOut . mField0 [ 0ULL ] , & dc_efOut .
mField1 [ 0ULL ] , & dc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t32 = dc_efOut ; tlu2_2d_linear_linear_value ( & ec_efOut [ 0ULL ] , & t32 .
mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , & t52 . mField0 [ 0ULL ] , &
t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ec_efOut [
0 ] ; intermediate_der3714 = t710_idx_0 ; t719 [ 0ULL ] = X [ 9ULL ] ;
tlu2_linear_linear_prelookup ( & fc_efOut . mField0 [ 0ULL ] , & fc_efOut .
mField1 [ 0ULL ] , & fc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = fc_efOut ; tlu2_2d_linear_linear_value ( & gc_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , &
t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = gc_efOut [
0 ] ; intermediate_der9401 = t710_idx_0 ; tlu2_2d_linear_linear_value ( &
hc_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField7 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = hc_efOut [ 0 ] ; intermediate_der10249 = t710_idx_0 ;
intermediate_der5449 = intermediate_der197 >= 0.0 ? X [ 103ULL ] : X [ 110ULL
] ; t719 [ 0ULL ] = ( X [ 11ULL ] + intermediate_der5449 ) / 2.0 ;
tlu2_linear_linear_prelookup ( & ic_efOut . mField0 [ 0ULL ] , & ic_efOut .
mField1 [ 0ULL ] , & ic_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = ic_efOut ; t719 [ 0ULL ] = ( X [ 104ULL ] + X [ 111ULL ] ) / 2.0 ;
tlu2_linear_linear_prelookup ( & jc_efOut . mField0 [ 0ULL ] , & jc_efOut .
mField1 [ 0ULL ] , & jc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = jc_efOut ; tlu2_2d_linear_linear_value ( & kc_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , &
t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField6 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = kc_efOut [
0 ] ; intermediate_der5453 = t710_idx_0 ; tlu2_2d_linear_linear_value ( &
lc_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , &
t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField7 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = lc_efOut [ 0 ] ; t1425 = t710_idx_0 * 7.8539816339744827E-5 ;
t822 = t800 / ( t1425 == 0.0 ? 1.0E-16 : t1425 ) ; t800 = t822 > 1000.0 ?
t822 : 1000.0 ; t823 = t822 >= 2000.0 ? t822 : 1.0 ; t826 = pmf_log10 ( 6.9 /
( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * 3.24 ;
intermediate_der5547 = 1.0 / ( t826 == 0.0 ? 1.0E-16 : t826 ) ; t1426 = (
pmf_pow ( intermediate_der5453 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der5547 / 8.0 ) * 12.7 + 1.0 ; t826 = ( t800 - 1000.0 ) * (
intermediate_der5547 / 8.0 ) * intermediate_der5453 / ( t1426 == 0.0 ?
1.0E-16 : t1426 ) ; t827 = ( t822 - 2000.0 ) / 2000.0 ; intermediate_der5551
= t827 * t827 * 3.0 - t827 * t827 * t827 * 2.0 ; if ( t822 <= 2000.0 ) {
intermediate_der5554 = 3.66 ; } else if ( t822 >= 4000.0 ) {
intermediate_der5554 = t826 ; } else { intermediate_der5554 = ( 1.0 -
intermediate_der5551 ) * 3.66 + t826 * intermediate_der5551 ; } t830 =
intermediate_der5554 * 0.031415926535897927 / ( t822 + 1.0 == 0.0 ? 1.0E-16 :
t822 + 1.0 ) / 7.8539816339744827E-5 / ( intermediate_der5453 == 0.0 ?
1.0E-16 : intermediate_der5453 ) ; t832 = ( X [ 12ULL ] -
intermediate_der5449 ) * ( 1.0 - pmf_exp ( - t830 ) ) ;
tlu2_2d_linear_linear_value ( & mc_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField8 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = mc_efOut [ 0 ] ;
intermediate_der8213 = t710_idx_0 ; t719 [ 0ULL ] = X [ 133ULL ] ;
tlu2_linear_linear_prelookup ( & nc_efOut . mField0 [ 0ULL ] , & nc_efOut .
mField1 [ 0ULL ] , & nc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = nc_efOut ; tlu2_2d_linear_linear_value ( & oc_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t49 . mField0 [ 0ULL ] , &
t49 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = oc_efOut [
0 ] ; intermediate_der5591 = t710_idx_0 ; t719 [ 0ULL ] = X [ 135ULL ] ;
tlu2_linear_linear_prelookup ( & pc_efOut . mField0 [ 0ULL ] , & pc_efOut .
mField1 [ 0ULL ] , & pc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = pc_efOut ; tlu2_2d_linear_linear_value ( & qc_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t55 . mField0 [ 0ULL ] , &
t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = qc_efOut [
0 ] ; intermediate_der5594 = t710_idx_0 ; t719 [ 0ULL ] = X [ 11ULL ] ;
tlu2_linear_linear_prelookup ( & rc_efOut . mField0 [ 0ULL ] , & rc_efOut .
mField1 [ 0ULL ] , & rc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t32 = rc_efOut ; tlu2_2d_linear_linear_value ( & sc_efOut [ 0ULL ] , & t32 .
mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , & t60 . mField0 [ 0ULL ] , &
t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = sc_efOut [
0 ] ; intrm_sf_mf_56 = t710_idx_0 ; tlu2_2d_linear_linear_value ( & tc_efOut
[ 0ULL ] , & t32 . mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField7 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = tc_efOut [ 0 ] ; intermediate_der10838 = t710_idx_0 ; t719 [
0ULL ] = X [ 140ULL ] ; tlu2_linear_linear_prelookup ( & uc_efOut . mField0 [
0ULL ] , & uc_efOut . mField1 [ 0ULL ] , & uc_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t60 = uc_efOut ; t719 [ 0ULL ] = X [ 138ULL ] ;
tlu2_linear_linear_prelookup ( & vc_efOut . mField0 [ 0ULL ] , & vc_efOut .
mField1 [ 0ULL ] , & vc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = vc_efOut ; tlu2_2d_linear_linear_value ( & wc_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , & t68 . mField0 [ 0ULL ] , &
t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = wc_efOut [
0 ] ; intermediate_der5597 = t710_idx_0 ; t719 [ 0ULL ] = X [ 137ULL ] ;
tlu2_linear_linear_prelookup ( & xc_efOut . mField0 [ 0ULL ] , & xc_efOut .
mField1 [ 0ULL ] , & xc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = xc_efOut ; tlu2_2d_linear_linear_value ( & yc_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , & t68 . mField0 [ 0ULL ] , &
t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = yc_efOut [
0 ] ; Electrical_Cooling_System_Pump_convection_A_u_in = t710_idx_0 ; t719 [
0ULL ] = X [ 142ULL ] ; tlu2_linear_linear_prelookup ( & ad_efOut . mField0 [
0ULL ] , & ad_efOut . mField1 [ 0ULL ] , & ad_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t719 [ 0ULL ] , & t581 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t52 = ad_efOut ; tlu2_2d_linear_linear_value ( &
bd_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , &
t64 . mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField1 , & t581 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = bd_efOut [ 0 ] ; intermediate_der5598 = t710_idx_0 ;
intermediate_der11512 = ( intermediate_der5597 + t710_idx_0 ) / 2.0 ; t1804 =
X [ 158ULL ] * - 0.2 + 0.2 ; Fuel_Cell_Boost_Converter_L_i = X [ 172ULL ] *
1.0E-9 + X [ 19ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = - X [
198ULL ] + U_idx_4 * - 0.01 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = X [
24ULL ] >= 1.0 ? 1.0 : X [ 24ULL ] ; } intrm_sf_mf_95 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 *
4124.48151675695 ; intermediate_der10338 = ( X [ 21ULL ] / ( X [ 22ULL ] ==
0.0 ? 1.0E-16 : X [ 22ULL ] ) - X [ 199ULL ] / ( X [ 200ULL ] == 0.0 ?
1.0E-16 : X [ 200ULL ] ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intrm_sf_mf_95 / 7.8539816339744827E-5 ; if ( X [ 199ULL ] <=
216.59999999999997 ) { t839 = 216.59999999999997 ; } else { t839 = X [ 199ULL
] >= 623.15 ? 623.15 : X [ 199ULL ] ; } t775 = t839 * t839 ;
intermediate_der11334 = ( ( ( 1074.1165326382554 + t839 * -
0.22145652610641059 ) + t775 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) + ( (
1479.6504774710402 + t839 * 1.2002114337050787 ) + t775 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) + ( (
12825.281119789837 + t839 * 6.9647057412840034 ) + t775 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ;
intermediate_der8351 = intermediate_der11334 - intrm_sf_mf_95 ; t839 =
intermediate_der11334 / ( intermediate_der8351 == 0.0 ? 1.0E-16 :
intermediate_der8351 ) ; intermediate_der11334 = pmf_sqrt (
intermediate_der10338 * intermediate_der10338 * 9.999999999999999E-14 + fabs
( X [ 199ULL ] * t839 * intrm_sf_mf_95 ) * 1.0E-9 ) ; if ( X [ 201ULL ] <=
0.0 ) { t775 = 0.0 ; } else { t775 = X [ 201ULL ] >= 1.0 ? 1.0 : X [ 201ULL ]
; } if ( X [ 202ULL ] <= 0.0 ) { intermediate_der8351 = 0.0 ; } else {
intermediate_der8351 = X [ 202ULL ] >= 1.0 ? 1.0 : X [ 202ULL ] ; } t719 [
0ULL ] = X [ 21ULL ] ; t581 [ 0 ] = 52ULL ; tlu2_linear_nearest_prelookup ( &
cd_efOut . mField0 [ 0ULL ] , & cd_efOut . mField1 [ 0ULL ] , & cd_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t50 = cd_efOut ;
tlu2_1d_linear_nearest_value ( & dd_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = dd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ed_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = ed_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fd_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = fd_efOut [ 0 ] ;
intermediate_der8955 = ( ( ( 1.0 - t775 ) - intermediate_der8351 ) *
t710_idx_0 + U_idx_1 * t775 ) + t706_idx_0 * intermediate_der8351 ; t841 = X
[ 200ULL ] * X [ 200ULL ] * t839 ; intermediate_der11472 = - pmf_sqrt ( fabs
( t841 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) / ( X [ 199ULL
] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) * 7.8539816339744827E-5 ; if (
intermediate_der11472 >= 0.0 ) { t842 = intermediate_der11472 * 100000.0 ; }
else { t842 = - intermediate_der11472 * 100000.0 ; } t845 =
intermediate_der8955 * 7.8539816339744827E-5 ; intermediate_der11539 = t842 *
0.01 / ( t845 == 0.0 ? 1.0E-16 : t845 ) ; t847 = X [ 21ULL ] * intrm_sf_mf_95
; t844 = X [ 22ULL ] / ( t847 == 0.0 ? 1.0E-16 : t847 ) ; t849 = t844 *
1.5707963267948965E-8 ; intermediate_der7296 = intermediate_der11472 *
intermediate_der8955 * 35.2 / ( t849 == 0.0 ? 1.0E-16 : t849 ) ; t848 =
intermediate_der11539 >= 1.0 ? intermediate_der11539 : 1.0 ; t850 = pmf_log10
( 6.9 / ( t848 == 0.0 ? 1.0E-16 : t848 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t848 == 0.0 ? 1.0E-16 : t848 ) + 0.00017169489553429715 )
* 3.24 ; t852 = t844 * 1.2337005501361697E-10 ; t842 = intermediate_der11472
* t842 * ( 1.0 / ( t850 == 0.0 ? 1.0E-16 : t850 ) ) * 0.55 / ( t852 == 0.0 ?
1.0E-16 : t852 ) ; t844 = ( intermediate_der11539 - 2000.0 ) / 2000.0 ; t848
= t844 * t844 * 3.0 - t844 * t844 * t844 * 2.0 ; if ( intermediate_der11539
<= 2000.0 ) { t844 = intermediate_der7296 * 1.0E-5 ; } else if (
intermediate_der11539 >= 4000.0 ) { t844 = t842 * 1.0E-5 ; } else { t844 = (
( 1.0 - t848 ) * intermediate_der7296 + t842 * t848 ) * 1.0E-5 ; }
intermediate_der11334 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der11334 / 7.8539816339744827E-5 * 0.00031622776601683789 + t844
; t842 = X [ 176ULL ] - X [ 22ULL ] ; t719 [ 0ULL ] = X [ 21ULL ] ;
tlu2_linear_linear_prelookup ( & gd_efOut . mField0 [ 0ULL ] , & gd_efOut .
mField1 [ 0ULL ] , & gd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t52 = gd_efOut ; tlu2_1d_linear_linear_value ( & hd_efOut [ 0ULL ] , & t52 .
mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = hd_efOut [
0 ] ; t844 = t710_idx_0 ; tlu2_1d_linear_nearest_value ( & id_efOut [ 0ULL ]
, & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField20 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
id_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & jd_efOut [ 0ULL ] , & t50 .
mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField21 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = jd_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & kd_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL
] , & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22
, & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = kd_efOut [ 0 ] ;
intermediate_der7296 = ( ( ( 1.0 - t775 ) - intermediate_der8351 ) *
t710_idx_0 + U_idx_1 * t775 ) + t706_idx_0 * intermediate_der8351 ; if ( X [
178ULL ] <= 0.0 ) { t848 = 0.0 ; } else { t848 = X [ 178ULL ] >= 1.0 ? 1.0 :
X [ 178ULL ] ; } if ( X [ 177ULL ] <= 0.0 ) { t850 = 0.0 ; } else { t850 = X
[ 177ULL ] >= 1.0 ? 1.0 : X [ 177ULL ] ; } t851 = ( ( ( 1.0 - t848 ) - t850 )
* 296.802103844292 + t848 * 461.523 ) + t850 * 4124.48151675695 ; t853 = X [
178ULL ] * 461.523 / ( t851 == 0.0 ? 1.0E-16 : t851 ) ; if ( t853 <= 0.0 ) {
intermediate_der7331 = 0.0 ; } else { intermediate_der7331 = t853 >= 1.0 ?
1.0 : t853 ; } t853 = X [ 177ULL ] * 4124.48151675695 / ( t851 == 0.0 ?
1.0E-16 : t851 ) ; if ( t853 <= 0.0 ) { t855 = 0.0 ; } else { t855 = t853 >=
1.0 ? 1.0 : t853 ; } t719 [ 0ULL ] = X [ 175ULL ] ;
tlu2_linear_nearest_prelookup ( & ld_efOut . mField0 [ 0ULL ] , & ld_efOut .
mField1 [ 0ULL ] , & ld_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = ld_efOut ; tlu2_1d_linear_nearest_value ( & md_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField23 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = md_efOut [
0 ] ; tlu2_1d_linear_nearest_value ( & nd_efOut [ 0ULL ] , & t68 . mField0 [
0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField24 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = nd_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & od_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField25 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = od_efOut [ 0 ] ; t853 = ( (
( 1.0 - intermediate_der7331 ) - t855 ) * t710_idx_0 + U_idx_1 *
intermediate_der7331 ) + t706_idx_0 * t855 ; tlu2_1d_linear_nearest_value ( &
pd_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField23 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t710_idx_0 = pd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & qd_efOut [
0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; U_idx_1 = qd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & rd_efOut [
0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField25 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t706_idx_0 = rd_efOut [ 0 ] ; t856 = ( ( ( 1.0 - t775 ) -
intermediate_der8351 ) * t710_idx_0 + U_idx_1 * t775 ) + t706_idx_0 *
intermediate_der8351 ; tlu2_1d_linear_nearest_value ( & sd_efOut [ 0ULL ] , &
t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField20 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
sd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & td_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField21 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = td_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & ud_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL
] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22
, & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = ud_efOut [ 0 ] ; t775 = (
( ( 1.0 - intermediate_der7331 ) - t855 ) * t710_idx_0 + U_idx_1 *
intermediate_der7331 ) + t706_idx_0 * t855 ; intermediate_der8351 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 - ( - X [
186ULL ] ) ) / 2.0 ; tlu2_1d_linear_nearest_value ( & vd_efOut [ 0ULL ] , &
t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField15 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
vd_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & wd_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField16 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = wd_efOut [ 0 ]
; tlu2_1d_linear_nearest_value ( & xd_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL
] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17
, & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = xd_efOut [ 0 ] ; t1430 =
intermediate_der8955 + ( ( ( ( 1.0 - intermediate_der7331 ) - t855 ) *
t710_idx_0 + U_idx_1 * intermediate_der7331 ) + t706_idx_0 * t855 ) ; t860 =
t1430 / 2.0 * 7.8539816339744827E-5 ; intermediate_der7331 = (
intermediate_der8351 >= 0.0 ? intermediate_der8351 : 0.0 ) * 0.01 / ( t860 ==
0.0 ? 1.0E-16 : t860 ) ; t855 = intermediate_der7331 >= 0.0 ?
intermediate_der7331 : - intermediate_der7331 ; t857 = t855 > 1000.0 ? t855 :
1000.0 ; t1431 = t853 + t856 ; if ( t1431 / 2.0 > 0.5 ) {
intermediate_der8325 = ( t853 + t856 ) / 2.0 ; } else { intermediate_der8325
= 0.5 ; } intermediate_der8034 = pmf_log10 ( 6.9 / ( t857 == 0.0 ? 1.0E-16 :
t857 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t857 == 0.0 ? 1.0E-16
: t857 ) + 0.00017169489553429715 ) * 3.24 ; intermediate_der8507 = 1.0 / (
intermediate_der8034 == 0.0 ? 1.0E-16 : intermediate_der8034 ) ; t1432 = (
pmf_pow ( intermediate_der8325 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der8507 / 8.0 ) * 12.7 + 1.0 ; t860 = ( t857 - 1000.0 ) * (
intermediate_der8507 / 8.0 ) * intermediate_der8325 / ( t1432 == 0.0 ?
1.0E-16 : t1432 ) ; intermediate_der11637 = ( t855 - 2000.0 ) / 2000.0 ;
intermediate_der8034 = intermediate_der11637 * intermediate_der11637 * 3.0 -
intermediate_der11637 * intermediate_der11637 * intermediate_der11637 * 2.0 ;
if ( t855 <= 2000.0 ) { intermediate_der8886 = 3.66 ; } else if ( t855 >=
4000.0 ) { intermediate_der8886 = t860 ; } else { intermediate_der8886 = (
1.0 - intermediate_der8034 ) * 3.66 + t860 * intermediate_der8034 ; } t1433 =
intermediate_der8886 * 0.031415926535897927 ; t870 = t1431 / 2.0 ; if ( t855
> t1433 / 7.8539816339744827E-5 / ( t870 == 0.0 ? 1.0E-16 : t870 ) / 30.0 ) {
t1793 = ( t853 + t856 ) / 2.0 ; t866 = intermediate_der8886 *
0.031415926535897927 / ( t855 == 0.0 ? 1.0E-16 : t855 ) /
7.8539816339744827E-5 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ; } else { t866 =
30.0 ; } t869 = ( X [ 179ULL ] - X [ 175ULL ] ) * ( 1.0 - pmf_exp ( - t866 )
) ; if ( X [ 197ULL ] <= 0.0 ) { t870 = 0.0 ; } else { t870 = X [ 197ULL ] >=
1.0 ? 1.0 : X [ 197ULL ] ; } if ( X [ 196ULL ] <= 0.0 ) { t871 = 0.0 ; } else
{ t871 = X [ 196ULL ] >= 1.0 ? 1.0 : X [ 196ULL ] ; } t872 = ( ( ( 1.0 - t870
) - t871 ) * 296.802103844292 + t870 * 461.523 ) + t871 * 4124.48151675695 ;
t870 = X [ 197ULL ] * 461.523 / ( t872 == 0.0 ? 1.0E-16 : t872 ) ; if ( t870
<= 0.0 ) { t871 = 0.0 ; } else { t871 = t870 >= 1.0 ? 1.0 : t870 ; } t870 = X
[ 196ULL ] * 4124.48151675695 / ( t872 == 0.0 ? 1.0E-16 : t872 ) ; if ( t870
<= 0.0 ) { t872 = 0.0 ; } else { t872 = t870 >= 1.0 ? 1.0 : t870 ; } t719 [
0ULL ] = X [ 194ULL ] ; tlu2_linear_nearest_prelookup ( & yd_efOut . mField0
[ 0ULL ] , & yd_efOut . mField1 [ 0ULL ] , & yd_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL
] , & t76 [ 0ULL ] ) ; t50 = yd_efOut ; tlu2_1d_linear_nearest_value ( &
ae_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField23 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t710_idx_0 = ae_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & be_efOut [
0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField24 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; U_idx_1 = be_efOut [ 0 ] ; tlu2_1d_linear_nearest_value ( & ce_efOut [
0ULL ] , & t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField25 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t706_idx_0 = ce_efOut [ 0 ] ; t870 = ( ( ( 1.0 - t871 ) - t872 ) *
t710_idx_0 + U_idx_1 * t871 ) + t706_idx_0 * t872 ;
tlu2_1d_linear_nearest_value ( & de_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField20 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = de_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ee_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField21 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = ee_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fe_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField22 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = fe_efOut [ 0 ] ; t873 = ( (
( 1.0 - t871 ) - t872 ) * t710_idx_0 + U_idx_1 * t871 ) + t706_idx_0 * t872 ;
tlu2_1d_linear_nearest_value ( & ge_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ge_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & he_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = he_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & ie_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = ie_efOut [ 0 ] ; t1434 =
intermediate_der8955 + ( ( ( ( 1.0 - t871 ) - t872 ) * t710_idx_0 + U_idx_1 *
t871 ) + t706_idx_0 * t872 ) ; t1456 = t1434 / 2.0 * 7.8539816339744827E-5 ;
t871 = - ( intermediate_der8351 <= 0.0 ? intermediate_der8351 : 0.0 ) * 0.01
/ ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ; t872 = t871 >= 0.0 ? t871 : - t871 ;
t874 = t872 > 1000.0 ? t872 : 1000.0 ; t1435 = t856 + t870 ; if ( t1435 / 2.0
> 0.5 ) { t1822 = ( t856 + t870 ) / 2.0 ; } else { t1822 = 0.5 ; } t1757 =
pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715
) * 3.24 ; t1793 = 1.0 / ( t1757 == 0.0 ? 1.0E-16 : t1757 ) ; t1436 = (
pmf_pow ( t1822 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1793 / 8.0 ) *
12.7 + 1.0 ; t1694 = ( t874 - 1000.0 ) * ( t1793 / 8.0 ) * t1822 / ( t1436 ==
0.0 ? 1.0E-16 : t1436 ) ; t1794 = ( t872 - 2000.0 ) / 2000.0 ; t1681 = t1794
* t1794 * 3.0 - t1794 * t1794 * t1794 * 2.0 ; if ( t872 <= 2000.0 ) { t1456 =
3.66 ; } else if ( t872 >= 4000.0 ) { t1456 = t1694 ; } else { t1456 = ( 1.0
- t1681 ) * 3.66 + t1694 * t1681 ; } t1437 = t1456 * 0.031415926535897927 ;
t891 = t1435 / 2.0 ; if ( t872 > t1437 / 7.8539816339744827E-5 / ( t891 ==
0.0 ? 1.0E-16 : t891 ) / 30.0 ) { t1645 = ( t856 + t870 ) / 2.0 ; t1464 =
t1456 * 0.031415926535897927 / ( t872 == 0.0 ? 1.0E-16 : t872 ) /
7.8539816339744827E-5 / ( t1645 == 0.0 ? 1.0E-16 : t1645 ) ; } else { t1464 =
30.0 ; } t1757 = ( X [ 179ULL ] - X [ 194ULL ] ) * ( 1.0 - pmf_exp ( - t1464
) ) ; t885 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) ; tlu2_1d_linear_linear_value ( & je_efOut [ 0ULL ]
, & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
je_efOut [ 0 ] ; t887 = t710_idx_0 ; tlu2_1d_linear_linear_value ( & ke_efOut
[ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField27 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t710_idx_0 = ke_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 = ( ( ( ( 1.0
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) * t887 +
t844 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 ) +
t710_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1
) - X [ 21ULL ] * intrm_sf_mf_95 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 = t887 - X [
21ULL ] * 0.296802103844292 ; t887 = t710_idx_0 - X [ 21ULL ] *
4.12448151675695 ; t890 = t844 - X [ 21ULL ] * 0.461523 ; t844 = U_idx_3 *
0.031415926535897927 ; if ( t844 * 0.0001 <= 7.8539816339744857E-13 ) { t891
= 7.8539816339744857E-13 ; } else if ( t844 * 0.0001 >= 3.1415926535897929E-6
) { t891 = 3.1415926535897929E-6 ; } else { t891 = t844 * 0.0001 ; } t1473 =
t891 / 7.8539816339744827E-5 ; if ( X [ 221ULL ] <= 0.0 ) { t893 = 0.0 ; }
else { t893 = X [ 221ULL ] >= 1.0 ? 1.0 : X [ 221ULL ] ; } if ( X [ 222ULL ]
<= 0.0 ) { t894 = 0.0 ; } else { t894 = X [ 222ULL ] >= 1.0 ? 1.0 : X [
222ULL ] ; } t895 = ( ( ( 1.0 - t893 ) - t894 ) * 296.802103844292 + t893 *
461.523 ) + t894 * 4124.48151675695 ; t899 = X [ 219ULL ] * t895 ; t896 = X [
220ULL ] / ( t899 == 0.0 ? 1.0E-16 : t899 ) ; t1645 = X [ 220ULL ] / ( X [
195ULL ] == 0.0 ? 1.0E-16 : X [ 195ULL ] ) * ( X [ 223ULL ] / ( X [ 219ULL ]
== 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t1487 = X [ 220ULL ] / 1.01325 * ( X [
224ULL ] / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ; t1513 = ( X [
195ULL ] + 1.01325 ) / 2.0 * 0.0010000000000000009 ; t1502 = ( 1.0 - t1473 )
* ( 1.0 - t1473 ) ; t907 = t1513 * t1502 ; t1713 = ( t1473 + 1.0 ) * ( 1.0 -
t1473 * t1645 ) - ( 1.0 - t1473 * t1487 ) * t1473 * 2.0 ; t1723 = ( X [
195ULL ] - 1.01325 ) * ( t1713 >= t1502 ? t1713 : t1502 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = ( X [
195ULL ] - 1.01325 ) / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ; t1553 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 * 2.0 ; if (
X [ 195ULL ] - 1.01325 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = t907 ; }
else if ( X [ 195ULL ] - 1.01325 >= t1513 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = t1723 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = (
1.0 - t1553 ) * t907 + t1723 * t1553 ; } t1723 = ( t1473 + 1.0 ) * ( 1.0 -
t1473 * t1487 ) - ( 1.0 - t1473 * t1645 ) * t1473 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = ( 1.01325 -
X [ 195ULL ] ) * ( t1723 >= t1502 ? t1723 : t1502 ) ; intrm_sf_mf_545 = (
1.01325 - X [ 195ULL ] ) / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ; t1581 =
intrm_sf_mf_545 * intrm_sf_mf_545 * 3.0 - intrm_sf_mf_545 * intrm_sf_mf_545 *
intrm_sf_mf_545 * 2.0 ; if ( 1.01325 - X [ 195ULL ] <= 0.0 ) {
intrm_sf_mf_545 = t907 ; } else if ( 1.01325 - X [ 195ULL ] >= t1513 ) {
intrm_sf_mf_545 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; } else {
intrm_sf_mf_545 = ( 1.0 - t1581 ) * t907 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 * t1581 ; } if
( X [ 195ULL ] > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 = X [ 195ULL ]
< 1.01325 ? intrm_sf_mf_545 : t907 ; } if ( X [ 219ULL ] <=
216.59999999999997 ) { t907 = 216.59999999999997 ; } else { t907 = X [ 219ULL
] >= 623.15 ? 623.15 : X [ 219ULL ] ; } t778 = t907 * t907 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = ( ( (
1074.1165326382554 + t907 * - 0.22145652610641059 ) + t778 *
0.0003721298010901061 ) * ( ( 1.0 - t893 ) - t894 ) + ( ( 1479.6504774710402
+ t907 * 1.2002114337050787 ) + t778 * - 0.00038614513167845434 ) * t893 ) +
( ( 12825.281119789837 + t907 * 6.9647057412840034 ) + t778 * -
0.0070524868246844051 ) * t894 ; t910 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 - t895 ; t911
= X [ 220ULL ] * X [ 220ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 / ( t910 ==
0.0 ? 1.0E-16 : t910 ) ) ; t893 = pmf_sqrt ( fabs ( t911 / ( t895 == 0.0 ?
1.0E-16 : t895 ) / ( X [ 219ULL ] == 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) *
t891 * 0.64 ; t914 = t896 * 2.0 ; t894 = ( X [ 195ULL ] - 1.01325 ) *
pmf_sqrt ( fabs ( t914 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t891 * 0.64 ; if ( X [ 36ULL ] <= 0.0 ) { t907 = 0.0 ; } else { t907 = X
[ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = X [
35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } intrm_sf_mf_545 = ( ( ( 1.0 - t907 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) *
296.802103844292 + t907 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 *
4124.48151675695 ; t719 [ 0ULL ] = X [ 34ULL ] ; tlu2_linear_linear_prelookup
( & le_efOut . mField0 [ 0ULL ] , & le_efOut . mField1 [ 0ULL ] , & le_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = le_efOut ;
tlu2_1d_linear_linear_value ( & me_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = me_efOut [ 0 ] ; t778 =
t710_idx_0 ; tlu2_1d_linear_linear_value ( & ne_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ne_efOut [
0 ] ; t910 = t710_idx_0 ; tlu2_1d_linear_linear_value ( & oe_efOut [ 0ULL ] ,
& t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField27 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
oe_efOut [ 0 ] ; t907 = ( ( ( ( 1.0 - t907 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) * t910 +
t778 * t907 ) + t710_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) - X [ 34ULL
] * intrm_sf_mf_545 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 = t910 - X [
34ULL ] * 0.296802103844292 ; t910 = t710_idx_0 - X [ 34ULL ] *
4.12448151675695 ; t912 = t778 - X [ 34ULL ] * 0.461523 ; t778 = pmf_sqrt ( X
[ 313ULL ] * X [ 313ULL ] + 3.6921614138577959E-12 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 = ( X [ 322ULL
] * 0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X
[ 41ULL ] <= 0.0 ) { zc_int17 = 0.0 ; } else { zc_int17 = X [ 41ULL ] >= 1.0
? 1.0 : X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = X [ 42ULL
] >= 1.0 ? 1.0 : X [ 42ULL ] ; } zc_int174 = ( ( ( 1.0 - zc_int17 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) *
296.802103844292 + zc_int17 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 *
259.836612622973 ; if ( X [ 328ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = X [
328ULL ] >= 1.0 ? 1.0 : X [ 328ULL ] ; } if ( X [ 329ULL ] <= 0.0 ) {
zc_int179 = 0.0 ; } else { zc_int179 = X [ 329ULL ] >= 1.0 ? 1.0 : X [ 329ULL
] ; } t719 [ 0ULL ] = X [ 39ULL ] ; tlu2_linear_nearest_prelookup ( &
pe_efOut . mField0 [ 0ULL ] , & pe_efOut . mField1 [ 0ULL ] , & pe_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t50 = pe_efOut ;
tlu2_1d_linear_nearest_value ( & qe_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = qe_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & re_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = re_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & se_efOut [ 0ULL ] , & t50 . mField0 [ 0ULL ]
, & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField28 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = se_efOut [ 0 ] ; zc_int180
= ( ( ( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43
) - zc_int179 ) * t710_idx_0 + U_idx_1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ) +
t706_idx_0 * zc_int179 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = X [ 39ULL ]
* zc_int174 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43
= X [ 40ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) ;
zc_int179 = - ( ( X [ 39ULL ] / ( X [ 40ULL ] == 0.0 ? 1.0E-16 : X [ 40ULL ]
) - X [ 330ULL ] / ( X [ 331ULL ] == 0.0 ? 1.0E-16 : X [ 331ULL ] ) ) * X [
313ULL ] * zc_int174 ) / 0.0019634954084936209 ; if ( X [ 330ULL ] <=
216.59999999999997 ) { zc_int184 = 216.59999999999997 ; } else { zc_int184 =
X [ 330ULL ] >= 623.15 ? 623.15 : X [ 330ULL ] ; } t917 = zc_int184 *
zc_int184 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 =
( ( ( 1074.1165326382554 + zc_int184 * - 0.22145652610641059 ) + t917 *
0.0003721298010901061 ) * ( ( 1.0 - zc_int17 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) + ( (
1479.6504774710402 + zc_int184 * 1.2002114337050787 ) + t917 * -
0.00038614513167845434 ) * zc_int17 ) + ( ( 900.639412248396 + zc_int184 * -
0.044484923911441127 ) + t917 * 0.00036936011832051582 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ; t1519 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 - zc_int174 ;
zc_int17 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 /
( t1519 == 0.0 ? 1.0E-16 : t1519 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = pmf_sqrt (
zc_int179 * zc_int179 * 9.999999999999999E-14 + fabs ( X [ 330ULL ] *
zc_int17 * zc_int174 ) * 1.0E-9 ) ; t923 = X [ 331ULL ] * X [ 331ULL ] *
zc_int17 ; zc_int184 = - pmf_sqrt ( fabs ( t923 / ( zc_int174 == 0.0 ?
1.0E-16 : zc_int174 ) / ( X [ 330ULL ] == 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) )
* 0.0019634954084936209 ; if ( zc_int184 >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = zc_int184 *
100000.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = - zc_int184
* 100000.0 ; } t927 = zc_int180 * 0.0019634954084936209 ; t917 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 0.05 / (
t927 == 0.0 ? 1.0E-16 : t927 ) ; t929 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
9.8174770424681068E-6 ; t920 = zc_int184 * zc_int180 * 35.2 / ( t929 == 0.0 ?
1.0E-16 : t929 ) ; t921 = t917 >= 1.0 ? t917 : 1.0 ; t930 = pmf_log10 ( 6.9 /
( t921 == 0.0 ? 1.0E-16 : t921 ) + 2.8767404433520813E-5 ) * pmf_log10 ( 6.9
/ ( t921 == 0.0 ? 1.0E-16 : t921 ) + 2.8767404433520813E-5 ) * 3.24 ; t932 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
3.855314219175531E-7 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = zc_int184 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * ( 1.0 / (
t930 == 0.0 ? 1.0E-16 : t930 ) ) * 0.55 / ( t932 == 0.0 ? 1.0E-16 : t932 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = ( t917 -
2000.0 ) / 2000.0 ; t921 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 2.0 ; if (
t917 <= 2000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = t920 *
1.0E-5 ; } else if ( t917 >= 4000.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 * 1.0E-5 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = ( (
1.0 - t921 ) * t920 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 * t921 ) *
1.0E-5 ; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 = -
( X [ 313ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) /
0.0019634954084936209 * 0.00031622776601683789 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - X [ 40ULL ]
; if ( X [ 324ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = X [
324ULL ] >= 1.0 ? 1.0 : X [ 324ULL ] ; } if ( X [ 323ULL ] <= 0.0 ) { t920 =
0.0 ; } else { t920 = X [ 323ULL ] >= 1.0 ? 1.0 : X [ 323ULL ] ; } t921 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) -
t920 ) * 296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 * 461.523 ) +
t920 * 259.836612622973 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 = pmf_sqrt (
X [ 313ULL ] * X [ 313ULL ] + 4.1024015709531055E-13 ) ; if ( X [ 322ULL ] *
0.0019634954084936209 <= 1.9634954084936209E-11 ) { t920 =
1.9634954084936209E-11 ; } else if ( X [ 322ULL ] * 0.0019634954084936209 >=
0.0012566370614359179 ) { t920 = 0.0012566370614359179 ; } else { t920 = X [
322ULL ] * 0.0019634954084936209 ; } t1519 = t920 / 0.0019634954084936209 ;
if ( X [ 345ULL ] <= 0.0 ) { t924 = 0.0 ; } else { t924 = X [ 345ULL ] >= 1.0
? 1.0 : X [ 345ULL ] ; } if ( X [ 346ULL ] <= 0.0 ) { t926 = 0.0 ; } else {
t926 = X [ 346ULL ] >= 1.0 ? 1.0 : X [ 346ULL ] ; } t928 = ( ( ( 1.0 - t924 )
- t926 ) * 296.802103844292 + t924 * 461.523 ) + t926 * 259.836612622973 ;
t936 = X [ 343ULL ] * t928 ; t930 = X [ 344ULL ] / ( t936 == 0.0 ? 1.0E-16 :
t936 ) ; t931 = X [ 344ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) *
( X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ; t933 =
X [ 344ULL ] / 1.01325 * ( X [ 348ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X
[ 343ULL ] ) ) ; t935 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 + 1.01325 ) /
2.0 * 0.0010000000000000009 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 = ( 1.0 -
t1519 ) * ( 1.0 - t1519 ) ; t936 = t935 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ; t941 = (
t1519 + 1.0 ) * ( 1.0 - t1519 * t931 ) - ( 1.0 - t1519 * t933 ) * t1519 * 2.0
; t943 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 -
1.01325 ) * ( t941 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ? t941 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ) ;
intrm_sf_mf_839 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t935 == 0.0 ? 1.0E-16 : t935 ) ; t944 = intrm_sf_mf_839 * intrm_sf_mf_839 *
3.0 - intrm_sf_mf_839 * intrm_sf_mf_839 * intrm_sf_mf_839 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { intrm_sf_mf_1142 = t936 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t935 ) { intrm_sf_mf_1142 = t943 ; } else { intrm_sf_mf_1142 = ( 1.0 - t944 )
* t936 + t943 * t944 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 = ( t1519 +
1.0 ) * ( 1.0 - t1519 * t933 ) - ( 1.0 - t1519 * t931 ) * t1519 * 2.0 ; t931
= ( 1.01325 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0
) * ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ) ; t933 = (
1.01325 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) /
( t935 == 0.0 ? 1.0E-16 : t935 ) ; t945 = t933 * t933 * 3.0 - t933 * t933 *
t933 * 2.0 ; if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t936 ; }
else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t935 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t931 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = (
1.0 - t945 ) * t936 + t931 * t945 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 =
intrm_sf_mf_1142 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 : t936 ; } if
( X [ 343ULL ] <= 216.59999999999997 ) { intrm_sf_mf_1142 =
216.59999999999997 ; } else { intrm_sf_mf_1142 = X [ 343ULL ] >= 623.15 ?
623.15 : X [ 343ULL ] ; } t784 = intrm_sf_mf_1142 * intrm_sf_mf_1142 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = ( ( (
1074.1165326382554 + intrm_sf_mf_1142 * - 0.22145652610641059 ) + t784 *
0.0003721298010901061 ) * ( ( 1.0 - t924 ) - t926 ) + ( ( 1479.6504774710402
+ intrm_sf_mf_1142 * 1.2002114337050787 ) + t784 * - 0.00038614513167845434 )
* t924 ) + ( ( 900.639412248396 + intrm_sf_mf_1142 * - 0.044484923911441127 )
+ t784 * 0.00036936011832051582 ) * t926 ; t946 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 - t928 ; t947
= X [ 344ULL ] * X [ 344ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 / ( t946 ==
0.0 ? 1.0E-16 : t946 ) ) ; t924 = pmf_sqrt ( fabs ( t947 / ( t928 == 0.0 ?
1.0E-16 : t928 ) / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [ 343ULL ] ) ) ) *
t920 * 0.64 ; t950 = t930 * 2.0 ; t926 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
pmf_sqrt ( fabs ( t950 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * t920 * 0.64 ; if ( X [ 53ULL ] <= 0.0 ) { intrm_sf_mf_1142 = 0.0 ; } else
{ intrm_sf_mf_1142 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; } if ( X [
52ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = X [
52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t784 = ( ( ( 1.0 - intrm_sf_mf_1142 )
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) *
296.802103844292 + intrm_sf_mf_1142 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 *
259.836612622973 ; t719 [ 0ULL ] = X [ 51ULL ] ; tlu2_linear_linear_prelookup
( & te_efOut . mField0 [ 0ULL ] , & te_efOut . mField1 [ 0ULL ] , & te_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = te_efOut ;
tlu2_1d_linear_linear_value ( & ue_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ue_efOut [ 0 ] ; t946 =
t710_idx_0 ; tlu2_1d_linear_linear_value ( & ve_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ve_efOut [
0 ] ; t948 = t710_idx_0 ; tlu2_1d_linear_linear_value ( & we_efOut [ 0ULL ] ,
& t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField31 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 =
we_efOut [ 0 ] ; intrm_sf_mf_1142 = ( ( ( ( 1.0 - intrm_sf_mf_1142 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) * t948 +
t946 * intrm_sf_mf_1142 ) + t710_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) - X [ 51ULL
] * t784 * 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 = t948 - X [
51ULL ] * 0.296802103844292 ; t948 = t710_idx_0 - X [ 51ULL ] *
0.25983661262297303 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 = - X [ 434ULL
] + U_idx_10 * - 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 +
6.4274470286298274E-9 ) ; t719 [ 0ULL ] = X [ 433ULL ] ; t584 [ 0 ] = 11ULL ;
tlu2_linear_linear_prelookup ( & xe_efOut . mField0 [ 0ULL ] , & xe_efOut .
mField1 [ 0ULL ] , & xe_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t49 = xe_efOut ; t719 [ 0ULL ] = 1.01325 ; t408 [ 0 ] = 12ULL ;
tlu2_linear_linear_prelookup ( & ye_efOut . mField0 [ 0ULL ] , & ye_efOut .
mField1 [ 0ULL ] , & ye_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t719 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = ye_efOut ; tlu2_2d_linear_linear_value ( & af_efOut [ 0ULL ] , & t49 .
mField0 [ 0ULL ] , & t49 . mField2 [ 0ULL ] , & t68 . mField0 [ 0ULL ] , &
t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = af_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant6 =
t710_idx_0 ; t719 [ 0ULL ] = X [ 429ULL ] ; tlu2_linear_linear_prelookup ( &
bf_efOut . mField0 [ 0ULL ] , & bf_efOut . mField1 [ 0ULL ] , & bf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t52 = bf_efOut ;
tlu2_2d_linear_linear_value ( & cf_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ]
, & t52 . mField2 [ 0ULL ] , & t68 . mField0 [ 0ULL ] , & t68 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = cf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 = t710_idx_0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 = U_idx_10 *
2.0 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 =
pmf_sqrt ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
1.2620262729050631E-10 ) ; t719 [ 0ULL ] = X [ 453ULL ] ;
tlu2_linear_linear_prelookup ( & df_efOut . mField0 [ 0ULL ] , & df_efOut .
mField1 [ 0ULL ] , & df_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t61 = df_efOut ; tlu2_2d_linear_linear_value ( & ef_efOut [ 0ULL ] , & t61 .
mField0 [ 0ULL ] , & t61 . mField2 [ 0ULL ] , & t68 . mField0 [ 0ULL ] , &
t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ef_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co3 =
t710_idx_0 ; t719 [ 0ULL ] = X [ 455ULL ] ; tlu2_linear_linear_prelookup ( &
ff_efOut . mField0 [ 0ULL ] , & ff_efOut . mField1 [ 0ULL ] , & ff_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t60 = ff_efOut ; t719 [ 0ULL ]
= X [ 451ULL ] ; tlu2_linear_linear_prelookup ( & gf_efOut . mField0 [ 0ULL ]
, & gf_efOut . mField1 [ 0ULL ] , & gf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t719 [ 0ULL ] , & t408 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t61 = gf_efOut ; tlu2_2d_linear_linear_value ( &
hf_efOut [ 0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , &
t61 . mField0 [ 0ULL ] , & t61 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = hf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co8 = t710_idx_0 ;
t719 [ 0ULL ] = X [ 450ULL ] ; tlu2_linear_linear_prelookup ( & if_efOut .
mField0 [ 0ULL ] , & if_efOut . mField1 [ 0ULL ] , & if_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = if_efOut ;
tlu2_2d_linear_linear_value ( & jf_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t61 . mField0 [ 0ULL ] , & t61 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = jf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 = t710_idx_0
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_rho_ = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co3 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co8 ) / 2.0 ; t719
[ 0ULL ] = X [ 450ULL ] ; tlu2_linear_nearest_prelookup ( & kf_efOut .
mField0 [ 0ULL ] , & kf_efOut . mField1 [ 0ULL ] , & kf_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t49 = kf_efOut ; t719 [ 0ULL ] = X [ 60ULL
] ; tlu2_linear_nearest_prelookup ( & lf_efOut . mField0 [ 0ULL ] , &
lf_efOut . mField1 [ 0ULL ] , & lf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t719 [ 0ULL ] , & t408 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t32 = lf_efOut ; tlu2_2d_linear_nearest_value ( &
mf_efOut [ 0ULL ] , & t49 . mField0 [ 0ULL ] , & t49 . mField2 [ 0ULL ] , &
t32 . mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField39 , & t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = mf_efOut [ 0 ] ; t951 = t710_idx_0 ; t719 [ 0ULL ] = X [ 436ULL
] ; tlu2_linear_nearest_prelookup ( & nf_efOut . mField0 [ 0ULL ] , &
nf_efOut . mField1 [ 0ULL ] , & nf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [ 0ULL ] , & t584 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t55 = nf_efOut ; tlu2_2d_linear_nearest_value ( &
of_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , &
t32 . mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField39 , & t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = of_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 = t710_idx_0 ;
t719 [ 0ULL ] = X [ 61ULL ] ; tlu2_linear_nearest_prelookup ( & pf_efOut .
mField0 [ 0ULL ] , & pf_efOut . mField1 [ 0ULL ] , & pf_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = pf_efOut ;
tlu2_2d_linear_nearest_value ( & qf_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ] , & t32 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField39 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = qf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 = t710_idx_0 ;
tlu2_2d_linear_nearest_value ( & rf_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ] , & t32 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = rf_efOut [ 0 ] ; U_idx_7 =
t710_idx_0 ; intrm_sf_mf_1336 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 - ( - X [
442ULL ] ) ) / 2.0 ; tlu2_2d_linear_nearest_value ( & sf_efOut [ 0ULL ] , &
t68 . mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ]
, & t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 ,
& t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = sf_efOut
[ 0 ] ; t952 = t710_idx_0 ; t953 = intrm_sf_mf_1336 * 0.0028301886792452828 ;
t954 = t710_idx_0 * 0.00093750000000000007 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 = t953 / (
t954 == 0.0 ? 1.0E-16 : t954 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
2.4102926357361849E-12 ) ; t719 [ 0ULL ] = X [ 456ULL ] ;
tlu2_linear_linear_prelookup ( & tf_efOut . mField0 [ 0ULL ] , & tf_efOut .
mField1 [ 0ULL ] , & tf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t719 [ 0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = tf_efOut ; tlu2_2d_linear_linear_value ( & uf_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , & t61 . mField0 [ 0ULL ] , &
t61 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = uf_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato9 =
t710_idx_0 ; t719 [ 0ULL ] = X [ 61ULL ] ; tlu2_linear_linear_prelookup ( &
vf_efOut . mField0 [ 0ULL ] , & vf_efOut . mField1 [ 0ULL ] , & vf_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t719 [
0ULL ] , & t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t52 = vf_efOut ; t719 [ 0ULL ]
= X [ 60ULL ] ; tlu2_linear_linear_prelookup ( & wf_efOut . mField0 [ 0ULL ]
, & wf_efOut . mField1 [ 0ULL ] , & wf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField34 , & t719 [ 0ULL ] , & t408 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t50 = wf_efOut ; tlu2_2d_linear_linear_value ( &
xf_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , &
t50 . mField0 [ 0ULL ] , & t50 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = xf_efOut [ 0 ] ; U_idx_10 = t710_idx_0 ;
tlu2_2d_linear_nearest_value ( & yf_efOut [ 0ULL ] , & t49 . mField0 [ 0ULL ]
, & t49 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ] , & t32 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = yf_efOut [ 0 ] ; U_idx_3 =
t710_idx_0 ; tlu2_2d_linear_nearest_value ( & ag_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ] , &
t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField40 , &
t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ag_efOut [
0 ] ; intrm_sf_mf_1348 = t710_idx_0 ; tlu2_2d_linear_nearest_value ( &
bg_efOut [ 0ULL ] , & t49 . mField0 [ 0ULL ] , & t49 . mField2 [ 0ULL ] , &
t32 . mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField41 , & t584 [ 0ULL ] , & t408 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t710_idx_0 = bg_efOut [ 0 ] ; intrm_sf_mf_1324 = t710_idx_0 ;
tlu2_2d_linear_nearest_value ( & cg_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , & t32 . mField0 [ 0ULL ] , & t32 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t584 [ 0ULL ] , &
t408 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = cg_efOut [ 0 ] ;
intrm_sf_mf_1337 = t710_idx_0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T8 = pmf_sqrt ( X
[ 478ULL ] * X [ 478ULL ] + 1.4768645655431184E-13 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 = ( X [ 485ULL
] * - 0.62500003906250234 + U_idx_11 * 10.0 ) + 6.2500003783494407E-9 ; if (
X [ 69ULL ] <= 0.0 ) { zc_int321 = 0.0 ; } else { zc_int321 = X [ 69ULL ] >=
1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 = X [
70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; } zc_int322 = ( ( ( 1.0 - zc_int321 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 ) *
296.802103844292 + zc_int321 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 *
4124.48151675695 ; t955 = - ( ( X [ 67ULL ] / ( X [ 68ULL ] == 0.0 ? 1.0E-16
: X [ 68ULL ] ) - X [ 488ULL ] / ( X [ 489ULL ] == 0.0 ? 1.0E-16 : X [ 489ULL
] ) ) * X [ 478ULL ] * zc_int322 ) / 7.8539816339744827E-5 ; if ( X [ 488ULL
] <= 216.59999999999997 ) { zc_int341 = 216.59999999999997 ; } else {
zc_int341 = X [ 488ULL ] >= 623.15 ? 623.15 : X [ 488ULL ] ; } t787 =
zc_int341 * zc_int341 ; t959 = ( ( ( 1074.1165326382554 + zc_int341 * -
0.22145652610641059 ) + t787 * 0.0003721298010901061 ) * ( ( 1.0 - zc_int321
) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 ) + ( (
1479.6504774710402 + zc_int341 * 1.2002114337050787 ) + t787 * -
0.00038614513167845434 ) * zc_int321 ) + ( ( 12825.281119789837 + zc_int341 *
6.9647057412840034 ) + t787 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 ; t960 = t959
- zc_int322 ; zc_int321 = t959 / ( t960 == 0.0 ? 1.0E-16 : t960 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 = pmf_sqrt (
t955 * t955 * 9.999999999999999E-14 + fabs ( X [ 488ULL ] * zc_int321 *
zc_int322 ) * 1.0E-9 ) ; if ( X [ 490ULL ] <= 0.0 ) { zc_int341 = 0.0 ; }
else { zc_int341 = X [ 490ULL ] >= 1.0 ? 1.0 : X [ 490ULL ] ; } if ( X [
491ULL ] <= 0.0 ) { t959 = 0.0 ; } else { t959 = X [ 491ULL ] >= 1.0 ? 1.0 :
X [ 491ULL ] ; } t719 [ 0ULL ] = X [ 67ULL ] ; tlu2_linear_nearest_prelookup
( & dg_efOut . mField0 [ 0ULL ] , & dg_efOut . mField1 [ 0ULL ] , & dg_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t719 [
0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 = dg_efOut ;
tlu2_1d_linear_nearest_value ( & eg_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField15 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = eg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & fg_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = fg_efOut [ 0 ] ;
tlu2_1d_linear_nearest_value ( & gg_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField17 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = gg_efOut [ 0 ] ; t787 = ( (
( 1.0 - zc_int341 ) - t959 ) * t710_idx_0 + U_idx_1 * zc_int341 ) +
t706_idx_0 * t959 ; t961 = X [ 489ULL ] * X [ 489ULL ] * zc_int321 ;
zc_int341 = - pmf_sqrt ( fabs ( t961 / ( zc_int322 == 0.0 ? 1.0E-16 :
zc_int322 ) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) ) *
7.8539816339744827E-5 ; if ( zc_int341 >= 0.0 ) { t959 = zc_int341 * 100000.0
; } else { t959 = - zc_int341 * 100000.0 ; } t965 = t787 *
7.8539816339744827E-5 ; t960 = t959 * 0.01 / ( t965 == 0.0 ? 1.0E-16 : t965 )
; t967 = X [ 67ULL ] * zc_int322 ; t962 = X [ 68ULL ] / ( t967 == 0.0 ?
1.0E-16 : t967 ) ; U_idx_11 = t962 * 1.5707963267948965E-8 ; intrm_sf_mf_1433
= zc_int341 * t787 * 35.2 / ( U_idx_11 == 0.0 ? 1.0E-16 : U_idx_11 ) ; t964 =
t960 >= 1.0 ? t960 : 1.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 = pmf_log10 (
6.9 / ( t964 == 0.0 ? 1.0E-16 : t964 ) + 0.00017169489553429715 ) * pmf_log10
( 6.9 / ( t964 == 0.0 ? 1.0E-16 : t964 ) + 0.00017169489553429715 ) * 3.24 ;
t972 = t962 * 1.2337005501361697E-10 ; t959 = zc_int341 * t959 * ( 1.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 ) )
* 0.55 / ( t972 == 0.0 ? 1.0E-16 : t972 ) ; t962 = ( t960 - 2000.0 ) / 2000.0
; t964 = t962 * t962 * 3.0 - t962 * t962 * t962 * 2.0 ; if ( t960 <= 2000.0 )
{ t962 = intrm_sf_mf_1433 * 1.0E-5 ; } else if ( t960 >= 4000.0 ) { t962 =
t959 * 1.0E-5 ; } else { t962 = ( ( 1.0 - t964 ) * intrm_sf_mf_1433 + t959 *
t964 ) * 1.0E-5 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 = - ( X [
478ULL ] * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 )
/ 7.8539816339744827E-5 * 0.00031622776601683789 + t962 ; t959 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 68ULL ]
; if ( X [ 487ULL ] <= 0.0 ) { t962 = 0.0 ; } else { t962 = X [ 487ULL ] >=
1.0 ? 1.0 : X [ 487ULL ] ; } if ( X [ 486ULL ] <= 0.0 ) { intrm_sf_mf_1433 =
0.0 ; } else { intrm_sf_mf_1433 = X [ 486ULL ] >= 1.0 ? 1.0 : X [ 486ULL ] ;
} t964 = ( ( ( 1.0 - t962 ) - intrm_sf_mf_1433 ) * 296.802103844292 + t962 *
461.523 ) + intrm_sf_mf_1433 * 4124.48151675695 ; t962 = pmf_sqrt ( X [
478ULL ] * X [ 478ULL ] + 1.6409606283812424E-14 ) ; if ( X [ 485ULL ] *
7.8539816339744827E-5 <= 7.8539816339744857E-13 ) { intrm_sf_mf_1433 =
7.8539816339744857E-13 ; } else if ( X [ 485ULL ] * 7.8539816339744827E-5 >=
1.2566370614359172E-5 ) { intrm_sf_mf_1433 = 1.2566370614359172E-5 ; } else {
intrm_sf_mf_1433 = X [ 485ULL ] * 7.8539816339744827E-5 ; } t967 =
intrm_sf_mf_1433 / 7.8539816339744827E-5 ; if ( X [ 508ULL ] <= 0.0 ) { t968
= 0.0 ; } else { t968 = X [ 508ULL ] >= 1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [
509ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 = X [
509ULL ] >= 1.0 ? 1.0 : X [ 509ULL ] ; } t971 = ( ( ( 1.0 - t968 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 ) *
296.802103844292 + t968 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 *
4124.48151675695 ; t976 = X [ 506ULL ] * t971 ; t973 = X [ 507ULL ] / ( t976
== 0.0 ? 1.0E-16 : t976 ) ; t974 = X [ 507ULL ] / ( X [ 64ULL ] == 0.0 ?
1.0E-16 : X [ 64ULL ] ) * ( X [ 510ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 :
X [ 506ULL ] ) ) ; t976 = X [ 507ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) *
( X [ 511ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ; t978 =
( X [ 64ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) / 2.0 *
0.0010000000000000009 ; t975 = ( 1.0 - t967 ) * ( 1.0 - t967 ) ; t979 = t978
* t975 ; t984 = ( t967 + 1.0 ) * ( 1.0 - t967 * t974 ) - ( 1.0 - t967 * t976
) * t967 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 = ( X [ 64ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) * ( t984
>= t975 ? t984 : t975 ) ; intrm_sf_mf_1544 = ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) / ( t978 ==
0.0 ? 1.0E-16 : t978 ) ; t985 = intrm_sf_mf_1544 * intrm_sf_mf_1544 * 3.0 -
intrm_sf_mf_1544 * intrm_sf_mf_1544 * intrm_sf_mf_1544 * 2.0 ; if ( X [ 64ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 <= 0.0 ) {
U_idx_1 = t979 ; } else if ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 >= t978 ) {
U_idx_1 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 ; }
else { U_idx_1 = ( 1.0 - t985 ) * t979 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 * t985 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 = ( t967 +
1.0 ) * ( 1.0 - t967 * t976 ) - ( 1.0 - t967 * t974 ) * t967 * 2.0 ; t974 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
) * ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 >= t975
? Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 : t975 ) ;
t976 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [
64ULL ] ) / ( t978 == 0.0 ? 1.0E-16 : t978 ) ; t986 = t976 * t976 * 3.0 -
t976 * t976 * t976 * 2.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
<= 0.0 ) { intrm_sf_mf_9 = t979 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
>= t978 ) { intrm_sf_mf_9 = t974 ; } else { intrm_sf_mf_9 = ( 1.0 - t986 ) *
t979 + t974 * t986 ; } if ( X [ 64ULL ] >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 = U_idx_1 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 = X [
64ULL ] < Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ?
intrm_sf_mf_9 : t979 ; } if ( X [ 506ULL ] <= 216.59999999999997 ) { U_idx_1
= 216.59999999999997 ; } else { U_idx_1 = X [ 506ULL ] >= 623.15 ? 623.15 : X
[ 506ULL ] ; } t790 = U_idx_1 * U_idx_1 ; intrm_sf_mf_9 = ( ( (
1074.1165326382554 + U_idx_1 * - 0.22145652610641059 ) + t790 *
0.0003721298010901061 ) * ( ( 1.0 - t968 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 ) + ( (
1479.6504774710402 + U_idx_1 * 1.2002114337050787 ) + t790 * -
0.00038614513167845434 ) * t968 ) + ( ( 12825.281119789837 + U_idx_1 *
6.9647057412840034 ) + t790 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 ; t987 =
intrm_sf_mf_9 - t971 ; t988 = X [ 507ULL ] * X [ 507ULL ] * ( intrm_sf_mf_9 /
( t987 == 0.0 ? 1.0E-16 : t987 ) ) ; t968 = pmf_sqrt ( fabs ( t988 / ( t971
== 0.0 ? 1.0E-16 : t971 ) / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] )
) ) * intrm_sf_mf_1433 * 0.64 ; t991 = t973 * 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 = ( X [ 64ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) *
pmf_sqrt ( fabs ( t991 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ) )
) * intrm_sf_mf_1433 * 0.64 ; t719 [ 0ULL ] = X [ 74ULL ] ;
tlu2_linear_linear_prelookup ( & hg_efOut . mField0 [ 0ULL ] , & hg_efOut .
mField1 [ 0ULL ] , & hg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = hg_efOut ; tlu2_1d_linear_linear_value ( & ig_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ig_efOut [
0 ] ; intrm_sf_mf_9 = t710_idx_0 ; if ( X [ 76ULL ] <= 0.0 ) { t790 = 0.0 ; }
else { t790 = X [ 76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <=
0.0 ) { t987 = 0.0 ; } else { t987 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ;
} t989 = ( ( ( 1.0 - t790 ) - t987 ) * 296.802103844292 + t790 * 461.523 ) +
t987 * 4124.48151675695 ; t992 = U_idx_4 * 0.01 ; t993 = pmf_sqrt ( t992 *
t992 + 1.4768645655431184E-13 ) ; tlu2_1d_linear_linear_value ( & jg_efOut [
0ULL ] , & t60 . mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t710_idx_0 = jg_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 = t710_idx_0
; tlu2_1d_linear_linear_value ( & kg_efOut [ 0ULL ] , & t60 . mField0 [ 0ULL
] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = kg_efOut [ 0 ] ; t790 = (
( ( ( 1.0 - t790 ) - t987 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 +
intrm_sf_mf_9 * t790 ) + t710_idx_0 * t987 ) - X [ 74ULL ] * t989 * 0.001 ;
t987 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 - X [
74ULL ] * 0.296802103844292 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 = t710_idx_0
- X [ 74ULL ] * 4.12448151675695 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 =
intrm_sf_mf_9 - X [ 74ULL ] * 0.461523 ; if ( X [ 576ULL ] <= 0.0 ) {
intrm_sf_mf_9 = 0.0 ; } else { intrm_sf_mf_9 = X [ 576ULL ] >= 1.0 ? 1.0 : X
[ 576ULL ] ; } if ( X [ 575ULL ] <= 0.0 ) { intrm_sf_mf_10 = 0.0 ; } else {
intrm_sf_mf_10 = X [ 575ULL ] >= 1.0 ? 1.0 : X [ 575ULL ] ; } zc_int367 = ( (
( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * 296.802103844292 + intrm_sf_mf_9
* 461.523 ) + intrm_sf_mf_10 * 4124.48151675695 ; t719 [ 0ULL ] = X [ 570ULL
] ; tlu2_linear_linear_prelookup ( & lg_efOut . mField0 [ 0ULL ] , & lg_efOut
. mField1 [ 0ULL ] , & lg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = lg_efOut ; tlu2_1d_linear_linear_value ( & mg_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = mg_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & ng_efOut [ 0ULL ] , & t68 . mField0 [
0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = ng_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & og_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = og_efOut [ 0 ] ; zc_int366
= ( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t710_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t706_idx_0 * intrm_sf_mf_10 ; t719 [ 0ULL ] = X [ 573ULL ]
; tlu2_linear_linear_prelookup ( & pg_efOut . mField0 [ 0ULL ] , & pg_efOut .
mField1 [ 0ULL ] , & pg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = pg_efOut ; tlu2_1d_linear_linear_value ( & qg_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = qg_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & rg_efOut [ 0ULL ] , & t55 . mField0 [
0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = rg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & sg_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = sg_efOut [ 0 ] ; zc_int365
= ( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t710_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t706_idx_0 * intrm_sf_mf_10 ; t719 [ 0ULL ] = X [ 571ULL ]
; tlu2_linear_linear_prelookup ( & tg_efOut . mField0 [ 0ULL ] , & tg_efOut .
mField1 [ 0ULL ] , & tg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t52 = tg_efOut ; tlu2_1d_linear_linear_value ( & ug_efOut [ 0ULL ] , & t52 .
mField0 [ 0ULL ] , & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = ug_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & vg_efOut [ 0ULL ] , & t52 . mField0 [
0ULL ] , & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = vg_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & wg_efOut [ 0ULL ] , & t52 . mField0 [ 0ULL ]
, & t52 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = wg_efOut [ 0 ] ; zc_int42 =
( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t710_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t706_idx_0 * intrm_sf_mf_10 ; t719 [ 0ULL ] = X [ 572ULL ]
; tlu2_linear_linear_prelookup ( & xg_efOut . mField0 [ 0ULL ] , & xg_efOut .
mField1 [ 0ULL ] , & xg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = xg_efOut ; tlu2_1d_linear_linear_value ( & yg_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = yg_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & ah_efOut [ 0ULL ] , & t55 . mField0 [
0ULL ] , & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = ah_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & bh_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = bh_efOut [ 0 ] ; zc_int43 =
( ( ( 1.0 - intrm_sf_mf_9 ) - intrm_sf_mf_10 ) * t710_idx_0 + U_idx_1 *
intrm_sf_mf_9 ) + t706_idx_0 * intrm_sf_mf_10 ; intrm_sf_mf_9 = U_idx_2 >=
0.0 ? U_idx_2 : - U_idx_2 ; t994 = intrm_sf_mf_9 * 0.01 ; t995 =
intermediate_der9543 * 7.8539816339744827E-5 ; intrm_sf_mf_10 = t994 / ( t995
== 0.0 ? 1.0E-16 : t995 ) ; intrm_sf_mf_11 = intrm_sf_mf_10 >= 2000.0 ?
intrm_sf_mf_10 : 1.0 ; t996 = pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ?
1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* 3.24 ; t996 = 1.0 / ( t996 == 0.0 ? 1.0E-16 : t996 ) * 0.55 / 0.01 ; t999 =
intermediate_der8470 * 1.5707963267948965E-8 ; t1000 = intrm_sf_mf_1324 +
t952 ; t1002 = t1000 / 2.0 * 0.00093750000000000007 ; intrm_sf_mf_1324 = t953
/ ( t1002 == 0.0 ? 1.0E-16 : t1002 ) ; t953 = intrm_sf_mf_1324 >= 0.0 ?
intrm_sf_mf_1324 : - intrm_sf_mf_1324 ; t998 = t953 > 1000.0 ? t953 : 1000.0
; t1003 = t951 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; if ( t1003 /
2.0 > 0.5 ) { t1002 = ( t951 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; }
else { t1002 = 0.5 ; } t1005 = pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 :
t998 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16
: t998 ) + 0.00069701528436089772 ) * 3.24 ; t1004 = 1.0 / ( t1005 == 0.0 ?
1.0E-16 : t1005 ) ; t1007 = ( pmf_pow ( t1002 , 0.66666666666666663 ) - 1.0 )
* pmf_sqrt ( t1004 / 8.0 ) * 12.7 + 1.0 ; t1005 = ( t998 - 1000.0 ) * ( t1004
/ 8.0 ) * t1002 / ( t1007 == 0.0 ? 1.0E-16 : t1007 ) ; t1006 = ( t953 -
2000.0 ) / 2000.0 ; t1008 = t1006 * t1006 * 3.0 - t1006 * t1006 * t1006 * 2.0
; if ( t953 <= 2000.0 ) { intrm_sf_mf_1332 = 3.66 ; } else if ( t953 >=
4000.0 ) { intrm_sf_mf_1332 = t1005 ; } else { intrm_sf_mf_1332 = ( 1.0 -
t1008 ) * 3.66 + t1005 * t1008 ; } t1009 = intrm_sf_mf_1332 *
1.3250000000000002 ; t1012 = t1003 / 2.0 ; if ( t953 > t1009 /
0.00093750000000000007 / ( t1012 == 0.0 ? 1.0E-16 : t1012 ) / 30.0 ) { t1018
= ( t951 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) /
2.0 ; t1011 = intrm_sf_mf_1332 * 1.3250000000000002 / ( t953 == 0.0 ? 1.0E-16
: t953 ) / 0.00093750000000000007 / ( t1018 == 0.0 ? 1.0E-16 : t1018 ) ; }
else { t1011 = 30.0 ; } t1012 = ( X [ 62ULL ] - X [ 450ULL ] ) * ( 1.0 -
pmf_exp ( - t1011 ) ) ; t1019 = intrm_sf_mf_1324 * 0.00093750000000000007 ;
t1021 = U_idx_3 + U_idx_7 ; t1022 = intrm_sf_mf_1337 + t952 ; t1024 = t1022 /
2.0 * 0.00093750000000000007 ; intrm_sf_mf_1336 = - intrm_sf_mf_1336 *
0.0028301886792452828 / ( t1024 == 0.0 ? 1.0E-16 : t1024 ) ; intrm_sf_mf_1337
= intrm_sf_mf_1336 >= 0.0 ? intrm_sf_mf_1336 : - intrm_sf_mf_1336 ; t1013 =
intrm_sf_mf_1337 > 1000.0 ? intrm_sf_mf_1337 : 1000.0 ; t1025 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ; if ( t1025 /
2.0 > 0.5 ) { t1014 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ; }
else { t1014 = 0.5 ; } t1027 = pmf_log10 ( 6.9 / ( t1013 == 0.0 ? 1.0E-16 :
t1013 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1013 == 0.0 ?
1.0E-16 : t1013 ) + 0.00069701528436089772 ) * 3.24 ; t1015 = 1.0 / ( t1027
== 0.0 ? 1.0E-16 : t1027 ) ; t1029 = ( pmf_pow ( t1014 , 0.66666666666666663
) - 1.0 ) * pmf_sqrt ( t1015 / 8.0 ) * 12.7 + 1.0 ; t1016 = ( t1013 - 1000.0
) * ( t1015 / 8.0 ) * t1014 / ( t1029 == 0.0 ? 1.0E-16 : t1029 ) ; t1017 = (
intrm_sf_mf_1337 - 2000.0 ) / 2000.0 ; t1018 = t1017 * t1017 * 3.0 - t1017 *
t1017 * t1017 * 2.0 ; if ( intrm_sf_mf_1337 <= 2000.0 ) { t1023 = 3.66 ; }
else if ( intrm_sf_mf_1337 >= 4000.0 ) { t1023 = t1016 ; } else { t1023 = (
1.0 - t1018 ) * 3.66 + t1016 * t1018 ; } t1031 = t1023 * 1.3250000000000002 ;
t1034 = t1025 / 2.0 ; if ( intrm_sf_mf_1337 > t1031 / 0.00093750000000000007
/ ( t1034 == 0.0 ? 1.0E-16 : t1034 ) / 30.0 ) { U_idx_1 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ;
t1024 = t1023 * 1.3250000000000002 / ( intrm_sf_mf_1337 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1337 ) / 0.00093750000000000007 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ; } else { t1024 = 30.0 ; } t1026 = ( X [ 62ULL ] - X [ 436ULL ] )
* ( 1.0 - pmf_exp ( - t1024 ) ) ; t1041 = intrm_sf_mf_1336 *
0.00093750000000000007 ; t1043 = intrm_sf_mf_1348 + U_idx_7 ;
intrm_sf_mf_1348 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 - - 20.0 ) /
40.0 ; t1027 = intrm_sf_mf_1348 * intrm_sf_mf_1348 * 3.0 - intrm_sf_mf_1348 *
intrm_sf_mf_1348 * intrm_sf_mf_1348 * 2.0 ; t1028 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 >= 0.0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 ; t1030 =
t1028 * 0.0028301886792452828 / ( t954 == 0.0 ? 1.0E-16 : t954 ) ; t1033 =
t1030 >= 1.0 ? t1030 : 1.0 ; t1047 = pmf_log10 ( 6.9 / ( t1033 == 0.0 ?
1.0E-16 : t1033 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1033 ==
0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772 ) * 3.24 ; t1034 = 1.0 / (
t1047 == 0.0 ? 1.0E-16 : t1047 ) ; t1049 = U_idx_10 * 1.50186899252403E-8 ;
t1051 = U_idx_10 * 4.97494103773585E-9 ; t1036 = ( t1030 - 2000.0 ) / 2000.0
; t1037 = t1036 * t1036 * 3.0 - t1036 * t1036 * t1036 * 2.0 ; t1054 =
intermediate_der8470 * 1.2337005501361696E-8 ; intermediate_der8470 = (
intrm_sf_mf_10 - 2000.0 ) / 2000.0 ; t1057 = t978 - ( - t978 ) ; t1039 = ( (
X [ 64ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0
) - ( - t978 ) ) / ( t1057 == 0.0 ? 1.0E-16 : t1057 ) ; t1044 =
intermediate_der8470 * intermediate_der8470 * 3.0 - intermediate_der8470 *
intermediate_der8470 * intermediate_der8470 * 2.0 ; if ( X [ 555ULL ] <= 0.0
) { intermediate_der0 = 0.0 ; } else { intermediate_der0 = X [ 555ULL ] >=
1.0 ? 1.0 : X [ 555ULL ] ; } if ( X [ 554ULL ] <= 0.0 ) { t1047 = 0.0 ; }
else { t1047 = X [ 554ULL ] >= 1.0 ? 1.0 : X [ 554ULL ] ; } zc_int360 = ( ( (
1.0 - intermediate_der0 ) - t1047 ) * 296.802103844292 + intermediate_der0 *
461.523 ) + t1047 * 4124.48151675695 ; t719 [ 0ULL ] = X [ 553ULL ] ;
tlu2_linear_linear_prelookup ( & ch_efOut . mField0 [ 0ULL ] , & ch_efOut .
mField1 [ 0ULL ] , & ch_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = ch_efOut ; tlu2_1d_linear_linear_value ( & dh_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = dh_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & eh_efOut [ 0ULL ] , & t60 . mField0 [
0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = eh_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & fh_efOut [ 0ULL ] , & t60 . mField0 [ 0ULL ]
, & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = fh_efOut [ 0 ] ; zc_int364
= ( ( ( 1.0 - intermediate_der0 ) - t1047 ) * t710_idx_0 + U_idx_1 *
intermediate_der0 ) + t706_idx_0 * t1047 ; t719 [ 0ULL ] = X [ 175ULL ] ;
tlu2_linear_linear_prelookup ( & gh_efOut . mField0 [ 0ULL ] , & gh_efOut .
mField1 [ 0ULL ] , & gh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t68 = gh_efOut ; tlu2_1d_linear_linear_value ( & hh_efOut [ 0ULL ] , & t68 .
mField0 [ 0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = hh_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & ih_efOut [ 0ULL ] , & t68 . mField0 [
0ULL ] , & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; U_idx_1 = ih_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & jh_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t706_idx_0 = jh_efOut [ 0 ] ;
intermediate_der0 = ( ( ( 1.0 - t848 ) - t850 ) * t710_idx_0 + U_idx_1 * t848
) + t706_idx_0 * t850 ; if ( - U_idx_2 >= 0.0 ) { t850 = - U_idx_2 ; } else {
t850 = U_idx_2 ; } t1060 = t850 * 0.01 ; t1047 = t1060 / ( t995 == 0.0 ?
1.0E-16 : t995 ) ; t1052 = t1047 >= 2000.0 ? t1047 : 1.0 ; t1062 = pmf_log10
( 6.9 / ( t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715
) * 3.24 ; t1053 = 1.0 / ( t1062 == 0.0 ? 1.0E-16 : t1062 ) * 0.55 / 0.01 ;
t1055 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >=
0.0 ? Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 : -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t1056 =
t1055 * 0.01 / ( t845 == 0.0 ? 1.0E-16 : t845 ) ; t1058 = t1056 >= 1.0 ?
t1056 : 1.0 ; t1066 = pmf_log10 ( 6.9 / ( t1058 == 0.0 ? 1.0E-16 : t1058 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1058 == 0.0 ? 1.0E-16 : t1058
) + 0.00017169489553429715 ) * 3.24 ; t1062 = 1.0 / ( t1066 == 0.0 ? 1.0E-16
: t1066 ) ; t1063 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der8955 * 35.2 / ( t849 == 0.0 ? 1.0E-16 : t849 ) ; t1066 = (
t1056 - 2000.0 ) / 2000.0 ; t1067 = t1066 * t1066 * 3.0 - t1066 * t1066 *
t1066 * 2.0 ; t1069 = U_idx_2 * intermediate_der9543 * - 35.2 / ( t999 == 0.0
? 1.0E-16 : t999 ) * 1.0E-5 ; t1072 = ( t1047 - 2000.0 ) / 2000.0 ; t1074 =
t1072 * t1072 * 3.0 - t1072 * t1072 * t1072 * 2.0 ; t1078 =
intermediate_der10249 * 7.8539816339744827E-5 ; t1076 = t994 / ( t1078 == 0.0
? 1.0E-16 : t1078 ) ; intrm_sf_mf_32 = t1076 >= 2000.0 ? t1076 : 1.0 ; t1079
= pmf_log10 ( 6.9 / ( intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_32 == 0.0 ?
1.0E-16 : intrm_sf_mf_32 ) + 0.00017169489553429715 ) * 3.24 ; t1079 = 1.0 /
( t1079 == 0.0 ? 1.0E-16 : t1079 ) * 0.55 / 0.01 ; t1082 =
intermediate_der9401 * 1.5707963267948965E-8 ; t1084 = intermediate_der9401 *
1.2337005501361696E-8 ; intermediate_der9401 = ( t1076 - 2000.0 ) / 2000.0 ;
t1083 = intermediate_der9401 * intermediate_der9401 * 3.0 -
intermediate_der9401 * intermediate_der9401 * intermediate_der9401 * 2.0 ;
t1085 = t1060 / ( t1078 == 0.0 ? 1.0E-16 : t1078 ) ; intrm_sf_mf_41 = t1085
>= 2000.0 ? t1085 : 1.0 ; t1088 = pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ?
1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 )
* 3.24 ; t1088 = 1.0 / ( t1088 == 0.0 ? 1.0E-16 : t1088 ) * 0.55 / 0.01 ;
t1089 = U_idx_2 * intermediate_der10249 * - 35.2 / ( t1082 == 0.0 ? 1.0E-16 :
t1082 ) * 1.0E-5 ; t1092 = ( t1085 - 2000.0 ) / 2000.0 ; t1094 = t1092 *
t1092 * 3.0 - t1092 * t1092 * t1092 * 2.0 ; t1096 = intermediate_der10838 *
7.8539816339744827E-5 ; intrm_sf_mf_52 = t994 / ( t1096 == 0.0 ? 1.0E-16 :
t1096 ) ; t994 = intrm_sf_mf_52 >= 2000.0 ? intrm_sf_mf_52 : 1.0 ; t1097 =
pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16 : t994 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16 : t994 ) + 0.00017169489553429715
) * 3.24 ; t1097 = 1.0 / ( t1097 == 0.0 ? 1.0E-16 : t1097 ) * 0.55 / 0.01 ;
t1100 = intrm_sf_mf_56 * 1.5707963267948965E-8 ; t1102 = intrm_sf_mf_56 *
1.2337005501361696E-8 ; t1099 = ( intrm_sf_mf_52 - 2000.0 ) / 2000.0 ; t1101
= t1099 * t1099 * 3.0 - t1099 * t1099 * t1099 * 2.0 ; t1103 = t1060 / ( t1096
== 0.0 ? 1.0E-16 : t1096 ) ; t1060 = t1103 >= 2000.0 ? t1103 : 1.0 ; t1106 =
pmf_log10 ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) +
0.00017169489553429715 ) * 3.24 ; t1106 = 1.0 / ( t1106 == 0.0 ? 1.0E-16 :
t1106 ) * 0.55 / 0.01 ; t1110 = ( t1103 - 2000.0 ) / 2000.0 ; t1112 = t1110 *
t1110 * 3.0 - t1110 * t1110 * t1110 * 2.0 ; t1114 = t935 - ( - t935 ) ;
intrm_sf_mf_864 = ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) -
( - t935 ) ) / ( t1114 == 0.0 ? 1.0E-16 : t1114 ) ; zc_int10 = pmf_sqrt (
intermediate_der10338 * intermediate_der10338 * 9.999999999999999E-14 + ( (
real_T ) ( M [ 32ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 199ULL ] * t839 *
intrm_sf_mf_95 * 1.0E-9 ) ; if ( M [ 310ULL ] != 0 ) { zc_int116 =
216.59999999999997 ; } else { zc_int116 = M [ 311ULL ] != 0 ? 623.15 :
U_idx_6 ; } t719 [ 0ULL ] = U_idx_5 >= 0.0 ? zc_int116 : X [ 34ULL ] ;
tlu2_linear_linear_prelookup ( & kh_efOut . mField0 [ 0ULL ] , & kh_efOut .
mField1 [ 0ULL ] , & kh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t60 = kh_efOut ; tlu2_1d_linear_linear_value ( & lh_efOut [ 0ULL ] , & t60 .
mField0 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = lh_efOut [
0 ] ; zc_int116 = t710_idx_0 ; zc_int186 = - pmf_sqrt ( ( ( real_T ) ( M [
50ULL ] != 0 ) * 2.0 - 1.0 ) * ( t841 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 :
intrm_sf_mf_95 ) / ( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) *
7.8539816339744827E-5 ; t841 = intermediate_der8955 * zc_int186 * 35.2 / (
t849 == 0.0 ? 1.0E-16 : t849 ) ; if ( intermediate_der11472 >= 0.0 ) {
U_idx_3 = zc_int186 * 100000.0 ; } else { U_idx_3 = - zc_int186 * 100000.0 ;
} intermediate_der11472 = U_idx_3 * 0.01 / ( t845 == 0.0 ? 1.0E-16 : t845 ) ;
t1118 = pmf_sqrt ( zc_int179 * zc_int179 * 9.999999999999999E-14 + ( ( real_T
) ( M [ 326ULL ] != 0 ) * 2.0 - 1.0 ) * X [ 330ULL ] * zc_int17 * zc_int174 *
1.0E-9 ) ; zc_int17 = intermediate_der11539 >= 1.0 ? intermediate_der11472 :
1.0 ; zc_int174 = - pmf_sqrt ( ( ( real_T ) ( M [ 328ULL ] != 0 ) * 2.0 - 1.0
) * ( t923 / ( zc_int174 == 0.0 ? 1.0E-16 : zc_int174 ) / ( X [ 330ULL ] ==
0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) * 0.0019634954084936209 ; zc_int179 =
zc_int180 * zc_int174 * 35.2 / ( t929 == 0.0 ? 1.0E-16 : t929 ) ; t1127 =
pmf_log10 ( 6.9 / ( zc_int17 == 0.0 ? 1.0E-16 : zc_int17 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( zc_int17 == 0.0 ? 1.0E-16 :
zc_int17 ) + 0.00017169489553429715 ) * 3.24 ; if ( zc_int184 >= 0.0 ) {
zc_int180 = zc_int174 * 100000.0 ; } else { zc_int180 = - zc_int174 *
100000.0 ; } zc_int184 = zc_int180 * 0.05 / ( t927 == 0.0 ? 1.0E-16 : t927 )
; U_idx_1 = t917 >= 1.0 ? zc_int184 : 1.0 ; U_idx_1 = pmf_log10 ( 6.9 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) + 2.8767404433520813E-5 ) * pmf_log10 (
6.9 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) + 2.8767404433520813E-5 ) * 3.24
; zc_int174 = zc_int174 * zc_int180 * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 :
U_idx_1 ) ) * 0.55 / ( t932 == 0.0 ? 1.0E-16 : t932 ) ; zc_int180 = (
zc_int184 - 2000.0 ) / 2000.0 ; zc_int184 = zc_int180 * zc_int180 * 3.0 -
zc_int180 * zc_int180 * zc_int180 * 2.0 ; if ( t917 <= 2000.0 ) { zc_int180 =
zc_int179 * 1.0E-5 ; } else if ( t917 >= 4000.0 ) { zc_int180 = zc_int174 *
1.0E-5 ; } else { zc_int180 = ( ( 1.0 - zc_int184 ) * zc_int179 + zc_int174 *
zc_int184 ) * 1.0E-5 ; } zc_int174 = - ( X [ 313ULL ] * t1118 ) /
0.0019634954084936209 * 0.00031622776601683789 + zc_int180 ; intrm_sf_mf_56 =
- zc_int174 - zc_int174 * - 0.95 ; zc_int179 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 - zc_int174 *
- 0.95 ) / ( intrm_sf_mf_56 == 0.0 ? 1.0E-16 : intrm_sf_mf_56 ) ; zc_int17 =
zc_int186 * U_idx_3 * ( 1.0 / ( t1127 == 0.0 ? 1.0E-16 : t1127 ) ) * 0.55 / (
t852 == 0.0 ? 1.0E-16 : t852 ) ; zc_int184 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 - 1.0 ) * ( t950 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * t920 * 0.64 ; t917 = pmf_sqrt ( ( ( real_T ) ( M [ 334ULL ] != 0 ) * 2.0
- 1.0 ) * ( t947 / ( t928 == 0.0 ? 1.0E-16 : t928 ) / ( X [ 343ULL ] == 0.0 ?
1.0E-16 : X [ 343ULL ] ) ) ) * t920 * 0.64 ; t1144 = t917 - t917 * 0.95 ;
zc_int186 = ( zc_int184 - t917 * 0.95 ) / ( t1144 == 0.0 ? 1.0E-16 : t1144 )
; t1118 = ( - zc_int184 - t917 * 0.95 ) / ( t1144 == 0.0 ? 1.0E-16 : t1144 )
; intermediate_der11472 = ( intermediate_der11472 - 2000.0 ) / 2000.0 ; t923
= intermediate_der11472 * intermediate_der11472 * 3.0 - intermediate_der11472
* intermediate_der11472 * intermediate_der11472 * 2.0 ; if (
intermediate_der11539 <= 2000.0 ) { intermediate_der11472 = t841 * 1.0E-5 ; }
else if ( intermediate_der11539 >= 4000.0 ) { intermediate_der11472 =
zc_int17 * 1.0E-5 ; } else { intermediate_der11472 = ( ( 1.0 - t923 ) * t841
+ zc_int17 * t923 ) * 1.0E-5 ; } intermediate_der11539 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * zc_int10 /
7.8539816339744827E-5 * 0.00031622776601683789 + intermediate_der11472 ;
t1150 = - intermediate_der11539 - intermediate_der11539 * - 0.95 ;
intermediate_der11472 = ( - t842 - intermediate_der11539 * - 0.95 ) / ( t1150
== 0.0 ? 1.0E-16 : t1150 ) ; if ( M [ 355ULL ] != 0 ) { t841 =
216.59999999999997 ; } else { t841 = M [ 356ULL ] != 0 ? 623.15 : U_idx_9 ; }
t719 [ 0ULL ] = U_idx_8 >= 0.0 ? t841 : X [ 51ULL ] ;
tlu2_linear_linear_prelookup ( & mh_efOut . mField0 [ 0ULL ] , & mh_efOut .
mField1 [ 0ULL ] , & mh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t32 = mh_efOut ; tlu2_1d_linear_linear_value ( & nh_efOut [ 0ULL ] , & t32 .
mField0 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = nh_efOut [
0 ] ; t841 = t710_idx_0 ; t923 = pmf_sqrt ( t955 * t955 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 12ULL ] != 0 ) * 2.0 - 1.0 ) * X [
488ULL ] * zc_int321 * zc_int322 * 1.0E-9 ) ; zc_int321 = - pmf_sqrt ( ( (
real_T ) ( M [ 15ULL ] != 0 ) * 2.0 - 1.0 ) * ( t961 / ( zc_int322 == 0.0 ?
1.0E-16 : zc_int322 ) / ( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) )
* 7.8539816339744827E-5 ; zc_int322 = t787 * zc_int321 * 35.2 / ( U_idx_11 ==
0.0 ? 1.0E-16 : U_idx_11 ) ; if ( zc_int341 >= 0.0 ) { t955 = zc_int321 *
100000.0 ; } else { t955 = - zc_int321 * 100000.0 ; } zc_int341 = t955 * 0.01
/ ( t965 == 0.0 ? 1.0E-16 : t965 ) ; t787 = t960 >= 1.0 ? zc_int341 : 1.0 ;
t1173 = pmf_log10 ( 6.9 / ( t787 == 0.0 ? 1.0E-16 : t787 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t787 == 0.0 ? 1.0E-16 : t787 )
+ 0.00017169489553429715 ) * 3.24 ; zc_int321 = zc_int321 * t955 * ( 1.0 / (
t1173 == 0.0 ? 1.0E-16 : t1173 ) ) * 0.55 / ( t972 == 0.0 ? 1.0E-16 : t972 )
; t955 = ( zc_int341 - 2000.0 ) / 2000.0 ; zc_int341 = t955 * t955 * 3.0 -
t955 * t955 * t955 * 2.0 ; if ( t960 <= 2000.0 ) { t955 = zc_int322 * 1.0E-5
; } else if ( t960 >= 4000.0 ) { t955 = zc_int321 * 1.0E-5 ; } else { t955 =
( ( 1.0 - zc_int341 ) * zc_int322 + zc_int321 * zc_int341 ) * 1.0E-5 ; }
zc_int321 = - ( X [ 478ULL ] * t923 ) / 7.8539816339744827E-5 *
0.00031622776601683789 + t955 ; t1164 = - zc_int321 - zc_int321 * - 0.95 ;
zc_int322 = ( - t959 - zc_int321 * - 0.95 ) / ( t1164 == 0.0 ? 1.0E-16 :
t1164 ) ; zc_int341 = ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) * pmf_sqrt (
( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( t991 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ) )
) * intrm_sf_mf_1433 * 0.64 ; t787 = pmf_sqrt ( ( ( real_T ) ( M [ 21ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t988 / ( t971 == 0.0 ? 1.0E-16 : t971 ) / ( X [ 506ULL
] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) * intrm_sf_mf_1433 * 0.64 ; t1170 =
t787 - t787 * 0.95 ; t960 = ( zc_int341 - t787 * 0.95 ) / ( t1170 == 0.0 ?
1.0E-16 : t1170 ) ; t927 = ( - zc_int341 - t787 * 0.95 ) / ( t1170 == 0.0 ?
1.0E-16 : t1170 ) ; t1173 = X [ 553ULL ] * zc_int360 ; zc_int360 = ( ( real_T
) ( M [ 36ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1173 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( t1173 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [
38ULL ] ) ) * ( t992 / 7.8539816339744827E-5 ) * ( t992 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + zc_int364 ; t1178 = X
[ 175ULL ] * t851 ; t932 = ( ( real_T ) ( M [ 36ULL ] != 0 ) * 2.0 - 1.0 ) *
( t1173 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t1173 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - t992 / 7.8539816339744827E-5
) * ( - t992 / 7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 +
zc_int364 ; U_idx_11 = X [ 573ULL ] * zc_int367 ; zc_int364 = ( ( real_T ) (
M [ 40ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [
38ULL ] ) ) * ( t992 / 7.8539816339744827E-5 ) * ( t992 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + zc_int365 ; U_idx_4 =
X [ 570ULL ] * zc_int367 ; zc_int365 = ( ( real_T ) ( M [ 41ULL ] != 0 ) *
2.0 - 1.0 ) * ( U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) )
* ( U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t992 /
7.8539816339744827E-5 ) * ( t992 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + zc_int366 ; t706_idx_0 = X [ 572ULL ] * zc_int367 ;
zc_int366 = ( ( real_T ) ( M [ 42ULL ] != 0 ) * 2.0 - 1.0 ) * ( t706_idx_0 /
( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t706_idx_0 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( - t992 /
7.8539816339744827E-5 ) * ( - t992 / 7.8539816339744827E-5 ) / 2.0 *
9.999999999999999E-14 + zc_int43 ; t848 = X [ 571ULL ] * zc_int367 ;
zc_int367 = ( ( real_T ) ( M [ 43ULL ] != 0 ) * 2.0 - 1.0 ) * ( t848 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t848 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) * ( - t992 / 7.8539816339744827E-5 ) * ( - t992 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + zc_int42 ; zc_int42 =
( X [ 195ULL ] - 1.01325 ) * pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) *
2.0 - 1.0 ) * ( t914 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t891 * 0.64 ; zc_int43 = pmf_sqrt ( ( ( real_T ) ( M [ 137ULL ] != 0 ) *
2.0 - 1.0 ) * ( t911 / ( t895 == 0.0 ? 1.0E-16 : t895 ) / ( X [ 219ULL ] ==
0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) * t891 * 0.64 ; U_idx_6 = zc_int43 -
zc_int43 * 0.95 ; t947 = ( zc_int42 - zc_int43 * 0.95 ) / ( U_idx_6 == 0.0 ?
1.0E-16 : U_idx_6 ) ; t929 = t947 * t947 * 3.0 - t947 * t947 * t947 * 2.0 ;
t961 = ( - zc_int42 - zc_int43 * 0.95 ) / ( U_idx_6 == 0.0 ? 1.0E-16 :
U_idx_6 ) ; t965 = t961 * t961 * 3.0 - t961 * t961 * t961 * 2.0 ; t988 = - (
real_T ) ( t791 >= 0.0 ) * 1000.0 / 0.099999999999999978 ; if ( ( real_T ) (
t791 >= 0.0 ) * t791 * 1000.0 + ( real_T ) ( t791 < 0.0 ) * X [ 81ULL ] <=
0.9 ) { t73 = 0.0 ; } else { t73 = ( real_T ) ( t791 >= 0.0 ) * t791 * 1000.0
+ ( real_T ) ( t791 < 0.0 ) * X [ 81ULL ] >= 1.0 ? 0.0 : t988 * t73 * 6.0 -
t73 * t73 * t988 * 6.0 ; } zc_int17 = pmf_sqrt ( U_idx_2 * U_idx_2 +
4.5311819630628225E-12 ) * 2.0 ; t791 = 1.0 / ( zc_int17 == 0.0 ? 1.0E-16 :
zc_int17 ) * U_idx_2 * 2.0 ; zc_int180 = t1922 * t1922 ; t988 = ( - U_idx_2 /
( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 + 1.0 / ( t1922 == 0.0 ?
1.0E-16 : t1922 ) ) * X [ 93ULL ] / ( t1936 == 0.0 ? 1.0E-16 : t1936 ) ;
t1936 = - ( - U_idx_2 / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 +
1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) / 2.0 ; t923 = ( - U_idx_2 / (
zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 + 1.0 / ( t1922 == 0.0 ?
1.0E-16 : t1922 ) ) / 2.0 ; t955 = 1.0 / ( zc_int17 == 0.0 ? 1.0E-16 :
zc_int17 ) * U_idx_2 * 2.0 ; t972 = t1922 * t1922 ; zc_int17 = ( U_idx_2 / (
t972 == 0.0 ? 1.0E-16 : t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ? 1.0E-16 :
t1922 ) ) * X [ 95ULL ] / ( t1901 == 0.0 ? 1.0E-16 : t1901 ) ; t1901 = - (
U_idx_2 / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ?
1.0E-16 : t1922 ) ) / 2.0 ; t1127 = ( U_idx_2 / ( t972 == 0.0 ? 1.0E-16 :
t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) / 2.0 ; U_idx_9
= ( - U_idx_2 / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 + 1.0 / (
t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [ 102ULL ] / ( t1903 == 0.0 ? 1.0E-16
: t1903 ) ; t1903 = ( U_idx_2 / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 + -
1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [ 104ULL ] / ( t1908 == 0.0 ?
1.0E-16 : t1908 ) ; t1908 = ( - U_idx_2 / ( zc_int180 == 0.0 ? 1.0E-16 :
zc_int180 ) * t791 + 1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [ 111ULL
] / ( t1830 == 0.0 ? 1.0E-16 : t1830 ) ; t1830 = ( U_idx_2 / ( t972 == 0.0 ?
1.0E-16 : t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [
113ULL ] / ( intermediate_der149 == 0.0 ? 1.0E-16 : intermediate_der149 ) ;
intermediate_der149 = 1.0 ; U_idx_7 = ( intermediate_der197 >= 0.0 ?
intermediate_der149 : - intermediate_der149 ) * 0.01 ; intermediate_der149 =
U_idx_7 / ( t1282 == 0.0 ? 1.0E-16 : t1282 ) ; t851 = ( 6.9 / (
intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; U_idx_3 = pmf_log10 ( 6.9 / (
intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ?
1.0E-16 : intermediate_der239 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( intermediate_der239 == 0.0 ? 1.0E-16 : intermediate_der239 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ?
1.0E-16 : intermediate_der239 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_1 = intermediate_der239 * intermediate_der239 ;
t1282 = - 1.0 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * ( - 6.9 / ( U_idx_1
== 0.0 ? 1.0E-16 : U_idx_1 ) ) * ( 1.0 / ( t851 == 0.0 ? 1.0E-16 : t851 ) ) *
pmf_log10 ( 6.9 / ( intermediate_der239 == 0.0 ? 1.0E-16 :
intermediate_der239 ) + 0.00017169489553429715 ) * ( t798 >= 2000.0 ?
intermediate_der149 : 0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt ( intermediate_der242
/ 8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ) * ( ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der242 / 8.0 ) * 12.7
+ 1.0 ) ; intermediate_der197 = ( pmf_pow (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ,
0.66666666666666663 ) - 1.0 ) * ( - ( ( t799 - 1000.0 ) * (
intermediate_der242 / 8.0 ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) / ( U_idx_3 ==
0.0 ? 1.0E-16 : U_idx_3 ) ) * ( t1282 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t799 - 1000.0 ) * ( t1282 / 8.0 ) +
intermediate_der242 / 8.0 * ( t798 > 1000.0 ? intermediate_der149 : 0.0 ) ) *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg / ( t1382 == 0.0 ?
1.0E-16 : t1382 ) ; t799 = intermediate_der149 / 2000.0 ; intermediate_der239
= t799 * intermediate_der358 * 6.0 - intermediate_der358 *
intermediate_der358 * t799 * 6.0 ; if ( t798 <= 2000.0 ) { t799 = 0.0 ; }
else if ( t798 >= 4000.0 ) { t799 = intermediate_der197 ; } else { t799 = ( -
intermediate_der239 * 3.66 + t802 * intermediate_der239 ) +
intermediate_der197 * t805 ; } t851 = ( t798 + 1.0 ) * ( t798 + 1.0 ) ; t1282
= ( - ( intermediate_der349 * 0.031415926535897927 ) / ( t851 == 0.0 ?
1.0E-16 : t851 ) * intermediate_der149 + t799 * 0.031415926535897927 / ( t798
+ 1.0 == 0.0 ? 1.0E-16 : t798 + 1.0 ) ) / 7.8539816339744827E-5 ; t799 = 1.0
- pmf_exp ( - t806 ) ; intermediate_der239 = - ( - ( t1282 / (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) ) * pmf_exp ( -
t806 ) ) * ( U_idx_0 - t797 ) ; t851 = t798 * 7.8539816339744827E-5 ;
U_idx_10 = intermediate_der149 * 7.8539816339744827E-5 / 0.01 *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg * t808 *
intermediate_der509 + t851 / 0.01 *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg *
intermediate_der509 * intermediate_der239 ; intermediate_der149 = t851 / 0.01
* Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg *
intermediate_der509 * t799 ; U_idx_1 = pmf_sqrt ( U_idx_2 * U_idx_2 +
1.8124727852251287E-13 ) * 2.0 ; intermediate_der197 = 1.0 / ( U_idx_1 == 0.0
? 1.0E-16 : U_idx_1 ) * U_idx_2 * 2.0 ; t1282 = intermediate_der539 *
intermediate_der539 ; t797 = ( - U_idx_2 / ( t1282 == 0.0 ? 1.0E-16 : t1282 )
* intermediate_der197 + 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 :
intermediate_der539 ) ) * X [ 113ULL ] / ( intermediate_der546 == 0.0 ?
1.0E-16 : intermediate_der546 ) ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg = - ( - U_idx_2 /
( t1282 == 0.0 ? 1.0E-16 : t1282 ) * intermediate_der197 + 1.0 / (
intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ; t798 =
( - U_idx_2 / ( t1282 == 0.0 ? 1.0E-16 : t1282 ) * intermediate_der197 + 1.0
/ ( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ;
t799 = 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) * U_idx_2 * 2.0 ; t851 =
intermediate_der539 * intermediate_der539 ; intermediate_der239 = ( U_idx_2 /
( t851 == 0.0 ? 1.0E-16 : t851 ) * t799 + - 1.0 / ( intermediate_der539 ==
0.0 ? 1.0E-16 : intermediate_der539 ) ) * X [ 120ULL ] / (
intermediate_der553 == 0.0 ? 1.0E-16 : intermediate_der553 ) ;
intermediate_der242 = - ( U_idx_2 / ( t851 == 0.0 ? 1.0E-16 : t851 ) * t799 +
- 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) /
2.0 ; t802 = ( U_idx_2 / ( t851 == 0.0 ? 1.0E-16 : t851 ) * t799 + - 1.0 / (
intermediate_der539 == 0.0 ? 1.0E-16 : intermediate_der539 ) ) / 2.0 ;
intermediate_der358 = U_idx_7 / ( t1395 == 0.0 ? 1.0E-16 : t1395 ) ; U_idx_1
= ( 6.9 / ( intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1382 = pmf_log10 ( 6.9 / (
intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ?
1.0E-16 : intermediate_der1148 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( intermediate_der1148 == 0.0 ? 1.0E-16 : intermediate_der1148 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ?
1.0E-16 : intermediate_der1148 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_3 = intermediate_der1148 * intermediate_der1148 ;
t806 = - 1.0 / ( t1382 == 0.0 ? 1.0E-16 : t1382 ) * ( - 6.9 / ( U_idx_3 ==
0.0 ? 1.0E-16 : U_idx_3 ) ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 )
) * pmf_log10 ( 6.9 / ( intermediate_der1148 == 0.0 ? 1.0E-16 :
intermediate_der1148 ) + 0.00017169489553429715 ) * ( intermediate_der1258 >=
2000.0 ? intermediate_der358 : 0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt (
intermediate_der11712 / 8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow (
intermediate_der1227 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der11712 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow (
intermediate_der1227 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der11712 / 8.0 ) * 12.7 + 1.0 ) ; t805 = ( pmf_pow (
intermediate_der1227 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t811 - 1000.0
) * ( intermediate_der11712 / 8.0 ) * intermediate_der1227 ) / ( U_idx_3 ==
0.0 ? 1.0E-16 : U_idx_3 ) ) * ( t806 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ?
1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t811 - 1000.0 ) * ( t806 / 8.0 ) +
intermediate_der11712 / 8.0 * ( intermediate_der1258 > 1000.0 ?
intermediate_der358 : 0.0 ) ) * intermediate_der1227 / ( t1423 == 0.0 ?
1.0E-16 : t1423 ) ; intermediate_der349 = intermediate_der358 / 2000.0 ; t806
= intermediate_der349 * t815 * 6.0 - t815 * t815 * intermediate_der349 * 6.0
; if ( intermediate_der1258 <= 2000.0 ) { intermediate_der349 = 0.0 ; } else
if ( intermediate_der1258 >= 4000.0 ) { intermediate_der349 = t805 ; } else {
intermediate_der349 = ( - t806 * 3.66 + t814 * t806 ) + t805 * t817 ; }
U_idx_3 = ( intermediate_der1258 + 1.0 ) * ( intermediate_der1258 + 1.0 ) ;
intermediate_der349 = - ( - ( ( - ( intermediate_der3747 *
0.031415926535897927 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) *
intermediate_der358 + intermediate_der349 * 0.031415926535897927 / (
intermediate_der1258 + 1.0 == 0.0 ? 1.0E-16 : intermediate_der1258 + 1.0 ) )
/ 7.8539816339744827E-5 / ( intermediate_der1227 == 0.0 ? 1.0E-16 :
intermediate_der1227 ) ) * pmf_exp ( - t818 ) ) * ( X [ 10ULL ] -
intermediate_der9757 ) ; intermediate_der358 = intermediate_der358 *
7.8539816339744827E-5 / 0.01 * intermediate_der1227 * t820 * t821 +
intermediate_der1258 * 7.8539816339744827E-5 / 0.01 * intermediate_der1227 *
t821 * intermediate_der349 ; t805 = ( - U_idx_2 / ( t1282 == 0.0 ? 1.0E-16 :
t1282 ) * intermediate_der197 + 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16
: intermediate_der539 ) ) * X [ 95ULL ] / ( intermediate_der5455 == 0.0 ?
1.0E-16 : intermediate_der5455 ) ; intermediate_der349 = ( U_idx_2 / ( t851
== 0.0 ? 1.0E-16 : t851 ) * t799 + - 1.0 / ( intermediate_der539 == 0.0 ?
1.0E-16 : intermediate_der539 ) ) * X [ 102ULL ] / ( intermediate_der3714 ==
0.0 ? 1.0E-16 : intermediate_der3714 ) ; t806 = U_idx_7 / ( t1425 == 0.0 ?
1.0E-16 : t1425 ) ; U_idx_1 = ( 6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1382 = pmf_log10 ( 6.9 / (
t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 /
( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_3 = t823 * t823 ; intermediate_der546 = - 1.0 / (
t1382 == 0.0 ? 1.0E-16 : t1382 ) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 :
U_idx_3 ) ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 (
6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 ) * ( t822 >=
2000.0 ? t806 : 0.0 ) * 6.48 ; U_idx_1 = pmf_sqrt ( intermediate_der5547 /
8.0 ) * 2.0 ; U_idx_3 = ( ( pmf_pow ( intermediate_der5453 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( intermediate_der5547 / 8.0 ) *
12.7 + 1.0 ) * ( ( pmf_pow ( intermediate_der5453 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( intermediate_der5547 / 8.0 ) * 12.7 + 1.0 ) ; t808 = (
pmf_pow ( intermediate_der5453 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t800
- 1000.0 ) * ( intermediate_der5547 / 8.0 ) * intermediate_der5453 ) / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( intermediate_der546 / 8.0 ) * (
1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t800 - 1000.0 ) *
( intermediate_der546 / 8.0 ) + intermediate_der5547 / 8.0 * ( t822 > 1000.0
? t806 : 0.0 ) ) * intermediate_der5453 / ( t1426 == 0.0 ? 1.0E-16 : t1426 )
; intermediate_der509 = t806 / 2000.0 ; intermediate_der546 =
intermediate_der509 * t827 * 6.0 - t827 * t827 * intermediate_der509 * 6.0 ;
if ( t822 <= 2000.0 ) { intermediate_der509 = 0.0 ; } else if ( t822 >=
4000.0 ) { intermediate_der509 = t808 ; } else { intermediate_der509 = ( -
intermediate_der546 * 3.66 + t826 * intermediate_der546 ) + t808 *
intermediate_der5551 ; } U_idx_3 = ( t822 + 1.0 ) * ( t822 + 1.0 ) ;
intermediate_der509 = - ( - ( ( - ( intermediate_der5554 *
0.031415926535897927 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * t806 +
intermediate_der509 * 0.031415926535897927 / ( t822 + 1.0 == 0.0 ? 1.0E-16 :
t822 + 1.0 ) ) / 7.8539816339744827E-5 / ( intermediate_der5453 == 0.0 ?
1.0E-16 : intermediate_der5453 ) ) * pmf_exp ( - t830 ) ) * ( X [ 12ULL ] -
intermediate_der5449 ) ; t806 = t806 * 7.8539816339744827E-5 / 0.01 *
intermediate_der5453 * t832 * intermediate_der8213 + t822 *
7.8539816339744827E-5 / 0.01 * intermediate_der5453 * intermediate_der8213 *
intermediate_der509 ; t808 = ( - U_idx_2 / ( t1282 == 0.0 ? 1.0E-16 : t1282 )
* intermediate_der197 + 1.0 / ( intermediate_der539 == 0.0 ? 1.0E-16 :
intermediate_der539 ) ) * X [ 104ULL ] / ( intermediate_der5591 == 0.0 ?
1.0E-16 : intermediate_der5591 ) ; intermediate_der509 = ( U_idx_2 / ( t851
== 0.0 ? 1.0E-16 : t851 ) * t799 + - 1.0 / ( intermediate_der539 == 0.0 ?
1.0E-16 : intermediate_der539 ) ) * X [ 111ULL ] / ( intermediate_der5594 ==
0.0 ? 1.0E-16 : intermediate_der5594 ) ; intermediate_der539 = ( - U_idx_2 /
( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 + 1.0 / ( t1922 == 0.0 ?
1.0E-16 : t1922 ) ) * X [ 138ULL ] / ( intermediate_der5597 == 0.0 ? 1.0E-16
: intermediate_der5597 ) ; intermediate_der546 = ( U_idx_2 / ( t972 == 0.0 ?
1.0E-16 : t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [
93ULL ] / ( intermediate_der5598 == 0.0 ? 1.0E-16 : intermediate_der5598 ) ;
intermediate_der553 = ( X [ 93ULL ] - X [ 138ULL ] ) / (
intermediate_der11512 == 0.0 ? 1.0E-16 : intermediate_der11512 ) ;
intermediate_der1227 = - 0.005 ; U_idx_3 = t1430 / 2.0 *
7.8539816339744827E-5 ; intermediate_der1258 = ( intermediate_der8351 >= 0.0
? intermediate_der1227 : 0.0 ) * 0.01 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3
) ; t811 = intermediate_der7331 >= 0.0 ? intermediate_der1258 : -
intermediate_der1258 ; intermediate_der1148 = t855 > 1000.0 ? t811 : 0.0 ;
U_idx_1 = ( 6.9 / ( t857 == 0.0 ? 1.0E-16 : t857 ) + 0.00017169489553429715 )
* 2.3025850929940459 ; t1382 = pmf_log10 ( 6.9 / ( t857 == 0.0 ? 1.0E-16 :
t857 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t857 == 0.0 ? 1.0E-16
: t857 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t857 == 0.0 ?
1.0E-16 : t857 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t857 == 0.0
? 1.0E-16 : t857 ) + 0.00017169489553429715 ) * 10.497600000000002 ; U_idx_3
= t857 * t857 ; intermediate_der11712 = - 1.0 / ( t1382 == 0.0 ? 1.0E-16 :
t1382 ) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( 1.0 / (
U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 ( 6.9 / ( t857 == 0.0 ?
1.0E-16 : t857 ) + 0.00017169489553429715 ) * intermediate_der1148 * 6.48 ;
U_idx_1 = pmf_sqrt ( intermediate_der8507 / 8.0 ) * 2.0 ; U_idx_3 = ( (
pmf_pow ( intermediate_der8325 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der8507 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow (
intermediate_der8325 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
intermediate_der8507 / 8.0 ) * 12.7 + 1.0 ) ; intermediate_der1148 = (
pmf_pow ( intermediate_der8325 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t857
- 1000.0 ) * ( intermediate_der8507 / 8.0 ) * intermediate_der8325 ) / (
U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * ( intermediate_der11712 / 8.0 ) * (
1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * 12.7 + ( ( t857 - 1000.0 ) *
( intermediate_der11712 / 8.0 ) + intermediate_der8507 / 8.0 *
intermediate_der1148 ) * intermediate_der8325 / ( t1432 == 0.0 ? 1.0E-16 :
t1432 ) ; intermediate_der11712 = t811 / 2000.0 ; t814 =
intermediate_der11712 * intermediate_der11637 * 6.0 - intermediate_der11637 *
intermediate_der11637 * intermediate_der11712 * 6.0 ; if ( t855 <= 2000.0 ) {
intermediate_der11712 = 0.0 ; } else if ( t855 >= 4000.0 ) {
intermediate_der11712 = intermediate_der1148 ; } else { intermediate_der11712
= ( - t814 * 3.66 + t814 * t860 ) + intermediate_der1148 *
intermediate_der8034 ; } U_idx_3 = t1431 / 2.0 ; if ( t855 > t1433 /
7.8539816339744827E-5 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) / 30.0 ) {
U_idx_3 = t855 * t855 ; U_idx_1 = ( t853 + t856 ) / 2.0 ;
intermediate_der1148 = ( - ( intermediate_der8886 * 0.031415926535897927 ) /
( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) * t811 + intermediate_der11712 *
0.031415926535897927 / ( t855 == 0.0 ? 1.0E-16 : t855 ) ) /
7.8539816339744827E-5 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ; } else {
intermediate_der1148 = 0.0 ; } t811 = - ( - intermediate_der1148 * pmf_exp (
- t866 ) ) * ( X [ 179ULL ] - X [ 175ULL ] ) ; t1382 = t775 +
intermediate_der7296 ; intermediate_der1258 = t1382 / 2.0 * ( t1431 / 2.0 ) *
( intermediate_der1258 * 7.8539816339744827E-5 / 0.01 ) * t869 +
intermediate_der7331 * 7.8539816339744827E-5 / 0.01 * ( t1431 / 2.0 ) * (
t1382 / 2.0 ) * t811 ; U_idx_3 = t1434 / 2.0 * 7.8539816339744827E-5 ;
intermediate_der1227 = - ( intermediate_der8351 <= 0.0 ? intermediate_der1227
: 0.0 ) * 0.01 / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ; t811 = t871 >= 0.0
? intermediate_der1227 : - intermediate_der1227 ; intermediate_der1148 = t872
> 1000.0 ? t811 : 0.0 ; U_idx_1 = ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1382 = pmf_log10 ( 6.9 / (
t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 /
( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 ) *
10.497600000000002 ; U_idx_3 = t874 * t874 ; intermediate_der11712 = - 1.0 /
( t1382 == 0.0 ? 1.0E-16 : t1382 ) * ( - 6.9 / ( U_idx_3 == 0.0 ? 1.0E-16 :
U_idx_3 ) ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) ) * pmf_log10 (
6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715 ) *
intermediate_der1148 * 6.48 ; U_idx_1 = pmf_sqrt ( t1793 / 8.0 ) * 2.0 ;
U_idx_3 = ( ( pmf_pow ( t1822 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
t1793 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow ( t1822 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t1793 / 8.0 ) * 12.7 + 1.0 ) ; intermediate_der1148 = (
pmf_pow ( t1822 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t874 - 1000.0 ) * (
t1793 / 8.0 ) * t1822 ) / ( U_idx_3 == 0.0 ? 1.0E-16 : U_idx_3 ) ) * (
intermediate_der11712 / 8.0 ) * ( 1.0 / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1
) ) * 12.7 + ( ( t874 - 1000.0 ) * ( intermediate_der11712 / 8.0 ) + t1793 /
8.0 * intermediate_der1148 ) * t1822 / ( t1436 == 0.0 ? 1.0E-16 : t1436 ) ;
intermediate_der11712 = t811 / 2000.0 ; t814 = intermediate_der11712 * t1794
* 6.0 - t1794 * t1794 * intermediate_der11712 * 6.0 ; if ( t872 <= 2000.0 ) {
intermediate_der11712 = 0.0 ; } else if ( t872 >= 4000.0 ) {
intermediate_der11712 = intermediate_der1148 ; } else { intermediate_der11712
= ( - t814 * 3.66 + t814 * t1694 ) + intermediate_der1148 * t1681 ; } U_idx_1
= t1435 / 2.0 ; if ( t872 > t1437 / 7.8539816339744827E-5 / ( U_idx_1 == 0.0
? 1.0E-16 : U_idx_1 ) / 30.0 ) { U_idx_1 = t872 * t872 ; t1425 = ( t856 +
t870 ) / 2.0 ; intermediate_der1148 = ( - ( t1456 * 0.031415926535897927 ) /
( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1 ) * t811 + intermediate_der11712 *
0.031415926535897927 / ( t872 == 0.0 ? 1.0E-16 : t872 ) ) /
7.8539816339744827E-5 / ( t1425 == 0.0 ? 1.0E-16 : t1425 ) ; } else {
intermediate_der1148 = 0.0 ; } t811 = - ( - intermediate_der1148 * pmf_exp (
- t1464 ) ) * ( X [ 179ULL ] - X [ 194ULL ] ) ; t1681 = intermediate_der7296
+ t873 ; t811 = intermediate_der1258 + ( t1681 / 2.0 * ( t1435 / 2.0 ) * (
intermediate_der1227 * 7.8539816339744827E-5 / 0.01 ) * t1757 + t871 *
7.8539816339744827E-5 / 0.01 * ( t1435 / 2.0 ) * ( t1681 / 2.0 ) * t811 ) ;
t1793 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.0360111955237585E-13 ) * 2.0 ; intermediate_der1227 = 1.0 / ( t1793 == 0.0
? 1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; t1793 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
2.3237892571262758E-14 ) * 2.0 ; intermediate_der1258 = 1.0 / ( t1793 == 0.0
? 1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; t1793 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 +
1.6409606283812424E-14 ) * 2.0 ; intermediate_der1148 = 1.0 / ( t1793 == 0.0
? 1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * - 0.01 *
2.0 ; if ( t844 * 0.0001 <= 7.8539816339744857E-13 ) { t814 = 0.0 ; } else if
( t844 * 0.0001 >= 3.1415926535897929E-6 ) { t814 = 0.0 ; } else { t814 =
3.1415926535897929E-6 ; } intermediate_der11712 = t814 /
7.8539816339744827E-5 ; if ( X [ 186ULL ] > 0.0 ) { U_idx_1 = t891 * t891 ;
t815 = ( ( ( t1473 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t891 == 0.0 ? 1.0E-16
: t891 ) * ( - ( X [ 186ULL ] / 0.64 ) / ( U_idx_1 == 0.0 ? 1.0E-16 : U_idx_1
) ) * t814 * 2.0 / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) ) + X [ 186ULL ] /
0.64 / ( t891 == 0.0 ? 1.0E-16 : t891 ) * ( X [ 186ULL ] / 0.64 / ( t891 ==
0.0 ? 1.0E-16 : t891 ) ) / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) *
intermediate_der11712 ) * ( 1.0 - t1473 * t1645 ) + - ( t1645 *
intermediate_der11712 ) * ( t1473 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t891 ==
0.0 ? 1.0E-16 : t891 ) * ( X [ 186ULL ] / 0.64 / ( t891 == 0.0 ? 1.0E-16 :
t891 ) ) / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) ) ) *
9.9999999999999991E-11 ; } else if ( X [ 186ULL ] < 0.0 ) { U_idx_7 = t891 *
t891 ; t815 = ( ( ( t1473 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t891 == 0.0 ?
1.0E-16 : t891 ) * ( - ( X [ 186ULL ] / 0.64 ) / ( U_idx_7 == 0.0 ? 1.0E-16 :
U_idx_7 ) ) * t814 * 2.0 / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) ) + X [
186ULL ] / 0.64 / ( t891 == 0.0 ? 1.0E-16 : t891 ) * ( X [ 186ULL ] / 0.64 /
( t891 == 0.0 ? 1.0E-16 : t891 ) ) / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) *
intermediate_der11712 ) * ( 1.0 - t1473 * t1487 ) + - ( t1487 *
intermediate_der11712 ) * ( t1473 + 1.0 ) * ( X [ 186ULL ] / 0.64 / ( t891 ==
0.0 ? 1.0E-16 : t891 ) * ( X [ 186ULL ] / 0.64 / ( t891 == 0.0 ? 1.0E-16 :
t891 ) ) / 2.0 / ( t896 == 0.0 ? 1.0E-16 : t896 ) ) ) *
9.9999999999999991E-11 ; } else { t815 = 0.0 ; } t817 = -
intermediate_der11712 * ( 1.0 - t1473 ) * 2.0 ; intermediate_der3747 = t1513
* t817 ; t820 = ( X [ 195ULL ] - 1.01325 ) * ( t1713 >= t1502 ? ( ( 1.0 -
t1473 * t1645 ) * intermediate_der11712 + - ( t1645 * intermediate_der11712 )
* ( t1473 + 1.0 ) ) - ( ( 1.0 - t1473 * t1487 ) * intermediate_der11712 * 2.0
+ - ( t1487 * intermediate_der11712 ) * t1473 * 2.0 ) : t817 ) ; if ( X [
195ULL ] - 1.01325 <= 0.0 ) { t818 = intermediate_der3747 ; } else if ( X [
195ULL ] - 1.01325 >= t1513 ) { t818 = t820 ; } else { t818 = ( 1.0 - t1553 )
* intermediate_der3747 + t820 * t1553 ; } intermediate_der11712 = ( 1.01325 -
X [ 195ULL ] ) * ( t1723 >= t1502 ? ( ( 1.0 - t1473 * t1487 ) *
intermediate_der11712 + - ( t1487 * intermediate_der11712 ) * ( t1473 + 1.0 )
) - ( ( 1.0 - t1473 * t1645 ) * intermediate_der11712 * 2.0 + - ( t1645 *
intermediate_der11712 ) * t1473 * 2.0 ) : t817 ) ; if ( 1.01325 - X [ 195ULL
] <= 0.0 ) { t817 = intermediate_der3747 ; } else if ( 1.01325 - X [ 195ULL ]
>= t1513 ) { t817 = intermediate_der11712 ; } else { t817 = ( 1.0 - t1581 ) *
intermediate_der3747 + intermediate_der11712 * t1581 ; } if ( X [ 195ULL ] >
1.01325 ) { intermediate_der11712 = t818 ; } else { intermediate_der11712 = X
[ 195ULL ] < 1.01325 ? t817 : intermediate_der3747 ; } t1456 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ;
intermediate_der3747 = X [ 347ULL ] / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [
343ULL ] ) * ( - X [ 344ULL ] / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 ;
if ( X [ 313ULL ] > 0.0 ) { t818 = - ( t1519 * intermediate_der3747 ) * (
t1519 + 1.0 ) * ( X [ 313ULL ] / 0.64 / ( t920 == 0.0 ? 1.0E-16 : t920 ) * (
X [ 313ULL ] / 0.64 / ( t920 == 0.0 ? 1.0E-16 : t920 ) ) / 2.0 / ( t930 ==
0.0 ? 1.0E-16 : t930 ) ) * 9.9999999999999991E-11 ; } else { t818 = 0.0 ; }
t820 = 5.0 ; t821 = t820 * 0.0010000000000000009 ; intermediate_der5455 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 * t821 ;
intermediate_der5449 = ( t941 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ? t941 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ) * 10.0 + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( t941 >= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ? -
( t1519 * intermediate_der3747 ) * ( t1519 + 1.0 ) : 0.0 ) ; t1464 = t935 *
t935 ; intermediate_der3714 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) /
( t1464 == 0.0 ? 1.0E-16 : t1464 ) * t821 + 10.0 / ( t935 == 0.0 ? 1.0E-16 :
t935 ) ; intermediate_der5453 = intermediate_der3714 * intrm_sf_mf_839 * 6.0
- intrm_sf_mf_839 * intrm_sf_mf_839 * intermediate_der3714 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 <=
0.0 ) { intermediate_der3714 = intermediate_der5455 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t935 ) { intermediate_der3714 = intermediate_der5449 ; } else {
intermediate_der3714 = ( ( - intermediate_der5453 * t936 + ( 1.0 - t944 ) *
intermediate_der5455 ) + t943 * intermediate_der5453 ) + intermediate_der5449
* t944 ; } intermediate_der3747 = - 10.0 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ) + ( 1.01325
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu12 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu10 ? - ( - (
t1519 * intermediate_der3747 ) * t1519 * 2.0 ) : 0.0 ) ; intermediate_der5449
= - ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) / ( t1464 ==
0.0 ? 1.0E-16 : t1464 ) * t821 + - 10.0 / ( t935 == 0.0 ? 1.0E-16 : t935 ) ;
intermediate_der5453 = intermediate_der5449 * t933 * 6.0 - t933 * t933 *
intermediate_der5449 * 6.0 ; if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 <= 0.0 ) {
intermediate_der5449 = intermediate_der5455 ; } else if ( 1.01325 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 >= t935 ) {
intermediate_der5449 = intermediate_der3747 ; } else { intermediate_der5449 =
( ( - intermediate_der5453 * t936 + ( 1.0 - t945 ) * intermediate_der5455 ) +
t931 * intermediate_der5453 ) + intermediate_der3747 * t945 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 > 1.01325 ) {
intermediate_der3747 = intermediate_der3714 ; } else { intermediate_der3747 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 < 1.01325 ?
intermediate_der5449 : intermediate_der5455 ; } t1793 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 +
6.4274470286298274E-9 ) * 2.0 ; intermediate_der3714 = 1.0 / ( t1793 == 0.0 ?
1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 * - 2.0 * 2.0
; t1464 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 ;
intermediate_der5453 = - ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 / ( t1464 ==
0.0 ? 1.0E-16 : t1464 ) * intermediate_der3714 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 ) )
/ 2.0 ; intermediate_der5455 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 / ( t1464 ==
0.0 ? 1.0E-16 : t1464 ) * intermediate_der3714 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 ) )
/ 2.0 ; t1793 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
1.2620262729050631E-10 ) * 2.0 ; t823 = 1.0 / ( t1793 == 0.0 ? 1.0E-16 :
t1793 ) * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
2.0 * 2.0 ; t1473 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ; t826 = - ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1473 ==
0.0 ? 1.0E-16 : t1473 ) * t823 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
/ 2.0 ; t827 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1473 ==
0.0 ? 1.0E-16 : t1473 ) * t823 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
/ 2.0 ; intermediate_der5551 = 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * 2.0 * 2.0 ;
t1487 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ; t830 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1487 ==
0.0 ? 1.0E-16 : t1487 ) * intermediate_der5551 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
/ 2.0 ; t832 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1487 ==
0.0 ? 1.0E-16 : t1487 ) * intermediate_der5551 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
/ 2.0 ; t822 = 1.0 ; t1645 = t822 * 0.0028301886792452828 ; t1793 = pmf_sqrt
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 +
2.4102926357361849E-12 ) * 2.0 ; intermediate_der5591 = 1.0 / ( t1793 == 0.0
? 1.0E-16 : t1793 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * 2.0 * 2.0 ;
t1502 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 ;
intermediate_der5597 = - ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1502 ==
0.0 ? 1.0E-16 : t1502 ) * intermediate_der5591 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 ) )
/ 2.0 ; intermediate_der5598 = ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1502 ==
0.0 ? 1.0E-16 : t1502 ) * intermediate_der5591 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 ) )
/ 2.0 ; t1513 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ;
intermediate_der11512 = X [ 511ULL ] / ( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [
506ULL ] ) * ( - X [ 507ULL ] / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 ;
if ( - X [ 478ULL ] > 0.0 ) { t775 = 0.0 ; } else if ( - X [ 478ULL ] < 0.0 )
{ t775 = - ( t967 * intermediate_der11512 ) * ( t967 + 1.0 ) * ( - X [ 478ULL
] / 0.64 / ( intrm_sf_mf_1433 == 0.0 ? 1.0E-16 : intrm_sf_mf_1433 ) * ( - X [
478ULL ] / 0.64 / ( intrm_sf_mf_1433 == 0.0 ? 1.0E-16 : intrm_sf_mf_1433 ) )
/ 2.0 / ( t973 == 0.0 ? 1.0E-16 : t973 ) ) * 9.9999999999999991E-11 ; } else
{ t775 = 0.0 ; } intermediate_der8351 = t820 * 0.0010000000000000009 ; t820 =
t975 * intermediate_der8351 ; intermediate_der7296 = - 10.0 * ( t984 >= t975
? t984 : t975 ) + ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) * ( t984 >=
t975 ? - ( - ( t967 * intermediate_der11512 ) * t967 * 2.0 ) : 0.0 ) ; t1713
= t978 * t978 ; t844 = - ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) / ( t1713 ==
0.0 ? 1.0E-16 : t1713 ) * intermediate_der8351 + - 10.0 / ( t978 == 0.0 ?
1.0E-16 : t978 ) ; t853 = t844 * intrm_sf_mf_1544 * 6.0 - intrm_sf_mf_1544 *
intrm_sf_mf_1544 * t844 * 6.0 ; if ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 <= 0.0 ) {
t844 = t820 ; } else if ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 >= t978 ) {
t844 = intermediate_der7296 ; } else { t844 = ( ( - t853 * t979 + ( 1.0 -
t985 ) * t820 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu12 * t853 ) +
intermediate_der7296 * t985 ; } intermediate_der11512 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 >= t975 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16 : t975 ) *
10.0 + ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [
64ULL ] ) * ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu16
>= t975 ? - ( t967 * intermediate_der11512 ) * ( t967 + 1.0 ) : 0.0 ) ;
intermediate_der7296 = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
) / ( t1713 == 0.0 ? 1.0E-16 : t1713 ) * intermediate_der8351 + 10.0 / ( t978
== 0.0 ? 1.0E-16 : t978 ) ; t853 = intermediate_der7296 * t976 * 6.0 - t976 *
t976 * intermediate_der7296 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
<= 0.0 ) { intermediate_der7296 = t820 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 - X [ 64ULL ]
>= t978 ) { intermediate_der7296 = intermediate_der11512 ; } else {
intermediate_der7296 = ( ( - t853 * t979 + ( 1.0 - t986 ) * t820 ) + t974 *
t853 ) + intermediate_der11512 * t986 ; } if ( X [ 64ULL ] >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) {
intermediate_der11512 = t844 ; } else { intermediate_der11512 = X [ 64ULL ] <
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ?
intermediate_der7296 : t820 ; } t1793 = pmf_sqrt ( t992 * t992 +
1.8324100759713822E-12 ) * 2.0 ; t844 = 1.0 / ( t1793 == 0.0 ? 1.0E-16 :
t1793 ) * t992 * 0.01 * 2.0 ; t1694 = pmf_sqrt ( t992 * t992 +
2.0914103314136477E-13 ) * 2.0 ; intermediate_der7296 = 1.0 / ( t1694 == 0.0
? 1.0E-16 : t1694 ) * t992 * 0.01 * 2.0 ; t1794 = pmf_sqrt ( t992 * t992 +
1.4768645655431184E-13 ) * 2.0 ; t853 = 1.0 / ( t1794 == 0.0 ? 1.0E-16 :
t1794 ) * t992 * 0.01 * 2.0 ; intermediate_der7331 = 1.0 / ( t1793 == 0.0 ?
1.0E-16 : t1793 ) * t992 * 0.01 * 2.0 ; t855 = 1.0 / ( t1694 == 0.0 ? 1.0E-16
: t1694 ) * t992 * 0.01 * 2.0 ; t856 = 1.0 / ( t1794 == 0.0 ? 1.0E-16 : t1794
) * t992 * 0.01 * 2.0 ; t857 = U_idx_2 >= 0.0 ? 1.0 : - 1.0 ; t1694 = t857 *
0.01 ; intermediate_der8325 = t1694 / ( t995 == 0.0 ? 1.0E-16 : t995 ) ;
t1793 = ( 6.9 / ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1794 = pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_11 == 0.0 ?
1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) + 0.00017169489553429715 )
* 10.497600000000002 ; t1681 = intrm_sf_mf_11 * intrm_sf_mf_11 ; t1757 = -
1.0 / ( t1794 == 0.0 ? 1.0E-16 : t1794 ) * ( - 6.9 / ( t1681 == 0.0 ? 1.0E-16
: t1681 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9
/ ( intrm_sf_mf_11 == 0.0 ? 1.0E-16 : intrm_sf_mf_11 ) +
0.00017169489553429715 ) * ( intrm_sf_mf_10 >= 2000.0 ? intermediate_der8325
: 0.0 ) * 3.5640000000000005 ; t860 = intermediate_der9543 * 35.2 / ( t999 ==
0.0 ? 1.0E-16 : t999 ) * 1.0E-5 ; t1794 = t1000 / 2.0 *
0.00093750000000000007 ; intermediate_der11637 = t1645 / ( t1794 == 0.0 ?
1.0E-16 : t1794 ) ; intermediate_der8034 = intrm_sf_mf_1324 >= 0.0 ?
intermediate_der11637 : - intermediate_der11637 ; intermediate_der8886 = t953
> 1000.0 ? intermediate_der8034 : 0.0 ; t1793 = ( 6.9 / ( t998 == 0.0 ?
1.0E-16 : t998 ) + 0.00069701528436089772 ) * 2.3025850929940459 ; t1794 =
pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 : t998 ) + 0.00069701528436089772 )
* pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 : t998 ) + 0.00069701528436089772
) * pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 : t998 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 : t998 )
+ 0.00069701528436089772 ) * 10.497600000000002 ; t1681 = t998 * t998 ; t866
= - 1.0 / ( t1794 == 0.0 ? 1.0E-16 : t1794 ) * ( - 6.9 / ( t1681 == 0.0 ?
1.0E-16 : t1681 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) *
pmf_log10 ( 6.9 / ( t998 == 0.0 ? 1.0E-16 : t998 ) + 0.00069701528436089772 )
* intermediate_der8886 * 6.48 ; t1793 = pmf_sqrt ( t1004 / 8.0 ) * 2.0 ;
t1681 = ( ( pmf_pow ( t1002 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt (
t1004 / 8.0 ) * 12.7 + 1.0 ) * ( ( pmf_pow ( t1002 , 0.66666666666666663 ) -
1.0 ) * pmf_sqrt ( t1004 / 8.0 ) * 12.7 + 1.0 ) ; intermediate_der8886 = (
pmf_pow ( t1002 , 0.66666666666666663 ) - 1.0 ) * ( - ( ( t998 - 1000.0 ) * (
t1004 / 8.0 ) * t1002 ) / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) ) * ( t866 / 8.0
) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * 12.7 + ( ( t998 - 1000.0 )
* ( t866 / 8.0 ) + t1004 / 8.0 * intermediate_der8886 ) * t1002 / ( t1007 ==
0.0 ? 1.0E-16 : t1007 ) ; t866 = intermediate_der8034 / 2000.0 ; t869 = t866
* t1006 * 6.0 - t1006 * t1006 * t866 * 6.0 ; if ( t953 <= 2000.0 ) { t866 =
0.0 ; } else if ( t953 >= 4000.0 ) { t866 = intermediate_der8886 ; } else {
t866 = ( - t869 * 3.66 + t869 * t1005 ) + intermediate_der8886 * t1008 ; }
t1681 = t1003 / 2.0 ; if ( t953 > t1009 / 0.00093750000000000007 / ( t1681 ==
0.0 ? 1.0E-16 : t1681 ) / 30.0 ) { t1681 = t953 * t953 ; t1581 = ( t951 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ;
intermediate_der8886 = ( - ( intrm_sf_mf_1332 * 1.3250000000000002 ) / (
t1681 == 0.0 ? 1.0E-16 : t1681 ) * intermediate_der8034 + t866 *
1.3250000000000002 / ( t953 == 0.0 ? 1.0E-16 : t953 ) ) /
0.00093750000000000007 / ( t1581 == 0.0 ? 1.0E-16 : t1581 ) ; } else {
intermediate_der8886 = 0.0 ; } intermediate_der8034 = - ( -
intermediate_der8886 * pmf_exp ( - t1011 ) ) * ( X [ 62ULL ] - X [ 450ULL ] )
; intermediate_der11637 = t1021 / 2.0 * ( t1003 / 2.0 ) * (
intermediate_der11637 * 0.00093750000000000007 / 0.0028301886792452828 ) *
t1012 + t1019 / 0.0028301886792452828 * ( t1003 / 2.0 ) * ( t1021 / 2.0 ) *
intermediate_der8034 ; t1681 = t1022 / 2.0 * 0.00093750000000000007 ; t822 =
- t822 * 0.0028301886792452828 / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) ;
intermediate_der8034 = intrm_sf_mf_1336 >= 0.0 ? t822 : - t822 ;
intermediate_der8886 = intrm_sf_mf_1337 > 1000.0 ? intermediate_der8034 : 0.0
; t1793 = ( 6.9 / ( t1013 == 0.0 ? 1.0E-16 : t1013 ) + 0.00069701528436089772
) * 2.3025850929940459 ; t1794 = pmf_log10 ( 6.9 / ( t1013 == 0.0 ? 1.0E-16 :
t1013 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1013 == 0.0 ?
1.0E-16 : t1013 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( t1013 ==
0.0 ? 1.0E-16 : t1013 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9 / (
t1013 == 0.0 ? 1.0E-16 : t1013 ) + 0.00069701528436089772 ) *
10.497600000000002 ; t1681 = t1013 * t1013 ; t866 = - 1.0 / ( t1794 == 0.0 ?
1.0E-16 : t1794 ) * ( - 6.9 / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) ) * ( 1.0 /
( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9 / ( t1013 == 0.0 ?
1.0E-16 : t1013 ) + 0.00069701528436089772 ) * intermediate_der8886 * 6.48 ;
t1793 = pmf_sqrt ( t1015 / 8.0 ) * 2.0 ; t1681 = ( ( pmf_pow ( t1014 ,
0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1015 / 8.0 ) * 12.7 + 1.0 ) * ( (
pmf_pow ( t1014 , 0.66666666666666663 ) - 1.0 ) * pmf_sqrt ( t1015 / 8.0 ) *
12.7 + 1.0 ) ; intermediate_der8886 = ( pmf_pow ( t1014 , 0.66666666666666663
) - 1.0 ) * ( - ( ( t1013 - 1000.0 ) * ( t1015 / 8.0 ) * t1014 ) / ( t1681 ==
0.0 ? 1.0E-16 : t1681 ) ) * ( t866 / 8.0 ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16
: t1793 ) ) * 12.7 + ( ( t1013 - 1000.0 ) * ( t866 / 8.0 ) + t1015 / 8.0 *
intermediate_der8886 ) * t1014 / ( t1029 == 0.0 ? 1.0E-16 : t1029 ) ; t866 =
intermediate_der8034 / 2000.0 ; t869 = t866 * t1017 * 6.0 - t1017 * t1017 *
t866 * 6.0 ; if ( intrm_sf_mf_1337 <= 2000.0 ) { t866 = 0.0 ; } else if (
intrm_sf_mf_1337 >= 4000.0 ) { t866 = intermediate_der8886 ; } else { t866 =
( - t869 * 3.66 + t869 * t1016 ) + intermediate_der8886 * t1018 ; } t1681 =
t1025 / 2.0 ; if ( intrm_sf_mf_1337 > t1031 / 0.00093750000000000007 / (
t1681 == 0.0 ? 1.0E-16 : t1681 ) / 30.0 ) { t1681 = intrm_sf_mf_1337 *
intrm_sf_mf_1337 ; t1581 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato1 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato2 ) / 2.0 ;
intermediate_der8886 = ( - ( t1023 * 1.3250000000000002 ) / ( t1681 == 0.0 ?
1.0E-16 : t1681 ) * intermediate_der8034 + t866 * 1.3250000000000002 / (
intrm_sf_mf_1337 == 0.0 ? 1.0E-16 : intrm_sf_mf_1337 ) ) /
0.00093750000000000007 / ( t1581 == 0.0 ? 1.0E-16 : t1581 ) ; } else {
intermediate_der8886 = 0.0 ; } intermediate_der8034 = - ( -
intermediate_der8886 * pmf_exp ( - t1024 ) ) * ( X [ 62ULL ] - X [ 436ULL ] )
; t822 = t1043 / 2.0 * ( t1025 / 2.0 ) * ( t822 * 0.00093750000000000007 /
0.0028301886792452828 ) * t1026 + t1041 / 0.0028301886792452828 * ( t1025 /
2.0 ) * ( t1043 / 2.0 ) * intermediate_der8034 ; intermediate_der8034 = t1645
/ ( t954 == 0.0 ? 1.0E-16 : t954 ) / 40.0 ; intermediate_der8213 =
intermediate_der8034 * intrm_sf_mf_1348 * 6.0 - intrm_sf_mf_1348 *
intrm_sf_mf_1348 * intermediate_der8034 * 6.0 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 <= - 20.0 ) {
intermediate_der8034 = t822 * 0.001 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato4 >= 20.0 ) {
intermediate_der8034 = intermediate_der11637 * 0.001 ; } else {
intermediate_der8034 = ( ( ( - intermediate_der8213 * ( t1041 /
0.0028301886792452828 * ( t1025 / 2.0 ) * ( t1043 / 2.0 ) * t1026 ) + ( 1.0 -
t1027 ) * t822 ) + intermediate_der8213 * ( t1019 / 0.0028301886792452828 * (
t1003 / 2.0 ) * ( t1021 / 2.0 ) * t1012 ) ) + intermediate_der11637 * t1027 )
* 0.001 ; } t822 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 >= 0.0 ? 2.0 :
- 2.0 ; intermediate_der8213 = t822 * 0.0028301886792452828 / ( t954 == 0.0 ?
1.0E-16 : t954 ) ; t1793 = ( 6.9 / ( t1033 == 0.0 ? 1.0E-16 : t1033 ) +
0.00069701528436089772 ) * 2.3025850929940459 ; t1794 = pmf_log10 ( 6.9 / (
t1033 == 0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772 ) * pmf_log10 ( 6.9
/ ( t1033 == 0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772 ) * pmf_log10 (
6.9 / ( t1033 == 0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772 ) *
pmf_log10 ( 6.9 / ( t1033 == 0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772
) * 10.497600000000002 ; t1681 = t1033 * t1033 ; intermediate_der8886 = - 1.0
/ ( t1794 == 0.0 ? 1.0E-16 : t1794 ) * ( - 6.9 / ( t1681 == 0.0 ? 1.0E-16 :
t1681 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9 /
( t1033 == 0.0 ? 1.0E-16 : t1033 ) + 0.00069701528436089772 ) * ( t1030 >=
1.0 ? intermediate_der8213 : 0.0 ) * 6.48 ; intermediate_der11637 = t952 *
2.0 * 112.0 / ( t1049 == 0.0 ? 1.0E-16 : t1049 ) ; t822 = ( ( 2.0 * t1028 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t822 ) *
t1034 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 *
intermediate_der8886 * t1028 ) * 1.75 / ( t1051 == 0.0 ? 1.0E-16 : t1051 ) ;
t800 = intermediate_der8213 / 2000.0 ; intermediate_der8213 = t800 * t1036 *
6.0 - t1036 * t1036 * t800 * 6.0 ; if ( t1030 <= 2000.0 ) { t800 =
intermediate_der11637 * 1.0E-5 ; } else if ( t1030 >= 4000.0 ) { t800 = t822
* 1.0E-5 ; } else { t800 = ( ( ( - intermediate_der8213 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t952 * 112.0
/ ( t1049 == 0.0 ? 1.0E-16 : t1049 ) ) + ( 1.0 - t1037 ) *
intermediate_der11637 ) + intermediate_der8213 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 * t1028 *
t1034 * 1.75 / ( t1051 == 0.0 ? 1.0E-16 : t1051 ) ) ) + t822 * t1037 ) *
1.0E-5 ; } t822 = ( ( intrm_sf_mf_9 + U_idx_2 * t857 ) * t996 + U_idx_2 * (
t1757 / 0.01 ) * intrm_sf_mf_9 ) / ( t1054 == 0.0 ? 1.0E-16 : t1054 ) *
1.0E-5 ; intermediate_der8213 = intermediate_der8325 / 2000.0 ; t1681 = (
t978 - ( - t978 ) ) * ( t978 - ( - t978 ) ) ; intermediate_der8325 = (
intermediate_der8351 - ( - intermediate_der8351 ) ) * ( - ( ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) - ( - t978 )
) / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) ) + ( - 10.0 - ( -
intermediate_der8351 ) ) / ( t1057 == 0.0 ? 1.0E-16 : t1057 ) ;
intermediate_der8351 = intermediate_der8325 * t1039 * 6.0 - t1039 * t1039 *
intermediate_der8325 * 6.0 ; if ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 <= - t978 ) {
intermediate_der8325 = 10.0 ; } else if ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 >= t978 ) {
intermediate_der8325 = 0.0 ; } else { intermediate_der8325 = ( -
intermediate_der8351 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 + ( 1.0 - (
t1039 * t1039 * 3.0 - t1039 * t1039 * t1039 * 2.0 ) ) * 10.0 ) + X [ 64ULL ]
* intermediate_der8351 ; } intermediate_der8351 = intermediate_der8213 *
intermediate_der8470 * 6.0 - intermediate_der8470 * intermediate_der8470 *
intermediate_der8213 * 6.0 ; if ( intrm_sf_mf_10 <= 2000.0 ) {
intermediate_der8213 = t860 ; } else if ( intrm_sf_mf_10 >= 4000.0 ) {
intermediate_der8213 = t822 ; } else { intermediate_der8213 = ( ( -
intermediate_der8351 * ( U_idx_2 * intermediate_der9543 * 35.2 / ( t999 ==
0.0 ? 1.0E-16 : t999 ) * 1.0E-5 ) + ( 1.0 - t1044 ) * t860 ) +
intermediate_der8351 * ( U_idx_2 * t996 * intrm_sf_mf_9 / ( t1054 == 0.0 ?
1.0E-16 : t1054 ) * 1.0E-5 ) ) + t822 * t1044 ; } intermediate_der8470 = (
U_idx_2 / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 + - 1.0 / ( t1922 == 0.0 ?
1.0E-16 : t1922 ) ) * X [ 138ULL ] / ( X [ 159ULL ] == 0.0 ? 1.0E-16 : X [
159ULL ] ) ; t1922 = ( - U_idx_2 / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 )
* t791 + 1.0 / ( t1922 == 0.0 ? 1.0E-16 : t1922 ) ) * X [ 120ULL ] / ( X [
160ULL ] == 0.0 ? 1.0E-16 : X [ 160ULL ] ) ; if ( - U_idx_2 >= 0.0 ) { t822 =
0.0 ; } else { t1681 = X [ 159ULL ] * 1.2337005501361696E-8 ; t822 = U_idx_2
* 2.0 / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) * 1.0E-5 ; } if ( U_idx_2 >= 0.0 )
{ intermediate_der8351 = 0.0 ; } else { t1681 = X [ 160ULL ] *
1.2337005501361696E-8 ; intermediate_der8351 = U_idx_2 * 2.0 / ( t1681 == 0.0
? 1.0E-16 : t1681 ) * 1.0E-5 ; } if ( U_idx_13 >= 1.0 ) {
intermediate_der8507 = 0.0 ; } else { intermediate_der8507 = ( real_T ) ! (
U_idx_13 <= 0.0 ) ; } if ( - U_idx_2 >= 0.0 ) { t860 = - 1.0 ; } else { t860
= 1.0 ; } t1794 = t860 * 0.01 ; intermediate_der11637 = t1794 / ( t995 == 0.0
? 1.0E-16 : t995 ) ; t1793 = ( 6.9 / ( t1052 == 0.0 ? 1.0E-16 : t1052 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1681 = pmf_log10 ( 6.9 / (
t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9
/ ( t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1052 == 0.0 ? 1.0E-16 : t1052 ) + 0.00017169489553429715
) * 10.497600000000002 ; t1757 = t1052 * t1052 ; t1645 = - 1.0 / ( t1681 ==
0.0 ? 1.0E-16 : t1681 ) * ( - 6.9 / ( t1757 == 0.0 ? 1.0E-16 : t1757 ) ) * (
1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9 / ( t1052 == 0.0
? 1.0E-16 : t1052 ) + 0.00017169489553429715 ) * ( t1047 >= 2000.0 ?
intermediate_der11637 : 0.0 ) * 3.5640000000000005 ; t866 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ? -
0.01 : 0.01 ; t869 = t866 * 0.01 / ( t845 == 0.0 ? 1.0E-16 : t845 ) ; t1793 =
( 6.9 / ( t1058 == 0.0 ? 1.0E-16 : t1058 ) + 0.00017169489553429715 ) *
2.3025850929940459 ; t1681 = pmf_log10 ( 6.9 / ( t1058 == 0.0 ? 1.0E-16 :
t1058 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1058 == 0.0 ?
1.0E-16 : t1058 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t1058 ==
0.0 ? 1.0E-16 : t1058 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t1058 == 0.0 ? 1.0E-16 : t1058 ) + 0.00017169489553429715 ) *
10.497600000000002 ; t1757 = t1058 * t1058 ; t871 = - 1.0 / ( t1681 == 0.0 ?
1.0E-16 : t1681 ) * ( - 6.9 / ( t1757 == 0.0 ? 1.0E-16 : t1757 ) ) * ( 1.0 /
( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9 / ( t1058 == 0.0 ?
1.0E-16 : t1058 ) + 0.00017169489553429715 ) * ( t1056 >= 1.0 ? t869 : 0.0 )
* 6.48 ; intermediate_der8955 = - 0.01 * intermediate_der8955 * 35.2 / ( t849
== 0.0 ? 1.0E-16 : t849 ) ; t866 = ( ( - 0.01 * t1055 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * t866 ) *
t1062 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
t871 * t1055 ) * 0.55 / ( t852 == 0.0 ? 1.0E-16 : t852 ) ; t870 = t869 /
2000.0 ; t869 = t870 * t1066 * 6.0 - t1066 * t1066 * t870 * 6.0 ;
intermediate_der9543 = intermediate_der9543 * - 35.2 / ( t999 == 0.0 ?
1.0E-16 : t999 ) * 1.0E-5 ; if ( t1056 <= 2000.0 ) { t870 =
intermediate_der8955 * 9.9999999999999991E-11 ; } else if ( t1056 >= 4000.0 )
{ t870 = t866 * 9.9999999999999991E-11 ; } else { t870 = ( ( ( - t869 * t1063
+ ( 1.0 - t1067 ) * intermediate_der8955 ) + t869 * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 * t1055 *
t1062 * 0.55 / ( t852 == 0.0 ? 1.0E-16 : t852 ) ) ) + t866 * t1067 ) *
9.9999999999999991E-11 ; } intermediate_der8955 = ( ( - t850 - U_idx_2 * t860
) * t1053 - U_idx_2 * ( t1645 / 0.01 ) * t850 ) / ( t1054 == 0.0 ? 1.0E-16 :
t1054 ) * 1.0E-5 ; intermediate_der8886 = intermediate_der11637 / 2000.0 ;
intermediate_der11637 = intermediate_der8886 * t1072 * 6.0 - t1072 * t1072 *
intermediate_der8886 * 6.0 ; if ( t1047 <= 2000.0 ) { intermediate_der8886 =
intermediate_der9543 ; } else if ( t1047 >= 4000.0 ) { intermediate_der8886 =
intermediate_der8955 ; } else { intermediate_der8886 = ( ( -
intermediate_der11637 * t1069 + ( 1.0 - t1074 ) * intermediate_der9543 ) +
intermediate_der11637 * ( - ( U_idx_2 * t850 * t1053 ) / ( t1054 == 0.0 ?
1.0E-16 : t1054 ) * 1.0E-5 ) ) + intermediate_der8955 * t1074 ; }
intermediate_der9543 = t1694 / ( t1078 == 0.0 ? 1.0E-16 : t1078 ) ; t1793 = (
6.9 / ( intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1681 = pmf_log10 ( 6.9 / (
intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_32 == 0.0 ?
1.0E-16 : intrm_sf_mf_32 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) + 0.00017169489553429715 )
* 10.497600000000002 ; t1757 = intrm_sf_mf_32 * intrm_sf_mf_32 ; t1645 = -
1.0 / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) * ( - 6.9 / ( t1757 == 0.0 ? 1.0E-16
: t1757 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9
/ ( intrm_sf_mf_32 == 0.0 ? 1.0E-16 : intrm_sf_mf_32 ) +
0.00017169489553429715 ) * ( t1076 >= 2000.0 ? intermediate_der9543 : 0.0 ) *
3.5640000000000005 ; intermediate_der11637 = intermediate_der10249 * 35.2 / (
t1082 == 0.0 ? 1.0E-16 : t1082 ) * 1.0E-5 ; intermediate_der8955 = ( (
intrm_sf_mf_9 + U_idx_2 * t857 ) * t1079 + U_idx_2 * ( t1645 / 0.01 ) *
intrm_sf_mf_9 ) / ( t1084 == 0.0 ? 1.0E-16 : t1084 ) * 1.0E-5 ; t866 =
intermediate_der9543 / 2000.0 ; intermediate_der9543 = t866 *
intermediate_der9401 * 6.0 - intermediate_der9401 * intermediate_der9401 *
t866 * 6.0 ; if ( t1076 <= 2000.0 ) { t866 = intermediate_der11637 ; } else
if ( t1076 >= 4000.0 ) { t866 = intermediate_der8955 ; } else { t866 = ( ( -
intermediate_der9543 * ( U_idx_2 * intermediate_der10249 * 35.2 / ( t1082 ==
0.0 ? 1.0E-16 : t1082 ) * 1.0E-5 ) + ( 1.0 - t1083 ) * intermediate_der11637
) + intermediate_der9543 * ( U_idx_2 * t1079 * intrm_sf_mf_9 / ( t1084 == 0.0
? 1.0E-16 : t1084 ) * 1.0E-5 ) ) + intermediate_der8955 * t1083 ; }
intermediate_der9543 = t1794 / ( t1078 == 0.0 ? 1.0E-16 : t1078 ) ; t1793 = (
6.9 / ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * 2.3025850929940459 ; t1681 = pmf_log10 ( 6.9 / (
intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_41 == 0.0 ?
1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) + 0.00017169489553429715 )
* 10.497600000000002 ; t1757 = intrm_sf_mf_41 * intrm_sf_mf_41 ; t1645 = -
1.0 / ( t1681 == 0.0 ? 1.0E-16 : t1681 ) * ( - 6.9 / ( t1757 == 0.0 ? 1.0E-16
: t1757 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * pmf_log10 ( 6.9
/ ( intrm_sf_mf_41 == 0.0 ? 1.0E-16 : intrm_sf_mf_41 ) +
0.00017169489553429715 ) * ( t1085 >= 2000.0 ? intermediate_der9543 : 0.0 ) *
3.5640000000000005 ; intermediate_der10249 = intermediate_der10249 * - 35.2 /
( t1082 == 0.0 ? 1.0E-16 : t1082 ) * 1.0E-5 ; intermediate_der9401 = ( ( -
t850 - U_idx_2 * t860 ) * t1088 - U_idx_2 * ( t1645 / 0.01 ) * t850 ) / (
t1084 == 0.0 ? 1.0E-16 : t1084 ) * 1.0E-5 ; intermediate_der8955 =
intermediate_der9543 / 2000.0 ; intermediate_der9543 = intermediate_der8955 *
t1092 * 6.0 - t1092 * t1092 * intermediate_der8955 * 6.0 ; if ( t1085 <=
2000.0 ) { intermediate_der8955 = intermediate_der10249 ; } else if ( t1085
>= 4000.0 ) { intermediate_der8955 = intermediate_der9401 ; } else {
intermediate_der8955 = ( ( - intermediate_der9543 * t1089 + ( 1.0 - t1094 ) *
intermediate_der10249 ) + intermediate_der9543 * ( - ( U_idx_2 * t850 * t1088
) / ( t1084 == 0.0 ? 1.0E-16 : t1084 ) * 1.0E-5 ) ) + intermediate_der9401 *
t1094 ; } intermediate_der9543 = t1694 / ( t1096 == 0.0 ? 1.0E-16 : t1096 ) ;
t1793 = ( 6.9 / ( t994 == 0.0 ? 1.0E-16 : t994 ) + 0.00017169489553429715 ) *
2.3025850929940459 ; t1694 = pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16 : t994
) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16 :
t994 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16
: t994 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t994 == 0.0 ?
1.0E-16 : t994 ) + 0.00017169489553429715 ) * 10.497600000000002 ; t1681 =
t994 * t994 ; t1757 = - 1.0 / ( t1694 == 0.0 ? 1.0E-16 : t1694 ) * ( - 6.9 /
( t1681 == 0.0 ? 1.0E-16 : t1681 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 :
t1793 ) ) * pmf_log10 ( 6.9 / ( t994 == 0.0 ? 1.0E-16 : t994 ) +
0.00017169489553429715 ) * ( intrm_sf_mf_52 >= 2000.0 ? intermediate_der9543
: 0.0 ) * 3.5640000000000005 ; intermediate_der10249 = intermediate_der10838
* 35.2 / ( t1100 == 0.0 ? 1.0E-16 : t1100 ) * 1.0E-5 ; intermediate_der9401 =
( ( intrm_sf_mf_9 + U_idx_2 * t857 ) * t1097 + U_idx_2 * ( t1757 / 0.01 ) *
intrm_sf_mf_9 ) / ( t1102 == 0.0 ? 1.0E-16 : t1102 ) * 1.0E-5 ; t857 =
intermediate_der9543 / 2000.0 ; intermediate_der9543 = t857 * t1099 * 6.0 -
t1099 * t1099 * t857 * 6.0 ; if ( intrm_sf_mf_52 <= 2000.0 ) { t857 =
intermediate_der10249 ; } else if ( intrm_sf_mf_52 >= 4000.0 ) { t857 =
intermediate_der9401 ; } else { t857 = ( ( - intermediate_der9543 * ( U_idx_2
* intermediate_der10838 * 35.2 / ( t1100 == 0.0 ? 1.0E-16 : t1100 ) * 1.0E-5
) + ( 1.0 - t1101 ) * intermediate_der10249 ) + intermediate_der9543 * (
U_idx_2 * t1097 * intrm_sf_mf_9 / ( t1102 == 0.0 ? 1.0E-16 : t1102 ) * 1.0E-5
) ) + intermediate_der9401 * t1101 ; } intermediate_der9543 = t1794 / ( t1096
== 0.0 ? 1.0E-16 : t1096 ) ; t1793 = ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060
) + 0.00017169489553429715 ) * 2.3025850929940459 ; t1694 = pmf_log10 ( 6.9 /
( t1060 == 0.0 ? 1.0E-16 : t1060 ) + 0.00017169489553429715 ) * pmf_log10 (
6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) + 0.00017169489553429715 ) *
pmf_log10 ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) +
0.00017169489553429715 ) * 10.497600000000002 ; t1794 = t1060 * t1060 ; t1681
= - 1.0 / ( t1694 == 0.0 ? 1.0E-16 : t1694 ) * ( - 6.9 / ( t1794 == 0.0 ?
1.0E-16 : t1794 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) *
pmf_log10 ( 6.9 / ( t1060 == 0.0 ? 1.0E-16 : t1060 ) + 0.00017169489553429715
) * ( t1103 >= 2000.0 ? intermediate_der9543 : 0.0 ) * 3.5640000000000005 ;
intermediate_der10249 = intermediate_der10838 * - 35.2 / ( t1100 == 0.0 ?
1.0E-16 : t1100 ) * 1.0E-5 ; U_idx_3 = ( ( - t850 - U_idx_2 * t860 ) * t1106
- U_idx_2 * ( t1681 / 0.01 ) * t850 ) / ( t1102 == 0.0 ? 1.0E-16 : t1102 ) *
1.0E-5 ; intermediate_der9401 = intermediate_der9543 / 2000.0 ;
intermediate_der9543 = intermediate_der9401 * t1110 * 6.0 - t1110 * t1110 *
intermediate_der9401 * 6.0 ; if ( t1103 <= 2000.0 ) { intermediate_der9401 =
intermediate_der10249 ; } else if ( t1103 >= 4000.0 ) { intermediate_der9401
= U_idx_3 ; } else { intermediate_der9401 = ( ( - intermediate_der9543 * (
U_idx_2 * intermediate_der10838 * - 35.2 / ( t1100 == 0.0 ? 1.0E-16 : t1100 )
* 1.0E-5 ) + ( 1.0 - t1112 ) * intermediate_der10249 ) + intermediate_der9543
* ( - ( U_idx_2 * t850 * t1106 ) / ( t1102 == 0.0 ? 1.0E-16 : t1102 ) *
1.0E-5 ) ) + U_idx_3 * t1112 ; } t1794 = ( t935 - ( - t935 ) ) * ( t935 - ( -
t935 ) ) ; U_idx_3 = ( t821 - ( - t821 ) ) * ( - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) -
( - t935 ) ) / ( t1794 == 0.0 ? 1.0E-16 : t1794 ) ) + ( 10.0 - ( - t821 ) ) /
( t1114 == 0.0 ? 1.0E-16 : t1114 ) ; intermediate_der9543 = U_idx_3 *
intrm_sf_mf_864 * 6.0 - intrm_sf_mf_864 * intrm_sf_mf_864 * U_idx_3 * 6.0 ;
if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325
<= - t935 ) { U_idx_3 = 0.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 >=
t935 ) { U_idx_3 = 10.0 ; } else { U_idx_3 = ( - intermediate_der9543 *
1.01325 + Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 *
intermediate_der9543 ) + 10.0 * ( intrm_sf_mf_864 * intrm_sf_mf_864 * 3.0 -
intrm_sf_mf_864 * intrm_sf_mf_864 * intrm_sf_mf_864 * 2.0 ) ; } t1793 =
pmf_sqrt ( intermediate_der10338 * intermediate_der10338 *
9.999999999999999E-14 + ( ( real_T ) ( M [ 32ULL ] != 0 ) * 2.0 - 1.0 ) * X [
199ULL ] * t839 * intrm_sf_mf_95 * 1.0E-9 ) * 2.0 ; intermediate_der9543 =
1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) * intermediate_der10338 * ( ( X [
21ULL ] / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) - X [ 199ULL ] / ( X
[ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * - 0.01 * intrm_sf_mf_95 /
7.8539816339744827E-5 ) * 1.9999999999999998E-13 ; if ( M [ 310ULL ] != 0 ) {
intermediate_der9757 = 0.0 ; } else { intermediate_der9757 = ( real_T ) ( M [
311ULL ] == 0 ) ; } tlu2_1d_linear_linear_value ( & oh_efOut [ 0ULL ] , & t60
. mField1 [ 0ULL ] , & t60 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t710_idx_0 = oh_efOut
[ 0 ] ; intermediate_der9757 = t710_idx_0 * ( U_idx_5 >= 0.0 ?
intermediate_der9757 : 0.0 ) ; t1694 = X [ 321ULL ] * t921 ; t1794 = - ( X [
321ULL ] * t921 ) ; t821 = ( ( ( real_T ) ( M [ 323ULL ] != 0 ) * 2.0 - 1.0 )
* ( t1694 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) ) * ( t1794
/ ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 + ( ( real_T ) ( M [ 323ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t1694 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1794 / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 ) * ( - X [ 313ULL ]
/ 0.0019634954084936209 ) * ( - X [ 313ULL ] / 0.0019634954084936209 ) / 2.0
* 9.999999999999999E-14 ; intermediate_der10249 = - 10.0 / ( intrm_sf_mf_56
== 0.0 ? 1.0E-16 : intrm_sf_mf_56 ) ; intrm_sf_mf_56 = intermediate_der10249
* zc_int179 * 6.0 - zc_int179 * zc_int179 * intermediate_der10249 * 6.0 ; if
( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 <=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 * - 0.95 ) {
intermediate_der10249 = 10.0 ; } else if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 >= -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M3 ) {
intermediate_der10249 = 0.0 ; } else { intermediate_der10249 = ( -
intrm_sf_mf_56 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 + ( 1.0 - (
zc_int179 * zc_int179 * 3.0 - zc_int179 * zc_int179 * zc_int179 * 2.0 ) ) *
10.0 ) + intrm_sf_mf_56 * zc_int174 ; } intrm_sf_mf_56 = ( ( ( real_T ) ( M [
323ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1694 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1794 / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 + ( ( real_T ) ( M [
323ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1694 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( t1794 / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 ) * ( X [ 313ULL ] /
0.0019634954084936209 ) * ( X [ 313ULL ] / 0.0019634954084936209 ) / 2.0 *
9.999999999999999E-14 ; t1793 = pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 )
* 2.0 - 1.0 ) * ( t950 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) ; t1794 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ;
intermediate_der10838 = pmf_sqrt ( ( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 -
1.0 ) * ( t950 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu6 ) )
) * 10.0 * t920 * 0.64 + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 - 1.01325 ) *
( ( real_T ) ( M [ 332ULL ] != 0 ) * 2.0 - 1.0 ) * ( - ( t930 * 2.0 ) / (
t1794 == 0.0 ? 1.0E-16 : t1794 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793
) ) * intermediate_der3747 * t920 * 0.32 ; intermediate_der3747 =
intermediate_der10838 / ( t1144 == 0.0 ? 1.0E-16 : t1144 ) ;
intermediate_der10338 = intermediate_der3747 * zc_int186 * 6.0 - zc_int186 *
zc_int186 * intermediate_der3747 * 6.0 ; if ( t926 <= t924 * 0.95 ) {
intermediate_der3747 = intermediate_der10838 * 100000.0 ; } else if ( t926 >=
t924 ) { intermediate_der3747 = 0.0 ; } else { intermediate_der3747 = ( ( -
intermediate_der10338 * zc_int184 + ( 1.0 - ( zc_int186 * zc_int186 * 3.0 -
zc_int186 * zc_int186 * zc_int186 * 2.0 ) ) * intermediate_der10838 ) +
intermediate_der10338 * t917 ) * 100000.0 ; } intermediate_der10338 = -
intermediate_der10838 / ( t1144 == 0.0 ? 1.0E-16 : t1144 ) ; t839 =
intermediate_der10338 * t1118 * 6.0 - t1118 * t1118 * intermediate_der10338 *
6.0 ; if ( - t926 <= t924 * 0.95 ) { intermediate_der10338 =
intermediate_der10838 * 100000.0 ; } else if ( - t926 >= t924 ) {
intermediate_der10338 = 0.0 ; } else { intermediate_der10338 = ( ( - t839 *
zc_int184 + ( 1.0 - ( t1118 * t1118 * 3.0 - t1118 * t1118 * t1118 * 2.0 ) ) *
intermediate_der10838 ) + - t917 * t839 ) * 100000.0 ; } t1694 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 *
intermediate_der9543 + - 0.01 * zc_int10 ; intermediate_der9543 = t1694 /
7.8539816339744827E-5 * 0.00031622776601683789 ; t1757 = ( -
intermediate_der11539 - intermediate_der11539 * - 0.95 ) * ( -
intermediate_der11539 - intermediate_der11539 * - 0.95 ) ;
intermediate_der10838 = ( - intermediate_der9543 - intermediate_der9543 * -
0.95 ) * ( - ( - t842 - intermediate_der11539 * - 0.95 ) / ( t1757 == 0.0 ?
1.0E-16 : t1757 ) ) + - ( intermediate_der9543 * - 0.95 ) / ( t1150 == 0.0 ?
1.0E-16 : t1150 ) ; t839 = intermediate_der10838 * intermediate_der11472 *
6.0 - intermediate_der11472 * intermediate_der11472 * intermediate_der10838 *
6.0 ; if ( - t842 <= intermediate_der11334 * - 0.95 ) { intermediate_der10838
= 0.0 ; } else if ( - t842 >= - intermediate_der11334 ) {
intermediate_der10838 = intermediate_der9543 ; } else { intermediate_der10838
= ( - t839 * t842 + t839 * intermediate_der11539 ) + intermediate_der9543 * (
intermediate_der11472 * intermediate_der11472 * 3.0 - intermediate_der11472 *
intermediate_der11472 * intermediate_der11472 * 2.0 ) ; } if ( M [ 355ULL ]
!= 0 ) { intermediate_der9543 = 0.0 ; } else { intermediate_der9543 = (
real_T ) ( M [ 356ULL ] == 0 ) ; } tlu2_1d_linear_linear_value ( & ph_efOut [
0ULL ] , & t32 . mField1 [ 0ULL ] , & t32 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t581 [ 0ULL ] , & t76 [ 0ULL ]
) ; t710_idx_0 = ph_efOut [ 0 ] ; intermediate_der9543 = t710_idx_0 * (
U_idx_8 >= 0.0 ? intermediate_der9543 : 0.0 ) ; t1794 = X [ 484ULL ] * t964 ;
t1757 = - ( X [ 484ULL ] * t964 ) ; t839 = ( ( ( real_T ) ( M [ 10ULL ] != 0
) * 2.0 - 1.0 ) * ( t1794 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) )
* ( t1757 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 + ( ( real_T ) ( M [
10ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1794 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) )
* ( t1757 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 ) * ( - X [ 478ULL ]
/ 7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 7.8539816339744827E-5 ) / 2.0
* 9.999999999999999E-14 ; intermediate_der11334 = - 10.0 / ( t1164 == 0.0 ?
1.0E-16 : t1164 ) ; intermediate_der11472 = intermediate_der11334 * zc_int322
* 6.0 - zc_int322 * zc_int322 * intermediate_der11334 * 6.0 ; if ( - t959 <=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 * - 0.95 ) {
intermediate_der11334 = 10.0 ; } else if ( - t959 >= -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M25 ) {
intermediate_der11334 = 0.0 ; } else { intermediate_der11334 = ( -
intermediate_der11472 * t959 + ( 1.0 - ( zc_int322 * zc_int322 * 3.0 -
zc_int322 * zc_int322 * zc_int322 * 2.0 ) ) * 10.0 ) + intermediate_der11472
* zc_int321 ; } t1723 = ( ( ( real_T ) ( M [ 10ULL ] != 0 ) * 2.0 - 1.0 ) * (
t1794 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ==
0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) ) * ( t1757
/ ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 + ( ( real_T ) ( M [ 10ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t1794 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) )
* ( t1757 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 ) * ( X [ 478ULL ] /
7.8539816339744827E-5 ) * ( X [ 478ULL ] / 7.8539816339744827E-5 ) ; t1793 =
pmf_sqrt ( ( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( t991 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ) )
) ; t1757 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ; t842 = -
10.0 * pmf_sqrt ( ( ( real_T ) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( t991 /
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu10 ) )
) * intrm_sf_mf_1433 * 0.64 + ( X [ 64ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) * ( ( real_T
) ( M [ 20ULL ] != 0 ) * 2.0 - 1.0 ) * ( - ( t973 * 2.0 ) / ( t1757 == 0.0 ?
1.0E-16 : t1757 ) ) * ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) *
intermediate_der11512 * intrm_sf_mf_1433 * 0.32 ; intermediate_der11512 =
t842 / ( t1170 == 0.0 ? 1.0E-16 : t1170 ) ; intermediate_der11539 =
intermediate_der11512 * t960 * 6.0 - t960 * t960 * intermediate_der11512 *
6.0 ; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 <=
t968 * 0.95 ) { intermediate_der11512 = t842 * 100000.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 >= t968 ) {
intermediate_der11512 = 0.0 ; } else { intermediate_der11512 = ( ( -
intermediate_der11539 * zc_int341 + ( 1.0 - ( t960 * t960 * 3.0 - t960 * t960
* t960 * 2.0 ) ) * t842 ) + intermediate_der11539 * t787 ) * 100000.0 ; }
intermediate_der11539 = - t842 / ( t1170 == 0.0 ? 1.0E-16 : t1170 ) ; t850 =
intermediate_der11539 * t927 * 6.0 - t927 * t927 * intermediate_der11539 *
6.0 ; if ( - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25
<= t968 * 0.95 ) { intermediate_der11539 = t842 * 100000.0 ; } else if ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 >= t968 ) {
intermediate_der11539 = 0.0 ; } else { intermediate_der11539 = ( ( - t850 *
zc_int341 + ( 1.0 - ( t927 * t927 * 3.0 - t927 * t927 * t927 * 2.0 ) ) * t842
) + - t787 * t850 ) * 100000.0 ; } intermediate_der11637 = ( ( real_T ) ( M [
40ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 :
X [ 38ULL ] ) ) * ( U_idx_11 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] )
) * ( t992 / 7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ; t871 = ( ( real_T ) ( M [ 42ULL ] != 0 ) * 2.0 - 1.0
) * ( t706_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
t706_idx_0 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( - t992 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ; if ( t992 >= 0.0 ) { t873 = ( zc_int364 - zc_int365 )
* 0.01 + ( intermediate_der11637 - ( ( real_T ) ( M [ 41ULL ] != 0 ) * 2.0 -
1.0 ) * ( U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
U_idx_4 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t992 /
7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) * t992 ; } else { t873 = - ( ( zc_int366 - zc_int367
) * 0.01 ) - ( t871 - ( ( real_T ) ( M [ 43ULL ] != 0 ) * 2.0 - 1.0 ) * (
t848 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t848 / ( X [
38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - t992 / 7.8539816339744827E-5
) * - 127.32395447351628 * 2.0 / 2.0 * 9.999999999999999E-14 ) * t992 ; }
t1793 = pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) * 2.0 - 1.0 ) * ( t914
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) ; t1757 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ; t869 = ( X [
195ULL ] - 1.01325 ) * pmf_sqrt ( ( ( real_T ) ( M [ 126ULL ] != 0 ) * 2.0 -
1.0 ) * ( t914 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va3 ) )
) * t814 * 0.64 + ( X [ 195ULL ] - 1.01325 ) * ( ( real_T ) ( M [ 126ULL ] !=
0 ) * 2.0 - 1.0 ) * ( - ( t896 * 2.0 ) / ( t1757 == 0.0 ? 1.0E-16 : t1757 ) )
* ( 1.0 / ( t1793 == 0.0 ? 1.0E-16 : t1793 ) ) * intermediate_der11712 * t891
* 0.32 ; intermediate_der11712 = pmf_sqrt ( ( ( real_T ) ( M [ 137ULL ] != 0
) * 2.0 - 1.0 ) * ( t911 / ( t895 == 0.0 ? 1.0E-16 : t895 ) / ( X [ 219ULL ]
== 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) * t814 * 0.64 ; t1794 = ( zc_int43 -
zc_int43 * 0.95 ) * ( zc_int43 - zc_int43 * 0.95 ) ; t872 = (
intermediate_der11712 - intermediate_der11712 * 0.95 ) * ( - ( zc_int42 -
zc_int43 * 0.95 ) / ( t1794 == 0.0 ? 1.0E-16 : t1794 ) ) + ( t869 -
intermediate_der11712 * 0.95 ) / ( U_idx_6 == 0.0 ? 1.0E-16 : U_idx_6 ) ;
t874 = t872 * t947 * 6.0 - t947 * t947 * t872 * 6.0 ; if ( t894 <= t893 *
0.95 ) { t872 = t869 * 100000.0 ; } else if ( t894 >= t893 ) { t872 =
intermediate_der11712 * 100000.0 ; } else { t872 = ( ( ( - t874 * zc_int42 +
( 1.0 - t929 ) * t869 ) + t874 * zc_int43 ) + intermediate_der11712 * t929 )
* 100000.0 ; } t874 = ( intermediate_der11712 - intermediate_der11712 * 0.95
) * ( - ( - zc_int42 - zc_int43 * 0.95 ) / ( t1794 == 0.0 ? 1.0E-16 : t1794 )
) + ( - t869 - intermediate_der11712 * 0.95 ) / ( U_idx_6 == 0.0 ? 1.0E-16 :
U_idx_6 ) ; t1822 = t874 * t961 * 6.0 - t961 * t961 * t874 * 6.0 ; if ( -
t894 <= t893 * 0.95 ) { t874 = t869 * 100000.0 ; } else if ( - t894 >= t893 )
{ t874 = - intermediate_der11712 * 100000.0 ; } else { t874 = ( ( ( - t1822 *
zc_int42 + ( 1.0 - t965 ) * t869 ) + - zc_int43 * t1822 ) + -
intermediate_der11712 * t965 ) * 100000.0 ; } t719 [ 0ULL ] = X [ 538ULL ] ;
t581 [ 0 ] = 5ULL ; tlu2_linear_nearest_prelookup ( & qh_efOut . mField0 [
0ULL ] , & qh_efOut . mField1 [ 0ULL ] , & qh_efOut . mField2 [ 0ULL ] , &
t714 [ 0ULL ] , & t719 [ 0ULL ] , & t581 [ 0ULL ] , & t76 [ 0ULL ] ) ; t68 =
qh_efOut ; t719 [ 0ULL ] = U_idx_12 * 376.99111843077515 *
0.99999999999999978 / 0.99999999999999978 * 0.99999999999999978 /
0.99999999999999978 ; t584 [ 0 ] = 3ULL ; tlu2_linear_nearest_prelookup ( &
rh_efOut . mField0 [ 0ULL ] , & rh_efOut . mField1 [ 0ULL ] , & rh_efOut .
mField2 [ 0ULL ] , & nonscalar64 [ 0ULL ] , & t719 [ 0ULL ] , & t584 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t60 = rh_efOut ; t1793 = M [ 214ULL ] != 0 ? X [ 81ULL ]
: 0.9 ; t869 = - ( ( X [ 90ULL ] - X [ 88ULL ] * X [ 89ULL ] * 0.001 ) * t73
/ ( t1793 == 0.0 ? 1.0E-16 : t1793 ) * 1000.0 + - t73 * X [ 81ULL ] / 1000.0
) ; if ( M [ 344ULL ] != 0 ) { t73 = - ( ( ( ( ( ( ( X [ 18ULL ] * 0.1 - X [
88ULL ] ) + X [ 89ULL ] * - 0.1 ) + X [ 172ULL ] * 1.0E-9 ) - X [ 174ULL ] )
+ X [ 19ULL ] ) - Fuel_Cell_Boost_Converter_L_i ) * intermediate_der8507 *
0.001 ) ; } else { t73 = - ( ( Fuel_Cell_Boost_Converter_L_i * 0.001 + X [
89ULL ] ) * intermediate_der8507 ) ; } t711 [ 0ULL ] = - ( - ( 0.0 * ( X [
161ULL ] / ( X [ 164ULL ] == 0.0 ? 1.0E-16 : X [ 164ULL ] ) ) ) /
1.1843079200592157 ) ; t711 [ 1ULL ] = 0.0 * ( X [ 161ULL ] / ( X [ 164ULL ]
== 0.0 ? 1.0E-16 : X [ 164ULL ] ) ) * ( X [ 7ULL ] + 126.84999999999997 ) ;
t711 [ 2ULL ] = ( ( 0.01 - t1804 ) * - 0.009810000000000001 + ( 0.01 - t1804
) * 0.009810000000000001 ) - 0.0 * ( X [ 15ULL ] / ( X [ 164ULL ] == 0.0 ?
1.0E-16 : X [ 164ULL ] ) * 100.0 + X [ 167ULL ] ) ; t711 [ 3ULL ] = ( - X [
96ULL ] / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 - ( ( t1862 *
t923 - X [ 98ULL ] * t1936 ) + t988 * 100.0 ) ) / 2.6578958850679178E+7 ;
t711 [ 4ULL ] = - ( t1862 * t923 + X [ 98ULL ] * t1936 ) /
1.3398809999599461E+7 ; t711 [ 5ULL ] = ( X [ 96ULL ] / ( t972 == 0.0 ?
1.0E-16 : t972 ) * t955 - ( ( t1902 * t1127 - X [ 98ULL ] * t1901 ) +
zc_int17 * 100.0 ) ) / 2.6578958850679178E+7 ; t711 [ 6ULL ] = - ( t1902 *
t1127 + X [ 98ULL ] * t1901 ) / 1.3398809999599461E+7 ; t711 [ 7ULL ] = ( - X
[ 105ULL ] / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 - ( ( t1904 *
t923 - X [ 107ULL ] * t1936 ) + U_idx_9 * 100.0 ) ) / 2.6578958850679178E+7 ;
t711 [ 8ULL ] = - ( t1904 * t923 + X [ 107ULL ] * t1936 ) /
1.3398809999599461E+7 ; t711 [ 9ULL ] = ( X [ 105ULL ] / ( t972 == 0.0 ?
1.0E-16 : t972 ) * t955 - ( (
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 * t1127 - X [
107ULL ] * t1901 ) + t1903 * 100.0 ) ) / 2.6578958850679178E+7 ; t711 [ 10ULL
] = - ( Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 *
t1127 + X [ 107ULL ] * t1901 ) / 1.3398809999599461E+7 ; t711 [ 11ULL ] = ( -
X [ 114ULL ] / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t923 - X [
116ULL ] * t1936 ) + t1908 * 100.0 ) ) / 2.6578958850679178E+7 ; t711 [ 12ULL
] = - ( Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 *
t923 + X [ 116ULL ] * t1936 ) / 1.3398809999599461E+7 ; t711 [ 13ULL ] = ( X
[ 114ULL ] / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t1127 - X [
116ULL ] * t1901 ) + t1830 * 100.0 ) ) / 2.6578958850679178E+7 ; t711 [ 14ULL
] = - ( Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 *
t1127 + X [ 116ULL ] * t1901 ) / 1.3398809999599461E+7 ; t711 [ 15ULL ] = ( -
X [ 114ULL ] / ( t1282 == 0.0 ? 1.0E-16 : t1282 ) * intermediate_der197 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t798 - X [
124ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) +
t797 * 100.0 ) ) / 1.328947942533959E+8 ; t711 [ 16ULL ] = - (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio5 * t798 + X [
124ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t711 [ 17ULL ] = ( - X [ 121ULL ] / ( t851 == 0.0 ?
1.0E-16 : t851 ) * t799 - ( (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t802 - X [
126ULL ] * intermediate_der242 ) + intermediate_der239 * 100.0 ) ) /
1.328947942533959E+8 ; t711 [ 18ULL ] = - (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t802 + X [
126ULL ] * intermediate_der242 ) / 6.6994049997997306E+7 ; t711 [ 19ULL ] = -
( U_idx_10 * 0.001 ) / 28.173600337531049 ; t711 [ 20ULL ] = - (
intermediate_der8213 - intermediate_der8886 ) ; t711 [ 21ULL ] = ( - X [
96ULL ] / ( t1282 == 0.0 ? 1.0E-16 : t1282 ) * intermediate_der197 - ( (
t1902 * t798 - X [ 129ULL ] *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) + t805 * 100.0 )
) / 1.328947942533959E+8 ; t711 [ 22ULL ] = - ( t1902 * t798 + X [ 129ULL ] *
Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t711 [ 23ULL ] = ( X [ 105ULL ] / ( t851 == 0.0 ?
1.0E-16 : t851 ) * t799 - ( ( t1904 * t802 - X [ 131ULL ] *
intermediate_der242 ) + intermediate_der349 * 100.0 ) ) /
1.328947942533959E+8 ; t711 [ 24ULL ] = - ( t1904 * t802 + X [ 131ULL ] *
intermediate_der242 ) / 6.6994049997997306E+7 ; t711 [ 25ULL ] = - (
intermediate_der358 * 0.001 ) ; t711 [ 26ULL ] = - ( t866 -
intermediate_der8955 ) ; t711 [ 27ULL ] = ( - X [ 105ULL ] / ( t1282 == 0.0 ?
1.0E-16 : t1282 ) * intermediate_der197 - ( (
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 * t798 - X [
134ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) +
t808 * 100.0 ) ) / 1.328947942533959E+8 ; t711 [ 28ULL ] = - (
Electrical_Cooling_System_Flow_Restriction_Converter_MotorR_co5 * t798 + X [
134ULL ] * Electrical_Cooling_System_Heat_Exchanger_pipe_model_Pr_avg ) /
6.6994049997997306E+7 ; t711 [ 29ULL ] = ( X [ 114ULL ] / ( t851 == 0.0 ?
1.0E-16 : t851 ) * t799 - ( (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t802 - X [
136ULL ] * intermediate_der242 ) + intermediate_der509 * 100.0 ) ) /
1.328947942533959E+8 ; t711 [ 30ULL ] = - (
Electrical_Cooling_System_Flow_Restriction_MotorR_HX_convectio2 * t802 + X [
136ULL ] * intermediate_der242 ) / 6.6994049997997306E+7 ; t711 [ 31ULL ] = -
( t806 * 0.001 ) ; t711 [ 32ULL ] = - ( t857 - intermediate_der9401 ) ; t711
[ 33ULL ] = ( - X [ 139ULL ] / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) *
t791 - ( ( Electrical_Cooling_System_Pump_convection_A_u_in * t923 - X [
141ULL ] * t1936 ) + intermediate_der539 * 100.0 ) ) / 2.6578958850679178E+7
; t711 [ 34ULL ] = - ( Electrical_Cooling_System_Pump_convection_A_u_in *
t923 + X [ 141ULL ] * t1936 ) / 1.3398809999599461E+7 ; t711 [ 35ULL ] = ( X
[ 96ULL ] / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 - ( ( t1862 * t1127 - X [
141ULL ] * t1901 ) + intermediate_der546 * 100.0 ) ) / 2.6578958850679178E+7
; t711 [ 36ULL ] = - ( t1862 * t1127 + X [ 141ULL ] * t1901 ) /
1.3398809999599461E+7 ; t711 [ 37ULL ] = intermediate_der553 * 100.0 ; t711 [
38ULL ] = ( X [ 139ULL ] / ( t972 == 0.0 ? 1.0E-16 : t972 ) * t955 - ( (
Electrical_Cooling_System_Pump_convection_A_u_in * t1127 - X [ 167ULL ] *
t1901 ) + intermediate_der8470 * 100.0 ) ) / 2.65794426837838E+7 ; t711 [
39ULL ] = ( X [ 121ULL ] / ( zc_int180 == 0.0 ? 1.0E-16 : zc_int180 ) * t791
- ( ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t923
- X [ 167ULL ] * t1936 ) + t1922 * 100.0 ) ) / 2.65794426837838E+7 ; t711 [
40ULL ] = - ( Electrical_Cooling_System_Pump_convection_A_u_in * t1127 + X [
167ULL ] * t1901 ) / 1.3398809999599461E+7 ; t711 [ 41ULL ] = - (
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio10 * t923 + X [
167ULL ] * t1936 ) / 1.3398809999599461E+7 ; t711 [ 42ULL ] = t822 ; t711 [
43ULL ] = intermediate_der8351 ; U_idx_10 = t891 * t891 ; U_idx_1 = - ( ( (
real_T ) ( M [ 170ULL ] != 0 ) * 2.0 - 1.0 ) * ( t899 / ( X [ 220ULL ] == 0.0
? 1.0E-16 : X [ 220ULL ] ) ) * ( t899 / ( X [ 220ULL ] == 0.0 ? 1.0E-16 : X [
220ULL ] ) ) * ( X [ 186ULL ] / 0.64 / ( t891 == 0.0 ? 1.0E-16 : t891 ) ) * (
- ( X [ 186ULL ] / 0.64 ) / ( U_idx_10 == 0.0 ? 1.0E-16 : U_idx_10 ) ) * t814
* 2.0 / 2.0 * 9.999999999999999E-14 ) ; t713 [ 0ULL ] = - ( ( - ( X [ 23ULL ]
* - 0.01 ) * ( - 164.72089615570803 / ( intrm_sf_mf_95 == 0.0 ? 1.0E-16 :
intrm_sf_mf_95 ) ) + - ( X [ 24ULL ] * - 0.01 ) * ( - 3827.6794129126583 / (
intrm_sf_mf_95 == 0.0 ? 1.0E-16 : intrm_sf_mf_95 ) ) ) / 12.896402563644669 )
; t713 [ 1ULL ] = - ( ( ( - ( X [ 23ULL ] * - 0.01 ) * ( t890 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) + - ( X [
24ULL ] * - 0.01 ) * ( t887 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u1 ) ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_u0 * - 0.01 ) /
2246.65922904024 ) ; t713 [ 2ULL ] = - ( X [ 23ULL ] * - 0.01 ) ; t713 [ 3ULL
] = - ( X [ 24ULL ] * - 0.01 ) ; t713 [ 4ULL ] = - ( ( - ( X [ 76ULL ] * 0.01
) * ( - 164.72089615570803 / ( t989 == 0.0 ? 1.0E-16 : t989 ) ) + - ( X [
75ULL ] * 0.01 ) * ( - 3827.6794129126583 / ( t989 == 0.0 ? 1.0E-16 : t989 )
) ) / 12.896402563644669 ) ; t713 [ 5ULL ] = - ( ( ( - ( X [ 76ULL ] * 0.01 )
* ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant29 - t987 )
+ - ( X [ 75ULL ] * 0.01 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Recirculation_Constant28 - t987 ) ) +
t790 * 0.01 ) / 2246.65922904024 ) ; t713 [ 6ULL ] = - ( X [ 76ULL ] * 0.01 )
; t713 [ 7ULL ] = - ( X [ 75ULL ] * 0.01 ) ; t713 [ 8ULL ] = - ( ( ( - 0.01 +
intermediate_der1148 ) / 2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 -
1.0 ) * ( t1178 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
t1178 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intermediate_der0 ) +
( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 + t885 ) /
2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1178 / ( X [
176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1178 / ( X [ 176ULL ] ==
0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( intermediate_der1148 - - 0.01 ) / 2.0 * X [
209ULL ] ) ; t713 [ 9ULL ] = - ( ( - 0.01 + intermediate_der1258 ) / 2.0 * X
[ 178ULL ] - ( intermediate_der1258 - - 0.01 ) / 2.0 * X [ 215ULL ] ) ; t713
[ 10ULL ] = - ( ( - 0.01 + intermediate_der1227 ) / 2.0 * X [ 177ULL ] - (
intermediate_der1227 - - 0.01 ) / 2.0 * X [ 214ULL ] ) ; t713 [ 11ULL ] = - (
t811 * 0.001 ) ; t713 [ 12ULL ] = - ( t1694 / 7.8539816339744827E-5 *
0.00031622776601683789 + t870 ) ; t713 [ 13ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 >= 0.0 ? 0.0
: - intermediate_der10838 ; U_idx_10 = X [ 199ULL ] * intrm_sf_mf_95 ; t713 [
14ULL ] = - ( ( ( real_T ) ( M [ 72ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_10 /
( X [ 200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * ( U_idx_10 / ( X [
200ULL ] == 0.0 ? 1.0E-16 : X [ 200ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t713 [ 15ULL ] = - ( ( ( real_T ) ( M [ 94ULL ] !=
0 ) * 2.0 - 1.0 ) * ( t847 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) )
* ( t847 / ( X [ 22ULL ] == 0.0 ? 1.0E-16 : X [ 22ULL ] ) ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t1922 = t992 + t993 ; t713 [ 16ULL ] = - ( ( ( 0.01
+ t853 ) / 2.0 * zc_int360 + t1922 / 2.0 * ( ( ( real_T ) ( M [ 36ULL ] != 0
) * 2.0 - 1.0 ) * ( t1173 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) )
* ( t1173 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t992 /
7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( t853 - 0.01 ) / 2.0 * X [ 564ULL ] ) ; t713 [
17ULL ] = - ( ( 0.01 + intermediate_der7296 ) / 2.0 * X [ 555ULL ] - (
intermediate_der7296 - 0.01 ) / 2.0 * X [ 566ULL ] ) ; t713 [ 18ULL ] = - ( (
0.01 + t844 ) / 2.0 * X [ 554ULL ] - ( t844 - 0.01 ) / 2.0 * X [ 565ULL ] ) ;
t1904 = X [ 74ULL ] * t989 ; t713 [ 19ULL ] = - ( ( ( real_T ) ( M [ 38ULL ]
!= 0 ) * 2.0 - 1.0 ) * ( t1904 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ]
) ) * ( t1904 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t992 /
7.8539816339744827E-5 ) * 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ; t713 [ 20ULL ] = - ( ( ( 0.01 + t853 ) / 2.0 * ( (
( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1178 / ( X [ 176ULL ] ==
0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1178 / ( X [ 176ULL ] == 0.0 ? 1.0E-16
: X [ 176ULL ] ) ) * ( t992 / 7.8539816339744827E-5 ) * ( t992 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 + intermediate_der0 ) +
t1922 / 2.0 * ( ( ( real_T ) ( M [ 13ULL ] != 0 ) * 2.0 - 1.0 ) * ( t1178 / (
X [ 176ULL ] == 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t1178 / ( X [ 176ULL ]
== 0.0 ? 1.0E-16 : X [ 176ULL ] ) ) * ( t992 / 7.8539816339744827E-5 ) *
127.32395447351628 * 2.0 / 2.0 * 9.999999999999999E-14 ) ) - ( t853 - 0.01 )
/ 2.0 * X [ 574ULL ] ) ; t713 [ 21ULL ] = - ( ( 0.01 + intermediate_der7296 )
/ 2.0 * X [ 178ULL ] - ( intermediate_der7296 - 0.01 ) / 2.0 * X [ 576ULL ] )
; t713 [ 22ULL ] = - ( ( 0.01 + t844 ) / 2.0 * X [ 177ULL ] - ( t844 - 0.01 )
/ 2.0 * X [ 575ULL ] ) ; t713 [ 23ULL ] = - ( ( ( - 0.01 + t856 ) / 2.0 *
t932 + ( - t992 + t993 ) / 2.0 * ( ( ( real_T ) ( M [ 36ULL ] != 0 ) * 2.0 -
1.0 ) * ( t1173 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( t1173
/ ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X [ 38ULL ] ) ) * ( - t992 /
7.8539816339744827E-5 ) * - 127.32395447351628 * 2.0 / 2.0 *
9.999999999999999E-14 ) ) - ( t856 - - 0.01 ) / 2.0 * X [ 574ULL ] ) ; t713 [
24ULL ] = - ( ( - 0.01 + t855 ) / 2.0 * X [ 555ULL ] - ( t855 - - 0.01 ) /
2.0 * X [ 576ULL ] ) ; t713 [ 25ULL ] = - ( ( - 0.01 + intermediate_der7331 )
/ 2.0 * X [ 554ULL ] - ( intermediate_der7331 - - 0.01 ) / 2.0 * X [ 575ULL ]
) ; t713 [ 26ULL ] = t873 ; t713 [ 27ULL ] = t871 ; t713 [ 28ULL ] =
intermediate_der11637 ; t714 [ 0ULL ] = - ( ( ( 1.0 - X [ 36ULL ] ) * ( -
164.72089615570803 / ( intrm_sf_mf_545 == 0.0 ? 1.0E-16 : intrm_sf_mf_545 ) )
+ - X [ 35ULL ] * ( - 3827.6794129126583 / ( intrm_sf_mf_545 == 0.0 ? 1.0E-16
: intrm_sf_mf_545 ) ) ) / 12.896402563644669 ) ; t714 [ 1ULL ] = - ( ( ( (
t912 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) * (
1.0 - X [ 36ULL ] ) + - X [ 35ULL ] * ( t910 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Pipe_43 ) ) + t907 )
/ 2246.65922904024 ) ; t714 [ 2ULL ] = - X [ 36ULL ] ; t714 [ 3ULL ] = - X [
35ULL ] ; t714 [ 4ULL ] = zc_int116 ; t715 [ 0ULL ] = - ( ( - X [ 313ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M22 ) / 2.0 *
t821 ) ; t715 [ 1ULL ] = - X [ 313ULL ] >= 0.0 ? - 10.0 : -
intermediate_der10249 ; t715 [ 2ULL ] = - ( ( X [ 313ULL ] + t778 ) / 2.0 *
intrm_sf_mf_56 ) ; t715 [ 3ULL ] = t926 >= 0.0 ? - intermediate_der3747 : -
intermediate_der10338 ; t715 [ 4ULL ] = - ( U_idx_3 - t818 ) ; U_idx_10 = X [
347ULL ] * t928 ; U_idx_3 = - ( X [ 347ULL ] * t928 ) ; t715 [ 5ULL ] = - ( (
( ( real_T ) ( M [ 335ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_10 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( U_idx_3 / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 + ( ( real_T ) ( M
[ 335ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_10 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M0 ) )
* ( U_idx_3 / ( t1456 == 0.0 ? 1.0E-16 : t1456 ) ) * 10.0 ) * ( X [ 313ULL ]
/ 0.64 / 0.0019634954084936209 ) * ( X [ 313ULL ] / 0.64 /
0.0019634954084936209 ) / 2.0 * 9.999999999999999E-14 ) ; t716 [ 0ULL ] = - (
( 1.0 - X [ 53ULL ] ) * ( - 164.72089615570803 / ( t784 == 0.0 ? 1.0E-16 :
t784 ) ) + - X [ 52ULL ] * ( 36.965491221318985 / ( t784 == 0.0 ? 1.0E-16 :
t784 ) ) ) ; t716 [ 1ULL ] = - ( ( ( ( ( t946 - X [ 51ULL ] * 0.461523 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) * ( 1.0 - X
[ 53ULL ] ) + - X [ 52ULL ] * ( t948 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip43 ) ) +
intrm_sf_mf_1142 ) / 2172.7681408465714 ) ; t716 [ 2ULL ] = - X [ 53ULL ] ;
t716 [ 3ULL ] = - X [ 52ULL ] ; t716 [ 4ULL ] = t841 ; t717 [ 0ULL ] = ( - (
- X [ 430ULL ] - X [ 431ULL ] ) / ( t1464 == 0.0 ? 1.0E-16 : t1464 ) *
intermediate_der3714 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 *
intermediate_der5455 - X [ 435ULL ] * intermediate_der5453 ) + ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant3 / ( t1464 ==
0.0 ? 1.0E-16 : t1464 ) * intermediate_der3714 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant4 ) )
* 1.01325 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant6
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant6 ) * 100.0 ) )
/ 1.233284047215034E+6 ; t717 [ 1ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 *
intermediate_der5455 + X [ 435ULL ] * intermediate_der5453 ) /
171803.29647667333 ; t717 [ 2ULL ] = ( - X [ 431ULL ] / ( t1473 == 0.0 ?
1.0E-16 : t1473 ) * t823 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 * t827 - X [
454ULL ] * t826 ) + ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1473 ==
0.0 ? 1.0E-16 : t1473 ) * t823 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
* 1.01325 / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co3
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co3 ) * 100.0 ) )
/ 8.80132724281134E+6 ; t717 [ 3ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant9 * t827 + X [
454ULL ] * t826 ) / 1.2260736179143097E+6 ; t717 [ 4ULL ] = ( - X [ 452ULL ]
/ ( t1487 == 0.0 ? 1.0E-16 : t1487 ) * intermediate_der5551 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 * t832 - X [
454ULL ] * t830 ) + (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1487 ==
0.0 ? 1.0E-16 : t1487 ) * intermediate_der5551 + - 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co1 ) )
* X [ 451ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co8 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co8 ) *
100.0 ) ) / 8.80132724281134E+6 ; t717 [ 5ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 * t832 + X [
454ULL ] * t830 ) / 1.2260736179143097E+6 ; t717 [ 6ULL ] = ( X [ 451ULL ] -
1.01325 ) * 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_rho_ == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_rho_ ) *
100.0 ; t717 [ 7ULL ] = ( X [ 452ULL ] / ( t1502 == 0.0 ? 1.0E-16 : t1502 ) *
intermediate_der5591 - ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 *
intermediate_der5598 - X [ 457ULL ] * intermediate_der5597 ) + ( -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co0 / ( t1502 ==
0.0 ? 1.0E-16 : t1502 ) * intermediate_der5591 + 2.0 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato7 ) )
* X [ 451ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato9 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Radiato9 ) *
100.0 ) ) / 6.3686514346761458E+7 ; t717 [ 8ULL ] = - (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_co11 *
intermediate_der5598 + X [ 457ULL ] * intermediate_der5597 ) /
8.87188408103589E+6 ; t717 [ 9ULL ] = - intermediate_der8034 ; t717 [ 10ULL ]
= - t800 ; t718 [ 0ULL ] = - ( ( - X [ 478ULL ] + t962 ) / 2.0 * t839 ) ;
t718 [ 1ULL ] = - X [ 478ULL ] >= 0.0 ? - 10.0 : - intermediate_der11334 ;
t718 [ 2ULL ] = - ( ( X [ 478ULL ] +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T8 ) / 2.0 * (
t1723 / 2.0 * 9.999999999999999E-14 ) ) ; t718 [ 3ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu25 >= 0.0 ? -
intermediate_der11512 : - intermediate_der11539 ; t718 [ 4ULL ] = - (
intermediate_der8325 - t775 ) ; U_idx_10 = X [ 511ULL ] * t971 ; U_idx_3 = -
( X [ 511ULL ] * t971 ) ; t718 [ 5ULL ] = - ( ( ( ( real_T ) ( M [ 24ULL ] !=
0 ) * 2.0 - 1.0 ) * ( U_idx_10 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) )
* ( U_idx_3 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 + ( ( real_T ) ( M
[ 24ULL ] != 0 ) * 2.0 - 1.0 ) * ( U_idx_10 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M0 ) )
* ( U_idx_3 / ( t1513 == 0.0 ? 1.0E-16 : t1513 ) ) * 10.0 ) * ( - X [ 478ULL
] / 0.64 / 7.8539816339744827E-5 ) * ( - X [ 478ULL ] / 0.64 /
7.8539816339744827E-5 ) / 2.0 * 9.999999999999999E-14 ) ;
tlu2_2d_linear_nearest_value ( & sh_efOut [ 0ULL ] , & t68 . mField0 [ 0ULL ]
, & t68 . mField2 [ 0ULL ] , & t60 . mField1 [ 0ULL ] , & t60 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField51 , & t581 [ 0ULL ] , &
t584 [ 0ULL ] , & t76 [ 0ULL ] ) ; t719 [ 0 ] = sh_efOut [ 0 ] ; t589 [ 0ULL
] = - ( ( Electrical_Cooling_System_Heat_Exchanger_pipe_model_k_I *
0.031415926535897927 / 0.01 + intermediate_der149 ) * 0.001 ) /
28.173600337531049 ; t589 [ 1ULL ] = t869 ; for ( t727 = 0ULL ; t727 < 44ULL
; t727 ++ ) { t589 [ t727 + 2ULL ] = t711 [ t727 ] ; } t589 [ 46ULL ] = t894
>= 0.0 ? - t872 : - t874 ; t589 [ 47ULL ] = t815 ; t589 [ 48ULL ] = U_idx_1 ;
for ( t727 = 0ULL ; t727 < 29ULL ; t727 ++ ) { t589 [ t727 + 49ULL ] = t713 [
t727 ] ; } for ( t727 = 0ULL ; t727 < 5ULL ; t727 ++ ) { t589 [ t727 + 78ULL
] = t714 [ t727 ] ; } t589 [ 83ULL ] = U_idx_5 * intermediate_der9757 ; for (
t727 = 0ULL ; t727 < 6ULL ; t727 ++ ) { t589 [ t727 + 84ULL ] = t715 [ t727 ]
; } for ( t727 = 0ULL ; t727 < 5ULL ; t727 ++ ) { t589 [ t727 + 90ULL ] =
t716 [ t727 ] ; } t589 [ 95ULL ] = U_idx_8 * intermediate_der9543 ; for (
t727 = 0ULL ; t727 < 11ULL ; t727 ++ ) { t589 [ t727 + 96ULL ] = t717 [ t727
] ; } for ( t727 = 0ULL ; t727 < 6ULL ; t727 ++ ) { t589 [ t727 + 107ULL ] =
t718 [ t727 ] ; } t589 [ 113ULL ] = - ( t719 [ 0ULL ] * 376.99111843077515 )
; t589 [ 114ULL ] = t73 ; t589 [ 115ULL ] = - ( Fuel_Cell_Boost_Converter_L_i
* intermediate_der8507 ) ; for ( b = 0 ; b < 116 ; b ++ ) { out . mX [ b ] =
t589 [ b ] ; } ( void ) LC ; ( void ) t1971 ; return 0 ; }
