#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_log.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_log ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t1252 , NeDsMethodOutput * t1253 ) { ETTS0
ab_efOut ; ETTS0 ac_efOut ; ETTS0 ae_efOut ; ETTS0 b_efOut ; ETTS0 bb_efOut ;
ETTS0 bf_efOut ; ETTS0 cg_efOut ; ETTS0 d_efOut ; ETTS0 db_efOut ; ETTS0
de_efOut ; ETTS0 dh_efOut ; ETTS0 e_efOut ; ETTS0 eb_efOut ; ETTS0 ec_efOut ;
ETTS0 ed_efOut ; ETTS0 ee_efOut ; ETTS0 efOut ; ETTS0 fc_efOut ; ETTS0
g_efOut ; ETTS0 ge_efOut ; ETTS0 gf_efOut ; ETTS0 h_efOut ; ETTS0 he_efOut ;
ETTS0 hg_efOut ; ETTS0 ib_efOut ; ETTS0 jb_efOut ; ETTS0 jc_efOut ; ETTS0
jd_efOut ; ETTS0 ke_efOut ; ETTS0 l_efOut ; ETTS0 lb_efOut ; ETTS0 lf_efOut ;
ETTS0 m_efOut ; ETTS0 mb_efOut ; ETTS0 me_efOut ; ETTS0 mg_efOut ; ETTS0
ne_efOut ; ETTS0 o_efOut ; ETTS0 ob_efOut ; ETTS0 oc_efOut ; ETTS0 od_efOut ;
ETTS0 p_efOut ; ETTS0 pb_efOut ; ETTS0 pe_efOut ; ETTS0 pf_efOut ; ETTS0
qe_efOut ; ETTS0 qg_efOut ; ETTS0 r_efOut ; ETTS0 s_efOut ; ETTS0 se_efOut ;
ETTS0 t55 ; ETTS0 t64 ; ETTS0 t69 ; ETTS0 t70 ; ETTS0 t71 ; ETTS0 tb_efOut ;
ETTS0 tc_efOut ; ETTS0 td_efOut ; ETTS0 te_efOut ; ETTS0 tf_efOut ; ETTS0
ub_efOut ; ETTS0 ug_efOut ; ETTS0 w_efOut ; ETTS0 we_efOut ; ETTS0 x_efOut ;
ETTS0 xf_efOut ; ETTS0 yb_efOut ; ETTS0 yc_efOut ; ETTS0 yd_efOut ; ETTS0
ye_efOut ; ETTS0 yg_efOut ; PmRealVector out ; real_T t545 [ 2476 ] ; real_T
X [ 582 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ 8 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 8 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 8 ] ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ 8 ] ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 8 ]
; real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 8
] ; real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ 8
] ; real_T t576 [ 8 ] ; real_T t593 [ 8 ] ; real_T t621 [ 8 ] ; real_T t626 [
8 ] ; real_T t643 [ 8 ] ; real_T t648 [ 8 ] ; real_T t706 [ 2 ] ; real_T
ad_efOut [ 1 ] ; real_T af_efOut [ 1 ] ; real_T ag_efOut [ 1 ] ; real_T
ah_efOut [ 1 ] ; real_T bc_efOut [ 1 ] ; real_T bd_efOut [ 1 ] ; real_T
be_efOut [ 1 ] ; real_T bg_efOut [ 1 ] ; real_T bh_efOut [ 1 ] ; real_T
c_efOut [ 1 ] ; real_T cb_efOut [ 1 ] ; real_T cc_efOut [ 1 ] ; real_T
cd_efOut [ 1 ] ; real_T ce_efOut [ 1 ] ; real_T cf_efOut [ 1 ] ; real_T
ch_efOut [ 1 ] ; real_T dc_efOut [ 1 ] ; real_T dd_efOut [ 1 ] ; real_T
df_efOut [ 1 ] ; real_T dg_efOut [ 1 ] ; real_T ef_efOut [ 1 ] ; real_T
eg_efOut [ 1 ] ; real_T eh_efOut [ 1 ] ; real_T f_efOut [ 1 ] ; real_T
fb_efOut [ 1 ] ; real_T fd_efOut [ 1 ] ; real_T fe_efOut [ 1 ] ; real_T
ff_efOut [ 1 ] ; real_T fg_efOut [ 1 ] ; real_T fh_efOut [ 1 ] ; real_T
gb_efOut [ 1 ] ; real_T gc_efOut [ 1 ] ; real_T gd_efOut [ 1 ] ; real_T
gg_efOut [ 1 ] ; real_T gh_efOut [ 1 ] ; real_T hb_efOut [ 1 ] ; real_T
hc_efOut [ 1 ] ; real_T hd_efOut [ 1 ] ; real_T hf_efOut [ 1 ] ; real_T
hh_efOut [ 1 ] ; real_T i_efOut [ 1 ] ; real_T ic_efOut [ 1 ] ; real_T
id_efOut [ 1 ] ; real_T ie_efOut [ 1 ] ; real_T if_efOut [ 1 ] ; real_T
ig_efOut [ 1 ] ; real_T j_efOut [ 1 ] ; real_T je_efOut [ 1 ] ; real_T
jf_efOut [ 1 ] ; real_T jg_efOut [ 1 ] ; real_T k_efOut [ 1 ] ; real_T
kb_efOut [ 1 ] ; real_T kc_efOut [ 1 ] ; real_T kd_efOut [ 1 ] ; real_T
kf_efOut [ 1 ] ; real_T kg_efOut [ 1 ] ; real_T lc_efOut [ 1 ] ; real_T
ld_efOut [ 1 ] ; real_T le_efOut [ 1 ] ; real_T lg_efOut [ 1 ] ; real_T
mc_efOut [ 1 ] ; real_T md_efOut [ 1 ] ; real_T mf_efOut [ 1 ] ; real_T
n_efOut [ 1 ] ; real_T nb_efOut [ 1 ] ; real_T nc_efOut [ 1 ] ; real_T
nd_efOut [ 1 ] ; real_T nf_efOut [ 1 ] ; real_T ng_efOut [ 1 ] ; real_T
oe_efOut [ 1 ] ; real_T of_efOut [ 1 ] ; real_T og_efOut [ 1 ] ; real_T
pc_efOut [ 1 ] ; real_T pd_efOut [ 1 ] ; real_T pg_efOut [ 1 ] ; real_T
q_efOut [ 1 ] ; real_T qb_efOut [ 1 ] ; real_T qc_efOut [ 1 ] ; real_T
qd_efOut [ 1 ] ; real_T qf_efOut [ 1 ] ; real_T rb_efOut [ 1 ] ; real_T
rc_efOut [ 1 ] ; real_T rd_efOut [ 1 ] ; real_T re_efOut [ 1 ] ; real_T
rf_efOut [ 1 ] ; real_T rg_efOut [ 1 ] ; real_T sb_efOut [ 1 ] ; real_T
sc_efOut [ 1 ] ; real_T sd_efOut [ 1 ] ; real_T sf_efOut [ 1 ] ; real_T
sg_efOut [ 1 ] ; real_T t525 [ 1 ] ; real_T t546 [ 1 ] ; real_T t665 [ 1 ] ;
real_T t77 [ 1 ] ; real_T t_efOut [ 1 ] ; real_T tg_efOut [ 1 ] ; real_T
u_efOut [ 1 ] ; real_T uc_efOut [ 1 ] ; real_T ud_efOut [ 1 ] ; real_T
ue_efOut [ 1 ] ; real_T uf_efOut [ 1 ] ; real_T v_efOut [ 1 ] ; real_T
vb_efOut [ 1 ] ; real_T vc_efOut [ 1 ] ; real_T vd_efOut [ 1 ] ; real_T
ve_efOut [ 1 ] ; real_T vf_efOut [ 1 ] ; real_T vg_efOut [ 1 ] ; real_T
wb_efOut [ 1 ] ; real_T wc_efOut [ 1 ] ; real_T wd_efOut [ 1 ] ; real_T
wf_efOut [ 1 ] ; real_T wg_efOut [ 1 ] ; real_T xb_efOut [ 1 ] ; real_T
xc_efOut [ 1 ] ; real_T xd_efOut [ 1 ] ; real_T xe_efOut [ 1 ] ; real_T
xg_efOut [ 1 ] ; real_T y_efOut [ 1 ] ; real_T yf_efOut [ 1 ] ; real_T
Battery_System_Battery_Table_Based_Q ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio7 ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_p_I ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ; real_T
Electrical_Cooling_System_Heat_Exchanger_pipe_model_u_I ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection3 ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ; real_T
Electrical_Cooling_System_Pipe_Converter_pipe_model_u_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_convection_B_rh ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ; real_T
Electrical_Cooling_System_Pipe_Motor_pipe_model_u_I ; real_T
Electrical_Cooling_System_Pump_rho_avg ; real_T
Electrical_Cooling_System_Tank_Tank_level ; real_T
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co ; real_T
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 ; real_T
Fuel_Cell_Boost_Converter_L_i ; real_T Fuel_Cell_Boost_Converter_L_n_v ;
real_T Fuel_Cell_Boost_Converter_L_p_v ; real_T Fuel_Cell_Boost_Converter_i2
; real_T Fuel_Cell_Current_Sensor1_I ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_powe ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ; real_T
U_idx_0 ; real_T U_idx_1 ; real_T U_idx_10 ; real_T U_idx_11 ; real_T
U_idx_12 ; real_T U_idx_13 ; real_T U_idx_14 ; real_T U_idx_15 ; real_T
U_idx_2 ; real_T U_idx_3 ; real_T U_idx_4 ; real_T U_idx_5 ; real_T U_idx_6 ;
real_T U_idx_7 ; real_T U_idx_8 ; real_T U_idx_9 ; real_T intrm_sf_mf_1359 ;
real_T intrm_sf_mf_1368 ; real_T intrm_sf_mf_1371 ; real_T intrm_sf_mf_1372 ;
real_T intrm_sf_mf_1431 ; real_T intrm_sf_mf_1629 ; real_T intrm_sf_mf_19 ;
real_T intrm_sf_mf_2 ; real_T intrm_sf_mf_24 ; real_T intrm_sf_mf_47 ; real_T
intrm_sf_mf_5 ; real_T intrm_sf_mf_691 ; real_T intrm_sf_mf_724 ; real_T
intrm_sf_mf_901 ; real_T piece22 ; real_T piece23 ; real_T piece99 ; real_T
t1169 ; real_T t1186 ; real_T t1211 ; real_T t1227 ; real_T t1229 ; real_T
t1231 ; real_T t1244 ; real_T t1251 ; real_T t662_idx_0 ; real_T t702 ;
real_T t704 ; real_T t714 ; real_T t723 ; real_T t750 ; real_T t762 ; real_T
t776 ; real_T t777 ; real_T t778 ; real_T t779 ; real_T t780 ; real_T t781 ;
real_T t782 ; real_T t783 ; real_T t787 ; real_T t788 ; real_T t793 ; real_T
t794 ; real_T t797 ; real_T t798 ; real_T t799 ; real_T t802 ; real_T t803 ;
real_T t804 ; real_T t805 ; real_T t806 ; real_T t807 ; real_T t808 ; real_T
t809 ; real_T t812 ; real_T t814 ; real_T t815 ; real_T t816 ; real_T t817 ;
real_T t818 ; real_T t821 ; real_T t823 ; real_T t825 ; real_T t826 ; real_T
t828 ; real_T t831 ; real_T t833 ; real_T t835 ; real_T t839 ; real_T t842 ;
real_T t844 ; real_T t846 ; real_T t848 ; real_T t849 ; real_T t851 ; real_T
t854 ; real_T t855 ; real_T t857 ; real_T t861 ; real_T t868 ; real_T t874 ;
real_T t875 ; real_T t878 ; real_T t880 ; real_T t886 ; real_T t888 ; real_T
t890 ; real_T t891 ; real_T t893 ; real_T t896 ; real_T t898 ; real_T t899 ;
real_T t902 ; real_T t903 ; real_T t904 ; real_T t906 ; real_T t907 ; real_T
t910 ; real_T t911 ; real_T t912 ; real_T t913 ; real_T t917 ; real_T t918 ;
real_T t920 ; real_T t921 ; real_T t926 ; real_T t929 ; real_T t931 ; real_T
t935 ; real_T t936 ; real_T t937 ; real_T t938 ; real_T t939 ; real_T t941 ;
real_T t942 ; real_T t944 ; real_T t947 ; real_T t948 ; real_T t955 ; real_T
t956 ; real_T t957 ; real_T t960 ; real_T t962 ; real_T t963 ; real_T t964 ;
real_T t965 ; real_T t968 ; real_T t970 ; real_T t980 ; real_T t986 ; size_t
t252 [ 1 ] ; size_t t340 [ 1 ] ; size_t t343 [ 1 ] ; size_t t75 [ 1 ] ;
size_t t76 [ 1 ] ; size_t t692 ; size_t t697 ; int32_T b ; U_idx_0 = t1252 ->
mU . mX [ 0 ] ; U_idx_1 = t1252 -> mU . mX [ 1 ] ; U_idx_2 = t1252 -> mU . mX
[ 2 ] ; U_idx_3 = t1252 -> mU . mX [ 3 ] ; U_idx_4 = t1252 -> mU . mX [ 4 ] ;
U_idx_5 = t1252 -> mU . mX [ 5 ] ; U_idx_6 = t1252 -> mU . mX [ 6 ] ; U_idx_7
= t1252 -> mU . mX [ 7 ] ; U_idx_8 = t1252 -> mU . mX [ 8 ] ; U_idx_9 = t1252
-> mU . mX [ 9 ] ; U_idx_10 = t1252 -> mU . mX [ 10 ] ; U_idx_11 = t1252 ->
mU . mX [ 11 ] ; U_idx_12 = t1252 -> mU . mX [ 12 ] ; U_idx_13 = t1252 -> mU
. mX [ 13 ] ; U_idx_14 = t1252 -> mU . mX [ 14 ] ; U_idx_15 = t1252 -> mU .
mX [ 15 ] ; for ( b = 0 ; b < 582 ; b ++ ) { X [ b ] = t1252 -> mX . mX [ b ]
; } out = t1253 -> mLOG ; Battery_System_Battery_Table_Based_Q = X [ 0ULL ] *
- 0.01 + U_idx_0 * 0.01 ; t546 [ 0ULL ] = pmf_get_inf ( ) ; for ( t692 = 0ULL
; t692 < 42ULL ; t692 ++ ) { t697 = t692 / 42ULL ; t702 = t546 [ t697 > 0ULL
? 0ULL : t697 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( (
_NeDynamicSystem * ) ( LC ) ) -> mField0 [ t692 ] * 1.0E-5 ; t546 [ t697 >
0ULL ? 0ULL : t697 ] = t702 >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 : t702 ; }
t704 = X [ 80ULL ] ; intrm_sf_mf_2 = t546 [ 0ULL ] ; t702 = t704 >
intrm_sf_mf_2 ? t704 : intrm_sf_mf_2 ; t704 = - X [ 79ULL ] - U_idx_1 ;
intrm_sf_mf_2 = ( ( ( real_T ) ( t704 >= 0.0 ) * t704 * 1000.0 + ( real_T ) (
t704 < 0.0 ) * X [ 81ULL ] ) - 0.9 ) / 0.099999999999999978 ; if ( ( real_T )
( t704 >= 0.0 ) * t704 * 1000.0 + ( real_T ) ( t704 < 0.0 ) * X [ 81ULL ] <=
0.9 ) { intrm_sf_mf_2 = 0.0 ; } else { intrm_sf_mf_2 = ( real_T ) ( t704 >=
0.0 ) * t704 * 1000.0 + ( real_T ) ( t704 < 0.0 ) * X [ 81ULL ] >= 1.0 ? 1.0
: intrm_sf_mf_2 * intrm_sf_mf_2 * 3.0 - intrm_sf_mf_2 * intrm_sf_mf_2 *
intrm_sf_mf_2 * 2.0 ; } t776 = ( X [ 4ULL ] * 0.01 + X [ 5ULL ] * - 0.01 ) +
X [ 91ULL ] ; t777 = X [ 4ULL ] * 0.01 + X [ 5ULL ] * - 0.01 ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_p_I = ( X [ 113ULL ] + X
[ 120ULL ] ) / 2.0 ; t546 [ 0ULL ] = X [ 123ULL ] ; t75 [ 0 ] = 20ULL ; t76 [
0 ] = 1ULL ; tlu2_linear_linear_prelookup ( & efOut . mField0 [ 0ULL ] , &
efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField2 , & t546 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] )
; t69 = efOut ; t77 [ 0ULL ] = X [ 113ULL ] ; t252 [ 0 ] = 19ULL ;
tlu2_linear_linear_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t77 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71
= b_efOut ; tlu2_2d_linear_linear_value ( & c_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t665 [ 0 ] = c_efOut [ 0 ] ;
t778 = t665 [ 0ULL ] ; t665 [ 0ULL ] = X [ 125ULL ] ;
tlu2_linear_linear_prelookup ( & d_efOut . mField0 [ 0ULL ] , & d_efOut .
mField1 [ 0ULL ] , & d_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t665 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69
= d_efOut ; t525 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_linear_prelookup ( &
e_efOut . mField0 [ 0ULL ] , & e_efOut . mField1 [ 0ULL ] , & e_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = e_efOut ;
tlu2_2d_linear_linear_value ( & f_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] ,
& t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75 [ 0ULL ] , & t252 [
0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = f_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio7 = t662_idx_0 ;
t525 [ 0ULL ] = X [ 6ULL ] ; tlu2_linear_linear_prelookup ( & g_efOut .
mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [
0ULL ] , & t76 [ 0ULL ] ) ; t69 = g_efOut ; t525 [ 0ULL ] =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_p_I ;
tlu2_linear_linear_prelookup ( & h_efOut . mField0 [ 0ULL ] , & h_efOut .
mField1 [ 0ULL ] , & h_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = h_efOut ; tlu2_2d_linear_linear_value ( & i_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = i_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I = t662_idx_0 ;
tlu2_2d_linear_linear_value ( & j_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] ,
& t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t75 [ 0ULL ] , & t252 [
0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = j_efOut [ 0 ] ; intrm_sf_mf_5 =
t662_idx_0 ; tlu2_2d_linear_linear_value ( & k_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = k_efOut [ 0 ] ;
Electrical_Cooling_System_Heat_Exchanger_pipe_model_u_I = t662_idx_0 ; t779 =
( X [ 7ULL ] * - 0.0002 + X [ 8ULL ] * - 2.0E-6 ) + U_idx_0 * 0.000202 ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I = ( X [ 95ULL ] + X [
102ULL ] ) / 2.0 ; t525 [ 0ULL ] = X [ 128ULL ] ;
tlu2_linear_linear_prelookup ( & l_efOut . mField0 [ 0ULL ] , & l_efOut .
mField1 [ 0ULL ] , & l_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71
= l_efOut ; t525 [ 0ULL ] = X [ 95ULL ] ; tlu2_linear_linear_prelookup ( &
m_efOut . mField0 [ 0ULL ] , & m_efOut . mField1 [ 0ULL ] , & m_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = m_efOut ;
tlu2_2d_linear_linear_value ( & n_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] ,
& t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75 [ 0ULL ] , & t252 [
0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = n_efOut [ 0 ] ; t780 = t662_idx_0 ;
t525 [ 0ULL ] = X [ 130ULL ] ; tlu2_linear_linear_prelookup ( & o_efOut .
mField0 [ 0ULL ] , & o_efOut . mField1 [ 0ULL ] , & o_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [
0ULL ] , & t76 [ 0ULL ] ) ; t64 = o_efOut ; t525 [ 0ULL ] = X [ 102ULL ] ;
tlu2_linear_linear_prelookup ( & p_efOut . mField0 [ 0ULL ] , & p_efOut .
mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = p_efOut ; tlu2_2d_linear_linear_value ( & q_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = q_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_convection3 = t662_idx_0
; t525 [ 0ULL ] = X [ 9ULL ] ; tlu2_linear_linear_prelookup ( & r_efOut .
mField0 [ 0ULL ] , & r_efOut . mField1 [ 0ULL ] , & r_efOut . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [
0ULL ] , & t76 [ 0ULL ] ) ; t69 = r_efOut ; t525 [ 0ULL ] =
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I ;
tlu2_linear_linear_prelookup ( & s_efOut . mField0 [ 0ULL ] , & s_efOut .
mField1 [ 0ULL ] , & s_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = s_efOut ; tlu2_2d_linear_linear_value ( & t_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = t_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I = t662_idx_0 ;
tlu2_2d_linear_linear_value ( & u_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] ,
& t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t75 [ 0ULL ] , & t252 [
0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = u_efOut [ 0 ] ; intrm_sf_mf_724 =
t662_idx_0 ; tlu2_2d_linear_linear_value ( & v_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = v_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Converter_pipe_model_u_I = t662_idx_0 ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I = ( X [ 104ULL ] + X [
111ULL ] ) / 2.0 ; t525 [ 0ULL ] = X [ 133ULL ] ;
tlu2_linear_linear_prelookup ( & w_efOut . mField0 [ 0ULL ] , & w_efOut .
mField1 [ 0ULL ] , & w_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71
= w_efOut ; t525 [ 0ULL ] = X [ 104ULL ] ; tlu2_linear_linear_prelookup ( &
x_efOut . mField0 [ 0ULL ] , & x_efOut . mField1 [ 0ULL ] , & x_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t64 = x_efOut ;
tlu2_2d_linear_linear_value ( & y_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] ,
& t71 . mField2 [ 0ULL ] , & t64 . mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL
] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75 [ 0ULL ] , & t252 [
0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = y_efOut [ 0 ] ; t781 = t662_idx_0 ;
t525 [ 0ULL ] = X [ 135ULL ] ; tlu2_linear_linear_prelookup ( & ab_efOut .
mField0 [ 0ULL ] , & ab_efOut . mField1 [ 0ULL ] , & ab_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , &
t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t70 = ab_efOut ; t525 [ 0ULL ] = X [ 111ULL
] ; tlu2_linear_linear_prelookup ( & bb_efOut . mField0 [ 0ULL ] , & bb_efOut
. mField1 [ 0ULL ] , & bb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = bb_efOut ; tlu2_2d_linear_linear_value ( & cb_efOut [ 0ULL ] , & t70 .
mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = cb_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_convection_B_rh = t662_idx_0
; t525 [ 0ULL ] = X [ 11ULL ] ; tlu2_linear_linear_prelookup ( & db_efOut .
mField0 [ 0ULL ] , & db_efOut . mField1 [ 0ULL ] , & db_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , &
t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = db_efOut ; t525 [ 0ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I ;
tlu2_linear_linear_prelookup ( & eb_efOut . mField0 [ 0ULL ] , & eb_efOut .
mField1 [ 0ULL ] , & eb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = eb_efOut ; tlu2_2d_linear_linear_value ( & fb_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = fb_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I = t662_idx_0 ;
tlu2_2d_linear_linear_value ( & gb_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField7 , & t75 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = gb_efOut [ 0 ] ;
intrm_sf_mf_901 = t662_idx_0 ; tlu2_2d_linear_linear_value ( & hb_efOut [
0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField4 , & t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t662_idx_0 = hb_efOut [ 0 ] ;
Electrical_Cooling_System_Pipe_Motor_pipe_model_u_I = t662_idx_0 ; t525 [
0ULL ] = X [ 140ULL ] ; tlu2_linear_linear_prelookup ( & ib_efOut . mField0 [
0ULL ] , & ib_efOut . mField1 [ 0ULL ] , & ib_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] ,
& t76 [ 0ULL ] ) ; t71 = ib_efOut ; t525 [ 0ULL ] = X [ 138ULL ] ;
tlu2_linear_linear_prelookup ( & jb_efOut . mField0 [ 0ULL ] , & jb_efOut .
mField1 [ 0ULL ] , & jb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t69 = jb_efOut ; tlu2_2d_linear_linear_value ( & kb_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , &
t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = kb_efOut [ 0 ] ;
Electrical_Cooling_System_Pump_rho_avg = t662_idx_0 ; t525 [ 0ULL ] = X [
142ULL ] ; tlu2_linear_linear_prelookup ( & lb_efOut . mField0 [ 0ULL ] , &
lb_efOut . mField1 [ 0ULL ] , & lb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] ,
& t76 [ 0ULL ] ) ; t69 = lb_efOut ; t525 [ 0ULL ] = X [ 93ULL ] ;
tlu2_linear_linear_prelookup ( & mb_efOut . mField0 [ 0ULL ] , & mb_efOut .
mField1 [ 0ULL ] , & mb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = mb_efOut ; tlu2_2d_linear_linear_value ( & nb_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = nb_efOut [ 0 ] ;
Electrical_Cooling_System_Pump_rho_avg = (
Electrical_Cooling_System_Pump_rho_avg + t662_idx_0 ) / 2.0 ; t782 = X [
138ULL ] - X [ 93ULL ] ; t783 = t782 * X [ 143ULL ] * 0.0001 ; t787 = X [
7ULL ] * 0.0002 + U_idx_0 * - 0.0002 ; t788 = X [ 8ULL ] * 2.0E-6 + U_idx_0 *
- 2.0E-6 ; Electrical_Cooling_System_Tank_Tank_level = X [ 158ULL ] * - 0.2 +
0.2 ; Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co = X [
12ULL ] * 0.89999999999999991 + X [ 17ULL ] * - 0.89999999999999991 ; t525 [
0ULL ] = X [ 92ULL ] ; tlu2_linear_nearest_prelookup ( & ob_efOut . mField0 [
0ULL ] , & ob_efOut . mField1 [ 0ULL ] , & ob_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] ,
& t76 [ 0ULL ] ) ; t64 = ob_efOut ; t525 [ 0ULL ] = X [ 93ULL ] ;
tlu2_linear_nearest_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = pb_efOut ; tlu2_2d_linear_nearest_value ( & qb_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , &
t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = qb_efOut [ 0
] ; Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 =
t662_idx_0 ; tlu2_2d_linear_nearest_value ( & rb_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = rb_efOut [ 0 ] ;
t793 = t662_idx_0 ; tlu2_2d_linear_nearest_value ( & sb_efOut [ 0ULL ] , &
t64 . mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = sb_efOut [ 0
] ; t794 = t662_idx_0 ; t525 [ 0ULL ] = X [ 101ULL ] ;
tlu2_linear_nearest_prelookup ( & tb_efOut . mField0 [ 0ULL ] , & tb_efOut .
mField1 [ 0ULL ] , & tb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t64
= tb_efOut ; t525 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_nearest_prelookup ( &
ub_efOut . mField0 [ 0ULL ] , & ub_efOut . mField1 [ 0ULL ] , & ub_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = ub_efOut ;
tlu2_2d_linear_nearest_value ( & vb_efOut [ 0ULL ] , & t64 . mField0 [ 0ULL ]
, & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t75 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = vb_efOut [ 0 ] ; t797 =
t662_idx_0 ; tlu2_2d_linear_nearest_value ( & wb_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = wb_efOut [ 0 ] ;
t798 = t662_idx_0 ; tlu2_2d_linear_nearest_value ( & xb_efOut [ 0ULL ] , &
t64 . mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = xb_efOut [ 0
] ; t799 = t662_idx_0 ; t525 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_nearest_prelookup ( & yb_efOut . mField0 [ 0ULL ] , & yb_efOut .
mField1 [ 0ULL ] , & yb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t70
= yb_efOut ; t525 [ 0ULL ] = X [ 111ULL ] ; tlu2_linear_nearest_prelookup ( &
ac_efOut . mField0 [ 0ULL ] , & ac_efOut . mField1 [ 0ULL ] , & ac_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = ac_efOut ;
tlu2_2d_linear_nearest_value ( & bc_efOut [ 0ULL ] , & t70 . mField0 [ 0ULL ]
, & t70 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t75 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = bc_efOut [ 0 ] ; t802 =
t662_idx_0 ; tlu2_2d_linear_nearest_value ( & cc_efOut [ 0ULL ] , & t70 .
mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = cc_efOut [ 0 ] ;
t803 = t662_idx_0 ; tlu2_2d_linear_nearest_value ( & dc_efOut [ 0ULL ] , &
t70 . mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = dc_efOut [ 0
] ; t804 = t662_idx_0 ; t525 [ 0ULL ] = X [ 119ULL ] ;
tlu2_linear_nearest_prelookup ( & ec_efOut . mField0 [ 0ULL ] , & ec_efOut .
mField1 [ 0ULL ] , & ec_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t525 [ 0ULL ] , & t75 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71
= ec_efOut ; t525 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_nearest_prelookup ( &
fc_efOut . mField0 [ 0ULL ] , & fc_efOut . mField1 [ 0ULL ] , & fc_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = fc_efOut ;
tlu2_2d_linear_nearest_value ( & gc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t75 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = gc_efOut [ 0 ] ; t805 =
t662_idx_0 ; tlu2_2d_linear_nearest_value ( & hc_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , &
t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t75
[ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = hc_efOut [ 0 ] ;
t806 = t662_idx_0 ; tlu2_2d_linear_nearest_value ( & ic_efOut [ 0ULL ] , &
t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , &
t75 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ic_efOut [ 0
] ; t807 = t662_idx_0 ; t808 = X [ 18ULL ] * - 0.1 + X [ 89ULL ] * 0.1 ;
Fuel_Cell_Boost_Converter_L_i = X [ 172ULL ] * 1.0E-9 + X [ 19ULL ] ;
Fuel_Cell_Boost_Converter_L_n_v = ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] *
- 1.0000000000000011 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ;
Fuel_Cell_Boost_Converter_L_p_v = ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] *
- 1.0E-15 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ;
Fuel_Cell_Boost_Converter_i2 = ( ( ( ( X [ 18ULL ] * 0.1 - X [ 88ULL ] ) + X
[ 89ULL ] * - 0.1 ) + X [ 172ULL ] * 1.0E-9 ) - X [ 174ULL ] ) + X [ 19ULL ]
; Fuel_Cell_Current_Sensor1_I = X [ 88ULL ] + X [ 174ULL ] ; if ( X [ 191ULL
] <= 0.0 ) { piece22 = 0.0 ; } else { piece22 = X [ 191ULL ] >= 1.0 ? 1.0 : X
[ 191ULL ] ; } if ( X [ 192ULL ] <= 0.0 ) { piece23 = 0.0 ; } else { piece23
= X [ 192ULL ] >= 1.0 ? 1.0 : X [ 192ULL ] ; } t809 = ( ( ( ( 1.0 - piece22 )
- piece23 ) * 296.802103844292 + piece22 * 461.523 ) + piece23 *
4124.48151675695 ) * 293.15 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = - X [
198ULL ] + U_idx_4 * - 0.01 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 = 0.0 ; } else
{ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 = X [ 24ULL
] >= 1.0 ? 1.0 : X [ 24ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 *
4124.48151675695 ; if ( X [ 199ULL ] <= 216.59999999999997 ) { intrm_sf_mf_19
= 216.59999999999997 ; } else { intrm_sf_mf_19 = X [ 199ULL ] >= 623.15 ?
623.15 : X [ 199ULL ] ; } intrm_sf_mf_1371 = intrm_sf_mf_19 * intrm_sf_mf_19
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh = ( ( (
1074.1165326382554 + intrm_sf_mf_19 * - 0.22145652610641059 ) +
intrm_sf_mf_1371 * 0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ) + ( (
1479.6504774710402 + intrm_sf_mf_19 * 1.2002114337050787 ) + intrm_sf_mf_1371
* - 0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) + ( (
12825.281119789837 + intrm_sf_mf_19 * 6.9647057412840034 ) + intrm_sf_mf_1371
* - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ;
intrm_sf_mf_19 = - pmf_sqrt ( fabs ( X [ 200ULL ] * X [ 200ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 ) )
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ) /
( X [ 199ULL ] == 0.0 ? 1.0E-16 : X [ 199ULL ] ) ) ) * 7.8539816339744827E-5
; t815 = X [ 21ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh = X [ 22ULL ]
/ ( t815 == 0.0 ? 1.0E-16 : t815 ) ; if ( X [ 203ULL ] <= 216.59999999999997
) { intrm_sf_mf_1371 = 216.59999999999997 ; } else { intrm_sf_mf_1371 = X [
203ULL ] >= 623.15 ? 623.15 : X [ 203ULL ] ; } t714 = intrm_sf_mf_1371 *
intrm_sf_mf_1371 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 = ( ( (
1074.1165326382554 + intrm_sf_mf_1371 * - 0.22145652610641059 ) + t714 *
0.0003721298010901061 ) * ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ) + ( (
1479.6504774710402 + intrm_sf_mf_1371 * 1.2002114337050787 ) + t714 * -
0.00038614513167845434 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) + ( (
12825.281119789837 + intrm_sf_mf_1371 * 6.9647057412840034 ) + t714 * -
0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ; t816 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = - pmf_sqrt
( fabs ( X [ 204ULL ] * X [ 204ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 / ( t816 ==
0.0 ? 1.0E-16 : t816 ) ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ) /
( X [ 203ULL ] == 0.0 ? 1.0E-16 : X [ 203ULL ] ) ) ) * 7.8539816339744827E-5
; t576 [ 0ULL ] = X [ 22ULL ] * 100000.0 ; t576 [ 1ULL ] = X [ 21ULL ] ; t576
[ 2ULL ] = X [ 206ULL ] ; t576 [ 3ULL ] = X [ 23ULL ] ; t576 [ 4ULL ] = X [
201ULL ] ; t576 [ 5ULL ] = X [ 205ULL ] ; t576 [ 6ULL ] = X [ 24ULL ] ; t576
[ 7ULL ] = X [ 202ULL ] ; for ( t697 = 0ULL ; t697 < 8ULL ; t697 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ t697 ] =
t576 [ t697 ] ; } intrm_sf_mf_1371 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 / (
intrm_sf_mf_19 == 0.0 ? 1.0E-16 : intrm_sf_mf_19 ) ; intrm_sf_mf_19 = - X [
186ULL ] / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 = - X [
207ULL ] - X [ 208ULL ] ; t525 [ 0ULL ] = X [ 21ULL ] ; t252 [ 0 ] = 52ULL ;
tlu2_linear_linear_prelookup ( & jc_efOut . mField0 [ 0ULL ] , & jc_efOut .
mField1 [ 0ULL ] , & jc_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = jc_efOut ; tlu2_1d_linear_linear_value ( & kc_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = kc_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 =
t662_idx_0 ; if ( 1.0 - X [ 23ULL ] >= 0.01 ) { t812 = 1.0 - X [ 23ULL ] ; }
else if ( 1.0 - X [ 23ULL ] >= - 0.1 ) { t812 = pmf_exp ( ( ( 1.0 - X [ 23ULL
] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t812 = 1.6701700790245661E-7 ; } t714
= X [ 24ULL ] / ( t812 == 0.0 ? 1.0E-16 : t812 ) * 3827.6794129126583 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & lc_efOut [ 0ULL ] , & t71
. mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = lc_efOut
[ 0 ] ; t812 = pmf_exp ( pmf_log ( X [ 22ULL ] * 100000.0 ) - t662_idx_0 ) ;
if ( t812 >= 1.0 ) { t823 = ( t812 - 1.0 ) * 461.523 + t714 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 = t714 / (
t823 == 0.0 ? 1.0E-16 : t823 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 = 1.0 ; }
t825 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 * 0.01
; t714 = ( X [ 23ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) / ( t825 ==
0.0 ? 1.0E-16 : t825 ) ; if ( X [ 23ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 <= 0.0 ) {
t714 = 0.0 ; } else if ( X [ 23ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 * 0.01 ) {
t714 = X [ 23ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ; } else {
t714 = ( X [ 23ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ) * ( t714 *
t714 * 3.0 - t714 * t714 * t714 * 2.0 ) ; } t714 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh * t714 *
7.8539816339744827E-5 / 0.001 ; t714 *= 100000.0 ; t812 = - X [ 210ULL ] - X
[ 211ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5
= - X [ 212ULL ] - X [ 213ULL ] ; tlu2_1d_linear_linear_value ( & mc_efOut [
0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = mc_efOut [ 0 ] ; t814 = t662_idx_0 ;
tlu2_1d_linear_linear_value ( & nc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = nc_efOut [ 0 ] ; t816 = ( (
( 1.0 - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ) * t814 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) +
t662_idx_0 * Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 = U_idx_3 *
0.031415926535897927 ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 * 0.0001 <=
7.8539816339744857E-13 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 =
7.8539816339744857E-13 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 * 0.0001 >=
3.1415926535897929E-6 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 =
3.1415926535897929E-6 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 * 0.0001 ; }
if ( X [ 221ULL ] <= 0.0 ) { t814 = 0.0 ; } else { t814 = X [ 221ULL ] >= 1.0
? 1.0 : X [ 221ULL ] ; } if ( X [ 222ULL ] <= 0.0 ) { t815 = 0.0 ; } else {
t815 = X [ 222ULL ] >= 1.0 ? 1.0 : X [ 222ULL ] ; } t817 = ( ( ( 1.0 - t814 )
- t815 ) * 296.802103844292 + t814 * 461.523 ) + t815 * 4124.48151675695 ; if
( X [ 219ULL ] <= 216.59999999999997 ) { t818 = 216.59999999999997 ; } else {
t818 = X [ 219ULL ] >= 623.15 ? 623.15 : X [ 219ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t818 * t818
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( ( (
1074.1165326382554 + t818 * - 0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t814 ) - t815 ) + ( ( 1479.6504774710402
+ t818 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t814 ) + ( ( 12825.281119789837 + t818 *
6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.0070524868246844051 ) * t815 ; t828 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 - t817 ; t814
= pmf_sqrt ( fabs ( X [ 220ULL ] * X [ 220ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 / ( t828 ==
0.0 ? 1.0E-16 : t828 ) ) / ( t817 == 0.0 ? 1.0E-16 : t817 ) / ( X [ 219ULL ]
== 0.0 ? 1.0E-16 : X [ 219ULL ] ) ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 * 0.64 ; if (
X [ 186ULL ] >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 = X [ 186ULL
] / ( t814 == 0.0 ? 1.0E-16 : t814 ) * 1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 = - X [
186ULL ] / ( t814 == 0.0 ? 1.0E-16 : t814 ) * 1.0E-5 ; } t576 [ 0ULL ] = X [
230ULL ] ; t576 [ 1ULL ] = X [ 25ULL ] ; t576 [ 2ULL ] = X [ 231ULL ] ; t576
[ 3ULL ] = X [ 27ULL ] ; t576 [ 4ULL ] = X [ 232ULL ] ; t576 [ 5ULL ] = X [
233ULL ] ; t576 [ 6ULL ] = X [ 26ULL ] ; t576 [ 7ULL ] = X [ 234ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 0ULL ] = X [
235ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
1ULL ] = X [ 28ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 2ULL ] = X [
236ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
3ULL ] = X [ 30ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 4ULL ] = X [
237ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
5ULL ] = X [ 238ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 6ULL ] = X [
29ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
7ULL ] = X [ 239ULL ] ; if ( X [ 27ULL ] <= 0.0 ) { t814 = 0.0 ; } else {
t814 = X [ 27ULL ] >= 1.0 ? 1.0 : X [ 27ULL ] ; } if ( X [ 26ULL ] <= 0.0 ) {
t815 = 0.0 ; } else { t815 = X [ 26ULL ] >= 1.0 ? 1.0 : X [ 26ULL ] ; } t817
= ( ( ( 1.0 - t814 ) - t815 ) * 296.802103844292 + t814 * 461.523 ) + t815 *
4124.48151675695 ; if ( X [ 245ULL ] <= 216.59999999999997 ) { t818 =
216.59999999999997 ; } else { t818 = X [ 245ULL ] >= 623.15 ? 623.15 : X [
245ULL ] ; } t821 = t818 * t818 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( ( (
1074.1165326382554 + t818 * - 0.22145652610641059 ) + t821 *
0.0003721298010901061 ) * ( ( 1.0 - t814 ) - t815 ) + ( ( 1479.6504774710402
+ t818 * 1.2002114337050787 ) + t821 * - 0.00038614513167845434 ) * t814 ) +
( ( 12825.281119789837 + t818 * 6.9647057412840034 ) + t821 * -
0.0070524868246844051 ) * t815 ; t825 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 - t817 ; t818
= - pmf_sqrt ( fabs ( X [ 246ULL ] * X [ 246ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 / ( t825 ==
0.0 ? 1.0E-16 : t825 ) ) / ( t817 == 0.0 ? 1.0E-16 : t817 ) / ( X [ 245ULL ]
== 0.0 ? 1.0E-16 : X [ 245ULL ] ) ) ) * 0.44 ; t839 = X [ 25ULL ] * t817 ;
t821 = X [ 31ULL ] / ( t839 == 0.0 ? 1.0E-16 : t839 ) ; if ( X [ 248ULL ] <=
216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [ 248ULL
] >= 623.15 ? 623.15 : X [ 248ULL ] ; } t723 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; t823 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.22145652610641059 ) + t723 * 0.0003721298010901061 ) * ( ( 1.0 - t814 ) -
t815 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
1.2002114337050787 ) + t723 * - 0.00038614513167845434 ) * t814 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
6.9647057412840034 ) + t723 * - 0.0070524868246844051 ) * t815 ; t825 = t823
- t817 ; t817 = - pmf_sqrt ( fabs ( X [ 249ULL ] * X [ 249ULL ] * ( t823 / (
t825 == 0.0 ? 1.0E-16 : t825 ) ) / ( t817 == 0.0 ? 1.0E-16 : t817 ) / ( X [
248ULL ] == 0.0 ? 1.0E-16 : X [ 248ULL ] ) ) ) * 0.44 ; t823 = X [ 244ULL ] /
( t818 == 0.0 ? 1.0E-16 : t818 ) ; t818 = X [ 247ULL ] / ( t817 == 0.0 ?
1.0E-16 : t817 ) ; t525 [ 0ULL ] = X [ 25ULL ] ; tlu2_linear_linear_prelookup
( & oc_efOut . mField0 [ 0ULL ] , & oc_efOut . mField1 [ 0ULL ] , & oc_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = oc_efOut ;
tlu2_1d_linear_linear_value ( & pc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = pc_efOut [ 0 ] ; t817 =
t662_idx_0 ; if ( 1.0 - X [ 27ULL ] >= 0.01 ) { t825 = 1.0 - X [ 27ULL ] ; }
else if ( 1.0 - X [ 27ULL ] >= - 0.1 ) { t825 = pmf_exp ( ( ( 1.0 - X [ 27ULL
] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t825 = 1.6701700790245661E-7 ; } t723
= X [ 26ULL ] / ( t825 == 0.0 ? 1.0E-16 : t825 ) * 3827.6794129126583 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & qc_efOut [ 0ULL ] , & t71
. mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = qc_efOut
[ 0 ] ; t825 = pmf_exp ( pmf_log ( X [ 31ULL ] * 100000.0 ) - t662_idx_0 ) ;
if ( t825 >= 1.0 ) { t848 = ( t825 - 1.0 ) * 461.523 + t723 ; t826 = t723 / (
t848 == 0.0 ? 1.0E-16 : t848 ) ; } else { t826 = 1.0 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t826 * 0.01
; t723 = ( X [ 27ULL ] - t826 ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) ;
if ( X [ 27ULL ] - t826 <= 0.0 ) { t723 = 0.0 ; } else if ( X [ 27ULL ] -
t826 >= t826 * 0.01 ) { t723 = X [ 27ULL ] - t826 ; } else { t723 = ( X [
27ULL ] - t826 ) * ( t723 * t723 * 3.0 - t723 * t723 * t723 * 2.0 ) ; } t723
= t821 * t723 * 0.036813041167499325 / 0.001 ; t723 *= 100000.0 ;
tlu2_1d_linear_linear_value ( & rc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = rc_efOut [ 0 ] ; t826 =
t662_idx_0 ; tlu2_1d_linear_linear_value ( & sc_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = sc_efOut [
0 ] ; t828 = ( ( ( 1.0 - t814 ) - t815 ) * t826 + t817 * t814 ) + t662_idx_0
* t815 ; if ( X [ 30ULL ] <= 0.0 ) { t815 = 0.0 ; } else { t815 = X [ 30ULL ]
>= 1.0 ? 1.0 : X [ 30ULL ] ; } if ( X [ 29ULL ] <= 0.0 ) { t817 = 0.0 ; }
else { t817 = X [ 29ULL ] >= 1.0 ? 1.0 : X [ 29ULL ] ; } t826 = ( ( ( 1.0 -
t815 ) - t817 ) * 296.802103844292 + t815 * 461.523 ) + t817 *
4124.48151675695 ; if ( X [ 263ULL ] <= 216.59999999999997 ) { intrm_sf_mf_47
= 216.59999999999997 ; } else { intrm_sf_mf_47 = X [ 263ULL ] >= 623.15 ?
623.15 : X [ 263ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
intrm_sf_mf_47 * intrm_sf_mf_47 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( ( (
1074.1165326382554 + intrm_sf_mf_47 * - 0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t815 ) - t817 ) + ( ( 1479.6504774710402
+ intrm_sf_mf_47 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t815 ) + ( ( 12825.281119789837 + intrm_sf_mf_47 *
6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.0070524868246844051 ) * t817 ; t814 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 - t826 ;
intrm_sf_mf_47 = - pmf_sqrt ( fabs ( X [ 264ULL ] * X [ 264ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 / ( t814 ==
0.0 ? 1.0E-16 : t814 ) ) / ( t826 == 0.0 ? 1.0E-16 : t826 ) / ( X [ 263ULL ]
== 0.0 ? 1.0E-16 : X [ 263ULL ] ) ) ) * 0.44 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = X [ 28ULL ]
* t826 ; t831 = X [ 33ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 ) ;
if ( X [ 265ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [ 265ULL
] >= 623.15 ? 623.15 : X [ 265ULL ] ; } t825 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; t833 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.22145652610641059 ) + t825 * 0.0003721298010901061 ) * ( ( 1.0 - t815 ) -
t817 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
1.2002114337050787 ) + t825 * - 0.00038614513167845434 ) * t815 ) + ( (
12825.281119789837 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
6.9647057412840034 ) + t825 * - 0.0070524868246844051 ) * t817 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t833 - t826
; t826 = - pmf_sqrt ( fabs ( X [ 266ULL ] * X [ 266ULL ] * ( t833 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) )
/ ( t826 == 0.0 ? 1.0E-16 : t826 ) / ( X [ 265ULL ] == 0.0 ? 1.0E-16 : X [
265ULL ] ) ) ) * 0.44 ; t833 = - X [ 247ULL ] / ( intrm_sf_mf_47 == 0.0 ?
1.0E-16 : intrm_sf_mf_47 ) ; intrm_sf_mf_47 = X [ 198ULL ] / ( t826 == 0.0 ?
1.0E-16 : t826 ) ; t525 [ 0ULL ] = X [ 28ULL ] ; tlu2_linear_linear_prelookup
( & tc_efOut . mField0 [ 0ULL ] , & tc_efOut . mField1 [ 0ULL ] , & tc_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = tc_efOut ;
tlu2_1d_linear_linear_value ( & uc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = uc_efOut [ 0 ] ; t825 =
t662_idx_0 ; if ( 1.0 - X [ 30ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 - X [
30ULL ] ; } else if ( 1.0 - X [ 30ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp ( (
( 1.0 - X [ 30ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.6701700790245661E-7 ; } t835 = X [ 29ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
vc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = vc_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp (
pmf_log ( X [ 33ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >= 1.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 - 1.0 ) *
461.523 + t835 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t835 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) ;
} else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.0 ; } t814 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 0.01 ; t835
= ( X [ 30ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) / ( t814 ==
0.0 ? 1.0E-16 : t814 ) ; if ( X [ 30ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 <= 0.0 ) {
t835 = 0.0 ; } else if ( X [ 30ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 0.01 ) {
t835 = X [ 30ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; } else {
t835 = ( X [ 30ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * ( t835 *
t835 * 3.0 - t835 * t835 * t835 * 2.0 ) ; } t835 = t831 * t835 *
0.036813041167499325 / 0.001 ; t835 *= 100000.0 ; tlu2_1d_linear_linear_value
( & wc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [
0ULL ] ) ; t662_idx_0 = wc_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t662_idx_0
; tlu2_1d_linear_linear_value ( & xc_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = xc_efOut [ 0 ] ; t839 = (
( ( 1.0 - t815 ) - t817 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 + t825 * t815
) + t662_idx_0 * t817 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 0ULL ] = X
[ 286ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 1ULL ] = X [ 34ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 2ULL ] = X
[ 283ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 3ULL ] = X [ 36ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 4ULL ] = X
[ 285ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 5ULL ] = X [ 282ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 6ULL ] = X
[ 35ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [
7ULL ] = X [ 284ULL ] ; if ( X [ 36ULL ] <= 0.0 ) { t825 = 0.0 ; } else {
t825 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [
35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t842 = ( ( ( 1.0 - t825 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
296.802103844292 + t825 * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
4124.48151675695 ; if ( X [ 289ULL ] <= 216.59999999999997 ) { piece99 =
216.59999999999997 ; } else { piece99 = X [ 289ULL ] >= 623.15 ? 623.15 : X [
289ULL ] ; } t1244 = piece99 * piece99 ; t844 = ( ( ( 1074.1165326382554 +
piece99 * - 0.22145652610641059 ) + t1244 * 0.0003721298010901061 ) * ( ( 1.0
- t825 ) - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 )
+ ( ( 1479.6504774710402 + piece99 * 1.2002114337050787 ) + t1244 * -
0.00038614513167845434 ) * t825 ) + ( ( 12825.281119789837 + piece99 *
6.9647057412840034 ) + t1244 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; t814 = t844
- t842 ; piece99 = - pmf_sqrt ( fabs ( X [ 290ULL ] * X [ 290ULL ] * ( t844 /
( t814 == 0.0 ? 1.0E-16 : t814 ) ) / ( t842 == 0.0 ? 1.0E-16 : t842 ) / ( X [
289ULL ] == 0.0 ? 1.0E-16 : X [ 289ULL ] ) ) ) * 0.0019634954084936209 ; t814
= X [ 34ULL ] * t842 ; t844 = X [ 37ULL ] / ( t814 == 0.0 ? 1.0E-16 : t814 )
; if ( X [ 291ULL ] <= 216.59999999999997 ) { t1244 = 216.59999999999997 ; }
else { t1244 = X [ 291ULL ] >= 623.15 ? 623.15 : X [ 291ULL ] ; } t1251 =
t1244 * t1244 ; t846 = ( ( ( 1074.1165326382554 + t1244 * -
0.22145652610641059 ) + t1251 * 0.0003721298010901061 ) * ( ( 1.0 - t825 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) + ( (
1479.6504774710402 + t1244 * 1.2002114337050787 ) + t1251 * -
0.00038614513167845434 ) * t825 ) + ( ( 12825.281119789837 + t1244 *
6.9647057412840034 ) + t1251 * - 0.0070524868246844051 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = t846 - t842
; t842 = - pmf_sqrt ( fabs ( X [ 292ULL ] * X [ 292ULL ] * ( t846 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 ) )
/ ( t842 == 0.0 ? 1.0E-16 : t842 ) / ( X [ 291ULL ] == 0.0 ? 1.0E-16 : X [
291ULL ] ) ) ) * 0.0019634954084936209 ; t1244 = X [ 288ULL ] / ( piece99 ==
0.0 ? 1.0E-16 : piece99 ) ; piece99 = - X [ 244ULL ] / ( t842 == 0.0 ?
1.0E-16 : t842 ) ; t525 [ 0ULL ] = X [ 34ULL ] ; tlu2_linear_linear_prelookup
( & yc_efOut . mField0 [ 0ULL ] , & yc_efOut . mField1 [ 0ULL ] , & yc_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = yc_efOut ;
tlu2_1d_linear_linear_value ( & ad_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ad_efOut [ 0 ] ; t842 =
t662_idx_0 ; if ( 1.0 - X [ 36ULL ] >= 0.01 ) { t1251 = 1.0 - X [ 36ULL ] ; }
else if ( 1.0 - X [ 36ULL ] >= - 0.1 ) { t1251 = pmf_exp ( ( ( 1.0 - X [
36ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t1251 = 1.6701700790245661E-7 ;
} t846 = X [ 35ULL ] / ( t1251 == 0.0 ? 1.0E-16 : t1251 ) *
3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
bd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = bd_efOut [ 0 ] ; t1251 = pmf_exp ( pmf_log ( X [ 37ULL ] *
100000.0 ) - t662_idx_0 ) ; if ( t1251 >= 1.0 ) { t890 = ( t1251 - 1.0 ) *
461.523 + t846 ; t848 = t846 / ( t890 == 0.0 ? 1.0E-16 : t890 ) ; } else {
t848 = 1.0 ; } intrm_sf_mf_1372 = t848 * 0.01 ; t846 = ( X [ 36ULL ] - t848 )
/ ( intrm_sf_mf_1372 == 0.0 ? 1.0E-16 : intrm_sf_mf_1372 ) ; if ( X [ 36ULL ]
- t848 <= 0.0 ) { t846 = 0.0 ; } else if ( X [ 36ULL ] - t848 >= t848 * 0.01
) { t846 = X [ 36ULL ] - t848 ; } else { t846 = ( X [ 36ULL ] - t848 ) * (
t846 * t846 * 3.0 - t846 * t846 * t846 * 2.0 ) ; } t846 = t844 * t846 *
0.00049087385212340522 / 0.001 ; t846 *= 100000.0 ;
tlu2_1d_linear_linear_value ( & cd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = cd_efOut [ 0 ] ; t1251 =
t662_idx_0 ; tlu2_1d_linear_linear_value ( & dd_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = dd_efOut [
0 ] ; t849 = ( ( ( 1.0 - t825 ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * t1251 +
t842 * t825 ) + t662_idx_0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; if ( X [
318ULL ] <= 0.0 ) { t842 = 0.0 ; } else { t842 = X [ 318ULL ] >= 1.0 ? 1.0 :
X [ 318ULL ] ; } if ( X [ 319ULL ] <= 0.0 ) { t1251 = 0.0 ; } else { t1251 =
X [ 319ULL ] >= 1.0 ? 1.0 : X [ 319ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 = ( ( ( ( 1.0
- t842 ) - t1251 ) * 296.802103844292 + t842 * 461.523 ) + t1251 *
259.836612622973 ) * 293.15 ; t848 = 1.01325 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ) ;
t851 = ( X [ 322ULL ] * 0.07812500122070315 + U_idx_7 * 10.0 ) -
7.8125001220703152E-10 ; if ( X [ 41ULL ] <= 0.0 ) { t825 = 0.0 ; } else {
t825 = X [ 41ULL ] >= 1.0 ? 1.0 : X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) {
t814 = 0.0 ; } else { t814 = X [ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; } t854
= ( ( ( 1.0 - t825 ) - t814 ) * 296.802103844292 + t825 * 461.523 ) + t814 *
259.836612622973 ; if ( X [ 326ULL ] <= 216.59999999999997 ) { t855 =
216.59999999999997 ; } else { t855 = X [ 326ULL ] >= 623.15 ? 623.15 : X [
326ULL ] ; } t857 = t855 * t855 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = ( ( (
1074.1165326382554 + t855 * - 0.22145652610641059 ) + t857 *
0.0003721298010901061 ) * ( ( 1.0 - t825 ) - t814 ) + ( ( 1479.6504774710402
+ t855 * 1.2002114337050787 ) + t857 * - 0.00038614513167845434 ) * t825 ) +
( ( 900.639412248396 + t855 * - 0.044484923911441127 ) + t857 *
0.00036936011832051582 ) * t814 ; t896 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 - t854 ; t855
= - pmf_sqrt ( fabs ( X [ 327ULL ] * X [ 327ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 / ( t896 ==
0.0 ? 1.0E-16 : t896 ) ) / ( t854 == 0.0 ? 1.0E-16 : t854 ) / ( X [ 326ULL ]
== 0.0 ? 1.0E-16 : X [ 326ULL ] ) ) ) * 0.0019634954084936209 ;
intrm_sf_mf_1359 = X [ 39ULL ] * t854 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 = X [ 40ULL ]
/ ( intrm_sf_mf_1359 == 0.0 ? 1.0E-16 : intrm_sf_mf_1359 ) ; if ( X [ 330ULL
] <= 216.59999999999997 ) { t857 = 216.59999999999997 ; } else { t857 = X [
330ULL ] >= 623.15 ? 623.15 : X [ 330ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t857 * t857
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = ( ( (
1074.1165326382554 + t857 * - 0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t825 ) - t814 ) + ( ( 1479.6504774710402
+ t857 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t825 ) + ( ( 900.639412248396 + t857 * -
0.044484923911441127 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.00036936011832051582 ) * t814 ; t902 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 - t854 ; t854
= - pmf_sqrt ( fabs ( X [ 331ULL ] * X [ 331ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 / ( t902 ==
0.0 ? 1.0E-16 : t902 ) ) / ( t854 == 0.0 ? 1.0E-16 : t854 ) / ( X [ 330ULL ]
== 0.0 ? 1.0E-16 : X [ 330ULL ] ) ) ) * 0.0019634954084936209 ; t593 [ 0ULL ]
= X [ 40ULL ] * 100000.0 ; t593 [ 1ULL ] = X [ 39ULL ] ; t593 [ 2ULL ] = X [
333ULL ] ; t593 [ 3ULL ] = X [ 41ULL ] ; t593 [ 4ULL ] = X [ 328ULL ] ; t593
[ 5ULL ] = X [ 332ULL ] ; t593 [ 6ULL ] = X [ 42ULL ] ; t593 [ 7ULL ] = X [
329ULL ] ; for ( t697 = 0ULL ; t697 < 8ULL ; t697 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ t697 ] =
t593 [ t697 ] ; } t857 = X [ 325ULL ] / ( t855 == 0.0 ? 1.0E-16 : t855 ) ;
t855 = - X [ 313ULL ] / ( t854 == 0.0 ? 1.0E-16 : t854 ) ; t525 [ 0ULL ] = X
[ 39ULL ] ; tlu2_linear_linear_prelookup ( & ed_efOut . mField0 [ 0ULL ] , &
ed_efOut . mField1 [ 0ULL ] , & ed_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t71 = ed_efOut ; tlu2_1d_linear_linear_value ( &
fd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = fd_efOut [ 0 ] ; t854 = t662_idx_0 ; if ( 1.0 - X [ 41ULL ]
>= 0.01 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.0 - X [ 41ULL ] ; } else if ( 1.0 - X [ 41ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp ( (
( 1.0 - X [ 41ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = X [ 42ULL ]
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
- 36.965491221318985 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
gd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = gd_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp (
pmf_log ( X [ 40ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >= 1.0 ) {
t910 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 -
1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 / ( t910 ==
0.0 ? 1.0E-16 : t910 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 = 1.0 ; }
t912 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 * 0.01
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = ( X [
41ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 ) /
( t912 == 0.0 ? 1.0E-16 : t912 ) ; if ( X [ 41ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = 0.0 ; }
else if ( X [ 41ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = X [ 41ULL ]
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 = ( X [ 41ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 *
0.0019634954084936209 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 *= 100000.0 ;
tlu2_1d_linear_linear_value ( & hd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = hd_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t662_idx_0
; tlu2_1d_linear_linear_value ( & id_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = id_efOut [ 0 ] ; t861 = (
( ( 1.0 - t825 ) - t814 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 + t854 * t825
) + t662_idx_0 * t814 ; t854 = U_idx_7 * 10.0 ; if ( X [ 322ULL ] *
0.0019634954084936209 <= 1.9634954084936209E-11 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 =
1.9634954084936209E-11 ; } else if ( X [ 322ULL ] * 0.0019634954084936209 >=
0.0012566370614359179 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 =
0.0012566370614359179 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 = X [ 322ULL
] * 0.0019634954084936209 ; } if ( X [ 345ULL ] <= 0.0 ) { t826 = 0.0 ; }
else { t826 = X [ 345ULL ] >= 1.0 ? 1.0 : X [ 345ULL ] ; } if ( X [ 346ULL ]
<= 0.0 ) { t817 = 0.0 ; } else { t817 = X [ 346ULL ] >= 1.0 ? 1.0 : X [
346ULL ] ; } t815 = ( ( ( 1.0 - t826 ) - t817 ) * 296.802103844292 + t826 *
461.523 ) + t817 * 259.836612622973 ; if ( X [ 343ULL ] <= 216.59999999999997
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 = X [ 343ULL ]
>= 623.15 ? 623.15 : X [ 343ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 ; t825 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t826 ) - t817 ) + ( ( 1479.6504774710402
+ Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 *
1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t826 ) + ( ( 900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * -
0.044484923911441127 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.00036936011832051582 ) * t817 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = t825 - t815
; t826 = pmf_sqrt ( fabs ( X [ 344ULL ] * X [ 344ULL ] * ( t825 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 ) )
/ ( t815 == 0.0 ? 1.0E-16 : t815 ) / ( X [ 343ULL ] == 0.0 ? 1.0E-16 : X [
343ULL ] ) ) ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 * 0.64 ; if (
X [ 313ULL ] >= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 = X [ 313ULL
] / ( t826 == 0.0 ? 1.0E-16 : t826 ) * 1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 = - X [
313ULL ] / ( t826 == 0.0 ? 1.0E-16 : t826 ) * 1.0E-5 ; } t593 [ 0ULL ] = X [
354ULL ] ; t593 [ 1ULL ] = X [ 43ULL ] ; t593 [ 2ULL ] = X [ 355ULL ] ; t593
[ 3ULL ] = X [ 45ULL ] ; t593 [ 4ULL ] = X [ 356ULL ] ; t593 [ 5ULL ] = X [
357ULL ] ; t593 [ 6ULL ] = X [ 44ULL ] ; t593 [ 7ULL ] = X [ 358ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 0ULL ] = X
[ 359ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 1ULL ] = X [ 46ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 2ULL ] = X
[ 360ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 3ULL ] = X [ 48ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 4ULL ] = X
[ 361ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 5ULL ] = X [ 362ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 6ULL ] = X
[ 47ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
7ULL ] = X [ 363ULL ] ; if ( X [ 45ULL ] <= 0.0 ) { t826 = 0.0 ; } else {
t826 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; } if ( X [ 44ULL ] <= 0.0 ) {
t817 = 0.0 ; } else { t817 = X [ 44ULL ] >= 1.0 ? 1.0 : X [ 44ULL ] ; } t815
= ( ( ( 1.0 - t826 ) - t817 ) * 296.802103844292 + t826 * 461.523 ) + t817 *
259.836612622973 ; if ( X [ 369ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 = X [ 369ULL ]
>= 623.15 ? 623.15 : X [ 369ULL ] ; } t868 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 ; t825 = ( ( (
1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * -
0.22145652610641059 ) + t868 * 0.0003721298010901061 ) * ( ( 1.0 - t826 ) -
t817 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 *
1.2002114337050787 ) + t868 * - 0.00038614513167845434 ) * t826 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * -
0.044484923911441127 ) + t868 * 0.00036936011832051582 ) * t817 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t825 - t815
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 = - pmf_sqrt
( fabs ( X [ 370ULL ] * X [ 370ULL ] * ( t825 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) )
/ ( t815 == 0.0 ? 1.0E-16 : t815 ) / ( X [ 369ULL ] == 0.0 ? 1.0E-16 : X [
369ULL ] ) ) ) * 0.44 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 = X [ 43ULL ]
* t815 ; t868 = X [ 49ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ) ;
if ( X [ 372ULL ] <= 216.59999999999997 ) { t814 = 216.59999999999997 ; }
else { t814 = X [ 372ULL ] >= 623.15 ? 623.15 : X [ 372ULL ] ; } t750 = t814
* t814 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 = ( (
( 1074.1165326382554 + t814 * - 0.22145652610641059 ) + t750 *
0.0003721298010901061 ) * ( ( 1.0 - t826 ) - t817 ) + ( ( 1479.6504774710402
+ t814 * 1.2002114337050787 ) + t750 * - 0.00038614513167845434 ) * t826 ) +
( ( 900.639412248396 + t814 * - 0.044484923911441127 ) + t750 *
0.00036936011832051582 ) * t817 ; t814 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 - t815 ; t815 =
- pmf_sqrt ( fabs ( X [ 373ULL ] * X [ 373ULL ] * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 / ( t814 == 0.0
? 1.0E-16 : t814 ) ) / ( t815 == 0.0 ? 1.0E-16 : t815 ) / ( X [ 372ULL ] ==
0.0 ? 1.0E-16 : X [ 372ULL ] ) ) ) * 0.44 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 = X [ 368ULL ]
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 = X [ 371ULL ]
/ ( t815 == 0.0 ? 1.0E-16 : t815 ) ; t525 [ 0ULL ] = X [ 43ULL ] ;
tlu2_linear_linear_prelookup ( & jd_efOut . mField0 [ 0ULL ] , & jd_efOut .
mField1 [ 0ULL ] , & jd_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t70 = jd_efOut ; tlu2_1d_linear_linear_value ( & kd_efOut [ 0ULL ] , & t70 .
mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = kd_efOut [
0 ] ; t815 = t662_idx_0 ; if ( 1.0 - X [ 45ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 - X [
45ULL ] ; } else if ( 1.0 - X [ 45ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp ( (
( 1.0 - X [ 45ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.6701700790245661E-7 ; } t750 = X [ 44ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
- 36.965491221318985 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
ld_efOut [ 0ULL ] , & t70 . mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = ld_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp (
pmf_log ( X [ 49ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >= 1.0 ) {
t936 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 -
1.0 ) * 461.523 + t750 ; t825 = t750 / ( t936 == 0.0 ? 1.0E-16 : t936 ) ; }
else { t825 = 1.0 ; } t938 = t825 * 0.01 ; t750 = ( X [ 45ULL ] - t825 ) / (
t938 == 0.0 ? 1.0E-16 : t938 ) ; if ( X [ 45ULL ] - t825 <= 0.0 ) { t750 =
0.0 ; } else if ( X [ 45ULL ] - t825 >= t825 * 0.01 ) { t750 = X [ 45ULL ] -
t825 ; } else { t750 = ( X [ 45ULL ] - t825 ) * ( t750 * t750 * 3.0 - t750 *
t750 * t750 * 2.0 ) ; } t750 = t868 * t750 * 0.036813041167499325 / 0.001 ;
t750 *= 100000.0 ; tlu2_1d_linear_linear_value ( & md_efOut [ 0ULL ] , & t70
. mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = md_efOut
[ 0 ] ; t825 = t662_idx_0 ; tlu2_1d_linear_linear_value ( & nd_efOut [ 0ULL ]
, & t70 . mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField31 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 =
nd_efOut [ 0 ] ; t875 = ( ( ( 1.0 - t826 ) - t817 ) * t825 + t815 * t826 ) +
t662_idx_0 * t817 ; if ( X [ 48ULL ] <= 0.0 ) { t817 = 0.0 ; } else { t817 =
X [ 48ULL ] >= 1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { t815 =
0.0 ; } else { t815 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ; } t825 = ( ( (
1.0 - t817 ) - t815 ) * 296.802103844292 + t817 * 461.523 ) + t815 *
259.836612622973 ; if ( X [ 387ULL ] <= 216.59999999999997 ) { t874 =
216.59999999999997 ; } else { t874 = X [ 387ULL ] >= 623.15 ? 623.15 : X [
387ULL ] ; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0
= t874 * t874 ; t814 = ( ( ( 1074.1165326382554 + t874 * -
0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t817 ) - t815 ) + ( ( 1479.6504774710402
+ t874 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t817 ) + ( ( 900.639412248396 + t874 * -
0.044484923911441127 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.00036936011832051582 ) * t815 ; t941 = t814 - t825 ; t874 = - pmf_sqrt (
fabs ( X [ 388ULL ] * X [ 388ULL ] * ( t814 / ( t941 == 0.0 ? 1.0E-16 : t941
) ) / ( t825 == 0.0 ? 1.0E-16 : t825 ) / ( X [ 387ULL ] == 0.0 ? 1.0E-16 : X
[ 387ULL ] ) ) ) * 0.44 ; t826 = X [ 46ULL ] * t825 ; t878 = X [ 50ULL ] / (
t826 == 0.0 ? 1.0E-16 : t826 ) ; if ( X [ 389ULL ] <= 216.59999999999997 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
216.59999999999997 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [ 389ULL
] >= 623.15 ? 623.15 : X [ 389ULL ] ; } t814 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; t880 = ( (
( 1074.1165326382554 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.22145652610641059 ) + t814 * 0.0003721298010901061 ) * ( ( 1.0 - t817 ) -
t815 ) + ( ( 1479.6504774710402 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
1.2002114337050787 ) + t814 * - 0.00038614513167845434 ) * t817 ) + ( (
900.639412248396 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.044484923911441127 ) + t814 * 0.00036936011832051582 ) * t815 ; t947 = t880
- t825 ; t825 = - pmf_sqrt ( fabs ( X [ 390ULL ] * X [ 390ULL ] * ( t880 / (
t947 == 0.0 ? 1.0E-16 : t947 ) ) / ( t825 == 0.0 ? 1.0E-16 : t825 ) / ( X [
389ULL ] == 0.0 ? 1.0E-16 : X [ 389ULL ] ) ) ) * 0.44 ; t880 = - X [ 371ULL ]
/ ( t874 == 0.0 ? 1.0E-16 : t874 ) ; t874 = - X [ 325ULL ] / ( t825 == 0.0 ?
1.0E-16 : t825 ) ; t525 [ 0ULL ] = X [ 46ULL ] ; tlu2_linear_linear_prelookup
( & od_efOut . mField0 [ 0ULL ] , & od_efOut . mField1 [ 0ULL ] , & od_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = od_efOut ;
tlu2_1d_linear_linear_value ( & pd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = pd_efOut [ 0 ] ; t814 =
t662_idx_0 ; if ( 1.0 - X [ 48ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 - X [
48ULL ] ; } else if ( 1.0 - X [ 48ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp ( (
( 1.0 - X [ 48ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = X [ 47ULL ]
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
- 36.965491221318985 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
qd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = qd_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp (
pmf_log ( X [ 50ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >= 1.0 ) {
t955 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 -
1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 / ( t955 ==
0.0 ? 1.0E-16 : t955 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 ; }
t957 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 0.01
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = ( X [
48ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) /
( t957 == 0.0 ? 1.0E-16 : t957 ) ; if ( X [ 48ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = 0.0 ; } else
if ( X [ 48ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = X [ 48ULL ]
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = ( X [ 48ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 = t878 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 *
0.036813041167499325 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 *= 100000.0 ;
tlu2_1d_linear_linear_value ( & rd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = rd_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t662_idx_0
; tlu2_1d_linear_linear_value ( & sd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = sd_efOut [ 0 ] ; t886 = (
( ( 1.0 - t817 ) - t815 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 + t814 * t817
) + t662_idx_0 * t815 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 0ULL ] = X
[ 411ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 1ULL ] = X [ 51ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 2ULL ] = X
[ 408ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 3ULL ] = X [ 53ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 4ULL ] = X
[ 410ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 5ULL ] = X [ 407ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 6ULL ] = X
[ 52ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [
7ULL ] = X [ 409ULL ] ; if ( X [ 53ULL ] <= 0.0 ) { t825 = 0.0 ; } else {
t825 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; } if ( X [ 52ULL ] <= 0.0 ) {
t888 = 0.0 ; } else { t888 = X [ 52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 = ( ( ( 1.0 -
t825 ) - t888 ) * 296.802103844292 + t825 * 461.523 ) + t888 *
259.836612622973 ; if ( X [ 414ULL ] <= 216.59999999999997 ) { t890 =
216.59999999999997 ; } else { t890 = X [ 414ULL ] >= 623.15 ? 623.15 : X [
414ULL ] ; } intrm_sf_mf_1372 = t890 * t890 ; t891 = ( ( ( 1074.1165326382554
+ t890 * - 0.22145652610641059 ) + intrm_sf_mf_1372 * 0.0003721298010901061 )
* ( ( 1.0 - t825 ) - t888 ) + ( ( 1479.6504774710402 + t890 *
1.2002114337050787 ) + intrm_sf_mf_1372 * - 0.00038614513167845434 ) * t825 )
+ ( ( 900.639412248396 + t890 * - 0.044484923911441127 ) + intrm_sf_mf_1372 *
0.00036936011832051582 ) * t888 ; t964 = t891 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ; t890 = -
pmf_sqrt ( fabs ( X [ 415ULL ] * X [ 415ULL ] * ( t891 / ( t964 == 0.0 ?
1.0E-16 : t964 ) ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ) /
( X [ 414ULL ] == 0.0 ? 1.0E-16 : X [ 414ULL ] ) ) ) * 0.0019634954084936209
; t814 = X [ 51ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ; t891 = X [
54ULL ] / ( t814 == 0.0 ? 1.0E-16 : t814 ) ; if ( X [ 416ULL ] <=
216.59999999999997 ) { intrm_sf_mf_1372 = 216.59999999999997 ; } else {
intrm_sf_mf_1372 = X [ 416ULL ] >= 623.15 ? 623.15 : X [ 416ULL ] ; } t762 =
intrm_sf_mf_1372 * intrm_sf_mf_1372 ; t893 = ( ( ( 1074.1165326382554 +
intrm_sf_mf_1372 * - 0.22145652610641059 ) + t762 * 0.0003721298010901061 ) *
( ( 1.0 - t825 ) - t888 ) + ( ( 1479.6504774710402 + intrm_sf_mf_1372 *
1.2002114337050787 ) + t762 * - 0.00038614513167845434 ) * t825 ) + ( (
900.639412248396 + intrm_sf_mf_1372 * - 0.044484923911441127 ) + t762 *
0.00036936011832051582 ) * t888 ; t970 = t893 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 = - pmf_sqrt
( fabs ( X [ 417ULL ] * X [ 417ULL ] * ( t893 / ( t970 == 0.0 ? 1.0E-16 :
t970 ) ) / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ) / ( X [
416ULL ] == 0.0 ? 1.0E-16 : X [ 416ULL ] ) ) ) * 0.0019634954084936209 ;
intrm_sf_mf_1372 = X [ 413ULL ] / ( t890 == 0.0 ? 1.0E-16 : t890 ) ; t890 = -
X [ 368ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ) ;
t525 [ 0ULL ] = X [ 51ULL ] ; tlu2_linear_linear_prelookup ( & td_efOut .
mField0 [ 0ULL ] , & td_efOut . mField1 [ 0ULL ] , & td_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = td_efOut ;
tlu2_1d_linear_linear_value ( & ud_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ud_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 = t662_idx_0
; if ( 1.0 - X [ 53ULL ] >= 0.01 ) { t762 = 1.0 - X [ 53ULL ] ; } else if (
1.0 - X [ 53ULL ] >= - 0.1 ) { t762 = pmf_exp ( ( ( 1.0 - X [ 53ULL ] ) -
0.01 ) / 0.01 ) * 0.01 ; } else { t762 = 1.6701700790245661E-7 ; } t893 = X [
52ULL ] / ( t762 == 0.0 ? 1.0E-16 : t762 ) * - 36.965491221318985 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & vd_efOut [ 0ULL ] , & t71
. mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = vd_efOut
[ 0 ] ; t762 = pmf_exp ( pmf_log ( X [ 54ULL ] * 100000.0 ) - t662_idx_0 ) ;
if ( t762 >= 1.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( t762 -
1.0 ) * 461.523 + t893 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 = t893 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) ;
} else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 =
1.0 ; } t980 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 * 0.01 ; t893
= ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ) / ( t980 ==
0.0 ? 1.0E-16 : t980 ) ; if ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 <= 0.0 ) {
t893 = 0.0 ; } else if ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 * 0.01 ) {
t893 = X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ; } else {
t893 = ( X [ 53ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ) * ( t893 *
t893 * 3.0 - t893 * t893 * t893 * 2.0 ) ; } t893 = t891 * t893 *
0.00049087385212340522 / 0.001 ; t893 *= 100000.0 ;
tlu2_1d_linear_linear_value ( & wd_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = wd_efOut [ 0 ] ; t762 =
t662_idx_0 ; tlu2_1d_linear_linear_value ( & xd_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField31 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = xd_efOut [
0 ] ; t896 = ( ( ( 1.0 - t825 ) - t888 ) * t762 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 * t825 ) +
t662_idx_0 * t888 ; t888 = - X [ 427ULL ] - X [ 428ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 = - X [
430ULL ] - X [ 431ULL ] ; t762 = - X [ 434ULL ] + U_idx_10 * - 2.0 ; t525 [
0ULL ] = X [ 56ULL ] ; t340 [ 0 ] = 11ULL ; tlu2_linear_linear_prelookup ( &
yd_efOut . mField0 [ 0ULL ] , & yd_efOut . mField1 [ 0ULL ] , & yd_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t525 [
0ULL ] , & t340 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = yd_efOut ; t525 [ 0ULL ]
= 1.01325 ; t343 [ 0 ] = 12ULL ; tlu2_linear_linear_prelookup ( & ae_efOut .
mField0 [ 0ULL ] , & ae_efOut . mField1 [ 0ULL ] , & ae_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t525 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = ae_efOut ;
tlu2_2d_linear_linear_value ( & be_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = be_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 = t662_idx_0
; tlu2_2d_linear_linear_value ( & ce_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ce_efOut [ 0 ] ; t898 =
t662_idx_0 ; t899 = 1.01325 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ) *
100.0 + t662_idx_0 ; t525 [ 0ULL ] = X [ 59ULL ] ;
tlu2_linear_nearest_prelookup ( & de_efOut . mField0 [ 0ULL ] , & de_efOut .
mField1 [ 0ULL ] , & de_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t64 = de_efOut ; t525 [ 0ULL ] = X [ 58ULL ] ; tlu2_linear_nearest_prelookup
( & ee_efOut . mField0 [ 0ULL ] , & ee_efOut . mField1 [ 0ULL ] , & ee_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t525 [
0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = ee_efOut ;
tlu2_2d_linear_nearest_value ( & fe_efOut [ 0ULL ] , & t64 . mField0 [ 0ULL ]
, & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = fe_efOut [ 0 ] ;
intrm_sf_mf_1359 = t662_idx_0 ; t525 [ 0ULL ] = X [ 59ULL ] ;
tlu2_linear_linear_prelookup ( & ge_efOut . mField0 [ 0ULL ] , & ge_efOut .
mField1 [ 0ULL ] , & ge_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = ge_efOut ; t525 [ 0ULL ] = X [ 58ULL ] ; tlu2_linear_linear_prelookup (
& he_efOut . mField0 [ 0ULL ] , & he_efOut . mField1 [ 0ULL ] , & he_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t525 [
0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t70 = he_efOut ;
tlu2_2d_linear_linear_value ( & ie_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , & t70 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ie_efOut [ 0 ] ; t902 =
t662_idx_0 ; tlu2_2d_linear_linear_value ( & je_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , &
t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , &
t340 [ 0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = je_efOut [
0 ] ; t903 = t662_idx_0 ; t904 = X [ 58ULL ] / ( t902 == 0.0 ? 1.0E-16 : t902
) * 100.0 + t662_idx_0 ; t906 = U_idx_10 * 2.0 ; t907 = U_idx_10 * 2.0 ; t525
[ 0ULL ] = X [ 453ULL ] ; tlu2_linear_linear_prelookup ( & ke_efOut . mField0
[ 0ULL ] , & ke_efOut . mField1 [ 0ULL ] , & ke_efOut . mField2 [ 0ULL ] , (
( _NeDynamicSystem * ) ( LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL
] , & t76 [ 0ULL ] ) ; t71 = ke_efOut ; tlu2_2d_linear_linear_value ( &
le_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , &
t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * )
( LC ) ) -> mField36 , & t340 [ 0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t662_idx_0 = le_efOut [ 0 ] ; intrm_sf_mf_1431 = t662_idx_0 ; t525 [ 0ULL ] =
X [ 455ULL ] ; tlu2_linear_linear_prelookup ( & me_efOut . mField0 [ 0ULL ] ,
& me_efOut . mField1 [ 0ULL ] , & me_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t64 = me_efOut ; t525 [ 0ULL ] = X [ 451ULL ] ;
tlu2_linear_linear_prelookup ( & ne_efOut . mField0 [ 0ULL ] , & ne_efOut .
mField1 [ 0ULL ] , & ne_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField34 , & t525 [ 0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = ne_efOut ; tlu2_2d_linear_linear_value ( & oe_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , & t71 . mField0 [ 0ULL ] , &
t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , &
t340 [ 0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = oe_efOut [
0 ] ; intrm_sf_mf_1431 = ( intrm_sf_mf_1431 + t662_idx_0 ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_powe = ( X [
451ULL ] - 1.01325 ) * t906 / ( intrm_sf_mf_1431 == 0.0 ? 1.0E-16 :
intrm_sf_mf_1431 ) ; t525 [ 0ULL ] = X [ 61ULL ] ;
tlu2_linear_nearest_prelookup ( & pe_efOut . mField0 [ 0ULL ] , & pe_efOut .
mField1 [ 0ULL ] , & pe_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = pe_efOut ; t525 [ 0ULL ] = X [ 60ULL ] ; tlu2_linear_nearest_prelookup
( & qe_efOut . mField0 [ 0ULL ] , & qe_efOut . mField1 [ 0ULL ] , & qe_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t525 [
0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t64 = qe_efOut ;
tlu2_2d_linear_nearest_value ( & re_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , & t64 . mField0 [ 0ULL ] , & t64 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField41 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = re_efOut [ 0 ] ;
intrm_sf_mf_1431 = t662_idx_0 ; t525 [ 0ULL ] = X [ 61ULL ] ;
tlu2_linear_linear_prelookup ( & se_efOut . mField0 [ 0ULL ] , & se_efOut .
mField1 [ 0ULL ] , & se_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField33 , & t525 [ 0ULL ] , & t340 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t55 = se_efOut ; t525 [ 0ULL ] = X [ 60ULL ] ; tlu2_linear_linear_prelookup (
& te_efOut . mField0 [ 0ULL ] , & te_efOut . mField1 [ 0ULL ] , & te_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField34 , & t525 [
0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t70 = te_efOut ;
tlu2_2d_linear_linear_value ( & ue_efOut [ 0ULL ] , & t55 . mField0 [ 0ULL ]
, & t55 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , & t70 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField36 , & t340 [ 0ULL ] , &
t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ue_efOut [ 0 ] ; t910 =
t662_idx_0 ; tlu2_2d_linear_linear_value ( & ve_efOut [ 0ULL ] , & t55 .
mField0 [ 0ULL ] , & t55 . mField2 [ 0ULL ] , & t70 . mField0 [ 0ULL ] , &
t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField37 , &
t340 [ 0ULL ] , & t343 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ve_efOut [
0 ] ; t911 = t662_idx_0 ; t912 = X [ 60ULL ] / ( t910 == 0.0 ? 1.0E-16 : t910
) * 100.0 + t662_idx_0 ; t913 = ( 1.01325 - X [ 451ULL ] ) * X [ 460ULL ] *
0.0001 ; if ( X [ 461ULL ] < 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = X [ 461ULL
] * 17.81 + 0.043 ; } else if ( X [ 461ULL ] <= 1.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = ( ( X [
461ULL ] * 17.81 + 0.043 ) - X [ 461ULL ] * X [ 461ULL ] * 39.85 ) + X [
461ULL ] * X [ 461ULL ] * X [ 461ULL ] * 36.0 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = ( X [
461ULL ] - 1.0 ) * 1.4 + 14.003 ; } if ( X [ 462ULL ] < 0.0 ) { t918 = X [
462ULL ] * 17.81 + 0.043 ; } else if ( X [ 462ULL ] <= 1.0 ) { t918 = ( ( X [
462ULL ] * 17.81 + 0.043 ) - X [ 462ULL ] * X [ 462ULL ] * 39.85 ) + X [
462ULL ] * X [ 462ULL ] * X [ 462ULL ] * 36.0 ; } else { t918 = ( X [ 462ULL
] - 1.0 ) * 1.4 + 14.003 ; } t920 = pmf_exp ( ( 0.003298697014679202 - 1.0 /
( X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) ) * 2416.0 ) * 1.25E-10 ; if (
X [ 173ULL ] <= 0.0 ) { t921 = - X [ 173ULL ] / 0.028 ; } else { t921 = 0.0 ;
} if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 >= 0.0
) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.0029 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.05 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.05 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t921 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 / 96485.33212
; t525 [ 0ULL ] = X [ 32ULL ] ; tlu2_linear_nearest_prelookup ( & we_efOut .
mField0 [ 0ULL ] , & we_efOut . mField1 [ 0ULL ] , & we_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t64 = we_efOut ;
tlu2_1d_linear_nearest_value ( & xe_efOut [ 0ULL ] , & t64 . mField0 [ 0ULL ]
, & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField16 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = xe_efOut [ 0 ] ; t825 = ( X
[ 230ULL ] + X [ 235ULL ] ) / 2.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 = ( X [
354ULL ] + X [ 359ULL ] ) / 2.0 ; t525 [ 0ULL ] = X [ 32ULL ] ;
tlu2_linear_linear_prelookup ( & ye_efOut . mField0 [ 0ULL ] , & ye_efOut .
mField1 [ 0ULL ] , & ye_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t70 = ye_efOut ; tlu2_1d_linear_linear_value ( & af_efOut [ 0ULL ] , & t70 .
mField0 [ 0ULL ] , & t70 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t546 [ 0 ] = af_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 =
pmf_exp ( pmf_log ( t825 ) - t546 [ 0ULL ] ) ; t926 = X [ 461ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 = pmf_exp (
pmf_log ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ) -
t546 [ 0ULL ] ) ; if ( t825 >
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ) { t814 =
t662_idx_0 * X [ 32ULL ] * 0.001039307827269155 ; t814 = ( t825 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ) * t825 *
t926 * 1.58E-18 / ( t814 == 0.0 ? 1.0E-16 : t814 ) ; } else { t1227 =
t662_idx_0 * X [ 32ULL ] * 0.001039307827269155 ; t814 = ( t825 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 * ( X [
462ULL ] / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 ) ) *
1.58E-18 / ( t1227 == 0.0 ? 1.0E-16 : t1227 ) ; } t920 = ( ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 *
1818.181818181818 - t918 * 1818.181818181818 ) * t920 / 0.000125 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) + t814 ) *
0.2774351967714716 ; t917 = t921 * 0.031044562522428019 / 192970.66424 ; t926
= ( ( ( ( - X [ 252ULL ] - X [ 269ULL ] ) - X [ 376ULL ] ) - X [ 394ULL ] ) -
X [ 445ULL ] ) - X [ 463ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 + t918 ) /
2.0 ; if ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 >=
1.0 ) { t918 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.005139 -
0.00326 ; } else { t918 = 0.0018790000000000005 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = pmf_exp ( (
0.003298697014679202 - 1.0 / ( X [ 32ULL ] == 0.0 ? 1.0E-16 : X [ 32ULL ] ) )
* 1268.0 ) * t918 ; t918 = 0.000125 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 * ( ( X [
356ULL ] + X [ 361ULL ] ) / 2.0 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 >= 1.0E-9 ?
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 : 1.0E-6 ;
t825 = t825 * ( ( X [ 234ULL ] + X [ 239ULL ] ) / 2.0 ) / 1.01325 ; if ( t825
* 1.0E-5 >= 1.0E-9 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 = t825 *
1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 = 1.0E-6 ; }
t825 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 * ( (
X [ 358ULL ] + X [ 363ULL ] ) / 2.0 ) / 1.01325 ; if ( t825 * 1.0E-5 >=
1.0E-9 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 =
t825 * 1.0E-5 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 = 1.0E-6 ; }
t1231 = X [ 32ULL ] * 8.31446261815324 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 = ( ( ( X [
19ULL ] * - 1.0E-6 + X [ 172ULL ] * - 1.0E-15 ) + X [ 173ULL ] * - 0.001001 )
+ X [ 20ULL ] ) + X [ 464ULL ] ; if ( t921 >= 1.0 ) { t929 = pmf_log ( t921 )
* ( t1231 / 135079.46496800001 ) ; } else { t929 = 0.0 ; } if ( t921 <=
13986.0 ) { t825 = pmf_log ( 1.0 - t921 / 14000.0 ) ; } else { t825 = -
6.9077552789821359 - ( t921 / 14000.0 - 0.999 ) / 0.0010000000000000009 ; }
t1211 = pmf_sqrt (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 = t1231 /
192970.66424 * pmf_log ( t1211 / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 ) )
+ 1.228891453185164 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 = ( (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 - t929 ) -
t918 * t921 * 0.01 ) - X [ 32ULL ] * - 8.31446261815324 / 192970.66424 * t825
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 = t921 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 * 15.4 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 = - X [
465ULL ] + X [ 402ULL ] ; t621 [ 0ULL ] = X [ 64ULL ] * 100000.0 ; t621 [
1ULL ] = X [ 63ULL ] ; t621 [ 2ULL ] = X [ 473ULL ] ; t621 [ 3ULL ] = X [
66ULL ] ; t621 [ 4ULL ] = X [ 475ULL ] ; t621 [ 5ULL ] = X [ 472ULL ] ; t621
[ 6ULL ] = X [ 65ULL ] ; t621 [ 7ULL ] = X [ 474ULL ] ; for ( t697 = 0ULL ;
t697 < 8ULL ; t697 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ t697 ] =
t621 [ t697 ] ; } t525 [ 0ULL ] = X [ 63ULL ] ; tlu2_linear_linear_prelookup
( & bf_efOut . mField0 [ 0ULL ] , & bf_efOut . mField1 [ 0ULL ] , & bf_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [
0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = bf_efOut ;
tlu2_1d_linear_linear_value ( & cf_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = cf_efOut [ 0 ] ; t814 =
t662_idx_0 ; if ( X [ 66ULL ] <= 0.0 ) { t929 = 0.0 ; } else { t929 = X [
66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ] ; } if ( X [ 65ULL ] <= 0.0 ) { t825 = 0.0
; } else { t825 = X [ 65ULL ] >= 1.0 ? 1.0 : X [ 65ULL ] ; } t1211 = X [
63ULL ] * ( ( ( ( 1.0 - t929 ) - t825 ) * 296.802103844292 + t929 * 461.523 )
+ t825 * 4124.48151675695 ) ; t931 = X [ 64ULL ] / ( t1211 == 0.0 ? 1.0E-16 :
t1211 ) ; if ( 1.0 - X [ 66ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = 1.0 - X [
66ULL ] ; } else if ( 1.0 - X [ 66ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = pmf_exp ( (
( 1.0 - X [ 66ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 =
1.6701700790245661E-7 ; } t826 = X [ 65ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 ) *
3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
df_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = df_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = pmf_exp (
pmf_log ( X [ 64ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 >= 1.0 ) {
t1231 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 -
1.0 ) * 461.523 + t826 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = t826 / (
t1231 == 0.0 ? 1.0E-16 : t1231 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = 1.0 ; }
t1211 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 *
0.01 ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = ( X [
66ULL ] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ) /
( t1211 == 0.0 ? 1.0E-16 : t1211 ) ; if ( X [ 66ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = 0.0 ; } else
if ( X [ 66ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = X [ 66ULL ]
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = ( X [ 66ULL
] - Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 = t931 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 * 0.18 / 0.001
; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 *= 100000.0
; tlu2_1d_linear_linear_value ( & ef_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL
] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ef_efOut [ 0 ] ; t826 =
t662_idx_0 ; tlu2_1d_linear_linear_value ( & ff_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ff_efOut [
0 ] ; t935 = ( ( ( 1.0 - t929 ) - t825 ) * t826 + t814 * t929 ) + t662_idx_0
* t825 ; t929 = ( X [ 485ULL ] * - 0.62500003906250234 + U_idx_11 * 10.0 ) +
6.2500003783494407E-9 ; if ( X [ 69ULL ] <= 0.0 ) { t825 = 0.0 ; } else {
t825 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <= 0.0 ) {
t826 = 0.0 ; } else { t826 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = ( ( ( 1.0 -
t825 ) - t826 ) * 296.802103844292 + t825 * 461.523 ) + t826 *
4124.48151675695 ; if ( X [ 488ULL ] <= 216.59999999999997 ) { t936 =
216.59999999999997 ; } else { t936 = X [ 488ULL ] >= 623.15 ? 623.15 : X [
488ULL ] ; } t938 = t936 * t936 ; t937 = ( ( ( 1074.1165326382554 + t936 * -
0.22145652610641059 ) + t938 * 0.0003721298010901061 ) * ( ( 1.0 - t825 ) -
t826 ) + ( ( 1479.6504774710402 + t936 * 1.2002114337050787 ) + t938 * -
0.00038614513167845434 ) * t825 ) + ( ( 12825.281119789837 + t936 *
6.9647057412840034 ) + t938 * - 0.0070524868246844051 ) * t826 ; t1231 = t937
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ; t936 = -
pmf_sqrt ( fabs ( X [ 489ULL ] * X [ 489ULL ] * ( t937 / ( t1231 == 0.0 ?
1.0E-16 : t1231 ) ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ) /
( X [ 488ULL ] == 0.0 ? 1.0E-16 : X [ 488ULL ] ) ) ) * 7.8539816339744827E-5
; t1211 = X [ 67ULL ] *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ; t937 = X [
68ULL ] / ( t1211 == 0.0 ? 1.0E-16 : t1211 ) ; if ( X [ 493ULL ] <=
216.59999999999997 ) { t938 = 216.59999999999997 ; } else { t938 = X [ 493ULL
] >= 623.15 ? 623.15 : X [ 493ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t938 * t938
; t939 = ( ( ( 1074.1165326382554 + t938 * - 0.22145652610641059 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.0003721298010901061 ) * ( ( 1.0 - t825 ) - t826 ) + ( ( 1479.6504774710402
+ t938 * 1.2002114337050787 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.00038614513167845434 ) * t825 ) + ( ( 12825.281119789837 + t938 *
6.9647057412840034 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * -
0.0070524868246844051 ) * t826 ; t1231 = t939 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = - pmf_sqrt
( fabs ( X [ 494ULL ] * X [ 494ULL ] * ( t939 / ( t1231 == 0.0 ? 1.0E-16 :
t1231 ) ) / ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31
== 0.0 ? 1.0E-16 :
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ) / ( X [
493ULL ] == 0.0 ? 1.0E-16 : X [ 493ULL ] ) ) ) * 7.8539816339744827E-5 ; t626
[ 0ULL ] = X [ 68ULL ] * 100000.0 ; t626 [ 1ULL ] = X [ 67ULL ] ; t626 [ 2ULL
] = X [ 496ULL ] ; t626 [ 3ULL ] = X [ 69ULL ] ; t626 [ 4ULL ] = X [ 490ULL ]
; t626 [ 5ULL ] = X [ 495ULL ] ; t626 [ 6ULL ] = X [ 70ULL ] ; t626 [ 7ULL ]
= X [ 491ULL ] ; for ( t697 = 0ULL ; t697 < 8ULL ; t697 ++ ) { t621 [ t697 ]
= t626 [ t697 ] ; } t938 = - X [ 478ULL ] / ( t936 == 0.0 ? 1.0E-16 : t936 )
; t936 = X [ 492ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 ) ;
t525 [ 0ULL ] = X [ 67ULL ] ; tlu2_linear_linear_prelookup ( & gf_efOut .
mField0 [ 0ULL ] , & gf_efOut . mField1 [ 0ULL ] , & gf_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t64 = gf_efOut ;
tlu2_1d_linear_linear_value ( & hf_efOut [ 0ULL ] , & t64 . mField0 [ 0ULL ]
, & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = hf_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = t662_idx_0
; if ( 1.0 - X [ 69ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 - X [
69ULL ] ; } else if ( 1.0 - X [ 69ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp ( (
( 1.0 - X [ 69ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
1.6701700790245661E-7 ; } t939 = X [ 70ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) *
3827.6794129126583 + 296.802103844292 ; tlu2_1d_linear_linear_value ( &
if_efOut [ 0ULL ] , & t64 . mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = if_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = pmf_exp (
pmf_log ( X [ 68ULL ] * 100000.0 ) - t662_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >= 1.0 ) {
t1231 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 -
1.0 ) * 461.523 + t939 ; t941 = t939 / ( t1231 == 0.0 ? 1.0E-16 : t1231 ) ; }
else { t941 = 1.0 ; } t1211 = t941 * 0.01 ; t939 = ( X [ 69ULL ] - t941 ) / (
t1211 == 0.0 ? 1.0E-16 : t1211 ) ; if ( X [ 69ULL ] - t941 <= 0.0 ) { t939 =
0.0 ; } else if ( X [ 69ULL ] - t941 >= t941 * 0.01 ) { t939 = X [ 69ULL ] -
t941 ; } else { t939 = ( X [ 69ULL ] - t941 ) * ( t939 * t939 * 3.0 - t939 *
t939 * t939 * 2.0 ) ; } t939 = t937 * t939 * 7.8539816339744827E-5 / 0.001 ;
t939 *= 100000.0 ; tlu2_1d_linear_linear_value ( & jf_efOut [ 0ULL ] , & t64
. mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = jf_efOut
[ 0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
t662_idx_0 ; tlu2_1d_linear_linear_value ( & kf_efOut [ 0ULL ] , & t64 .
mField0 [ 0ULL ] , & t64 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = kf_efOut [
0 ] ; t942 = ( ( ( 1.0 - t825 ) - t826 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 * t825 ) +
t662_idx_0 * t826 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 = U_idx_11 *
10.0 ; if ( X [ 485ULL ] * 7.8539816339744827E-5 <= 7.8539816339744857E-13 )
{ t941 = 7.8539816339744857E-13 ; } else if ( X [ 485ULL ] *
7.8539816339744827E-5 >= 1.2566370614359172E-5 ) { t941 =
1.2566370614359172E-5 ; } else { t941 = X [ 485ULL ] * 7.8539816339744827E-5
; } if ( X [ 508ULL ] <= 0.0 ) { intrm_sf_mf_24 = 0.0 ; } else {
intrm_sf_mf_24 = X [ 508ULL ] >= 1.0 ? 1.0 : X [ 508ULL ] ; } if ( X [ 509ULL
] <= 0.0 ) { t944 = 0.0 ; } else { t944 = X [ 509ULL ] >= 1.0 ? 1.0 : X [
509ULL ] ; } Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0
= ( ( ( 1.0 - intrm_sf_mf_24 ) - t944 ) * 296.802103844292 + intrm_sf_mf_24 *
461.523 ) + t944 * 4124.48151675695 ; if ( X [ 506ULL ] <= 216.59999999999997
) { t826 = 216.59999999999997 ; } else { t826 = X [ 506ULL ] >= 623.15 ?
623.15 : X [ 506ULL ] ; } t948 = t826 * t826 ; t947 = ( ( (
1074.1165326382554 + t826 * - 0.22145652610641059 ) + t948 *
0.0003721298010901061 ) * ( ( 1.0 - intrm_sf_mf_24 ) - t944 ) + ( (
1479.6504774710402 + t826 * 1.2002114337050787 ) + t948 * -
0.00038614513167845434 ) * intrm_sf_mf_24 ) + ( ( 12825.281119789837 + t826 *
6.9647057412840034 ) + t948 * - 0.0070524868246844051 ) * t944 ; t1231 = t947
- Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ;
intrm_sf_mf_691 = pmf_sqrt ( fabs ( X [ 507ULL ] * X [ 507ULL ] * ( t947 / (
t1231 == 0.0 ? 1.0E-16 : t1231 ) ) / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) /
( X [ 506ULL ] == 0.0 ? 1.0E-16 : X [ 506ULL ] ) ) ) * t941 * 0.64 ; if ( - X
[ 478ULL ] >= 0.0 ) { t941 = - X [ 478ULL ] / ( intrm_sf_mf_691 == 0.0 ?
1.0E-16 : intrm_sf_mf_691 ) * 1.0E-5 ; } else { t941 = X [ 478ULL ] / (
intrm_sf_mf_691 == 0.0 ? 1.0E-16 : intrm_sf_mf_691 ) * 1.0E-5 ; } if ( X [
524ULL ] <= 0.0 ) { intrm_sf_mf_691 = 0.0 ; } else { intrm_sf_mf_691 = X [
524ULL ] >= 1.0 ? 1.0 : X [ 524ULL ] ; } if ( X [ 525ULL ] <= 0.0 ) {
intrm_sf_mf_24 = 0.0 ; } else { intrm_sf_mf_24 = X [ 525ULL ] >= 1.0 ? 1.0 :
X [ 525ULL ] ; } t1231 = ( ( ( ( 1.0 - intrm_sf_mf_691 ) - intrm_sf_mf_24 ) *
296.802103844292 + intrm_sf_mf_691 * 461.523 ) + intrm_sf_mf_24 *
259.836612622973 ) * 293.15 ; t944 = 1.01325 / ( t1231 == 0.0 ? 1.0E-16 :
t1231 ) ; if ( X [ 537ULL ] <= 0.0 ) { t826 = 0.0 ; } else { t826 = X [
537ULL ] >= 1.0 ? 1.0 : X [ 537ULL ] ; } if ( X [ 536ULL ] <= 0.0 ) { t947 =
0.0 ; } else { t947 = X [ 536ULL ] >= 1.0 ? 1.0 : X [ 536ULL ] ; } t948 = ( (
( 1.0 - t826 ) - t947 ) * 296.802103844292 + t826 * 461.523 ) + t947 *
259.836612622973 ; t525 [ 0ULL ] = X [ 531ULL ] ;
tlu2_linear_linear_prelookup ( & lf_efOut . mField0 [ 0ULL ] , & lf_efOut .
mField1 [ 0ULL ] , & lf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = lf_efOut ; tlu2_1d_linear_linear_value ( & mf_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = mf_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & nf_efOut [ 0ULL ] , & t71 . mField0 [
0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t817 = nf_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & of_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 = of_efOut [ 0 ] ; t1231 = X [
531ULL ] * t948 ; t814 = t1231 / 1.01325 * ( - X [ 519ULL ] /
0.0019634954084936209 ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) * fabs (
t1231 / 1.01325 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t814 / 2.0
* 9.999999999999999E-14 + ( ( ( ( 1.0 - t826 ) - t947 ) * t662_idx_0 + t817 *
t826 ) + t815 * t947 ) ; t525 [ 0ULL ] = X [ 534ULL ] ;
tlu2_linear_linear_prelookup ( & pf_efOut . mField0 [ 0ULL ] , & pf_efOut .
mField1 [ 0ULL ] , & pf_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = pf_efOut ; tlu2_1d_linear_linear_value ( & qf_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = qf_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & rf_efOut [ 0ULL ] , & t71 . mField0 [
0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t817 = rf_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & sf_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 = sf_efOut [ 0 ] ; t1231 = X [
534ULL ] * t948 ; t1186 = t1231 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [ 55ULL
] ) * ( - X [ 519ULL ] / 0.0019634954084936209 ) * ( - X [ 519ULL ] /
0.0019634954084936209 ) * fabs ( t1231 / ( X [ 55ULL ] == 0.0 ? 1.0E-16 : X [
55ULL ] ) ) ; t825 = t1186 / 2.0 * 9.999999999999999E-14 + ( ( ( ( 1.0 - t826
) - t947 ) * t662_idx_0 + t817 * t826 ) + t815 * t947 ) ; t525 [ 0ULL ] = X [
532ULL ] ; tlu2_linear_linear_prelookup ( & tf_efOut . mField0 [ 0ULL ] , &
tf_efOut . mField1 [ 0ULL ] , & tf_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t69 = tf_efOut ; tlu2_1d_linear_linear_value ( &
uf_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = uf_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & vf_efOut [
0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t817 = vf_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & wf_efOut [ 0ULL ]
, & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField31 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 =
wf_efOut [ 0 ] ; t1231 = X [ 532ULL ] * t948 ; t1186 = t1231 / ( X [ 55ULL ]
== 0.0 ? 1.0E-16 : X [ 55ULL ] ) * ( X [ 519ULL ] / 0.0019634954084936209 ) *
( X [ 519ULL ] / 0.0019634954084936209 ) * fabs ( t1231 / ( X [ 55ULL ] ==
0.0 ? 1.0E-16 : X [ 55ULL ] ) ) ; t814 = t1186 / 2.0 * 9.999999999999999E-14
+ ( ( ( ( 1.0 - t826 ) - t947 ) * t662_idx_0 + t817 * t826 ) + t815 * t947 )
; t525 [ 0ULL ] = X [ 533ULL ] ; tlu2_linear_linear_prelookup ( & xf_efOut .
mField0 [ 0ULL ] , & xf_efOut . mField1 [ 0ULL ] , & xf_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t69 = xf_efOut ;
tlu2_1d_linear_linear_value ( & yf_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField26 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = yf_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ag_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t817 = ag_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & bg_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ]
, & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 = bg_efOut [ 0 ] ; t1231 = X [
533ULL ] * t948 ; t1186 = t1231 / 1.01325 * ( X [ 519ULL ] /
0.0019634954084936209 ) * ( X [ 519ULL ] / 0.0019634954084936209 ) * fabs (
t1231 / 1.01325 ) ; if ( - X [ 519ULL ] >= 0.0 ) { t947 = - ( ( t825 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * X [
519ULL ] ) ; } else { t947 = ( ( t1186 / 2.0 * 9.999999999999999E-14 + ( ( (
( 1.0 - t826 ) - t947 ) * t662_idx_0 + t817 * t826 ) + t815 * t947 ) ) - t814
) * X [ 519ULL ] ; } t948 = U_idx_12 * 376.99111843077515 ; intrm_sf_mf_1629
= t948 * 0.99999999999999978 / 0.99999999999999978 ; t643 [ 0ULL ] = X [
55ULL ] * 100000.0 ; t643 [ 1ULL ] = X [ 71ULL ] ; t643 [ 2ULL ] = X [ 543ULL
] ; t643 [ 3ULL ] = X [ 73ULL ] ; t643 [ 4ULL ] = X [ 545ULL ] ; t643 [ 5ULL
] = X [ 542ULL ] ; t643 [ 6ULL ] = X [ 72ULL ] ; t643 [ 7ULL ] = X [ 544ULL ]
; for ( t697 = 0ULL ; t697 < 8ULL ; t697 ++ ) { t626 [ t697 ] = t643 [ t697 ]
; } t525 [ 0ULL ] = X [ 71ULL ] ; tlu2_linear_linear_prelookup ( & cg_efOut .
mField0 [ 0ULL ] , & cg_efOut . mField1 [ 0ULL ] , & cg_efOut . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , &
t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t71 = cg_efOut ;
tlu2_1d_linear_linear_value ( & dg_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField18 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = dg_efOut [ 0 ] ; t825 =
t662_idx_0 ; if ( X [ 73ULL ] <= 0.0 ) { t814 = 0.0 ; } else { t814 = X [
73ULL ] >= 1.0 ? 1.0 : X [ 73ULL ] ; } if ( X [ 72ULL ] <= 0.0 ) { t955 = 0.0
; } else { t955 = X [ 72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; } t1231 = X [
71ULL ] * ( ( ( ( 1.0 - t814 ) - t955 ) * 296.802103844292 + t814 * 461.523 )
+ t955 * 259.836612622973 ) ; t956 = X [ 55ULL ] / ( t1231 == 0.0 ? 1.0E-16 :
t1231 ) ; if ( 1.0 - X [ 73ULL ] >= 0.01 ) { t957 = 1.0 - X [ 73ULL ] ; }
else if ( 1.0 - X [ 73ULL ] >= - 0.1 ) { t957 = pmf_exp ( ( ( 1.0 - X [ 73ULL
] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t957 = 1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = X [ 72ULL ]
/ ( t957 == 0.0 ? 1.0E-16 : t957 ) * - 36.965491221318985 + 296.802103844292
; tlu2_1d_linear_linear_value ( & eg_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = eg_efOut [ 0 ] ; t957 =
pmf_exp ( pmf_log ( X [ 55ULL ] * 100000.0 ) - t662_idx_0 ) ; if ( t957 >=
1.0 ) { t1231 = ( t957 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 /= t1231 ==
0.0 ? 1.0E-16 : t1231 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = 1.0 ; }
t1211 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
0.01 ; t957 = ( X [ 73ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) / ( t1211
== 0.0 ? 1.0E-16 : t1211 ) ; if ( X [ 73ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 <= 0.0 ) {
t957 = 0.0 ; } else if ( X [ 73ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 0.01 ) {
t957 = X [ 73ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; } else {
t957 = ( X [ 73ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * ( t957 *
t957 * 3.0 - t957 * t957 * t957 * 2.0 ) ; } t957 = t956 * t957 * 0.0003 /
0.001 ; t957 *= 100000.0 ; tlu2_1d_linear_linear_value ( & fg_efOut [ 0ULL ]
, & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 =
fg_efOut [ 0 ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t662_idx_0
; tlu2_1d_linear_linear_value ( & gg_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL
] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31
, & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = gg_efOut [ 0 ] ; t960 = (
( ( 1.0 - t814 ) - t955 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 + t825 * t814
) + t662_idx_0 * t955 ; t955 = - ( X [ 55ULL ] - 1.01325 ) * X [ 552ULL ] *
0.0001 ; t648 [ 0ULL ] = X [ 38ULL ] * 100000.0 ; t648 [ 1ULL ] = X [ 74ULL ]
; t648 [ 2ULL ] = X [ 557ULL ] ; t648 [ 3ULL ] = X [ 76ULL ] ; t648 [ 4ULL ]
= X [ 559ULL ] ; t648 [ 5ULL ] = X [ 556ULL ] ; t648 [ 6ULL ] = X [ 75ULL ] ;
t648 [ 7ULL ] = X [ 558ULL ] ; for ( t697 = 0ULL ; t697 < 8ULL ; t697 ++ ) {
t643 [ t697 ] = t648 [ t697 ] ; } t525 [ 0ULL ] = X [ 74ULL ] ;
tlu2_linear_linear_prelookup ( & hg_efOut . mField0 [ 0ULL ] , & hg_efOut .
mField1 [ 0ULL ] , & hg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t69 = hg_efOut ; tlu2_1d_linear_linear_value ( & ig_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ig_efOut [
0 ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 =
t662_idx_0 ; if ( X [ 76ULL ] <= 0.0 ) { t826 = 0.0 ; } else { t826 = X [
76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) { t962 = 0.0
; } else { t962 = X [ 75ULL ] >= 1.0 ? 1.0 : X [ 75ULL ] ; } t1211 = X [
74ULL ] * ( ( ( ( 1.0 - t826 ) - t962 ) * 296.802103844292 + t826 * 461.523 )
+ t962 * 4124.48151675695 ) ; t963 = X [ 38ULL ] / ( t1211 == 0.0 ? 1.0E-16 :
t1211 ) ; if ( 1.0 - X [ 76ULL ] >= 0.01 ) { t964 = 1.0 - X [ 76ULL ] ; }
else if ( 1.0 - X [ 76ULL ] >= - 0.1 ) { t964 = pmf_exp ( ( ( 1.0 - X [ 76ULL
] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t964 = 1.6701700790245661E-7 ; } t965
= X [ 75ULL ] / ( t964 == 0.0 ? 1.0E-16 : t964 ) * 3827.6794129126583 +
296.802103844292 ; tlu2_1d_linear_linear_value ( & jg_efOut [ 0ULL ] , & t69
. mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField14 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = jg_efOut
[ 0 ] ; t964 = pmf_exp ( pmf_log ( X [ 38ULL ] * 100000.0 ) - t662_idx_0 ) ;
if ( t964 >= 1.0 ) { t1211 = ( t964 - 1.0 ) * 461.523 + t965 ; t825 = t965 /
( t1211 == 0.0 ? 1.0E-16 : t1211 ) ; } else { t825 = 1.0 ; } t1186 = t825 *
0.01 ; t964 = ( X [ 76ULL ] - t825 ) / ( t1186 == 0.0 ? 1.0E-16 : t1186 ) ;
if ( X [ 76ULL ] - t825 <= 0.0 ) { t964 = 0.0 ; } else if ( X [ 76ULL ] -
t825 >= t825 * 0.01 ) { t964 = X [ 76ULL ] - t825 ; } else { t964 = ( X [
76ULL ] - t825 ) * ( t964 * t964 * 3.0 - t964 * t964 * t964 * 2.0 ) ; } t964
= t963 * t964 * 0.00012500000000000003 / 0.001 ; t964 *= 100000.0 ; t965 =
U_idx_4 * 0.01 ; tlu2_1d_linear_linear_value ( & kg_efOut [ 0ULL ] , & t69 .
mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = kg_efOut [
0 ] ; t825 = t662_idx_0 ; tlu2_1d_linear_linear_value ( & lg_efOut [ 0ULL ] ,
& t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem *
) ( LC ) ) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 =
lg_efOut [ 0 ] ; t968 = ( ( ( 1.0 - t826 ) - t962 ) * t825 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * t826 ) +
t662_idx_0 * t962 ; if ( X [ 576ULL ] <= 0.0 ) { t826 = 0.0 ; } else { t826 =
X [ 576ULL ] >= 1.0 ? 1.0 : X [ 576ULL ] ; } if ( X [ 575ULL ] <= 0.0 ) {
t962 = 0.0 ; } else { t962 = X [ 575ULL ] >= 1.0 ? 1.0 : X [ 575ULL ] ; }
t825 = ( ( ( 1.0 - t826 ) - t962 ) * 296.802103844292 + t826 * 461.523 ) +
t962 * 4124.48151675695 ; t525 [ 0ULL ] = X [ 570ULL ] ;
tlu2_linear_linear_prelookup ( & mg_efOut . mField0 [ 0ULL ] , & mg_efOut .
mField1 [ 0ULL ] , & mg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = mg_efOut ; tlu2_1d_linear_linear_value ( & ng_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ng_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & og_efOut [ 0ULL ] , & t71 . mField0 [
0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t817 = og_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & pg_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 = pg_efOut [ 0 ] ; t1211 = X [
570ULL ] * t825 ; t1227 = t1211 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [
176ULL ] ) * ( t965 / 7.8539816339744827E-5 ) * ( t965 /
7.8539816339744827E-5 ) * fabs ( t1211 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X
[ 176ULL ] ) ) ; t814 = t1227 / 2.0 * 9.999999999999999E-14 + ( ( ( ( 1.0 -
t826 ) - t962 ) * t662_idx_0 + t817 * t826 ) + t815 * t962 ) ; t525 [ 0ULL ]
= X [ 573ULL ] ; tlu2_linear_linear_prelookup ( & qg_efOut . mField0 [ 0ULL ]
, & qg_efOut . mField1 [ 0ULL ] , & qg_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t69 = qg_efOut ; tlu2_1d_linear_linear_value ( &
rg_efOut [ 0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = rg_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & sg_efOut [
0ULL ] , & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t817 = sg_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & tg_efOut [ 0ULL ]
, & t69 . mField0 [ 0ULL ] , & t69 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 =
tg_efOut [ 0 ] ; t1211 = X [ 573ULL ] * t825 ; t1227 = t1211 / ( X [ 38ULL ]
== 0.0 ? 1.0E-16 : X [ 38ULL ] ) * ( t965 / 7.8539816339744827E-5 ) * ( t965
/ 7.8539816339744827E-5 ) * fabs ( t1211 / ( X [ 38ULL ] == 0.0 ? 1.0E-16 : X
[ 38ULL ] ) ) ; t970 = t1227 / 2.0 * 9.999999999999999E-14 + ( ( ( ( 1.0 -
t826 ) - t962 ) * t662_idx_0 + t817 * t826 ) + t815 * t962 ) ; t525 [ 0ULL ]
= X [ 571ULL ] ; tlu2_linear_linear_prelookup ( & ug_efOut . mField0 [ 0ULL ]
, & ug_efOut . mField1 [ 0ULL ] , & ug_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ]
, & t76 [ 0ULL ] ) ; t71 = ug_efOut ; tlu2_1d_linear_linear_value ( &
vg_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t662_idx_0 = vg_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & wg_efOut [
0ULL ] , & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ]
) ; t817 = wg_efOut [ 0 ] ; tlu2_1d_linear_linear_value ( & xg_efOut [ 0ULL ]
, & t71 . mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem
* ) ( LC ) ) -> mField27 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 =
xg_efOut [ 0 ] ; t1211 = X [ 571ULL ] * t825 ; t1229 = t1211 / ( X [ 38ULL ]
== 0.0 ? 1.0E-16 : X [ 38ULL ] ) * ( - t965 / 7.8539816339744827E-5 ) * ( -
t965 / 7.8539816339744827E-5 ) * fabs ( t1211 / ( X [ 38ULL ] == 0.0 ?
1.0E-16 : X [ 38ULL ] ) ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = t1229 / 2.0
* 9.999999999999999E-14 + ( ( ( ( 1.0 - t826 ) - t962 ) * t662_idx_0 + t817 *
t826 ) + t815 * t962 ) ; t525 [ 0ULL ] = X [ 572ULL ] ;
tlu2_linear_linear_prelookup ( & yg_efOut . mField0 [ 0ULL ] , & yg_efOut .
mField1 [ 0ULL ] , & yg_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = yg_efOut ; tlu2_1d_linear_linear_value ( & ah_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t662_idx_0 = ah_efOut [
0 ] ; tlu2_1d_linear_linear_value ( & bh_efOut [ 0ULL ] , & t71 . mField0 [
0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t817 = bh_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & ch_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t815 = ch_efOut [ 0 ] ; t1231 = X [
572ULL ] * t825 ; t1211 = t1231 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X [
176ULL ] ) * ( - t965 / 7.8539816339744827E-5 ) * ( - t965 /
7.8539816339744827E-5 ) * fabs ( t1231 / ( X [ 176ULL ] == 0.0 ? 1.0E-16 : X
[ 176ULL ] ) ) ; if ( t965 >= 0.0 ) { t962 = ( t970 - t814 ) * t965 ; } else
{ t962 = - ( ( ( t1211 / 2.0 * 9.999999999999999E-14 + ( ( ( ( 1.0 - t826 ) -
t962 ) * t662_idx_0 + t817 * t826 ) + t815 * t962 ) ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ) * t965 ) ;
} Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 = ( - X [
19ULL ] + X [ 172ULL ] * - 1.0E-9 ) - X [ 173ULL ] ; t970 = ( ( ( X [ 19ULL ]
* - 1.0E-6 + X [ 172ULL ] * - 1.0E-15 ) + X [ 173ULL ] * - 1.0E-6 ) + X [
20ULL ] ) + X [ 464ULL ] ; t825 = ( ( X [ 4ULL ] * - 0.01 + X [ 5ULL ] * 0.01
) + X [ 168ULL ] ) + X [ 577ULL ] ; t980 = U_idx_2 >= 0.0 ? U_idx_2 : -
U_idx_2 ; t1231 = t980 * 0.01 ; t1211 = intrm_sf_mf_5 * 7.8539816339744827E-5
; t814 = t1231 / ( t1211 == 0.0 ? 1.0E-16 : t1211 ) ; t1186 = t874 - t880 ;
t826 = ( t1186 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t817 = t826 * t826 * 3.0 -
t826 * t826 * t826 * 2.0 ; if ( t1186 / 2.0 * 1.0E-5 <= - 0.01 ) { t826 =
t880 * 1.0E-5 ; } else if ( ( t874 - t880 ) / 2.0 * 1.0E-5 >= 0.01 ) { t826 =
t874 * 1.0E-5 ; } else { t826 = ( ( 1.0 - t817 ) * t880 + t874 * t817 ) *
1.0E-5 ; } t874 = t814 >= 2000.0 ? t814 : 1.0 ; t1186 = t890 -
intrm_sf_mf_1372 ; t880 = ( t1186 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t817 =
t880 * t880 * 3.0 - t880 * t880 * t880 * 2.0 ; if ( t1186 / 2.0 * 1.0E-5 <= -
0.01 ) { t880 = intrm_sf_mf_1372 * 1.0E-5 ; } else if ( ( t890 -
intrm_sf_mf_1372 ) / 2.0 * 1.0E-5 >= 0.01 ) { t880 = t890 * 1.0E-5 ; } else {
t880 = ( ( 1.0 - t817 ) * intrm_sf_mf_1372 + t890 * t817 ) * 1.0E-5 ; } t1186
= pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) +
0.00017169489553429715 ) * 3.24 ; t874 = 1.0 / ( t1186 == 0.0 ? 1.0E-16 :
t1186 ) * 0.55 / 0.01 ; t1186 = intrm_sf_mf_19 - intrm_sf_mf_1371 ; t890 = (
t1186 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; intrm_sf_mf_1372 = t890 * t890 * 3.0
- t890 * t890 * t890 * 2.0 ; if ( t1186 / 2.0 * 1.0E-5 <= - 0.01 ) { t890 =
intrm_sf_mf_1371 * 1.0E-5 ; } else if ( ( intrm_sf_mf_19 - intrm_sf_mf_1371 )
/ 2.0 * 1.0E-5 >= 0.01 ) { t890 = intrm_sf_mf_19 * 1.0E-5 ; } else { t890 = (
( 1.0 - intrm_sf_mf_1372 ) * intrm_sf_mf_1371 + intrm_sf_mf_19 *
intrm_sf_mf_1372 ) * 1.0E-5 ; } t1227 =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I *
1.5707963267948965E-8 ; intrm_sf_mf_19 = U_idx_2 * intrm_sf_mf_5 * 35.2 / (
t1227 == 0.0 ? 1.0E-16 : t1227 ) * 1.0E-5 ; intrm_sf_mf_1371 = X [ 442ULL ]
>= 0.0 ? X [ 442ULL ] : - X [ 442ULL ] ; t1229 = intrm_sf_mf_1359 * 0.002 ;
intrm_sf_mf_1372 = intrm_sf_mf_1371 * 0.01 / ( t1229 == 0.0 ? 1.0E-16 : t1229
) ; t817 = intrm_sf_mf_1372 >= 1.0 ? intrm_sf_mf_1372 : 1.0 ; t1186 =
pmf_log10 ( 6.9 / ( t817 == 0.0 ? 1.0E-16 : t817 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( t817 == 0.0 ? 1.0E-16 : t817 ) + 0.00017169489553429715
) * 3.24 ; t815 = t902 * 4.0000000000000003E-7 ; t662_idx_0 = X [ 442ULL ] *
intrm_sf_mf_1359 * 67.455490037817 / ( t815 == 0.0 ? 1.0E-16 : t815 ) ; t1169
= t902 * 8.0E-8 ; intrm_sf_mf_1371 = X [ 442ULL ] * intrm_sf_mf_1371 * ( 1.0
/ ( t1186 == 0.0 ? 1.0E-16 : t1186 ) ) * 1.0539920318408906 / ( t1169 == 0.0
? 1.0E-16 : t1169 ) ; t817 = ( intrm_sf_mf_1372 - 2000.0 ) / 2000.0 ;
intrm_sf_mf_1368 = t817 * t817 * 3.0 - t817 * t817 * t817 * 2.0 ; if (
intrm_sf_mf_1372 <= 2000.0 ) { t817 = t662_idx_0 * 1.0E-5 ; } else if (
intrm_sf_mf_1372 >= 4000.0 ) { t817 = intrm_sf_mf_1371 * 1.0E-5 ; } else {
t817 = ( ( 1.0 - intrm_sf_mf_1368 ) * t662_idx_0 + intrm_sf_mf_1371 *
intrm_sf_mf_1368 ) * 1.0E-5 ; } intrm_sf_mf_1371 = X [ 434ULL ] >= 0.0 ? X [
434ULL ] : - X [ 434ULL ] ; intrm_sf_mf_1372 = intrm_sf_mf_1371 * 0.01 / (
t1229 == 0.0 ? 1.0E-16 : t1229 ) ; t662_idx_0 = intrm_sf_mf_1372 >= 1.0 ?
intrm_sf_mf_1372 : 1.0 ; t1186 = pmf_log10 ( 6.9 / ( t662_idx_0 == 0.0 ?
1.0E-16 : t662_idx_0 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / (
t662_idx_0 == 0.0 ? 1.0E-16 : t662_idx_0 ) + 0.00017169489553429715 ) * 3.24
; intrm_sf_mf_1359 = X [ 434ULL ] * intrm_sf_mf_1359 * 67.455490037817 / (
t815 == 0.0 ? 1.0E-16 : t815 ) ; intrm_sf_mf_1371 = X [ 434ULL ] *
intrm_sf_mf_1371 * ( 1.0 / ( t1186 == 0.0 ? 1.0E-16 : t1186 ) ) *
1.0539920318408906 / ( t1169 == 0.0 ? 1.0E-16 : t1169 ) ; t662_idx_0 = (
intrm_sf_mf_1372 - 2000.0 ) / 2000.0 ; intrm_sf_mf_1368 = t662_idx_0 *
t662_idx_0 * 3.0 - t662_idx_0 * t662_idx_0 * t662_idx_0 * 2.0 ; if (
intrm_sf_mf_1372 <= 2000.0 ) { t662_idx_0 = intrm_sf_mf_1359 * 1.0E-5 ; }
else if ( intrm_sf_mf_1372 >= 4000.0 ) { t662_idx_0 = intrm_sf_mf_1371 *
1.0E-5 ; } else { t662_idx_0 = ( ( 1.0 - intrm_sf_mf_1368 ) *
intrm_sf_mf_1359 + intrm_sf_mf_1371 * intrm_sf_mf_1368 ) * 1.0E-5 ; }
intrm_sf_mf_1371 = t907 >= 0.0 ? t907 : - t907 ; t1229 = intrm_sf_mf_1431 *
0.00093750000000000007 ; intrm_sf_mf_1372 = intrm_sf_mf_1371 *
0.0028301886792452828 / ( t1229 == 0.0 ? 1.0E-16 : t1229 ) ; intrm_sf_mf_1359
= intrm_sf_mf_1372 >= 1.0 ? intrm_sf_mf_1372 : 1.0 ; t1186 = pmf_log10 ( 6.9
/ ( intrm_sf_mf_1359 == 0.0 ? 1.0E-16 : intrm_sf_mf_1359 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1359 == 0.0 ?
1.0E-16 : intrm_sf_mf_1359 ) + 0.00069701528436089772 ) * 3.24 ; t815 = t910
* 1.50186899252403E-8 ; intrm_sf_mf_1368 = t907 * intrm_sf_mf_1431 * 112.0 /
( t815 == 0.0 ? 1.0E-16 : t815 ) ; t1169 = t910 * 4.97494103773585E-9 ;
intrm_sf_mf_1371 = t907 * intrm_sf_mf_1371 * ( 1.0 / ( t1186 == 0.0 ? 1.0E-16
: t1186 ) ) * 1.75 / ( t1169 == 0.0 ? 1.0E-16 : t1169 ) ; intrm_sf_mf_1359 =
( intrm_sf_mf_1372 - 2000.0 ) / 2000.0 ; t986 = intrm_sf_mf_1359 *
intrm_sf_mf_1359 * 3.0 - intrm_sf_mf_1359 * intrm_sf_mf_1359 *
intrm_sf_mf_1359 * 2.0 ; if ( intrm_sf_mf_1372 <= 2000.0 ) { intrm_sf_mf_1359
= intrm_sf_mf_1368 * 1.0E-5 ; } else if ( intrm_sf_mf_1372 >= 4000.0 ) {
intrm_sf_mf_1359 = intrm_sf_mf_1371 * 1.0E-5 ; } else { intrm_sf_mf_1359 = (
( 1.0 - t986 ) * intrm_sf_mf_1368 + intrm_sf_mf_1371 * t986 ) * 1.0E-5 ; } if
( - X [ 442ULL ] >= 0.0 ) { intrm_sf_mf_1371 = - X [ 442ULL ] ; } else {
intrm_sf_mf_1371 = X [ 442ULL ] ; } intrm_sf_mf_1372 = intrm_sf_mf_1371 *
0.0028301886792452828 / ( t1229 == 0.0 ? 1.0E-16 : t1229 ) ; intrm_sf_mf_1368
= intrm_sf_mf_1372 >= 1.0 ? intrm_sf_mf_1372 : 1.0 ; t1186 = pmf_log10 ( 6.9
/ ( intrm_sf_mf_1368 == 0.0 ? 1.0E-16 : intrm_sf_mf_1368 ) +
0.00069701528436089772 ) * pmf_log10 ( 6.9 / ( intrm_sf_mf_1368 == 0.0 ?
1.0E-16 : intrm_sf_mf_1368 ) + 0.00069701528436089772 ) * 3.24 ;
intrm_sf_mf_1431 = X [ 442ULL ] * intrm_sf_mf_1431 * - 112.0 / ( t815 == 0.0
? 1.0E-16 : t815 ) ; intrm_sf_mf_1371 = X [ 442ULL ] * intrm_sf_mf_1371 * (
1.0 / ( t1186 == 0.0 ? 1.0E-16 : t1186 ) ) * - 1.75 / ( t1169 == 0.0 ?
1.0E-16 : t1169 ) ; intrm_sf_mf_1368 = ( intrm_sf_mf_1372 - 2000.0 ) / 2000.0
; t986 = intrm_sf_mf_1368 * intrm_sf_mf_1368 * 3.0 - intrm_sf_mf_1368 *
intrm_sf_mf_1368 * intrm_sf_mf_1368 * 2.0 ; if ( intrm_sf_mf_1372 <= 2000.0 )
{ intrm_sf_mf_1368 = intrm_sf_mf_1431 * 1.0E-5 ; } else if ( intrm_sf_mf_1372
>= 4000.0 ) { intrm_sf_mf_1368 = intrm_sf_mf_1371 * 1.0E-5 ; } else {
intrm_sf_mf_1368 = ( ( 1.0 - t986 ) * intrm_sf_mf_1431 + intrm_sf_mf_1371 *
t986 ) * 1.0E-5 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.4810541339306735 <= 0.0 ) { intrm_sf_mf_1371 = 0.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.4810541339306735 >= 1.0 ) { intrm_sf_mf_1371 = 1.0 ; } else {
intrm_sf_mf_1371 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.4810541339306735 ; } if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.2531035067089982 <= 0.0 ) { intrm_sf_mf_1372 = 0.0 ; } else if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.2531035067089982 >= 1.0 ) { intrm_sf_mf_1372 = 1.0 ; } else {
intrm_sf_mf_1372 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 /
1.2531035067089982 ; } t1229 =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I *
1.2337005501361696E-8 ; t874 = U_idx_2 * t874 * t980 / ( t1229 == 0.0 ?
1.0E-16 : t1229 ) * 1.0E-5 ; t1186 = t936 - t938 ; intrm_sf_mf_1431 = ( t1186
/ 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t986 = intrm_sf_mf_1431 * intrm_sf_mf_1431
* 3.0 - intrm_sf_mf_1431 * intrm_sf_mf_1431 * intrm_sf_mf_1431 * 2.0 ; if (
t1186 / 2.0 * 1.0E-5 <= - 0.01 ) { intrm_sf_mf_1431 = t938 * 1.0E-5 ; } else
if ( ( t936 - t938 ) / 2.0 * 1.0E-5 >= 0.01 ) { intrm_sf_mf_1431 = t936 *
1.0E-5 ; } else { intrm_sf_mf_1431 = ( ( 1.0 - t986 ) * t938 + t936 * t986 )
* 1.0E-5 ; } t936 = ( t814 - 2000.0 ) / 2000.0 ; t525 [ 0 ] = 293.15 ;
tlu2_linear_linear_prelookup ( & dh_efOut . mField0 [ 0ULL ] , & dh_efOut .
mField1 [ 0ULL ] , & dh_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t525 [ 0ULL ] , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ;
t71 = dh_efOut ; tlu2_1d_linear_linear_value ( & eh_efOut [ 0ULL ] , & t71 .
mField0 [ 0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField26 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t77 [ 0 ] = eh_efOut [ 0
] ; tlu2_1d_linear_linear_value ( & fh_efOut [ 0ULL ] , & t71 . mField0 [
0ULL ] , & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField18 , & t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t546 [ 0 ] = fh_efOut [ 0 ] ;
tlu2_1d_linear_linear_value ( & gh_efOut [ 0ULL ] , & t71 . mField0 [ 0ULL ]
, & t71 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField31 ,
& t252 [ 0ULL ] , & t76 [ 0ULL ] ) ; t665 [ 0 ] = gh_efOut [ 0 ] ; t938 = ( (
( 1.0 - intrm_sf_mf_691 ) - intrm_sf_mf_24 ) * t77 [ 0ULL ] + t546 [ 0ULL ] *
intrm_sf_mf_691 ) + t665 [ 0ULL ] * intrm_sf_mf_24 ; intrm_sf_mf_691 = t936 *
t936 * 3.0 - t936 * t936 * t936 * 2.0 ; if ( t814 <= 2000.0 ) { t936 =
intrm_sf_mf_19 ; } else if ( t814 >= 4000.0 ) { t936 = t874 ; } else { t936 =
( 1.0 - intrm_sf_mf_691 ) * intrm_sf_mf_19 + t874 * intrm_sf_mf_691 ; } if (
- U_idx_2 >= 0.0 ) { intrm_sf_mf_691 = - U_idx_2 ; } else { intrm_sf_mf_691 =
U_idx_2 ; } t1186 = intrm_sf_mf_691 * 0.01 ; intrm_sf_mf_19 = t1186 / ( t1211
== 0.0 ? 1.0E-16 : t1211 ) ; t874 = intrm_sf_mf_19 >= 2000.0 ? intrm_sf_mf_19
: 1.0 ; t1211 = pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t874 == 0.0 ? 1.0E-16 : t874 )
+ 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_5 = U_idx_2 * intrm_sf_mf_5 *
- 35.2 / ( t1227 == 0.0 ? 1.0E-16 : t1227 ) * 1.0E-5 ; t874 = - ( U_idx_2 *
intrm_sf_mf_691 * ( 1.0 / ( t1211 == 0.0 ? 1.0E-16 : t1211 ) * 0.55 / 0.01 )
) / ( t1229 == 0.0 ? 1.0E-16 : t1229 ) * 1.0E-5 ; intrm_sf_mf_24 = (
intrm_sf_mf_19 - 2000.0 ) / 2000.0 ; t814 = intrm_sf_mf_24 * intrm_sf_mf_24 *
3.0 - intrm_sf_mf_24 * intrm_sf_mf_24 * intrm_sf_mf_24 * 2.0 ; if (
intrm_sf_mf_19 <= 2000.0 ) { intrm_sf_mf_24 = intrm_sf_mf_5 ; } else if (
intrm_sf_mf_19 >= 4000.0 ) { intrm_sf_mf_24 = t874 ; } else { intrm_sf_mf_24
= ( 1.0 - t814 ) * intrm_sf_mf_5 + t874 * t814 ; } intrm_sf_mf_5 = ( X [
81ULL ] - 0.9 ) / 0.099999999999999978 ; t1211 = t818 - t823 ; intrm_sf_mf_19
= ( t1211 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t874 = intrm_sf_mf_19 *
intrm_sf_mf_19 * 3.0 - intrm_sf_mf_19 * intrm_sf_mf_19 * intrm_sf_mf_19 * 2.0
; if ( t1211 / 2.0 * 1.0E-5 <= - 0.01 ) { intrm_sf_mf_19 = t823 * 1.0E-5 ; }
else if ( ( t818 - t823 ) / 2.0 * 1.0E-5 >= 0.01 ) { intrm_sf_mf_19 = t818 *
1.0E-5 ; } else { intrm_sf_mf_19 = ( ( 1.0 - t874 ) * t823 + t818 * t874 ) *
1.0E-5 ; } t1211 = intrm_sf_mf_724 * 7.8539816339744827E-5 ; t818 = t1231 / (
t1211 == 0.0 ? 1.0E-16 : t1211 ) ; t823 = t818 >= 2000.0 ? t818 : 1.0 ; t1227
= pmf_log10 ( 6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715
) * pmf_log10 ( 6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) +
0.00017169489553429715 ) * 3.24 ; t1229 =
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
1.5707963267948965E-8 ; t874 = U_idx_2 * intrm_sf_mf_724 * 35.2 / ( t1229 ==
0.0 ? 1.0E-16 : t1229 ) * 1.0E-5 ; t815 =
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I *
1.2337005501361696E-8 ; t823 = U_idx_2 * ( 1.0 / ( t1227 == 0.0 ? 1.0E-16 :
t1227 ) * 0.55 / 0.01 ) * t980 / ( t815 == 0.0 ? 1.0E-16 : t815 ) * 1.0E-5 ;
t814 = ( t818 - 2000.0 ) / 2000.0 ; t986 = t814 * t814 * 3.0 - t814 * t814 *
t814 * 2.0 ; if ( t818 <= 2000.0 ) { t814 = t874 ; } else if ( t818 >= 4000.0
) { t814 = t823 ; } else { t814 = ( 1.0 - t986 ) * t874 + t823 * t986 ; }
t818 = intrm_sf_mf_5 * intrm_sf_mf_5 * 3.0 - intrm_sf_mf_5 * intrm_sf_mf_5 *
intrm_sf_mf_5 * 2.0 ; intrm_sf_mf_5 = t1186 / ( t1211 == 0.0 ? 1.0E-16 :
t1211 ) ; t823 = intrm_sf_mf_5 >= 2000.0 ? intrm_sf_mf_5 : 1.0 ; t1211 =
pmf_log10 ( 6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715 )
* pmf_log10 ( 6.9 / ( t823 == 0.0 ? 1.0E-16 : t823 ) + 0.00017169489553429715
) * 3.24 ; t823 = 1.0 / ( t1211 == 0.0 ? 1.0E-16 : t1211 ) * 0.55 / 0.01 ;
intrm_sf_mf_724 = U_idx_2 * intrm_sf_mf_724 * - 35.2 / ( t1229 == 0.0 ?
1.0E-16 : t1229 ) * 1.0E-5 ; t1211 = intrm_sf_mf_47 - t833 ; t874 = ( t1211 /
2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t986 = t874 * t874 * 3.0 - t874 * t874 *
t874 * 2.0 ; if ( t1211 / 2.0 * 1.0E-5 <= - 0.01 ) { t874 = t833 * 1.0E-5 ; }
else if ( ( intrm_sf_mf_47 - t833 ) / 2.0 * 1.0E-5 >= 0.01 ) { t874 =
intrm_sf_mf_47 * 1.0E-5 ; } else { t874 = ( ( 1.0 - t986 ) * t833 +
intrm_sf_mf_47 * t986 ) * 1.0E-5 ; } t823 = - ( U_idx_2 * intrm_sf_mf_691 *
t823 ) / ( t815 == 0.0 ? 1.0E-16 : t815 ) * 1.0E-5 ; intrm_sf_mf_47 = (
intrm_sf_mf_5 - 2000.0 ) / 2000.0 ; t833 = intrm_sf_mf_47 * intrm_sf_mf_47 *
3.0 - intrm_sf_mf_47 * intrm_sf_mf_47 * intrm_sf_mf_47 * 2.0 ; if (
intrm_sf_mf_5 <= 2000.0 ) { intrm_sf_mf_47 = intrm_sf_mf_724 ; } else if (
intrm_sf_mf_5 >= 4000.0 ) { intrm_sf_mf_47 = t823 ; } else { intrm_sf_mf_47 =
( 1.0 - t833 ) * intrm_sf_mf_724 + t823 * t833 ; } if ( X [ 81ULL ] <= 0.9 )
{ intrm_sf_mf_5 = 0.0 ; } else { intrm_sf_mf_5 = X [ 81ULL ] >= 1.0 ? 1.0 :
t818 ; } t1211 = intrm_sf_mf_901 * 7.8539816339744827E-5 ; intrm_sf_mf_724 =
t1231 / ( t1211 == 0.0 ? 1.0E-16 : t1211 ) ; t818 = intrm_sf_mf_724 >= 2000.0
? intrm_sf_mf_724 : 1.0 ; t1231 = pmf_log10 ( 6.9 / ( t818 == 0.0 ? 1.0E-16 :
t818 ) + 0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t818 == 0.0 ? 1.0E-16
: t818 ) + 0.00017169489553429715 ) * 3.24 ; t1227 =
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I * 1.5707963267948965E-8
; t823 = U_idx_2 * intrm_sf_mf_901 * 35.2 / ( t1227 == 0.0 ? 1.0E-16 : t1227
) * 1.0E-5 ; t1229 = Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I *
1.2337005501361696E-8 ; t818 = U_idx_2 * ( 1.0 / ( t1231 == 0.0 ? 1.0E-16 :
t1231 ) * 0.55 / 0.01 ) * t980 / ( t1229 == 0.0 ? 1.0E-16 : t1229 ) * 1.0E-5
; t833 = ( intrm_sf_mf_724 - 2000.0 ) / 2000.0 ; t1231 = piece99 - t1244 ;
t980 = ( t1231 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t986 = t980 * t980 * 3.0 -
t980 * t980 * t980 * 2.0 ; if ( t1231 / 2.0 * 1.0E-5 <= - 0.01 ) { t980 =
t1244 * 1.0E-5 ; } else if ( ( piece99 - t1244 ) / 2.0 * 1.0E-5 >= 0.01 ) {
t980 = piece99 * 1.0E-5 ; } else { t980 = ( ( 1.0 - t986 ) * t1244 + piece99
* t986 ) * 1.0E-5 ; } piece99 = t833 * t833 * 3.0 - t833 * t833 * t833 * 2.0
; if ( intrm_sf_mf_724 <= 2000.0 ) { t833 = t823 ; } else if (
intrm_sf_mf_724 >= 4000.0 ) { t833 = t818 ; } else { t833 = ( 1.0 - piece99 )
* t823 + t818 * piece99 ; } intrm_sf_mf_724 = t1186 / ( t1211 == 0.0 ?
1.0E-16 : t1211 ) ; t818 = intrm_sf_mf_724 >= 2000.0 ? intrm_sf_mf_724 : 1.0
; t1244 = pmf_log10 ( 6.9 / ( t818 == 0.0 ? 1.0E-16 : t818 ) +
0.00017169489553429715 ) * pmf_log10 ( 6.9 / ( t818 == 0.0 ? 1.0E-16 : t818 )
+ 0.00017169489553429715 ) * 3.24 ; intrm_sf_mf_901 = U_idx_2 *
intrm_sf_mf_901 * - 35.2 / ( t1227 == 0.0 ? 1.0E-16 : t1227 ) * 1.0E-5 ;
intrm_sf_mf_691 = - ( U_idx_2 * intrm_sf_mf_691 * ( 1.0 / ( t1244 == 0.0 ?
1.0E-16 : t1244 ) * 0.55 / 0.01 ) ) / ( t1229 == 0.0 ? 1.0E-16 : t1229 ) *
1.0E-5 ; t818 = ( intrm_sf_mf_724 - 2000.0 ) / 2000.0 ; t823 = t818 * t818 *
3.0 - t818 * t818 * t818 * 2.0 ; if ( intrm_sf_mf_724 <= 2000.0 ) { t818 =
intrm_sf_mf_901 ; } else if ( intrm_sf_mf_724 >= 4000.0 ) { t818 =
intrm_sf_mf_691 ; } else { t818 = ( 1.0 - t823 ) * intrm_sf_mf_901 +
intrm_sf_mf_691 * t823 ; } intrm_sf_mf_691 = ( ( ( 1.0 - t842 ) - t1251 ) *
t77 [ 0ULL ] + t546 [ 0ULL ] * t842 ) + t665 [ 0ULL ] * t1251 ; t1244 = t855
- t857 ; intrm_sf_mf_724 = ( t1244 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ;
intrm_sf_mf_901 = intrm_sf_mf_724 * intrm_sf_mf_724 * 3.0 - intrm_sf_mf_724 *
intrm_sf_mf_724 * intrm_sf_mf_724 * 2.0 ; if ( t1244 / 2.0 * 1.0E-5 <= - 0.01
) { intrm_sf_mf_724 = t857 * 1.0E-5 ; } else if ( ( t855 - t857 ) / 2.0 *
1.0E-5 >= 0.01 ) { intrm_sf_mf_724 = t855 * 1.0E-5 ; } else { intrm_sf_mf_724
= ( ( 1.0 - intrm_sf_mf_901 ) * t857 + t855 * intrm_sf_mf_901 ) * 1.0E-5 ; }
t1244 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 ;
intrm_sf_mf_901 = ( t1244 / 2.0 * 1.0E-5 - - 0.01 ) / 0.02 ; t823 =
intrm_sf_mf_901 * intrm_sf_mf_901 * 3.0 - intrm_sf_mf_901 * intrm_sf_mf_901 *
intrm_sf_mf_901 * 2.0 ; if ( t1244 / 2.0 * 1.0E-5 <= - 0.01 ) {
intrm_sf_mf_901 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 * 1.0E-5 ; }
else if ( ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 ) / 2.0 *
1.0E-5 >= 0.01 ) { intrm_sf_mf_901 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * 1.0E-5 ; }
else { intrm_sf_mf_901 = ( ( 1.0 - t823 ) *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_5 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_33 * t823 ) *
1.0E-5 ; } t706 [ 0ULL ] = t71 . mField0 [ 0ULL ] ; t706 [ 1ULL ] = t71 .
mField0 [ 1ULL ] ; t75 [ 0ULL ] = t71 . mField2 [ 0ULL ] ;
tlu2_1d_linear_linear_value ( & hh_efOut [ 0ULL ] , & t706 [ 0ULL ] , & t75 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField27 , & t252 [ 0ULL ] , &
t76 [ 0ULL ] ) ; t665 [ 0 ] = hh_efOut [ 0 ] ; t823 = ( ( ( 1.0 - piece22 ) -
piece23 ) * t77 [ 0ULL ] + t546 [ 0ULL ] * piece22 ) + t665 [ 0ULL ] *
piece23 ; piece23 = X [ 179ULL ] * 0.00062831853071795862 ; piece99 = X [
306ULL ] * 0.0031415926535897937 ; t545 [ 0ULL ] = X [ 0ULL ] ; t545 [ 1ULL ]
= Battery_System_Battery_Table_Based_Q * 1000.0 ; t545 [ 2ULL ] = X [ 0ULL ]
; t545 [ 3ULL ] = X [ 1ULL ] * 0.00027777777777777778 ; t545 [ 4ULL ] = X [
79ULL ] ; t545 [ 5ULL ] = X [ 2ULL ] ; t545 [ 6ULL ] = X [ 80ULL ] ; t545 [
7ULL ] = t702 ; t545 [ 8ULL ] = X [ 81ULL ] ; t545 [ 9ULL ] = X [ 82ULL ] *
1000.0 ; t545 [ 10ULL ] = X [ 82ULL ] * 1000.0 ; t545 [ 11ULL ] = X [ 83ULL ]
; t545 [ 12ULL ] = X [ 83ULL ] ; t545 [ 13ULL ] = X [ 81ULL ] ; t545 [ 14ULL
] = X [ 84ULL ] ; t545 [ 15ULL ] = X [ 85ULL ] ; t545 [ 16ULL ] = X [ 86ULL ]
; t545 [ 17ULL ] = X [ 87ULL ] * 0.00027777777777777778 ; t545 [ 18ULL ] = X
[ 83ULL ] ; t545 [ 19ULL ] = t704 ; t545 [ 20ULL ] = X [ 81ULL ] ; t545 [
21ULL ] = intrm_sf_mf_2 ; t545 [ 22ULL ] = intrm_sf_mf_5 ; t545 [ 23ULL ] = X
[ 88ULL ] ; t545 [ 24ULL ] = X [ 81ULL ] ; t545 [ 25ULL ] = X [ 89ULL ] ;
t545 [ 26ULL ] = ( X [ 90ULL ] * intrm_sf_mf_2 + ( 1.0 - intrm_sf_mf_2 ) *
t704 * t704 ) * 1000.0 ; t545 [ 27ULL ] = X [ 90ULL ] * 1000.0 ; t545 [ 28ULL
] = X [ 3ULL ] ; t545 [ 29ULL ] = X [ 89ULL ] ; t545 [ 30ULL ] = X [ 5ULL ] ;
t545 [ 31ULL ] = U_idx_0 ; t545 [ 32ULL ] = U_idx_1 ; t545 [ 33ULL ] =
U_idx_1 ; t545 [ 34ULL ] = X [ 81ULL ] ; t545 [ 35ULL ] = X [ 81ULL ] ; t545
[ 36ULL ] = U_idx_1 ; t545 [ 37ULL ] = X [ 81ULL ] ; t545 [ 38ULL ] = - X [
79ULL ] ; t545 [ 39ULL ] = - X [ 79ULL ] ; t545 [ 40ULL ] = X [ 81ULL ] ;
t545 [ 41ULL ] = X [ 81ULL ] ; t545 [ 42ULL ] = - X [ 79ULL ] ; t545 [ 43ULL
] = X [ 81ULL ] ; t545 [ 44ULL ] = X [ 81ULL ] ; t545 [ 45ULL ] = X [ 81ULL ]
; t545 [ 46ULL ] = X [ 81ULL ] ; t545 [ 47ULL ] = X [ 81ULL ] ; t545 [ 48ULL
] = - X [ 88ULL ] ; t545 [ 49ULL ] = - X [ 88ULL ] ; t545 [ 50ULL ] = X [
89ULL ] ; t545 [ 51ULL ] = X [ 89ULL ] ; t545 [ 52ULL ] = - X [ 88ULL ] ;
t545 [ 53ULL ] = X [ 89ULL ] ; t545 [ 54ULL ] = X [ 89ULL ] ; t545 [ 55ULL ]
= X [ 89ULL ] ; t545 [ 56ULL ] = X [ 89ULL ] ; t545 [ 57ULL ] = X [ 89ULL ] ;
t545 [ 58ULL ] = X [ 4ULL ] ; t545 [ 59ULL ] = t776 * 1000.0 ; t545 [ 60ULL ]
= t776 * 1000.0 ; t545 [ 61ULL ] = - X [ 4ULL ] ; t545 [ 62ULL ] = X [ 5ULL ]
; t545 [ 63ULL ] = t776 * 1.0E+6 ; t545 [ 64ULL ] = t776 * 1000.0 ; t545 [
65ULL ] = - X [ 88ULL ] ; t545 [ 66ULL ] = t776 * 1.0E+6 ; t545 [ 67ULL ] = -
X [ 88ULL ] ; t545 [ 68ULL ] = X [ 4ULL ] ; t545 [ 69ULL ] = X [ 4ULL ] ;
t545 [ 70ULL ] = X [ 91ULL ] * 1000.0 ; t545 [ 71ULL ] = X [ 4ULL ] ; t545 [
72ULL ] = X [ 4ULL ] ; t545 [ 73ULL ] = X [ 5ULL ] ; t545 [ 74ULL ] = t777 *
1000.0 ; t545 [ 75ULL ] = t777 * 100.0 ; t545 [ 76ULL ] = - X [ 88ULL ] ;
t545 [ 77ULL ] = U_idx_0 ; t545 [ 78ULL ] = X [ 0ULL ] ; t545 [ 79ULL ] =
Battery_System_Battery_Table_Based_Q * 1000.0 ; t545 [ 80ULL ] =
Battery_System_Battery_Table_Based_Q * 100.0 ; t545 [ 81ULL ] = X [ 89ULL ] ;
t545 [ 82ULL ] = X [ 92ULL ] ; t545 [ 83ULL ] = X [ 93ULL ] * 0.1 ; t545 [
84ULL ] = X [ 94ULL ] ; t545 [ 85ULL ] = X [ 95ULL ] * 0.1 ; t545 [ 86ULL ] =
X [ 96ULL ] ; t545 [ 87ULL ] = - X [ 96ULL ] ; t545 [ 88ULL ] = X [ 92ULL ] ;
t545 [ 89ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 90ULL ] = X [ 96ULL ] ; t545 [
91ULL ] = X [ 97ULL ] ; t545 [ 92ULL ] = U_idx_2 ; t545 [ 93ULL ] = X [ 98ULL
] ; t545 [ 94ULL ] = X [ 94ULL ] ; t545 [ 95ULL ] = X [ 95ULL ] * 0.1 ; t545
[ 96ULL ] = - X [ 96ULL ] ; t545 [ 97ULL ] = X [ 99ULL ] ; t545 [ 98ULL ] = -
U_idx_2 ; t545 [ 99ULL ] = X [ 98ULL ] ; t545 [ 100ULL ] = U_idx_2 ; t545 [
101ULL ] = - U_idx_2 ; t545 [ 102ULL ] = X [ 100ULL ] ; t545 [ 103ULL ] = X [
101ULL ] ; t545 [ 104ULL ] = X [ 102ULL ] * 0.1 ; t545 [ 105ULL ] = X [
103ULL ] ; t545 [ 106ULL ] = X [ 104ULL ] * 0.1 ; t545 [ 107ULL ] = X [
105ULL ] ; t545 [ 108ULL ] = - X [ 105ULL ] ; t545 [ 109ULL ] = X [ 101ULL ]
; t545 [ 110ULL ] = X [ 102ULL ] * 0.1 ; t545 [ 111ULL ] = X [ 105ULL ] ;
t545 [ 112ULL ] = X [ 106ULL ] ; t545 [ 113ULL ] = U_idx_2 ; t545 [ 114ULL ]
= X [ 107ULL ] ; t545 [ 115ULL ] = X [ 103ULL ] ; t545 [ 116ULL ] = X [
104ULL ] * 0.1 ; t545 [ 117ULL ] = - X [ 105ULL ] ; t545 [ 118ULL ] = X [
108ULL ] ; t545 [ 119ULL ] = - U_idx_2 ; t545 [ 120ULL ] = X [ 107ULL ] ;
t545 [ 121ULL ] = U_idx_2 ; t545 [ 122ULL ] = - U_idx_2 ; t545 [ 123ULL ] = X
[ 109ULL ] ; t545 [ 124ULL ] = X [ 110ULL ] ; t545 [ 125ULL ] = X [ 111ULL ]
* 0.1 ; t545 [ 126ULL ] = X [ 112ULL ] ; t545 [ 127ULL ] = X [ 113ULL ] * 0.1
; t545 [ 128ULL ] = X [ 114ULL ] ; t545 [ 129ULL ] = - X [ 114ULL ] ; t545 [
130ULL ] = X [ 110ULL ] ; t545 [ 131ULL ] = X [ 111ULL ] * 0.1 ; t545 [
132ULL ] = X [ 114ULL ] ; t545 [ 133ULL ] = X [ 115ULL ] ; t545 [ 134ULL ] =
U_idx_2 ; t545 [ 135ULL ] = X [ 116ULL ] ; t545 [ 136ULL ] = X [ 112ULL ] ;
t545 [ 137ULL ] = X [ 113ULL ] * 0.1 ; t545 [ 138ULL ] = - X [ 114ULL ] ;
t545 [ 139ULL ] = X [ 117ULL ] ; t545 [ 140ULL ] = - U_idx_2 ; t545 [ 141ULL
] = X [ 116ULL ] ; t545 [ 142ULL ] = U_idx_2 ; t545 [ 143ULL ] = - U_idx_2 ;
t545 [ 144ULL ] = X [ 118ULL ] ; t545 [ 145ULL ] = X [ 5ULL ] ; t545 [ 146ULL
] = X [ 13ULL ] ; t545 [ 147ULL ] = U_idx_0 ; t545 [ 148ULL ] = X [ 112ULL ]
; t545 [ 149ULL ] = X [ 113ULL ] * 0.1 ; t545 [ 150ULL ] = X [ 119ULL ] ;
t545 [ 151ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 152ULL ] = U_idx_0 ; t545 [
153ULL ] = X [ 112ULL ] ; t545 [ 154ULL ] = X [ 113ULL ] * 0.1 ; t545 [
155ULL ] = X [ 119ULL ] ; t545 [ 156ULL ] = X [ 120ULL ] * 0.1 ; t545 [
157ULL ] = U_idx_0 ; t545 [ 158ULL ] = X [ 6ULL ] ; t545 [ 159ULL ] = U_idx_2
; t545 [ 160ULL ] = - U_idx_2 ; t545 [ 161ULL ] =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_p_I ; t545 [ 162ULL ] = X
[ 114ULL ] ; t545 [ 163ULL ] = X [ 121ULL ] ; t545 [ 164ULL ] = X [ 122ULL ]
; t545 [ 165ULL ] = X [ 112ULL ] ; t545 [ 166ULL ] = X [ 113ULL ] * 0.1 ;
t545 [ 167ULL ] = X [ 114ULL ] ; t545 [ 168ULL ] = X [ 123ULL ] ; t545 [
169ULL ] = U_idx_2 ; t545 [ 170ULL ] = X [ 124ULL ] ; t545 [ 171ULL ] = X [
123ULL ] ; t545 [ 172ULL ] = X [ 119ULL ] ; t545 [ 173ULL ] = X [ 120ULL ] *
0.1 ; t545 [ 174ULL ] = X [ 121ULL ] ; t545 [ 175ULL ] = X [ 125ULL ] ; t545
[ 176ULL ] = - U_idx_2 ; t545 [ 177ULL ] = X [ 126ULL ] ; t545 [ 178ULL ] = X
[ 125ULL ] ; t545 [ 179ULL ] =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_rho_I ; t545 [ 180ULL ] =
Electrical_Cooling_System_Heat_Exchanger_pipe_model_u_I ; t545 [ 181ULL ] =
t936 ; t545 [ 182ULL ] = intrm_sf_mf_24 ; t545 [ 183ULL ] = t778 ; t545 [
184ULL ] = Electrical_Cooling_System_Heat_Exchanger_pipe_model_convectio7 ;
t545 [ 185ULL ] = U_idx_0 ; t545 [ 186ULL ] = U_idx_0 ; t545 [ 187ULL ] =
U_idx_0 ; t545 [ 188ULL ] = U_idx_0 ; t545 [ 189ULL ] = X [ 122ULL ] * 1000.0
; t545 [ 190ULL ] = X [ 122ULL ] * 1000.0 ; t545 [ 191ULL ] = X [ 122ULL ] *
1000.0 ; t545 [ 192ULL ] = U_idx_0 ; t545 [ 193ULL ] = U_idx_0 ; t545 [
194ULL ] = U_idx_0 ; t545 [ 195ULL ] = U_idx_0 ; t545 [ 196ULL ] = U_idx_0 ;
t545 [ 197ULL ] = U_idx_0 ; t545 [ 198ULL ] = t779 * 1000.0 ; t545 [ 199ULL ]
= t779 * 1000.0 ; t545 [ 200ULL ] = t779 * 1000.0 ; t545 [ 201ULL ] = U_idx_0
; t545 [ 202ULL ] = U_idx_0 ; t545 [ 203ULL ] = X [ 94ULL ] ; t545 [ 204ULL ]
= X [ 95ULL ] * 0.1 ; t545 [ 205ULL ] = X [ 101ULL ] ; t545 [ 206ULL ] = X [
102ULL ] * 0.1 ; t545 [ 207ULL ] = X [ 10ULL ] ; t545 [ 208ULL ] = X [ 94ULL
] ; t545 [ 209ULL ] = X [ 95ULL ] * 0.1 ; t545 [ 210ULL ] = X [ 101ULL ] ;
t545 [ 211ULL ] = X [ 102ULL ] * 0.1 ; t545 [ 212ULL ] = X [ 10ULL ] ; t545 [
213ULL ] = X [ 9ULL ] ; t545 [ 214ULL ] = U_idx_2 ; t545 [ 215ULL ] = -
U_idx_2 ; t545 [ 216ULL ] =
Electrical_Cooling_System_Pipe_Converter_pipe_model_p_I ; t545 [ 217ULL ] = X
[ 96ULL ] ; t545 [ 218ULL ] = - X [ 105ULL ] ; t545 [ 219ULL ] = X [ 127ULL ]
; t545 [ 220ULL ] = X [ 94ULL ] ; t545 [ 221ULL ] = X [ 95ULL ] * 0.1 ; t545
[ 222ULL ] = X [ 96ULL ] ; t545 [ 223ULL ] = X [ 128ULL ] ; t545 [ 224ULL ] =
U_idx_2 ; t545 [ 225ULL ] = X [ 129ULL ] ; t545 [ 226ULL ] = X [ 128ULL ] ;
t545 [ 227ULL ] = X [ 101ULL ] ; t545 [ 228ULL ] = X [ 102ULL ] * 0.1 ; t545
[ 229ULL ] = - X [ 105ULL ] ; t545 [ 230ULL ] = X [ 130ULL ] ; t545 [ 231ULL
] = - U_idx_2 ; t545 [ 232ULL ] = X [ 131ULL ] ; t545 [ 233ULL ] = X [ 130ULL
] ; t545 [ 234ULL ] =
Electrical_Cooling_System_Pipe_Converter_pipe_model_rho_I ; t545 [ 235ULL ] =
Electrical_Cooling_System_Pipe_Converter_pipe_model_u_I ; t545 [ 236ULL ] =
t814 ; t545 [ 237ULL ] = intrm_sf_mf_47 ; t545 [ 238ULL ] = t780 ; t545 [
239ULL ] = Electrical_Cooling_System_Pipe_Converter_pipe_model_convection3 ;
t545 [ 240ULL ] = X [ 103ULL ] ; t545 [ 241ULL ] = X [ 104ULL ] * 0.1 ; t545
[ 242ULL ] = X [ 110ULL ] ; t545 [ 243ULL ] = X [ 111ULL ] * 0.1 ; t545 [
244ULL ] = X [ 12ULL ] ; t545 [ 245ULL ] = X [ 103ULL ] ; t545 [ 246ULL ] = X
[ 104ULL ] * 0.1 ; t545 [ 247ULL ] = X [ 110ULL ] ; t545 [ 248ULL ] = X [
111ULL ] * 0.1 ; t545 [ 249ULL ] = X [ 12ULL ] ; t545 [ 250ULL ] = X [ 11ULL
] ; t545 [ 251ULL ] = U_idx_2 ; t545 [ 252ULL ] = - U_idx_2 ; t545 [ 253ULL ]
= Electrical_Cooling_System_Pipe_Motor_pipe_model_p_I ; t545 [ 254ULL ] = X [
105ULL ] ; t545 [ 255ULL ] = - X [ 114ULL ] ; t545 [ 256ULL ] = X [ 132ULL ]
; t545 [ 257ULL ] = X [ 103ULL ] ; t545 [ 258ULL ] = X [ 104ULL ] * 0.1 ;
t545 [ 259ULL ] = X [ 105ULL ] ; t545 [ 260ULL ] = X [ 133ULL ] ; t545 [
261ULL ] = U_idx_2 ; t545 [ 262ULL ] = X [ 134ULL ] ; t545 [ 263ULL ] = X [
133ULL ] ; t545 [ 264ULL ] = X [ 110ULL ] ; t545 [ 265ULL ] = X [ 111ULL ] *
0.1 ; t545 [ 266ULL ] = - X [ 114ULL ] ; t545 [ 267ULL ] = X [ 135ULL ] ;
t545 [ 268ULL ] = - U_idx_2 ; t545 [ 269ULL ] = X [ 136ULL ] ; t545 [ 270ULL
] = X [ 135ULL ] ; t545 [ 271ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_rho_I ; t545 [ 272ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_u_I ; t545 [ 273ULL ] = t833
; t545 [ 274ULL ] = t818 ; t545 [ 275ULL ] = t781 ; t545 [ 276ULL ] =
Electrical_Cooling_System_Pipe_Motor_pipe_model_convection_B_rh ; t545 [
277ULL ] = X [ 137ULL ] ; t545 [ 278ULL ] = X [ 138ULL ] * 0.1 ; t545 [
279ULL ] = X [ 92ULL ] ; t545 [ 280ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 281ULL
] = U_idx_2 ; t545 [ 282ULL ] = X [ 139ULL ] ; t545 [ 283ULL ] = - X [ 96ULL
] ; t545 [ 284ULL ] = X [ 137ULL ] ; t545 [ 285ULL ] = X [ 138ULL ] * 0.1 ;
t545 [ 286ULL ] = X [ 139ULL ] ; t545 [ 287ULL ] = X [ 140ULL ] ; t545 [
288ULL ] = U_idx_2 ; t545 [ 289ULL ] = X [ 141ULL ] ; t545 [ 290ULL ] = X [
92ULL ] ; t545 [ 291ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 292ULL ] = - X [ 96ULL
] ; t545 [ 293ULL ] = X [ 142ULL ] ; t545 [ 294ULL ] = - U_idx_2 ; t545 [
295ULL ] = X [ 141ULL ] ; t545 [ 296ULL ] = U_idx_2 ; t545 [ 297ULL ] = -
U_idx_2 ; t545 [ 298ULL ] = ( X [ 93ULL ] - X [ 138ULL ] ) * U_idx_2 / (
Electrical_Cooling_System_Pump_rho_avg == 0.0 ? 1.0E-16 :
Electrical_Cooling_System_Pump_rho_avg ) ; t545 [ 299ULL ] = U_idx_0 ; t545 [
300ULL ] = U_idx_0 ; t545 [ 301ULL ] = U_idx_0 ; t545 [ 302ULL ] = U_idx_0 ;
t545 [ 303ULL ] = X [ 13ULL ] ; t545 [ 304ULL ] = X [ 13ULL ] ; t545 [ 305ULL
] = X [ 13ULL ] ; t545 [ 306ULL ] = X [ 13ULL ] ; t545 [ 307ULL ] = X [ 92ULL
] ; t545 [ 308ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 309ULL ] = X [ 137ULL ] ;
t545 [ 310ULL ] = X [ 138ULL ] * 0.1 ; t545 [ 311ULL ] = X [ 92ULL ] ; t545 [
312ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 313ULL ] = t783 * 1000.0 ; t545 [
314ULL ] = t783 * 1111.1111111111111 ; t545 [ 315ULL ] = t783 *
1111.1111111111111 ; t545 [ 316ULL ] = t782 * 99999.999999999985 ; t545 [
317ULL ] = X [ 143ULL ] * 1.0E-6 ; t545 [ 318ULL ] = t783 * 1000.0 ; t545 [
319ULL ] = X [ 137ULL ] ; t545 [ 320ULL ] = X [ 138ULL ] * 0.1 ; t545 [
321ULL ] = X [ 92ULL ] ; t545 [ 322ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 323ULL
] = t782 * 99999.999999999985 ; t545 [ 324ULL ] = X [ 137ULL ] - X [ 92ULL ]
; t545 [ 325ULL ] = X [ 92ULL ] ; t545 [ 326ULL ] = X [ 93ULL ] * 0.1 ; t545
[ 327ULL ] = X [ 92ULL ] ; t545 [ 328ULL ] = X [ 93ULL ] * 0.1 ; t545 [
329ULL ] = X [ 96ULL ] ; t545 [ 330ULL ] = X [ 143ULL ] * 1.0E-6 ; t545 [
331ULL ] = U_idx_2 ; t545 [ 332ULL ] = U_idx_2 ; t545 [ 333ULL ] = X [ 137ULL
] ; t545 [ 334ULL ] = X [ 138ULL ] * 0.1 ; t545 [ 335ULL ] = X [ 119ULL ] ;
t545 [ 336ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 337ULL ] = X [ 144ULL ] ; t545
[ 338ULL ] = X [ 145ULL ] * 0.1 ; t545 [ 339ULL ] = X [ 144ULL ] ; t545 [
340ULL ] = X [ 145ULL ] * 0.1 ; t545 [ 341ULL ] = X [ 7ULL ] ; t545 [ 342ULL
] = U_idx_0 ; t545 [ 343ULL ] = t787 * 1000.0 ; t545 [ 344ULL ] = t787 *
5000.0 ; t545 [ 345ULL ] = X [ 8ULL ] ; t545 [ 346ULL ] = U_idx_0 ; t545 [
347ULL ] = t788 * 1000.0 ; t545 [ 348ULL ] = t788 * 500000.0 ; t545 [ 349ULL
] = X [ 146ULL ] ; t545 [ 350ULL ] = X [ 147ULL ] * 0.1 ; t545 [ 351ULL ] = X
[ 148ULL ] ; t545 [ 352ULL ] = X [ 149ULL ] * 0.1 ; t545 [ 353ULL ] = X [
150ULL ] ; t545 [ 354ULL ] = - X [ 150ULL ] ; t545 [ 355ULL ] = X [ 151ULL ]
; t545 [ 356ULL ] = X [ 152ULL ] ; t545 [ 357ULL ] = X [ 146ULL ] ; t545 [
358ULL ] = X [ 147ULL ] * 0.1 ; t545 [ 359ULL ] = X [ 150ULL ] ; t545 [
360ULL ] = X [ 153ULL ] ; t545 [ 361ULL ] = X [ 154ULL ] ; t545 [ 362ULL ] =
X [ 148ULL ] ; t545 [ 363ULL ] = X [ 149ULL ] * 0.1 ; t545 [ 364ULL ] = - X [
150ULL ] ; t545 [ 365ULL ] = X [ 153ULL ] ; t545 [ 366ULL ] = - X [ 154ULL ]
; t545 [ 367ULL ] = X [ 154ULL ] ; t545 [ 368ULL ] = - X [ 154ULL ] ; t545 [
369ULL ] = U_idx_0 ; t545 [ 370ULL ] = U_idx_0 ; t545 [ 371ULL ] = X [ 146ULL
] ; t545 [ 372ULL ] = X [ 147ULL ] * 0.1 ; t545 [ 373ULL ] = - X [ 150ULL ] ;
t545 [ 374ULL ] = X [ 146ULL ] ; t545 [ 375ULL ] = X [ 147ULL ] * 0.1 ; t545
[ 376ULL ] = - X [ 150ULL ] ; t545 [ 377ULL ] = X [ 155ULL ] ; t545 [ 378ULL
] = - X [ 154ULL ] ; t545 [ 379ULL ] = - X [ 154ULL ] ; t545 [ 380ULL ] = X [
119ULL ] ; t545 [ 381ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 382ULL ] = X [
120ULL ] * 99999.999999999985 ; t545 [ 383ULL ] = X [ 119ULL ] ; t545 [
384ULL ] = X [ 119ULL ] ; t545 [ 385ULL ] = X [ 148ULL ] ; t545 [ 386ULL ] =
X [ 149ULL ] * 0.1 ; t545 [ 387ULL ] = X [ 137ULL ] ; t545 [ 388ULL ] = X [
138ULL ] * 0.1 ; t545 [ 389ULL ] = X [ 144ULL ] ; t545 [ 390ULL ] = X [
145ULL ] * 0.1 ; t545 [ 391ULL ] = X [ 119ULL ] ; t545 [ 392ULL ] = X [
120ULL ] * 0.1 ; t545 [ 393ULL ] = X [ 150ULL ] ; t545 [ 394ULL ] = - X [
139ULL ] ; t545 [ 395ULL ] = - X [ 121ULL ] ; t545 [ 396ULL ] = X [ 156ULL ]
; t545 [ 397ULL ] = X [ 157ULL ] ; t545 [ 398ULL ] = X [ 7ULL ] ; t545 [
399ULL ] = X [ 8ULL ] ; t545 [ 400ULL ] = X [ 7ULL ] + 126.84999999999997 ;
t545 [ 401ULL ] = X [ 154ULL ] ; t545 [ 402ULL ] = - U_idx_2 ; t545 [ 403ULL
] = U_idx_2 ; t545 [ 404ULL ] = X [ 15ULL ] * 0.1 ; t545 [ 405ULL ] = X [
15ULL ] * 0.1 ; t545 [ 406ULL ] = X [ 159ULL ] ; t545 [ 407ULL ] = X [ 160ULL
] ; t545 [ 408ULL ] = X [ 161ULL ] ; t545 [ 409ULL ] = X [ 162ULL ] ; t545 [
410ULL ] = X [ 163ULL ] ; t545 [ 411ULL ] = X [ 165ULL ] ; t545 [ 412ULL ] =
X [ 166ULL ] ; t545 [ 413ULL ] = X [ 167ULL ] ; t545 [ 414ULL ] = X [ 7ULL ]
; t545 [ 415ULL ] = X [ 8ULL ] ; t545 [ 416ULL ] =
Electrical_Cooling_System_Tank_Tank_level ; t545 [ 417ULL ] = - t787 ; t545 [
418ULL ] = - t788 ; t545 [ 419ULL ] = X [ 7ULL ] ; t545 [ 420ULL ] = X [ 8ULL
] ; t545 [ 421ULL ] = Electrical_Cooling_System_Tank_Tank_level * 0.005 ;
t545 [ 422ULL ] = Electrical_Cooling_System_Tank_Tank_level ; t545 [ 423ULL ]
= X [ 14ULL ] ; t545 [ 424ULL ] = X [ 15ULL ] * 0.1 ; t545 [ 425ULL ] = X [
15ULL ] * 0.1 ; t545 [ 426ULL ] = X [ 161ULL ] ; t545 [ 427ULL ] = X [ 164ULL
] ; t545 [ 428ULL ] = X [ 158ULL ] * 0.001 ; t545 [ 429ULL ] =
Electrical_Cooling_System_Tank_Tank_level * 0.005 ; t545 [ 430ULL ] = X [
5ULL ] ; t545 [ 431ULL ] = X [ 10ULL ] ; t545 [ 432ULL ] = X [ 5ULL ] ; t545
[ 433ULL ] = X [ 10ULL ] ; t545 [ 434ULL ] = X [ 168ULL ] * 1000.0 ; t545 [
435ULL ] = X [ 168ULL ] * 0.5372318754156804 ; t545 [ 436ULL ] = X [ 10ULL ]
; t545 [ 437ULL ] = X [ 10ULL ] ; t545 [ 438ULL ] = X [ 127ULL ] * 1000.0 ;
t545 [ 439ULL ] = X [ 127ULL ] * 1000.0 ; t545 [ 440ULL ] = X [ 127ULL ] *
1000.0 ; t545 [ 441ULL ] = X [ 10ULL ] ; t545 [ 442ULL ] = X [ 10ULL ] ; t545
[ 443ULL ] = X [ 10ULL ] ; t545 [ 444ULL ] = X [ 10ULL ] ; t545 [ 445ULL ] =
( - X [ 127ULL ] + X [ 168ULL ] ) * 1000.0 ; t545 [ 446ULL ] = X [ 10ULL ] ;
t545 [ 447ULL ] = X [ 13ULL ] ; t545 [ 448ULL ] = X [ 12ULL ] ; t545 [ 449ULL
] = X [ 16ULL ] ; t545 [ 450ULL ] = X [ 16ULL ] ; t545 [ 451ULL ] = X [ 12ULL
] ; t545 [ 452ULL ] = X [ 12ULL ] ; t545 [ 453ULL ] = X [ 132ULL ] * 1000.0 ;
t545 [ 454ULL ] = X [ 132ULL ] * 1000.0 ; t545 [ 455ULL ] = X [ 132ULL ] *
1000.0 ; t545 [ 456ULL ] = X [ 12ULL ] ; t545 [ 457ULL ] = X [ 16ULL ] ; t545
[ 458ULL ] = X [ 169ULL ] * 1000.0 ; t545 [ 459ULL ] = X [ 169ULL ] *
0.28663972253274855 ; t545 [ 460ULL ] = X [ 16ULL ] ; t545 [ 461ULL ] = X [
16ULL ] ; t545 [ 462ULL ] = X [ 169ULL ] * 1000.0 ; t545 [ 463ULL ] = X [
16ULL ] ; t545 [ 464ULL ] = X [ 12ULL ] ; t545 [ 465ULL ] = X [ 12ULL ] ;
t545 [ 466ULL ] = ( ( ( X [ 12ULL ] * - 0.89999999999999991 + X [ 17ULL ] *
0.89999999999999991 ) - X [ 132ULL ] ) - X [ 169ULL ] ) * 1000.0 ; t545 [
467ULL ] = X [ 12ULL ] ; t545 [ 468ULL ] = X [ 17ULL ] ; t545 [ 469ULL ] = X
[ 13ULL ] ; t545 [ 470ULL ] = X [ 170ULL ] * 1000.0 ; t545 [ 471ULL ] = X [
170ULL ] * 0.9967088673201091 ; t545 [ 472ULL ] = X [ 12ULL ] ; t545 [ 473ULL
] = X [ 17ULL ] ; t545 [ 474ULL ] =
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co * 1000.0 ;
t545 [ 475ULL ] =
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co *
1.1111111111111112 ; t545 [ 476ULL ] = X [ 17ULL ] ; t545 [ 477ULL ] = X [
17ULL ] ; t545 [ 478ULL ] = ( ( X [ 12ULL ] * 0.89999999999999991 + X [ 17ULL
] * - 0.89999999999999991 ) - X [ 170ULL ] ) * 1000.0 ; t545 [ 479ULL ] = X [
17ULL ] ; t545 [ 480ULL ] = X [ 137ULL ] ; t545 [ 481ULL ] = X [ 138ULL ] *
0.1 ; t545 [ 482ULL ] = X [ 92ULL ] ; t545 [ 483ULL ] = X [ 93ULL ] * 0.1 ;
t545 [ 484ULL ] = X [ 92ULL ] ; t545 [ 485ULL ] = X [ 93ULL ] * 0.1 ; t545 [
486ULL ] = X [ 92ULL ] ; t545 [ 487ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 488ULL
] = X [ 92ULL ] ; t545 [ 489ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 490ULL ] =
U_idx_2 ; t545 [ 491ULL ] = X [ 96ULL ] * 1000.0 ; t545 [ 492ULL ] = X [
96ULL ] ; t545 [ 493ULL ] = U_idx_2 ; t545 [ 494ULL ] = U_idx_2 ; t545 [
495ULL ] = X [ 96ULL ] * 1000.0 ; t545 [ 496ULL ] = X [ 92ULL ] ; t545 [
497ULL ] = X [ 93ULL ] * 0.1 ; t545 [ 498ULL ] =
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 * 0.001 ;
t545 [ 499ULL ] = t793 ; t545 [ 500ULL ] = t794 ; t545 [ 501ULL ] =
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 * 0.001 ;
t545 [ 502ULL ] = t794 ; t545 [ 503ULL ] = X [ 101ULL ] ; t545 [ 504ULL ] = X
[ 102ULL ] * 0.1 ; t545 [ 505ULL ] = X [ 101ULL ] ; t545 [ 506ULL ] = X [
102ULL ] * 0.1 ; t545 [ 507ULL ] = X [ 101ULL ] ; t545 [ 508ULL ] = X [
102ULL ] * 0.1 ; t545 [ 509ULL ] = X [ 101ULL ] ; t545 [ 510ULL ] = X [
102ULL ] * 0.1 ; t545 [ 511ULL ] = U_idx_2 ; t545 [ 512ULL ] = X [ 105ULL ] *
1000.0 ; t545 [ 513ULL ] = X [ 105ULL ] ; t545 [ 514ULL ] = U_idx_2 ; t545 [
515ULL ] = U_idx_2 ; t545 [ 516ULL ] = X [ 105ULL ] * 1000.0 ; t545 [ 517ULL
] = X [ 101ULL ] ; t545 [ 518ULL ] = X [ 102ULL ] * 0.1 ; t545 [ 519ULL ] = X
[ 102ULL ] * 99999.999999999985 ; t545 [ 520ULL ] = X [ 101ULL ] ; t545 [
521ULL ] = X [ 101ULL ] ; t545 [ 522ULL ] = X [ 101ULL ] ; t545 [ 523ULL ] =
X [ 102ULL ] * 0.1 ; t545 [ 524ULL ] = t797 * 0.001 ; t545 [ 525ULL ] = t798
; t545 [ 526ULL ] = t799 ; t545 [ 527ULL ] = t799 ; t545 [ 528ULL ] = X [
110ULL ] ; t545 [ 529ULL ] = X [ 111ULL ] * 0.1 ; t545 [ 530ULL ] = X [
110ULL ] ; t545 [ 531ULL ] = X [ 111ULL ] * 0.1 ; t545 [ 532ULL ] = X [
110ULL ] ; t545 [ 533ULL ] = X [ 111ULL ] * 0.1 ; t545 [ 534ULL ] = X [
110ULL ] ; t545 [ 535ULL ] = X [ 111ULL ] * 0.1 ; t545 [ 536ULL ] = U_idx_2 ;
t545 [ 537ULL ] = X [ 114ULL ] * 1000.0 ; t545 [ 538ULL ] = X [ 114ULL ] ;
t545 [ 539ULL ] = U_idx_2 ; t545 [ 540ULL ] = U_idx_2 ; t545 [ 541ULL ] = X [
114ULL ] * 1000.0 ; t545 [ 542ULL ] = X [ 110ULL ] ; t545 [ 543ULL ] = X [
111ULL ] * 0.1 ; t545 [ 544ULL ] = X [ 111ULL ] * 99999.999999999985 ; t545 [
545ULL ] = X [ 110ULL ] ; t545 [ 546ULL ] = X [ 110ULL ] ; t545 [ 547ULL ] =
X [ 111ULL ] * 0.1 ; t545 [ 548ULL ] = t802 * 0.001 ; t545 [ 549ULL ] = t803
; t545 [ 550ULL ] = t804 ; t545 [ 551ULL ] = t804 ; t545 [ 552ULL ] = X [
119ULL ] ; t545 [ 553ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 554ULL ] = X [
119ULL ] ; t545 [ 555ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 556ULL ] = X [
119ULL ] ; t545 [ 557ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 558ULL ] = X [
119ULL ] ; t545 [ 559ULL ] = X [ 120ULL ] * 0.1 ; t545 [ 560ULL ] = U_idx_2 ;
t545 [ 561ULL ] = X [ 121ULL ] * - 1000.0 ; t545 [ 562ULL ] = - X [ 121ULL ]
; t545 [ 563ULL ] = U_idx_2 ; t545 [ 564ULL ] = U_idx_2 ; t545 [ 565ULL ] = X
[ 121ULL ] * - 1000.0 ; t545 [ 566ULL ] = X [ 119ULL ] ; t545 [ 567ULL ] = X
[ 120ULL ] * 0.1 ; t545 [ 568ULL ] = X [ 120ULL ] * 99999.999999999985 ; t545
[ 569ULL ] = X [ 119ULL ] ; t545 [ 570ULL ] = X [ 119ULL ] ; t545 [ 571ULL ]
= X [ 120ULL ] * 0.1 ; t545 [ 572ULL ] = t805 * 0.001 ; t545 [ 573ULL ] =
t806 ; t545 [ 574ULL ] = t807 ; t545 [ 575ULL ] = t807 ; t545 [ 576ULL ] =
t808 ; t545 [ 577ULL ] = X [ 89ULL ] ; t545 [ 578ULL ] = X [ 89ULL ] ; t545 [
579ULL ] = X [ 18ULL ] ; t545 [ 580ULL ] = t808 * t808 * 0.01 ; t545 [ 581ULL
] = X [ 171ULL ] ; t545 [ 582ULL ] = U_idx_13 ; t545 [ 583ULL ] =
Fuel_Cell_Boost_Converter_L_i ; t545 [ 584ULL ] =
Fuel_Cell_Boost_Converter_L_n_v ; t545 [ 585ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 586ULL ] = X [ 172ULL ] ; t545 [
587ULL ] = X [ 19ULL ] ; t545 [ 588ULL ] = X [ 172ULL ] * X [ 172ULL ] *
1.0000000000000002E-12 ; t545 [ 589ULL ] = Fuel_Cell_Boost_Converter_L_n_v ;
t545 [ 590ULL ] = Fuel_Cell_Boost_Converter_i2 ; t545 [ 591ULL ] = X [ 19ULL
] ; t545 [ 592ULL ] = Fuel_Cell_Boost_Converter_L_i ; t545 [ 593ULL ] =
Fuel_Cell_Boost_Converter_L_i ; t545 [ 594ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 595ULL ] = X [ 89ULL ] ; t545 [
596ULL ] = Fuel_Cell_Boost_Converter_L_n_v * Fuel_Cell_Boost_Converter_i2 + (
Fuel_Cell_Boost_Converter_L_n_v - X [ 171ULL ] ) * (
Fuel_Cell_Boost_Converter_L_i - Fuel_Cell_Boost_Converter_i2 ) ; t545 [
597ULL ] = X [ 18ULL ] ; t545 [ 598ULL ] = Fuel_Cell_Current_Sensor1_I ; t545
[ 599ULL ] = Fuel_Cell_Current_Sensor1_I ; t545 [ 600ULL ] = X [ 89ULL ] ;
t545 [ 601ULL ] = X [ 89ULL ] ; t545 [ 602ULL ] = Fuel_Cell_Current_Sensor1_I
; t545 [ 603ULL ] = X [ 175ULL ] ; t545 [ 604ULL ] = X [ 176ULL ] * 0.1 ;
t545 [ 605ULL ] = X [ 177ULL ] ; t545 [ 606ULL ] = X [ 178ULL ] ; t545 [
607ULL ] = X [ 179ULL ] ; t545 [ 608ULL ] = - 184.19157727996955 + piece23 *
1000.0 ; t545 [ 609ULL ] = ( X [ 179ULL ] * 0.00062831853071795862 -
0.18419157727996954 ) * 1591.5494309189535 ; t545 [ 610ULL ] = X [ 180ULL ] ;
t545 [ 611ULL ] = X [ 181ULL ] ; t545 [ 612ULL ] = X [ 182ULL ] ; t545 [
613ULL ] = X [ 183ULL ] ; t545 [ 614ULL ] = X [ 184ULL ] ; t545 [ 615ULL ] =
X [ 192ULL ] ; t545 [ 616ULL ] = X [ 191ULL ] ; t545 [ 617ULL ] = X [ 180ULL
] ; t545 [ 618ULL ] = X [ 181ULL ] ; t545 [ 619ULL ] = X [ 182ULL ] ; t545 [
620ULL ] = X [ 184ULL ] ; t545 [ 621ULL ] = X [ 185ULL ] ; t545 [ 622ULL ] =
X [ 186ULL ] ; t545 [ 623ULL ] = X [ 187ULL ] ; t545 [ 624ULL ] = X [ 188ULL
] ; t545 [ 625ULL ] = X [ 189ULL ] ; t545 [ 626ULL ] = X [ 190ULL ] ; t545 [
627ULL ] = t823 ; t545 [ 628ULL ] = X [ 186ULL ] ; t545 [ 629ULL ] = X [
187ULL ] ; t545 [ 630ULL ] = X [ 188ULL ] ; t545 [ 631ULL ] = 1.01325 / (
t809 == 0.0 ? 1.0E-16 : t809 ) ; t545 [ 632ULL ] = ( 1.0 - X [ 191ULL ] ) - X
[ 192ULL ] ; t545 [ 633ULL ] = X [ 193ULL ] ; t545 [ 634ULL ] = -
184.19157727996955 + piece23 * 1000.0 ; t545 [ 635ULL ] = U_idx_3 ; t545 [
636ULL ] = U_idx_3 * 3.1415926535897929E-6 ; t545 [ 637ULL ] = X [ 175ULL ] ;
t545 [ 638ULL ] = X [ 176ULL ] * 0.1 ; t545 [ 639ULL ] = X [ 177ULL ] ; t545
[ 640ULL ] = X [ 178ULL ] ; t545 [ 641ULL ] = X [ 194ULL ] ; t545 [ 642ULL ]
= X [ 195ULL ] * 0.1 ; t545 [ 643ULL ] = X [ 196ULL ] ; t545 [ 644ULL ] = X [
197ULL ] ; t545 [ 645ULL ] = X [ 24ULL ] ; t545 [ 646ULL ] = X [ 202ULL ] ;
t545 [ 647ULL ] = X [ 23ULL ] ; t545 [ 648ULL ] = X [ 199ULL ] ; t545 [
649ULL ] = X [ 21ULL ] - 273.15 ; t545 [ 650ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t545 [
651ULL ] = X [ 200ULL ] * 0.1 ; t545 [ 652ULL ] = X [ 22ULL ] * 0.1 ; t545 [
653ULL ] = X [ 201ULL ] ; t545 [ 654ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh * 100000.0 ;
t545 [ 655ULL ] = X [ 203ULL ] ; t545 [ 656ULL ] = - X [ 186ULL ] ; t545 [
657ULL ] = X [ 204ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) {
t545 [ t692 + 658ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ t692 ] ; }
t545 [ 666ULL ] = X [ 179ULL ] ; t545 [ 667ULL ] = X [ 205ULL ] ; t545 [
668ULL ] = t890 ; t545 [ 669ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ; t545 [
670ULL ] = - X [ 184ULL ] ; t545 [ 671ULL ] = 0.18419157727996954 - piece23 ;
t545 [ 672ULL ] = X [ 206ULL ] ; t545 [ 673ULL ] = X [ 21ULL ] ; t545 [
674ULL ] = X [ 24ULL ] ; t545 [ 675ULL ] = X [ 23ULL ] ; t545 [ 676ULL ] =
t714 ; t545 [ 677ULL ] = X [ 175ULL ] ; t545 [ 678ULL ] = X [ 176ULL ] * 0.1
; t545 [ 679ULL ] = X [ 177ULL ] ; t545 [ 680ULL ] = X [ 178ULL ] ; t545 [
681ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_m1 ;
t545 [ 682ULL ] = X [ 209ULL ] ; t545 [ 683ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t545 [
684ULL ] = t812 ; t545 [ 685ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ; t545 [
686ULL ] = X [ 214ULL ] ; t545 [ 687ULL ] = X [ 215ULL ] ; t545 [ 688ULL ] =
X [ 194ULL ] ; t545 [ 689ULL ] = X [ 195ULL ] * 0.1 ; t545 [ 690ULL ] = X [
196ULL ] ; t545 [ 691ULL ] = X [ 197ULL ] ; t545 [ 692ULL ] = - X [ 184ULL ]
; t545 [ 693ULL ] = X [ 216ULL ] ; t545 [ 694ULL ] = - X [ 186ULL ] ; t545 [
695ULL ] = - X [ 187ULL ] ; t545 [ 696ULL ] = - X [ 188ULL ] ; t545 [ 697ULL
] = X [ 217ULL ] ; t545 [ 698ULL ] = X [ 218ULL ] ; t545 [ 699ULL ] = t816 ;
t545 [ 700ULL ] = t812 ; t545 [ 701ULL ] = - X [ 187ULL ] ; t545 [ 702ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c5 ; t545 [
703ULL ] = - X [ 188ULL ] ; t545 [ 704ULL ] = ( 1.0 - X [ 23ULL ] ) - X [
24ULL ] ; t545 [ 705ULL ] = X [ 194ULL ] ; t545 [ 706ULL ] = X [ 195ULL ] *
0.1 ; t545 [ 707ULL ] = X [ 196ULL ] ; t545 [ 708ULL ] = X [ 197ULL ] ; t545
[ 709ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va0 *
0.0001 ; t545 [ 710ULL ] = X [ 180ULL ] ; t545 [ 711ULL ] = X [ 181ULL ] ;
t545 [ 712ULL ] = X [ 182ULL ] ; t545 [ 713ULL ] = X [ 186ULL ] ; t545 [
714ULL ] = X [ 194ULL ] ; t545 [ 715ULL ] = X [ 195ULL ] * 0.1 ; t545 [
716ULL ] = X [ 196ULL ] ; t545 [ 717ULL ] = X [ 197ULL ] ; t545 [ 718ULL ] =
X [ 184ULL ] ; t545 [ 719ULL ] = X [ 225ULL ] ; t545 [ 720ULL ] = X [ 186ULL
] ; t545 [ 721ULL ] = X [ 187ULL ] ; t545 [ 722ULL ] = X [ 188ULL ] ; t545 [
723ULL ] = X [ 222ULL ] ; t545 [ 724ULL ] = X [ 221ULL ] ; t545 [ 725ULL ] =
X [ 219ULL ] ; t545 [ 726ULL ] = X [ 220ULL ] * 0.1 ; t545 [ 727ULL ] = X [
223ULL ] ; t545 [ 728ULL ] = X [ 224ULL ] ; t545 [ 729ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Purge_Va10 ; t545 [
730ULL ] = X [ 184ULL ] ; t545 [ 731ULL ] = - X [ 184ULL ] ; t545 [ 732ULL ]
= X [ 180ULL ] ; t545 [ 733ULL ] = X [ 181ULL ] ; t545 [ 734ULL ] = X [
182ULL ] ; t545 [ 735ULL ] = - X [ 184ULL ] ; t545 [ 736ULL ] = X [ 225ULL ]
; t545 [ 737ULL ] = - X [ 186ULL ] ; t545 [ 738ULL ] = - X [ 187ULL ] ; t545
[ 739ULL ] = - X [ 188ULL ] ; t545 [ 740ULL ] = X [ 222ULL ] ; t545 [ 741ULL
] = X [ 221ULL ] ; t545 [ 742ULL ] = - X [ 186ULL ] ; t545 [ 743ULL ] = X [
187ULL ] ; t545 [ 744ULL ] = - X [ 187ULL ] ; t545 [ 745ULL ] = X [ 188ULL ]
; t545 [ 746ULL ] = - X [ 188ULL ] ; t545 [ 747ULL ] = U_idx_3 ; t545 [
748ULL ] = X [ 226ULL ] ; t545 [ 749ULL ] = X [ 227ULL ] * 0.1 ; t545 [
750ULL ] = X [ 228ULL ] ; t545 [ 751ULL ] = X [ 229ULL ] ; for ( t692 = 0ULL
; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 752ULL ] = t576 [ t692 ] ; } for (
t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 760ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t692 ] ; }
t545 [ 768ULL ] = X [ 32ULL ] ; t545 [ 769ULL ] = X [ 240ULL ] ; t545 [
770ULL ] = X [ 241ULL ] * 0.1 ; t545 [ 771ULL ] = X [ 242ULL ] ; t545 [
772ULL ] = X [ 243ULL ] ; t545 [ 773ULL ] = X [ 226ULL ] ; t545 [ 774ULL ] =
X [ 227ULL ] * 0.1 ; t545 [ 775ULL ] = X [ 228ULL ] ; t545 [ 776ULL ] = X [
229ULL ] ; t545 [ 777ULL ] = X [ 26ULL ] ; t545 [ 778ULL ] = X [ 234ULL ] ;
t545 [ 779ULL ] = X [ 27ULL ] ; t545 [ 780ULL ] = X [ 245ULL ] ; t545 [
781ULL ] = X [ 25ULL ] - 273.15 ; t545 [ 782ULL ] = X [ 244ULL ] ; t545 [
783ULL ] = X [ 246ULL ] * 0.1 ; t545 [ 784ULL ] = X [ 31ULL ] * 0.1 ; t545 [
785ULL ] = X [ 232ULL ] ; t545 [ 786ULL ] = t821 * 100000.0 ; t545 [ 787ULL ]
= X [ 248ULL ] ; t545 [ 788ULL ] = X [ 247ULL ] ; t545 [ 789ULL ] = X [
249ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
790ULL ] = t576 [ t692 ] ; } t545 [ 798ULL ] = X [ 32ULL ] ; t545 [ 799ULL ]
= X [ 233ULL ] ; t545 [ 800ULL ] = intrm_sf_mf_19 ; t545 [ 801ULL ] = X [
250ULL ] ; t545 [ 802ULL ] = X [ 251ULL ] ; t545 [ 803ULL ] = X [ 252ULL ] ;
t545 [ 804ULL ] = X [ 231ULL ] ; t545 [ 805ULL ] = X [ 25ULL ] ; t545 [
806ULL ] = X [ 26ULL ] ; t545 [ 807ULL ] = X [ 27ULL ] ; t545 [ 808ULL ] =
t723 ; t545 [ 809ULL ] = X [ 240ULL ] ; t545 [ 810ULL ] = X [ 241ULL ] * 0.1
; t545 [ 811ULL ] = X [ 242ULL ] ; t545 [ 812ULL ] = X [ 243ULL ] ; t545 [
813ULL ] = X [ 250ULL ] ; t545 [ 814ULL ] = X [ 253ULL ] ; t545 [ 815ULL ] =
X [ 244ULL ] ; t545 [ 816ULL ] = X [ 254ULL ] ; t545 [ 817ULL ] = X [ 255ULL
] ; t545 [ 818ULL ] = X [ 256ULL ] ; t545 [ 819ULL ] = X [ 257ULL ] ; t545 [
820ULL ] = X [ 226ULL ] ; t545 [ 821ULL ] = X [ 227ULL ] * 0.1 ; t545 [
822ULL ] = X [ 228ULL ] ; t545 [ 823ULL ] = X [ 229ULL ] ; t545 [ 824ULL ] =
X [ 251ULL ] ; t545 [ 825ULL ] = X [ 258ULL ] ; t545 [ 826ULL ] = X [ 247ULL
] ; t545 [ 827ULL ] = X [ 259ULL ] ; t545 [ 828ULL ] = X [ 260ULL ] ; t545 [
829ULL ] = X [ 261ULL ] ; t545 [ 830ULL ] = X [ 262ULL ] ; t545 [ 831ULL ] =
t828 ; t545 [ 832ULL ] = X [ 254ULL ] ; t545 [ 833ULL ] = X [ 259ULL ] ; t545
[ 834ULL ] = X [ 255ULL ] ; t545 [ 835ULL ] = X [ 260ULL ] ; t545 [ 836ULL ]
= ( 1.0 - X [ 27ULL ] ) - X [ 26ULL ] ; t545 [ 837ULL ] = X [ 226ULL ] ; t545
[ 838ULL ] = X [ 227ULL ] * 0.1 ; t545 [ 839ULL ] = X [ 228ULL ] ; t545 [
840ULL ] = X [ 229ULL ] ; t545 [ 841ULL ] = X [ 175ULL ] ; t545 [ 842ULL ] =
X [ 176ULL ] * 0.1 ; t545 [ 843ULL ] = X [ 177ULL ] ; t545 [ 844ULL ] = X [
178ULL ] ; t545 [ 845ULL ] = X [ 29ULL ] ; t545 [ 846ULL ] = X [ 239ULL ] ;
t545 [ 847ULL ] = X [ 30ULL ] ; t545 [ 848ULL ] = X [ 263ULL ] ; t545 [
849ULL ] = X [ 28ULL ] - 273.15 ; t545 [ 850ULL ] = - X [ 247ULL ] ; t545 [
851ULL ] = X [ 264ULL ] * 0.1 ; t545 [ 852ULL ] = X [ 33ULL ] * 0.1 ; t545 [
853ULL ] = X [ 237ULL ] ; t545 [ 854ULL ] = t831 * 100000.0 ; t545 [ 855ULL ]
= X [ 265ULL ] ; t545 [ 856ULL ] = X [ 198ULL ] ; t545 [ 857ULL ] = X [
266ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
858ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
t692 ] ; } t545 [ 866ULL ] = X [ 32ULL ] ; t545 [ 867ULL ] = X [ 238ULL ] ;
t545 [ 868ULL ] = t874 ; t545 [ 869ULL ] = - X [ 251ULL ] ; t545 [ 870ULL ] =
X [ 207ULL ] ; t545 [ 871ULL ] = - X [ 267ULL ] - X [ 268ULL ] ; t545 [
872ULL ] = X [ 269ULL ] ; t545 [ 873ULL ] = X [ 236ULL ] ; t545 [ 874ULL ] =
X [ 28ULL ] ; t545 [ 875ULL ] = X [ 29ULL ] ; t545 [ 876ULL ] = X [ 30ULL ] ;
t545 [ 877ULL ] = t835 ; t545 [ 878ULL ] = X [ 226ULL ] ; t545 [ 879ULL ] = X
[ 227ULL ] * 0.1 ; t545 [ 880ULL ] = X [ 228ULL ] ; t545 [ 881ULL ] = X [
229ULL ] ; t545 [ 882ULL ] = - X [ 251ULL ] ; t545 [ 883ULL ] = X [ 270ULL ]
; t545 [ 884ULL ] = - X [ 247ULL ] ; t545 [ 885ULL ] = - X [ 259ULL ] ; t545
[ 886ULL ] = - X [ 260ULL ] ; t545 [ 887ULL ] = X [ 271ULL ] ; t545 [ 888ULL
] = X [ 272ULL ] ; t545 [ 889ULL ] = X [ 175ULL ] ; t545 [ 890ULL ] = X [
176ULL ] * 0.1 ; t545 [ 891ULL ] = X [ 177ULL ] ; t545 [ 892ULL ] = X [
178ULL ] ; t545 [ 893ULL ] = X [ 207ULL ] ; t545 [ 894ULL ] = X [ 273ULL ] ;
t545 [ 895ULL ] = X [ 198ULL ] ; t545 [ 896ULL ] = X [ 210ULL ] ; t545 [
897ULL ] = X [ 212ULL ] ; t545 [ 898ULL ] = X [ 274ULL ] ; t545 [ 899ULL ] =
X [ 275ULL ] ; t545 [ 900ULL ] = t839 ; t545 [ 901ULL ] = - X [ 259ULL ] ;
t545 [ 902ULL ] = X [ 210ULL ] ; t545 [ 903ULL ] = X [ 276ULL ] ; t545 [
904ULL ] = X [ 277ULL ] ; t545 [ 905ULL ] = - X [ 260ULL ] ; t545 [ 906ULL ]
= X [ 212ULL ] ; t545 [ 907ULL ] = ( 1.0 - X [ 30ULL ] ) - X [ 29ULL ] ; t545
[ 908ULL ] = X [ 28ULL ] ; t545 [ 909ULL ] = X [ 29ULL ] ; t545 [ 910ULL ] =
X [ 30ULL ] ; t545 [ 911ULL ] = X [ 240ULL ] ; t545 [ 912ULL ] = X [ 241ULL ]
* 0.1 ; t545 [ 913ULL ] = X [ 242ULL ] ; t545 [ 914ULL ] = X [ 243ULL ] ;
t545 [ 915ULL ] = X [ 175ULL ] ; t545 [ 916ULL ] = X [ 176ULL ] * 0.1 ; t545
[ 917ULL ] = X [ 177ULL ] ; t545 [ 918ULL ] = X [ 178ULL ] ; t545 [ 919ULL ]
= X [ 278ULL ] ; t545 [ 920ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 921ULL ] = X [
279ULL ] ; t545 [ 922ULL ] = X [ 280ULL ] ; t545 [ 923ULL ] = X [ 240ULL ] ;
t545 [ 924ULL ] = X [ 241ULL ] * 0.1 ; t545 [ 925ULL ] = X [ 242ULL ] ; t545
[ 926ULL ] = X [ 243ULL ] ; t545 [ 927ULL ] = U_idx_5 ; t545 [ 928ULL ] = X [
281ULL ] ; t545 [ 929ULL ] = X [ 34ULL ] ; t545 [ 930ULL ] = X [ 35ULL ] ;
t545 [ 931ULL ] = X [ 36ULL ] ; t545 [ 932ULL ] = U_idx_6 ; t545 [ 933ULL ] =
- U_idx_5 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
934ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [
t692 ] ; } t545 [ 942ULL ] = X [ 284ULL ] ; t545 [ 943ULL ] = X [ 286ULL ] *
1.0E-5 * 99999.999999999985 ; t545 [ 944ULL ] = X [ 34ULL ] ; t545 [ 945ULL ]
= X [ 283ULL ] ; t545 [ 946ULL ] = X [ 283ULL ] ; t545 [ 947ULL ] = X [
287ULL ] ; t545 [ 948ULL ] = X [ 287ULL ] ; t545 [ 949ULL ] = X [ 278ULL ] ;
t545 [ 950ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 951ULL ] = X [ 279ULL ] ; t545 [
952ULL ] = X [ 280ULL ] ; t545 [ 953ULL ] = X [ 240ULL ] ; t545 [ 954ULL ] =
X [ 241ULL ] * 0.1 ; t545 [ 955ULL ] = X [ 242ULL ] ; t545 [ 956ULL ] = X [
243ULL ] ; t545 [ 957ULL ] = X [ 35ULL ] ; t545 [ 958ULL ] = X [ 284ULL ] ;
t545 [ 959ULL ] = X [ 36ULL ] ; t545 [ 960ULL ] = X [ 289ULL ] ; t545 [
961ULL ] = X [ 34ULL ] - 273.15 ; t545 [ 962ULL ] = X [ 288ULL ] ; t545 [
963ULL ] = X [ 290ULL ] * 0.1 ; t545 [ 964ULL ] = X [ 37ULL ] * 0.1 ; t545 [
965ULL ] = X [ 285ULL ] ; t545 [ 966ULL ] = t844 * 100000.0 ; t545 [ 967ULL ]
= X [ 291ULL ] ; t545 [ 968ULL ] = - X [ 244ULL ] ; t545 [ 969ULL ] = X [
292ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
970ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [
t692 ] ; } t545 [ 978ULL ] = X [ 287ULL ] ; t545 [ 979ULL ] = X [ 282ULL ] ;
t545 [ 980ULL ] = t980 ; t545 [ 981ULL ] = X [ 293ULL ] ; t545 [ 982ULL ] = -
X [ 250ULL ] ; t545 [ 983ULL ] = - X [ 281ULL ] ; t545 [ 984ULL ] = X [
283ULL ] ; t545 [ 985ULL ] = X [ 34ULL ] ; t545 [ 986ULL ] = X [ 35ULL ] ;
t545 [ 987ULL ] = X [ 36ULL ] ; t545 [ 988ULL ] = t846 ; t545 [ 989ULL ] = X
[ 278ULL ] ; t545 [ 990ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 991ULL ] = X [
279ULL ] ; t545 [ 992ULL ] = X [ 280ULL ] ; t545 [ 993ULL ] = X [ 293ULL ] ;
t545 [ 994ULL ] = X [ 294ULL ] ; t545 [ 995ULL ] = X [ 288ULL ] ; t545 [
996ULL ] = X [ 295ULL ] ; t545 [ 997ULL ] = X [ 296ULL ] ; t545 [ 998ULL ] =
X [ 297ULL ] ; t545 [ 999ULL ] = X [ 298ULL ] ; t545 [ 1000ULL ] = X [ 240ULL
] ; t545 [ 1001ULL ] = X [ 241ULL ] * 0.1 ; t545 [ 1002ULL ] = X [ 242ULL ] ;
t545 [ 1003ULL ] = X [ 243ULL ] ; t545 [ 1004ULL ] = - X [ 250ULL ] ; t545 [
1005ULL ] = X [ 299ULL ] ; t545 [ 1006ULL ] = - X [ 244ULL ] ; t545 [ 1007ULL
] = - X [ 254ULL ] ; t545 [ 1008ULL ] = - X [ 255ULL ] ; t545 [ 1009ULL ] = X
[ 300ULL ] ; t545 [ 1010ULL ] = X [ 301ULL ] ; t545 [ 1011ULL ] = t849 ; t545
[ 1012ULL ] = X [ 295ULL ] ; t545 [ 1013ULL ] = - X [ 254ULL ] ; t545 [
1014ULL ] = U_idx_5 ; t545 [ 1015ULL ] = X [ 296ULL ] ; t545 [ 1016ULL ] = -
X [ 255ULL ] ; t545 [ 1017ULL ] = ( 1.0 - X [ 36ULL ] ) - X [ 35ULL ] ; t545
[ 1018ULL ] = U_idx_6 ; t545 [ 1019ULL ] = U_idx_5 ; t545 [ 1020ULL ] = X [
302ULL ] ; t545 [ 1021ULL ] = X [ 303ULL ] * 0.1 ; t545 [ 1022ULL ] = X [
304ULL ] ; t545 [ 1023ULL ] = X [ 305ULL ] ; t545 [ 1024ULL ] = X [ 306ULL ]
; t545 [ 1025ULL ] = - 920.95788639984789 + piece99 * 1000.0 ; t545 [ 1026ULL
] = ( X [ 306ULL ] * 0.0031415926535897937 - 0.92095788639984788 ) *
318.30988618379064 ; t545 [ 1027ULL ] = X [ 307ULL ] ; t545 [ 1028ULL ] = X [
308ULL ] ; t545 [ 1029ULL ] = X [ 309ULL ] ; t545 [ 1030ULL ] = X [ 310ULL ]
; t545 [ 1031ULL ] = X [ 311ULL ] ; t545 [ 1032ULL ] = X [ 319ULL ] ; t545 [
1033ULL ] = X [ 318ULL ] ; t545 [ 1034ULL ] = X [ 307ULL ] ; t545 [ 1035ULL ]
= X [ 308ULL ] ; t545 [ 1036ULL ] = X [ 309ULL ] ; t545 [ 1037ULL ] = X [
311ULL ] ; t545 [ 1038ULL ] = X [ 312ULL ] ; t545 [ 1039ULL ] = X [ 313ULL ]
; t545 [ 1040ULL ] = X [ 314ULL ] ; t545 [ 1041ULL ] = X [ 315ULL ] ; t545 [
1042ULL ] = X [ 316ULL ] ; t545 [ 1043ULL ] = X [ 317ULL ] ; t545 [ 1044ULL ]
= intrm_sf_mf_691 ; t545 [ 1045ULL ] = X [ 313ULL ] ; t545 [ 1046ULL ] = X [
314ULL ] ; t545 [ 1047ULL ] = X [ 315ULL ] ; t545 [ 1048ULL ] = t848 ; t545 [
1049ULL ] = ( 1.0 - X [ 318ULL ] ) - X [ 319ULL ] ; t545 [ 1050ULL ] = X [
320ULL ] ; t545 [ 1051ULL ] = - 920.95788639984789 + piece99 * 1000.0 ; t545
[ 1052ULL ] = X [ 302ULL ] ; t545 [ 1053ULL ] = X [ 303ULL ] * 0.1 ; t545 [
1054ULL ] = X [ 304ULL ] ; t545 [ 1055ULL ] = X [ 305ULL ] ; t545 [ 1056ULL ]
= X [ 321ULL ] ; t545 [ 1057ULL ] = t851 * 0.1 ; t545 [ 1058ULL ] = X [
323ULL ] ; t545 [ 1059ULL ] = X [ 324ULL ] ; t545 [ 1060ULL ] = X [ 42ULL ] ;
t545 [ 1061ULL ] = X [ 329ULL ] ; t545 [ 1062ULL ] = X [ 41ULL ] ; t545 [
1063ULL ] = X [ 326ULL ] ; t545 [ 1064ULL ] = X [ 39ULL ] - 273.15 ; t545 [
1065ULL ] = X [ 325ULL ] ; t545 [ 1066ULL ] = X [ 327ULL ] * 0.1 ; t545 [
1067ULL ] = X [ 40ULL ] * 0.1 ; t545 [ 1068ULL ] = X [ 328ULL ] ; t545 [
1069ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M43 *
100000.0 ; t545 [ 1070ULL ] = X [ 330ULL ] ; t545 [ 1071ULL ] = - X [ 313ULL
] ; t545 [ 1072ULL ] = X [ 331ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ;
t692 ++ ) { t545 [ t692 + 1073ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ t692 ] ; }
t545 [ 1081ULL ] = X [ 306ULL ] ; t545 [ 1082ULL ] = X [ 332ULL ] ; t545 [
1083ULL ] = intrm_sf_mf_724 ; t545 [ 1084ULL ] = X [ 334ULL ] ; t545 [
1085ULL ] = - X [ 311ULL ] ; t545 [ 1086ULL ] = 0.92095788639984788 - piece99
; t545 [ 1087ULL ] = X [ 333ULL ] ; t545 [ 1088ULL ] = X [ 39ULL ] ; t545 [
1089ULL ] = X [ 42ULL ] ; t545 [ 1090ULL ] = X [ 41ULL ] ; t545 [ 1091ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M40 ; t545 [
1092ULL ] = X [ 302ULL ] ; t545 [ 1093ULL ] = X [ 303ULL ] * 0.1 ; t545 [
1094ULL ] = X [ 304ULL ] ; t545 [ 1095ULL ] = X [ 305ULL ] ; t545 [ 1096ULL ]
= X [ 334ULL ] ; t545 [ 1097ULL ] = X [ 335ULL ] ; t545 [ 1098ULL ] = X [
325ULL ] ; t545 [ 1099ULL ] = X [ 336ULL ] ; t545 [ 1100ULL ] = X [ 337ULL ]
; t545 [ 1101ULL ] = X [ 338ULL ] ; t545 [ 1102ULL ] = X [ 339ULL ] ; t545 [
1103ULL ] = X [ 321ULL ] ; t545 [ 1104ULL ] = t851 * 0.1 ; t545 [ 1105ULL ] =
X [ 323ULL ] ; t545 [ 1106ULL ] = X [ 324ULL ] ; t545 [ 1107ULL ] = - X [
311ULL ] ; t545 [ 1108ULL ] = X [ 340ULL ] ; t545 [ 1109ULL ] = - X [ 313ULL
] ; t545 [ 1110ULL ] = - X [ 314ULL ] ; t545 [ 1111ULL ] = - X [ 315ULL ] ;
t545 [ 1112ULL ] = X [ 341ULL ] ; t545 [ 1113ULL ] = X [ 342ULL ] ; t545 [
1114ULL ] = t861 ; t545 [ 1115ULL ] = X [ 336ULL ] ; t545 [ 1116ULL ] = - X [
314ULL ] ; t545 [ 1117ULL ] = X [ 337ULL ] ; t545 [ 1118ULL ] = - X [ 315ULL
] ; t545 [ 1119ULL ] = ( 1.0 - X [ 41ULL ] ) - X [ 42ULL ] ; t545 [ 1120ULL ]
= X [ 321ULL ] ; t545 [ 1121ULL ] = t851 * 0.1 ; t545 [ 1122ULL ] = X [
323ULL ] ; t545 [ 1123ULL ] = X [ 324ULL ] ; t545 [ 1124ULL ] = X [ 307ULL ]
; t545 [ 1125ULL ] = X [ 308ULL ] ; t545 [ 1126ULL ] = X [ 309ULL ] ; t545 [
1127ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 1.0E+6 ; t545 [ 1128ULL ] = X [
322ULL ] ; t545 [ 1129ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 7812.5001220703134
; t545 [ 1130ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 1.0E+6 ; t545 [ 1131ULL ] =
X [ 322ULL ] ; t545 [ 1132ULL ] = X [ 322ULL ] * 0.0019634954084936209 ; t545
[ 1133ULL ] = t851 * 99999.999999999985 ; t545 [ 1134ULL ] = t854 * 0.1 ;
t545 [ 1135ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 7812.5001220703134 ; t545 [
1136ULL ] = X [ 321ULL ] ; t545 [ 1137ULL ] = t851 * 0.1 ; t545 [ 1138ULL ] =
X [ 323ULL ] ; t545 [ 1139ULL ] = X [ 324ULL ] ; t545 [ 1140ULL ] = t851 *
99999.999999999985 ; t545 [ 1141ULL ] = X [ 321ULL ] ; t545 [ 1142ULL ] = X [
321ULL ] ; t545 [ 1143ULL ] = t851 * 0.1 ; t545 [ 1144ULL ] = X [ 323ULL ] ;
t545 [ 1145ULL ] = X [ 324ULL ] ; t545 [ 1146ULL ] = X [ 322ULL ] *
0.0019634954084936209 ; t545 [ 1147ULL ] = X [ 307ULL ] ; t545 [ 1148ULL ] =
X [ 308ULL ] ; t545 [ 1149ULL ] = X [ 309ULL ] ; t545 [ 1150ULL ] = X [
313ULL ] ; t545 [ 1151ULL ] = X [ 321ULL ] ; t545 [ 1152ULL ] = t851 * 0.1 ;
t545 [ 1153ULL ] = X [ 323ULL ] ; t545 [ 1154ULL ] = X [ 324ULL ] ; t545 [
1155ULL ] = X [ 311ULL ] ; t545 [ 1156ULL ] = X [ 349ULL ] ; t545 [ 1157ULL ]
= X [ 313ULL ] ; t545 [ 1158ULL ] = X [ 314ULL ] ; t545 [ 1159ULL ] = X [
315ULL ] ; t545 [ 1160ULL ] = X [ 346ULL ] ; t545 [ 1161ULL ] = X [ 345ULL ]
; t545 [ 1162ULL ] = X [ 343ULL ] ; t545 [ 1163ULL ] = X [ 344ULL ] * 0.1 ;
t545 [ 1164ULL ] = X [ 347ULL ] ; t545 [ 1165ULL ] = X [ 348ULL ] ; t545 [
1166ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pressu13 ;
t545 [ 1167ULL ] = X [ 311ULL ] ; t545 [ 1168ULL ] = - X [ 311ULL ] ; t545 [
1169ULL ] = X [ 307ULL ] ; t545 [ 1170ULL ] = X [ 308ULL ] ; t545 [ 1171ULL ]
= X [ 309ULL ] ; t545 [ 1172ULL ] = - X [ 311ULL ] ; t545 [ 1173ULL ] = X [
349ULL ] ; t545 [ 1174ULL ] = - X [ 313ULL ] ; t545 [ 1175ULL ] = - X [
314ULL ] ; t545 [ 1176ULL ] = - X [ 315ULL ] ; t545 [ 1177ULL ] = X [ 346ULL
] ; t545 [ 1178ULL ] = X [ 345ULL ] ; t545 [ 1179ULL ] = - X [ 313ULL ] ;
t545 [ 1180ULL ] = X [ 314ULL ] ; t545 [ 1181ULL ] = - X [ 314ULL ] ; t545 [
1182ULL ] = X [ 315ULL ] ; t545 [ 1183ULL ] = - X [ 315ULL ] ; t545 [ 1184ULL
] = t854 * 0.1 ; t545 [ 1185ULL ] = U_idx_7 ; t545 [ 1186ULL ] = X [ 350ULL ]
; t545 [ 1187ULL ] = X [ 351ULL ] * 0.1 ; t545 [ 1188ULL ] = X [ 352ULL ] ;
t545 [ 1189ULL ] = X [ 353ULL ] ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ )
{ t545 [ t692 + 1190ULL ] = t593 [ t692 ] ; } for ( t692 = 0ULL ; t692 < 8ULL
; t692 ++ ) { t545 [ t692 + 1198ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ t692 ] ; }
t545 [ 1206ULL ] = X [ 32ULL ] ; t545 [ 1207ULL ] = X [ 364ULL ] ; t545 [
1208ULL ] = X [ 365ULL ] * 0.1 ; t545 [ 1209ULL ] = X [ 366ULL ] ; t545 [
1210ULL ] = X [ 367ULL ] ; t545 [ 1211ULL ] = X [ 350ULL ] ; t545 [ 1212ULL ]
= X [ 351ULL ] * 0.1 ; t545 [ 1213ULL ] = X [ 352ULL ] ; t545 [ 1214ULL ] = X
[ 353ULL ] ; t545 [ 1215ULL ] = X [ 44ULL ] ; t545 [ 1216ULL ] = X [ 358ULL ]
; t545 [ 1217ULL ] = X [ 45ULL ] ; t545 [ 1218ULL ] = X [ 369ULL ] ; t545 [
1219ULL ] = X [ 43ULL ] - 273.15 ; t545 [ 1220ULL ] = X [ 368ULL ] ; t545 [
1221ULL ] = X [ 370ULL ] * 0.1 ; t545 [ 1222ULL ] = X [ 49ULL ] * 0.1 ; t545
[ 1223ULL ] = X [ 356ULL ] ; t545 [ 1224ULL ] = t868 * 100000.0 ; t545 [
1225ULL ] = X [ 372ULL ] ; t545 [ 1226ULL ] = X [ 371ULL ] ; t545 [ 1227ULL ]
= X [ 373ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [
t692 + 1228ULL ] = t593 [ t692 ] ; } t545 [ 1236ULL ] = X [ 32ULL ] ; t545 [
1237ULL ] = X [ 357ULL ] ; t545 [ 1238ULL ] = intrm_sf_mf_901 ; t545 [
1239ULL ] = X [ 374ULL ] ; t545 [ 1240ULL ] = X [ 375ULL ] ; t545 [ 1241ULL ]
= X [ 376ULL ] ; t545 [ 1242ULL ] = X [ 355ULL ] ; t545 [ 1243ULL ] = X [
43ULL ] ; t545 [ 1244ULL ] = X [ 44ULL ] ; t545 [ 1245ULL ] = X [ 45ULL ] ;
t545 [ 1246ULL ] = t750 ; t545 [ 1247ULL ] = X [ 364ULL ] ; t545 [ 1248ULL ]
= X [ 365ULL ] * 0.1 ; t545 [ 1249ULL ] = X [ 366ULL ] ; t545 [ 1250ULL ] = X
[ 367ULL ] ; t545 [ 1251ULL ] = X [ 374ULL ] ; t545 [ 1252ULL ] = X [ 377ULL
] ; t545 [ 1253ULL ] = X [ 368ULL ] ; t545 [ 1254ULL ] = X [ 378ULL ] ; t545
[ 1255ULL ] = X [ 379ULL ] ; t545 [ 1256ULL ] = X [ 380ULL ] ; t545 [ 1257ULL
] = X [ 381ULL ] ; t545 [ 1258ULL ] = X [ 350ULL ] ; t545 [ 1259ULL ] = X [
351ULL ] * 0.1 ; t545 [ 1260ULL ] = X [ 352ULL ] ; t545 [ 1261ULL ] = X [
353ULL ] ; t545 [ 1262ULL ] = X [ 375ULL ] ; t545 [ 1263ULL ] = X [ 382ULL ]
; t545 [ 1264ULL ] = X [ 371ULL ] ; t545 [ 1265ULL ] = X [ 383ULL ] ; t545 [
1266ULL ] = X [ 384ULL ] ; t545 [ 1267ULL ] = X [ 385ULL ] ; t545 [ 1268ULL ]
= X [ 386ULL ] ; t545 [ 1269ULL ] = t875 ; t545 [ 1270ULL ] = X [ 378ULL ] ;
t545 [ 1271ULL ] = X [ 383ULL ] ; t545 [ 1272ULL ] = X [ 379ULL ] ; t545 [
1273ULL ] = X [ 384ULL ] ; t545 [ 1274ULL ] = ( 1.0 - X [ 45ULL ] ) - X [
44ULL ] ; t545 [ 1275ULL ] = X [ 350ULL ] ; t545 [ 1276ULL ] = X [ 351ULL ] *
0.1 ; t545 [ 1277ULL ] = X [ 352ULL ] ; t545 [ 1278ULL ] = X [ 353ULL ] ;
t545 [ 1279ULL ] = X [ 302ULL ] ; t545 [ 1280ULL ] = X [ 303ULL ] * 0.1 ;
t545 [ 1281ULL ] = X [ 304ULL ] ; t545 [ 1282ULL ] = X [ 305ULL ] ; t545 [
1283ULL ] = X [ 47ULL ] ; t545 [ 1284ULL ] = X [ 363ULL ] ; t545 [ 1285ULL ]
= X [ 48ULL ] ; t545 [ 1286ULL ] = X [ 387ULL ] ; t545 [ 1287ULL ] = X [
46ULL ] - 273.15 ; t545 [ 1288ULL ] = - X [ 371ULL ] ; t545 [ 1289ULL ] = X [
388ULL ] * 0.1 ; t545 [ 1290ULL ] = X [ 50ULL ] * 0.1 ; t545 [ 1291ULL ] = X
[ 361ULL ] ; t545 [ 1292ULL ] = t878 * 100000.0 ; t545 [ 1293ULL ] = X [
389ULL ] ; t545 [ 1294ULL ] = - X [ 325ULL ] ; t545 [ 1295ULL ] = X [ 390ULL
] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1296ULL
] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ t692 ]
; } t545 [ 1304ULL ] = X [ 32ULL ] ; t545 [ 1305ULL ] = X [ 362ULL ] ; t545 [
1306ULL ] = t826 ; t545 [ 1307ULL ] = - X [ 375ULL ] ; t545 [ 1308ULL ] = - X
[ 334ULL ] ; t545 [ 1309ULL ] = ( - X [ 391ULL ] - X [ 392ULL ] ) - X [
393ULL ] ; t545 [ 1310ULL ] = X [ 394ULL ] ; t545 [ 1311ULL ] = X [ 360ULL ]
; t545 [ 1312ULL ] = X [ 46ULL ] ; t545 [ 1313ULL ] = X [ 47ULL ] ; t545 [
1314ULL ] = X [ 48ULL ] ; t545 [ 1315ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_97 ; t545 [
1316ULL ] = X [ 350ULL ] ; t545 [ 1317ULL ] = X [ 351ULL ] * 0.1 ; t545 [
1318ULL ] = X [ 352ULL ] ; t545 [ 1319ULL ] = X [ 353ULL ] ; t545 [ 1320ULL ]
= - X [ 375ULL ] ; t545 [ 1321ULL ] = X [ 395ULL ] ; t545 [ 1322ULL ] = - X [
371ULL ] ; t545 [ 1323ULL ] = - X [ 383ULL ] ; t545 [ 1324ULL ] = - X [
384ULL ] ; t545 [ 1325ULL ] = X [ 396ULL ] ; t545 [ 1326ULL ] = X [ 397ULL ]
; t545 [ 1327ULL ] = X [ 302ULL ] ; t545 [ 1328ULL ] = X [ 303ULL ] * 0.1 ;
t545 [ 1329ULL ] = X [ 304ULL ] ; t545 [ 1330ULL ] = X [ 305ULL ] ; t545 [
1331ULL ] = - X [ 334ULL ] ; t545 [ 1332ULL ] = X [ 398ULL ] ; t545 [ 1333ULL
] = - X [ 325ULL ] ; t545 [ 1334ULL ] = - X [ 336ULL ] ; t545 [ 1335ULL ] = -
X [ 337ULL ] ; t545 [ 1336ULL ] = X [ 399ULL ] ; t545 [ 1337ULL ] = X [
400ULL ] ; t545 [ 1338ULL ] = t886 ; t545 [ 1339ULL ] = - X [ 383ULL ] ; t545
[ 1340ULL ] = - X [ 336ULL ] ; t545 [ 1341ULL ] = X [ 401ULL ] ; t545 [
1342ULL ] = X [ 402ULL ] ; t545 [ 1343ULL ] = - X [ 384ULL ] ; t545 [ 1344ULL
] = - X [ 337ULL ] ; t545 [ 1345ULL ] = ( 1.0 - X [ 48ULL ] ) - X [ 47ULL ] ;
t545 [ 1346ULL ] = X [ 46ULL ] ; t545 [ 1347ULL ] = X [ 47ULL ] ; t545 [
1348ULL ] = X [ 48ULL ] ; t545 [ 1349ULL ] = X [ 364ULL ] ; t545 [ 1350ULL ]
= X [ 365ULL ] * 0.1 ; t545 [ 1351ULL ] = X [ 366ULL ] ; t545 [ 1352ULL ] = X
[ 367ULL ] ; t545 [ 1353ULL ] = X [ 302ULL ] ; t545 [ 1354ULL ] = X [ 303ULL
] * 0.1 ; t545 [ 1355ULL ] = X [ 304ULL ] ; t545 [ 1356ULL ] = X [ 305ULL ] ;
t545 [ 1357ULL ] = X [ 403ULL ] ; t545 [ 1358ULL ] = X [ 55ULL ] * 0.1 ; t545
[ 1359ULL ] = X [ 404ULL ] ; t545 [ 1360ULL ] = X [ 405ULL ] ; t545 [ 1361ULL
] = X [ 364ULL ] ; t545 [ 1362ULL ] = X [ 365ULL ] * 0.1 ; t545 [ 1363ULL ] =
X [ 366ULL ] ; t545 [ 1364ULL ] = X [ 367ULL ] ; t545 [ 1365ULL ] = U_idx_8 ;
t545 [ 1366ULL ] = X [ 406ULL ] ; t545 [ 1367ULL ] = X [ 51ULL ] ; t545 [
1368ULL ] = X [ 52ULL ] ; t545 [ 1369ULL ] = X [ 53ULL ] ; t545 [ 1370ULL ] =
U_idx_9 ; t545 [ 1371ULL ] = - U_idx_8 ; for ( t692 = 0ULL ; t692 < 8ULL ;
t692 ++ ) { t545 [ t692 + 1372ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ t692 ] ; }
t545 [ 1380ULL ] = X [ 409ULL ] ; t545 [ 1381ULL ] = X [ 411ULL ] * 1.0E-5 *
99999.999999999985 ; t545 [ 1382ULL ] = X [ 51ULL ] ; t545 [ 1383ULL ] = X [
408ULL ] ; t545 [ 1384ULL ] = X [ 408ULL ] ; t545 [ 1385ULL ] = X [ 412ULL ]
; t545 [ 1386ULL ] = X [ 412ULL ] ; t545 [ 1387ULL ] = X [ 403ULL ] ; t545 [
1388ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 1389ULL ] = X [ 404ULL ] ; t545 [
1390ULL ] = X [ 405ULL ] ; t545 [ 1391ULL ] = X [ 364ULL ] ; t545 [ 1392ULL ]
= X [ 365ULL ] * 0.1 ; t545 [ 1393ULL ] = X [ 366ULL ] ; t545 [ 1394ULL ] = X
[ 367ULL ] ; t545 [ 1395ULL ] = X [ 52ULL ] ; t545 [ 1396ULL ] = X [ 409ULL ]
; t545 [ 1397ULL ] = X [ 53ULL ] ; t545 [ 1398ULL ] = X [ 414ULL ] ; t545 [
1399ULL ] = X [ 51ULL ] - 273.15 ; t545 [ 1400ULL ] = X [ 413ULL ] ; t545 [
1401ULL ] = X [ 415ULL ] * 0.1 ; t545 [ 1402ULL ] = X [ 54ULL ] * 0.1 ; t545
[ 1403ULL ] = X [ 410ULL ] ; t545 [ 1404ULL ] = t891 * 100000.0 ; t545 [
1405ULL ] = X [ 416ULL ] ; t545 [ 1406ULL ] = - X [ 368ULL ] ; t545 [ 1407ULL
] = X [ 417ULL ] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [
t692 + 1408ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ t692 ] ; }
t545 [ 1416ULL ] = X [ 412ULL ] ; t545 [ 1417ULL ] = X [ 407ULL ] ; t545 [
1418ULL ] = t880 ; t545 [ 1419ULL ] = X [ 418ULL ] ; t545 [ 1420ULL ] = - X [
374ULL ] ; t545 [ 1421ULL ] = - X [ 406ULL ] ; t545 [ 1422ULL ] = X [ 408ULL
] ; t545 [ 1423ULL ] = X [ 51ULL ] ; t545 [ 1424ULL ] = X [ 52ULL ] ; t545 [
1425ULL ] = X [ 53ULL ] ; t545 [ 1426ULL ] = t893 ; t545 [ 1427ULL ] = X [
403ULL ] ; t545 [ 1428ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 1429ULL ] = X [
404ULL ] ; t545 [ 1430ULL ] = X [ 405ULL ] ; t545 [ 1431ULL ] = X [ 418ULL ]
; t545 [ 1432ULL ] = X [ 419ULL ] ; t545 [ 1433ULL ] = X [ 413ULL ] ; t545 [
1434ULL ] = X [ 420ULL ] ; t545 [ 1435ULL ] = X [ 421ULL ] ; t545 [ 1436ULL ]
= X [ 422ULL ] ; t545 [ 1437ULL ] = X [ 423ULL ] ; t545 [ 1438ULL ] = X [
364ULL ] ; t545 [ 1439ULL ] = X [ 365ULL ] * 0.1 ; t545 [ 1440ULL ] = X [
366ULL ] ; t545 [ 1441ULL ] = X [ 367ULL ] ; t545 [ 1442ULL ] = - X [ 374ULL
] ; t545 [ 1443ULL ] = X [ 424ULL ] ; t545 [ 1444ULL ] = - X [ 368ULL ] ;
t545 [ 1445ULL ] = - X [ 378ULL ] ; t545 [ 1446ULL ] = - X [ 379ULL ] ; t545
[ 1447ULL ] = X [ 425ULL ] ; t545 [ 1448ULL ] = X [ 426ULL ] ; t545 [ 1449ULL
] = t896 ; t545 [ 1450ULL ] = X [ 420ULL ] ; t545 [ 1451ULL ] = - X [ 378ULL
] ; t545 [ 1452ULL ] = U_idx_8 ; t545 [ 1453ULL ] = X [ 421ULL ] ; t545 [
1454ULL ] = - X [ 379ULL ] ; t545 [ 1455ULL ] = ( 1.0 - X [ 53ULL ] ) - X [
52ULL ] ; t545 [ 1456ULL ] = U_idx_9 ; t545 [ 1457ULL ] = U_idx_8 ; t545 [
1458ULL ] = X [ 62ULL ] ; t545 [ 1459ULL ] = t888 * 1000.0 ; t545 [ 1460ULL ]
= t888 * 0.35777375282305851 ; t545 [ 1461ULL ] = X [ 429ULL ] ; t545 [
1462ULL ] = X [ 429ULL ] ; t545 [ 1463ULL ] = X [ 56ULL ] ; t545 [ 1464ULL ]
= Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ; t545 [
1465ULL ] = X [ 432ULL ] ; t545 [ 1466ULL ] = X [ 56ULL ] ; t545 [ 1467ULL ]
= X [ 429ULL ] ; t545 [ 1468ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip29 ; t545 [
1469ULL ] = X [ 433ULL ] ; t545 [ 1470ULL ] = t762 ; t545 [ 1471ULL ] = X [
435ULL ] ; t545 [ 1472ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Pip28 ; t545 [
1473ULL ] = t898 ; t545 [ 1474ULL ] = t899 ; t545 [ 1475ULL ] = X [ 57ULL ] ;
t545 [ 1476ULL ] = X [ 57ULL ] * 0.1 + 0.0001 ; t545 [ 1477ULL ] = X [ 432ULL
] ; t545 [ 1478ULL ] = t762 ; t545 [ 1479ULL ] = X [ 56ULL ] ; t545 [ 1480ULL
] = X [ 56ULL ] ; t545 [ 1481ULL ] = X [ 429ULL ] ; t545 [ 1482ULL ] = X [
432ULL ] ; t545 [ 1483ULL ] = X [ 432ULL ] ; t545 [ 1484ULL ] = t888 * 1000.0
; t545 [ 1485ULL ] = X [ 436ULL ] ; t545 [ 1486ULL ] = X [ 437ULL ] * 0.1 ;
t545 [ 1487ULL ] = X [ 438ULL ] ; t545 [ 1488ULL ] = X [ 439ULL ] * 0.1 ;
t545 [ 1489ULL ] = X [ 440ULL ] ; t545 [ 1490ULL ] = - X [ 440ULL ] ; t545 [
1491ULL ] = X [ 436ULL ] ; t545 [ 1492ULL ] = X [ 437ULL ] * 0.1 ; t545 [
1493ULL ] = X [ 440ULL ] ; t545 [ 1494ULL ] = X [ 441ULL ] ; t545 [ 1495ULL ]
= X [ 442ULL ] ; t545 [ 1496ULL ] = X [ 443ULL ] ; t545 [ 1497ULL ] = X [
438ULL ] ; t545 [ 1498ULL ] = X [ 439ULL ] * 0.1 ; t545 [ 1499ULL ] = - X [
440ULL ] ; t545 [ 1500ULL ] = X [ 444ULL ] ; t545 [ 1501ULL ] = - X [ 442ULL
] ; t545 [ 1502ULL ] = X [ 443ULL ] ; t545 [ 1503ULL ] = X [ 442ULL ] ; t545
[ 1504ULL ] = - X [ 442ULL ] ; t545 [ 1505ULL ] = X [ 438ULL ] ; t545 [
1506ULL ] = X [ 439ULL ] * 0.1 ; t545 [ 1507ULL ] = X [ 429ULL ] ; t545 [
1508ULL ] = X [ 32ULL ] ; t545 [ 1509ULL ] = X [ 440ULL ] ; t545 [ 1510ULL ]
= X [ 430ULL ] ; t545 [ 1511ULL ] = X [ 58ULL ] * 0.1 ; t545 [ 1512ULL ] = X
[ 59ULL ] ; t545 [ 1513ULL ] = X [ 442ULL ] ; t545 [ 1514ULL ] = X [ 434ULL ]
; t545 [ 1515ULL ] = X [ 445ULL ] ; t545 [ 1516ULL ] = X [ 438ULL ] ; t545 [
1517ULL ] = X [ 439ULL ] * 0.1 ; t545 [ 1518ULL ] = X [ 440ULL ] ; t545 [
1519ULL ] = X [ 446ULL ] ; t545 [ 1520ULL ] = X [ 442ULL ] ; t545 [ 1521ULL ]
= X [ 447ULL ] ; t545 [ 1522ULL ] = X [ 429ULL ] ; t545 [ 1523ULL ] = X [
430ULL ] ; t545 [ 1524ULL ] = X [ 448ULL ] ; t545 [ 1525ULL ] = X [ 434ULL ]
; t545 [ 1526ULL ] = X [ 449ULL ] ; t545 [ 1527ULL ] = t902 ; t545 [ 1528ULL
] = t903 ; t545 [ 1529ULL ] = t904 ; t545 [ 1530ULL ] = t817 ; t545 [ 1531ULL
] = t662_idx_0 ; t545 [ 1532ULL ] = X [ 32ULL ] ; t545 [ 1533ULL ] = U_idx_10
; t545 [ 1534ULL ] = t906 ; t545 [ 1535ULL ] = X [ 429ULL ] ; t545 [ 1536ULL
] = X [ 450ULL ] ; t545 [ 1537ULL ] = X [ 451ULL ] * 0.1 ; t545 [ 1538ULL ] =
t906 ; t545 [ 1539ULL ] = X [ 431ULL ] ; t545 [ 1540ULL ] = X [ 452ULL ] ;
t545 [ 1541ULL ] = X [ 429ULL ] ; t545 [ 1542ULL ] = X [ 431ULL ] ; t545 [
1543ULL ] = X [ 453ULL ] ; t545 [ 1544ULL ] = t907 ; t545 [ 1545ULL ] = X [
454ULL ] ; t545 [ 1546ULL ] = X [ 450ULL ] ; t545 [ 1547ULL ] = X [ 451ULL ]
* 0.1 ; t545 [ 1548ULL ] = X [ 452ULL ] ; t545 [ 1549ULL ] = X [ 455ULL ] ;
t545 [ 1550ULL ] = - t907 ; t545 [ 1551ULL ] = X [ 454ULL ] ; t545 [ 1552ULL
] = t907 ; t545 [ 1553ULL ] = - t907 ; t545 [ 1554ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Pump_powe ; t545 [
1555ULL ] = X [ 450ULL ] ; t545 [ 1556ULL ] = X [ 451ULL ] * 0.1 ; t545 [
1557ULL ] = X [ 436ULL ] ; t545 [ 1558ULL ] = X [ 437ULL ] * 0.1 ; t545 [
1559ULL ] = X [ 62ULL ] ; t545 [ 1560ULL ] = - X [ 452ULL ] ; t545 [ 1561ULL
] = - X [ 440ULL ] ; t545 [ 1562ULL ] = X [ 60ULL ] * 0.1 ; t545 [ 1563ULL ]
= X [ 61ULL ] ; t545 [ 1564ULL ] = t907 ; t545 [ 1565ULL ] = - X [ 442ULL ] ;
t545 [ 1566ULL ] = X [ 427ULL ] ; t545 [ 1567ULL ] = X [ 450ULL ] ; t545 [
1568ULL ] = X [ 451ULL ] * 0.1 ; t545 [ 1569ULL ] = - X [ 452ULL ] ; t545 [
1570ULL ] = X [ 456ULL ] ; t545 [ 1571ULL ] = t907 ; t545 [ 1572ULL ] = X [
457ULL ] ; t545 [ 1573ULL ] = X [ 436ULL ] ; t545 [ 1574ULL ] = X [ 437ULL ]
* 0.1 ; t545 [ 1575ULL ] = - X [ 440ULL ] ; t545 [ 1576ULL ] = X [ 458ULL ] ;
t545 [ 1577ULL ] = - X [ 442ULL ] ; t545 [ 1578ULL ] = X [ 459ULL ] ; t545 [
1579ULL ] = t910 ; t545 [ 1580ULL ] = t911 ; t545 [ 1581ULL ] = t912 ; t545 [
1582ULL ] = intrm_sf_mf_1359 ; t545 [ 1583ULL ] = intrm_sf_mf_1368 ; t545 [
1584ULL ] = X [ 450ULL ] ; t545 [ 1585ULL ] = X [ 451ULL ] * 0.1 ; t545 [
1586ULL ] = X [ 429ULL ] ; t545 [ 1587ULL ] = X [ 450ULL ] ; t545 [ 1588ULL ]
= X [ 451ULL ] * 0.1 ; t545 [ 1589ULL ] = t913 * 1000.0 ; t545 [ 1590ULL ] =
t913 * 1111.1111111111111 ; t545 [ 1591ULL ] = t913 * 1111.1111111111111 ;
t545 [ 1592ULL ] = ( 1.01325 - X [ 451ULL ] ) * 99999.999999999985 ; t545 [
1593ULL ] = X [ 460ULL ] * 1.0E-6 ; t545 [ 1594ULL ] = t913 * 1000.0 ; t545 [
1595ULL ] = X [ 429ULL ] ; t545 [ 1596ULL ] = X [ 450ULL ] ; t545 [ 1597ULL ]
= X [ 451ULL ] * 0.1 ; t545 [ 1598ULL ] = ( 1.01325 - X [ 451ULL ] ) *
99999.999999999985 ; t545 [ 1599ULL ] = X [ 429ULL ] - X [ 450ULL ] ; t545 [
1600ULL ] = X [ 450ULL ] ; t545 [ 1601ULL ] = X [ 451ULL ] * 0.1 ; t545 [
1602ULL ] = X [ 450ULL ] ; t545 [ 1603ULL ] = X [ 451ULL ] * 0.1 ; t545 [
1604ULL ] = - X [ 452ULL ] ; t545 [ 1605ULL ] = X [ 460ULL ] * 1.0E-6 ; t545
[ 1606ULL ] = t907 ; t545 [ 1607ULL ] = U_idx_10 ; t545 [ 1608ULL ] = X [
32ULL ] ; t545 [ 1609ULL ] = X [ 32ULL ] ; t545 [ 1610ULL ] = X [ 32ULL ] -
273.15 ; t545 [ 1611ULL ] = X [ 62ULL ] ; t545 [ 1612ULL ] = X [ 62ULL ] ;
t545 [ 1613ULL ] = X [ 428ULL ] * 1000.0 ; t545 [ 1614ULL ] = X [ 62ULL ] -
273.15 ; t545 [ 1615ULL ] = X [ 226ULL ] ; t545 [ 1616ULL ] = X [ 227ULL ] *
0.1 ; t545 [ 1617ULL ] = X [ 228ULL ] ; t545 [ 1618ULL ] = X [ 229ULL ] ;
t545 [ 1619ULL ] = X [ 350ULL ] ; t545 [ 1620ULL ] = X [ 351ULL ] * 0.1 ;
t545 [ 1621ULL ] = X [ 352ULL ] ; t545 [ 1622ULL ] = X [ 353ULL ] ; for (
t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1623ULL ] = t576 [ t692
] ; } for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1631ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t692 ] ; }
for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1639ULL ] = t593
[ t692 ] ; } for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
1647ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
t692 ] ; } t545 [ 1655ULL ] = X [ 32ULL ] ; t545 [ 1656ULL ] = X [ 226ULL ] ;
t545 [ 1657ULL ] = X [ 227ULL ] * 0.1 ; t545 [ 1658ULL ] = X [ 228ULL ] ;
t545 [ 1659ULL ] = X [ 229ULL ] ; t545 [ 1660ULL ] = X [ 350ULL ] ; t545 [
1661ULL ] = X [ 351ULL ] * 0.1 ; t545 [ 1662ULL ] = X [ 352ULL ] ; t545 [
1663ULL ] = X [ 353ULL ] ; t545 [ 1664ULL ] = X [ 461ULL ] ; t545 [ 1665ULL ]
= X [ 462ULL ] ; t545 [ 1666ULL ] = X [ 32ULL ] ; for ( t692 = 0ULL ; t692 <
8ULL ; t692 ++ ) { t545 [ t692 + 1667ULL ] = t576 [ t692 ] ; } for ( t692 =
0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1675ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t692 ] ; }
for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1683ULL ] = t593
[ t692 ] ; } for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 +
1691ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
t692 ] ; } t545 [ 1699ULL ] = X [ 173ULL ] ; t545 [ 1700ULL ] = t921 * 0.0001
; t545 [ 1701ULL ] = t921 * 0.2774351967714716 / 192970.66424 * 1000.0 ; t545
[ 1702ULL ] = t920 * 1000.0 ; t545 [ 1703ULL ] = t917 * 1000.0 ; t545 [
1704ULL ] = t921 * 0.49278168702634639 / 385941.32848 * 1000.0 ; t545 [
1705ULL ] = t926 ; t545 [ 1706ULL ] = t918 * 100.0 ; t545 [ 1707ULL ] = X [
28ULL ] ; t545 [ 1708ULL ] = X [ 29ULL ] ; t545 [ 1709ULL ] = X [ 30ULL ] ;
t545 [ 1710ULL ] = X [ 46ULL ] ; t545 [ 1711ULL ] = X [ 47ULL ] ; t545 [
1712ULL ] = X [ 48ULL ] ; t545 [ 1713ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra11 ; t545 [
1714ULL ] = intrm_sf_mf_1371 ; t545 [ 1715ULL ] = intrm_sf_mf_1372 ; t545 [
1716ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ;
t545 [ 1717ULL ] = X [ 465ULL ] ; t545 [ 1718ULL ] = X [ 391ULL ] ; t545 [
1719ULL ] = X [ 46ULL ] ; t545 [ 1720ULL ] = X [ 47ULL ] ; t545 [ 1721ULL ] =
X [ 48ULL ] ; t545 [ 1722ULL ] = X [ 32ULL ] ; t545 [ 1723ULL ] = - X [
465ULL ] ; t545 [ 1724ULL ] = X [ 276ULL ] ; t545 [ 1725ULL ] = X [ 267ULL ]
; t545 [ 1726ULL ] = X [ 28ULL ] ; t545 [ 1727ULL ] = X [ 29ULL ] ; t545 [
1728ULL ] = X [ 30ULL ] ; t545 [ 1729ULL ] = X [ 32ULL ] ; t545 [ 1730ULL ] =
- X [ 276ULL ] ; t545 [ 1731ULL ] = X [ 401ULL ] ; t545 [ 1732ULL ] = X [
392ULL ] ; t545 [ 1733ULL ] = X [ 46ULL ] ; t545 [ 1734ULL ] = X [ 47ULL ] ;
t545 [ 1735ULL ] = X [ 48ULL ] ; t545 [ 1736ULL ] = X [ 32ULL ] ; t545 [
1737ULL ] = - X [ 401ULL ] ; t545 [ 1738ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.001 ;
t545 [ 1739ULL ] = X [ 277ULL ] ; t545 [ 1740ULL ] = X [ 268ULL ] ; t545 [
1741ULL ] = X [ 28ULL ] ; t545 [ 1742ULL ] = X [ 29ULL ] ; t545 [ 1743ULL ] =
X [ 30ULL ] ; t545 [ 1744ULL ] = X [ 32ULL ] ; t545 [ 1745ULL ] = - X [
277ULL ] ; t545 [ 1746ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ; t545 [
1747ULL ] = X [ 393ULL ] ; t545 [ 1748ULL ] = X [ 46ULL ] ; t545 [ 1749ULL ]
= X [ 47ULL ] ; t545 [ 1750ULL ] = X [ 48ULL ] ; t545 [ 1751ULL ] = X [ 32ULL
] ; t545 [ 1752ULL ] = -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra42 ; t545 [
1753ULL ] = ( ( t917 * 241812.2160511087 / 0.0020158806832745466 * 0.001 + (
( ( X [ 267ULL ] - X [ 276ULL ] * - 3931.85243448965 ) + ( X [ 392ULL ] - X [
401ULL ] * - 271.011680699068 ) ) + ( X [ 391ULL ] - X [ 465ULL ] * -
2546.6190535198302 ) ) ) + ( X [ 268ULL ] + X [ 393ULL ] ) ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra48 * 0.001 ;
t545 [ 1754ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ; t545 [
1755ULL ] = X [ 28ULL ] ; t545 [ 1756ULL ] = X [ 29ULL ] ; t545 [ 1757ULL ] =
X [ 30ULL ] ; t545 [ 1758ULL ] = X [ 46ULL ] ; t545 [ 1759ULL ] = X [ 47ULL ]
; t545 [ 1760ULL ] = X [ 48ULL ] ; t545 [ 1761ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ; t545 [
1762ULL ] = X [ 32ULL ] ; t545 [ 1763ULL ] = X [ 32ULL ] ; t545 [ 1764ULL ] =
X [ 32ULL ] ; t545 [ 1765ULL ] = X [ 32ULL ] ; t545 [ 1766ULL ] = t926 * -
1000.0 ; t545 [ 1767ULL ] = t926 * - 1000.0 ; t545 [ 1768ULL ] = - t926 ;
t545 [ 1769ULL ] = X [ 466ULL ] ; t545 [ 1770ULL ] = X [ 38ULL ] * 0.1 ; t545
[ 1771ULL ] = X [ 467ULL ] ; t545 [ 1772ULL ] = X [ 468ULL ] ; t545 [ 1773ULL
] = X [ 469ULL ] ; t545 [ 1774ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1775ULL ] =
X [ 470ULL ] ; t545 [ 1776ULL ] = X [ 471ULL ] ; t545 [ 1777ULL ] = X [ 63ULL
] ; t545 [ 1778ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1779ULL ] = X [ 65ULL ] ;
t545 [ 1780ULL ] = X [ 66ULL ] ; t545 [ 1781ULL ] = X [ 63ULL ] ; t545 [
1782ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1783ULL ] = X [ 65ULL ] ; t545 [
1784ULL ] = X [ 66ULL ] ; t545 [ 1785ULL ] = X [ 63ULL ] ; t545 [ 1786ULL ] =
X [ 64ULL ] * 0.1 ; t545 [ 1787ULL ] = X [ 65ULL ] ; t545 [ 1788ULL ] = X [
66ULL ] ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1789ULL
] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ t692 ] ;
} t545 [ 1797ULL ] = X [ 63ULL ] ; t545 [ 1798ULL ] = X [ 472ULL ] ; t545 [
1799ULL ] = X [ 476ULL ] ; t545 [ 1800ULL ] = X [ 63ULL ] - 273.15 ; t545 [
1801ULL ] = X [ 65ULL ] ; t545 [ 1802ULL ] = X [ 474ULL ] ; t545 [ 1803ULL ]
= X [ 66ULL ] ; t545 [ 1804ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1805ULL ] =
t931 ; t545 [ 1806ULL ] = X [ 473ULL ] ; t545 [ 1807ULL ] = X [ 63ULL ] ;
t545 [ 1808ULL ] = X [ 65ULL ] ; t545 [ 1809ULL ] = X [ 66ULL ] ; t545 [
1810ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T5 ;
t545 [ 1811ULL ] = X [ 469ULL ] ; t545 [ 1812ULL ] = X [ 64ULL ] * 0.1 ; t545
[ 1813ULL ] = X [ 470ULL ] ; t545 [ 1814ULL ] = X [ 471ULL ] ; t545 [ 1815ULL
] = X [ 476ULL ] ; t545 [ 1816ULL ] = X [ 477ULL ] ; t545 [ 1817ULL ] = X [
478ULL ] ; t545 [ 1818ULL ] = X [ 479ULL ] ; t545 [ 1819ULL ] = X [ 480ULL ]
; t545 [ 1820ULL ] = X [ 481ULL ] ; t545 [ 1821ULL ] = X [ 482ULL ] ; t545 [
1822ULL ] = t935 ; t545 [ 1823ULL ] = X [ 478ULL ] ; t545 [ 1824ULL ] = X [
479ULL ] ; t545 [ 1825ULL ] = X [ 480ULL ] ; t545 [ 1826ULL ] = ( 1.0 - X [
66ULL ] ) - X [ 65ULL ] ; t545 [ 1827ULL ] = X [ 475ULL ] ; t545 [ 1828ULL ]
= X [ 466ULL ] ; t545 [ 1829ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 1830ULL ] = X
[ 467ULL ] ; t545 [ 1831ULL ] = X [ 468ULL ] ; t545 [ 1832ULL ] = X [ 469ULL
] ; t545 [ 1833ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1834ULL ] = X [ 470ULL ] ;
t545 [ 1835ULL ] = X [ 471ULL ] ; t545 [ 1836ULL ] = X [ 469ULL ] ; t545 [
1837ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1838ULL ] = X [ 470ULL ] ; t545 [
1839ULL ] = X [ 471ULL ] ; t545 [ 1840ULL ] = - X [ 478ULL ] ; t545 [ 1841ULL
] = - X [ 479ULL ] ; t545 [ 1842ULL ] = - X [ 480ULL ] ; t545 [ 1843ULL ] = X
[ 476ULL ] * - 1000.0 ; t545 [ 1844ULL ] = - X [ 476ULL ] ; t545 [ 1845ULL ]
= - X [ 478ULL ] ; t545 [ 1846ULL ] = - X [ 479ULL ] ; t545 [ 1847ULL ] = - X
[ 480ULL ] ; t545 [ 1848ULL ] = - X [ 478ULL ] ; t545 [ 1849ULL ] = X [ 63ULL
] ; t545 [ 1850ULL ] = X [ 63ULL ] ; t545 [ 1851ULL ] = X [ 483ULL ] ; t545 [
1852ULL ] = X [ 483ULL ] ; t545 [ 1853ULL ] = X [ 484ULL ] ; t545 [ 1854ULL ]
= t929 * 0.1 ; t545 [ 1855ULL ] = X [ 486ULL ] ; t545 [ 1856ULL ] = X [
487ULL ] ; t545 [ 1857ULL ] = X [ 466ULL ] ; t545 [ 1858ULL ] = X [ 38ULL ] *
0.1 ; t545 [ 1859ULL ] = X [ 467ULL ] ; t545 [ 1860ULL ] = X [ 468ULL ] ;
t545 [ 1861ULL ] = X [ 70ULL ] ; t545 [ 1862ULL ] = X [ 491ULL ] ; t545 [
1863ULL ] = X [ 69ULL ] ; t545 [ 1864ULL ] = X [ 488ULL ] ; t545 [ 1865ULL ]
= X [ 67ULL ] - 273.15 ; t545 [ 1866ULL ] = - X [ 478ULL ] ; t545 [ 1867ULL ]
= X [ 489ULL ] * 0.1 ; t545 [ 1868ULL ] = X [ 68ULL ] * 0.1 ; t545 [ 1869ULL
] = X [ 490ULL ] ; t545 [ 1870ULL ] = t937 * 100000.0 ; t545 [ 1871ULL ] = X
[ 493ULL ] ; t545 [ 1872ULL ] = X [ 492ULL ] ; t545 [ 1873ULL ] = X [ 494ULL
] * 0.1 ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 1874ULL
] = t621 [ t692 ] ; } t545 [ 1882ULL ] = X [ 483ULL ] ; t545 [ 1883ULL ] = X
[ 495ULL ] ; t545 [ 1884ULL ] = intrm_sf_mf_1431 ; t545 [ 1885ULL ] = - X [
476ULL ] ; t545 [ 1886ULL ] = X [ 497ULL ] ; t545 [ 1887ULL ] = X [ 496ULL ]
; t545 [ 1888ULL ] = X [ 67ULL ] ; t545 [ 1889ULL ] = X [ 70ULL ] ; t545 [
1890ULL ] = X [ 69ULL ] ; t545 [ 1891ULL ] = t939 ; t545 [ 1892ULL ] = X [
484ULL ] ; t545 [ 1893ULL ] = t929 * 0.1 ; t545 [ 1894ULL ] = X [ 486ULL ] ;
t545 [ 1895ULL ] = X [ 487ULL ] ; t545 [ 1896ULL ] = - X [ 476ULL ] ; t545 [
1897ULL ] = X [ 498ULL ] ; t545 [ 1898ULL ] = - X [ 478ULL ] ; t545 [ 1899ULL
] = - X [ 479ULL ] ; t545 [ 1900ULL ] = - X [ 480ULL ] ; t545 [ 1901ULL ] = X
[ 499ULL ] ; t545 [ 1902ULL ] = X [ 500ULL ] ; t545 [ 1903ULL ] = X [ 466ULL
] ; t545 [ 1904ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 1905ULL ] = X [ 467ULL ] ;
t545 [ 1906ULL ] = X [ 468ULL ] ; t545 [ 1907ULL ] = X [ 497ULL ] ; t545 [
1908ULL ] = X [ 501ULL ] ; t545 [ 1909ULL ] = X [ 492ULL ] ; t545 [ 1910ULL ]
= X [ 502ULL ] ; t545 [ 1911ULL ] = X [ 503ULL ] ; t545 [ 1912ULL ] = X [
504ULL ] ; t545 [ 1913ULL ] = X [ 505ULL ] ; t545 [ 1914ULL ] = t942 ; t545 [
1915ULL ] = - X [ 479ULL ] ; t545 [ 1916ULL ] = X [ 502ULL ] ; t545 [ 1917ULL
] = - X [ 480ULL ] ; t545 [ 1918ULL ] = X [ 503ULL ] ; t545 [ 1919ULL ] = (
1.0 - X [ 69ULL ] ) - X [ 70ULL ] ; t545 [ 1920ULL ] = X [ 469ULL ] ; t545 [
1921ULL ] = X [ 64ULL ] * 0.1 ; t545 [ 1922ULL ] = X [ 470ULL ] ; t545 [
1923ULL ] = X [ 471ULL ] ; t545 [ 1924ULL ] = X [ 484ULL ] ; t545 [ 1925ULL ]
= t929 * 0.1 ; t545 [ 1926ULL ] = X [ 486ULL ] ; t545 [ 1927ULL ] = X [
487ULL ] ; t545 [ 1928ULL ] = ( X [ 485ULL ] - 0.16000000000000003 ) * 1.0E+6
; t545 [ 1929ULL ] = X [ 485ULL ] ; t545 [ 1930ULL ] = ( X [ 485ULL ] -
0.16000000000000003 ) * - 62500.003906250226 ; t545 [ 1931ULL ] = ( X [
485ULL ] - 0.16000000000000003 ) * 1.0E+6 ; t545 [ 1932ULL ] = X [ 485ULL ] ;
t545 [ 1933ULL ] = X [ 485ULL ] * 7.8539816339744827E-5 ; t545 [ 1934ULL ] =
t929 * 99999.999999999985 ; t545 [ 1935ULL ] = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 -
0.10000000000000002 ) * 0.1 ; t545 [ 1936ULL ] = ( X [ 485ULL ] -
0.16000000000000003 ) * - 62500.003906250226 ; t545 [ 1937ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 * 0.1 ; t545
[ 1938ULL ] = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 -
0.10000000000000002 ) * 0.1 ; t545 [ 1939ULL ] = X [ 484ULL ] ; t545 [
1940ULL ] = t929 * 0.1 ; t545 [ 1941ULL ] = X [ 486ULL ] ; t545 [ 1942ULL ] =
X [ 487ULL ] ; t545 [ 1943ULL ] = t929 * 99999.999999999985 ; t545 [ 1944ULL
] = X [ 484ULL ] ; t545 [ 1945ULL ] = X [ 469ULL ] ; t545 [ 1946ULL ] = X [
64ULL ] * 0.1 ; t545 [ 1947ULL ] = X [ 470ULL ] ; t545 [ 1948ULL ] = X [
471ULL ] ; t545 [ 1949ULL ] = X [ 485ULL ] * 7.8539816339744827E-5 ; t545 [
1950ULL ] = X [ 484ULL ] ; t545 [ 1951ULL ] = t929 * 0.1 ; t545 [ 1952ULL ] =
X [ 486ULL ] ; t545 [ 1953ULL ] = X [ 487ULL ] ; t545 [ 1954ULL ] = - X [
478ULL ] ; t545 [ 1955ULL ] = X [ 469ULL ] ; t545 [ 1956ULL ] = X [ 64ULL ] *
0.1 ; t545 [ 1957ULL ] = X [ 470ULL ] ; t545 [ 1958ULL ] = X [ 471ULL ] ;
t545 [ 1959ULL ] = - X [ 476ULL ] ; t545 [ 1960ULL ] = X [ 512ULL ] ; t545 [
1961ULL ] = - X [ 478ULL ] ; t545 [ 1962ULL ] = - X [ 479ULL ] ; t545 [
1963ULL ] = - X [ 480ULL ] ; t545 [ 1964ULL ] = X [ 509ULL ] ; t545 [ 1965ULL
] = X [ 508ULL ] ; t545 [ 1966ULL ] = X [ 506ULL ] ; t545 [ 1967ULL ] = X [
507ULL ] * 0.1 ; t545 [ 1968ULL ] = X [ 510ULL ] ; t545 [ 1969ULL ] = X [
511ULL ] ; t545 [ 1970ULL ] = t941 ; t545 [ 1971ULL ] = - X [ 476ULL ] ; t545
[ 1972ULL ] = X [ 476ULL ] ; t545 [ 1973ULL ] = X [ 484ULL ] ; t545 [ 1974ULL
] = t929 * 0.1 ; t545 [ 1975ULL ] = X [ 486ULL ] ; t545 [ 1976ULL ] = X [
487ULL ] ; t545 [ 1977ULL ] = X [ 476ULL ] ; t545 [ 1978ULL ] = X [ 512ULL ]
; t545 [ 1979ULL ] = X [ 478ULL ] ; t545 [ 1980ULL ] = X [ 479ULL ] ; t545 [
1981ULL ] = X [ 480ULL ] ; t545 [ 1982ULL ] = X [ 509ULL ] ; t545 [ 1983ULL ]
= X [ 508ULL ] ; t545 [ 1984ULL ] = X [ 478ULL ] ; t545 [ 1985ULL ] = - X [
479ULL ] ; t545 [ 1986ULL ] = X [ 479ULL ] ; t545 [ 1987ULL ] = - X [ 480ULL
] ; t545 [ 1988ULL ] = X [ 480ULL ] ; t545 [ 1989ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pipe_M31 * 0.1 ; t545
[ 1990ULL ] = U_idx_11 ; t545 [ 1991ULL ] = X [ 32ULL ] ; t545 [ 1992ULL ] =
X [ 32ULL ] ; t545 [ 1993ULL ] = X [ 463ULL ] * 1000.0 ; t545 [ 1994ULL ] = X
[ 32ULL ] - 273.15 ; t545 [ 1995ULL ] = X [ 513ULL ] ; t545 [ 1996ULL ] = X [
514ULL ] ; t545 [ 1997ULL ] = X [ 515ULL ] ; t545 [ 1998ULL ] = X [ 516ULL ]
; t545 [ 1999ULL ] = X [ 517ULL ] ; t545 [ 2000ULL ] = X [ 525ULL ] ; t545 [
2001ULL ] = X [ 524ULL ] ; t545 [ 2002ULL ] = X [ 513ULL ] ; t545 [ 2003ULL ]
= X [ 514ULL ] ; t545 [ 2004ULL ] = X [ 515ULL ] ; t545 [ 2005ULL ] = X [
517ULL ] ; t545 [ 2006ULL ] = X [ 518ULL ] ; t545 [ 2007ULL ] = X [ 519ULL ]
; t545 [ 2008ULL ] = X [ 520ULL ] ; t545 [ 2009ULL ] = X [ 521ULL ] ; t545 [
2010ULL ] = X [ 522ULL ] ; t545 [ 2011ULL ] = X [ 523ULL ] ; t545 [ 2012ULL ]
= t938 ; t545 [ 2013ULL ] = X [ 519ULL ] ; t545 [ 2014ULL ] = X [ 520ULL ] ;
t545 [ 2015ULL ] = X [ 521ULL ] ; t545 [ 2016ULL ] = t944 ; t545 [ 2017ULL ]
= ( 1.0 - X [ 524ULL ] ) - X [ 525ULL ] ; t545 [ 2018ULL ] = X [ 526ULL ] ;
t545 [ 2019ULL ] = X [ 527ULL ] ; t545 [ 2020ULL ] = X [ 55ULL ] * 0.1 ; t545
[ 2021ULL ] = X [ 528ULL ] ; t545 [ 2022ULL ] = X [ 529ULL ] ; t545 [ 2023ULL
] = X [ 513ULL ] ; t545 [ 2024ULL ] = X [ 514ULL ] ; t545 [ 2025ULL ] = X [
515ULL ] ; t545 [ 2026ULL ] = X [ 527ULL ] ; t545 [ 2027ULL ] = X [ 55ULL ] *
0.1 ; t545 [ 2028ULL ] = X [ 528ULL ] ; t545 [ 2029ULL ] = X [ 529ULL ] ;
t545 [ 2030ULL ] = X [ 531ULL ] ; t545 [ 2031ULL ] = X [ 534ULL ] ; t545 [
2032ULL ] = X [ 513ULL ] ; t545 [ 2033ULL ] = X [ 514ULL ] ; t545 [ 2034ULL ]
= X [ 515ULL ] ; t545 [ 2035ULL ] = - X [ 517ULL ] ; t545 [ 2036ULL ] = X [
535ULL ] ; t545 [ 2037ULL ] = - X [ 519ULL ] ; t545 [ 2038ULL ] = - X [
520ULL ] ; t545 [ 2039ULL ] = - X [ 521ULL ] ; t545 [ 2040ULL ] = X [ 536ULL
] ; t545 [ 2041ULL ] = X [ 537ULL ] ; t545 [ 2042ULL ] = - X [ 519ULL ] ;
t545 [ 2043ULL ] = X [ 532ULL ] ; t545 [ 2044ULL ] = X [ 533ULL ] ; t545 [
2045ULL ] = X [ 527ULL ] ; t545 [ 2046ULL ] = X [ 55ULL ] * 0.1 ; t545 [
2047ULL ] = X [ 528ULL ] ; t545 [ 2048ULL ] = X [ 529ULL ] ; t545 [ 2049ULL ]
= X [ 530ULL ] ; t545 [ 2050ULL ] = X [ 535ULL ] ; t545 [ 2051ULL ] = X [
519ULL ] ; t545 [ 2052ULL ] = X [ 520ULL ] ; t545 [ 2053ULL ] = X [ 521ULL ]
; t545 [ 2054ULL ] = X [ 536ULL ] ; t545 [ 2055ULL ] = X [ 537ULL ] ; t545 [
2056ULL ] = X [ 519ULL ] ; t545 [ 2057ULL ] = - X [ 519ULL ] ; t545 [ 2058ULL
] = - X [ 517ULL ] ; t545 [ 2059ULL ] = X [ 530ULL ] ; t545 [ 2060ULL ] = - X
[ 520ULL ] ; t545 [ 2061ULL ] = X [ 520ULL ] ; t545 [ 2062ULL ] = - X [
521ULL ] ; t545 [ 2063ULL ] = X [ 521ULL ] ; t545 [ 2064ULL ] = t947 ; t545 [
2065ULL ] = X [ 538ULL ] ; t545 [ 2066ULL ] = intrm_sf_mf_1629 *
0.99999999999999978 / 0.99999999999999978 * 9.5492965855137211 ; t545 [
2067ULL ] = X [ 539ULL ] ; t545 [ 2068ULL ] = X [ 55ULL ] *
99999.999999999985 ; t545 [ 2069ULL ] = X [ 538ULL ] ; t545 [ 2070ULL ] = X [
540ULL ] ; t545 [ 2071ULL ] = X [ 541ULL ] ; t545 [ 2072ULL ] = - X [ 519ULL
] ; t545 [ 2073ULL ] = X [ 539ULL ] ; t545 [ 2074ULL ] = X [ 540ULL ] ; t545
[ 2075ULL ] = X [ 513ULL ] ; t545 [ 2076ULL ] = X [ 514ULL ] ; t545 [ 2077ULL
] = X [ 515ULL ] ; t545 [ 2078ULL ] = X [ 513ULL ] ; t545 [ 2079ULL ] = X [
527ULL ] ; t545 [ 2080ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2081ULL ] = X [
528ULL ] ; t545 [ 2082ULL ] = X [ 529ULL ] ; t545 [ 2083ULL ] = X [ 55ULL ] *
99999.999999999985 ; t545 [ 2084ULL ] = X [ 527ULL ] ; t545 [ 2085ULL ] = X [
513ULL ] ; t545 [ 2086ULL ] = X [ 514ULL ] ; t545 [ 2087ULL ] = X [ 515ULL ]
; t545 [ 2088ULL ] = - X [ 519ULL ] ; t545 [ 2089ULL ] = X [ 527ULL ] ; t545
[ 2090ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2091ULL ] = X [ 528ULL ] ; t545 [
2092ULL ] = X [ 529ULL ] ; t545 [ 2093ULL ] = intrm_sf_mf_1629 *
9.5492965855137211 ; t545 [ 2094ULL ] = X [ 513ULL ] * 0.00347041471455839 ;
t545 [ 2095ULL ] = X [ 541ULL ] ; t545 [ 2096ULL ] = X [ 513ULL ] ; t545 [
2097ULL ] = X [ 513ULL ] * 0.00347041471455839 ; t545 [ 2098ULL ] = X [
527ULL ] ; t545 [ 2099ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2100ULL ] = X [
528ULL ] ; t545 [ 2101ULL ] = X [ 529ULL ] ; t545 [ 2102ULL ] = X [ 403ULL ]
; t545 [ 2103ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2104ULL ] = X [ 404ULL ] ;
t545 [ 2105ULL ] = X [ 405ULL ] ; t545 [ 2106ULL ] = X [ 71ULL ] ; t545 [
2107ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2108ULL ] = X [ 72ULL ] ; t545 [
2109ULL ] = X [ 73ULL ] ; t545 [ 2110ULL ] = X [ 71ULL ] ; t545 [ 2111ULL ] =
X [ 55ULL ] * 0.1 ; t545 [ 2112ULL ] = X [ 72ULL ] ; t545 [ 2113ULL ] = X [
73ULL ] ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545 [ t692 + 2114ULL
] = t626 [ t692 ] ; } t545 [ 2122ULL ] = X [ 71ULL ] ; t545 [ 2123ULL ] = X [
542ULL ] ; t545 [ 2124ULL ] = - X [ 530ULL ] ; t545 [ 2125ULL ] = - X [
418ULL ] ; t545 [ 2126ULL ] = X [ 71ULL ] - 273.15 ; t545 [ 2127ULL ] = X [
72ULL ] ; t545 [ 2128ULL ] = X [ 544ULL ] ; t545 [ 2129ULL ] = X [ 73ULL ] ;
t545 [ 2130ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2131ULL ] = t956 ; t545 [
2132ULL ] = X [ 543ULL ] ; t545 [ 2133ULL ] = X [ 71ULL ] ; t545 [ 2134ULL ]
= X [ 72ULL ] ; t545 [ 2135ULL ] = X [ 73ULL ] ; t545 [ 2136ULL ] = t957 ;
t545 [ 2137ULL ] = X [ 527ULL ] ; t545 [ 2138ULL ] = X [ 55ULL ] * 0.1 ; t545
[ 2139ULL ] = X [ 528ULL ] ; t545 [ 2140ULL ] = X [ 529ULL ] ; t545 [ 2141ULL
] = - X [ 530ULL ] ; t545 [ 2142ULL ] = X [ 546ULL ] ; t545 [ 2143ULL ] = - X
[ 519ULL ] ; t545 [ 2144ULL ] = - X [ 520ULL ] ; t545 [ 2145ULL ] = - X [
521ULL ] ; t545 [ 2146ULL ] = X [ 547ULL ] ; t545 [ 2147ULL ] = X [ 548ULL ]
; t545 [ 2148ULL ] = X [ 403ULL ] ; t545 [ 2149ULL ] = X [ 55ULL ] * 0.1 ;
t545 [ 2150ULL ] = X [ 404ULL ] ; t545 [ 2151ULL ] = X [ 405ULL ] ; t545 [
2152ULL ] = - X [ 418ULL ] ; t545 [ 2153ULL ] = X [ 549ULL ] ; t545 [ 2154ULL
] = - X [ 413ULL ] ; t545 [ 2155ULL ] = - X [ 420ULL ] ; t545 [ 2156ULL ] = -
X [ 421ULL ] ; t545 [ 2157ULL ] = X [ 550ULL ] ; t545 [ 2158ULL ] = X [
551ULL ] ; t545 [ 2159ULL ] = t960 ; t545 [ 2160ULL ] = - X [ 519ULL ] ; t545
[ 2161ULL ] = - X [ 413ULL ] ; t545 [ 2162ULL ] = - X [ 520ULL ] ; t545 [
2163ULL ] = - X [ 420ULL ] ; t545 [ 2164ULL ] = - X [ 521ULL ] ; t545 [
2165ULL ] = - X [ 421ULL ] ; t545 [ 2166ULL ] = ( 1.0 - X [ 73ULL ] ) - X [
72ULL ] ; t545 [ 2167ULL ] = X [ 545ULL ] ; t545 [ 2168ULL ] = X [ 403ULL ] ;
t545 [ 2169ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2170ULL ] = X [ 404ULL ] ; t545
[ 2171ULL ] = X [ 405ULL ] ; t545 [ 2172ULL ] = X [ 403ULL ] ; t545 [ 2173ULL
] = X [ 55ULL ] * 0.1 ; t545 [ 2174ULL ] = X [ 404ULL ] ; t545 [ 2175ULL ] =
X [ 405ULL ] ; t545 [ 2176ULL ] = X [ 413ULL ] ; t545 [ 2177ULL ] = X [
420ULL ] ; t545 [ 2178ULL ] = X [ 421ULL ] ; t545 [ 2179ULL ] = X [ 418ULL ]
* 1000.0 ; t545 [ 2180ULL ] = X [ 418ULL ] ; t545 [ 2181ULL ] = X [ 413ULL ]
; t545 [ 2182ULL ] = X [ 420ULL ] ; t545 [ 2183ULL ] = X [ 421ULL ] ; t545 [
2184ULL ] = X [ 413ULL ] ; t545 [ 2185ULL ] = U_idx_12 ; t545 [ 2186ULL ] =
t948 * 9.5492965855137211 ; t545 [ 2187ULL ] = X [ 403ULL ] ; t545 [ 2188ULL
] = X [ 55ULL ] * 0.1 ; t545 [ 2189ULL ] = X [ 404ULL ] ; t545 [ 2190ULL ] =
X [ 405ULL ] ; t545 [ 2191ULL ] = X [ 71ULL ] ; t545 [ 2192ULL ] = X [ 71ULL
] ; t545 [ 2193ULL ] = X [ 527ULL ] ; t545 [ 2194ULL ] = X [ 55ULL ] * 0.1 ;
t545 [ 2195ULL ] = X [ 528ULL ] ; t545 [ 2196ULL ] = X [ 529ULL ] ; t545 [
2197ULL ] = X [ 513ULL ] ; t545 [ 2198ULL ] = X [ 514ULL ] ; t545 [ 2199ULL ]
= X [ 515ULL ] ; t545 [ 2200ULL ] = X [ 527ULL ] ; t545 [ 2201ULL ] = X [
55ULL ] * 0.1 ; t545 [ 2202ULL ] = X [ 528ULL ] ; t545 [ 2203ULL ] = X [
529ULL ] ; t545 [ 2204ULL ] = t955 * 1000.0 ; t545 [ 2205ULL ] = t955 *
1111.1111111111111 ; t545 [ 2206ULL ] = t955 * 1111.1111111111111 ; t545 [
2207ULL ] = - ( X [ 55ULL ] - 1.01325 ) * 99999.999999999985 ; t545 [ 2208ULL
] = X [ 552ULL ] * 1.0E-6 ; t545 [ 2209ULL ] = t955 * 1000.0 ; t545 [ 2210ULL
] = X [ 513ULL ] ; t545 [ 2211ULL ] = X [ 514ULL ] ; t545 [ 2212ULL ] = X [
515ULL ] ; t545 [ 2213ULL ] = X [ 527ULL ] ; t545 [ 2214ULL ] = X [ 55ULL ] *
0.1 ; t545 [ 2215ULL ] = X [ 528ULL ] ; t545 [ 2216ULL ] = X [ 529ULL ] ;
t545 [ 2217ULL ] = - ( X [ 55ULL ] - 1.01325 ) * 99999.999999999985 ; t545 [
2218ULL ] = X [ 513ULL ] - X [ 527ULL ] ; t545 [ 2219ULL ] = X [ 527ULL ] ;
t545 [ 2220ULL ] = X [ 55ULL ] * 0.1 ; t545 [ 2221ULL ] = X [ 528ULL ] ; t545
[ 2222ULL ] = X [ 529ULL ] ; t545 [ 2223ULL ] = X [ 527ULL ] ; t545 [ 2224ULL
] = X [ 55ULL ] * 0.1 ; t545 [ 2225ULL ] = X [ 528ULL ] ; t545 [ 2226ULL ] =
X [ 529ULL ] ; t545 [ 2227ULL ] = - X [ 530ULL ] ; t545 [ 2228ULL ] = X [
552ULL ] * 1.0E-6 ; t545 [ 2229ULL ] = - X [ 519ULL ] ; t545 [ 2230ULL ] = -
X [ 520ULL ] ; t545 [ 2231ULL ] = - X [ 521ULL ] ; t545 [ 2232ULL ] =
U_idx_12 ; t545 [ 2233ULL ] = X [ 466ULL ] ; t545 [ 2234ULL ] = X [ 38ULL ] *
0.1 ; t545 [ 2235ULL ] = X [ 467ULL ] ; t545 [ 2236ULL ] = X [ 468ULL ] ;
t545 [ 2237ULL ] = X [ 278ULL ] ; t545 [ 2238ULL ] = X [ 38ULL ] * 0.1 ; t545
[ 2239ULL ] = X [ 279ULL ] ; t545 [ 2240ULL ] = X [ 280ULL ] ; t545 [ 2241ULL
] = X [ 466ULL ] ; t545 [ 2242ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2243ULL ] =
X [ 467ULL ] ; t545 [ 2244ULL ] = X [ 468ULL ] ; t545 [ 2245ULL ] = X [
553ULL ] ; t545 [ 2246ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2247ULL ] = X [
554ULL ] ; t545 [ 2248ULL ] = X [ 555ULL ] ; t545 [ 2249ULL ] = X [ 278ULL ]
; t545 [ 2250ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2251ULL ] = X [ 279ULL ] ;
t545 [ 2252ULL ] = X [ 280ULL ] ; t545 [ 2253ULL ] = X [ 74ULL ] ; t545 [
2254ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2255ULL ] = X [ 75ULL ] ; t545 [
2256ULL ] = X [ 76ULL ] ; for ( t692 = 0ULL ; t692 < 8ULL ; t692 ++ ) { t545
[ t692 + 2257ULL ] = t643 [ t692 ] ; } t545 [ 2265ULL ] = X [ 74ULL ] ; t545
[ 2266ULL ] = X [ 556ULL ] ; t545 [ 2267ULL ] = - X [ 497ULL ] ; t545 [
2268ULL ] = X [ 560ULL ] ; t545 [ 2269ULL ] = - X [ 293ULL ] ; t545 [ 2270ULL
] = X [ 74ULL ] - 273.15 ; t545 [ 2271ULL ] = X [ 75ULL ] ; t545 [ 2272ULL ]
= X [ 558ULL ] ; t545 [ 2273ULL ] = X [ 76ULL ] ; t545 [ 2274ULL ] = X [
38ULL ] * 0.1 ; t545 [ 2275ULL ] = t963 ; t545 [ 2276ULL ] = X [ 557ULL ] ;
t545 [ 2277ULL ] = X [ 74ULL ] ; t545 [ 2278ULL ] = X [ 75ULL ] ; t545 [
2279ULL ] = X [ 76ULL ] ; t545 [ 2280ULL ] = t964 ; t545 [ 2281ULL ] = X [
466ULL ] ; t545 [ 2282ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2283ULL ] = X [
467ULL ] ; t545 [ 2284ULL ] = X [ 468ULL ] ; t545 [ 2285ULL ] = - X [ 497ULL
] ; t545 [ 2286ULL ] = X [ 561ULL ] ; t545 [ 2287ULL ] = - X [ 492ULL ] ;
t545 [ 2288ULL ] = - X [ 502ULL ] ; t545 [ 2289ULL ] = - X [ 503ULL ] ; t545
[ 2290ULL ] = X [ 562ULL ] ; t545 [ 2291ULL ] = X [ 563ULL ] ; t545 [ 2292ULL
] = X [ 553ULL ] ; t545 [ 2293ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2294ULL ] =
X [ 554ULL ] ; t545 [ 2295ULL ] = X [ 555ULL ] ; t545 [ 2296ULL ] = X [
560ULL ] ; t545 [ 2297ULL ] = X [ 564ULL ] ; t545 [ 2298ULL ] = t965 ; t545 [
2299ULL ] = X [ 211ULL ] ; t545 [ 2300ULL ] = X [ 213ULL ] ; t545 [ 2301ULL ]
= X [ 565ULL ] ; t545 [ 2302ULL ] = X [ 566ULL ] ; t545 [ 2303ULL ] = X [
278ULL ] ; t545 [ 2304ULL ] = X [ 38ULL ] * 0.1 ; t545 [ 2305ULL ] = X [
279ULL ] ; t545 [ 2306ULL ] = X [ 280ULL ] ; t545 [ 2307ULL ] = - X [ 293ULL
] ; t545 [ 2308ULL ] = X [ 567ULL ] ; t545 [ 2309ULL ] = - X [ 288ULL ] ;
t545 [ 2310ULL ] = - X [ 295ULL ] ; t545 [ 2311ULL ] = - X [ 296ULL ] ; t545
[ 2312ULL ] = X [ 568ULL ] ; t545 [ 2313ULL ] = X [ 569ULL ] ; t545 [ 2314ULL
] = t968 ; t545 [ 2315ULL ] = - X [ 492ULL ] ; t545 [ 2316ULL ] = t965 ; t545
[ 2317ULL ] = - X [ 288ULL ] ; t545 [ 2318ULL ] = - X [ 502ULL ] ; t545 [
2319ULL ] = X [ 211ULL ] ; t545 [ 2320ULL ] = - X [ 295ULL ] ; t545 [ 2321ULL
] = - X [ 503ULL ] ; t545 [ 2322ULL ] = X [ 213ULL ] ; t545 [ 2323ULL ] = - X
[ 296ULL ] ; t545 [ 2324ULL ] = ( 1.0 - X [ 76ULL ] ) - X [ 75ULL ] ; t545 [
2325ULL ] = X [ 559ULL ] ; t545 [ 2326ULL ] = X [ 175ULL ] ; t545 [ 2327ULL ]
= X [ 176ULL ] * 0.1 ; t545 [ 2328ULL ] = X [ 177ULL ] ; t545 [ 2329ULL ] = X
[ 178ULL ] ; t545 [ 2330ULL ] = X [ 553ULL ] ; t545 [ 2331ULL ] = X [ 38ULL ]
* 0.1 ; t545 [ 2332ULL ] = X [ 554ULL ] ; t545 [ 2333ULL ] = X [ 555ULL ] ;
t545 [ 2334ULL ] = X [ 570ULL ] ; t545 [ 2335ULL ] = X [ 573ULL ] ; t545 [
2336ULL ] = X [ 175ULL ] ; t545 [ 2337ULL ] = X [ 176ULL ] * 0.1 ; t545 [
2338ULL ] = X [ 177ULL ] ; t545 [ 2339ULL ] = X [ 178ULL ] ; t545 [ 2340ULL ]
= X [ 208ULL ] ; t545 [ 2341ULL ] = X [ 574ULL ] ; t545 [ 2342ULL ] = t965 ;
t545 [ 2343ULL ] = X [ 211ULL ] ; t545 [ 2344ULL ] = X [ 213ULL ] ; t545 [
2345ULL ] = X [ 575ULL ] ; t545 [ 2346ULL ] = X [ 576ULL ] ; t545 [ 2347ULL ]
= t965 ; t545 [ 2348ULL ] = X [ 571ULL ] ; t545 [ 2349ULL ] = X [ 572ULL ] ;
t545 [ 2350ULL ] = X [ 553ULL ] ; t545 [ 2351ULL ] = X [ 38ULL ] * 0.1 ; t545
[ 2352ULL ] = X [ 554ULL ] ; t545 [ 2353ULL ] = X [ 555ULL ] ; t545 [ 2354ULL
] = - X [ 560ULL ] ; t545 [ 2355ULL ] = X [ 574ULL ] ; t545 [ 2356ULL ] = -
t965 ; t545 [ 2357ULL ] = - X [ 211ULL ] ; t545 [ 2358ULL ] = - X [ 213ULL ]
; t545 [ 2359ULL ] = X [ 575ULL ] ; t545 [ 2360ULL ] = X [ 576ULL ] ; t545 [
2361ULL ] = - t965 ; t545 [ 2362ULL ] = t965 ; t545 [ 2363ULL ] = X [ 208ULL
] ; t545 [ 2364ULL ] = - X [ 560ULL ] ; t545 [ 2365ULL ] = X [ 211ULL ] ;
t545 [ 2366ULL ] = - X [ 211ULL ] ; t545 [ 2367ULL ] = X [ 213ULL ] ; t545 [
2368ULL ] = - X [ 213ULL ] ; t545 [ 2369ULL ] = t962 ; t545 [ 2370ULL ] =
U_idx_4 ; t545 [ 2371ULL ] = U_idx_4 * 0.01 ; t545 [ 2372ULL ] = X [ 74ULL ]
; t545 [ 2373ULL ] = X [ 74ULL ] ; t545 [ 2374ULL ] = X [ 175ULL ] ; t545 [
2375ULL ] = X [ 176ULL ] * 0.1 ; t545 [ 2376ULL ] = X [ 177ULL ] ; t545 [
2377ULL ] = X [ 178ULL ] ; t545 [ 2378ULL ] = U_idx_4 ; t545 [ 2379ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 ; t545 [
2380ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2381ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2382ULL ] = X [ 20ULL ] ; t545 [
2383ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_x0 * 1.0E-9 ;
t545 [ 2384ULL ] = Fuel_Cell_Boost_Converter_L_i ; t545 [ 2385ULL ] =
Fuel_Cell_Boost_Converter_L_i ; t545 [ 2386ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2387ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2388ULL ] =
Fuel_Cell_Boost_Converter_L_i ; t545 [ 2389ULL ] = - X [ 173ULL ] ; t545 [
2390ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2391ULL ] = t970 ; t545
[ 2392ULL ] = X [ 464ULL ] ; t545 [ 2393ULL ] = - ( X [ 173ULL ] * X [ 464ULL
] ) ; t545 [ 2394ULL ] = - X [ 173ULL ] ; t545 [ 2395ULL ] = t970 ; t545 [
2396ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ;
t545 [ 2397ULL ] = X [ 173ULL ] * - 0.001 ; t545 [ 2398ULL ] = X [ 173ULL ] *
X [ 173ULL ] * 0.001 ; t545 [ 2399ULL ] = Fuel_Cell_Boost_Converter_L_p_v ;
t545 [ 2400ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2401ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2402ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Fuel_Cell_Stack_Membra60 ; t545 [
2403ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2404ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2405ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t545 [ 2406ULL ] = X [ 5ULL ] ; t545 [
2407ULL ] = U_idx_13 ; t545 [ 2408ULL ] = X [ 5ULL ] ; t545 [ 2409ULL ] =
t825 * 1000.0 ; t545 [ 2410ULL ] = t825 * 1000.0 ; t545 [ 2411ULL ] = - X [
5ULL ] ; t545 [ 2412ULL ] = X [ 5ULL ] ; t545 [ 2413ULL ] = t825 * 1.0E+6 ;
t545 [ 2414ULL ] = t825 * 1000.0 ; t545 [ 2415ULL ] =
Fuel_Cell_Current_Sensor1_I ; t545 [ 2416ULL ] = t825 * 1.0E+6 ; t545 [
2417ULL ] = X [ 5ULL ] ; t545 [ 2418ULL ] = X [ 5ULL ] ; t545 [ 2419ULL ] = X
[ 577ULL ] * 1000.0 ; t545 [ 2420ULL ] = X [ 5ULL ] ; t545 [ 2421ULL ] =
Fuel_Cell_Current_Sensor1_I ; t545 [ 2422ULL ] = X [ 89ULL ] ; t545 [ 2423ULL
] = X [ 89ULL ] ; t545 [ 2424ULL ] = X [ 89ULL ] ; t545 [ 2425ULL ] = X [
89ULL ] ; t545 [ 2426ULL ] = X [ 174ULL ] ; t545 [ 2427ULL ] = X [ 174ULL ] ;
t545 [ 2428ULL ] = X [ 89ULL ] ; t545 [ 2429ULL ] = X [ 89ULL ] ; t545 [
2430ULL ] = X [ 174ULL ] ; t545 [ 2431ULL ] = X [ 89ULL ] ; t545 [ 2432ULL ]
= X [ 89ULL ] ; t545 [ 2433ULL ] = X [ 89ULL ] ; t545 [ 2434ULL ] = X [ 89ULL
] ; t545 [ 2435ULL ] = X [ 89ULL ] ; t545 [ 2436ULL ] = X [ 13ULL ] ; t545 [
2437ULL ] = X [ 77ULL ] ; t545 [ 2438ULL ] = X [ 77ULL ] ; t545 [ 2439ULL ] =
U_idx_14 ; t545 [ 2440ULL ] = X [ 89ULL ] ; t545 [ 2441ULL ] = X [ 13ULL ] ;
t545 [ 2442ULL ] = X [ 170ULL ] * 1000.0 ; t545 [ 2443ULL ] = X [ 174ULL ] ;
t545 [ 2444ULL ] = X [ 578ULL ] * 1000.0 ; t545 [ 2445ULL ] = X [ 579ULL ] ;
t545 [ 2446ULL ] = X [ 13ULL ] ; t545 [ 2447ULL ] = X [ 580ULL ] ; t545 [
2448ULL ] = X [ 580ULL ] ; t545 [ 2449ULL ] = X [ 581ULL ] ; t545 [ 2450ULL ]
= X [ 78ULL ] ; t545 [ 2451ULL ] = X [ 89ULL ] ; t545 [ 2452ULL ] = X [ 77ULL
] * 9.5492965855137211 ; t545 [ 2453ULL ] = X [ 77ULL ] ; t545 [ 2454ULL ] =
U_idx_15 ; t545 [ 2455ULL ] = - X [ 579ULL ] ; t545 [ 2456ULL ] = U_idx_15 ;
t545 [ 2457ULL ] = X [ 77ULL ] ; t545 [ 2458ULL ] = X [ 77ULL ] ; t545 [
2459ULL ] = - X [ 579ULL ] ; t545 [ 2460ULL ] = - X [ 579ULL ] ; t545 [
2461ULL ] = X [ 77ULL ] ; t545 [ 2462ULL ] = X [ 77ULL ] ; t545 [ 2463ULL ] =
- X [ 579ULL ] ; t545 [ 2464ULL ] = - X [ 579ULL ] ; t545 [ 2465ULL ] = - X [
579ULL ] ; t545 [ 2466ULL ] = X [ 77ULL ] ; t545 [ 2467ULL ] = U_idx_15 ;
t545 [ 2468ULL ] = U_idx_14 ; t545 [ 2469ULL ] = X [ 89ULL ] ; t545 [ 2470ULL
] = U_idx_0 ; t545 [ 2471ULL ] = U_idx_0 ; t545 [ 2472ULL ] = ( ( ( ( X [
0ULL ] * 0.01 + X [ 7ULL ] * 0.0002 ) + X [ 8ULL ] * 2.0E-6 ) - X [ 122ULL ]
) + U_idx_0 * - 0.010202000000000001 ) * 1000.0 ; t545 [ 2473ULL ] = U_idx_0
; t545 [ 2474ULL ] = U_idx_0 ; t545 [ 2475ULL ] = U_idx_0 ; for ( b = 0 ; b <
2476 ; b ++ ) { out . mX [ b ] = t545 [ b ] ; } ( void ) LC ; ( void ) t1253
; return 0 ; }
