#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_duf_p.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_duf_p ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t1 , NeDsMethodOutput * t2 ) { static int32_T
_cg_const_2 [ 116 ] = { 113 , 88 , 8 , 10 , 11 , 91 , 92 , 93 , 94 , 97 , 98
, 99 , 100 , 103 , 104 , 105 , 106 , 109 , 110 , 111 , 112 , 113 , 116 , 117
, 118 , 119 , 120 , 121 , 124 , 125 , 126 , 127 , 128 , 129 , 132 , 133 , 134
, 135 , 136 , 137 , 152 , 153 , 156 , 157 , 163 , 164 , 212 , 213 , 216 , 18
, 19 , 20 , 21 , 70 , 71 , 72 , 73 , 183 , 184 , 185 , 189 , 190 , 192 , 194
, 200 , 545 , 546 , 547 , 558 , 564 , 565 , 566 , 567 , 568 , 569 , 570 , 573
, 574 , 30 , 31 , 32 , 33 , 265 , 265 , 303 , 310 , 323 , 329 , 330 , 331 ,
46 , 47 , 48 , 49 , 382 , 382 , 408 , 409 , 426 , 427 , 428 , 429 , 430 , 431
, 432 , 435 , 438 , 465 , 474 , 491 , 494 , 495 , 497 , 520 , 171 , 172 } ;
PmSparsityPattern out ; int32_T b ; ( void ) t1 ; ( void ) LC ; out = t2 ->
mDUF_P ; out . mNumCol = 16ULL ; out . mNumRow = 582ULL ; out . mJc [ 0 ] = 0
; out . mJc [ 1 ] = 1 ; out . mJc [ 2 ] = 2 ; out . mJc [ 3 ] = 46 ; out .
mJc [ 4 ] = 49 ; out . mJc [ 5 ] = 78 ; out . mJc [ 6 ] = 83 ; out . mJc [ 7
] = 84 ; out . mJc [ 8 ] = 90 ; out . mJc [ 9 ] = 95 ; out . mJc [ 10 ] = 96
; out . mJc [ 11 ] = 107 ; out . mJc [ 12 ] = 113 ; out . mJc [ 13 ] = 114 ;
out . mJc [ 14 ] = 116 ; out . mJc [ 15 ] = 116 ; out . mJc [ 16 ] = 116 ;
for ( b = 0 ; b < 116 ; b ++ ) { out . mIr [ b ] = _cg_const_2 [ b ] ; } (
void ) LC ; ( void ) t2 ; return 0 ; }
