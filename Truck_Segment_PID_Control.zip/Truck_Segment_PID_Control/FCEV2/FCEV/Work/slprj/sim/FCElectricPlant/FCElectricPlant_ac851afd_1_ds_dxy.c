#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_dxy.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_dxy ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t213 , NeDsMethodOutput * t214 ) { ETTS0 b_efOut
; ETTS0 efOut ; ETTS0 g_efOut ; ETTS0 h_efOut ; ETTS0 k_efOut ; ETTS0 l_efOut
; ETTS0 o_efOut ; ETTS0 p_efOut ; ETTS0 t5 ; ETTS0 t6 ; PmRealVector out ;
real_T X [ 582 ] ; real_T c_efOut [ 1 ] ; real_T d_efOut [ 1 ] ; real_T
e_efOut [ 1 ] ; real_T f_efOut [ 1 ] ; real_T i_efOut [ 1 ] ; real_T j_efOut
[ 1 ] ; real_T m_efOut [ 1 ] ; real_T n_efOut [ 1 ] ; real_T q_efOut [ 1 ] ;
real_T r_efOut [ 1 ] ; real_T t72 [ 1 ] ; real_T t180 ; real_T t181 ; real_T
t182 ; real_T t183 ; real_T t184 ; real_T t185 ; real_T t186 ; real_T t190 ;
real_T t191 ; real_T t70_idx_0 ; size_t t10 [ 1 ] ; size_t t12 [ 1 ] ; size_t
t9 [ 1 ] ; int32_T b ; for ( b = 0 ; b < 582 ; b ++ ) { X [ b ] = t213 -> mX
. mX [ b ] ; } out = t214 -> mDXY ; t72 [ 0ULL ] = X [ 92ULL ] ; t9 [ 0 ] =
20ULL ; t10 [ 0 ] = 1ULL ; tlu2_linear_nearest_prelookup ( & efOut . mField0
[ 0ULL ] , & efOut . mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField2 , & t72 [ 0ULL ] , & t9 [ 0ULL ] , &
t10 [ 0ULL ] ) ; t6 = efOut ; t72 [ 0ULL ] = X [ 93ULL ] ; t12 [ 0 ] = 19ULL
; tlu2_linear_nearest_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t72 [ 0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t5 =
b_efOut ; tlu2_2d_linear_nearest_value ( & c_efOut [ 0ULL ] , & t6 . mField1
[ 0ULL ] , & t6 . mField2 [ 0ULL ] , & t5 . mField0 [ 0ULL ] , & t5 . mField2
[ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t9 [ 0ULL ] , &
t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 = c_efOut [ 0 ] ; t180 =
t70_idx_0 ; tlu2_2d_linear_nearest_value ( & d_efOut [ 0ULL ] , & t6 .
mField0 [ 0ULL ] , & t6 . mField2 [ 0ULL ] , & t5 . mField1 [ 0ULL ] , & t5 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t9 [
0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 = d_efOut [ 0 ] ; t181
= t70_idx_0 ; tlu2_2d_linear_nearest_value ( & e_efOut [ 0ULL ] , & t6 .
mField1 [ 0ULL ] , & t6 . mField2 [ 0ULL ] , & t5 . mField0 [ 0ULL ] , & t5 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL
] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 = e_efOut [ 0 ] ; t182 =
t70_idx_0 ; tlu2_2d_linear_nearest_value ( & f_efOut [ 0ULL ] , & t6 .
mField0 [ 0ULL ] , & t6 . mField2 [ 0ULL ] , & t5 . mField1 [ 0ULL ] , & t5 .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL
] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 = f_efOut [ 0 ] ; t183 =
t70_idx_0 ; t72 [ 0ULL ] = X [ 101ULL ] ; tlu2_linear_nearest_prelookup ( &
g_efOut . mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField2 , & t72 [
0ULL ] , & t9 [ 0ULL ] , & t10 [ 0ULL ] ) ; t5 = g_efOut ; t72 [ 0ULL ] = X [
102ULL ] ; tlu2_linear_nearest_prelookup ( & h_efOut . mField0 [ 0ULL ] , &
h_efOut . mField1 [ 0ULL ] , & h_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField3 , & t72 [ 0ULL ] , & t12 [ 0ULL ] ,
& t10 [ 0ULL ] ) ; t6 = h_efOut ; tlu2_2d_linear_nearest_value ( & i_efOut [
0ULL ] , & t5 . mField1 [ 0ULL ] , & t5 . mField2 [ 0ULL ] , & t6 . mField0 [
0ULL ] , & t6 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 =
i_efOut [ 0 ] ; t184 = t70_idx_0 ; tlu2_2d_linear_nearest_value ( & j_efOut [
0ULL ] , & t5 . mField0 [ 0ULL ] , & t5 . mField2 [ 0ULL ] , & t6 . mField1 [
0ULL ] , & t6 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t70_idx_0 =
j_efOut [ 0 ] ; t185 = t70_idx_0 ; t72 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_nearest_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t72 [ 0ULL ] , & t9 [ 0ULL ] , & t10 [ 0ULL ] ) ; t6 =
k_efOut ; t72 [ 0ULL ] = X [ 111ULL ] ; tlu2_linear_nearest_prelookup ( &
l_efOut . mField0 [ 0ULL ] , & l_efOut . mField1 [ 0ULL ] , & l_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t72 [
0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t5 = l_efOut ;
tlu2_2d_linear_nearest_value ( & m_efOut [ 0ULL ] , & t6 . mField1 [ 0ULL ] ,
& t6 . mField2 [ 0ULL ] , & t5 . mField0 [ 0ULL ] , & t5 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ]
, & t10 [ 0ULL ] ) ; t70_idx_0 = m_efOut [ 0 ] ; t186 = t70_idx_0 ;
tlu2_2d_linear_nearest_value ( & n_efOut [ 0ULL ] , & t6 . mField0 [ 0ULL ] ,
& t6 . mField2 [ 0ULL ] , & t5 . mField1 [ 0ULL ] , & t5 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ]
, & t10 [ 0ULL ] ) ; t70_idx_0 = n_efOut [ 0 ] ; t72 [ 0ULL ] = X [ 119ULL ]
; tlu2_linear_nearest_prelookup ( & o_efOut . mField0 [ 0ULL ] , & o_efOut .
mField1 [ 0ULL ] , & o_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t72 [ 0ULL ] , & t9 [ 0ULL ] , & t10 [ 0ULL ] ) ; t6 =
o_efOut ; t72 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_nearest_prelookup ( &
p_efOut . mField0 [ 0ULL ] , & p_efOut . mField1 [ 0ULL ] , & p_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t72 [
0ULL ] , & t12 [ 0ULL ] , & t10 [ 0ULL ] ) ; t5 = p_efOut ;
tlu2_2d_linear_nearest_value ( & q_efOut [ 0ULL ] , & t6 . mField1 [ 0ULL ] ,
& t6 . mField2 [ 0ULL ] , & t5 . mField0 [ 0ULL ] , & t5 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ]
, & t10 [ 0ULL ] ) ; t72 [ 0 ] = q_efOut [ 0 ] ; t190 = - t72 [ 0ULL ] ;
tlu2_2d_linear_nearest_value ( & r_efOut [ 0ULL ] , & t6 . mField0 [ 0ULL ] ,
& t6 . mField2 [ 0ULL ] , & t5 . mField1 [ 0ULL ] , & t5 . mField2 [ 0ULL ] ,
( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t9 [ 0ULL ] , & t12 [ 0ULL ]
, & t10 [ 0ULL ] ) ; t72 [ 0 ] = r_efOut [ 0 ] ; t191 = - t72 [ 0ULL ] ; out
. mX [ 0 ] = - 0.2 ; out . mX [ 1 ] = - 0.002 ; out . mX [ 2 ] = 1.0 ; out .
mX [ 3 ] = 1.0 ; out . mX [ 4 ] = - 1.0E-6 ; out . mX [ 5 ] = 1.0 ; out . mX
[ 6 ] = 1.0 ; out . mX [ 7 ] = 0.0 ; out . mX [ 8 ] = 0.0 ; out . mX [ 9 ] =
0.0 ; out . mX [ 10 ] = 0.0 ; out . mX [ 11 ] = 0.0 ; out . mX [ 12 ] = 0.0 ;
out . mX [ 13 ] = - X [ 552ULL ] * 0.0001 * 1111.1111111111111 ; out . mX [
14 ] = - 1.0 ; out . mX [ 15 ] = 1.0 ; out . mX [ 16 ] = 1.0 ; out . mX [ 17
] = - 1.0 ; out . mX [ 18 ] = 1.0 ; out . mX [ 19 ] = 1.0 ; out . mX [ 20 ] =
1.0 ; out . mX [ 21 ] = 1.0 ; out . mX [ 22 ] = t180 * 0.001 ; out . mX [ 23
] = t182 ; out . mX [ 24 ] = - X [ 143ULL ] * 0.0001 * 1111.1111111111111 ;
out . mX [ 25 ] = t181 * 0.001 ; out . mX [ 26 ] = t183 ; out . mX [ 27 ] =
1000.0 ; out . mX [ 28 ] = 1.0 ; out . mX [ 29 ] = t184 ; out . mX [ 30 ] =
t185 ; out . mX [ 31 ] = 1000.0 ; out . mX [ 32 ] = t186 ; out . mX [ 33 ] =
t70_idx_0 ; out . mX [ 34 ] = 1000.0 ; out . mX [ 35 ] = 1.0 ; out . mX [ 36
] = - t190 ; out . mX [ 37 ] = - t191 ; out . mX [ 38 ] = - 1000.0 ; out . mX
[ 39 ] = 1000.0 ; out . mX [ 40 ] = 1000.0 ; out . mX [ 41 ] = 1000.0 ; out .
mX [ 42 ] = X [ 143ULL ] * 0.0001 * 1111.1111111111111 ; out . mX [ 43 ] = (
X [ 138ULL ] - X [ 93ULL ] ) * 0.0001 * 1111.1111111111111 ; out . mX [ 44 ]
= 1.0E-9 ; out . mX [ 45 ] = - 1.0E-15 ; out . mX [ 46 ] = - 1.0E-6 ; out .
mX [ 47 ] = 1.0 ; out . mX [ 48 ] = 1.0 ; out . mX [ 49 ] = 1.0 ; out . mX [
50 ] = 1.0 ; out . mX [ 51 ] = 0.0 ; out . mX [ 52 ] = 1.0 ; out . mX [ 53 ]
= 0.0 ; out . mX [ 54 ] = 0.0 ; out . mX [ 55 ] = 0.0 ; out . mX [ 56 ] = 1.0
; out . mX [ 57 ] = 1.0 ; out . mX [ 58 ] = 0.0 ; out . mX [ 59 ] = 1.0 ; out
. mX [ 60 ] = 0.0 ; out . mX [ 61 ] = 0.0 ; out . mX [ 62 ] = 0.0 ; out . mX
[ 63 ] = 1.0 ; out . mX [ 64 ] = 1.0 ; out . mX [ 65 ] = - X [ 460ULL ] *
0.0001 * 1111.1111111111111 ; out . mX [ 66 ] = ( 1.01325 - X [ 451ULL ] ) *
0.0001 * 1111.1111111111111 ; out . mX [ 67 ] = 1.0 ; out . mX [ 68 ] = - 1.0
; out . mX [ 69 ] = - ( X [ 55ULL ] - 1.01325 ) * 0.0001 * 1111.1111111111111
; out . mX [ 70 ] = - 1.0 ; ( void ) LC ; ( void ) t214 ; return 0 ; }
