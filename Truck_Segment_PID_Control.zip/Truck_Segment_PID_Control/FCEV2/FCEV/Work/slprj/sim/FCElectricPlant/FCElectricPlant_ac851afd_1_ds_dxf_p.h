#ifdef __cplusplus
extern "C" {
#endif
#ifndef FCELECTRICPLANT_AC851AFD_1_DS_DXF_P_H
#define FCELECTRICPLANT_AC851AFD_1_DS_DXF_P_H 1
int32_T FCElectricPlant_ac851afd_1_ds_dxf_p ( const NeDynamicSystem * sys ,
const NeDynamicSystemInput * Q , NeDsMethodOutput * M ) ;
#endif
#ifdef __cplusplus
}
#endif
