#ifndef RTW_HEADER_FCElectricPlant_capi_h_
#define RTW_HEADER_FCElectricPlant_capi_h_
#include "FCElectricPlant.h"
extern void FCElectricPlant_InitializeDataMapInfo ( m5e23pbc2h * const
lmamcwn3a2 , ammy3t1awn * localDW , fw3fcrujzt * localX , void * sysRanPtr ,
int contextTid ) ;
#endif
