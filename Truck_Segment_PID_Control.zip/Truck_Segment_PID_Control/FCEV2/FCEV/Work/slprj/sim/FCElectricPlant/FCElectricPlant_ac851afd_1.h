#ifndef __FCElectricPlant_ac851afd_1_h__
#define __FCElectricPlant_ac851afd_1_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void FCElectricPlant_ac851afd_1_dae ( NeDae * * dae , const
NeModelParameters * modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
