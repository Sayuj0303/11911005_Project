#include "ne_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_sys_struct.h"
#include "FCElectricPlant_ac851afd_1_ds_obs_act.h"
#include "FCElectricPlant_ac851afd_1_ds.h"
#include "FCElectricPlant_ac851afd_1_ds_externals.h"
#include "FCElectricPlant_ac851afd_1_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T FCElectricPlant_ac851afd_1_ds_obs_act ( const NeDynamicSystem * LC ,
const NeDynamicSystemInput * t364 , NeDsMethodOutput * t365 ) { ETTS0 b_efOut
; ETTS0 bb_efOut ; ETTS0 db_efOut ; ETTS0 efOut ; ETTS0 f_efOut ; ETTS0
fb_efOut ; ETTS0 g_efOut ; ETTS0 hb_efOut ; ETTS0 jb_efOut ; ETTS0 k_efOut ;
ETTS0 l_efOut ; ETTS0 lb_efOut ; ETTS0 nb_efOut ; ETTS0 p_efOut ; ETTS0
pb_efOut ; ETTS0 q_efOut ; ETTS0 rb_efOut ; ETTS0 t12 ; ETTS0 t16 ; ETTS0 t8
; ETTS0 u_efOut ; ETTS0 w_efOut ; ETTS0 y_efOut ; PmRealVector out ; real_T
t141 [ 2616 ] ; real_T X [ 582 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ 8 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 8 ] ; real_T
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 8 ] ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ 8 ] ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 8 ]
; real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 8
] ; real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ 8
] ; real_T t154 [ 8 ] ; real_T t159 [ 8 ] ; real_T t164 [ 8 ] ; real_T t166 [
8 ] ; real_T t168 [ 8 ] ; real_T t170 [ 8 ] ; real_T ab_efOut [ 1 ] ; real_T
c_efOut [ 1 ] ; real_T cb_efOut [ 1 ] ; real_T d_efOut [ 1 ] ; real_T e_efOut
[ 1 ] ; real_T eb_efOut [ 1 ] ; real_T gb_efOut [ 1 ] ; real_T h_efOut [ 1 ]
; real_T i_efOut [ 1 ] ; real_T ib_efOut [ 1 ] ; real_T j_efOut [ 1 ] ;
real_T kb_efOut [ 1 ] ; real_T m_efOut [ 1 ] ; real_T mb_efOut [ 1 ] ; real_T
n_efOut [ 1 ] ; real_T o_efOut [ 1 ] ; real_T ob_efOut [ 1 ] ; real_T
qb_efOut [ 1 ] ; real_T r_efOut [ 1 ] ; real_T s_efOut [ 1 ] ; real_T
sb_efOut [ 1 ] ; real_T t171 [ 1 ] ; real_T t_efOut [ 1 ] ; real_T v_efOut [
1 ] ; real_T x_efOut [ 1 ] ; real_T Battery_System_Battery_Table_Based_Q ;
real_T Battery_System_DC_DC_Converter_i1 ; real_T
Battery_System_DC_DC_Converter_power_dissipated ; real_T
Electrical_Cooling_System_Tank_Convection_HLiq_Q ; real_T
Electrical_Cooling_System_Tank_Tank_level ; real_T
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co ; real_T
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 ; real_T
Fuel_Cell_Boost_Converter_L_i ; real_T Fuel_Cell_Boost_Converter_L_n_v ;
real_T Fuel_Cell_Boost_Converter_L_p_v ; real_T Fuel_Cell_Current_Sensor1_I ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_16 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 ;
real_T Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ;
real_T U_idx_0 ; real_T U_idx_1 ; real_T U_idx_10 ; real_T U_idx_11 ; real_T
U_idx_12 ; real_T U_idx_13 ; real_T U_idx_14 ; real_T U_idx_15 ; real_T
U_idx_2 ; real_T U_idx_3 ; real_T U_idx_4 ; real_T U_idx_5 ; real_T U_idx_6 ;
real_T U_idx_7 ; real_T U_idx_8 ; real_T U_idx_9 ; real_T intrm_sf_mf_1383 ;
real_T intrm_sf_mf_1660 ; real_T t169_idx_0 ; real_T t206 ; real_T t207 ;
real_T t208 ; real_T t209 ; real_T t210 ; real_T t214 ; real_T t218 ; real_T
t219 ; real_T t222 ; real_T t223 ; real_T t224 ; real_T t227 ; real_T t228 ;
real_T t229 ; real_T t230 ; real_T t231 ; real_T t232 ; real_T t234 ; real_T
t235 ; real_T t237 ; real_T t240 ; real_T t243 ; real_T t244 ; real_T t252 ;
real_T t253 ; real_T t256 ; real_T t266 ; real_T t268 ; real_T t273 ; real_T
t274 ; real_T t276 ; real_T t278 ; real_T t279 ; real_T t281 ; real_T t284 ;
real_T t285 ; real_T t286 ; real_T t287 ; real_T t289 ; real_T t294 ; real_T
t295 ; real_T t296 ; real_T t301 ; real_T t303 ; real_T t305 ; real_T t312 ;
size_t t23 [ 1 ] ; size_t t25 [ 1 ] ; size_t t82 [ 1 ] ; size_t t197 ;
int32_T b ; U_idx_0 = t364 -> mU . mX [ 0 ] ; U_idx_1 = t364 -> mU . mX [ 1 ]
; U_idx_2 = t364 -> mU . mX [ 2 ] ; U_idx_3 = t364 -> mU . mX [ 3 ] ; U_idx_4
= t364 -> mU . mX [ 4 ] ; U_idx_5 = t364 -> mU . mX [ 5 ] ; U_idx_6 = t364 ->
mU . mX [ 6 ] ; U_idx_7 = t364 -> mU . mX [ 7 ] ; U_idx_8 = t364 -> mU . mX [
8 ] ; U_idx_9 = t364 -> mU . mX [ 9 ] ; U_idx_10 = t364 -> mU . mX [ 10 ] ;
U_idx_11 = t364 -> mU . mX [ 11 ] ; U_idx_12 = t364 -> mU . mX [ 12 ] ;
U_idx_13 = t364 -> mU . mX [ 13 ] ; U_idx_14 = t364 -> mU . mX [ 14 ] ;
U_idx_15 = t364 -> mU . mX [ 15 ] ; for ( b = 0 ; b < 582 ; b ++ ) { X [ b ]
= t364 -> mX . mX [ b ] ; } out = t365 -> mOBS_ACT ;
Battery_System_Battery_Table_Based_Q = X [ 0ULL ] * - 0.01 + U_idx_0 * 0.01 ;
Battery_System_DC_DC_Converter_i1 = - X [ 79ULL ] - U_idx_1 ;
Battery_System_DC_DC_Converter_power_dissipated = ( ( ( real_T ) (
Battery_System_DC_DC_Converter_i1 >= 0.0 ) *
Battery_System_DC_DC_Converter_i1 * 1000.0 + ( real_T ) (
Battery_System_DC_DC_Converter_i1 < 0.0 ) * X [ 81ULL ] ) - 0.9 ) /
0.099999999999999978 ; if ( ( real_T ) ( Battery_System_DC_DC_Converter_i1 >=
0.0 ) * Battery_System_DC_DC_Converter_i1 * 1000.0 + ( real_T ) (
Battery_System_DC_DC_Converter_i1 < 0.0 ) * X [ 81ULL ] <= 0.9 ) {
Battery_System_DC_DC_Converter_power_dissipated = 0.0 ; } else {
Battery_System_DC_DC_Converter_power_dissipated = ( real_T ) (
Battery_System_DC_DC_Converter_i1 >= 0.0 ) *
Battery_System_DC_DC_Converter_i1 * 1000.0 + ( real_T ) (
Battery_System_DC_DC_Converter_i1 < 0.0 ) * X [ 81ULL ] >= 1.0 ? 1.0 :
Battery_System_DC_DC_Converter_power_dissipated *
Battery_System_DC_DC_Converter_power_dissipated * 3.0 -
Battery_System_DC_DC_Converter_power_dissipated *
Battery_System_DC_DC_Converter_power_dissipated *
Battery_System_DC_DC_Converter_power_dissipated * 2.0 ; } t206 = ( X [ 4ULL ]
* 0.01 + X [ 5ULL ] * - 0.01 ) + X [ 91ULL ] ; t207 = X [ 4ULL ] * 0.01 + X [
5ULL ] * - 0.01 ; t208 = ( X [ 7ULL ] * - 0.0002 + X [ 8ULL ] * - 2.0E-6 ) +
U_idx_0 * 0.000202 ; t209 = X [ 138ULL ] - X [ 93ULL ] ; t210 = t209 * X [
143ULL ] * 0.0001 ; t214 = X [ 7ULL ] * 0.0002 + U_idx_0 * - 0.0002 ;
Electrical_Cooling_System_Tank_Convection_HLiq_Q = X [ 8ULL ] * 2.0E-6 +
U_idx_0 * - 2.0E-6 ; Electrical_Cooling_System_Tank_Tank_level = X [ 158ULL ]
* - 0.2 + 0.2 ;
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co = X [ 12ULL ]
* 0.89999999999999991 + X [ 17ULL ] * - 0.89999999999999991 ; t171 [ 0ULL ] =
X [ 92ULL ] ; t82 [ 0 ] = 20ULL ; t23 [ 0 ] = 1ULL ;
tlu2_linear_nearest_prelookup ( & efOut . mField0 [ 0ULL ] , & efOut .
mField1 [ 0ULL ] , & efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC
) ) -> mField2 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t12 =
efOut ; t171 [ 0ULL ] = X [ 93ULL ] ; t25 [ 0 ] = 19ULL ;
tlu2_linear_nearest_prelookup ( & b_efOut . mField0 [ 0ULL ] , & b_efOut .
mField1 [ 0ULL ] , & b_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField3 , & t171 [ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t16
= b_efOut ; tlu2_2d_linear_nearest_value ( & c_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , &
t82 [ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = c_efOut [ 0 ]
; Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 =
t169_idx_0 ; tlu2_2d_linear_nearest_value ( & d_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = d_efOut [ 0 ] ;
t218 = t169_idx_0 ; tlu2_2d_linear_nearest_value ( & e_efOut [ 0ULL ] , & t12
. mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = e_efOut [ 0 ] ;
t219 = t169_idx_0 ; t171 [ 0ULL ] = X [ 101ULL ] ;
tlu2_linear_nearest_prelookup ( & f_efOut . mField0 [ 0ULL ] , & f_efOut .
mField1 [ 0ULL ] , & f_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t16
= f_efOut ; t171 [ 0ULL ] = X [ 102ULL ] ; tlu2_linear_nearest_prelookup ( &
g_efOut . mField0 [ 0ULL ] , & g_efOut . mField1 [ 0ULL ] , & g_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t171 [
0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t12 = g_efOut ;
tlu2_2d_linear_nearest_value ( & h_efOut [ 0ULL ] , & t16 . mField0 [ 0ULL ]
, & t16 . mField2 [ 0ULL ] , & t12 . mField0 [ 0ULL ] , & t12 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t82 [ 0ULL ] , &
t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = h_efOut [ 0 ] ; t222 =
t169_idx_0 ; tlu2_2d_linear_nearest_value ( & i_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , & t12 . mField0 [ 0ULL ] , &
t12 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = i_efOut [ 0 ] ;
t223 = t169_idx_0 ; tlu2_2d_linear_nearest_value ( & j_efOut [ 0ULL ] , & t16
. mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , & t12 . mField0 [ 0ULL ] , &
t12 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = j_efOut [ 0 ] ;
t224 = t169_idx_0 ; t171 [ 0ULL ] = X [ 110ULL ] ;
tlu2_linear_nearest_prelookup ( & k_efOut . mField0 [ 0ULL ] , & k_efOut .
mField1 [ 0ULL ] , & k_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t12
= k_efOut ; t171 [ 0ULL ] = X [ 111ULL ] ; tlu2_linear_nearest_prelookup ( &
l_efOut . mField0 [ 0ULL ] , & l_efOut . mField1 [ 0ULL ] , & l_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t171 [
0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t16 = l_efOut ;
tlu2_2d_linear_nearest_value ( & m_efOut [ 0ULL ] , & t12 . mField0 [ 0ULL ]
, & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t82 [ 0ULL ] , &
t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = m_efOut [ 0 ] ; t227 =
t169_idx_0 ; tlu2_2d_linear_nearest_value ( & n_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = n_efOut [ 0 ] ;
t228 = t169_idx_0 ; tlu2_2d_linear_nearest_value ( & o_efOut [ 0ULL ] , & t12
. mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = o_efOut [ 0 ] ;
t229 = t169_idx_0 ; t171 [ 0ULL ] = X [ 119ULL ] ;
tlu2_linear_nearest_prelookup ( & p_efOut . mField0 [ 0ULL ] , & p_efOut .
mField1 [ 0ULL ] , & p_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField2 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t12
= p_efOut ; t171 [ 0ULL ] = X [ 120ULL ] ; tlu2_linear_nearest_prelookup ( &
q_efOut . mField0 [ 0ULL ] , & q_efOut . mField1 [ 0ULL ] , & q_efOut .
mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField3 , & t171 [
0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t16 = q_efOut ;
tlu2_2d_linear_nearest_value ( & r_efOut [ 0ULL ] , & t12 . mField0 [ 0ULL ]
, & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [
0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField11 , & t82 [ 0ULL ] , &
t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = r_efOut [ 0 ] ; t230 =
t169_idx_0 ; tlu2_2d_linear_nearest_value ( & s_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField1 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = s_efOut [ 0 ] ;
t231 = t169_idx_0 ; tlu2_2d_linear_nearest_value ( & t_efOut [ 0ULL ] , & t12
. mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , & t16 . mField0 [ 0ULL ] , &
t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField4 , & t82
[ 0ULL ] , & t25 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = t_efOut [ 0 ] ;
t232 = t169_idx_0 ; Fuel_Cell_Boost_Converter_L_i = X [ 172ULL ] * 1.0E-9 + X
[ 19ULL ] ; Fuel_Cell_Boost_Converter_L_n_v = ( ( X [ 19ULL ] * - 1.0E-6 + X
[ 172ULL ] * - 1.0000000000000011 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ]
; Fuel_Cell_Boost_Converter_L_p_v = ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ]
* - 1.0E-15 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ;
Fuel_Cell_Current_Sensor1_I = X [ 88ULL ] + X [ 174ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 = - X [
198ULL ] + U_idx_4 * - 0.01 ; if ( X [ 23ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh = X [
23ULL ] >= 1.0 ? 1.0 : X [ 23ULL ] ; } if ( X [ 24ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 = X [
24ULL ] >= 1.0 ? 1.0 : X [ 24ULL ] ; } t235 = X [ 21ULL ] * ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh ) -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh * 461.523 ) +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 *
4124.48151675695 ) ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh = X [ 22ULL ]
/ ( t235 == 0.0 ? 1.0E-16 : t235 ) ; t154 [ 0ULL ] = X [ 22ULL ] * 100000.0 ;
t154 [ 1ULL ] = X [ 21ULL ] ; t154 [ 2ULL ] = X [ 206ULL ] ; t154 [ 3ULL ] =
X [ 23ULL ] ; t154 [ 4ULL ] = X [ 201ULL ] ; t154 [ 5ULL ] = X [ 205ULL ] ;
t154 [ 6ULL ] = X [ 24ULL ] ; t154 [ 7ULL ] = X [ 202ULL ] ; for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ t197 ] =
t154 [ t197 ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 = - X [
207ULL ] - X [ 208ULL ] ; if ( 1.0 - X [ 23ULL ] >= 0.01 ) { t234 = 1.0 - X [
23ULL ] ; } else if ( 1.0 - X [ 23ULL ] >= - 0.1 ) { t234 = pmf_exp ( ( ( 1.0
- X [ 23ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t234 =
1.6701700790245661E-7 ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = X [ 24ULL ]
/ ( t234 == 0.0 ? 1.0E-16 : t234 ) * 3827.6794129126583 + 296.802103844292 ;
t171 [ 0ULL ] = X [ 21ULL ] ; t82 [ 0 ] = 52ULL ;
tlu2_linear_linear_prelookup ( & u_efOut . mField0 [ 0ULL ] , & u_efOut .
mField1 [ 0ULL ] , & u_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t8
= u_efOut ; tlu2_1d_linear_linear_value ( & v_efOut [ 0ULL ] , & t8 . mField0
[ 0ULL ] , & t8 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) ->
mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = v_efOut [ 0 ] ;
t234 = pmf_exp ( pmf_log ( X [ 22ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t234 >= 1.0 ) { t235 = ( t234 - 1.0 ) * 461.523 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 ; t235 =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 / ( t235 ==
0.0 ? 1.0E-16 : t235 ) ; } else { t235 = 1.0 ; } t240 = t235 * 0.01 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = ( X [ 23ULL
] - t235 ) / ( t240 == 0.0 ? 1.0E-16 : t240 ) ; if ( X [ 23ULL ] - t235 <=
0.0 ) { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = 0.0
; } else if ( X [ 23ULL ] - t235 >= t235 * 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = X [ 23ULL ]
- t235 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = ( X [ 23ULL
] - t235 ) * (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 * 3.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh *
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 *
7.8539816339744827E-5 / 0.001 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh *= 100000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 = - X [
210ULL ] - X [ 211ULL ] ; t234 = - X [ 212ULL ] - X [ 213ULL ] ; t154 [ 0ULL
] = X [ 230ULL ] ; t154 [ 1ULL ] = X [ 25ULL ] ; t154 [ 2ULL ] = X [ 231ULL ]
; t154 [ 3ULL ] = X [ 27ULL ] ; t154 [ 4ULL ] = X [ 232ULL ] ; t154 [ 5ULL ]
= X [ 233ULL ] ; t154 [ 6ULL ] = X [ 26ULL ] ; t154 [ 7ULL ] = X [ 234ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 0ULL ] = X [
235ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
1ULL ] = X [ 28ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 2ULL ] = X [
236ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
3ULL ] = X [ 30ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 4ULL ] = X [
237ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
5ULL ] = X [ 238ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ 6ULL ] = X [
29ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [
7ULL ] = X [ 239ULL ] ; if ( X [ 27ULL ] <= 0.0 ) { t235 = 0.0 ; } else {
t235 = X [ 27ULL ] >= 1.0 ? 1.0 : X [ 27ULL ] ; } if ( X [ 26ULL ] <= 0.0 ) {
t237 = 0.0 ; } else { t237 = X [ 26ULL ] >= 1.0 ? 1.0 : X [ 26ULL ] ; } t244
= X [ 25ULL ] * ( ( ( ( 1.0 - t235 ) - t237 ) * 296.802103844292 + t235 *
461.523 ) + t237 * 4124.48151675695 ) ; if ( 1.0 - X [ 27ULL ] >= 0.01 ) {
t235 = 1.0 - X [ 27ULL ] ; } else if ( 1.0 - X [ 27ULL ] >= - 0.1 ) { t235 =
pmf_exp ( ( ( 1.0 - X [ 27ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t235 =
1.6701700790245661E-7 ; } t240 = X [ 26ULL ] / ( t235 == 0.0 ? 1.0E-16 : t235
) * 3827.6794129126583 + 296.802103844292 ; t171 [ 0ULL ] = X [ 25ULL ] ;
tlu2_linear_linear_prelookup ( & w_efOut . mField0 [ 0ULL ] , & w_efOut .
mField1 [ 0ULL ] , & w_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = w_efOut ; tlu2_1d_linear_linear_value ( & x_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = x_efOut [ 0
] ; t235 = pmf_exp ( pmf_log ( X [ 31ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t235 >= 1.0 ) { t235 = ( t235 - 1.0 ) * 461.523 + t240 ; t237 = t240 / ( t235
== 0.0 ? 1.0E-16 : t235 ) ; } else { t237 = 1.0 ; } t235 = t237 * 0.01 ; t240
= ( X [ 27ULL ] - t237 ) / ( t235 == 0.0 ? 1.0E-16 : t235 ) ; if ( X [ 27ULL
] - t237 <= 0.0 ) { t240 = 0.0 ; } else if ( X [ 27ULL ] - t237 >= t237 *
0.01 ) { t240 = X [ 27ULL ] - t237 ; } else { t240 = ( X [ 27ULL ] - t237 ) *
( t240 * t240 * 3.0 - t240 * t240 * t240 * 2.0 ) ; } if ( X [ 30ULL ] <= 0.0
) { t235 = 0.0 ; } else { t235 = X [ 30ULL ] >= 1.0 ? 1.0 : X [ 30ULL ] ; }
if ( X [ 29ULL ] <= 0.0 ) { t237 = 0.0 ; } else { t237 = X [ 29ULL ] >= 1.0 ?
1.0 : X [ 29ULL ] ; } t253 = X [ 28ULL ] * ( ( ( ( 1.0 - t235 ) - t237 ) *
296.802103844292 + t235 * 461.523 ) + t237 * 4124.48151675695 ) ; if ( 1.0 -
X [ 30ULL ] >= 0.01 ) { t235 = 1.0 - X [ 30ULL ] ; } else if ( 1.0 - X [
30ULL ] >= - 0.1 ) { t235 = pmf_exp ( ( ( 1.0 - X [ 30ULL ] ) - 0.01 ) / 0.01
) * 0.01 ; } else { t235 = 1.6701700790245661E-7 ; } t237 = X [ 29ULL ] / (
t235 == 0.0 ? 1.0E-16 : t235 ) * 3827.6794129126583 + 296.802103844292 ; t171
[ 0ULL ] = X [ 28ULL ] ; tlu2_linear_linear_prelookup ( & y_efOut . mField0 [
0ULL ] , & y_efOut . mField1 [ 0ULL ] , & y_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ]
, & t23 [ 0ULL ] ) ; t16 = y_efOut ; tlu2_1d_linear_linear_value ( & ab_efOut
[ 0ULL ] , & t16 . mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] )
; t169_idx_0 = ab_efOut [ 0 ] ; t235 = pmf_exp ( pmf_log ( X [ 33ULL ] *
100000.0 ) - t169_idx_0 ) ; if ( t235 >= 1.0 ) { t256 = ( t235 - 1.0 ) *
461.523 + t237 ; t235 = t237 / ( t256 == 0.0 ? 1.0E-16 : t256 ) ; } else {
t235 = 1.0 ; } t237 = t235 * 0.01 ; t237 = ( X [ 30ULL ] - t235 ) / ( t237 ==
0.0 ? 1.0E-16 : t237 ) ; if ( X [ 30ULL ] - t235 <= 0.0 ) { t237 = 0.0 ; }
else if ( X [ 30ULL ] - t235 >= t235 * 0.01 ) { t237 = X [ 30ULL ] - t235 ; }
else { t237 = ( X [ 30ULL ] - t235 ) * ( t237 * t237 * 3.0 - t237 * t237 *
t237 * 2.0 ) ; } t243 = X [ 33ULL ] / ( t253 == 0.0 ? 1.0E-16 : t253 ) * t237
* 0.036813041167499325 / 0.001 * 100000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 0ULL ] = X
[ 286ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 1ULL ] = X [ 34ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 2ULL ] = X
[ 283ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 3ULL ] = X [ 36ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 4ULL ] = X
[ 285ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0
[ 5ULL ] = X [ 282ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ 6ULL ] = X
[ 35ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [
7ULL ] = X [ 284ULL ] ; if ( X [ 36ULL ] <= 0.0 ) { t235 = 0.0 ; } else {
t235 = X [ 36ULL ] >= 1.0 ? 1.0 : X [ 36ULL ] ; } if ( X [ 35ULL ] <= 0.0 ) {
t252 = 0.0 ; } else { t252 = X [ 35ULL ] >= 1.0 ? 1.0 : X [ 35ULL ] ; } t266
= X [ 34ULL ] * ( ( ( ( 1.0 - t235 ) - t252 ) * 296.802103844292 + t235 *
461.523 ) + t252 * 4124.48151675695 ) ; if ( 1.0 - X [ 36ULL ] >= 0.01 ) {
t253 = 1.0 - X [ 36ULL ] ; } else if ( 1.0 - X [ 36ULL ] >= - 0.1 ) { t253 =
pmf_exp ( ( ( 1.0 - X [ 36ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t253 =
1.6701700790245661E-7 ; } t252 = X [ 35ULL ] / ( t253 == 0.0 ? 1.0E-16 : t253
) * 3827.6794129126583 + 296.802103844292 ; t171 [ 0ULL ] = X [ 34ULL ] ;
tlu2_linear_linear_prelookup ( & bb_efOut . mField0 [ 0ULL ] , & bb_efOut .
mField1 [ 0ULL ] , & bb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = bb_efOut ; tlu2_1d_linear_linear_value ( & cb_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = cb_efOut [ 0
] ; t253 = pmf_exp ( pmf_log ( X [ 37ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t253 >= 1.0 ) { t235 = ( t253 - 1.0 ) * 461.523 + t252 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 = t252 / (
t235 == 0.0 ? 1.0E-16 : t235 ) ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 = 1.0 ; }
t235 = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 * 0.01
; t252 = ( X [ 36ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ) / ( t235 ==
0.0 ? 1.0E-16 : t235 ) ; if ( X [ 36ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 <= 0.0 ) {
t252 = 0.0 ; } else if ( X [ 36ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 >=
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 * 0.01 ) {
t252 = X [ 36ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ; } else {
t252 = ( X [ 36ULL ] -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ) * ( t252 *
t252 * 3.0 - t252 * t252 * t252 * 2.0 ) ; } t253 = ( X [ 322ULL ] *
0.07812500122070315 + U_idx_7 * 10.0 ) - 7.8125001220703152E-10 ; if ( X [
41ULL ] <= 0.0 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 = 0.0 ; }
else { Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 = X [
41ULL ] >= 1.0 ? 1.0 : X [ 41ULL ] ; } if ( X [ 42ULL ] <= 0.0 ) { t235 = 0.0
; } else { t235 = X [ 42ULL ] >= 1.0 ? 1.0 : X [ 42ULL ] ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 = X [ 39ULL ]
* ( ( ( ( 1.0 -
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ) - t235 ) *
296.802103844292 +
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 * 461.523 ) +
t235 * 259.836612622973 ) ; t159 [ 0ULL ] = X [ 40ULL ] * 100000.0 ; t159 [
1ULL ] = X [ 39ULL ] ; t159 [ 2ULL ] = X [ 333ULL ] ; t159 [ 3ULL ] = X [
41ULL ] ; t159 [ 4ULL ] = X [ 328ULL ] ; t159 [ 5ULL ] = X [ 332ULL ] ; t159
[ 6ULL ] = X [ 42ULL ] ; t159 [ 7ULL ] = X [ 329ULL ] ; for ( t197 = 0ULL ;
t197 < 8ULL ; t197 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ t197 ] =
t159 [ t197 ] ; } if ( 1.0 - X [ 41ULL ] >= 0.01 ) { t256 = 1.0 - X [ 41ULL ]
; } else if ( 1.0 - X [ 41ULL ] >= - 0.1 ) { t256 = pmf_exp ( ( ( 1.0 - X [
41ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t256 = 1.6701700790245661E-7 ;
} t235 = X [ 42ULL ] / ( t256 == 0.0 ? 1.0E-16 : t256 ) * -
36.965491221318985 + 296.802103844292 ; t171 [ 0ULL ] = X [ 39ULL ] ;
tlu2_linear_linear_prelookup ( & db_efOut . mField0 [ 0ULL ] , & db_efOut .
mField1 [ 0ULL ] , & db_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = db_efOut ; tlu2_1d_linear_linear_value ( & eb_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = eb_efOut [ 0
] ; t256 = pmf_exp ( pmf_log ( X [ 40ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t256 >= 1.0 ) { t278 = ( t256 - 1.0 ) * 461.523 + t235 ; t237 = t235 / ( t278
== 0.0 ? 1.0E-16 : t278 ) ; } else { t237 = 1.0 ; } t235 = t237 * 0.01 ; t235
= ( X [ 41ULL ] - t237 ) / ( t235 == 0.0 ? 1.0E-16 : t235 ) ; if ( X [ 41ULL
] - t237 <= 0.0 ) { t235 = 0.0 ; } else if ( X [ 41ULL ] - t237 >= t237 *
0.01 ) { t235 = X [ 41ULL ] - t237 ; } else { t235 = ( X [ 41ULL ] - t237 ) *
( t235 * t235 * 3.0 - t235 * t235 * t235 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 = X [ 40ULL ]
/ ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 ) *
t235 * 0.0019634954084936209 / 0.001 * 100000.0 ; t256 = U_idx_7 * 10.0 ;
t159 [ 0ULL ] = X [ 354ULL ] ; t159 [ 1ULL ] = X [ 43ULL ] ; t159 [ 2ULL ] =
X [ 355ULL ] ; t159 [ 3ULL ] = X [ 45ULL ] ; t159 [ 4ULL ] = X [ 356ULL ] ;
t159 [ 5ULL ] = X [ 357ULL ] ; t159 [ 6ULL ] = X [ 44ULL ] ; t159 [ 7ULL ] =
X [ 358ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 0ULL ] = X
[ 359ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 1ULL ] = X [ 46ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 2ULL ] = X
[ 360ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 3ULL ] = X [ 48ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 4ULL ] = X
[ 361ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo
[ 5ULL ] = X [ 362ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ 6ULL ] = X
[ 47ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
7ULL ] = X [ 363ULL ] ; if ( X [ 45ULL ] <= 0.0 ) { t237 = 0.0 ; } else {
t237 = X [ 45ULL ] >= 1.0 ? 1.0 : X [ 45ULL ] ; } if ( X [ 44ULL ] <= 0.0 ) {
t235 = 0.0 ; } else { t235 = X [ 44ULL ] >= 1.0 ? 1.0 : X [ 44ULL ] ; } t285
= X [ 43ULL ] * ( ( ( ( 1.0 - t237 ) - t235 ) * 296.802103844292 + t237 *
461.523 ) + t235 * 259.836612622973 ) ; if ( 1.0 - X [ 45ULL ] >= 0.01 ) {
t235 = 1.0 - X [ 45ULL ] ; } else if ( 1.0 - X [ 45ULL ] >= - 0.1 ) { t235 =
pmf_exp ( ( ( 1.0 - X [ 45ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t235 =
1.6701700790245661E-7 ; } t237 = X [ 44ULL ] / ( t235 == 0.0 ? 1.0E-16 : t235
) * - 36.965491221318985 + 296.802103844292 ; t171 [ 0ULL ] = X [ 43ULL ] ;
tlu2_linear_linear_prelookup ( & fb_efOut . mField0 [ 0ULL ] , & fb_efOut .
mField1 [ 0ULL ] , & fb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t12 = fb_efOut ; tlu2_1d_linear_linear_value ( & gb_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = gb_efOut [ 0
] ; t235 = pmf_exp ( pmf_log ( X [ 49ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t235 >= 1.0 ) { intrm_sf_mf_1383 = ( t235 - 1.0 ) * 461.523 + t237 ;
t169_idx_0 = t237 / ( intrm_sf_mf_1383 == 0.0 ? 1.0E-16 : intrm_sf_mf_1383 )
; } else { t169_idx_0 = 1.0 ; } t237 = t169_idx_0 * 0.01 ; t237 = ( X [ 45ULL
] - t169_idx_0 ) / ( t237 == 0.0 ? 1.0E-16 : t237 ) ; if ( X [ 45ULL ] -
t169_idx_0 <= 0.0 ) { t237 = 0.0 ; } else if ( X [ 45ULL ] - t169_idx_0 >=
t169_idx_0 * 0.01 ) { t237 = X [ 45ULL ] - t169_idx_0 ; } else { t237 = ( X [
45ULL ] - t169_idx_0 ) * ( t237 * t237 * 3.0 - t237 * t237 * t237 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_16 = X [ 49ULL ]
/ ( t285 == 0.0 ? 1.0E-16 : t285 ) * t237 * 0.036813041167499325 / 0.001 *
100000.0 ; if ( X [ 48ULL ] <= 0.0 ) { t235 = 0.0 ; } else { t235 = X [ 48ULL
] >= 1.0 ? 1.0 : X [ 48ULL ] ; } if ( X [ 47ULL ] <= 0.0 ) { t169_idx_0 = 0.0
; } else { t169_idx_0 = X [ 47ULL ] >= 1.0 ? 1.0 : X [ 47ULL ] ; } t294 = X [
46ULL ] * ( ( ( ( 1.0 - t235 ) - t169_idx_0 ) * 296.802103844292 + t235 *
461.523 ) + t169_idx_0 * 259.836612622973 ) ; if ( 1.0 - X [ 48ULL ] >= 0.01
) { t235 = 1.0 - X [ 48ULL ] ; } else if ( 1.0 - X [ 48ULL ] >= - 0.1 ) {
t235 = pmf_exp ( ( ( 1.0 - X [ 48ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
t235 = 1.6701700790245661E-7 ; } t268 = X [ 47ULL ] / ( t235 == 0.0 ? 1.0E-16
: t235 ) * - 36.965491221318985 + 296.802103844292 ; t171 [ 0ULL ] = X [
46ULL ] ; tlu2_linear_linear_prelookup ( & hb_efOut . mField0 [ 0ULL ] , &
hb_efOut . mField1 [ 0ULL ] , & hb_efOut . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ]
, & t23 [ 0ULL ] ) ; t12 = hb_efOut ; tlu2_1d_linear_linear_value ( &
ib_efOut [ 0ULL ] , & t12 . mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , ( (
_NeDynamicSystem * ) ( LC ) ) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] )
; t169_idx_0 = ib_efOut [ 0 ] ; t235 = pmf_exp ( pmf_log ( X [ 50ULL ] *
100000.0 ) - t169_idx_0 ) ; if ( t235 >= 1.0 ) { t235 = ( t235 - 1.0 ) *
461.523 + t268 ; t237 = t268 / ( t235 == 0.0 ? 1.0E-16 : t235 ) ; } else {
t237 = 1.0 ; } t235 = t237 * 0.01 ; t268 = ( X [ 48ULL ] - t237 ) / ( t235 ==
0.0 ? 1.0E-16 : t235 ) ; if ( X [ 48ULL ] - t237 <= 0.0 ) { t268 = 0.0 ; }
else if ( X [ 48ULL ] - t237 >= t237 * 0.01 ) { t268 = X [ 48ULL ] - t237 ; }
else { t268 = ( X [ 48ULL ] - t237 ) * ( t268 * t268 * 3.0 - t268 * t268 *
t268 * 2.0 ) ; }
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 0ULL ] = X
[ 411ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 1ULL ] = X [ 51ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 2ULL ] = X
[ 408ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 3ULL ] = X [ 53ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 4ULL ] = X
[ 410ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0
[ 5ULL ] = X [ 407ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ 6ULL ] = X
[ 52ULL ] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [
7ULL ] = X [ 409ULL ] ; if ( X [ 53ULL ] <= 0.0 ) { t273 = 0.0 ; } else {
t273 = X [ 53ULL ] >= 1.0 ? 1.0 : X [ 53ULL ] ; } if ( X [ 52ULL ] <= 0.0 ) {
t274 = 0.0 ; } else { t274 = X [ 52ULL ] >= 1.0 ? 1.0 : X [ 52ULL ] ; } t235
= X [ 51ULL ] * ( ( ( ( 1.0 - t273 ) - t274 ) * 296.802103844292 + t273 *
461.523 ) + t274 * 259.836612622973 ) ; if ( 1.0 - X [ 53ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 = 1.0 - X [
53ULL ] ; } else if ( 1.0 - X [ 53ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 = pmf_exp ( (
( 1.0 - X [ 53ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 =
1.6701700790245661E-7 ; } t274 = X [ 52ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 ) *
- 36.965491221318985 + 296.802103844292 ; t171 [ 0ULL ] = X [ 51ULL ] ;
tlu2_linear_linear_prelookup ( & jb_efOut . mField0 [ 0ULL ] , & jb_efOut .
mField1 [ 0ULL ] , & jb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = jb_efOut ; tlu2_1d_linear_linear_value ( & kb_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = kb_efOut [ 0
] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 = pmf_exp
( pmf_log ( X [ 54ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 >= 1.0 ) {
t169_idx_0 = ( Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0
- 1.0 ) * 461.523 + t274 ; t276 = t274 / ( t169_idx_0 == 0.0 ? 1.0E-16 :
t169_idx_0 ) ; } else { t276 = 1.0 ; } t312 = t276 * 0.01 ; t274 = ( X [
53ULL ] - t276 ) / ( t312 == 0.0 ? 1.0E-16 : t312 ) ; if ( X [ 53ULL ] - t276
<= 0.0 ) { t274 = 0.0 ; } else if ( X [ 53ULL ] - t276 >= t276 * 0.01 ) {
t274 = X [ 53ULL ] - t276 ; } else { t274 = ( X [ 53ULL ] - t276 ) * ( t274 *
t274 * 3.0 - t274 * t274 * t274 * 2.0 ) ; } t273 = X [ 54ULL ] / ( t235 ==
0.0 ? 1.0E-16 : t235 ) * t274 * 0.00049087385212340522 / 0.001 * 100000.0 ;
t274 = - X [ 427ULL ] - X [ 428ULL ] ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 = - X [ 430ULL
] - X [ 431ULL ] ; t276 = - X [ 434ULL ] + U_idx_10 * - 2.0 ; t278 = U_idx_10
* 2.0 ; t279 = U_idx_10 * 2.0 ; t281 = ( 1.01325 - X [ 451ULL ] ) * X [
460ULL ] * 0.0001 ; t284 = ( ( ( ( - X [ 252ULL ] - X [ 269ULL ] ) - X [
376ULL ] ) - X [ 394ULL ] ) - X [ 445ULL ] ) - X [ 463ULL ] ; t285 = ( ( ( X
[ 19ULL ] * - 1.0E-6 + X [ 172ULL ] * - 1.0E-15 ) + X [ 173ULL ] * - 0.001001
) + X [ 20ULL ] ) + X [ 464ULL ] ; t286 = - X [ 465ULL ] + X [ 402ULL ] ;
t164 [ 0ULL ] = X [ 64ULL ] * 100000.0 ; t164 [ 1ULL ] = X [ 63ULL ] ; t164 [
2ULL ] = X [ 473ULL ] ; t164 [ 3ULL ] = X [ 66ULL ] ; t164 [ 4ULL ] = X [
475ULL ] ; t164 [ 5ULL ] = X [ 472ULL ] ; t164 [ 6ULL ] = X [ 65ULL ] ; t164
[ 7ULL ] = X [ 474ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ t197 ] =
t164 [ t197 ] ; } if ( X [ 66ULL ] <= 0.0 ) { t287 = 0.0 ; } else { t287 = X
[ 66ULL ] >= 1.0 ? 1.0 : X [ 66ULL ] ; } if ( X [ 65ULL ] <= 0.0 ) {
intrm_sf_mf_1383 = 0.0 ; } else { intrm_sf_mf_1383 = X [ 65ULL ] >= 1.0 ? 1.0
: X [ 65ULL ] ; } t235 = X [ 63ULL ] * ( ( ( ( 1.0 - t287 ) -
intrm_sf_mf_1383 ) * 296.802103844292 + t287 * 461.523 ) + intrm_sf_mf_1383 *
4124.48151675695 ) ; if ( 1.0 - X [ 66ULL ] >= 0.01 ) { intrm_sf_mf_1383 =
1.0 - X [ 66ULL ] ; } else if ( 1.0 - X [ 66ULL ] >= - 0.1 ) {
intrm_sf_mf_1383 = pmf_exp ( ( ( 1.0 - X [ 66ULL ] ) - 0.01 ) / 0.01 ) * 0.01
; } else { intrm_sf_mf_1383 = 1.6701700790245661E-7 ; } t289 = X [ 65ULL ] /
( intrm_sf_mf_1383 == 0.0 ? 1.0E-16 : intrm_sf_mf_1383 ) * 3827.6794129126583
+ 296.802103844292 ; t171 [ 0ULL ] = X [ 63ULL ] ;
tlu2_linear_linear_prelookup ( & lb_efOut . mField0 [ 0ULL ] , & lb_efOut .
mField1 [ 0ULL ] , & lb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t12 = lb_efOut ; tlu2_1d_linear_linear_value ( & mb_efOut [ 0ULL ] , & t12 .
mField0 [ 0ULL ] , & t12 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = mb_efOut [ 0
] ; intrm_sf_mf_1383 = pmf_exp ( pmf_log ( X [ 64ULL ] * 100000.0 ) -
t169_idx_0 ) ; if ( intrm_sf_mf_1383 >= 1.0 ) { t169_idx_0 = (
intrm_sf_mf_1383 - 1.0 ) * 461.523 + t289 ; t237 = t289 / ( t169_idx_0 == 0.0
? 1.0E-16 : t169_idx_0 ) ; } else { t237 = 1.0 ; } t169_idx_0 = t237 * 0.01 ;
intrm_sf_mf_1383 = ( X [ 66ULL ] - t237 ) / ( t169_idx_0 == 0.0 ? 1.0E-16 :
t169_idx_0 ) ; if ( X [ 66ULL ] - t237 <= 0.0 ) { intrm_sf_mf_1383 = 0.0 ; }
else if ( X [ 66ULL ] - t237 >= t237 * 0.01 ) { intrm_sf_mf_1383 = X [ 66ULL
] - t237 ; } else { intrm_sf_mf_1383 = ( X [ 66ULL ] - t237 ) * (
intrm_sf_mf_1383 * intrm_sf_mf_1383 * 3.0 - intrm_sf_mf_1383 *
intrm_sf_mf_1383 * intrm_sf_mf_1383 * 2.0 ) ; } t287 = X [ 64ULL ] / ( t235
== 0.0 ? 1.0E-16 : t235 ) * intrm_sf_mf_1383 * 0.18 / 0.001 * 100000.0 ;
intrm_sf_mf_1383 = ( X [ 485ULL ] * - 0.62500003906250234 + U_idx_11 * 10.0 )
+ 6.2500003783494407E-9 ; if ( X [ 69ULL ] <= 0.0 ) { t289 = 0.0 ; } else {
t289 = X [ 69ULL ] >= 1.0 ? 1.0 : X [ 69ULL ] ; } if ( X [ 70ULL ] <= 0.0 ) {
t237 = 0.0 ; } else { t237 = X [ 70ULL ] >= 1.0 ? 1.0 : X [ 70ULL ] ; }
t169_idx_0 = X [ 67ULL ] * ( ( ( ( 1.0 - t289 ) - t237 ) * 296.802103844292 +
t289 * 461.523 ) + t237 * 4124.48151675695 ) ; t289 = X [ 68ULL ] / (
t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ) ; t166 [ 0ULL ] = X [ 68ULL ] *
100000.0 ; t166 [ 1ULL ] = X [ 67ULL ] ; t166 [ 2ULL ] = X [ 496ULL ] ; t166
[ 3ULL ] = X [ 69ULL ] ; t166 [ 4ULL ] = X [ 490ULL ] ; t166 [ 5ULL ] = X [
495ULL ] ; t166 [ 6ULL ] = X [ 70ULL ] ; t166 [ 7ULL ] = X [ 491ULL ] ; for (
t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t164 [ t197 ] = t166 [ t197 ] ; } if
( 1.0 - X [ 69ULL ] >= 0.01 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 = 1.0 - X [
69ULL ] ; } else if ( 1.0 - X [ 69ULL ] >= - 0.1 ) {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 = pmf_exp ( (
( 1.0 - X [ 69ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 =
1.6701700790245661E-7 ; } t237 = X [ 70ULL ] / (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 == 0.0 ?
1.0E-16 : Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 ) *
3827.6794129126583 + 296.802103844292 ; t171 [ 0ULL ] = X [ 67ULL ] ;
tlu2_linear_linear_prelookup ( & nb_efOut . mField0 [ 0ULL ] , & nb_efOut .
mField1 [ 0ULL ] , & nb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = nb_efOut ; tlu2_1d_linear_linear_value ( & ob_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = ob_efOut [ 0
] ; Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 = pmf_exp
( pmf_log ( X [ 68ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 >= 1.0 ) {
t169_idx_0 = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 - 1.0 ) *
461.523 + t237 ; t235 = t237 / ( t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ) ;
} else { t235 = 1.0 ; } t169_idx_0 = t235 * 0.01 ; t237 = ( X [ 69ULL ] -
t235 ) / ( t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ) ; if ( X [ 69ULL ] -
t235 <= 0.0 ) { t237 = 0.0 ; } else if ( X [ 69ULL ] - t235 >= t235 * 0.01 )
{ t237 = X [ 69ULL ] - t235 ; } else { t237 = ( X [ 69ULL ] - t235 ) * ( t237
* t237 * 3.0 - t237 * t237 * t237 * 2.0 ) ; } t289 = t289 * t237 *
7.8539816339744827E-5 / 0.001 ; t289 *= 100000.0 ;
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 = U_idx_11 *
10.0 ; t295 = U_idx_12 * 376.99111843077515 ; t296 = t295 *
0.99999999999999978 / 0.99999999999999978 ; t168 [ 0ULL ] = X [ 55ULL ] *
100000.0 ; t168 [ 1ULL ] = X [ 71ULL ] ; t168 [ 2ULL ] = X [ 543ULL ] ; t168
[ 3ULL ] = X [ 73ULL ] ; t168 [ 4ULL ] = X [ 545ULL ] ; t168 [ 5ULL ] = X [
542ULL ] ; t168 [ 6ULL ] = X [ 72ULL ] ; t168 [ 7ULL ] = X [ 544ULL ] ; for (
t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t166 [ t197 ] = t168 [ t197 ] ; } if
( X [ 73ULL ] <= 0.0 ) { t301 = 0.0 ; } else { t301 = X [ 73ULL ] >= 1.0 ?
1.0 : X [ 73ULL ] ; } if ( X [ 72ULL ] <= 0.0 ) { t235 = 0.0 ; } else { t235
= X [ 72ULL ] >= 1.0 ? 1.0 : X [ 72ULL ] ; } t169_idx_0 = X [ 71ULL ] * ( ( (
( 1.0 - t301 ) - t235 ) * 296.802103844292 + t301 * 461.523 ) + t235 *
259.836612622973 ) ; t301 = X [ 55ULL ] / ( t169_idx_0 == 0.0 ? 1.0E-16 :
t169_idx_0 ) ; if ( 1.0 - X [ 73ULL ] >= 0.01 ) { t235 = 1.0 - X [ 73ULL ] ;
} else if ( 1.0 - X [ 73ULL ] >= - 0.1 ) { t235 = pmf_exp ( ( ( 1.0 - X [
73ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else { t235 = 1.6701700790245661E-7 ;
} t303 = X [ 72ULL ] / ( t235 == 0.0 ? 1.0E-16 : t235 ) * -
36.965491221318985 + 296.802103844292 ; t171 [ 0ULL ] = X [ 71ULL ] ;
tlu2_linear_linear_prelookup ( & pb_efOut . mField0 [ 0ULL ] , & pb_efOut .
mField1 [ 0ULL ] , & pb_efOut . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) (
LC ) ) -> mField13 , & t171 [ 0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ;
t16 = pb_efOut ; tlu2_1d_linear_linear_value ( & qb_efOut [ 0ULL ] , & t16 .
mField0 [ 0ULL ] , & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC )
) -> mField14 , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t169_idx_0 = qb_efOut [ 0
] ; t235 = pmf_exp ( pmf_log ( X [ 55ULL ] * 100000.0 ) - t169_idx_0 ) ; if (
t235 >= 1.0 ) { t169_idx_0 = ( t235 - 1.0 ) * 461.523 + t303 ; t237 = t303 /
( t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ) ; } else { t237 = 1.0 ; }
t169_idx_0 = t237 * 0.01 ; t235 = ( X [ 73ULL ] - t237 ) / ( t169_idx_0 ==
0.0 ? 1.0E-16 : t169_idx_0 ) ; if ( X [ 73ULL ] - t237 <= 0.0 ) { t235 = 0.0
; } else if ( X [ 73ULL ] - t237 >= t237 * 0.01 ) { t235 = X [ 73ULL ] - t237
; } else { t235 = ( X [ 73ULL ] - t237 ) * ( t235 * t235 * 3.0 - t235 * t235
* t235 * 2.0 ) ; } t301 = t301 * t235 * 0.0003 / 0.001 ; t301 *= 100000.0 ;
t303 = - ( X [ 55ULL ] - 1.01325 ) * X [ 552ULL ] * 0.0001 ; t170 [ 0ULL ] =
X [ 38ULL ] * 100000.0 ; t170 [ 1ULL ] = X [ 74ULL ] ; t170 [ 2ULL ] = X [
557ULL ] ; t170 [ 3ULL ] = X [ 76ULL ] ; t170 [ 4ULL ] = X [ 559ULL ] ; t170
[ 5ULL ] = X [ 556ULL ] ; t170 [ 6ULL ] = X [ 75ULL ] ; t170 [ 7ULL ] = X [
558ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t168 [ t197 ] = t170
[ t197 ] ; } if ( X [ 76ULL ] <= 0.0 ) { t305 = 0.0 ; } else { t305 = X [
76ULL ] >= 1.0 ? 1.0 : X [ 76ULL ] ; } if ( X [ 75ULL ] <= 0.0 ) {
intrm_sf_mf_1660 = 0.0 ; } else { intrm_sf_mf_1660 = X [ 75ULL ] >= 1.0 ? 1.0
: X [ 75ULL ] ; } t169_idx_0 = X [ 74ULL ] * ( ( ( ( 1.0 - t305 ) -
intrm_sf_mf_1660 ) * 296.802103844292 + t305 * 461.523 ) + intrm_sf_mf_1660 *
4124.48151675695 ) ; t305 = X [ 38ULL ] / ( t169_idx_0 == 0.0 ? 1.0E-16 :
t169_idx_0 ) ; if ( 1.0 - X [ 76ULL ] >= 0.01 ) { intrm_sf_mf_1660 = 1.0 - X
[ 76ULL ] ; } else if ( 1.0 - X [ 76ULL ] >= - 0.1 ) { intrm_sf_mf_1660 =
pmf_exp ( ( ( 1.0 - X [ 76ULL ] ) - 0.01 ) / 0.01 ) * 0.01 ; } else {
intrm_sf_mf_1660 = 1.6701700790245661E-7 ; } t235 = X [ 75ULL ] / (
intrm_sf_mf_1660 == 0.0 ? 1.0E-16 : intrm_sf_mf_1660 ) * 3827.6794129126583 +
296.802103844292 ; t171 [ 0ULL ] = X [ 74ULL ] ; tlu2_linear_linear_prelookup
( & rb_efOut . mField0 [ 0ULL ] , & rb_efOut . mField1 [ 0ULL ] , & rb_efOut
. mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField13 , & t171 [
0ULL ] , & t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t16 = rb_efOut ;
tlu2_1d_linear_linear_value ( & sb_efOut [ 0ULL ] , & t16 . mField0 [ 0ULL ]
, & t16 . mField2 [ 0ULL ] , ( ( _NeDynamicSystem * ) ( LC ) ) -> mField14 ,
& t82 [ 0ULL ] , & t23 [ 0ULL ] ) ; t171 [ 0 ] = sb_efOut [ 0 ] ;
intrm_sf_mf_1660 = pmf_exp ( pmf_log ( X [ 38ULL ] * 100000.0 ) - t171 [ 0ULL
] ) ; if ( intrm_sf_mf_1660 >= 1.0 ) { t169_idx_0 = ( intrm_sf_mf_1660 - 1.0
) * 461.523 + t235 ; t235 /= t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ; }
else { t235 = 1.0 ; } t169_idx_0 = t235 * 0.01 ; intrm_sf_mf_1660 = ( X [
76ULL ] - t235 ) / ( t169_idx_0 == 0.0 ? 1.0E-16 : t169_idx_0 ) ; if ( X [
76ULL ] - t235 <= 0.0 ) { intrm_sf_mf_1660 = 0.0 ; } else if ( X [ 76ULL ] -
t235 >= t235 * 0.01 ) { intrm_sf_mf_1660 = X [ 76ULL ] - t235 ; } else {
intrm_sf_mf_1660 = ( X [ 76ULL ] - t235 ) * ( intrm_sf_mf_1660 *
intrm_sf_mf_1660 * 3.0 - intrm_sf_mf_1660 * intrm_sf_mf_1660 *
intrm_sf_mf_1660 * 2.0 ) ; } t305 = t305 * intrm_sf_mf_1660 *
0.00012500000000000003 / 0.001 ; t305 *= 100000.0 ; intrm_sf_mf_1660 =
U_idx_4 * 0.01 ; t169_idx_0 = ( ( ( X [ 19ULL ] * - 1.0E-6 + X [ 172ULL ] * -
1.0E-15 ) + X [ 173ULL ] * - 1.0E-6 ) + X [ 20ULL ] ) + X [ 464ULL ] ; t312 =
( ( X [ 4ULL ] * - 0.01 + X [ 5ULL ] * 0.01 ) + X [ 168ULL ] ) + X [ 577ULL ]
; t235 = X [ 179ULL ] * 0.00062831853071795862 ; t237 = X [ 306ULL ] *
0.0031415926535897937 ; t141 [ 0ULL ] = X [ 0ULL ] ; t141 [ 1ULL ] =
Battery_System_Battery_Table_Based_Q * 1000.0 ; t141 [ 2ULL ] = X [ 0ULL ] ;
t141 [ 3ULL ] = X [ 1ULL ] * 0.00027777777777777778 ; t141 [ 4ULL ] = X [
79ULL ] ; t141 [ 5ULL ] = 0.0 ; t141 [ 6ULL ] = X [ 2ULL ] ; t141 [ 7ULL ] =
X [ 80ULL ] ; t141 [ 8ULL ] = 1.0 ; t141 [ 9ULL ] = X [ 81ULL ] ; t141 [
10ULL ] = X [ 82ULL ] * 1000.0 ; t141 [ 11ULL ] = X [ 82ULL ] * 1000.0 ; t141
[ 12ULL ] = X [ 83ULL ] ; t141 [ 13ULL ] = X [ 83ULL ] ; t141 [ 14ULL ] = X [
81ULL ] ; t141 [ 15ULL ] = 0.0 ; t141 [ 16ULL ] = 0.0 ; t141 [ 17ULL ] = 0.0
; t141 [ 18ULL ] = 0.0 ; t141 [ 19ULL ] = 0.0 ; t141 [ 20ULL ] = 0.0 ; t141 [
21ULL ] = 0.0 ; t141 [ 22ULL ] = 0.0 ; t141 [ 23ULL ] = 0.0 ; t141 [ 24ULL ]
= 0.0 ; t141 [ 25ULL ] = 0.0 ; t141 [ 26ULL ] = X [ 84ULL ] ; t141 [ 27ULL ]
= X [ 85ULL ] ; t141 [ 28ULL ] = X [ 86ULL ] ; t141 [ 29ULL ] = X [ 87ULL ] *
0.00027777777777777778 ; t141 [ 30ULL ] = X [ 83ULL ] ; t141 [ 31ULL ] =
Battery_System_DC_DC_Converter_i1 ; t141 [ 32ULL ] = X [ 81ULL ] ; t141 [
33ULL ] = 0.0 ; t141 [ 34ULL ] = 0.0 ; t141 [ 35ULL ] = X [ 88ULL ] ; t141 [
36ULL ] = 0.0 ; t141 [ 37ULL ] = 0.0 ; t141 [ 38ULL ] = X [ 81ULL ] ; t141 [
39ULL ] = X [ 89ULL ] ; t141 [ 40ULL ] = ( X [ 90ULL ] *
Battery_System_DC_DC_Converter_power_dissipated + ( 1.0 -
Battery_System_DC_DC_Converter_power_dissipated ) *
Battery_System_DC_DC_Converter_i1 * Battery_System_DC_DC_Converter_i1 ) *
1000.0 ; t141 [ 41ULL ] = X [ 90ULL ] * 1000.0 ; t141 [ 42ULL ] = X [ 3ULL ]
; t141 [ 43ULL ] = X [ 89ULL ] ; t141 [ 44ULL ] = 0.0 ; t141 [ 45ULL ] = 0.0
; t141 [ 46ULL ] = X [ 5ULL ] ; t141 [ 47ULL ] = U_idx_0 ; t141 [ 48ULL ] =
0.0 ; t141 [ 49ULL ] = U_idx_1 ; t141 [ 50ULL ] = U_idx_1 ; t141 [ 51ULL ] =
X [ 81ULL ] ; t141 [ 52ULL ] = X [ 81ULL ] ; t141 [ 53ULL ] = U_idx_1 ; t141
[ 54ULL ] = X [ 81ULL ] ; t141 [ 55ULL ] = 0.0 ; t141 [ 56ULL ] = - X [ 79ULL
] ; t141 [ 57ULL ] = - X [ 79ULL ] ; t141 [ 58ULL ] = X [ 81ULL ] ; t141 [
59ULL ] = X [ 81ULL ] ; t141 [ 60ULL ] = - X [ 79ULL ] ; t141 [ 61ULL ] = 0.0
; t141 [ 62ULL ] = X [ 81ULL ] ; t141 [ 63ULL ] = 0.0 ; t141 [ 64ULL ] = X [
81ULL ] ; t141 [ 65ULL ] = X [ 81ULL ] ; t141 [ 66ULL ] = X [ 81ULL ] ; t141
[ 67ULL ] = X [ 81ULL ] ; t141 [ 68ULL ] = - X [ 88ULL ] ; t141 [ 69ULL ] = -
X [ 88ULL ] ; t141 [ 70ULL ] = X [ 89ULL ] ; t141 [ 71ULL ] = X [ 89ULL ] ;
t141 [ 72ULL ] = 0.0 ; t141 [ 73ULL ] = - X [ 88ULL ] ; t141 [ 74ULL ] = X [
89ULL ] ; t141 [ 75ULL ] = 0.0 ; t141 [ 76ULL ] = X [ 89ULL ] ; t141 [ 77ULL
] = X [ 89ULL ] ; t141 [ 78ULL ] = X [ 89ULL ] ; t141 [ 79ULL ] = X [ 89ULL ]
; t141 [ 80ULL ] = 0.0 ; t141 [ 81ULL ] = X [ 4ULL ] ; t141 [ 82ULL ] = t206
* 1000.0 ; t141 [ 83ULL ] = t206 * 1000.0 ; t141 [ 84ULL ] = - X [ 4ULL ] ;
t141 [ 85ULL ] = X [ 5ULL ] ; t141 [ 86ULL ] = t206 * 1.0E+6 ; t141 [ 87ULL ]
= t206 * 1000.0 ; t141 [ 88ULL ] = - X [ 88ULL ] ; t141 [ 89ULL ] = t206 *
1.0E+6 ; t141 [ 90ULL ] = - X [ 88ULL ] ; t141 [ 91ULL ] = X [ 4ULL ] ; t141
[ 92ULL ] = X [ 4ULL ] ; t141 [ 93ULL ] = X [ 91ULL ] * 1000.0 ; t141 [ 94ULL
] = X [ 4ULL ] ; t141 [ 95ULL ] = 0.0 ; t141 [ 96ULL ] = X [ 4ULL ] ; t141 [
97ULL ] = X [ 5ULL ] ; t141 [ 98ULL ] = t207 * 1000.0 ; t141 [ 99ULL ] = t207
* 100.0 ; t141 [ 100ULL ] = - X [ 88ULL ] ; t141 [ 101ULL ] = U_idx_0 ; t141
[ 102ULL ] = X [ 0ULL ] ; t141 [ 103ULL ] =
Battery_System_Battery_Table_Based_Q * 1000.0 ; t141 [ 104ULL ] =
Battery_System_Battery_Table_Based_Q * 100.0 ; t141 [ 105ULL ] = X [ 89ULL ]
; t141 [ 106ULL ] = 0.0 ; t141 [ 107ULL ] = X [ 92ULL ] ; t141 [ 108ULL ] = X
[ 93ULL ] * 0.1 ; t141 [ 109ULL ] = X [ 94ULL ] ; t141 [ 110ULL ] = X [ 95ULL
] * 0.1 ; t141 [ 111ULL ] = X [ 96ULL ] ; t141 [ 112ULL ] = - X [ 96ULL ] ;
t141 [ 113ULL ] = X [ 92ULL ] ; t141 [ 114ULL ] = X [ 93ULL ] * 0.1 ; t141 [
115ULL ] = X [ 96ULL ] ; t141 [ 116ULL ] = X [ 97ULL ] ; t141 [ 117ULL ] =
U_idx_2 ; t141 [ 118ULL ] = X [ 98ULL ] ; t141 [ 119ULL ] = X [ 94ULL ] ;
t141 [ 120ULL ] = X [ 95ULL ] * 0.1 ; t141 [ 121ULL ] = - X [ 96ULL ] ; t141
[ 122ULL ] = X [ 99ULL ] ; t141 [ 123ULL ] = - U_idx_2 ; t141 [ 124ULL ] = X
[ 98ULL ] ; t141 [ 125ULL ] = 0.0 ; t141 [ 126ULL ] = U_idx_2 ; t141 [ 127ULL
] = - U_idx_2 ; t141 [ 128ULL ] = X [ 100ULL ] ; t141 [ 129ULL ] = X [ 101ULL
] ; t141 [ 130ULL ] = X [ 102ULL ] * 0.1 ; t141 [ 131ULL ] = X [ 103ULL ] ;
t141 [ 132ULL ] = X [ 104ULL ] * 0.1 ; t141 [ 133ULL ] = X [ 105ULL ] ; t141
[ 134ULL ] = - X [ 105ULL ] ; t141 [ 135ULL ] = X [ 101ULL ] ; t141 [ 136ULL
] = X [ 102ULL ] * 0.1 ; t141 [ 137ULL ] = X [ 105ULL ] ; t141 [ 138ULL ] = X
[ 106ULL ] ; t141 [ 139ULL ] = U_idx_2 ; t141 [ 140ULL ] = X [ 107ULL ] ;
t141 [ 141ULL ] = X [ 103ULL ] ; t141 [ 142ULL ] = X [ 104ULL ] * 0.1 ; t141
[ 143ULL ] = - X [ 105ULL ] ; t141 [ 144ULL ] = X [ 108ULL ] ; t141 [ 145ULL
] = - U_idx_2 ; t141 [ 146ULL ] = X [ 107ULL ] ; t141 [ 147ULL ] = 0.0 ; t141
[ 148ULL ] = U_idx_2 ; t141 [ 149ULL ] = - U_idx_2 ; t141 [ 150ULL ] = X [
109ULL ] ; t141 [ 151ULL ] = X [ 110ULL ] ; t141 [ 152ULL ] = X [ 111ULL ] *
0.1 ; t141 [ 153ULL ] = X [ 112ULL ] ; t141 [ 154ULL ] = X [ 113ULL ] * 0.1 ;
t141 [ 155ULL ] = X [ 114ULL ] ; t141 [ 156ULL ] = - X [ 114ULL ] ; t141 [
157ULL ] = X [ 110ULL ] ; t141 [ 158ULL ] = X [ 111ULL ] * 0.1 ; t141 [
159ULL ] = X [ 114ULL ] ; t141 [ 160ULL ] = X [ 115ULL ] ; t141 [ 161ULL ] =
U_idx_2 ; t141 [ 162ULL ] = X [ 116ULL ] ; t141 [ 163ULL ] = X [ 112ULL ] ;
t141 [ 164ULL ] = X [ 113ULL ] * 0.1 ; t141 [ 165ULL ] = - X [ 114ULL ] ;
t141 [ 166ULL ] = X [ 117ULL ] ; t141 [ 167ULL ] = - U_idx_2 ; t141 [ 168ULL
] = X [ 116ULL ] ; t141 [ 169ULL ] = 0.0 ; t141 [ 170ULL ] = U_idx_2 ; t141 [
171ULL ] = - U_idx_2 ; t141 [ 172ULL ] = X [ 118ULL ] ; t141 [ 173ULL ] = X [
5ULL ] ; t141 [ 174ULL ] = X [ 13ULL ] ; t141 [ 175ULL ] = U_idx_0 ; t141 [
176ULL ] = X [ 112ULL ] ; t141 [ 177ULL ] = X [ 113ULL ] * 0.1 ; t141 [
178ULL ] = X [ 119ULL ] ; t141 [ 179ULL ] = X [ 120ULL ] * 0.1 ; t141 [
180ULL ] = 0.0 ; t141 [ 181ULL ] = U_idx_0 ; t141 [ 182ULL ] = X [ 112ULL ] ;
t141 [ 183ULL ] = X [ 113ULL ] * 0.1 ; t141 [ 184ULL ] = X [ 119ULL ] ; t141
[ 185ULL ] = X [ 120ULL ] * 0.1 ; t141 [ 186ULL ] = 0.0 ; t141 [ 187ULL ] =
U_idx_0 ; t141 [ 188ULL ] = X [ 6ULL ] ; t141 [ 189ULL ] = U_idx_2 ; t141 [
190ULL ] = - U_idx_2 ; t141 [ 191ULL ] = X [ 114ULL ] ; t141 [ 192ULL ] = X [
121ULL ] ; t141 [ 193ULL ] = X [ 122ULL ] ; t141 [ 194ULL ] = X [ 112ULL ] ;
t141 [ 195ULL ] = X [ 113ULL ] * 0.1 ; t141 [ 196ULL ] = X [ 114ULL ] ; t141
[ 197ULL ] = X [ 123ULL ] ; t141 [ 198ULL ] = U_idx_2 ; t141 [ 199ULL ] = X [
124ULL ] ; t141 [ 200ULL ] = X [ 119ULL ] ; t141 [ 201ULL ] = X [ 120ULL ] *
0.1 ; t141 [ 202ULL ] = X [ 121ULL ] ; t141 [ 203ULL ] = X [ 125ULL ] ; t141
[ 204ULL ] = - U_idx_2 ; t141 [ 205ULL ] = X [ 126ULL ] ; t141 [ 206ULL ] =
U_idx_0 ; t141 [ 207ULL ] = U_idx_0 ; t141 [ 208ULL ] = U_idx_0 ; t141 [
209ULL ] = U_idx_0 ; t141 [ 210ULL ] = X [ 122ULL ] * 1000.0 ; t141 [ 211ULL
] = X [ 122ULL ] * 1000.0 ; t141 [ 212ULL ] = X [ 122ULL ] * 1000.0 ; t141 [
213ULL ] = U_idx_0 ; t141 [ 214ULL ] = 0.0 ; t141 [ 215ULL ] = U_idx_0 ; t141
[ 216ULL ] = 0.0 ; t141 [ 217ULL ] = U_idx_0 ; t141 [ 218ULL ] = U_idx_0 ;
t141 [ 219ULL ] = U_idx_0 ; t141 [ 220ULL ] = U_idx_0 ; t141 [ 221ULL ] =
t208 * 1000.0 ; t141 [ 222ULL ] = t208 * 1000.0 ; t141 [ 223ULL ] = t208 *
1000.0 ; t141 [ 224ULL ] = U_idx_0 ; t141 [ 225ULL ] = 0.0 ; t141 [ 226ULL ]
= U_idx_0 ; t141 [ 227ULL ] = 0.0 ; t141 [ 228ULL ] = X [ 94ULL ] ; t141 [
229ULL ] = X [ 95ULL ] * 0.1 ; t141 [ 230ULL ] = X [ 101ULL ] ; t141 [ 231ULL
] = X [ 102ULL ] * 0.1 ; t141 [ 232ULL ] = 0.0 ; t141 [ 233ULL ] = X [ 10ULL
] ; t141 [ 234ULL ] = X [ 94ULL ] ; t141 [ 235ULL ] = X [ 95ULL ] * 0.1 ;
t141 [ 236ULL ] = X [ 101ULL ] ; t141 [ 237ULL ] = X [ 102ULL ] * 0.1 ; t141
[ 238ULL ] = 0.0 ; t141 [ 239ULL ] = X [ 10ULL ] ; t141 [ 240ULL ] = X [ 9ULL
] ; t141 [ 241ULL ] = U_idx_2 ; t141 [ 242ULL ] = - U_idx_2 ; t141 [ 243ULL ]
= X [ 96ULL ] ; t141 [ 244ULL ] = - X [ 105ULL ] ; t141 [ 245ULL ] = X [
127ULL ] ; t141 [ 246ULL ] = X [ 94ULL ] ; t141 [ 247ULL ] = X [ 95ULL ] *
0.1 ; t141 [ 248ULL ] = X [ 96ULL ] ; t141 [ 249ULL ] = X [ 128ULL ] ; t141 [
250ULL ] = U_idx_2 ; t141 [ 251ULL ] = X [ 129ULL ] ; t141 [ 252ULL ] = X [
101ULL ] ; t141 [ 253ULL ] = X [ 102ULL ] * 0.1 ; t141 [ 254ULL ] = - X [
105ULL ] ; t141 [ 255ULL ] = X [ 130ULL ] ; t141 [ 256ULL ] = - U_idx_2 ;
t141 [ 257ULL ] = X [ 131ULL ] ; t141 [ 258ULL ] = X [ 103ULL ] ; t141 [
259ULL ] = X [ 104ULL ] * 0.1 ; t141 [ 260ULL ] = X [ 110ULL ] ; t141 [
261ULL ] = X [ 111ULL ] * 0.1 ; t141 [ 262ULL ] = 0.0 ; t141 [ 263ULL ] = X [
12ULL ] ; t141 [ 264ULL ] = X [ 103ULL ] ; t141 [ 265ULL ] = X [ 104ULL ] *
0.1 ; t141 [ 266ULL ] = X [ 110ULL ] ; t141 [ 267ULL ] = X [ 111ULL ] * 0.1 ;
t141 [ 268ULL ] = 0.0 ; t141 [ 269ULL ] = X [ 12ULL ] ; t141 [ 270ULL ] = X [
11ULL ] ; t141 [ 271ULL ] = U_idx_2 ; t141 [ 272ULL ] = - U_idx_2 ; t141 [
273ULL ] = X [ 105ULL ] ; t141 [ 274ULL ] = - X [ 114ULL ] ; t141 [ 275ULL ]
= X [ 132ULL ] ; t141 [ 276ULL ] = X [ 103ULL ] ; t141 [ 277ULL ] = X [
104ULL ] * 0.1 ; t141 [ 278ULL ] = X [ 105ULL ] ; t141 [ 279ULL ] = X [
133ULL ] ; t141 [ 280ULL ] = U_idx_2 ; t141 [ 281ULL ] = X [ 134ULL ] ; t141
[ 282ULL ] = X [ 110ULL ] ; t141 [ 283ULL ] = X [ 111ULL ] * 0.1 ; t141 [
284ULL ] = - X [ 114ULL ] ; t141 [ 285ULL ] = X [ 135ULL ] ; t141 [ 286ULL ]
= - U_idx_2 ; t141 [ 287ULL ] = X [ 136ULL ] ; t141 [ 288ULL ] = X [ 137ULL ]
; t141 [ 289ULL ] = X [ 138ULL ] * 0.1 ; t141 [ 290ULL ] = X [ 92ULL ] ; t141
[ 291ULL ] = X [ 93ULL ] * 0.1 ; t141 [ 292ULL ] = U_idx_2 ; t141 [ 293ULL ]
= X [ 139ULL ] ; t141 [ 294ULL ] = - X [ 96ULL ] ; t141 [ 295ULL ] = X [
137ULL ] ; t141 [ 296ULL ] = X [ 138ULL ] * 0.1 ; t141 [ 297ULL ] = X [
139ULL ] ; t141 [ 298ULL ] = X [ 140ULL ] ; t141 [ 299ULL ] = U_idx_2 ; t141
[ 300ULL ] = X [ 141ULL ] ; t141 [ 301ULL ] = X [ 92ULL ] ; t141 [ 302ULL ] =
X [ 93ULL ] * 0.1 ; t141 [ 303ULL ] = - X [ 96ULL ] ; t141 [ 304ULL ] = X [
142ULL ] ; t141 [ 305ULL ] = - U_idx_2 ; t141 [ 306ULL ] = X [ 141ULL ] ;
t141 [ 307ULL ] = U_idx_2 ; t141 [ 308ULL ] = - U_idx_2 ; t141 [ 309ULL ] =
U_idx_0 ; t141 [ 310ULL ] = U_idx_0 ; t141 [ 311ULL ] = 0.0 ; t141 [ 312ULL ]
= U_idx_0 ; t141 [ 313ULL ] = U_idx_0 ; t141 [ 314ULL ] = 0.0 ; t141 [ 315ULL
] = X [ 13ULL ] ; t141 [ 316ULL ] = X [ 13ULL ] ; t141 [ 317ULL ] = 0.0 ;
t141 [ 318ULL ] = X [ 13ULL ] ; t141 [ 319ULL ] = X [ 13ULL ] ; t141 [ 320ULL
] = 0.0 ; t141 [ 321ULL ] = X [ 92ULL ] ; t141 [ 322ULL ] = X [ 93ULL ] * 0.1
; t141 [ 323ULL ] = X [ 137ULL ] ; t141 [ 324ULL ] = X [ 138ULL ] * 0.1 ;
t141 [ 325ULL ] = 0.9 ; t141 [ 326ULL ] = X [ 92ULL ] ; t141 [ 327ULL ] = X [
93ULL ] * 0.1 ; t141 [ 328ULL ] = t210 * 1000.0 ; t141 [ 329ULL ] = 0.9 ;
t141 [ 330ULL ] = t210 * 1111.1111111111111 ; t141 [ 331ULL ] = t210 *
1111.1111111111111 ; t141 [ 332ULL ] = t209 * 99999.999999999985 ; t141 [
333ULL ] = X [ 143ULL ] * 1.0E-6 ; t141 [ 334ULL ] = t210 * 1000.0 ; t141 [
335ULL ] = X [ 137ULL ] ; t141 [ 336ULL ] = X [ 138ULL ] * 0.1 ; t141 [
337ULL ] = X [ 92ULL ] ; t141 [ 338ULL ] = X [ 93ULL ] * 0.1 ; t141 [ 339ULL
] = t209 * 99999.999999999985 ; t141 [ 340ULL ] = X [ 137ULL ] - X [ 92ULL ]
; t141 [ 341ULL ] = X [ 92ULL ] ; t141 [ 342ULL ] = X [ 93ULL ] * 0.1 ; t141
[ 343ULL ] = X [ 92ULL ] ; t141 [ 344ULL ] = X [ 93ULL ] * 0.1 ; t141 [
345ULL ] = X [ 96ULL ] ; t141 [ 346ULL ] = X [ 143ULL ] * 1.0E-6 ; t141 [
347ULL ] = U_idx_2 ; t141 [ 348ULL ] = U_idx_2 ; t141 [ 349ULL ] = X [ 137ULL
] ; t141 [ 350ULL ] = X [ 138ULL ] * 0.1 ; t141 [ 351ULL ] = 0.0 ; t141 [
352ULL ] = 0.0 ; t141 [ 353ULL ] = X [ 119ULL ] ; t141 [ 354ULL ] = X [
120ULL ] * 0.1 ; t141 [ 355ULL ] = X [ 144ULL ] ; t141 [ 356ULL ] = X [
145ULL ] * 0.1 ; t141 [ 357ULL ] = X [ 144ULL ] ; t141 [ 358ULL ] = X [
145ULL ] * 0.1 ; t141 [ 359ULL ] = X [ 7ULL ] ; t141 [ 360ULL ] = U_idx_0 ;
t141 [ 361ULL ] = t214 * 1000.0 ; t141 [ 362ULL ] = t214 * 5000.0 ; t141 [
363ULL ] = 0.0 ; t141 [ 364ULL ] = X [ 8ULL ] ; t141 [ 365ULL ] = U_idx_0 ;
t141 [ 366ULL ] = Electrical_Cooling_System_Tank_Convection_HLiq_Q * 1000.0 ;
t141 [ 367ULL ] = Electrical_Cooling_System_Tank_Convection_HLiq_Q * 500000.0
; t141 [ 368ULL ] = 0.0 ; t141 [ 369ULL ] = X [ 146ULL ] ; t141 [ 370ULL ] =
X [ 147ULL ] * 0.1 ; t141 [ 371ULL ] = X [ 148ULL ] ; t141 [ 372ULL ] = X [
149ULL ] * 0.1 ; t141 [ 373ULL ] = X [ 150ULL ] ; t141 [ 374ULL ] = - X [
150ULL ] ; t141 [ 375ULL ] = X [ 151ULL ] ; t141 [ 376ULL ] = X [ 152ULL ] ;
t141 [ 377ULL ] = X [ 146ULL ] ; t141 [ 378ULL ] = X [ 147ULL ] * 0.1 ; t141
[ 379ULL ] = X [ 150ULL ] ; t141 [ 380ULL ] = X [ 153ULL ] ; t141 [ 381ULL ]
= X [ 154ULL ] ; t141 [ 382ULL ] = X [ 148ULL ] ; t141 [ 383ULL ] = X [
149ULL ] * 0.1 ; t141 [ 384ULL ] = - X [ 150ULL ] ; t141 [ 385ULL ] = X [
153ULL ] ; t141 [ 386ULL ] = - X [ 154ULL ] ; t141 [ 387ULL ] = X [ 154ULL ]
; t141 [ 388ULL ] = - X [ 154ULL ] ; t141 [ 389ULL ] = U_idx_0 ; t141 [
390ULL ] = U_idx_0 ; t141 [ 391ULL ] = X [ 146ULL ] ; t141 [ 392ULL ] = X [
147ULL ] * 0.1 ; t141 [ 393ULL ] = - X [ 150ULL ] ; t141 [ 394ULL ] = 300.0 ;
t141 [ 395ULL ] = X [ 146ULL ] ; t141 [ 396ULL ] = X [ 147ULL ] * 0.1 ; t141
[ 397ULL ] = - X [ 150ULL ] ; t141 [ 398ULL ] = X [ 155ULL ] ; t141 [ 399ULL
] = - X [ 154ULL ] ; t141 [ 400ULL ] = 0.101325 ; t141 [ 401ULL ] = - X [
154ULL ] ; t141 [ 402ULL ] = X [ 119ULL ] ; t141 [ 403ULL ] = X [ 120ULL ] *
0.1 ; t141 [ 404ULL ] = 0.0 ; t141 [ 405ULL ] = 0.0 ; t141 [ 406ULL ] = X [
120ULL ] * 99999.999999999985 ; t141 [ 407ULL ] = X [ 119ULL ] ; t141 [
408ULL ] = X [ 119ULL ] ; t141 [ 409ULL ] = X [ 148ULL ] ; t141 [ 410ULL ] =
X [ 149ULL ] * 0.1 ; t141 [ 411ULL ] = X [ 137ULL ] ; t141 [ 412ULL ] = X [
138ULL ] * 0.1 ; t141 [ 413ULL ] = X [ 144ULL ] ; t141 [ 414ULL ] = X [
145ULL ] * 0.1 ; t141 [ 415ULL ] = X [ 119ULL ] ; t141 [ 416ULL ] = X [
120ULL ] * 0.1 ; t141 [ 417ULL ] = X [ 150ULL ] ; t141 [ 418ULL ] = - X [
139ULL ] ; t141 [ 419ULL ] = 0.0 ; t141 [ 420ULL ] = - X [ 121ULL ] ; t141 [
421ULL ] = X [ 156ULL ] ; t141 [ 422ULL ] = X [ 157ULL ] ; t141 [ 423ULL ] =
X [ 7ULL ] ; t141 [ 424ULL ] = X [ 8ULL ] ; t141 [ 425ULL ] = X [ 7ULL ] +
126.84999999999997 ; t141 [ 426ULL ] = X [ 154ULL ] ; t141 [ 427ULL ] = -
U_idx_2 ; t141 [ 428ULL ] = 0.0 ; t141 [ 429ULL ] = U_idx_2 ; t141 [ 430ULL ]
= X [ 15ULL ] * 0.1 ; t141 [ 431ULL ] = X [ 15ULL ] * 0.1 ; t141 [ 432ULL ] =
X [ 159ULL ] ; t141 [ 433ULL ] = X [ 160ULL ] ; t141 [ 434ULL ] = X [ 161ULL
] ; t141 [ 435ULL ] = X [ 162ULL ] ; t141 [ 436ULL ] = X [ 163ULL ] ; t141 [
437ULL ] = X [ 165ULL ] ; t141 [ 438ULL ] = X [ 166ULL ] ; t141 [ 439ULL ] =
X [ 167ULL ] ; t141 [ 440ULL ] = X [ 7ULL ] ; t141 [ 441ULL ] = X [ 8ULL ] ;
t141 [ 442ULL ] = Electrical_Cooling_System_Tank_Tank_level ; t141 [ 443ULL ]
= - t214 ; t141 [ 444ULL ] = -
Electrical_Cooling_System_Tank_Convection_HLiq_Q ; t141 [ 445ULL ] = X [ 7ULL
] ; t141 [ 446ULL ] = X [ 8ULL ] ; t141 [ 447ULL ] =
Electrical_Cooling_System_Tank_Tank_level * 0.005 ; t141 [ 448ULL ] =
Electrical_Cooling_System_Tank_Tank_level ; t141 [ 449ULL ] = X [ 14ULL ] ;
t141 [ 450ULL ] = X [ 15ULL ] * 0.1 ; t141 [ 451ULL ] = X [ 15ULL ] * 0.1 ;
t141 [ 452ULL ] = X [ 161ULL ] ; t141 [ 453ULL ] = X [ 164ULL ] ; t141 [
454ULL ] = X [ 158ULL ] * 0.001 ; t141 [ 455ULL ] =
Electrical_Cooling_System_Tank_Tank_level * 0.005 ; t141 [ 456ULL ] = X [
5ULL ] ; t141 [ 457ULL ] = X [ 10ULL ] ; t141 [ 458ULL ] = X [ 5ULL ] ; t141
[ 459ULL ] = X [ 10ULL ] ; t141 [ 460ULL ] = X [ 168ULL ] * 1000.0 ; t141 [
461ULL ] = X [ 168ULL ] * 0.5372318754156804 ; t141 [ 462ULL ] = 0.0 ; t141 [
463ULL ] = X [ 10ULL ] ; t141 [ 464ULL ] = X [ 10ULL ] ; t141 [ 465ULL ] = X
[ 127ULL ] * 1000.0 ; t141 [ 466ULL ] = X [ 127ULL ] * 1000.0 ; t141 [ 467ULL
] = X [ 127ULL ] * 1000.0 ; t141 [ 468ULL ] = X [ 10ULL ] ; t141 [ 469ULL ] =
0.0 ; t141 [ 470ULL ] = X [ 10ULL ] ; t141 [ 471ULL ] = X [ 10ULL ] ; t141 [
472ULL ] = X [ 10ULL ] ; t141 [ 473ULL ] = ( - X [ 127ULL ] + X [ 168ULL ] )
* 1000.0 ; t141 [ 474ULL ] = X [ 10ULL ] ; t141 [ 475ULL ] = 0.0 ; t141 [
476ULL ] = X [ 13ULL ] ; t141 [ 477ULL ] = X [ 12ULL ] ; t141 [ 478ULL ] = X
[ 16ULL ] ; t141 [ 479ULL ] = X [ 16ULL ] ; t141 [ 480ULL ] = X [ 12ULL ] ;
t141 [ 481ULL ] = X [ 12ULL ] ; t141 [ 482ULL ] = X [ 132ULL ] * 1000.0 ;
t141 [ 483ULL ] = X [ 132ULL ] * 1000.0 ; t141 [ 484ULL ] = X [ 132ULL ] *
1000.0 ; t141 [ 485ULL ] = X [ 12ULL ] ; t141 [ 486ULL ] = X [ 16ULL ] ; t141
[ 487ULL ] = X [ 169ULL ] * 1000.0 ; t141 [ 488ULL ] = X [ 169ULL ] *
0.28663972253274855 ; t141 [ 489ULL ] = 0.0 ; t141 [ 490ULL ] = X [ 16ULL ] ;
t141 [ 491ULL ] = X [ 16ULL ] ; t141 [ 492ULL ] = X [ 169ULL ] * 1000.0 ;
t141 [ 493ULL ] = X [ 16ULL ] ; t141 [ 494ULL ] = X [ 12ULL ] ; t141 [ 495ULL
] = X [ 12ULL ] ; t141 [ 496ULL ] = ( ( ( X [ 12ULL ] * - 0.89999999999999991
+ X [ 17ULL ] * 0.89999999999999991 ) - X [ 132ULL ] ) - X [ 169ULL ] ) *
1000.0 ; t141 [ 497ULL ] = X [ 12ULL ] ; t141 [ 498ULL ] = X [ 17ULL ] ; t141
[ 499ULL ] = X [ 13ULL ] ; t141 [ 500ULL ] = X [ 170ULL ] * 1000.0 ; t141 [
501ULL ] = X [ 170ULL ] * 0.9967088673201091 ; t141 [ 502ULL ] = 0.0 ; t141 [
503ULL ] = X [ 12ULL ] ; t141 [ 504ULL ] = X [ 17ULL ] ; t141 [ 505ULL ] =
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co * 1000.0 ;
t141 [ 506ULL ] =
Electrical_Cooling_System_Thermal_Circuit_Motor_Winding_Iron_Co *
1.1111111111111112 ; t141 [ 507ULL ] = 0.0 ; t141 [ 508ULL ] = X [ 17ULL ] ;
t141 [ 509ULL ] = X [ 17ULL ] ; t141 [ 510ULL ] = ( ( X [ 12ULL ] *
0.89999999999999991 + X [ 17ULL ] * - 0.89999999999999991 ) - X [ 170ULL ] )
* 1000.0 ; t141 [ 511ULL ] = X [ 17ULL ] ; t141 [ 512ULL ] = X [ 137ULL ] ;
t141 [ 513ULL ] = X [ 138ULL ] * 0.1 ; t141 [ 514ULL ] = X [ 92ULL ] ; t141 [
515ULL ] = X [ 93ULL ] * 0.1 ; t141 [ 516ULL ] = X [ 92ULL ] ; t141 [ 517ULL
] = X [ 93ULL ] * 0.1 ; t141 [ 518ULL ] = X [ 92ULL ] ; t141 [ 519ULL ] = X [
93ULL ] * 0.1 ; t141 [ 520ULL ] = X [ 92ULL ] ; t141 [ 521ULL ] = X [ 93ULL ]
* 0.1 ; t141 [ 522ULL ] = U_idx_2 ; t141 [ 523ULL ] = X [ 96ULL ] * 1000.0 ;
t141 [ 524ULL ] = X [ 96ULL ] ; t141 [ 525ULL ] = U_idx_2 ; t141 [ 526ULL ] =
U_idx_2 ; t141 [ 527ULL ] = X [ 96ULL ] * 1000.0 ; t141 [ 528ULL ] = X [
92ULL ] ; t141 [ 529ULL ] = X [ 93ULL ] * 0.1 ; t141 [ 530ULL ] =
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 * 0.001 ;
t141 [ 531ULL ] = t218 ; t141 [ 532ULL ] = t219 ; t141 [ 533ULL ] =
Electrical_Cooling_System_sensor1_Thermodynamic_Properties_Sen0 * 0.001 ;
t141 [ 534ULL ] = t219 ; t141 [ 535ULL ] = X [ 101ULL ] ; t141 [ 536ULL ] = X
[ 102ULL ] * 0.1 ; t141 [ 537ULL ] = 0.0 ; t141 [ 538ULL ] = 0.0 ; t141 [
539ULL ] = X [ 101ULL ] ; t141 [ 540ULL ] = X [ 102ULL ] * 0.1 ; t141 [
541ULL ] = X [ 101ULL ] ; t141 [ 542ULL ] = X [ 102ULL ] * 0.1 ; t141 [
543ULL ] = X [ 101ULL ] ; t141 [ 544ULL ] = X [ 102ULL ] * 0.1 ; t141 [
545ULL ] = U_idx_2 ; t141 [ 546ULL ] = X [ 105ULL ] * 1000.0 ; t141 [ 547ULL
] = X [ 105ULL ] ; t141 [ 548ULL ] = U_idx_2 ; t141 [ 549ULL ] = U_idx_2 ;
t141 [ 550ULL ] = X [ 105ULL ] * 1000.0 ; t141 [ 551ULL ] = X [ 101ULL ] ;
t141 [ 552ULL ] = X [ 102ULL ] * 0.1 ; t141 [ 553ULL ] = 0.0 ; t141 [ 554ULL
] = 0.0 ; t141 [ 555ULL ] = X [ 102ULL ] * 99999.999999999985 ; t141 [ 556ULL
] = X [ 101ULL ] ; t141 [ 557ULL ] = X [ 101ULL ] ; t141 [ 558ULL ] = X [
101ULL ] ; t141 [ 559ULL ] = X [ 102ULL ] * 0.1 ; t141 [ 560ULL ] = t222 *
0.001 ; t141 [ 561ULL ] = t223 ; t141 [ 562ULL ] = t224 ; t141 [ 563ULL ] =
t224 ; t141 [ 564ULL ] = X [ 110ULL ] ; t141 [ 565ULL ] = X [ 111ULL ] * 0.1
; t141 [ 566ULL ] = 0.0 ; t141 [ 567ULL ] = 0.0 ; t141 [ 568ULL ] = X [
110ULL ] ; t141 [ 569ULL ] = X [ 111ULL ] * 0.1 ; t141 [ 570ULL ] = X [
110ULL ] ; t141 [ 571ULL ] = X [ 111ULL ] * 0.1 ; t141 [ 572ULL ] = X [
110ULL ] ; t141 [ 573ULL ] = X [ 111ULL ] * 0.1 ; t141 [ 574ULL ] = U_idx_2 ;
t141 [ 575ULL ] = X [ 114ULL ] * 1000.0 ; t141 [ 576ULL ] = X [ 114ULL ] ;
t141 [ 577ULL ] = U_idx_2 ; t141 [ 578ULL ] = U_idx_2 ; t141 [ 579ULL ] = X [
114ULL ] * 1000.0 ; t141 [ 580ULL ] = X [ 110ULL ] ; t141 [ 581ULL ] = X [
111ULL ] * 0.1 ; t141 [ 582ULL ] = 0.0 ; t141 [ 583ULL ] = 0.0 ; t141 [
584ULL ] = X [ 111ULL ] * 99999.999999999985 ; t141 [ 585ULL ] = X [ 110ULL ]
; t141 [ 586ULL ] = X [ 110ULL ] ; t141 [ 587ULL ] = X [ 111ULL ] * 0.1 ;
t141 [ 588ULL ] = t227 * 0.001 ; t141 [ 589ULL ] = t228 ; t141 [ 590ULL ] =
t229 ; t141 [ 591ULL ] = t229 ; t141 [ 592ULL ] = X [ 119ULL ] ; t141 [
593ULL ] = X [ 120ULL ] * 0.1 ; t141 [ 594ULL ] = 0.0 ; t141 [ 595ULL ] = 0.0
; t141 [ 596ULL ] = X [ 119ULL ] ; t141 [ 597ULL ] = X [ 120ULL ] * 0.1 ;
t141 [ 598ULL ] = X [ 119ULL ] ; t141 [ 599ULL ] = X [ 120ULL ] * 0.1 ; t141
[ 600ULL ] = X [ 119ULL ] ; t141 [ 601ULL ] = X [ 120ULL ] * 0.1 ; t141 [
602ULL ] = U_idx_2 ; t141 [ 603ULL ] = X [ 121ULL ] * - 1000.0 ; t141 [
604ULL ] = - X [ 121ULL ] ; t141 [ 605ULL ] = U_idx_2 ; t141 [ 606ULL ] =
U_idx_2 ; t141 [ 607ULL ] = X [ 121ULL ] * - 1000.0 ; t141 [ 608ULL ] = X [
119ULL ] ; t141 [ 609ULL ] = X [ 120ULL ] * 0.1 ; t141 [ 610ULL ] = 0.0 ;
t141 [ 611ULL ] = 0.0 ; t141 [ 612ULL ] = X [ 120ULL ] * 99999.999999999985 ;
t141 [ 613ULL ] = X [ 119ULL ] ; t141 [ 614ULL ] = X [ 119ULL ] ; t141 [
615ULL ] = X [ 120ULL ] * 0.1 ; t141 [ 616ULL ] = t230 * 0.001 ; t141 [
617ULL ] = t231 ; t141 [ 618ULL ] = t232 ; t141 [ 619ULL ] = t232 ; t141 [
620ULL ] = 0.0 ; t141 [ 621ULL ] = X [ 18ULL ] * - 0.1 + X [ 89ULL ] * 0.1 ;
t141 [ 622ULL ] = 0.0 ; t141 [ 623ULL ] = X [ 89ULL ] ; t141 [ 624ULL ] = X [
89ULL ] ; t141 [ 625ULL ] = X [ 18ULL ] ; t141 [ 626ULL ] = X [ 171ULL ] ;
t141 [ 627ULL ] = U_idx_13 ; t141 [ 628ULL ] = 0.0 ; t141 [ 629ULL ] = 0.0 ;
t141 [ 630ULL ] = Fuel_Cell_Boost_Converter_L_i ; t141 [ 631ULL ] =
Fuel_Cell_Boost_Converter_L_n_v ; t141 [ 632ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 633ULL ] = X [ 172ULL ] ; t141 [
634ULL ] = X [ 19ULL ] ; t141 [ 635ULL ] = Fuel_Cell_Boost_Converter_L_n_v ;
t141 [ 636ULL ] = ( ( ( ( X [ 18ULL ] * 0.1 - X [ 88ULL ] ) + X [ 89ULL ] * -
0.1 ) + X [ 172ULL ] * 1.0E-9 ) - X [ 174ULL ] ) + X [ 19ULL ] ; t141 [
637ULL ] = X [ 19ULL ] ; t141 [ 638ULL ] = Fuel_Cell_Boost_Converter_L_i ;
t141 [ 639ULL ] = Fuel_Cell_Boost_Converter_L_i ; t141 [ 640ULL ] = 0.0 ;
t141 [ 641ULL ] = 0.0 ; t141 [ 642ULL ] = Fuel_Cell_Boost_Converter_L_p_v ;
t141 [ 643ULL ] = X [ 89ULL ] ; t141 [ 644ULL ] = X [ 18ULL ] ; t141 [ 645ULL
] = Fuel_Cell_Current_Sensor1_I ; t141 [ 646ULL ] =
Fuel_Cell_Current_Sensor1_I ; t141 [ 647ULL ] = X [ 89ULL ] ; t141 [ 648ULL ]
= X [ 89ULL ] ; t141 [ 649ULL ] = Fuel_Cell_Current_Sensor1_I ; t141 [ 650ULL
] = 0.0 ; t141 [ 651ULL ] = X [ 175ULL ] ; t141 [ 652ULL ] = X [ 176ULL ] *
0.1 ; t141 [ 653ULL ] = X [ 177ULL ] ; t141 [ 654ULL ] = X [ 178ULL ] ; t141
[ 655ULL ] = X [ 179ULL ] ; t141 [ 656ULL ] = 293.15 ; t141 [ 657ULL ] = -
184.19157727996955 + t235 * 1000.0 ; t141 [ 658ULL ] = ( X [ 179ULL ] *
0.00062831853071795862 - 0.18419157727996954 ) * 1591.5494309189535 ; t141 [
659ULL ] = 0.0 ; t141 [ 660ULL ] = X [ 180ULL ] ; t141 [ 661ULL ] = 0.101325
; t141 [ 662ULL ] = X [ 181ULL ] ; t141 [ 663ULL ] = X [ 182ULL ] ; t141 [
664ULL ] = X [ 183ULL ] ; t141 [ 665ULL ] = X [ 184ULL ] ; t141 [ 666ULL ] =
0.0 ; t141 [ 667ULL ] = X [ 192ULL ] ; t141 [ 668ULL ] = X [ 191ULL ] ; t141
[ 669ULL ] = 293.15 ; t141 [ 670ULL ] = X [ 180ULL ] ; t141 [ 671ULL ] =
0.101325 ; t141 [ 672ULL ] = X [ 181ULL ] ; t141 [ 673ULL ] = X [ 182ULL ] ;
t141 [ 674ULL ] = X [ 184ULL ] ; t141 [ 675ULL ] = X [ 185ULL ] ; t141 [
676ULL ] = X [ 186ULL ] ; t141 [ 677ULL ] = X [ 187ULL ] ; t141 [ 678ULL ] =
X [ 188ULL ] ; t141 [ 679ULL ] = X [ 189ULL ] ; t141 [ 680ULL ] = X [ 190ULL
] ; t141 [ 681ULL ] = X [ 186ULL ] ; t141 [ 682ULL ] = X [ 187ULL ] ; t141 [
683ULL ] = X [ 188ULL ] ; t141 [ 684ULL ] = 0.101325 ; t141 [ 685ULL ] =
0.9997 ; t141 [ 686ULL ] = X [ 193ULL ] ; t141 [ 687ULL ] = 293.15 ; t141 [
688ULL ] = - 184.19157727996955 + t235 * 1000.0 ; t141 [ 689ULL ] = U_idx_3 ;
t141 [ 690ULL ] = U_idx_3 * 3.1415926535897929E-6 ; t141 [ 691ULL ] = X [
175ULL ] ; t141 [ 692ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 693ULL ] = X [
177ULL ] ; t141 [ 694ULL ] = X [ 178ULL ] ; t141 [ 695ULL ] = X [ 194ULL ] ;
t141 [ 696ULL ] = X [ 195ULL ] * 0.1 ; t141 [ 697ULL ] = X [ 196ULL ] ; t141
[ 698ULL ] = X [ 197ULL ] ; t141 [ 699ULL ] = X [ 24ULL ] ; t141 [ 700ULL ] =
X [ 202ULL ] ; t141 [ 701ULL ] = X [ 23ULL ] ; t141 [ 702ULL ] = X [ 199ULL ]
; t141 [ 703ULL ] = X [ 21ULL ] - 273.15 ; t141 [ 704ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t141 [
705ULL ] = X [ 200ULL ] * 0.1 ; t141 [ 706ULL ] = X [ 22ULL ] * 0.1 ; t141 [
707ULL ] = X [ 201ULL ] ; t141 [ 708ULL ] = X [ 203ULL ] ; t141 [ 709ULL ] =
- X [ 186ULL ] ; t141 [ 710ULL ] = X [ 204ULL ] * 0.1 ; for ( t197 = 0ULL ;
t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 711ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_F [ t197 ] ; }
t141 [ 719ULL ] = X [ 179ULL ] ; t141 [ 720ULL ] = X [ 205ULL ] ; t141 [
721ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 ;
t141 [ 722ULL ] = - X [ 184ULL ] ; t141 [ 723ULL ] = 0.0 ; t141 [ 724ULL ] =
0.18419157727996954 - t235 ; t141 [ 725ULL ] = X [ 206ULL ] ; t141 [ 726ULL ]
= X [ 21ULL ] ; t141 [ 727ULL ] = X [ 24ULL ] ; t141 [ 728ULL ] = X [ 23ULL ]
; t141 [ 729ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_rh ; t141 [
730ULL ] = X [ 175ULL ] ; t141 [ 731ULL ] = X [ 176ULL ] * 0.1 ; t141 [
732ULL ] = X [ 177ULL ] ; t141 [ 733ULL ] = X [ 178ULL ] ; t141 [ 734ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_P0 ; t141 [
735ULL ] = X [ 209ULL ] ; t141 [ 736ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c0 ; t141 [
737ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 ;
t141 [ 738ULL ] = t234 ; t141 [ 739ULL ] = X [ 214ULL ] ; t141 [ 740ULL ] = X
[ 215ULL ] ; t141 [ 741ULL ] = X [ 194ULL ] ; t141 [ 742ULL ] = X [ 195ULL ]
* 0.1 ; t141 [ 743ULL ] = X [ 196ULL ] ; t141 [ 744ULL ] = X [ 197ULL ] ;
t141 [ 745ULL ] = - X [ 184ULL ] ; t141 [ 746ULL ] = X [ 216ULL ] ; t141 [
747ULL ] = - X [ 186ULL ] ; t141 [ 748ULL ] = - X [ 187ULL ] ; t141 [ 749ULL
] = - X [ 188ULL ] ; t141 [ 750ULL ] = X [ 217ULL ] ; t141 [ 751ULL ] = X [
218ULL ] ; t141 [ 752ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Exhaust_Pipe_MA_c4 ; t141 [
753ULL ] = - X [ 187ULL ] ; t141 [ 754ULL ] = 0.0 ; t141 [ 755ULL ] = 0.0 ;
t141 [ 756ULL ] = t234 ; t141 [ 757ULL ] = - X [ 188ULL ] ; t141 [ 758ULL ] =
X [ 194ULL ] ; t141 [ 759ULL ] = X [ 195ULL ] * 0.1 ; t141 [ 760ULL ] = X [
196ULL ] ; t141 [ 761ULL ] = X [ 197ULL ] ; t141 [ 762ULL ] = U_idx_3 *
0.031415926535897927 * 0.0001 ; t141 [ 763ULL ] = X [ 180ULL ] ; t141 [
764ULL ] = 0.101325 ; t141 [ 765ULL ] = X [ 181ULL ] ; t141 [ 766ULL ] = X [
182ULL ] ; t141 [ 767ULL ] = X [ 186ULL ] ; t141 [ 768ULL ] = X [ 194ULL ] ;
t141 [ 769ULL ] = X [ 195ULL ] * 0.1 ; t141 [ 770ULL ] = X [ 196ULL ] ; t141
[ 771ULL ] = X [ 197ULL ] ; t141 [ 772ULL ] = X [ 184ULL ] ; t141 [ 773ULL ]
= X [ 225ULL ] ; t141 [ 774ULL ] = X [ 186ULL ] ; t141 [ 775ULL ] = X [
187ULL ] ; t141 [ 776ULL ] = X [ 188ULL ] ; t141 [ 777ULL ] = X [ 222ULL ] ;
t141 [ 778ULL ] = X [ 221ULL ] ; t141 [ 779ULL ] = X [ 219ULL ] ; t141 [
780ULL ] = X [ 220ULL ] * 0.1 ; t141 [ 781ULL ] = X [ 223ULL ] ; t141 [
782ULL ] = X [ 224ULL ] ; t141 [ 783ULL ] = X [ 184ULL ] ; t141 [ 784ULL ] =
- X [ 184ULL ] ; t141 [ 785ULL ] = X [ 180ULL ] ; t141 [ 786ULL ] = 0.101325
; t141 [ 787ULL ] = X [ 181ULL ] ; t141 [ 788ULL ] = X [ 182ULL ] ; t141 [
789ULL ] = - X [ 184ULL ] ; t141 [ 790ULL ] = X [ 225ULL ] ; t141 [ 791ULL ]
= - X [ 186ULL ] ; t141 [ 792ULL ] = - X [ 187ULL ] ; t141 [ 793ULL ] = - X [
188ULL ] ; t141 [ 794ULL ] = X [ 222ULL ] ; t141 [ 795ULL ] = X [ 221ULL ] ;
t141 [ 796ULL ] = - X [ 186ULL ] ; t141 [ 797ULL ] = X [ 187ULL ] ; t141 [
798ULL ] = - X [ 187ULL ] ; t141 [ 799ULL ] = X [ 188ULL ] ; t141 [ 800ULL ]
= - X [ 188ULL ] ; t141 [ 801ULL ] = U_idx_3 ; t141 [ 802ULL ] = X [ 226ULL ]
; t141 [ 803ULL ] = X [ 227ULL ] * 0.1 ; t141 [ 804ULL ] = X [ 228ULL ] ;
t141 [ 805ULL ] = X [ 229ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ )
{ t141 [ t197 + 806ULL ] = t154 [ t197 ] ; } for ( t197 = 0ULL ; t197 < 8ULL
; t197 ++ ) { t141 [ t197 + 814ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t197 ] ; }
t141 [ 822ULL ] = X [ 32ULL ] ; t141 [ 823ULL ] = X [ 240ULL ] ; t141 [
824ULL ] = X [ 241ULL ] * 0.1 ; t141 [ 825ULL ] = X [ 242ULL ] ; t141 [
826ULL ] = X [ 243ULL ] ; t141 [ 827ULL ] = X [ 226ULL ] ; t141 [ 828ULL ] =
X [ 227ULL ] * 0.1 ; t141 [ 829ULL ] = X [ 228ULL ] ; t141 [ 830ULL ] = X [
229ULL ] ; t141 [ 831ULL ] = X [ 26ULL ] ; t141 [ 832ULL ] = X [ 234ULL ] ;
t141 [ 833ULL ] = X [ 27ULL ] ; t141 [ 834ULL ] = X [ 245ULL ] ; t141 [
835ULL ] = X [ 25ULL ] - 273.15 ; t141 [ 836ULL ] = X [ 244ULL ] ; t141 [
837ULL ] = X [ 246ULL ] * 0.1 ; t141 [ 838ULL ] = X [ 31ULL ] * 0.1 ; t141 [
839ULL ] = X [ 232ULL ] ; t141 [ 840ULL ] = X [ 248ULL ] ; t141 [ 841ULL ] =
X [ 247ULL ] ; t141 [ 842ULL ] = X [ 249ULL ] * 0.1 ; for ( t197 = 0ULL ;
t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 843ULL ] = t154 [ t197 ] ; } t141 [
851ULL ] = X [ 32ULL ] ; t141 [ 852ULL ] = X [ 233ULL ] ; t141 [ 853ULL ] = X
[ 250ULL ] ; t141 [ 854ULL ] = X [ 251ULL ] ; t141 [ 855ULL ] = 0.0 ; t141 [
856ULL ] = X [ 252ULL ] ; t141 [ 857ULL ] = X [ 231ULL ] ; t141 [ 858ULL ] =
X [ 25ULL ] ; t141 [ 859ULL ] = X [ 26ULL ] ; t141 [ 860ULL ] = X [ 27ULL ] ;
t141 [ 861ULL ] = X [ 31ULL ] / ( t244 == 0.0 ? 1.0E-16 : t244 ) * t240 *
0.036813041167499325 / 0.001 * 100000.0 ; t141 [ 862ULL ] = X [ 240ULL ] ;
t141 [ 863ULL ] = X [ 241ULL ] * 0.1 ; t141 [ 864ULL ] = X [ 242ULL ] ; t141
[ 865ULL ] = X [ 243ULL ] ; t141 [ 866ULL ] = X [ 250ULL ] ; t141 [ 867ULL ]
= X [ 253ULL ] ; t141 [ 868ULL ] = X [ 244ULL ] ; t141 [ 869ULL ] = X [
254ULL ] ; t141 [ 870ULL ] = X [ 255ULL ] ; t141 [ 871ULL ] = X [ 256ULL ] ;
t141 [ 872ULL ] = X [ 257ULL ] ; t141 [ 873ULL ] = X [ 226ULL ] ; t141 [
874ULL ] = X [ 227ULL ] * 0.1 ; t141 [ 875ULL ] = X [ 228ULL ] ; t141 [
876ULL ] = X [ 229ULL ] ; t141 [ 877ULL ] = X [ 251ULL ] ; t141 [ 878ULL ] =
X [ 258ULL ] ; t141 [ 879ULL ] = X [ 247ULL ] ; t141 [ 880ULL ] = X [ 259ULL
] ; t141 [ 881ULL ] = X [ 260ULL ] ; t141 [ 882ULL ] = X [ 261ULL ] ; t141 [
883ULL ] = X [ 262ULL ] ; t141 [ 884ULL ] = X [ 254ULL ] ; t141 [ 885ULL ] =
X [ 259ULL ] ; t141 [ 886ULL ] = 0.0 ; t141 [ 887ULL ] = 0.0 ; t141 [ 888ULL
] = X [ 255ULL ] ; t141 [ 889ULL ] = X [ 260ULL ] ; t141 [ 890ULL ] = X [
226ULL ] ; t141 [ 891ULL ] = X [ 227ULL ] * 0.1 ; t141 [ 892ULL ] = X [
228ULL ] ; t141 [ 893ULL ] = X [ 229ULL ] ; t141 [ 894ULL ] = X [ 175ULL ] ;
t141 [ 895ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 896ULL ] = X [ 177ULL ] ; t141
[ 897ULL ] = X [ 178ULL ] ; t141 [ 898ULL ] = X [ 29ULL ] ; t141 [ 899ULL ] =
X [ 239ULL ] ; t141 [ 900ULL ] = X [ 30ULL ] ; t141 [ 901ULL ] = X [ 263ULL ]
; t141 [ 902ULL ] = X [ 28ULL ] - 273.15 ; t141 [ 903ULL ] = - X [ 247ULL ] ;
t141 [ 904ULL ] = X [ 264ULL ] * 0.1 ; t141 [ 905ULL ] = X [ 33ULL ] * 0.1 ;
t141 [ 906ULL ] = X [ 237ULL ] ; t141 [ 907ULL ] = X [ 265ULL ] ; t141 [
908ULL ] = X [ 198ULL ] ; t141 [ 909ULL ] = X [ 266ULL ] * 0.1 ; for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 910ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t197 ] ; }
t141 [ 918ULL ] = X [ 32ULL ] ; t141 [ 919ULL ] = X [ 238ULL ] ; t141 [
920ULL ] = - X [ 251ULL ] ; t141 [ 921ULL ] = X [ 207ULL ] ; t141 [ 922ULL ]
= - X [ 267ULL ] - X [ 268ULL ] ; t141 [ 923ULL ] = X [ 269ULL ] ; t141 [
924ULL ] = X [ 236ULL ] ; t141 [ 925ULL ] = X [ 28ULL ] ; t141 [ 926ULL ] = X
[ 29ULL ] ; t141 [ 927ULL ] = X [ 30ULL ] ; t141 [ 928ULL ] = t243 ; t141 [
929ULL ] = X [ 226ULL ] ; t141 [ 930ULL ] = X [ 227ULL ] * 0.1 ; t141 [
931ULL ] = X [ 228ULL ] ; t141 [ 932ULL ] = X [ 229ULL ] ; t141 [ 933ULL ] =
- X [ 251ULL ] ; t141 [ 934ULL ] = X [ 270ULL ] ; t141 [ 935ULL ] = - X [
247ULL ] ; t141 [ 936ULL ] = - X [ 259ULL ] ; t141 [ 937ULL ] = - X [ 260ULL
] ; t141 [ 938ULL ] = X [ 271ULL ] ; t141 [ 939ULL ] = X [ 272ULL ] ; t141 [
940ULL ] = X [ 175ULL ] ; t141 [ 941ULL ] = X [ 176ULL ] * 0.1 ; t141 [
942ULL ] = X [ 177ULL ] ; t141 [ 943ULL ] = X [ 178ULL ] ; t141 [ 944ULL ] =
X [ 207ULL ] ; t141 [ 945ULL ] = X [ 273ULL ] ; t141 [ 946ULL ] = X [ 198ULL
] ; t141 [ 947ULL ] = X [ 210ULL ] ; t141 [ 948ULL ] = X [ 212ULL ] ; t141 [
949ULL ] = X [ 274ULL ] ; t141 [ 950ULL ] = X [ 275ULL ] ; t141 [ 951ULL ] =
- X [ 259ULL ] ; t141 [ 952ULL ] = X [ 210ULL ] ; t141 [ 953ULL ] = X [
276ULL ] ; t141 [ 954ULL ] = X [ 277ULL ] ; t141 [ 955ULL ] = - X [ 260ULL ]
; t141 [ 956ULL ] = X [ 212ULL ] ; t141 [ 957ULL ] = X [ 28ULL ] ; t141 [
958ULL ] = X [ 29ULL ] ; t141 [ 959ULL ] = X [ 30ULL ] ; t141 [ 960ULL ] = X
[ 240ULL ] ; t141 [ 961ULL ] = X [ 241ULL ] * 0.1 ; t141 [ 962ULL ] = X [
242ULL ] ; t141 [ 963ULL ] = X [ 243ULL ] ; t141 [ 964ULL ] = X [ 175ULL ] ;
t141 [ 965ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 966ULL ] = X [ 177ULL ] ; t141
[ 967ULL ] = X [ 178ULL ] ; t141 [ 968ULL ] = X [ 278ULL ] ; t141 [ 969ULL ]
= X [ 38ULL ] * 0.1 ; t141 [ 970ULL ] = X [ 279ULL ] ; t141 [ 971ULL ] = X [
280ULL ] ; t141 [ 972ULL ] = X [ 240ULL ] ; t141 [ 973ULL ] = X [ 241ULL ] *
0.1 ; t141 [ 974ULL ] = X [ 242ULL ] ; t141 [ 975ULL ] = X [ 243ULL ] ; t141
[ 976ULL ] = U_idx_5 ; t141 [ 977ULL ] = X [ 281ULL ] ; t141 [ 978ULL ] = X [
34ULL ] ; t141 [ 979ULL ] = X [ 35ULL ] ; t141 [ 980ULL ] = X [ 36ULL ] ;
t141 [ 981ULL ] = U_idx_6 ; t141 [ 982ULL ] = - U_idx_5 ; for ( t197 = 0ULL ;
t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 983ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ t197 ] ; }
t141 [ 991ULL ] = X [ 284ULL ] ; t141 [ 992ULL ] = X [ 286ULL ] * 1.0E-5 *
99999.999999999985 ; t141 [ 993ULL ] = X [ 34ULL ] ; t141 [ 994ULL ] = X [
283ULL ] ; t141 [ 995ULL ] = X [ 283ULL ] ; t141 [ 996ULL ] = X [ 287ULL ] ;
t141 [ 997ULL ] = X [ 287ULL ] ; t141 [ 998ULL ] = X [ 278ULL ] ; t141 [
999ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 1000ULL ] = X [ 279ULL ] ; t141 [
1001ULL ] = X [ 280ULL ] ; t141 [ 1002ULL ] = X [ 240ULL ] ; t141 [ 1003ULL ]
= X [ 241ULL ] * 0.1 ; t141 [ 1004ULL ] = X [ 242ULL ] ; t141 [ 1005ULL ] = X
[ 243ULL ] ; t141 [ 1006ULL ] = X [ 35ULL ] ; t141 [ 1007ULL ] = X [ 284ULL ]
; t141 [ 1008ULL ] = X [ 36ULL ] ; t141 [ 1009ULL ] = X [ 289ULL ] ; t141 [
1010ULL ] = X [ 34ULL ] - 273.15 ; t141 [ 1011ULL ] = X [ 288ULL ] ; t141 [
1012ULL ] = X [ 290ULL ] * 0.1 ; t141 [ 1013ULL ] = X [ 37ULL ] * 0.1 ; t141
[ 1014ULL ] = X [ 285ULL ] ; t141 [ 1015ULL ] = X [ 291ULL ] ; t141 [ 1016ULL
] = - X [ 244ULL ] ; t141 [ 1017ULL ] = X [ 292ULL ] * 0.1 ; for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1018ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Humidifier_Measur0 [ t197 ] ; }
t141 [ 1026ULL ] = X [ 287ULL ] ; t141 [ 1027ULL ] = X [ 282ULL ] ; t141 [
1028ULL ] = X [ 293ULL ] ; t141 [ 1029ULL ] = - X [ 250ULL ] ; t141 [ 1030ULL
] = - X [ 281ULL ] ; t141 [ 1031ULL ] = 0.0 ; t141 [ 1032ULL ] = X [ 283ULL ]
; t141 [ 1033ULL ] = X [ 34ULL ] ; t141 [ 1034ULL ] = X [ 35ULL ] ; t141 [
1035ULL ] = X [ 36ULL ] ; t141 [ 1036ULL ] = X [ 37ULL ] / ( t266 == 0.0 ?
1.0E-16 : t266 ) * t252 * 0.00049087385212340522 / 0.001 * 100000.0 ; t141 [
1037ULL ] = X [ 278ULL ] ; t141 [ 1038ULL ] = X [ 38ULL ] * 0.1 ; t141 [
1039ULL ] = X [ 279ULL ] ; t141 [ 1040ULL ] = X [ 280ULL ] ; t141 [ 1041ULL ]
= X [ 293ULL ] ; t141 [ 1042ULL ] = X [ 294ULL ] ; t141 [ 1043ULL ] = X [
288ULL ] ; t141 [ 1044ULL ] = X [ 295ULL ] ; t141 [ 1045ULL ] = X [ 296ULL ]
; t141 [ 1046ULL ] = X [ 297ULL ] ; t141 [ 1047ULL ] = X [ 298ULL ] ; t141 [
1048ULL ] = X [ 240ULL ] ; t141 [ 1049ULL ] = X [ 241ULL ] * 0.1 ; t141 [
1050ULL ] = X [ 242ULL ] ; t141 [ 1051ULL ] = X [ 243ULL ] ; t141 [ 1052ULL ]
= - X [ 250ULL ] ; t141 [ 1053ULL ] = X [ 299ULL ] ; t141 [ 1054ULL ] = - X [
244ULL ] ; t141 [ 1055ULL ] = - X [ 254ULL ] ; t141 [ 1056ULL ] = - X [
255ULL ] ; t141 [ 1057ULL ] = X [ 300ULL ] ; t141 [ 1058ULL ] = X [ 301ULL ]
; t141 [ 1059ULL ] = X [ 295ULL ] ; t141 [ 1060ULL ] = - X [ 254ULL ] ; t141
[ 1061ULL ] = 0.0 ; t141 [ 1062ULL ] = U_idx_5 ; t141 [ 1063ULL ] = X [
296ULL ] ; t141 [ 1064ULL ] = - X [ 255ULL ] ; t141 [ 1065ULL ] = U_idx_6 ;
t141 [ 1066ULL ] = U_idx_5 ; t141 [ 1067ULL ] = X [ 302ULL ] ; t141 [ 1068ULL
] = X [ 303ULL ] * 0.1 ; t141 [ 1069ULL ] = X [ 304ULL ] ; t141 [ 1070ULL ] =
X [ 305ULL ] ; t141 [ 1071ULL ] = X [ 306ULL ] ; t141 [ 1072ULL ] = 293.15 ;
t141 [ 1073ULL ] = - 920.95788639984789 + t237 * 1000.0 ; t141 [ 1074ULL ] =
( X [ 306ULL ] * 0.0031415926535897937 - 0.92095788639984788 ) *
318.30988618379064 ; t141 [ 1075ULL ] = 0.0 ; t141 [ 1076ULL ] = X [ 307ULL ]
; t141 [ 1077ULL ] = 0.101325 ; t141 [ 1078ULL ] = X [ 308ULL ] ; t141 [
1079ULL ] = X [ 309ULL ] ; t141 [ 1080ULL ] = X [ 310ULL ] ; t141 [ 1081ULL ]
= X [ 311ULL ] ; t141 [ 1082ULL ] = 0.5 ; t141 [ 1083ULL ] = X [ 319ULL ] ;
t141 [ 1084ULL ] = X [ 318ULL ] ; t141 [ 1085ULL ] = 293.15 ; t141 [ 1086ULL
] = X [ 307ULL ] ; t141 [ 1087ULL ] = 0.101325 ; t141 [ 1088ULL ] = X [
308ULL ] ; t141 [ 1089ULL ] = X [ 309ULL ] ; t141 [ 1090ULL ] = X [ 311ULL ]
; t141 [ 1091ULL ] = X [ 312ULL ] ; t141 [ 1092ULL ] = X [ 313ULL ] ; t141 [
1093ULL ] = X [ 314ULL ] ; t141 [ 1094ULL ] = X [ 315ULL ] ; t141 [ 1095ULL ]
= X [ 316ULL ] ; t141 [ 1096ULL ] = X [ 317ULL ] ; t141 [ 1097ULL ] = X [
313ULL ] ; t141 [ 1098ULL ] = X [ 314ULL ] ; t141 [ 1099ULL ] = X [ 315ULL ]
; t141 [ 1100ULL ] = 0.101325 ; t141 [ 1101ULL ] = 0.21 ; t141 [ 1102ULL ] =
X [ 320ULL ] ; t141 [ 1103ULL ] = 293.15 ; t141 [ 1104ULL ] = -
920.95788639984789 + t237 * 1000.0 ; t141 [ 1105ULL ] = X [ 302ULL ] ; t141 [
1106ULL ] = X [ 303ULL ] * 0.1 ; t141 [ 1107ULL ] = X [ 304ULL ] ; t141 [
1108ULL ] = X [ 305ULL ] ; t141 [ 1109ULL ] = X [ 321ULL ] ; t141 [ 1110ULL ]
= t253 * 0.1 ; t141 [ 1111ULL ] = X [ 323ULL ] ; t141 [ 1112ULL ] = X [
324ULL ] ; t141 [ 1113ULL ] = X [ 42ULL ] ; t141 [ 1114ULL ] = X [ 329ULL ] ;
t141 [ 1115ULL ] = X [ 41ULL ] ; t141 [ 1116ULL ] = X [ 326ULL ] ; t141 [
1117ULL ] = X [ 39ULL ] - 273.15 ; t141 [ 1118ULL ] = X [ 325ULL ] ; t141 [
1119ULL ] = X [ 327ULL ] * 0.1 ; t141 [ 1120ULL ] = X [ 40ULL ] * 0.1 ; t141
[ 1121ULL ] = X [ 328ULL ] ; t141 [ 1122ULL ] = X [ 330ULL ] ; t141 [ 1123ULL
] = - X [ 313ULL ] ; t141 [ 1124ULL ] = X [ 331ULL ] * 0.1 ; for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1125ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M5 [ t197 ] ; }
t141 [ 1133ULL ] = X [ 306ULL ] ; t141 [ 1134ULL ] = X [ 332ULL ] ; t141 [
1135ULL ] = X [ 334ULL ] ; t141 [ 1136ULL ] = - X [ 311ULL ] ; t141 [ 1137ULL
] = 0.0 ; t141 [ 1138ULL ] = 0.92095788639984788 - t237 ; t141 [ 1139ULL ] =
X [ 333ULL ] ; t141 [ 1140ULL ] = X [ 39ULL ] ; t141 [ 1141ULL ] = X [ 42ULL
] ; t141 [ 1142ULL ] = X [ 41ULL ] ; t141 [ 1143ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Exhaust_Pipe_M16 ; t141 [
1144ULL ] = X [ 302ULL ] ; t141 [ 1145ULL ] = X [ 303ULL ] * 0.1 ; t141 [
1146ULL ] = X [ 304ULL ] ; t141 [ 1147ULL ] = X [ 305ULL ] ; t141 [ 1148ULL ]
= X [ 334ULL ] ; t141 [ 1149ULL ] = X [ 335ULL ] ; t141 [ 1150ULL ] = X [
325ULL ] ; t141 [ 1151ULL ] = X [ 336ULL ] ; t141 [ 1152ULL ] = X [ 337ULL ]
; t141 [ 1153ULL ] = X [ 338ULL ] ; t141 [ 1154ULL ] = X [ 339ULL ] ; t141 [
1155ULL ] = X [ 321ULL ] ; t141 [ 1156ULL ] = t253 * 0.1 ; t141 [ 1157ULL ] =
X [ 323ULL ] ; t141 [ 1158ULL ] = X [ 324ULL ] ; t141 [ 1159ULL ] = - X [
311ULL ] ; t141 [ 1160ULL ] = X [ 340ULL ] ; t141 [ 1161ULL ] = - X [ 313ULL
] ; t141 [ 1162ULL ] = - X [ 314ULL ] ; t141 [ 1163ULL ] = - X [ 315ULL ] ;
t141 [ 1164ULL ] = X [ 341ULL ] ; t141 [ 1165ULL ] = X [ 342ULL ] ; t141 [
1166ULL ] = X [ 336ULL ] ; t141 [ 1167ULL ] = - X [ 314ULL ] ; t141 [ 1168ULL
] = 0.0 ; t141 [ 1169ULL ] = 0.0 ; t141 [ 1170ULL ] = X [ 337ULL ] ; t141 [
1171ULL ] = - X [ 315ULL ] ; t141 [ 1172ULL ] = X [ 321ULL ] ; t141 [ 1173ULL
] = t253 * 0.1 ; t141 [ 1174ULL ] = X [ 323ULL ] ; t141 [ 1175ULL ] = X [
324ULL ] ; t141 [ 1176ULL ] = 0.0 ; t141 [ 1177ULL ] = 0.0 ; t141 [ 1178ULL ]
= 0.0 ; t141 [ 1179ULL ] = 0.0 ; t141 [ 1180ULL ] = X [ 307ULL ] ; t141 [
1181ULL ] = 0.101325 ; t141 [ 1182ULL ] = X [ 308ULL ] ; t141 [ 1183ULL ] = X
[ 309ULL ] ; t141 [ 1184ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 1.0E+6 ; t141 [
1185ULL ] = 1.0E-8 ; t141 [ 1186ULL ] = X [ 322ULL ] ; t141 [ 1187ULL ] =
1.0E-8 ; t141 [ 1188ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 7812.5001220703134 ;
t141 [ 1189ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 1.0E+6 ; t141 [ 1190ULL ] = X
[ 322ULL ] ; t141 [ 1191ULL ] = X [ 322ULL ] * 0.0019634954084936209 ; t141 [
1192ULL ] = t253 * 99999.999999999985 ; t141 [ 1193ULL ] = t256 * 0.1 ; t141
[ 1194ULL ] = ( X [ 322ULL ] - 1.0E-8 ) * 7812.5001220703134 ; t141 [ 1195ULL
] = X [ 321ULL ] ; t141 [ 1196ULL ] = t253 * 0.1 ; t141 [ 1197ULL ] = X [
323ULL ] ; t141 [ 1198ULL ] = X [ 324ULL ] ; t141 [ 1199ULL ] = 0.0 ; t141 [
1200ULL ] = 0.0 ; t141 [ 1201ULL ] = 0.0 ; t141 [ 1202ULL ] = 0.0 ; t141 [
1203ULL ] = t253 * 99999.999999999985 ; t141 [ 1204ULL ] = X [ 321ULL ] ;
t141 [ 1205ULL ] = X [ 321ULL ] ; t141 [ 1206ULL ] = t253 * 0.1 ; t141 [
1207ULL ] = X [ 323ULL ] ; t141 [ 1208ULL ] = X [ 324ULL ] ; t141 [ 1209ULL ]
= X [ 322ULL ] * 0.0019634954084936209 ; t141 [ 1210ULL ] = X [ 307ULL ] ;
t141 [ 1211ULL ] = 0.101325 ; t141 [ 1212ULL ] = X [ 308ULL ] ; t141 [
1213ULL ] = X [ 309ULL ] ; t141 [ 1214ULL ] = X [ 313ULL ] ; t141 [ 1215ULL ]
= X [ 321ULL ] ; t141 [ 1216ULL ] = t253 * 0.1 ; t141 [ 1217ULL ] = X [
323ULL ] ; t141 [ 1218ULL ] = X [ 324ULL ] ; t141 [ 1219ULL ] = X [ 311ULL ]
; t141 [ 1220ULL ] = X [ 349ULL ] ; t141 [ 1221ULL ] = X [ 313ULL ] ; t141 [
1222ULL ] = X [ 314ULL ] ; t141 [ 1223ULL ] = X [ 315ULL ] ; t141 [ 1224ULL ]
= X [ 346ULL ] ; t141 [ 1225ULL ] = X [ 345ULL ] ; t141 [ 1226ULL ] = X [
343ULL ] ; t141 [ 1227ULL ] = X [ 344ULL ] * 0.1 ; t141 [ 1228ULL ] = X [
347ULL ] ; t141 [ 1229ULL ] = X [ 348ULL ] ; t141 [ 1230ULL ] = X [ 311ULL ]
; t141 [ 1231ULL ] = - X [ 311ULL ] ; t141 [ 1232ULL ] = X [ 307ULL ] ; t141
[ 1233ULL ] = 0.101325 ; t141 [ 1234ULL ] = X [ 308ULL ] ; t141 [ 1235ULL ] =
X [ 309ULL ] ; t141 [ 1236ULL ] = - X [ 311ULL ] ; t141 [ 1237ULL ] = X [
349ULL ] ; t141 [ 1238ULL ] = - X [ 313ULL ] ; t141 [ 1239ULL ] = - X [
314ULL ] ; t141 [ 1240ULL ] = - X [ 315ULL ] ; t141 [ 1241ULL ] = X [ 346ULL
] ; t141 [ 1242ULL ] = X [ 345ULL ] ; t141 [ 1243ULL ] = - X [ 313ULL ] ;
t141 [ 1244ULL ] = X [ 314ULL ] ; t141 [ 1245ULL ] = - X [ 314ULL ] ; t141 [
1246ULL ] = X [ 315ULL ] ; t141 [ 1247ULL ] = - X [ 315ULL ] ; t141 [ 1248ULL
] = t256 * 0.1 ; t141 [ 1249ULL ] = U_idx_7 ; t141 [ 1250ULL ] = X [ 350ULL ]
; t141 [ 1251ULL ] = X [ 351ULL ] * 0.1 ; t141 [ 1252ULL ] = X [ 352ULL ] ;
t141 [ 1253ULL ] = X [ 353ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ )
{ t141 [ t197 + 1254ULL ] = t159 [ t197 ] ; } for ( t197 = 0ULL ; t197 < 8ULL
; t197 ++ ) { t141 [ t197 + 1262ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ t197 ] ; }
t141 [ 1270ULL ] = X [ 32ULL ] ; t141 [ 1271ULL ] = X [ 364ULL ] ; t141 [
1272ULL ] = X [ 365ULL ] * 0.1 ; t141 [ 1273ULL ] = X [ 366ULL ] ; t141 [
1274ULL ] = X [ 367ULL ] ; t141 [ 1275ULL ] = X [ 350ULL ] ; t141 [ 1276ULL ]
= X [ 351ULL ] * 0.1 ; t141 [ 1277ULL ] = X [ 352ULL ] ; t141 [ 1278ULL ] = X
[ 353ULL ] ; t141 [ 1279ULL ] = X [ 44ULL ] ; t141 [ 1280ULL ] = X [ 358ULL ]
; t141 [ 1281ULL ] = X [ 45ULL ] ; t141 [ 1282ULL ] = X [ 369ULL ] ; t141 [
1283ULL ] = X [ 43ULL ] - 273.15 ; t141 [ 1284ULL ] = X [ 368ULL ] ; t141 [
1285ULL ] = X [ 370ULL ] * 0.1 ; t141 [ 1286ULL ] = X [ 49ULL ] * 0.1 ; t141
[ 1287ULL ] = X [ 356ULL ] ; t141 [ 1288ULL ] = X [ 372ULL ] ; t141 [ 1289ULL
] = X [ 371ULL ] ; t141 [ 1290ULL ] = X [ 373ULL ] * 0.1 ; for ( t197 = 0ULL
; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1291ULL ] = t159 [ t197 ] ; } t141
[ 1299ULL ] = X [ 32ULL ] ; t141 [ 1300ULL ] = X [ 357ULL ] ; t141 [ 1301ULL
] = X [ 374ULL ] ; t141 [ 1302ULL ] = X [ 375ULL ] ; t141 [ 1303ULL ] = 0.0 ;
t141 [ 1304ULL ] = X [ 376ULL ] ; t141 [ 1305ULL ] = X [ 355ULL ] ; t141 [
1306ULL ] = X [ 43ULL ] ; t141 [ 1307ULL ] = X [ 44ULL ] ; t141 [ 1308ULL ] =
X [ 45ULL ] ; t141 [ 1309ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_16 ; t141 [
1310ULL ] = X [ 364ULL ] ; t141 [ 1311ULL ] = X [ 365ULL ] * 0.1 ; t141 [
1312ULL ] = X [ 366ULL ] ; t141 [ 1313ULL ] = X [ 367ULL ] ; t141 [ 1314ULL ]
= X [ 374ULL ] ; t141 [ 1315ULL ] = X [ 377ULL ] ; t141 [ 1316ULL ] = X [
368ULL ] ; t141 [ 1317ULL ] = X [ 378ULL ] ; t141 [ 1318ULL ] = X [ 379ULL ]
; t141 [ 1319ULL ] = X [ 380ULL ] ; t141 [ 1320ULL ] = X [ 381ULL ] ; t141 [
1321ULL ] = X [ 350ULL ] ; t141 [ 1322ULL ] = X [ 351ULL ] * 0.1 ; t141 [
1323ULL ] = X [ 352ULL ] ; t141 [ 1324ULL ] = X [ 353ULL ] ; t141 [ 1325ULL ]
= X [ 375ULL ] ; t141 [ 1326ULL ] = X [ 382ULL ] ; t141 [ 1327ULL ] = X [
371ULL ] ; t141 [ 1328ULL ] = X [ 383ULL ] ; t141 [ 1329ULL ] = X [ 384ULL ]
; t141 [ 1330ULL ] = X [ 385ULL ] ; t141 [ 1331ULL ] = X [ 386ULL ] ; t141 [
1332ULL ] = X [ 378ULL ] ; t141 [ 1333ULL ] = X [ 383ULL ] ; t141 [ 1334ULL ]
= 0.0 ; t141 [ 1335ULL ] = 0.0 ; t141 [ 1336ULL ] = X [ 379ULL ] ; t141 [
1337ULL ] = X [ 384ULL ] ; t141 [ 1338ULL ] = X [ 350ULL ] ; t141 [ 1339ULL ]
= X [ 351ULL ] * 0.1 ; t141 [ 1340ULL ] = X [ 352ULL ] ; t141 [ 1341ULL ] = X
[ 353ULL ] ; t141 [ 1342ULL ] = X [ 302ULL ] ; t141 [ 1343ULL ] = X [ 303ULL
] * 0.1 ; t141 [ 1344ULL ] = X [ 304ULL ] ; t141 [ 1345ULL ] = X [ 305ULL ] ;
t141 [ 1346ULL ] = X [ 47ULL ] ; t141 [ 1347ULL ] = X [ 363ULL ] ; t141 [
1348ULL ] = X [ 48ULL ] ; t141 [ 1349ULL ] = X [ 387ULL ] ; t141 [ 1350ULL ]
= X [ 46ULL ] - 273.15 ; t141 [ 1351ULL ] = - X [ 371ULL ] ; t141 [ 1352ULL ]
= X [ 388ULL ] * 0.1 ; t141 [ 1353ULL ] = X [ 50ULL ] * 0.1 ; t141 [ 1354ULL
] = X [ 361ULL ] ; t141 [ 1355ULL ] = X [ 389ULL ] ; t141 [ 1356ULL ] = - X [
325ULL ] ; t141 [ 1357ULL ] = X [ 390ULL ] * 0.1 ; for ( t197 = 0ULL ; t197 <
8ULL ; t197 ++ ) { t141 [ t197 + 1358ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [ t197 ] ; }
t141 [ 1366ULL ] = X [ 32ULL ] ; t141 [ 1367ULL ] = X [ 362ULL ] ; t141 [
1368ULL ] = - X [ 375ULL ] ; t141 [ 1369ULL ] = - X [ 334ULL ] ; t141 [
1370ULL ] = ( - X [ 391ULL ] - X [ 392ULL ] ) - X [ 393ULL ] ; t141 [ 1371ULL
] = X [ 394ULL ] ; t141 [ 1372ULL ] = X [ 360ULL ] ; t141 [ 1373ULL ] = X [
46ULL ] ; t141 [ 1374ULL ] = X [ 47ULL ] ; t141 [ 1375ULL ] = X [ 48ULL ] ;
t141 [ 1376ULL ] = X [ 50ULL ] / ( t294 == 0.0 ? 1.0E-16 : t294 ) * t268 *
0.036813041167499325 / 0.001 * 100000.0 ; t141 [ 1377ULL ] = X [ 350ULL ] ;
t141 [ 1378ULL ] = X [ 351ULL ] * 0.1 ; t141 [ 1379ULL ] = X [ 352ULL ] ;
t141 [ 1380ULL ] = X [ 353ULL ] ; t141 [ 1381ULL ] = - X [ 375ULL ] ; t141 [
1382ULL ] = X [ 395ULL ] ; t141 [ 1383ULL ] = - X [ 371ULL ] ; t141 [ 1384ULL
] = - X [ 383ULL ] ; t141 [ 1385ULL ] = - X [ 384ULL ] ; t141 [ 1386ULL ] = X
[ 396ULL ] ; t141 [ 1387ULL ] = X [ 397ULL ] ; t141 [ 1388ULL ] = X [ 302ULL
] ; t141 [ 1389ULL ] = X [ 303ULL ] * 0.1 ; t141 [ 1390ULL ] = X [ 304ULL ] ;
t141 [ 1391ULL ] = X [ 305ULL ] ; t141 [ 1392ULL ] = - X [ 334ULL ] ; t141 [
1393ULL ] = X [ 398ULL ] ; t141 [ 1394ULL ] = - X [ 325ULL ] ; t141 [ 1395ULL
] = - X [ 336ULL ] ; t141 [ 1396ULL ] = - X [ 337ULL ] ; t141 [ 1397ULL ] = X
[ 399ULL ] ; t141 [ 1398ULL ] = X [ 400ULL ] ; t141 [ 1399ULL ] = - X [
383ULL ] ; t141 [ 1400ULL ] = - X [ 336ULL ] ; t141 [ 1401ULL ] = X [ 401ULL
] ; t141 [ 1402ULL ] = X [ 402ULL ] ; t141 [ 1403ULL ] = - X [ 384ULL ] ;
t141 [ 1404ULL ] = - X [ 337ULL ] ; t141 [ 1405ULL ] = X [ 46ULL ] ; t141 [
1406ULL ] = X [ 47ULL ] ; t141 [ 1407ULL ] = X [ 48ULL ] ; t141 [ 1408ULL ] =
X [ 364ULL ] ; t141 [ 1409ULL ] = X [ 365ULL ] * 0.1 ; t141 [ 1410ULL ] = X [
366ULL ] ; t141 [ 1411ULL ] = X [ 367ULL ] ; t141 [ 1412ULL ] = X [ 302ULL ]
; t141 [ 1413ULL ] = X [ 303ULL ] * 0.1 ; t141 [ 1414ULL ] = X [ 304ULL ] ;
t141 [ 1415ULL ] = X [ 305ULL ] ; t141 [ 1416ULL ] = X [ 403ULL ] ; t141 [
1417ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 1418ULL ] = X [ 404ULL ] ; t141 [
1419ULL ] = X [ 405ULL ] ; t141 [ 1420ULL ] = X [ 364ULL ] ; t141 [ 1421ULL ]
= X [ 365ULL ] * 0.1 ; t141 [ 1422ULL ] = X [ 366ULL ] ; t141 [ 1423ULL ] = X
[ 367ULL ] ; t141 [ 1424ULL ] = U_idx_8 ; t141 [ 1425ULL ] = X [ 406ULL ] ;
t141 [ 1426ULL ] = X [ 51ULL ] ; t141 [ 1427ULL ] = X [ 52ULL ] ; t141 [
1428ULL ] = X [ 53ULL ] ; t141 [ 1429ULL ] = U_idx_9 ; t141 [ 1430ULL ] = -
U_idx_8 ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1431ULL
] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ t197 ]
; } t141 [ 1439ULL ] = X [ 409ULL ] ; t141 [ 1440ULL ] = X [ 411ULL ] *
1.0E-5 * 99999.999999999985 ; t141 [ 1441ULL ] = X [ 51ULL ] ; t141 [ 1442ULL
] = X [ 408ULL ] ; t141 [ 1443ULL ] = X [ 408ULL ] ; t141 [ 1444ULL ] = X [
412ULL ] ; t141 [ 1445ULL ] = X [ 412ULL ] ; t141 [ 1446ULL ] = X [ 403ULL ]
; t141 [ 1447ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 1448ULL ] = X [ 404ULL ] ;
t141 [ 1449ULL ] = X [ 405ULL ] ; t141 [ 1450ULL ] = X [ 364ULL ] ; t141 [
1451ULL ] = X [ 365ULL ] * 0.1 ; t141 [ 1452ULL ] = X [ 366ULL ] ; t141 [
1453ULL ] = X [ 367ULL ] ; t141 [ 1454ULL ] = X [ 52ULL ] ; t141 [ 1455ULL ]
= X [ 409ULL ] ; t141 [ 1456ULL ] = X [ 53ULL ] ; t141 [ 1457ULL ] = X [
414ULL ] ; t141 [ 1458ULL ] = X [ 51ULL ] - 273.15 ; t141 [ 1459ULL ] = X [
413ULL ] ; t141 [ 1460ULL ] = X [ 415ULL ] * 0.1 ; t141 [ 1461ULL ] = X [
54ULL ] * 0.1 ; t141 [ 1462ULL ] = X [ 410ULL ] ; t141 [ 1463ULL ] = X [
416ULL ] ; t141 [ 1464ULL ] = - X [ 368ULL ] ; t141 [ 1465ULL ] = X [ 417ULL
] * 0.1 ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1466ULL
] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Humidifier_Meas0 [ t197 ]
; } t141 [ 1474ULL ] = X [ 412ULL ] ; t141 [ 1475ULL ] = X [ 407ULL ] ; t141
[ 1476ULL ] = X [ 418ULL ] ; t141 [ 1477ULL ] = - X [ 374ULL ] ; t141 [
1478ULL ] = - X [ 406ULL ] ; t141 [ 1479ULL ] = 0.0 ; t141 [ 1480ULL ] = X [
408ULL ] ; t141 [ 1481ULL ] = X [ 51ULL ] ; t141 [ 1482ULL ] = X [ 52ULL ] ;
t141 [ 1483ULL ] = X [ 53ULL ] ; t141 [ 1484ULL ] = t273 ; t141 [ 1485ULL ] =
X [ 403ULL ] ; t141 [ 1486ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 1487ULL ] = X [
404ULL ] ; t141 [ 1488ULL ] = X [ 405ULL ] ; t141 [ 1489ULL ] = X [ 418ULL ]
; t141 [ 1490ULL ] = X [ 419ULL ] ; t141 [ 1491ULL ] = X [ 413ULL ] ; t141 [
1492ULL ] = X [ 420ULL ] ; t141 [ 1493ULL ] = X [ 421ULL ] ; t141 [ 1494ULL ]
= X [ 422ULL ] ; t141 [ 1495ULL ] = X [ 423ULL ] ; t141 [ 1496ULL ] = X [
364ULL ] ; t141 [ 1497ULL ] = X [ 365ULL ] * 0.1 ; t141 [ 1498ULL ] = X [
366ULL ] ; t141 [ 1499ULL ] = X [ 367ULL ] ; t141 [ 1500ULL ] = - X [ 374ULL
] ; t141 [ 1501ULL ] = X [ 424ULL ] ; t141 [ 1502ULL ] = - X [ 368ULL ] ;
t141 [ 1503ULL ] = - X [ 378ULL ] ; t141 [ 1504ULL ] = - X [ 379ULL ] ; t141
[ 1505ULL ] = X [ 425ULL ] ; t141 [ 1506ULL ] = X [ 426ULL ] ; t141 [ 1507ULL
] = X [ 420ULL ] ; t141 [ 1508ULL ] = - X [ 378ULL ] ; t141 [ 1509ULL ] = 0.0
; t141 [ 1510ULL ] = U_idx_8 ; t141 [ 1511ULL ] = X [ 421ULL ] ; t141 [
1512ULL ] = - X [ 379ULL ] ; t141 [ 1513ULL ] = U_idx_9 ; t141 [ 1514ULL ] =
U_idx_8 ; t141 [ 1515ULL ] = X [ 62ULL ] ; t141 [ 1516ULL ] = 293.15 ; t141 [
1517ULL ] = t274 * 1000.0 ; t141 [ 1518ULL ] = t274 * 0.35777375282305851 ;
t141 [ 1519ULL ] = 0.0 ; t141 [ 1520ULL ] = X [ 429ULL ] ; t141 [ 1521ULL ] =
0.101325 ; t141 [ 1522ULL ] = X [ 429ULL ] ; t141 [ 1523ULL ] = 0.101325 ;
t141 [ 1524ULL ] = 0.0 ; t141 [ 1525ULL ] = X [ 56ULL ] ; t141 [ 1526ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 ; t141 [
1527ULL ] = 0.0 ; t141 [ 1528ULL ] = X [ 432ULL ] ; t141 [ 1529ULL ] = X [
56ULL ] ; t141 [ 1530ULL ] = 0.101325 ; t141 [ 1531ULL ] = X [ 429ULL ] ;
t141 [ 1532ULL ] = 0.101325 ; t141 [ 1533ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cooling_System_Coolant0 ; t141 [
1534ULL ] = X [ 433ULL ] ; t141 [ 1535ULL ] = t276 ; t141 [ 1536ULL ] = X [
435ULL ] ; t141 [ 1537ULL ] = X [ 57ULL ] ; t141 [ 1538ULL ] = 0.0 ; t141 [
1539ULL ] = t276 ; t141 [ 1540ULL ] = 0.0 ; t141 [ 1541ULL ] = 0.0 ; t141 [
1542ULL ] = X [ 56ULL ] ; t141 [ 1543ULL ] = X [ 56ULL ] ; t141 [ 1544ULL ] =
X [ 429ULL ] ; t141 [ 1545ULL ] = 0.101325 ; t141 [ 1546ULL ] = X [ 432ULL ]
; t141 [ 1547ULL ] = X [ 432ULL ] ; t141 [ 1548ULL ] = 293.15 ; t141 [
1549ULL ] = t274 * 1000.0 ; t141 [ 1550ULL ] = X [ 436ULL ] ; t141 [ 1551ULL
] = X [ 437ULL ] * 0.1 ; t141 [ 1552ULL ] = X [ 438ULL ] ; t141 [ 1553ULL ] =
X [ 439ULL ] * 0.1 ; t141 [ 1554ULL ] = X [ 440ULL ] ; t141 [ 1555ULL ] = - X
[ 440ULL ] ; t141 [ 1556ULL ] = X [ 436ULL ] ; t141 [ 1557ULL ] = X [ 437ULL
] * 0.1 ; t141 [ 1558ULL ] = X [ 440ULL ] ; t141 [ 1559ULL ] = X [ 441ULL ] ;
t141 [ 1560ULL ] = X [ 442ULL ] ; t141 [ 1561ULL ] = X [ 443ULL ] ; t141 [
1562ULL ] = X [ 438ULL ] ; t141 [ 1563ULL ] = X [ 439ULL ] * 0.1 ; t141 [
1564ULL ] = - X [ 440ULL ] ; t141 [ 1565ULL ] = X [ 444ULL ] ; t141 [ 1566ULL
] = - X [ 442ULL ] ; t141 [ 1567ULL ] = X [ 443ULL ] ; t141 [ 1568ULL ] = X [
442ULL ] ; t141 [ 1569ULL ] = - X [ 442ULL ] ; t141 [ 1570ULL ] = X [ 438ULL
] ; t141 [ 1571ULL ] = X [ 439ULL ] * 0.1 ; t141 [ 1572ULL ] = X [ 429ULL ] ;
t141 [ 1573ULL ] = 0.101325 ; t141 [ 1574ULL ] = X [ 32ULL ] ; t141 [ 1575ULL
] = X [ 440ULL ] ; t141 [ 1576ULL ] = X [ 430ULL ] ; t141 [ 1577ULL ] = X [
58ULL ] * 0.1 ; t141 [ 1578ULL ] = X [ 59ULL ] ; t141 [ 1579ULL ] = X [
442ULL ] ; t141 [ 1580ULL ] = X [ 434ULL ] ; t141 [ 1581ULL ] = X [ 445ULL ]
; t141 [ 1582ULL ] = X [ 438ULL ] ; t141 [ 1583ULL ] = X [ 439ULL ] * 0.1 ;
t141 [ 1584ULL ] = X [ 440ULL ] ; t141 [ 1585ULL ] = X [ 446ULL ] ; t141 [
1586ULL ] = X [ 442ULL ] ; t141 [ 1587ULL ] = X [ 447ULL ] ; t141 [ 1588ULL ]
= X [ 429ULL ] ; t141 [ 1589ULL ] = 0.101325 ; t141 [ 1590ULL ] = X [ 430ULL
] ; t141 [ 1591ULL ] = X [ 448ULL ] ; t141 [ 1592ULL ] = X [ 434ULL ] ; t141
[ 1593ULL ] = X [ 449ULL ] ; t141 [ 1594ULL ] = X [ 32ULL ] ; t141 [ 1595ULL
] = U_idx_10 ; t141 [ 1596ULL ] = t278 ; t141 [ 1597ULL ] = X [ 429ULL ] ;
t141 [ 1598ULL ] = 0.101325 ; t141 [ 1599ULL ] = X [ 450ULL ] ; t141 [
1600ULL ] = X [ 451ULL ] * 0.1 ; t141 [ 1601ULL ] = t278 ; t141 [ 1602ULL ] =
X [ 431ULL ] ; t141 [ 1603ULL ] = X [ 452ULL ] ; t141 [ 1604ULL ] = X [
429ULL ] ; t141 [ 1605ULL ] = 0.101325 ; t141 [ 1606ULL ] = X [ 431ULL ] ;
t141 [ 1607ULL ] = X [ 453ULL ] ; t141 [ 1608ULL ] = t279 ; t141 [ 1609ULL ]
= X [ 454ULL ] ; t141 [ 1610ULL ] = X [ 450ULL ] ; t141 [ 1611ULL ] = X [
451ULL ] * 0.1 ; t141 [ 1612ULL ] = X [ 452ULL ] ; t141 [ 1613ULL ] = X [
455ULL ] ; t141 [ 1614ULL ] = - t279 ; t141 [ 1615ULL ] = X [ 454ULL ] ; t141
[ 1616ULL ] = t279 ; t141 [ 1617ULL ] = - t279 ; t141 [ 1618ULL ] = X [
450ULL ] ; t141 [ 1619ULL ] = X [ 451ULL ] * 0.1 ; t141 [ 1620ULL ] = X [
436ULL ] ; t141 [ 1621ULL ] = X [ 437ULL ] * 0.1 ; t141 [ 1622ULL ] = X [
62ULL ] ; t141 [ 1623ULL ] = - X [ 452ULL ] ; t141 [ 1624ULL ] = - X [ 440ULL
] ; t141 [ 1625ULL ] = X [ 60ULL ] * 0.1 ; t141 [ 1626ULL ] = X [ 61ULL ] ;
t141 [ 1627ULL ] = t279 ; t141 [ 1628ULL ] = - X [ 442ULL ] ; t141 [ 1629ULL
] = X [ 427ULL ] ; t141 [ 1630ULL ] = X [ 450ULL ] ; t141 [ 1631ULL ] = X [
451ULL ] * 0.1 ; t141 [ 1632ULL ] = - X [ 452ULL ] ; t141 [ 1633ULL ] = X [
456ULL ] ; t141 [ 1634ULL ] = t279 ; t141 [ 1635ULL ] = X [ 457ULL ] ; t141 [
1636ULL ] = X [ 436ULL ] ; t141 [ 1637ULL ] = X [ 437ULL ] * 0.1 ; t141 [
1638ULL ] = - X [ 440ULL ] ; t141 [ 1639ULL ] = X [ 458ULL ] ; t141 [ 1640ULL
] = - X [ 442ULL ] ; t141 [ 1641ULL ] = X [ 459ULL ] ; t141 [ 1642ULL ] = X [
450ULL ] ; t141 [ 1643ULL ] = X [ 451ULL ] * 0.1 ; t141 [ 1644ULL ] = X [
429ULL ] ; t141 [ 1645ULL ] = 0.101325 ; t141 [ 1646ULL ] = 0.9 ; t141 [
1647ULL ] = X [ 450ULL ] ; t141 [ 1648ULL ] = X [ 451ULL ] * 0.1 ; t141 [
1649ULL ] = t281 * 1000.0 ; t141 [ 1650ULL ] = 0.9 ; t141 [ 1651ULL ] = t281
* 1111.1111111111111 ; t141 [ 1652ULL ] = t281 * 1111.1111111111111 ; t141 [
1653ULL ] = ( 1.01325 - X [ 451ULL ] ) * 99999.999999999985 ; t141 [ 1654ULL
] = X [ 460ULL ] * 1.0E-6 ; t141 [ 1655ULL ] = t281 * 1000.0 ; t141 [ 1656ULL
] = X [ 429ULL ] ; t141 [ 1657ULL ] = 0.101325 ; t141 [ 1658ULL ] = X [
450ULL ] ; t141 [ 1659ULL ] = X [ 451ULL ] * 0.1 ; t141 [ 1660ULL ] = (
1.01325 - X [ 451ULL ] ) * 99999.999999999985 ; t141 [ 1661ULL ] = X [ 429ULL
] - X [ 450ULL ] ; t141 [ 1662ULL ] = X [ 450ULL ] ; t141 [ 1663ULL ] = X [
451ULL ] * 0.1 ; t141 [ 1664ULL ] = X [ 450ULL ] ; t141 [ 1665ULL ] = X [
451ULL ] * 0.1 ; t141 [ 1666ULL ] = - X [ 452ULL ] ; t141 [ 1667ULL ] = X [
460ULL ] * 1.0E-6 ; t141 [ 1668ULL ] = t279 ; t141 [ 1669ULL ] = U_idx_10 ;
t141 [ 1670ULL ] = X [ 32ULL ] ; t141 [ 1671ULL ] = 0.0 ; t141 [ 1672ULL ] =
X [ 32ULL ] ; t141 [ 1673ULL ] = X [ 32ULL ] - 273.15 ; t141 [ 1674ULL ] = X
[ 62ULL ] ; t141 [ 1675ULL ] = X [ 62ULL ] ; t141 [ 1676ULL ] = X [ 428ULL ]
* 1000.0 ; t141 [ 1677ULL ] = X [ 62ULL ] - 273.15 ; t141 [ 1678ULL ] = 0.0 ;
t141 [ 1679ULL ] = X [ 226ULL ] ; t141 [ 1680ULL ] = X [ 227ULL ] * 0.1 ;
t141 [ 1681ULL ] = X [ 228ULL ] ; t141 [ 1682ULL ] = X [ 229ULL ] ; t141 [
1683ULL ] = X [ 350ULL ] ; t141 [ 1684ULL ] = X [ 351ULL ] * 0.1 ; t141 [
1685ULL ] = X [ 352ULL ] ; t141 [ 1686ULL ] = X [ 353ULL ] ; for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1687ULL ] = t154 [ t197 ] ; }
for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1695ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t197 ] ; }
for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1703ULL ] = t159
[ t197 ] ; } for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 +
1711ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
t197 ] ; } t141 [ 1719ULL ] = X [ 32ULL ] ; t141 [ 1720ULL ] = X [ 226ULL ] ;
t141 [ 1721ULL ] = X [ 227ULL ] * 0.1 ; t141 [ 1722ULL ] = X [ 228ULL ] ;
t141 [ 1723ULL ] = X [ 229ULL ] ; t141 [ 1724ULL ] = X [ 350ULL ] ; t141 [
1725ULL ] = X [ 351ULL ] * 0.1 ; t141 [ 1726ULL ] = X [ 352ULL ] ; t141 [
1727ULL ] = X [ 353ULL ] ; t141 [ 1728ULL ] = X [ 461ULL ] ; t141 [ 1729ULL ]
= X [ 462ULL ] ; t141 [ 1730ULL ] = X [ 32ULL ] ; for ( t197 = 0ULL ; t197 <
8ULL ; t197 ++ ) { t141 [ t197 + 1731ULL ] = t154 [ t197 ] ; } for ( t197 =
0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1739ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Anode_Gas_Channels_FAo [ t197 ] ; }
for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1747ULL ] = t159
[ t197 ] ; } for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 +
1755ULL ] = Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Cathode_Gas_Channels_FCo [
t197 ] ; } t141 [ 1763ULL ] = X [ 173ULL ] ; t141 [ 1764ULL ] = t284 ; t141 [
1765ULL ] = X [ 28ULL ] ; t141 [ 1766ULL ] = X [ 29ULL ] ; t141 [ 1767ULL ] =
X [ 30ULL ] ; t141 [ 1768ULL ] = X [ 46ULL ] ; t141 [ 1769ULL ] = X [ 47ULL ]
; t141 [ 1770ULL ] = X [ 48ULL ] ; t141 [ 1771ULL ] = 0.0 ; t141 [ 1772ULL ]
= t285 ; t141 [ 1773ULL ] = X [ 465ULL ] ; t141 [ 1774ULL ] = X [ 391ULL ] ;
t141 [ 1775ULL ] = X [ 46ULL ] ; t141 [ 1776ULL ] = X [ 47ULL ] ; t141 [
1777ULL ] = X [ 48ULL ] ; t141 [ 1778ULL ] = X [ 32ULL ] ; t141 [ 1779ULL ] =
- X [ 465ULL ] ; t141 [ 1780ULL ] = X [ 276ULL ] ; t141 [ 1781ULL ] = X [
267ULL ] ; t141 [ 1782ULL ] = X [ 28ULL ] ; t141 [ 1783ULL ] = X [ 29ULL ] ;
t141 [ 1784ULL ] = X [ 30ULL ] ; t141 [ 1785ULL ] = X [ 32ULL ] ; t141 [
1786ULL ] = - X [ 276ULL ] ; t141 [ 1787ULL ] = X [ 401ULL ] ; t141 [ 1788ULL
] = X [ 392ULL ] ; t141 [ 1789ULL ] = X [ 46ULL ] ; t141 [ 1790ULL ] = X [
47ULL ] ; t141 [ 1791ULL ] = X [ 48ULL ] ; t141 [ 1792ULL ] = X [ 32ULL ] ;
t141 [ 1793ULL ] = - X [ 401ULL ] ; t141 [ 1794ULL ] = X [ 277ULL ] ; t141 [
1795ULL ] = X [ 268ULL ] ; t141 [ 1796ULL ] = X [ 28ULL ] ; t141 [ 1797ULL ]
= X [ 29ULL ] ; t141 [ 1798ULL ] = X [ 30ULL ] ; t141 [ 1799ULL ] = X [ 32ULL
] ; t141 [ 1800ULL ] = - X [ 277ULL ] ; t141 [ 1801ULL ] = t286 ; t141 [
1802ULL ] = X [ 393ULL ] ; t141 [ 1803ULL ] = X [ 46ULL ] ; t141 [ 1804ULL ]
= X [ 47ULL ] ; t141 [ 1805ULL ] = X [ 48ULL ] ; t141 [ 1806ULL ] = X [ 32ULL
] ; t141 [ 1807ULL ] = - t286 ; t141 [ 1808ULL ] = X [ 28ULL ] ; t141 [
1809ULL ] = X [ 29ULL ] ; t141 [ 1810ULL ] = X [ 30ULL ] ; t141 [ 1811ULL ] =
X [ 46ULL ] ; t141 [ 1812ULL ] = X [ 47ULL ] ; t141 [ 1813ULL ] = X [ 48ULL ]
; t141 [ 1814ULL ] = t285 ; t141 [ 1815ULL ] = 0.0 ; t141 [ 1816ULL ] = X [
32ULL ] ; t141 [ 1817ULL ] = X [ 32ULL ] ; t141 [ 1818ULL ] = X [ 32ULL ] ;
t141 [ 1819ULL ] = X [ 32ULL ] ; t141 [ 1820ULL ] = t284 * - 1000.0 ; t141 [
1821ULL ] = t284 * - 1000.0 ; t141 [ 1822ULL ] = - t284 ; t141 [ 1823ULL ] =
X [ 466ULL ] ; t141 [ 1824ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 1825ULL ] = X [
467ULL ] ; t141 [ 1826ULL ] = X [ 468ULL ] ; t141 [ 1827ULL ] = X [ 469ULL ]
; t141 [ 1828ULL ] = X [ 64ULL ] * 0.1 ; t141 [ 1829ULL ] = X [ 470ULL ] ;
t141 [ 1830ULL ] = X [ 471ULL ] ; t141 [ 1831ULL ] = X [ 63ULL ] ; t141 [
1832ULL ] = X [ 64ULL ] * 0.1 ; t141 [ 1833ULL ] = X [ 65ULL ] ; t141 [
1834ULL ] = X [ 66ULL ] ; t141 [ 1835ULL ] = X [ 63ULL ] ; t141 [ 1836ULL ] =
X [ 64ULL ] * 0.1 ; t141 [ 1837ULL ] = X [ 65ULL ] ; t141 [ 1838ULL ] = X [
66ULL ] ; t141 [ 1839ULL ] = X [ 63ULL ] ; t141 [ 1840ULL ] = X [ 64ULL ] *
0.1 ; t141 [ 1841ULL ] = X [ 65ULL ] ; t141 [ 1842ULL ] = X [ 66ULL ] ; for (
t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1843ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Fuel_T0 [ t197 ] ; }
t141 [ 1851ULL ] = X [ 63ULL ] ; t141 [ 1852ULL ] = X [ 472ULL ] ; t141 [
1853ULL ] = X [ 476ULL ] ; t141 [ 1854ULL ] = 0.0 ; t141 [ 1855ULL ] = 0.0 ;
t141 [ 1856ULL ] = 0.0 ; t141 [ 1857ULL ] = 0.0 ; t141 [ 1858ULL ] = X [
63ULL ] - 273.15 ; t141 [ 1859ULL ] = X [ 65ULL ] ; t141 [ 1860ULL ] = X [
474ULL ] ; t141 [ 1861ULL ] = X [ 66ULL ] ; t141 [ 1862ULL ] = X [ 64ULL ] *
0.1 ; t141 [ 1863ULL ] = 0.0 ; t141 [ 1864ULL ] = X [ 473ULL ] ; t141 [
1865ULL ] = X [ 63ULL ] ; t141 [ 1866ULL ] = X [ 65ULL ] ; t141 [ 1867ULL ] =
X [ 66ULL ] ; t141 [ 1868ULL ] = t287 ; t141 [ 1869ULL ] = X [ 469ULL ] ;
t141 [ 1870ULL ] = X [ 64ULL ] * 0.1 ; t141 [ 1871ULL ] = X [ 470ULL ] ; t141
[ 1872ULL ] = X [ 471ULL ] ; t141 [ 1873ULL ] = X [ 476ULL ] ; t141 [ 1874ULL
] = X [ 477ULL ] ; t141 [ 1875ULL ] = X [ 478ULL ] ; t141 [ 1876ULL ] = X [
479ULL ] ; t141 [ 1877ULL ] = X [ 480ULL ] ; t141 [ 1878ULL ] = X [ 481ULL ]
; t141 [ 1879ULL ] = X [ 482ULL ] ; t141 [ 1880ULL ] = X [ 478ULL ] ; t141 [
1881ULL ] = 0.0 ; t141 [ 1882ULL ] = 0.0 ; t141 [ 1883ULL ] = 0.0 ; t141 [
1884ULL ] = X [ 479ULL ] ; t141 [ 1885ULL ] = 0.0 ; t141 [ 1886ULL ] = 0.0 ;
t141 [ 1887ULL ] = 0.0 ; t141 [ 1888ULL ] = 0.0 ; t141 [ 1889ULL ] = 0.0 ;
t141 [ 1890ULL ] = X [ 480ULL ] ; t141 [ 1891ULL ] = 0.0 ; t141 [ 1892ULL ] =
0.0 ; t141 [ 1893ULL ] = 0.0 ; t141 [ 1894ULL ] = X [ 475ULL ] ; t141 [
1895ULL ] = X [ 466ULL ] ; t141 [ 1896ULL ] = X [ 38ULL ] * 0.1 ; t141 [
1897ULL ] = X [ 467ULL ] ; t141 [ 1898ULL ] = X [ 468ULL ] ; t141 [ 1899ULL ]
= X [ 469ULL ] ; t141 [ 1900ULL ] = X [ 64ULL ] * 0.1 ; t141 [ 1901ULL ] = X
[ 470ULL ] ; t141 [ 1902ULL ] = X [ 471ULL ] ; t141 [ 1903ULL ] = X [ 469ULL
] ; t141 [ 1904ULL ] = X [ 64ULL ] * 0.1 ; t141 [ 1905ULL ] = X [ 470ULL ] ;
t141 [ 1906ULL ] = X [ 471ULL ] ; t141 [ 1907ULL ] = - X [ 478ULL ] ; t141 [
1908ULL ] = - X [ 479ULL ] ; t141 [ 1909ULL ] = - X [ 480ULL ] ; t141 [
1910ULL ] = X [ 476ULL ] * - 1000.0 ; t141 [ 1911ULL ] = - X [ 476ULL ] ;
t141 [ 1912ULL ] = - X [ 478ULL ] ; t141 [ 1913ULL ] = - X [ 479ULL ] ; t141
[ 1914ULL ] = - X [ 480ULL ] ; t141 [ 1915ULL ] = - X [ 478ULL ] ; t141 [
1916ULL ] = X [ 63ULL ] ; t141 [ 1917ULL ] = X [ 63ULL ] ; t141 [ 1918ULL ] =
X [ 483ULL ] ; t141 [ 1919ULL ] = X [ 483ULL ] ; t141 [ 1920ULL ] = X [
484ULL ] ; t141 [ 1921ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 1922ULL ] = X [
486ULL ] ; t141 [ 1923ULL ] = X [ 487ULL ] ; t141 [ 1924ULL ] = X [ 466ULL ]
; t141 [ 1925ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 1926ULL ] = X [ 467ULL ] ;
t141 [ 1927ULL ] = X [ 468ULL ] ; t141 [ 1928ULL ] = X [ 70ULL ] ; t141 [
1929ULL ] = X [ 491ULL ] ; t141 [ 1930ULL ] = X [ 69ULL ] ; t141 [ 1931ULL ]
= X [ 488ULL ] ; t141 [ 1932ULL ] = X [ 67ULL ] - 273.15 ; t141 [ 1933ULL ] =
- X [ 478ULL ] ; t141 [ 1934ULL ] = X [ 489ULL ] * 0.1 ; t141 [ 1935ULL ] = X
[ 68ULL ] * 0.1 ; t141 [ 1936ULL ] = X [ 490ULL ] ; t141 [ 1937ULL ] = X [
493ULL ] ; t141 [ 1938ULL ] = X [ 492ULL ] ; t141 [ 1939ULL ] = X [ 494ULL ]
* 0.1 ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 1940ULL ]
= t164 [ t197 ] ; } t141 [ 1948ULL ] = X [ 483ULL ] ; t141 [ 1949ULL ] = X [
495ULL ] ; t141 [ 1950ULL ] = - X [ 476ULL ] ; t141 [ 1951ULL ] = X [ 497ULL
] ; t141 [ 1952ULL ] = 0.0 ; t141 [ 1953ULL ] = 0.0 ; t141 [ 1954ULL ] = X [
496ULL ] ; t141 [ 1955ULL ] = X [ 67ULL ] ; t141 [ 1956ULL ] = X [ 70ULL ] ;
t141 [ 1957ULL ] = X [ 69ULL ] ; t141 [ 1958ULL ] = t289 ; t141 [ 1959ULL ] =
X [ 484ULL ] ; t141 [ 1960ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 1961ULL ] =
X [ 486ULL ] ; t141 [ 1962ULL ] = X [ 487ULL ] ; t141 [ 1963ULL ] = - X [
476ULL ] ; t141 [ 1964ULL ] = X [ 498ULL ] ; t141 [ 1965ULL ] = - X [ 478ULL
] ; t141 [ 1966ULL ] = - X [ 479ULL ] ; t141 [ 1967ULL ] = - X [ 480ULL ] ;
t141 [ 1968ULL ] = X [ 499ULL ] ; t141 [ 1969ULL ] = X [ 500ULL ] ; t141 [
1970ULL ] = X [ 466ULL ] ; t141 [ 1971ULL ] = X [ 38ULL ] * 0.1 ; t141 [
1972ULL ] = X [ 467ULL ] ; t141 [ 1973ULL ] = X [ 468ULL ] ; t141 [ 1974ULL ]
= X [ 497ULL ] ; t141 [ 1975ULL ] = X [ 501ULL ] ; t141 [ 1976ULL ] = X [
492ULL ] ; t141 [ 1977ULL ] = X [ 502ULL ] ; t141 [ 1978ULL ] = X [ 503ULL ]
; t141 [ 1979ULL ] = X [ 504ULL ] ; t141 [ 1980ULL ] = X [ 505ULL ] ; t141 [
1981ULL ] = - X [ 479ULL ] ; t141 [ 1982ULL ] = X [ 502ULL ] ; t141 [ 1983ULL
] = 0.0 ; t141 [ 1984ULL ] = 0.0 ; t141 [ 1985ULL ] = - X [ 480ULL ] ; t141 [
1986ULL ] = X [ 503ULL ] ; t141 [ 1987ULL ] = X [ 469ULL ] ; t141 [ 1988ULL ]
= X [ 64ULL ] * 0.1 ; t141 [ 1989ULL ] = X [ 470ULL ] ; t141 [ 1990ULL ] = X
[ 471ULL ] ; t141 [ 1991ULL ] = 0.0 ; t141 [ 1992ULL ] = 0.0 ; t141 [ 1993ULL
] = 0.0 ; t141 [ 1994ULL ] = 0.0 ; t141 [ 1995ULL ] = X [ 484ULL ] ; t141 [
1996ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 1997ULL ] = X [ 486ULL ] ; t141 [
1998ULL ] = X [ 487ULL ] ; t141 [ 1999ULL ] = 0.16000000000000003 ; t141 [
2000ULL ] = ( X [ 485ULL ] - 0.16000000000000003 ) * 1.0E+6 ; t141 [ 2001ULL
] = X [ 485ULL ] ; t141 [ 2002ULL ] = 0.16000000000000003 ; t141 [ 2003ULL ]
= 0.010000000000000002 ; t141 [ 2004ULL ] = ( X [ 485ULL ] -
0.16000000000000003 ) * - 62500.003906250226 ; t141 [ 2005ULL ] = ( X [
485ULL ] - 0.16000000000000003 ) * 1.0E+6 ; t141 [ 2006ULL ] = X [ 485ULL ] ;
t141 [ 2007ULL ] = X [ 485ULL ] * 7.8539816339744827E-5 ; t141 [ 2008ULL ] =
intrm_sf_mf_1383 * 99999.999999999985 ; t141 [ 2009ULL ] = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 -
0.10000000000000002 ) * 0.1 ; t141 [ 2010ULL ] = ( X [ 485ULL ] -
0.16000000000000003 ) * - 62500.003906250226 ; t141 [ 2011ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 * 0.1 ; t141
[ 2012ULL ] = 0.010000000000000002 ; t141 [ 2013ULL ] = (
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 -
0.10000000000000002 ) * 0.1 ; t141 [ 2014ULL ] = X [ 484ULL ] ; t141 [
2015ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 2016ULL ] = X [ 486ULL ] ; t141 [
2017ULL ] = X [ 487ULL ] ; t141 [ 2018ULL ] = 0.0 ; t141 [ 2019ULL ] = 0.0 ;
t141 [ 2020ULL ] = 0.0 ; t141 [ 2021ULL ] = 0.0 ; t141 [ 2022ULL ] =
intrm_sf_mf_1383 * 99999.999999999985 ; t141 [ 2023ULL ] = X [ 484ULL ] ;
t141 [ 2024ULL ] = X [ 469ULL ] ; t141 [ 2025ULL ] = X [ 64ULL ] * 0.1 ; t141
[ 2026ULL ] = X [ 470ULL ] ; t141 [ 2027ULL ] = X [ 471ULL ] ; t141 [ 2028ULL
] = X [ 485ULL ] * 7.8539816339744827E-5 ; t141 [ 2029ULL ] = X [ 484ULL ] ;
t141 [ 2030ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 2031ULL ] = X [ 486ULL ] ;
t141 [ 2032ULL ] = X [ 487ULL ] ; t141 [ 2033ULL ] = - X [ 478ULL ] ; t141 [
2034ULL ] = X [ 469ULL ] ; t141 [ 2035ULL ] = X [ 64ULL ] * 0.1 ; t141 [
2036ULL ] = X [ 470ULL ] ; t141 [ 2037ULL ] = X [ 471ULL ] ; t141 [ 2038ULL ]
= - X [ 476ULL ] ; t141 [ 2039ULL ] = X [ 512ULL ] ; t141 [ 2040ULL ] = - X [
478ULL ] ; t141 [ 2041ULL ] = - X [ 479ULL ] ; t141 [ 2042ULL ] = - X [
480ULL ] ; t141 [ 2043ULL ] = X [ 509ULL ] ; t141 [ 2044ULL ] = X [ 508ULL ]
; t141 [ 2045ULL ] = X [ 506ULL ] ; t141 [ 2046ULL ] = X [ 507ULL ] * 0.1 ;
t141 [ 2047ULL ] = X [ 510ULL ] ; t141 [ 2048ULL ] = X [ 511ULL ] ; t141 [
2049ULL ] = - X [ 476ULL ] ; t141 [ 2050ULL ] = X [ 476ULL ] ; t141 [ 2051ULL
] = X [ 484ULL ] ; t141 [ 2052ULL ] = intrm_sf_mf_1383 * 0.1 ; t141 [ 2053ULL
] = X [ 486ULL ] ; t141 [ 2054ULL ] = X [ 487ULL ] ; t141 [ 2055ULL ] = X [
476ULL ] ; t141 [ 2056ULL ] = X [ 512ULL ] ; t141 [ 2057ULL ] = X [ 478ULL ]
; t141 [ 2058ULL ] = X [ 479ULL ] ; t141 [ 2059ULL ] = X [ 480ULL ] ; t141 [
2060ULL ] = X [ 509ULL ] ; t141 [ 2061ULL ] = X [ 508ULL ] ; t141 [ 2062ULL ]
= X [ 478ULL ] ; t141 [ 2063ULL ] = - X [ 479ULL ] ; t141 [ 2064ULL ] = X [
479ULL ] ; t141 [ 2065ULL ] = - X [ 480ULL ] ; t141 [ 2066ULL ] = X [ 480ULL
] ; t141 [ 2067ULL ] =
Fuel_Cell_Fuel_Cell_Simscape_Fuel_Cell_Hydrogen_Source_Pressu30 * 0.1 ; t141
[ 2068ULL ] = U_idx_11 ; t141 [ 2069ULL ] = X [ 32ULL ] ; t141 [ 2070ULL ] =
X [ 32ULL ] ; t141 [ 2071ULL ] = X [ 463ULL ] * 1000.0 ; t141 [ 2072ULL ] = X
[ 32ULL ] - 273.15 ; t141 [ 2073ULL ] = X [ 513ULL ] ; t141 [ 2074ULL ] =
0.101325 ; t141 [ 2075ULL ] = X [ 514ULL ] ; t141 [ 2076ULL ] = X [ 515ULL ]
; t141 [ 2077ULL ] = X [ 516ULL ] ; t141 [ 2078ULL ] = X [ 517ULL ] ; t141 [
2079ULL ] = 0.5 ; t141 [ 2080ULL ] = X [ 525ULL ] ; t141 [ 2081ULL ] = X [
524ULL ] ; t141 [ 2082ULL ] = 293.15 ; t141 [ 2083ULL ] = X [ 513ULL ] ; t141
[ 2084ULL ] = 0.101325 ; t141 [ 2085ULL ] = X [ 514ULL ] ; t141 [ 2086ULL ] =
X [ 515ULL ] ; t141 [ 2087ULL ] = X [ 517ULL ] ; t141 [ 2088ULL ] = X [
518ULL ] ; t141 [ 2089ULL ] = X [ 519ULL ] ; t141 [ 2090ULL ] = X [ 520ULL ]
; t141 [ 2091ULL ] = X [ 521ULL ] ; t141 [ 2092ULL ] = X [ 522ULL ] ; t141 [
2093ULL ] = X [ 523ULL ] ; t141 [ 2094ULL ] = X [ 519ULL ] ; t141 [ 2095ULL ]
= X [ 520ULL ] ; t141 [ 2096ULL ] = X [ 521ULL ] ; t141 [ 2097ULL ] =
0.101325 ; t141 [ 2098ULL ] = 0.21 ; t141 [ 2099ULL ] = X [ 526ULL ] ; t141 [
2100ULL ] = X [ 527ULL ] ; t141 [ 2101ULL ] = X [ 55ULL ] * 0.1 ; t141 [
2102ULL ] = X [ 528ULL ] ; t141 [ 2103ULL ] = X [ 529ULL ] ; t141 [ 2104ULL ]
= X [ 513ULL ] ; t141 [ 2105ULL ] = 0.101325 ; t141 [ 2106ULL ] = X [ 514ULL
] ; t141 [ 2107ULL ] = X [ 515ULL ] ; t141 [ 2108ULL ] = X [ 527ULL ] ; t141
[ 2109ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2110ULL ] = X [ 528ULL ] ; t141 [
2111ULL ] = X [ 529ULL ] ; t141 [ 2112ULL ] = X [ 531ULL ] ; t141 [ 2113ULL ]
= X [ 534ULL ] ; t141 [ 2114ULL ] = X [ 513ULL ] ; t141 [ 2115ULL ] =
0.101325 ; t141 [ 2116ULL ] = X [ 514ULL ] ; t141 [ 2117ULL ] = X [ 515ULL ]
; t141 [ 2118ULL ] = - X [ 517ULL ] ; t141 [ 2119ULL ] = X [ 535ULL ] ; t141
[ 2120ULL ] = - X [ 519ULL ] ; t141 [ 2121ULL ] = - X [ 520ULL ] ; t141 [
2122ULL ] = - X [ 521ULL ] ; t141 [ 2123ULL ] = X [ 536ULL ] ; t141 [ 2124ULL
] = X [ 537ULL ] ; t141 [ 2125ULL ] = - X [ 519ULL ] ; t141 [ 2126ULL ] = X [
532ULL ] ; t141 [ 2127ULL ] = X [ 533ULL ] ; t141 [ 2128ULL ] = X [ 527ULL ]
; t141 [ 2129ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2130ULL ] = X [ 528ULL ] ;
t141 [ 2131ULL ] = X [ 529ULL ] ; t141 [ 2132ULL ] = X [ 530ULL ] ; t141 [
2133ULL ] = X [ 535ULL ] ; t141 [ 2134ULL ] = X [ 519ULL ] ; t141 [ 2135ULL ]
= X [ 520ULL ] ; t141 [ 2136ULL ] = X [ 521ULL ] ; t141 [ 2137ULL ] = X [
536ULL ] ; t141 [ 2138ULL ] = X [ 537ULL ] ; t141 [ 2139ULL ] = X [ 519ULL ]
; t141 [ 2140ULL ] = - X [ 519ULL ] ; t141 [ 2141ULL ] = - X [ 517ULL ] ;
t141 [ 2142ULL ] = X [ 530ULL ] ; t141 [ 2143ULL ] = - X [ 520ULL ] ; t141 [
2144ULL ] = X [ 520ULL ] ; t141 [ 2145ULL ] = - X [ 521ULL ] ; t141 [ 2146ULL
] = X [ 521ULL ] ; t141 [ 2147ULL ] = 0.0 ; t141 [ 2148ULL ] = 0.0 ; t141 [
2149ULL ] = 0.0 ; t141 [ 2150ULL ] = 0.0 ; t141 [ 2151ULL ] = 0.0 ; t141 [
2152ULL ] = 0.0 ; t141 [ 2153ULL ] = 0.0 ; t141 [ 2154ULL ] = 0.0 ; t141 [
2155ULL ] = X [ 538ULL ] ; t141 [ 2156ULL ] = t296 * 0.99999999999999978 /
0.99999999999999978 * 9.5492965855137211 ; t141 [ 2157ULL ] = X [ 539ULL ] ;
t141 [ 2158ULL ] = X [ 55ULL ] * 99999.999999999985 ; t141 [ 2159ULL ] =
101324.99999999999 ; t141 [ 2160ULL ] = X [ 538ULL ] ; t141 [ 2161ULL ] = X [
540ULL ] ; t141 [ 2162ULL ] = X [ 541ULL ] ; t141 [ 2163ULL ] = - X [ 519ULL
] ; t141 [ 2164ULL ] = 1.0 ; t141 [ 2165ULL ] = X [ 539ULL ] ; t141 [ 2166ULL
] = X [ 540ULL ] ; t141 [ 2167ULL ] = X [ 513ULL ] ; t141 [ 2168ULL ] =
0.101325 ; t141 [ 2169ULL ] = X [ 514ULL ] ; t141 [ 2170ULL ] = X [ 515ULL ]
; t141 [ 2171ULL ] = 0.0 ; t141 [ 2172ULL ] = 0.0 ; t141 [ 2173ULL ] = 0.0 ;
t141 [ 2174ULL ] = 0.0 ; t141 [ 2175ULL ] = 101324.99999999999 ; t141 [
2176ULL ] = X [ 513ULL ] ; t141 [ 2177ULL ] = X [ 527ULL ] ; t141 [ 2178ULL ]
= X [ 55ULL ] * 0.1 ; t141 [ 2179ULL ] = X [ 528ULL ] ; t141 [ 2180ULL ] = X
[ 529ULL ] ; t141 [ 2181ULL ] = 0.0 ; t141 [ 2182ULL ] = 0.0 ; t141 [ 2183ULL
] = 0.0 ; t141 [ 2184ULL ] = 0.0 ; t141 [ 2185ULL ] = X [ 55ULL ] *
99999.999999999985 ; t141 [ 2186ULL ] = X [ 527ULL ] ; t141 [ 2187ULL ] = X [
513ULL ] ; t141 [ 2188ULL ] = 0.101325 ; t141 [ 2189ULL ] = X [ 514ULL ] ;
t141 [ 2190ULL ] = X [ 515ULL ] ; t141 [ 2191ULL ] = - X [ 519ULL ] ; t141 [
2192ULL ] = X [ 527ULL ] ; t141 [ 2193ULL ] = X [ 55ULL ] * 0.1 ; t141 [
2194ULL ] = X [ 528ULL ] ; t141 [ 2195ULL ] = X [ 529ULL ] ; t141 [ 2196ULL ]
= t296 * 9.5492965855137211 ; t141 [ 2197ULL ] = X [ 513ULL ] *
0.00347041471455839 ; t141 [ 2198ULL ] = X [ 541ULL ] ; t141 [ 2199ULL ] =
101324.99999999999 ; t141 [ 2200ULL ] = 1.0 ; t141 [ 2201ULL ] = X [ 513ULL ]
; t141 [ 2202ULL ] = X [ 513ULL ] * 0.00347041471455839 ; t141 [ 2203ULL ] =
X [ 527ULL ] ; t141 [ 2204ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2205ULL ] = X [
528ULL ] ; t141 [ 2206ULL ] = X [ 529ULL ] ; t141 [ 2207ULL ] = X [ 403ULL ]
; t141 [ 2208ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2209ULL ] = X [ 404ULL ] ;
t141 [ 2210ULL ] = X [ 405ULL ] ; t141 [ 2211ULL ] = X [ 71ULL ] ; t141 [
2212ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2213ULL ] = X [ 72ULL ] ; t141 [
2214ULL ] = X [ 73ULL ] ; t141 [ 2215ULL ] = X [ 71ULL ] ; t141 [ 2216ULL ] =
X [ 55ULL ] * 0.1 ; t141 [ 2217ULL ] = X [ 72ULL ] ; t141 [ 2218ULL ] = X [
73ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ ) { t141 [ t197 + 2219ULL
] = t166 [ t197 ] ; } t141 [ 2227ULL ] = X [ 71ULL ] ; t141 [ 2228ULL ] = X [
542ULL ] ; t141 [ 2229ULL ] = - X [ 530ULL ] ; t141 [ 2230ULL ] = - X [
418ULL ] ; t141 [ 2231ULL ] = 0.0 ; t141 [ 2232ULL ] = 0.0 ; t141 [ 2233ULL ]
= 0.0 ; t141 [ 2234ULL ] = X [ 71ULL ] - 273.15 ; t141 [ 2235ULL ] = X [
72ULL ] ; t141 [ 2236ULL ] = X [ 544ULL ] ; t141 [ 2237ULL ] = X [ 73ULL ] ;
t141 [ 2238ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2239ULL ] = 0.0 ; t141 [
2240ULL ] = X [ 543ULL ] ; t141 [ 2241ULL ] = X [ 71ULL ] ; t141 [ 2242ULL ]
= X [ 72ULL ] ; t141 [ 2243ULL ] = X [ 73ULL ] ; t141 [ 2244ULL ] = t301 ;
t141 [ 2245ULL ] = X [ 527ULL ] ; t141 [ 2246ULL ] = X [ 55ULL ] * 0.1 ; t141
[ 2247ULL ] = X [ 528ULL ] ; t141 [ 2248ULL ] = X [ 529ULL ] ; t141 [ 2249ULL
] = - X [ 530ULL ] ; t141 [ 2250ULL ] = X [ 546ULL ] ; t141 [ 2251ULL ] = - X
[ 519ULL ] ; t141 [ 2252ULL ] = - X [ 520ULL ] ; t141 [ 2253ULL ] = - X [
521ULL ] ; t141 [ 2254ULL ] = X [ 547ULL ] ; t141 [ 2255ULL ] = X [ 548ULL ]
; t141 [ 2256ULL ] = X [ 403ULL ] ; t141 [ 2257ULL ] = X [ 55ULL ] * 0.1 ;
t141 [ 2258ULL ] = X [ 404ULL ] ; t141 [ 2259ULL ] = X [ 405ULL ] ; t141 [
2260ULL ] = - X [ 418ULL ] ; t141 [ 2261ULL ] = X [ 549ULL ] ; t141 [ 2262ULL
] = - X [ 413ULL ] ; t141 [ 2263ULL ] = - X [ 420ULL ] ; t141 [ 2264ULL ] = -
X [ 421ULL ] ; t141 [ 2265ULL ] = X [ 550ULL ] ; t141 [ 2266ULL ] = X [
551ULL ] ; t141 [ 2267ULL ] = - X [ 519ULL ] ; t141 [ 2268ULL ] = - X [
413ULL ] ; t141 [ 2269ULL ] = 0.0 ; t141 [ 2270ULL ] = 0.0 ; t141 [ 2271ULL ]
= - X [ 520ULL ] ; t141 [ 2272ULL ] = - X [ 420ULL ] ; t141 [ 2273ULL ] = 0.0
; t141 [ 2274ULL ] = 0.0 ; t141 [ 2275ULL ] = 0.0 ; t141 [ 2276ULL ] = 0.0 ;
t141 [ 2277ULL ] = - X [ 521ULL ] ; t141 [ 2278ULL ] = - X [ 421ULL ] ; t141
[ 2279ULL ] = 0.0 ; t141 [ 2280ULL ] = 0.0 ; t141 [ 2281ULL ] = X [ 545ULL ]
; t141 [ 2282ULL ] = X [ 403ULL ] ; t141 [ 2283ULL ] = X [ 55ULL ] * 0.1 ;
t141 [ 2284ULL ] = X [ 404ULL ] ; t141 [ 2285ULL ] = X [ 405ULL ] ; t141 [
2286ULL ] = X [ 403ULL ] ; t141 [ 2287ULL ] = X [ 55ULL ] * 0.1 ; t141 [
2288ULL ] = X [ 404ULL ] ; t141 [ 2289ULL ] = X [ 405ULL ] ; t141 [ 2290ULL ]
= X [ 413ULL ] ; t141 [ 2291ULL ] = X [ 420ULL ] ; t141 [ 2292ULL ] = X [
421ULL ] ; t141 [ 2293ULL ] = X [ 418ULL ] * 1000.0 ; t141 [ 2294ULL ] = X [
418ULL ] ; t141 [ 2295ULL ] = X [ 413ULL ] ; t141 [ 2296ULL ] = X [ 420ULL ]
; t141 [ 2297ULL ] = X [ 421ULL ] ; t141 [ 2298ULL ] = X [ 413ULL ] ; t141 [
2299ULL ] = U_idx_12 ; t141 [ 2300ULL ] = t295 * 9.5492965855137211 ; t141 [
2301ULL ] = X [ 403ULL ] ; t141 [ 2302ULL ] = X [ 55ULL ] * 0.1 ; t141 [
2303ULL ] = X [ 404ULL ] ; t141 [ 2304ULL ] = X [ 405ULL ] ; t141 [ 2305ULL ]
= X [ 71ULL ] ; t141 [ 2306ULL ] = X [ 71ULL ] ; t141 [ 2307ULL ] = X [
527ULL ] ; t141 [ 2308ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2309ULL ] = X [
528ULL ] ; t141 [ 2310ULL ] = X [ 529ULL ] ; t141 [ 2311ULL ] = X [ 513ULL ]
; t141 [ 2312ULL ] = 0.101325 ; t141 [ 2313ULL ] = X [ 514ULL ] ; t141 [
2314ULL ] = X [ 515ULL ] ; t141 [ 2315ULL ] = 0.9 ; t141 [ 2316ULL ] = X [
527ULL ] ; t141 [ 2317ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2318ULL ] = X [
528ULL ] ; t141 [ 2319ULL ] = X [ 529ULL ] ; t141 [ 2320ULL ] = t303 * 1000.0
; t141 [ 2321ULL ] = 0.9 ; t141 [ 2322ULL ] = t303 * 1111.1111111111111 ;
t141 [ 2323ULL ] = t303 * 1111.1111111111111 ; t141 [ 2324ULL ] = - ( X [
55ULL ] - 1.01325 ) * 99999.999999999985 ; t141 [ 2325ULL ] = X [ 552ULL ] *
1.0E-6 ; t141 [ 2326ULL ] = t303 * 1000.0 ; t141 [ 2327ULL ] = X [ 513ULL ] ;
t141 [ 2328ULL ] = 0.101325 ; t141 [ 2329ULL ] = X [ 514ULL ] ; t141 [
2330ULL ] = X [ 515ULL ] ; t141 [ 2331ULL ] = X [ 527ULL ] ; t141 [ 2332ULL ]
= X [ 55ULL ] * 0.1 ; t141 [ 2333ULL ] = X [ 528ULL ] ; t141 [ 2334ULL ] = X
[ 529ULL ] ; t141 [ 2335ULL ] = - ( X [ 55ULL ] - 1.01325 ) *
99999.999999999985 ; t141 [ 2336ULL ] = X [ 513ULL ] - X [ 527ULL ] ; t141 [
2337ULL ] = X [ 527ULL ] ; t141 [ 2338ULL ] = X [ 55ULL ] * 0.1 ; t141 [
2339ULL ] = X [ 528ULL ] ; t141 [ 2340ULL ] = X [ 529ULL ] ; t141 [ 2341ULL ]
= X [ 527ULL ] ; t141 [ 2342ULL ] = X [ 55ULL ] * 0.1 ; t141 [ 2343ULL ] = X
[ 528ULL ] ; t141 [ 2344ULL ] = X [ 529ULL ] ; t141 [ 2345ULL ] = - X [
530ULL ] ; t141 [ 2346ULL ] = X [ 552ULL ] * 1.0E-6 ; t141 [ 2347ULL ] = - X
[ 519ULL ] ; t141 [ 2348ULL ] = - X [ 520ULL ] ; t141 [ 2349ULL ] = - X [
521ULL ] ; t141 [ 2350ULL ] = U_idx_12 ; t141 [ 2351ULL ] = X [ 466ULL ] ;
t141 [ 2352ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2353ULL ] = X [ 467ULL ] ; t141
[ 2354ULL ] = X [ 468ULL ] ; t141 [ 2355ULL ] = X [ 278ULL ] ; t141 [ 2356ULL
] = X [ 38ULL ] * 0.1 ; t141 [ 2357ULL ] = X [ 279ULL ] ; t141 [ 2358ULL ] =
X [ 280ULL ] ; t141 [ 2359ULL ] = X [ 466ULL ] ; t141 [ 2360ULL ] = X [ 38ULL
] * 0.1 ; t141 [ 2361ULL ] = X [ 467ULL ] ; t141 [ 2362ULL ] = X [ 468ULL ] ;
t141 [ 2363ULL ] = X [ 553ULL ] ; t141 [ 2364ULL ] = X [ 38ULL ] * 0.1 ; t141
[ 2365ULL ] = X [ 554ULL ] ; t141 [ 2366ULL ] = X [ 555ULL ] ; t141 [ 2367ULL
] = X [ 278ULL ] ; t141 [ 2368ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2369ULL ] =
X [ 279ULL ] ; t141 [ 2370ULL ] = X [ 280ULL ] ; t141 [ 2371ULL ] = X [ 74ULL
] ; t141 [ 2372ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2373ULL ] = X [ 75ULL ] ;
t141 [ 2374ULL ] = X [ 76ULL ] ; for ( t197 = 0ULL ; t197 < 8ULL ; t197 ++ )
{ t141 [ t197 + 2375ULL ] = t168 [ t197 ] ; } t141 [ 2383ULL ] = X [ 74ULL ]
; t141 [ 2384ULL ] = X [ 556ULL ] ; t141 [ 2385ULL ] = - X [ 497ULL ] ; t141
[ 2386ULL ] = X [ 560ULL ] ; t141 [ 2387ULL ] = - X [ 293ULL ] ; t141 [
2388ULL ] = 0.0 ; t141 [ 2389ULL ] = 0.0 ; t141 [ 2390ULL ] = X [ 74ULL ] -
273.15 ; t141 [ 2391ULL ] = X [ 75ULL ] ; t141 [ 2392ULL ] = X [ 558ULL ] ;
t141 [ 2393ULL ] = X [ 76ULL ] ; t141 [ 2394ULL ] = X [ 38ULL ] * 0.1 ; t141
[ 2395ULL ] = 0.0 ; t141 [ 2396ULL ] = X [ 557ULL ] ; t141 [ 2397ULL ] = X [
74ULL ] ; t141 [ 2398ULL ] = X [ 75ULL ] ; t141 [ 2399ULL ] = X [ 76ULL ] ;
t141 [ 2400ULL ] = t305 ; t141 [ 2401ULL ] = X [ 466ULL ] ; t141 [ 2402ULL ]
= X [ 38ULL ] * 0.1 ; t141 [ 2403ULL ] = X [ 467ULL ] ; t141 [ 2404ULL ] = X
[ 468ULL ] ; t141 [ 2405ULL ] = - X [ 497ULL ] ; t141 [ 2406ULL ] = X [
561ULL ] ; t141 [ 2407ULL ] = - X [ 492ULL ] ; t141 [ 2408ULL ] = - X [
502ULL ] ; t141 [ 2409ULL ] = - X [ 503ULL ] ; t141 [ 2410ULL ] = X [ 562ULL
] ; t141 [ 2411ULL ] = X [ 563ULL ] ; t141 [ 2412ULL ] = X [ 553ULL ] ; t141
[ 2413ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2414ULL ] = X [ 554ULL ] ; t141 [
2415ULL ] = X [ 555ULL ] ; t141 [ 2416ULL ] = X [ 560ULL ] ; t141 [ 2417ULL ]
= X [ 564ULL ] ; t141 [ 2418ULL ] = intrm_sf_mf_1660 ; t141 [ 2419ULL ] = X [
211ULL ] ; t141 [ 2420ULL ] = X [ 213ULL ] ; t141 [ 2421ULL ] = X [ 565ULL ]
; t141 [ 2422ULL ] = X [ 566ULL ] ; t141 [ 2423ULL ] = X [ 278ULL ] ; t141 [
2424ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2425ULL ] = X [ 279ULL ] ; t141 [
2426ULL ] = X [ 280ULL ] ; t141 [ 2427ULL ] = - X [ 293ULL ] ; t141 [ 2428ULL
] = X [ 567ULL ] ; t141 [ 2429ULL ] = - X [ 288ULL ] ; t141 [ 2430ULL ] = - X
[ 295ULL ] ; t141 [ 2431ULL ] = - X [ 296ULL ] ; t141 [ 2432ULL ] = X [
568ULL ] ; t141 [ 2433ULL ] = X [ 569ULL ] ; t141 [ 2434ULL ] = - X [ 492ULL
] ; t141 [ 2435ULL ] = intrm_sf_mf_1660 ; t141 [ 2436ULL ] = - X [ 288ULL ] ;
t141 [ 2437ULL ] = 0.0 ; t141 [ 2438ULL ] = - X [ 502ULL ] ; t141 [ 2439ULL ]
= X [ 211ULL ] ; t141 [ 2440ULL ] = - X [ 295ULL ] ; t141 [ 2441ULL ] = 0.0 ;
t141 [ 2442ULL ] = 0.0 ; t141 [ 2443ULL ] = 0.0 ; t141 [ 2444ULL ] = - X [
503ULL ] ; t141 [ 2445ULL ] = X [ 213ULL ] ; t141 [ 2446ULL ] = - X [ 296ULL
] ; t141 [ 2447ULL ] = 0.0 ; t141 [ 2448ULL ] = X [ 559ULL ] ; t141 [ 2449ULL
] = X [ 175ULL ] ; t141 [ 2450ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 2451ULL ] =
X [ 177ULL ] ; t141 [ 2452ULL ] = X [ 178ULL ] ; t141 [ 2453ULL ] = X [
553ULL ] ; t141 [ 2454ULL ] = X [ 38ULL ] * 0.1 ; t141 [ 2455ULL ] = X [
554ULL ] ; t141 [ 2456ULL ] = X [ 555ULL ] ; t141 [ 2457ULL ] = X [ 570ULL ]
; t141 [ 2458ULL ] = X [ 573ULL ] ; t141 [ 2459ULL ] = X [ 175ULL ] ; t141 [
2460ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 2461ULL ] = X [ 177ULL ] ; t141 [
2462ULL ] = X [ 178ULL ] ; t141 [ 2463ULL ] = X [ 208ULL ] ; t141 [ 2464ULL ]
= X [ 574ULL ] ; t141 [ 2465ULL ] = intrm_sf_mf_1660 ; t141 [ 2466ULL ] = X [
211ULL ] ; t141 [ 2467ULL ] = X [ 213ULL ] ; t141 [ 2468ULL ] = X [ 575ULL ]
; t141 [ 2469ULL ] = X [ 576ULL ] ; t141 [ 2470ULL ] = intrm_sf_mf_1660 ;
t141 [ 2471ULL ] = X [ 571ULL ] ; t141 [ 2472ULL ] = X [ 572ULL ] ; t141 [
2473ULL ] = X [ 553ULL ] ; t141 [ 2474ULL ] = X [ 38ULL ] * 0.1 ; t141 [
2475ULL ] = X [ 554ULL ] ; t141 [ 2476ULL ] = X [ 555ULL ] ; t141 [ 2477ULL ]
= - X [ 560ULL ] ; t141 [ 2478ULL ] = X [ 574ULL ] ; t141 [ 2479ULL ] = -
intrm_sf_mf_1660 ; t141 [ 2480ULL ] = - X [ 211ULL ] ; t141 [ 2481ULL ] = - X
[ 213ULL ] ; t141 [ 2482ULL ] = X [ 575ULL ] ; t141 [ 2483ULL ] = X [ 576ULL
] ; t141 [ 2484ULL ] = - intrm_sf_mf_1660 ; t141 [ 2485ULL ] =
intrm_sf_mf_1660 ; t141 [ 2486ULL ] = X [ 208ULL ] ; t141 [ 2487ULL ] = - X [
560ULL ] ; t141 [ 2488ULL ] = X [ 211ULL ] ; t141 [ 2489ULL ] = - X [ 211ULL
] ; t141 [ 2490ULL ] = X [ 213ULL ] ; t141 [ 2491ULL ] = - X [ 213ULL ] ;
t141 [ 2492ULL ] = U_idx_4 ; t141 [ 2493ULL ] = U_idx_4 * 0.01 ; t141 [
2494ULL ] = X [ 74ULL ] ; t141 [ 2495ULL ] = X [ 74ULL ] ; t141 [ 2496ULL ] =
X [ 175ULL ] ; t141 [ 2497ULL ] = X [ 176ULL ] * 0.1 ; t141 [ 2498ULL ] = X [
177ULL ] ; t141 [ 2499ULL ] = X [ 178ULL ] ; t141 [ 2500ULL ] = U_idx_4 ;
t141 [ 2501ULL ] = ( - X [ 19ULL ] + X [ 172ULL ] * - 1.0E-9 ) - X [ 173ULL ]
; t141 [ 2502ULL ] = 0.0 ; t141 [ 2503ULL ] = Fuel_Cell_Boost_Converter_L_p_v
; t141 [ 2504ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2505ULL ] = X [
20ULL ] ; t141 [ 2506ULL ] = Fuel_Cell_Boost_Converter_L_i ; t141 [ 2507ULL ]
= Fuel_Cell_Boost_Converter_L_i ; t141 [ 2508ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2509ULL ] =
Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2510ULL ] =
Fuel_Cell_Boost_Converter_L_i ; t141 [ 2511ULL ] = - X [ 173ULL ] ; t141 [
2512ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2513ULL ] = t169_idx_0 ;
t141 [ 2514ULL ] = X [ 464ULL ] ; t141 [ 2515ULL ] = - X [ 173ULL ] ; t141 [
2516ULL ] = t169_idx_0 ; t141 [ 2517ULL ] = t285 ; t141 [ 2518ULL ] = X [
173ULL ] * - 0.001 ; t141 [ 2519ULL ] = Fuel_Cell_Boost_Converter_L_p_v ;
t141 [ 2520ULL ] = 0.0 ; t141 [ 2521ULL ] = Fuel_Cell_Boost_Converter_L_p_v ;
t141 [ 2522ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2523ULL ] = t285
; t141 [ 2524ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2525ULL ] = 0.0
; t141 [ 2526ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2527ULL ] = 0.0
; t141 [ 2528ULL ] = Fuel_Cell_Boost_Converter_L_p_v ; t141 [ 2529ULL ] = 0.0
; t141 [ 2530ULL ] = X [ 5ULL ] ; t141 [ 2531ULL ] = U_idx_13 ; t141 [
2532ULL ] = 0.0 ; t141 [ 2533ULL ] = X [ 5ULL ] ; t141 [ 2534ULL ] = t312 *
1000.0 ; t141 [ 2535ULL ] = t312 * 1000.0 ; t141 [ 2536ULL ] = - X [ 5ULL ] ;
t141 [ 2537ULL ] = X [ 5ULL ] ; t141 [ 2538ULL ] = t312 * 1.0E+6 ; t141 [
2539ULL ] = t312 * 1000.0 ; t141 [ 2540ULL ] = Fuel_Cell_Current_Sensor1_I ;
t141 [ 2541ULL ] = t312 * 1.0E+6 ; t141 [ 2542ULL ] = X [ 5ULL ] ; t141 [
2543ULL ] = X [ 5ULL ] ; t141 [ 2544ULL ] = X [ 577ULL ] * 1000.0 ; t141 [
2545ULL ] = X [ 5ULL ] ; t141 [ 2546ULL ] = 0.0 ; t141 [ 2547ULL ] =
Fuel_Cell_Current_Sensor1_I ; t141 [ 2548ULL ] = X [ 89ULL ] ; t141 [ 2549ULL
] = 0.0 ; t141 [ 2550ULL ] = X [ 89ULL ] ; t141 [ 2551ULL ] = X [ 89ULL ] ;
t141 [ 2552ULL ] = X [ 89ULL ] ; t141 [ 2553ULL ] = 0.0 ; t141 [ 2554ULL ] =
X [ 174ULL ] ; t141 [ 2555ULL ] = X [ 174ULL ] ; t141 [ 2556ULL ] = X [ 89ULL
] ; t141 [ 2557ULL ] = X [ 89ULL ] ; t141 [ 2558ULL ] = X [ 174ULL ] ; t141 [
2559ULL ] = 0.0 ; t141 [ 2560ULL ] = X [ 89ULL ] ; t141 [ 2561ULL ] = 0.0 ;
t141 [ 2562ULL ] = X [ 89ULL ] ; t141 [ 2563ULL ] = X [ 89ULL ] ; t141 [
2564ULL ] = X [ 89ULL ] ; t141 [ 2565ULL ] = X [ 89ULL ] ; t141 [ 2566ULL ] =
X [ 13ULL ] ; t141 [ 2567ULL ] = 0.0 ; t141 [ 2568ULL ] = X [ 77ULL ] ; t141
[ 2569ULL ] = X [ 77ULL ] ; t141 [ 2570ULL ] = U_idx_14 ; t141 [ 2571ULL ] =
0.0 ; t141 [ 2572ULL ] = X [ 89ULL ] ; t141 [ 2573ULL ] = 0.0 ; t141 [
2574ULL ] = X [ 13ULL ] ; t141 [ 2575ULL ] = X [ 170ULL ] * 1000.0 ; t141 [
2576ULL ] = 0.0 ; t141 [ 2577ULL ] = X [ 174ULL ] ; t141 [ 2578ULL ] = X [
578ULL ] * 1000.0 ; t141 [ 2579ULL ] = X [ 579ULL ] ; t141 [ 2580ULL ] = X [
13ULL ] ; t141 [ 2581ULL ] = X [ 580ULL ] ; t141 [ 2582ULL ] = X [ 580ULL ] ;
t141 [ 2583ULL ] = X [ 581ULL ] ; t141 [ 2584ULL ] = X [ 78ULL ] ; t141 [
2585ULL ] = X [ 89ULL ] ; t141 [ 2586ULL ] = X [ 77ULL ] * 9.5492965855137211
; t141 [ 2587ULL ] = 0.0 ; t141 [ 2588ULL ] = 0.0 ; t141 [ 2589ULL ] = 0.0 ;
t141 [ 2590ULL ] = X [ 77ULL ] ; t141 [ 2591ULL ] = U_idx_15 ; t141 [ 2592ULL
] = - X [ 579ULL ] ; t141 [ 2593ULL ] = U_idx_15 ; t141 [ 2594ULL ] = X [
77ULL ] ; t141 [ 2595ULL ] = X [ 77ULL ] ; t141 [ 2596ULL ] = - X [ 579ULL ]
; t141 [ 2597ULL ] = - X [ 579ULL ] ; t141 [ 2598ULL ] = X [ 77ULL ] ; t141 [
2599ULL ] = X [ 77ULL ] ; t141 [ 2600ULL ] = - X [ 579ULL ] ; t141 [ 2601ULL
] = - X [ 579ULL ] ; t141 [ 2602ULL ] = - X [ 579ULL ] ; t141 [ 2603ULL ] = X
[ 77ULL ] ; t141 [ 2604ULL ] = U_idx_15 ; t141 [ 2605ULL ] = U_idx_14 ; t141
[ 2606ULL ] = X [ 89ULL ] ; t141 [ 2607ULL ] = 0.0 ; t141 [ 2608ULL ] =
U_idx_0 ; t141 [ 2609ULL ] = 0.0 ; t141 [ 2610ULL ] = U_idx_0 ; t141 [
2611ULL ] = ( ( ( ( X [ 0ULL ] * 0.01 + X [ 7ULL ] * 0.0002 ) + X [ 8ULL ] *
2.0E-6 ) - X [ 122ULL ] ) + U_idx_0 * - 0.010202000000000001 ) * 1000.0 ;
t141 [ 2612ULL ] = U_idx_0 ; t141 [ 2613ULL ] = U_idx_0 ; t141 [ 2614ULL ] =
U_idx_0 ; t141 [ 2615ULL ] = 0.0 ; for ( b = 0 ; b < 2616 ; b ++ ) { out . mX
[ b ] = t141 [ b ] ; } ( void ) LC ; ( void ) t365 ; return 0 ; }
